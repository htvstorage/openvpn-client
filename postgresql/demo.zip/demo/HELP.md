# Getting Started

### Open project with intelliJ
* Install jdk 1.8
* Install maven
* Install intelliJ
* File -> Open -> {dir}/demo
* Run project in intellij
* Test api : 
	* URL : http://localhost:8080/v1/api/tsc_getListIsdnForApp
    * request : 
    	{
		    "sessionId": "43bf4176-836b-46d0-873b-f5db7fc00e3e",
		    "apiKey": "tsc_getListIsdnForApp",
		    "wsCode": "tsc_getListIsdnForApp",
		    "wsRequest": {
		        "number": "0559*****8",
		        "statusId": 1,
		        "pageNo": 0,
		        "roleId": "",
		        "pageSize": 10,
		        "isdnType": "Active",
		        "type": "portal"
		    },
		    "baseInfo": {},
		    "clientIp": "14.232.208.251"
		}
package com.example.demo.utils;

public class API {
    public static final String GET_ISDN_FOR_TOUCHSCREEN = "get_isdn_for_touchscreen";
}

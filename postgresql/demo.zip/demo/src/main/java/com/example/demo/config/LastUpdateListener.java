package com.example.demo.config;

import com.example.demo.domain.sale.Isdn;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.time.LocalDateTime;

public class LastUpdateListener {
    /**
     * automatic property set before any database persistence
     */
    @PreUpdate
    @PrePersist
    public void setLastUpdate(Isdn o) {
        o.setUpdateDate(LocalDateTime.now());
    }
}

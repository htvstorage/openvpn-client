package com.example.demo.utils;

public class EntryService {
    public static final String FORMAT_NAME = "/v1/api/";

    public static final String PREFIX_CUSTOMER_SERVICE = FORMAT_NAME;
    public static final String PREFIX_SUBSCRIBER_SERVICE = FORMAT_NAME;
    public static final String PREFIX_INVENTORY_SERVICE = FORMAT_NAME;
    public static final String PREFIX_SALE_SERVICE = FORMAT_NAME;
    public static final String PREFIX_COMMISSION_SERVICE = FORMAT_NAME;
    public static final String PREFIX_SELFCARE_SERVICE = FORMAT_NAME;
    public static final String PREFIX_REPORT_SERVICE = FORMAT_NAME;
    public static final String PREFIX_PORTAL_SERVICE = FORMAT_NAME;
    public static final String PREFIX_DISTRIBUTION_SERVICE = FORMAT_NAME;
    public static final String PREFIX_COMPLAIN_SERVICE = FORMAT_NAME;
    public static final String PREFIX_EVOUCHER_SERVICE = FORMAT_NAME;
    public static final String PREFIX_OTP_SERVICE = FORMAT_NAME;
    public static final String PREFIX_EWALLET_SERVICE = FORMAT_NAME;
    public static final String PREFIX_EXCHANGERATE_SERVICE = FORMAT_NAME;
    public static final String PREFIX_PAYMENT_SERVICE = FORMAT_NAME;
    public static final String PREFIX_GENERAL_SERVICE = FORMAT_NAME;
    public static final String PREFIX_SWITCHBOARD_SERVICE = FORMAT_NAME;
    public static final String PREFIX_THIRD_PARTY_SERVICE = FORMAT_NAME;
    public static final String PREFIX_PROMOTION_SERVICE = FORMAT_NAME;
    public static final String PREFIX_VCM_API_SERVICE = FORMAT_NAME;

    public static final String PREFIX_REDDIGO = FORMAT_NAME;
    public static final String PREFIX_AIRTIME_SERVICE = FORMAT_NAME;
    public static final String PREFIX_QRCODE_SERVICE = FORMAT_NAME;
    public static final String PREFIX_EMAIL_SERVICE = FORMAT_NAME;
    public static final String PREFIX_STOCK_SERVICE = FORMAT_NAME; //20042021 - QuocDM - R202148
    public static final String PREFIX_MNP_SERVICE = FORMAT_NAME;
}

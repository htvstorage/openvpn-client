package com.example.demo.dto.request;

import lombok.Data;

@Data
public class BaseRequestData<T extends IRequestData> {
    private String wsCode;
    private String sessionId;
    private String username;
    private String otp;
    private String token;
    private T wsRequest;
}

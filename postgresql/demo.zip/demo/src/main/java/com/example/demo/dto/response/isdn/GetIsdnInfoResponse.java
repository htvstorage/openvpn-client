package com.example.demo.dto.response.isdn;

import com.example.demo.dto.response.IResponseData;
import lombok.Data;

@Data
public class GetIsdnInfoResponse implements IResponseData {
    private String isdn;
    private String status;
    private Long statusId;
    private String type;
    private Long priceDefault;
    private String shopCode;
    private Long priceCustom;
    private String createDate;
    private String creator;
    private String objectHolding;
    private Long roleId;
    private String stock;
    private Short sold;
    private String soldName;
}

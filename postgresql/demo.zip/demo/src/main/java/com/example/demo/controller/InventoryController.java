package com.example.demo.controller;

import com.example.demo.dto.request.BaseRequestData;
import com.example.demo.dto.request.isdn.IsdnPagingResquest;
import com.example.demo.dto.response.BaseResponseData;
import com.example.demo.utils.API;
import com.example.demo.utils.EntryService;
import com.example.demo.utils.exception.ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(EntryService.PREFIX_INVENTORY_SERVICE)
@Slf4j
public class InventoryController extends BaseController {

    @PostMapping(value = "tsc_getListIsdnForApp")
    public ResponseEntity<?> tcrgetListIsdnForApp(@RequestBody BaseRequestData<IsdnPagingResquest> request) throws ApplicationException {
        IsdnPagingResquest requestData = request.getWsRequest();
        BaseResponseData response = handle(API.GET_ISDN_FOR_TOUCHSCREEN, requestData);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}

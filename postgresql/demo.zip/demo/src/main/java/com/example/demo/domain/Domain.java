package com.example.demo.domain;

import java.io.Serializable;

public class Domain implements Serializable {

}

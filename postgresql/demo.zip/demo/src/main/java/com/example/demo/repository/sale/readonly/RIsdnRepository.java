package com.example.demo.repository.sale.readonly;

import com.example.demo.domain.sale.Isdn;
import org.springframework.data.repository.CrudRepository;

public interface RIsdnRepository extends CrudRepository<Isdn, String> {
}

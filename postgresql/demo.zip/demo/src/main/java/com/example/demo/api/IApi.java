package com.example.demo.api;

import com.example.demo.dto.request.IRequestData;
import com.example.demo.dto.response.BaseResponseData;
import com.example.demo.dto.response.IResponseData;

public interface IApi {
    BaseResponseData<IResponseData> excute(IRequestData request);
}

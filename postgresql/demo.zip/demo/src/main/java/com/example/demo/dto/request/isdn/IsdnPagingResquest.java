package com.example.demo.dto.request.isdn;

import com.example.demo.dto.request.IRequestData;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.util.List;

@Data
public class IsdnPagingResquest implements IRequestData {
    private int pageNo;
    private int pageSize;
    private String number;
    private String numberBeautiful;
    private String isdnType;
    private String creator;
    private String fromDate;
    private String toDate;
    private Long roleId;
    private String type = "crm";
    private String isdn;
    private Long level;
    private String shopCode;
    private Long statusId;
    private String extension;
    private String columnSort;
    private String sortType;
    private Integer objectHolding;
    private String action = "normal";
    private Long shopId;
    private String userName;
    private Long ruleType;
    private String dateBirth;
    private List<Long> lstRole;



    @Override
    public boolean isInValid() {
        return StringUtils.isEmpty(pageNo)
                || StringUtils.isEmpty(pageSize)

                || this.pageNo < 0
                || this.pageSize < 0;
    }
}

package com.example.demo.domain.sale;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(schema = "inventory", name = "status")
public class Status {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "status_id")
    private Long statusId;

    @Column(name = "status_name")
    private String statusName;

    @Column(name = "status_table")
    private String statusTable;

    public Status(Long statusId) {
        this.statusId = statusId;
    }

    public Status() {
    }
}

package com.example.demo.api.isdn;

import com.example.demo.api.IApi;
import com.example.demo.dto.request.IRequestData;
import com.example.demo.dto.request.isdn.IsdnPagingResquest;
import com.example.demo.dto.response.BaseResponseData;
import com.example.demo.dto.response.IResponseData;
import com.example.demo.dto.response.isdn.GetListIsdnPagingResponse;
import com.example.demo.service.IsdnService;
import com.example.demo.utils.API;
import com.example.demo.utils.ApplicationCode;
import com.example.demo.utils.exception.ApplicationException;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Log4j2
@Component(value = API.GET_ISDN_FOR_TOUCHSCREEN)
public class GetListIsdnForTouchscreenApi implements IApi {
    @Autowired
    IsdnService isdnService;

    @Override
    public BaseResponseData<IResponseData> excute(IRequestData request) {
        BaseResponseData baseResponseData = new BaseResponseData();
        try {
            if (request.isInValid()) {
                throw new ApplicationException(ApplicationCode.WRONG_DATA_FORMAT);
            }

            // Validate request
            IsdnPagingResquest isdnPagingResquest = (IsdnPagingResquest) request;
            if (!StringUtils.isEmpty(isdnPagingResquest.getNumber())) {
                isdnPagingResquest.setNumber(isdnPagingResquest.getNumber().replaceAll("\\*", "_"));
            }

            // Call Service to get list Isdn
            GetListIsdnPagingResponse getListIsdnPagingResponse = isdnService.getListIsdnForTouchscreen(isdnPagingResquest);

            // Set to response
            baseResponseData.setWsResponse(getListIsdnPagingResponse);
            baseResponseData.setErrorCode(ApplicationCode.SUCCESS);
            baseResponseData.setMessage(ApplicationCode.getMessage(ApplicationCode.SUCCESS));

            // Return response
            return baseResponseData;

        } catch (ApplicationException e) {
            log.error(e);
            baseResponseData.setErrorCode(e.getCode());
            baseResponseData.setMessage(e.getMessage());

            // Return error response
            return baseResponseData;
        } finally {
            // Log request and response
            log.info("\n Request: " + request);
            log.info("\n Response: " + baseResponseData);
        }
    }
}

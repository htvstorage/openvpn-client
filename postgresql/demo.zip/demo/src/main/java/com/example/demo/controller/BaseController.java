package com.example.demo.controller;

import com.example.demo.api.IApi;
import com.example.demo.dto.request.IRequestData;
import com.example.demo.dto.response.BaseResponseData;
import com.example.demo.dto.response.IResponseData;
import com.example.demo.utils.ApplicationCode;
import com.example.demo.utils.exception.ApplicationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

public class BaseController {

    @Autowired
    private ApplicationContext context;

    protected BaseResponseData<IResponseData> handle(String apiName, IRequestData request) throws ApplicationException {
        IApi api = context.getBean(apiName, IApi.class);
        if (api == null) {
            throw new ApplicationException(ApplicationCode.API_NOT_FOUND);
        }
        return api.excute(request);
    }
}

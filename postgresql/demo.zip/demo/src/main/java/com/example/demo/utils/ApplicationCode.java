package com.example.demo.utils;

import org.springframework.util.StringUtils;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class ApplicationCode {
    private static final ApplicationCode instance = new ApplicationCode();
    private static final String[] messages = new String[2000];
    private static final Map<Integer, String> msg = new HashMap<>();
    private static final String UTF8 = "UTF-8";
    private static final String ISO_8859 = "ISO-8859-1";
    private static final String LANGUAGE_DEFAULT = "vn";

    public static final int SUCCESS = 0;
    public static final int RECHARGED_SUCCESS = 200;
    public static final int RECHARGED_FAILURE = 201;
    public static final int DATA_NOT_FOUND = 6;
    public static final int UNKNOW_ERROR = 1;
    public static final int WRONG_DATA_FORMAT = 2;
    public static final int API_NOT_FOUND = 3;

    static {
        msg.put(SUCCESS, "SUCCESS");
        msg.put(RECHARGED_SUCCESS, "RECHARGED_SUCCESS");
        msg.put(RECHARGED_FAILURE, "RECHARGED_FAILURE");
        msg.put(UNKNOW_ERROR, "UNKNOW_ERROR");
        msg.put(WRONG_DATA_FORMAT, "WRONG_DATA_FORMAT");
        msg.put(API_NOT_FOUND, "API_NOT_FOUND");
        msg.put(WRONG_DATA_FORMAT, "WRONG_DATA_FORMAT");

    }

    public static ApplicationCode getInstance() {
        return instance;
    }

    public static ResourceBundle getBundle(String language) {
        System.out.println("language_" + language);
        ResourceBundle bundle = ResourceBundle.getBundle("language_" + language);

        return bundle;
    }

    public static String getProperty(int code, String language) {
        return getBundle(language).getString(msg.get(code));

    }

    public static String getMessage(int code) {
        return getMsg(code, LANGUAGE_DEFAULT);
    }

    public static String getMessage(int code, String language) {
        if (StringUtils.isEmpty(language)) {
            language = LANGUAGE_DEFAULT;
        }

        return getMsg(code, language);
    }

    private static String getMsg(int code, String language) {
        if (msg.containsKey(code)) {
            String message = getProperty(code, language);
            try {
                String msg;
                if (code == 0) {
                    msg = new String(message.getBytes(ISO_8859), StandardCharsets.UTF_8);
                } else {
//                    msg = "[ERR_" + code + "] " + new String(message.getBytes(ISO_8859), StandardCharsets.UTF_8);
                    msg = new String(message.getBytes(ISO_8859), StandardCharsets.UTF_8);
                }
                return msg;
            } catch (UnsupportedEncodingException e) {
                return "";
            }
        }

        return "";
    }
}

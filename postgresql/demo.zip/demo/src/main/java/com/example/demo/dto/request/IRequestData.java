package com.example.demo.dto.request;

public interface IRequestData {
    boolean isInValid();
}

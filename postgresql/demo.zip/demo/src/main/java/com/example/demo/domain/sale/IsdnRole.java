package com.example.demo.domain.sale;

import com.example.demo.domain.Domain;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(schema = "inventory", name = "isdn_rule")
public class IsdnRole extends Domain {
    @Id
    @Column(name = "rule_id")
    private Long roleId;

    @Column(name = "rule_name")
    private String roleName;
    @Column(name = "default_price")
    private Long priceDefault;
    @Column(name = "regex")
    private String regex;
    @Column(name = "level")
    private Long level;
    @Column(name = "status")
    private Integer status;
    @ManyToOne
    @JoinColumn(insertable = false, updatable = false, name = "rule_id", referencedColumnName = "rule_id")
    private IsdnRuleType isdnRuleType;
    private String description;
    private String example;

    public IsdnRole(Long roleId) {
        this.roleId = roleId;
    }

    public IsdnRole() {
    }
}


package com.example.demo.service;

import com.example.demo.dto.request.isdn.IsdnPagingResquest;
import com.example.demo.dto.response.isdn.GetListIsdnPagingResponse;
import com.example.demo.utils.exception.ApplicationException;

public interface IsdnService {
    GetListIsdnPagingResponse getListIsdnForTouchscreen(IsdnPagingResquest isdnPagingResquest) throws ApplicationException;
}

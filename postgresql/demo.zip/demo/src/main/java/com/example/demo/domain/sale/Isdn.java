package com.example.demo.domain.sale;

import com.example.demo.config.LastUpdateListener;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
@Entity
@Table(schema = "inventory", name = "isdn")
@NamedStoredProcedureQueries({
        @NamedStoredProcedureQuery(
                name = "insertIsdnByFirstNumber",
                procedureName = "inventory.insertIsdn",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "firstNumberParam", type = String.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "createDateParam", type = String.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "creatorParam", type = String.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "lengthNumberParam", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "descriptionParam", type = String.class)
                }

        )
})
@EntityListeners(LastUpdateListener.class)
@AllArgsConstructor
@NoArgsConstructor
public class Isdn {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "isdn")
    private String isdn;

    @Column(name = "object_holding")
    private Integer objectHolding;

    @OneToOne()
    @JoinColumn(name = "status_id", nullable = false)
    private Status status;

    @ManyToOne
    @JoinColumn(name = "type_id")
    private IsdnType isdnType;

    @Column(name = "price_default")
    private Long priceDefault;

    @Column(name = "price_custom")
    private Long priceCustom;

    @Column(name = "shop_id")
    private Long shopId;

    @OneToOne
    @JoinColumn(name = "role_id")
    private IsdnRole isdnRole;

    @Column(name = "create_at")
    private LocalDateTime createDate;

    @Column(name = "create_by")
    private String creator;

    @Column(name = "update_at")
    private LocalDateTime updateDate;

    @Column(name = "update_by")
    private String updateBy;

    @Column(name = "session_keeping")
    private String sessionKeeping; // Session của khách hàng đang giữ số

    //    @Column(name = "sold")
    private Short sold = 0;

    private Long level;

    @Version
    private Long version;

    private Short mnp;

    public Isdn(String isdn) {
        this.isdn = isdn;
    }

}

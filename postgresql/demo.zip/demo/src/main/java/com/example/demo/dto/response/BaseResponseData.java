package com.example.demo.dto.response;

import lombok.Data;

@Data
public class BaseResponseData<T extends IResponseData> {
    Integer errorCode;
    String message;
    T wsResponse;
}

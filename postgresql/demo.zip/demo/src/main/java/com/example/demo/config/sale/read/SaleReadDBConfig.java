package com.example.demo.config.sale.read;


import com.example.demo.config.DatabaseConfig;
import com.jolbox.bonecp.BoneCPDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;

@Configuration
@ComponentScan
@EnableJpaRepositories(
        basePackages = "com.example.demo.repository.sale.readonly",
        entityManagerFactoryRef = "entityManagerFactorySaleRead",
        transactionManagerRef = "transactionManagerSaleRead")
public class SaleReadDBConfig {

    @Autowired
    DatabaseConfig config;

    @Bean("sale_read_data_source_inv_service")
    public BoneCPDataSource boneCPDataSource() {

        String username = config.getSaleReadUsername();
        String password = config.getSaleReadPassword();
        BoneCPDataSource boneCPDataSource = new BoneCPDataSource();
        boneCPDataSource.setDriverClass(config.getDriverName());
        boneCPDataSource.setJdbcUrl(config.getSaleReadUri());
        boneCPDataSource.setUsername(config.getSaleReadUsername());
        boneCPDataSource.setPassword(config.getSaleReadPassword());
        boneCPDataSource.setIdleConnectionTestPeriodInMinutes(config.getSaleReadIdleConnectionTestPeriodInMinutes());
        boneCPDataSource.setIdleMaxAgeInMinutes(config.getSaleReadIdleConnectionTestPeriodInMinutes());
        boneCPDataSource.setPoolAvailabilityThreshold(config.getSaleReadPoolAvailabilityThreshold());
        boneCPDataSource.setMaxConnectionsPerPartition(config.getSaleReadMaxConnectionsPerPartition());
        boneCPDataSource.setMinConnectionsPerPartition(config.getSaleReadMinConnectionsPerPartition());
        boneCPDataSource.setPartitionCount(config.getSaleReadPartitionCount());
        boneCPDataSource.setAcquireIncrement(config.getSaleReadAcquireIncrement());
        boneCPDataSource.setStatementsCacheSize(config.getSaleReadStatementsCacheSize());
        boneCPDataSource.setReleaseHelperThreads(config.getSaleReadReleaseHelperThreads());
        boneCPDataSource.setConnectionTestStatement(config.getSaleReadConnectionTestStatement());
        return boneCPDataSource;

    }

    @Bean("entityManagerFactorySaleRead")
    public EntityManagerFactory entityManagerFactorySaleRead(@Qualifier("sale_read_data_source_inv_service") BoneCPDataSource BoneCPDataSource) {
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setGenerateDdl(false);
        vendorAdapter.setShowSql(true);
        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
        factory.setJpaVendorAdapter(vendorAdapter);
        factory.setPackagesToScan("com.example.demo.domain.sale");
        factory.setDataSource(BoneCPDataSource);
        factory.afterPropertiesSet();

        return factory.getObject();
    }

    @Bean("transactionManagerSaleRead")
    public PlatformTransactionManager transactionManagerSaleRead(@Qualifier("entityManagerFactorySaleRead") EntityManagerFactory EntityManagerFactory) {

        JpaTransactionManager txManager = new JpaTransactionManager();
        txManager.setEntityManagerFactory(EntityManagerFactory);
        return txManager;
    }
}
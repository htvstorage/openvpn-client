package com.example.demo.domain.sale;

import com.example.demo.domain.Domain;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Table(schema = "inventory", name = "isdn_rule_type")
@Entity
public class IsdnRuleType extends Domain {
    @Id
    private Long id;

    @Column(name = "rule_type")
    private Long ruleType;

    @Column(name = "rule_id")
    private Long ruleId;

    private String description;

    @Column(name = "note")
    private String note;
}

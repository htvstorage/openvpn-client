package com.example.demo.domain.sale;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(schema = "inventory", name = "isdn_type")
@NoArgsConstructor
@AllArgsConstructor
public class IsdnType {
    @Id
    @GeneratedValue
    @Column(name = "type_id")
    private Long typeId;

    @Column(name = "type_name")
    private String typeName;

    private String description;

    public IsdnType(Long typeId) {
        this.typeId = typeId;
    }
}

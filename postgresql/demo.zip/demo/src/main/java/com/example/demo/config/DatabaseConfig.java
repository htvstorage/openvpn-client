package com.example.demo.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class DatabaseConfig {
    @Value("${application.database.driverName}")
    private String driverName;

    /*========================================= DATABASE SALE =======================================================*/
    @Value("${application.database.readSale.url}")
    private String saleReadUri;

    @Value("${application.database.readSale.username}")
    private String saleReadUsername;

    @Value("${application.database.readSale.password}")
    private String saleReadPassword;

    @Value("${application.database.readSale.IdleConnectionTestPeriodInMinutes}")
    private int saleReadIdleConnectionTestPeriodInMinutes;

    @Value("${application.database.readSale.PoolAvailabilityThreshold}")
    private int saleReadPoolAvailabilityThreshold;

    @Value("${application.database.readSale.MaxConnectionsPerPartition}")
    private int saleReadMaxConnectionsPerPartition;

    @Value("${application.database.readSale.MinConnectionsPerPartition}")
    private int saleReadMinConnectionsPerPartition;

    @Value("${application.database.readSale.PartitionCount}")
    private int saleReadPartitionCount;

    @Value("${application.database.readSale.AcquireIncrement}")
    private int saleReadAcquireIncrement;

    @Value("${application.database.readSale.StatementsCacheSize}")
    private int saleReadStatementsCacheSize;

    @Value("${application.database.readSale.ReleaseHelperThreads}")
    private int saleReadReleaseHelperThreads;

    @Value("${application.database.readSale.ConnectionTestStatement}")
    private String saleReadConnectionTestStatement;
}

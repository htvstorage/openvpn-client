package com.example.demo.service.impl;

import com.example.demo.domain.sale.Isdn;
import com.example.demo.dto.request.isdn.IsdnPagingResquest;
import com.example.demo.dto.response.isdn.GetIsdnInfoResponse;
import com.example.demo.dto.response.isdn.GetListIsdnPagingResponse;
import com.example.demo.repository.sale.readonly.RIsdnRepository;
import com.example.demo.service.IsdnService;
import com.example.demo.utils.ApplicationCode;
import com.example.demo.utils.exception.ApplicationException;
import com.google.common.base.Stopwatch;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@Log4j2
@Service
public class IsdnServiceImpl implements IsdnService {
    @Autowired
    RIsdnRepository rIsdnRepository;
    @Autowired
    @Qualifier(value = "entityManagerFactorySaleRead")
    EntityManagerFactory entityManagerFactory;

    @Transactional(transactionManager = "transactionManagerSaleRead")
    @Override
    public GetListIsdnPagingResponse getListIsdnForTouchscreen(IsdnPagingResquest isdnPagingResquest) throws ApplicationException {
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        try {
            StringBuilder builder = new StringBuilder();
            builder.append(" FROM Isdn isdn ")
                    .append(" INNER JOIN IsdnRuleType ruleType ")
                    .append(" ON ruleType.ruleId = isdn.isdnRole.roleId ")
                    .append(" WHERE isdn.status.statusId = 1 ")
                    .append(" AND ruleType.ruleType = 1 ")
                    .append(" AND isdn.sold <> 1 ")
                    .append(" AND  isdn.isdn LIKE :number")
                    .append(" AND isdn.level = :level")
                    .append(" AND isdn.shopId = :shopId ")
                    .append(" AND isdn.objectHolding <> 2 ");
            GetListIsdnPagingResponse getListIsdnPagingResponse = new GetListIsdnPagingResponse();
            List<GetIsdnInfoResponse> isdnInfoResponseList = new ArrayList<>();
            AtomicLong singleResult = new AtomicLong();
            AtomicReference<List<Isdn>> isdnList = new AtomicReference<>();
            Thread threadCount = new Thread(() -> {
                Stopwatch stopwatch = Stopwatch.createStarted();
                Query query = entityManager.createQuery("SELECT COUNT(isdn) " + builder);
                query.setParameter("number", isdnPagingResquest.getNumber());
                query.setParameter("level", 3L);
                query.setParameter("shopId", 4L);
                singleResult.set((Long) query.getSingleResult());
                stopwatch.stop();
                log.info("==== getListIsdnForTouchscreen 1: " + stopwatch.elapsed(TimeUnit.MILLISECONDS));
                stopwatch.reset();
                stopwatch.start();
            });
            threadCount.start();

            Thread threadQuery = new Thread(() -> {
                Stopwatch stopwatch = Stopwatch.createStarted();
                Query query = entityManager.createQuery("SELECT isdn " + builder + " ORDER BY random() ");
                query.setFirstResult(isdnPagingResquest.getPageNo() * isdnPagingResquest.getPageSize());
                query.setMaxResults(isdnPagingResquest.getPageSize());
                query.setParameter("number", isdnPagingResquest.getNumber());
                query.setParameter("level", 3L);
                query.setParameter("shopId", 4L);
                isdnList.set(query.getResultList());
                stopwatch.stop();
                log.info("==== getListIsdnForTouchscreen 2: " + stopwatch.elapsed(TimeUnit.MILLISECONDS));
                stopwatch.reset();
                stopwatch.start();
            });
            threadQuery.start();
            threadCount.join();
            threadQuery.join();
            if (singleResult.get() < 1) {
                throw new ApplicationException(ApplicationCode.DATA_NOT_FOUND);
            }

            isdnList.get().forEach(isdn -> {
                GetIsdnInfoResponse getIsdnInfoResponse = new GetIsdnInfoResponse();
                BeanUtils.copyProperties(isdn, getIsdnInfoResponse);
                getIsdnInfoResponse.setStatus(isdn.getStatus().getStatusName());
                getIsdnInfoResponse.setSold(isdn.getSold());
                getIsdnInfoResponse.setType(isdn.getIsdnRole().getRoleName());
                getIsdnInfoResponse.setRoleId(isdn.getIsdnRole().getRoleId());
                isdnInfoResponseList.add(getIsdnInfoResponse);
            });
            getListIsdnPagingResponse.setIsdnInfoResponseList(isdnInfoResponseList);
            getListIsdnPagingResponse.setTotalCount(singleResult.get());
            // Return data
            return getListIsdnPagingResponse;
        } catch (ApplicationException e) {
            log.error(e);
            throw new ApplicationException(e.getCode());
        } catch (Exception e) {
            log.error(e);
            log.error(e.getMessage());
            throw new ApplicationException(ApplicationCode.DATA_NOT_FOUND);
        } finally {
            entityManager.close();
        }
    }
}

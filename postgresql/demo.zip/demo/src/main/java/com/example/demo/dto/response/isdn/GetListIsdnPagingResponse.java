package com.example.demo.dto.response.isdn;

import com.example.demo.dto.response.IResponseData;
import lombok.Data;

import java.util.List;

@Data
public class GetListIsdnPagingResponse implements IResponseData {
    private List<GetIsdnInfoResponse> isdnInfoResponseList;
    private long totalCount;
    private long pageSize;
    private String fileUrl;
}

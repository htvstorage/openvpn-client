package com.example.demo.dto.response;

public interface IResponseData {
}

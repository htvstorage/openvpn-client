/*
 Navicat Premium Data Transfer

 Source Server         : UAT_SALE
 Source Server Type    : PostgreSQL
 Source Server Version : 110005
 Source Host           : 192.168.0.79:5432
 Source Catalog        : sale_uat
 Source Schema         : inventory

 Target Server Type    : PostgreSQL
 Target Server Version : 110005
 File Encoding         : 65001

 Date: 11/12/2021 10:54:28
*/


-- ----------------------------
-- Table structure for status
-- ----------------------------
DROP TABLE IF EXISTS "inventory"."status";
CREATE TABLE "inventory"."status" (
  "status_id" int8 NOT NULL,
  "status_name" varchar(255) COLLATE "pg_catalog"."default",
  "status_table" varchar(255) COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "inventory"."status" OWNER TO "postgres";
COMMENT ON COLUMN "inventory"."status"."status_id" IS 'id bản ghi';
COMMENT ON COLUMN "inventory"."status"."status_name" IS 'tên trạng thái';
COMMENT ON COLUMN "inventory"."status"."status_table" IS 'tên bảng';

-- ----------------------------
-- Records of status
-- ----------------------------
BEGIN;
INSERT INTO "inventory"."status" VALUES (4, 'private', 'isdn');
INSERT INTO "inventory"."status" VALUES (6, 'deposited', 'isdn');
INSERT INTO "inventory"."status" VALUES (7, 'evicted', 'isdn');
INSERT INTO "inventory"."status" VALUES (2, 'hightlight', NULL);
INSERT INTO "inventory"."status" VALUES (1, 'active', 'isdn,sim');
INSERT INTO "inventory"."status" VALUES (3, 'delete', 'isdn,sim');
INSERT INTO "inventory"."status" VALUES (0, 'inactive', 'isdn,sim');
INSERT INTO "inventory"."status" VALUES (8, 'broken', 'sim');
INSERT INTO "inventory"."status" VALUES (9, 'returning', 'sim,kit');
INSERT INTO "inventory"."status" VALUES (5, 'used', 'isdn,sim');
INSERT INTO "inventory"."status" VALUES (11, 'holding', 'isdn');
INSERT INTO "inventory"."status" VALUES (10, 'revoking', 'sim,kit,isdn');
COMMIT;

-- ----------------------------
-- Indexes structure for table status
-- ----------------------------
CREATE INDEX "status_indexx" ON "inventory"."status" USING btree (
  "status_name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table status
-- ----------------------------
ALTER TABLE "inventory"."status" ADD CONSTRAINT "status_pkey" PRIMARY KEY ("status_id");

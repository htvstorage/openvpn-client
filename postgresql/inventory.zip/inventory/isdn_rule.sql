/*
 Navicat Premium Data Transfer

 Source Server         : UAT_SALE
 Source Server Type    : PostgreSQL
 Source Server Version : 110005
 Source Host           : 192.168.0.79:5432
 Source Catalog        : sale_uat
 Source Schema         : inventory

 Target Server Type    : PostgreSQL
 Target Server Version : 110005
 File Encoding         : 65001

 Date: 11/12/2021 10:53:45
*/


-- ----------------------------
-- Table structure for isdn_rule
-- ----------------------------
DROP TABLE IF EXISTS "inventory"."isdn_rule";
CREATE TABLE "inventory"."isdn_rule" (
  "rule_id" int8 NOT NULL,
  "rule_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "regex" text COLLATE "pg_catalog"."default",
  "status" int4 DEFAULT 0,
  "level" int4 DEFAULT 1,
  "default_price" int8,
  "description" text COLLATE "pg_catalog"."default",
  "example" text COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "inventory"."isdn_rule" OWNER TO "postgres";
COMMENT ON COLUMN "inventory"."isdn_rule"."rule_id" IS 'id của bảng';
COMMENT ON COLUMN "inventory"."isdn_rule"."rule_name" IS 'Tên loại số đep';
COMMENT ON COLUMN "inventory"."isdn_rule"."regex" IS 'Regex của loại số đẹp';
COMMENT ON COLUMN "inventory"."isdn_rule"."status" IS 'Trạng thái của rule';
COMMENT ON COLUMN "inventory"."isdn_rule"."level" IS 'Độ ưu tiên của rule';
COMMENT ON COLUMN "inventory"."isdn_rule"."default_price" IS 'Giá mặc định của rule';
COMMENT ON COLUMN "inventory"."isdn_rule"."description" IS 'Mô tả';
COMMENT ON COLUMN "inventory"."isdn_rule"."example" IS 'Ví dụ về rule';

-- ----------------------------
-- Records of isdn_rule
-- ----------------------------
BEGIN;
INSERT INTO "inventory"."isdn_rule" VALUES (4, 'Lặp 3', NULL, 1, 0, 190000000, 'A khác B;A,B là 6,8,9', '0559.AB.AB.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (5, 'Lặp 4 (tứ quý)', NULL, 1, 0, 235000000, 'A khác B; A là 9', '0559.AA.BBBB');
INSERT INTO "inventory"."isdn_rule" VALUES (6, 'Lặp 4', NULL, 1, 0, 300000000, NULL, '05.59.59.59.59');
INSERT INTO "inventory"."isdn_rule" VALUES (7, 'Soi gương 3', NULL, 1, 0, 90000000, 'X khác 9', '055.999.X.999');
INSERT INTO "inventory"."isdn_rule" VALUES (8, 'Lặp 4 (tứ quý)', NULL, 1, 0, 250000000, 'A là 6,8,9', '055.9999.AAA');
INSERT INTO "inventory"."isdn_rule" VALUES (9, 'Lặp 5 (ngũ quý)', NULL, 1, 0, 80000000, 'A khác 9', '055.99999.AA');
INSERT INTO "inventory"."isdn_rule" VALUES (10, 'Đảo 2', NULL, 1, 0, 65000000, 'A,B là 6,8,9', '0559.A.ABBA.A');
INSERT INTO "inventory"."isdn_rule" VALUES (11, 'Lặp 3 (tam hoa)', NULL, 1, 0, 60000000, 'A khác B', '0559.BBB.AAA');
INSERT INTO "inventory"."isdn_rule" VALUES (12, 'Lùi 7', NULL, 1, 0, 60000000, NULL, '055.9876.543');
INSERT INTO "inventory"."isdn_rule" VALUES (13, 'Lặp 5 (ngũ quý)', NULL, 1, 0, 50000000, 'A khác B', '055.99999.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (15, 'Lặp 5 (ngũ quý)', NULL, 1, 0, 90000000, 'A khác B; A là 6,8,9', '0559.AAAAA.B');
INSERT INTO "inventory"."isdn_rule" VALUES (16, 'Lặp 6 (lục quý)', NULL, 1, 0, 330000000, 'A khác 9', '05599.99.99.A');
INSERT INTO "inventory"."isdn_rule" VALUES (17, 'Lặp 2', NULL, 1, 0, 40000000, 'A,B,C là 6,8,9', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (18, 'Đảo 2', NULL, 1, 0, 40000000, 'A và B là 6,8,9', '0559.AB.AB.BA');
INSERT INTO "inventory"."isdn_rule" VALUES (19, 'Lặp 4 (tứ quý)', NULL, 1, 0, 70000000, 'A khác C; A là 6,8,9', '0559.BC.AAAA');
INSERT INTO "inventory"."isdn_rule" VALUES (20, 'Lặp 3', NULL, 1, 0, 35000000, 'A khác B;A,B khác 6,8,9', '0559.AB.AB.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (21, 'Tiến 3 (C=B+2)', NULL, 1, 0, 30000000, 'C=B+2=A+4, C khác X', '0559.ABC.XXX');
INSERT INTO "inventory"."isdn_rule" VALUES (22, 'Lặp 3', NULL, 1, 0, 25000000, NULL, '0.559.559.559');
INSERT INTO "inventory"."isdn_rule" VALUES (23, 'Lùi 3 (C=B-1)', NULL, 1, 0, 25000000, 'C=B-1=A-2', '0559.CBA.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (24, 'Tiến 3 (C=B+2)', NULL, 1, 0, 25000000, 'C=B+2=A+4', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (25, 'Tiến 3 (C=B+3)', NULL, 1, 0, 25000000, 'C=B+3=A+6', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (26, 'Lặp 3 (tam hoa)', NULL, 1, 0, 15000000, 'A khác 9;A khác B', '0559.AA.B.AAA');
INSERT INTO "inventory"."isdn_rule" VALUES (27, 'Lặp 2', NULL, 1, 0, 2850000, 'A,B là 6,8,9', '0559.CD.AB.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (28, 'Lặp 4 (tứ quý)', NULL, 1, 0, 6165000, 'A khác B,C', '0559.B.AAAA.C');
INSERT INTO "inventory"."isdn_rule" VALUES (29, 'Lặp 4 (tứ quý)', NULL, 1, 0, 12000000, 'A khác 9', '055.9999.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (30, 'Lùi 3 (C=B-1)', NULL, 1, 2, 10000000, 'C=B-1=A-2; C khác X', '0559.ABC.XXX');
INSERT INTO "inventory"."isdn_rule" VALUES (32, 'Lùi 6 (F=E-1)', NULL, 1, 2, 0, 'A khác 9; F= E-1 =D-2 =C-3 = B-4 = A-5', '0559.ABCDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (33, 'Lặp 2', NULL, 1, 0, 0, 'A khác 6,8,9', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (34, 'Lùi 3 (C=B-3)', NULL, 1, 0, 0, 'C=B-3=A-6', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (35, 'Lùi 3 (C=B-1)', NULL, 1, 0, 0, 'C=B-1=A-2', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (36, 'Lặp 3 (tam hoa)', NULL, 1, 1, 0, 'A khác B,C,D; A khác 9', '055.999.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (37, 'Lặp 4 (tứ quý)', NULL, 1, 2, 0, 'A khác 9; A khác B', '0559.AAAA.BC');
INSERT INTO "inventory"."isdn_rule" VALUES (38, 'Lùi 3 (C=B-1)', NULL, 1, 4, 0, 'A khác 9; D=C-1=B-2=A-3', '0559.AA.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (39, 'Lùi 3 (C=B-2)', NULL, 1, 5, 0, 'A khác 9; C=B-2=A-4', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (40, 'Lặp 3 (tam hoa)', NULL, 1, 1, 0, 'A khác D; A là 6,8,9', '0559.BCD.AAA');
INSERT INTO "inventory"."isdn_rule" VALUES (41, 'Lùi 3 (C=B-1)', NULL, 1, 0, 0, 'X khác 9; D=C-1=B-2=A-3; A khác X', '0559.XX.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (42, 'Lùi 4 (D=C-1)', NULL, 1, 6, 0, 'D =C-1 = B-2 = A-3', '0559.ABCD.DD');
INSERT INTO "inventory"."isdn_rule" VALUES (43, 'Tiến 4 (D=C+2)', NULL, 1, 5, 0, 'D=C+2=B+4=A+6', '0559.ABCD.DD');
INSERT INTO "inventory"."isdn_rule" VALUES (44, 'Tiến 4 (D=C+2)', NULL, 1, 4, 0, 'D=C+2=B+4=A+6', '0559.DD.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (45, 'Tiến 3 (C=B+3)', NULL, 1, 2, 0, 'C=B+3=A+6; C khác X', '0559.ABC.XXX');
INSERT INTO "inventory"."isdn_rule" VALUES (46, 'Tiến 3 (C=B+3)', NULL, 1, 3, 0, 'X khác 9; C=B+3=A+6; A khác X', '0559.XXX.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (47, 'Đảo 2', NULL, 1, 1, 0, 'A và B khác 6,8', '0559.BA.AB.BA');
INSERT INTO "inventory"."isdn_rule" VALUES (48, 'Lặp 3 (tam hoa)', NULL, 1, 1, 0, 'A khác B', '0559.AAA.BCD');
INSERT INTO "inventory"."isdn_rule" VALUES (49, 'Lặp 3 (tam hoa)', NULL, 1, 2, 0, 'A khác B; A khác C', '0559.B.AAA.CD');
INSERT INTO "inventory"."isdn_rule" VALUES (50, 'Lặp 3 (tam hoa)', NULL, 1, 3, 0, 'A khác C,D', '0559.BC.AAA.D');
INSERT INTO "inventory"."isdn_rule" VALUES (51, 'Lùi 3 (C=B-2)', NULL, 1, 4, 0, 'C=B-2=A-4; C khác X', '0559.ABC.XXX');
INSERT INTO "inventory"."isdn_rule" VALUES (52, 'Lùi 3 (C=B-2)', NULL, 1, 8, 0, 'X khác 9; C=B-2=A-4; A khác X', '0559.XXX.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (53, 'Lùi 3 (C=B-3)', NULL, 1, 5, 0, 'C=B-3=A-6; C khác X', '0559.ABC.XXX');
INSERT INTO "inventory"."isdn_rule" VALUES (55, 'Lùi 3 (C=B-1)', NULL, 1, 2, 0, 'C=B-1=A-2', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (56, 'Đảo 2', NULL, 1, 0, 0, 'A và B khác 6,8', '0559.AB.AB.BA');
INSERT INTO "inventory"."isdn_rule" VALUES (57, 'Lùi 4 (D=C-1)', NULL, 1, 3, 0, 'D =C-1 = B-2 = A-3; D khác X', '0559.ABCD.XX');
INSERT INTO "inventory"."isdn_rule" VALUES (58, 'Lùi 4 (D=C-1)', NULL, 1, 2, 0, 'E khác 9; D=C-1=B-2=A-3; A khác F', '0559.EF.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (59, 'Tiến 4 (D=C+2)', NULL, 1, 4, 0, 'X khác 9; D=C+2=B+4=A+6, A khác X', '0559.XX.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (60, 'Lùi 4 (D=C-2)', NULL, 1, 5, 0, 'X khác 9; D=C-2=B-4=A-6; A khác X', '0559.XX.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (61, 'Lùi 4 (D=C-1)', NULL, 1, NULL, 0, 'F khác 9; E=D-1=C-2=B-3=A-4;A khác F', '0559.E.ABCD.F');
INSERT INTO "inventory"."isdn_rule" VALUES (62, 'Lùi 3 (C=B-2)', NULL, 1, 0, 0, 'C=B-2=A-4', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (63, 'Tiến 3 (C=B+3)', NULL, 1, 0, 0, 'A khác 9; C=B+3=A+6', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (64, 'Tiến 3 (C=B+3)', NULL, 1, 0, 0, 'C=B+3=A+6', '0559.CBA.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (65, 'Lùi 3 (C=B-3)', NULL, 1, 0, 0, 'C=B-3=A-6', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (66, 'Đảo 3', NULL, 1, 0, 0, 'A,B,C khác 9; A khác B', '055.9AB.AB9.C');
INSERT INTO "inventory"."isdn_rule" VALUES (67, 'Lặp 2', NULL, 1, 0, 0, 'C khác 9;A,B khác 6,8,9', '0559.CD.ABAB');
INSERT INTO "inventory"."isdn_rule" VALUES (68, 'Năm sinh 19xx', NULL, 1, 0, 0, 'xx chạy từ 50 đến 99; AB khác 99', '0559.AB.19xx');
INSERT INTO "inventory"."isdn_rule" VALUES (69, 'Năm sinh 20xx', NULL, 1, 0, 0, 'xx chạy từ 00 đến 05; AB khác 99', '0559.AB.20xx');
INSERT INTO "inventory"."isdn_rule" VALUES (70, 'Lùi 3 (C=B-1)', NULL, 1, 5, 0, 'X khác 9;C=B-1=A-2; A khác X', '0559.XXX.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (71, 'Tiến 4 (D=C+2)', NULL, 1, 1, 0, 'E khác 9; D=C+2=B+4=A+6; A khác F', '0559.EF.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (72, 'Lùi 3 (C=B-2)', NULL, 1, 4, 0, 'C khác 9; C=B-2=A-4', '0559.CBA.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (73, 'Lùi 3 (C=B-3)', NULL, 1, 6, 0, 'C khác 9; C=B-3=A-6', '0559.CBA.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (74, 'Lùi 3 (C=B-3)', NULL, 1, 7, 0, 'X khác 9; C=B-3=A-6; A khác X', '0559.XXX.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (75, 'Soi gương 2', NULL, 1, 3, 0, 'A và B là 6,8,9; B khác X; A khác B', '055.99.AB.X.BA ');
INSERT INTO "inventory"."isdn_rule" VALUES (76, 'Soi gương 2', NULL, 1, 2, 0, 'A khác 9; A khác X', '055.99.AA.X.AA');
INSERT INTO "inventory"."isdn_rule" VALUES (77, 'Tiến 4 (D=C+2)', NULL, 1, 0, 990, 'A khác 9; D=C+2=B+4=A+6; D khác E', '0559.ABCD.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (78, 'Tiến 4 (D=C+2)', NULL, 1, 0, 990, 'D=C+2=B+4=A+6; D khác F', '0559.E.ABCD.F');
INSERT INTO "inventory"."isdn_rule" VALUES (139, 'Tiến 3 (C=B+3)', NULL, 1, 40, 400, 'D khác 9; C=B+3=A+6; C khác E; A khác D', '0559.D.ABC.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (140, 'Tiến 3 (C=B+3)', NULL, 1, 41, 400, 'D khác 9; A khác E; C=B+3=A+6; C khác F', '0559.DE.ABC.F');
INSERT INTO "inventory"."isdn_rule" VALUES (141, 'Tiến 2 (B=A+3)', NULL, 1, 21, 400, 'C khác 9; B=A+3; A khác F', '0559.CDEF.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (142, 'Tiến 3 (C=B+3)', NULL, 1, 42, 400, 'D khác 9; C=B+3=A+6; A khác F', '0559.DEF.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (143, 'Lùi 3 (C=B-3)', NULL, 1, 37, 400, 'A khác 9; C=B-3;A-6; C khác D', '0559.ABC.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (144, 'Lùi 3 (C=B-3)', NULL, 1, 33, 400, 'D khác 9; C=B-3=A-6; C khác E', '0559.D.ABC.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (145, 'Lùi 3 (C=B-3)', NULL, 1, 34, 400, 'D khác 9; C=B-3=A-6; A khác E, C khác F', '0559.DE.ABC.F');
INSERT INTO "inventory"."isdn_rule" VALUES (146, 'Lùi 3 (C=B-3)', NULL, 1, 35, 400, 'D khác 9; C =B-3=A-6; A khác F', '0559.DEF.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (79, 'Lùi 4 (D=C-2)', NULL, 1, 0, 990, 'D=C-2=B-4=A-6', '0559.ABCD.DD');
INSERT INTO "inventory"."isdn_rule" VALUES (80, 'Lùi 5 (E=D-1)', NULL, 1, 4, 900, 'E=D-1 =C-2 = B-3 = A-4; F khác E', '0559.ABCDE.F');
INSERT INTO "inventory"."isdn_rule" VALUES (81, 'Lùi 4 (D=C-2)', NULL, 1, 2, 800, 'D khác 9; D=C-2=B-4=A-6', '0559.DD.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (82, 'Soi gương 3', NULL, 1, 1, 800, 'A khác 9; A khác X', '055.99A.X.A99');
INSERT INTO "inventory"."isdn_rule" VALUES (83, 'Đảo 3', NULL, 1, 0, 750, 'A khác 9; A khác B,C', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (84, 'Tiến 3 (C=B+2)', NULL, 1, 2, 700, 'C khác 9; C=B+2=A+4', '0559.CBA.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (85, 'Soi gương 3', NULL, 1, 1, 700, 'A và B khác 9; A khác B,X', '055.9AB.X.BA9');
INSERT INTO "inventory"."isdn_rule" VALUES (87, 'Lặp 2', NULL, 1, 1, 600, 'A,B khác 9; A khác B,C', '055.9AB.9AB.C');
INSERT INTO "inventory"."isdn_rule" VALUES (88, 'Tiến 3 (C=B+2)', NULL, 1, 6, 600, 'X khác 9; C=B+2=A+4, A khác X', '0559.XXX.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (89, 'Đảo 4', NULL, 1, 4, 600, 'A,B khác 9; A khác B', '05.59AB.BA95');
INSERT INTO "inventory"."isdn_rule" VALUES (90, 'Đảo 5', NULL, 1, 5, 600, 'A khác 5,9', '0559A.A9550');
INSERT INTO "inventory"."isdn_rule" VALUES (91, 'Lùi 4 (D=C-2)', NULL, 1, 3, 500, 'E khác 9; D=C-2=B-4=A-6; A khác F', '0559.EF.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (92, 'Đảo 4', NULL, 1, 5, 500, 'A khác 0; A khác B', '0559.9550.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (93, 'Soi gương 2', NULL, 1, 4, 500, 'A khác 9; A khác B,C; B khác X', '0559.AB.X.BA.C');
INSERT INTO "inventory"."isdn_rule" VALUES (94, 'Soi gương 2', NULL, 1, 2, 500, 'C khác 9; A khác B,C; B khác X', '0559.C.AB.X.BA');
INSERT INTO "inventory"."isdn_rule" VALUES (95, 'Soi gương 2', NULL, 1, 1, 500, 'A và B khác 6,8,9; B khác X', '055.99.AB.X.BA');
INSERT INTO "inventory"."isdn_rule" VALUES (96, 'Ngày - Tháng - Năm', NULL, 1, 0, 900, 'DD từ 01 đến 31, MM từ 01 đến 12, YY từ 00-05 và 50-99', '0559.DD.MM.YY');
INSERT INTO "inventory"."isdn_rule" VALUES (97, 'Tháng - Ngày - Năm', NULL, 1, 0, 600, 'DD từ 01 đến 31, MM từ 01 đến 12, YY từ 00-05 và 50-99', '0559.MM.DD.YY');
INSERT INTO "inventory"."isdn_rule" VALUES (98, 'Lùi 4 (D=C-1)', NULL, 1, 3, 490, 'E khác 9; D=C-1=B-2=A-3; A khác E; D khác F', '0559.E.ABCD.F');
INSERT INTO "inventory"."isdn_rule" VALUES (99, 'Tiến 3 (C=B+2)', NULL, 1, 2, 490, 'A khác 9; C=B+2=A+4', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (100, 'Soi gương 4', NULL, 1, 1, 490, 'A khác 9; A khác X', '05.59A.X.A955');
INSERT INTO "inventory"."isdn_rule" VALUES (101, 'Lùi 4 (D=C-2)', NULL, 1, 0, 450, 'A khác 9; D=C-2=B-4=A-6; D khác E', '0559.ABCD.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (102, 'Đảo 2', NULL, 1, 0, 450, 'A,B khác 9; A khác B, A khác C', '0559.ABBA.CD');
INSERT INTO "inventory"."isdn_rule" VALUES (103, 'Lặp 2', NULL, 1, 7, 400, 'A khác 9;A khác B', '0559.AA.BCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (104, 'Lặp 2', NULL, 1, 6, 400, 'A khác 9; A khác B', '05599.ABCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (105, 'Lặp 2', NULL, 1, 9, 400, 'B khác 9; A khác B,C', '0559.B.AA.CDE');
INSERT INTO "inventory"."isdn_rule" VALUES (106, 'Lặp 2', NULL, 1, 8, 400, 'B khác 9; A khác C,D', '0559.BC.AA.DE');
INSERT INTO "inventory"."isdn_rule" VALUES (107, 'Lặp 2', NULL, 1, 10, 400, 'B khác 9; A khác D,E', '0559.BCD.AA.E');
INSERT INTO "inventory"."isdn_rule" VALUES (108, 'Lặp 2', NULL, 1, 11, 400, 'B khác 9; A khác E', '0559.BCDE.AA');
INSERT INTO "inventory"."isdn_rule" VALUES (109, 'Lặp 2', NULL, 1, 22, 400, 'A khác 9; A khác B,C', '0559.ABAB.CD');
INSERT INTO "inventory"."isdn_rule" VALUES (110, 'Lặp 2', NULL, 1, NULL, 400, 'A khác 9;A khác B,C,D,E', '05599.ABCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (111, 'Lặp 2', NULL, 1, 23, 400, 'A khác 9;A khác B,C,D', '05.59AB.59CD');
INSERT INTO "inventory"."isdn_rule" VALUES (112, 'Lặp 2', NULL, 1, 24, 400, 'C khác 9; A khác B,C,D', '0559.C.ABAB.D');
INSERT INTO "inventory"."isdn_rule" VALUES (113, 'Lùi 3 (C=B-1)', NULL, 1, 25, 400, 'A khác 9; C=B-1=A-2; C khác D', '0559.ABC.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (114, 'Lùi 3 (C=B-1)', NULL, 1, 26, 400, 'D khác 9; C=B-1=A-2; A khác D;C khác E', '0559.D.ABC.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (115, 'Lùi 3 (C=B-1)', NULL, 1, 27, 400, 'D khác 9; C=B-1=A-2; A khác E;C khác F', '0559.DE.ABC.F');
INSERT INTO "inventory"."isdn_rule" VALUES (116, 'Lùi 5 (E=D-1)', NULL, 1, NULL, 950, 'E=D-1 =C-2 = B-3 = A-4; A khác F', '0559.F.ABCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (117, 'Lùi 2 (B=A-1)', NULL, 1, 28, 400, 'D khác 9; C=B-1=A-2; A khác F', '0559.DEF.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (119, 'Tiến 3 (C=B+2)', NULL, 1, 44, 400, 'A khác 9; C=B+2=A+4; C khác D', '0559.ABC.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (120, 'Tiến 4 (D=C+2)', NULL, 1, 1, 400, 'A khác 9; D=C+2=B+4=A+6; D khác X', '0559.ABCD.XX');
INSERT INTO "inventory"."isdn_rule" VALUES (121, 'Tiến 2 (B=A+2)', NULL, 1, 13, 400, 'C khác 9; B=A+2; B khác D; A khác C', '0559.C.AB.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (122, 'Tiến 2 (B=A+2)', NULL, 1, 14, 400, 'C khác 9; B=A+2; B khác E; A khác D', '0559.CD.AB.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (123, 'Tiến 2 (B=A+2)', NULL, 1, 15, 400, 'C khác 9; B=A+2; A khác E; B khác F', '0559.CDE.AB.F');
INSERT INTO "inventory"."isdn_rule" VALUES (124, 'Tiến 3 (C=B+2)', NULL, 1, 43, 400, 'D khác 9; C=B+2=A+4; C khác E; A khác D', '0559.D.ABC.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (125, 'Tiến 3 (C=B+2)', NULL, 1, 39, 400, 'D khác 9; C=B+2=A+4; C khác F; A khác E', '0559.DE.ABC.F');
INSERT INTO "inventory"."isdn_rule" VALUES (126, 'Tiến 2 (B=A+2)', NULL, 1, 16, 400, 'C khác 9; B=A+2; F khác A', '0559.CDEF.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (127, 'Tiến 3 (C=B+2)', NULL, 1, 38, 400, 'D khác 9; C=B+2=A+4; A khác F', '0559.DEF.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (128, 'Lùi 3 (C=B-2)', NULL, 1, 29, 400, 'A khác 9; C=B-2=A-4, C khác D', '0559.ABC.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (129, 'Lùi 4 (D=C-2)', NULL, 1, 3, 400, 'D=C-2=B-4=A-6; D khác X', '0559.ABCD.XX');
INSERT INTO "inventory"."isdn_rule" VALUES (130, 'Lùi 3 (C=B-2)', NULL, 1, 30, 400, 'D khác 9; C=B-2=A-4; C khác E; A khác D', '0559.D.ABC.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (131, 'Lùi 3 (C=B-2)', NULL, 1, 31, 400, 'D khác 9; D khác E; C=B-2=A-4; C khác F', '0559.DE.ABC.F');
INSERT INTO "inventory"."isdn_rule" VALUES (132, 'Lùi 4 (D=C-2)', NULL, 1, 45, 400, 'D=C-2=B-4=A-6; D khác F; A khác E', '0559.E.ABCD.F');
INSERT INTO "inventory"."isdn_rule" VALUES (133, 'Lùi 3 (C=B-2)', NULL, 1, 32, 400, 'D khác 9; C=B-2=A-4; A khác F', '0559.DEF.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (134, 'Tiến 2 (B=A+3)', NULL, 1, 17, 400, 'A khác 9; B=A+3; B khác C', '0559.AB.CDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (135, 'Tiến 3 (C=B+3)', NULL, 1, 46, 400, 'A khác 9; C=B+3=A+6; C khác D', '0559.ABC.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (136, 'Tiến 2 (B=A+3)', NULL, 1, 18, 400, 'C khác 9; B=A+3; B khác D', '0559.C.AB.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (138, 'Tiến 2 (B=A+3)', NULL, 1, 19, 400, 'C khác 9; B=A+3; A khác E; B khác F', '0559.CDE.AB.F');
INSERT INTO "inventory"."isdn_rule" VALUES (209, 'Lặp tam hoa', NULL, 1, 0, 0, 'A khác B, A khác 6,8,9', '055.999.AAA.B');
INSERT INTO "inventory"."isdn_rule" VALUES (210, 'Lặp 3 (tam hoa)', NULL, 1, 0, 0, 'A khác 9', '055.999.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (211, 'Lặp 2', NULL, 1, 3, 0, 'A là 6,8; B,C là 6,8,9; B khác C', '055.99.AA.BB.C');
INSERT INTO "inventory"."isdn_rule" VALUES (212, 'Lặp 2', NULL, 1, 3, 450, 'A khác 9; B khác C', '055.99.AA.BB.C');
INSERT INTO "inventory"."isdn_rule" VALUES (213, 'Lặp 2', NULL, 1, 2, 0, 'A khác 9; C là 6,8,9', '055.99.AA.B.CC');
INSERT INTO "inventory"."isdn_rule" VALUES (214, 'Lặp 2', NULL, 1, 2, 450, 'A khác 9; C khác 6,8,9', '055.99.AA.B.CC');
INSERT INTO "inventory"."isdn_rule" VALUES (215, 'Lặp 2', NULL, 1, 1, 0, 'A khác 9; B khác C; C là 6,8,9', '055.99.A.BB.CC');
INSERT INTO "inventory"."isdn_rule" VALUES (148, 'Đảo 2', NULL, 1, 5, 400, 'C khác 9; A khác B,C,D', '0559.C.ABBA.D');
INSERT INTO "inventory"."isdn_rule" VALUES (149, 'Đảo 2', NULL, 1, 4, 400, 'C khác 9; A khác B,D', '0559.CD.ABBA');
INSERT INTO "inventory"."isdn_rule" VALUES (150, 'Năm sinh 19xx', NULL, 1, 0, 400, 'xx chạy từ 50 đến 99; AB khác xx', '0559.19xx.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (151, 'Năm sinh 19xx', NULL, 1, 0, 400, 'xx chạy từ 50 đến 99; A khác 9', '0559.A.19xx.B');
INSERT INTO "inventory"."isdn_rule" VALUES (152, 'Năm sinh 20xx', NULL, 1, 0, 400, 'xx chạy từ 00 đến 05', '0559.20xx.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (153, 'Năm sinh 20xx', NULL, 1, 0, 400, 'xx chạy từ 00 đến 05', '0559.A.20xx.B');
INSERT INTO "inventory"."isdn_rule" VALUES (155, 'Năm - Ngày - Tháng', NULL, 1, 0, 600, 'DD từ 01 đến 31, MM từ 01 đến 12, YY từ 00-05 và 50-99', '0559.YY.DD.MM');
INSERT INTO "inventory"."isdn_rule" VALUES (156, 'Lùi 2 (B=A-1)', NULL, 1, 3, 350, 'A khác 9; B=A-1; B khác C', '0559.AB.CDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (157, 'Lùi 2 (B=A-1)', NULL, 1, 4, 350, 'C khác 9; B=A-1; B khác D; A khác C', '0559.C.AB.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (158, 'Lùi 2 (B=A-1)', NULL, 1, 5, 350, 'C khác 9; A khác D; B=A-1; B khác E', '0559.CD.AB.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (159, 'Lùi 2 (B=A-1)', NULL, 1, 6, 350, 'C khác 9; B=A-1; A khác E; B khác F', '0559.CDE.AB.F');
INSERT INTO "inventory"."isdn_rule" VALUES (160, 'Lùi 2 (B=A-2)', NULL, 1, 7, 350, 'A khác 9; B=A-2; B khác C', '0559.AB.CDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (161, 'Lùi 2 (B=A-2)', NULL, 1, 8, 350, 'C khác 9; B=A-2; B khác D; A khác C', '0559.C.AB.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (162, 'Lùi 2 (B=A-2)', NULL, 1, 9, 350, 'C khác 9; A khác C,D; B=A-2; B khác E', '0559.CD.AB.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (163, 'Lùi 2 (B=A-2)', NULL, 1, 10, 350, 'C khác 9; A khác E; B=A-2; B khác F', '0559.CDE.AB.F');
INSERT INTO "inventory"."isdn_rule" VALUES (164, 'Lùi 2 (B=A-2)', NULL, 1, 11, 350, 'C khác 9; B=A-2; A khác F', '0559.CDEF.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (165, 'Lùi 2 (B=A-3)', NULL, 1, 12, 350, 'A khác 9; B=A-3; B khác C', '0559.AB.CDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (166, 'Lùi 2 (B=A-3)', NULL, 1, 18, 350, 'C khác 9; B=A-3; B khác D; A khác C', '0559.C.AB.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (167, 'Lùi 2 (B=A-3)', NULL, 1, 15, 350, 'C khác 9; B=A-3; B khác E; A khác D', '0559.CD.AB.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (168, 'Lùi 2 (B=A-3)', NULL, 1, 17, 350, 'C khác 9; B=A-3; A khác E; B khác F', '0559.CDE.AB.F');
INSERT INTO "inventory"."isdn_rule" VALUES (169, 'Lùi 2 (B=A-3)', NULL, 1, 16, 350, 'C khác 9; B =A-3; A khác F', '0559.CDEF.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (170, 'Tiến 3 (C=B+1)', NULL, 1, 1, 425, 'A khác 9; C=B+1=A+2; C khác D', '0559.ABC.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (171, 'Tiến 3 (C=B+1)', NULL, 1, 3, 425, 'D khác 9; C= B+1 = A+2; A khác D, C khác E', '0559.D.ABC.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (172, 'Tiến 3 (C=B+1)', NULL, 1, 2, 425, 'D khác 9; C= B+1 = A+2; A khác E; C khác F', '0559.DE.ABC.F');
INSERT INTO "inventory"."isdn_rule" VALUES (173, 'Tiến 3 (C=B+1)', NULL, 1, 1, 450, 'D khác 9; C= B+1 = A+2; A khác F', '0559.DEF.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (174, 'Tiến 3 (C=B+1)', NULL, 1, 1, 0, 'A khác 9; C= B+1 = A+2; C khác X', '0559.ABC.XXX');
INSERT INTO "inventory"."isdn_rule" VALUES (175, 'Tiến 3 (C=B+1)', NULL, 1, 6, 0, 'C= B+1 = A+2', '0559.CBA.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (176, 'Tiến 3 (C=B+1)', NULL, 1, NULL, 0, 'X khác 9; C= B+1 = A+2; A khác X', '0559.XXX.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (177, 'Tiến 3 (C=B+1)', NULL, 1, NULL, 0, 'A khác 9; C= B+1 = A+2', '0559.ABC.ABC');
INSERT INTO "inventory"."isdn_rule" VALUES (178, 'Tiến 3 (C=B+1)', NULL, 1, 3, 0, 'A khác 9; C= B+1 = A+2', '0559.ABC.CBA');
INSERT INTO "inventory"."isdn_rule" VALUES (179, 'Tiến 4 (D=C+1)', NULL, 1, 2, 0, 'A khác 9; D= C+1 = B+2 = A+3; D khác E', '0559.ABCD.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (180, 'Tiến 4 (D=C+1)', NULL, 1, 0, 520, 'E khác 9; D= C+1 = B+2 = A+3; A khác E; D khác F', '0559.E.ABCD.F');
INSERT INTO "inventory"."isdn_rule" VALUES (181, 'Tiến 4 (D=C+1)', NULL, 1, 0, 0, 'E khác 9; D= C+1 = B+2 = A+3; A khác F', '0559.EF.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (182, 'Tiến 4 (D=C+1)', NULL, 1, 0, 0, 'A khác 9; D= C+1 = B+2 = A+3; D khác X', '0559.ABCD.XX');
INSERT INTO "inventory"."isdn_rule" VALUES (183, 'Tiến 4 (D=C+1)', NULL, 1, 0, 0, 'D= C+1 = B+2 = A+3', '0559.ABCD.DD');
INSERT INTO "inventory"."isdn_rule" VALUES (184, 'Tiến 4 (D=C+1)', NULL, 1, 0, 0, 'X khác 9; D= C+1 = B+2 = A+3; A khác X', '0559.XX.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (185, 'Tiến 4 (D=C+1)', NULL, 1, 0, 0, 'A khác 9; D= C+1 = B+2 = A+3', '0559.AA.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (186, 'Tiến 5 (E=D+1)', NULL, 1, 0, 0, 'A khác 9; E = D+1 = C+2 = B+3 = A+4; E khác F', '0559.ABCDE.F');
INSERT INTO "inventory"."isdn_rule" VALUES (187, 'Tiến 5 (E=D+1)', NULL, 1, 0, 0, 'F khác 9; E = D+1 = C+2 = B+3 = A+4; A khác F', '0559.F.ABCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (188, 'Tiến 6 (F=E+1)', NULL, 1, 0, 0, 'A khác 9; F = E+1 = D+2 = C+3 = B+4 = A+5', '0559.ABCDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (189, 'Tiến 6 (F=E+1)', NULL, 1, 0, 0, NULL, '0559.456.789');
INSERT INTO "inventory"."isdn_rule" VALUES (190, 'Lặp 2', NULL, 1, 1, 0, 'C khác 9', '0559.CD.AB.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (191, 'Tiến 2 (B=A+1)', NULL, 1, 13, 350, 'B=A+1; C khác 9; A khác F', '0559.CD.EF.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (192, 'Tiến 2 (B=A+1)', NULL, 1, 0, 390, 'B=A+1; C khác 9; A khác D; B khác E', '0559.CD.AB.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (193, 'Tiến 2 (B=A+1)', NULL, 1, 0, 390, 'B=A+1', '0559.CDE.AB.F');
INSERT INTO "inventory"."isdn_rule" VALUES (194, 'Lùi 2 (B=A-1)', NULL, 1, 0, 360, 'B=A-1', '0559.CDEF.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (195, 'Tiến 4 (D=C+2)', NULL, 1, 1, 0, 'D=C+2=B+4=A+6', '0559.AA.ABCD');
INSERT INTO "inventory"."isdn_rule" VALUES (196, 'Tiến 2 (B=A+1)', NULL, 1, 0, 390, 'B=A+1', '0559.AB.CDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (197, 'Tiến 2 (B=A+1)', NULL, 1, 14, 350, 'B=A+1', '0559.C.AB.DEF');
INSERT INTO "inventory"."isdn_rule" VALUES (198, 'Lặp 5 (ngũ quý)', NULL, 1, 0, 0, 'A khác B; A khác 6,8,9', '0559.B.AAAAA');
INSERT INTO "inventory"."isdn_rule" VALUES (199, 'Lặp 2', NULL, 1, 2, 900, NULL, '055.9AB.C.9AB');
INSERT INTO "inventory"."isdn_rule" VALUES (200, 'Lặp 6 (lục quý)', NULL, 1, 0, 0, 'A khác 6,8,9', '0559.AAAAAA');
INSERT INTO "inventory"."isdn_rule" VALUES (202, 'Lặp 5 (ngũ quý)', NULL, 1, 1, 0, 'A khác B; A khác 6,8,9', '0559.AAAAA.B');
INSERT INTO "inventory"."isdn_rule" VALUES (203, 'Lặp 4 (tứ quý)', NULL, 1, 0, 0, 'A khác C; A khác 6,8,9', '0559.BC.AAAA');
INSERT INTO "inventory"."isdn_rule" VALUES (204, 'Lặp 2', NULL, 1, 3, 600, 'A,B khác 6,8,9', '0559.CD.AB.AB');
INSERT INTO "inventory"."isdn_rule" VALUES (205, 'Lặp 3 (tam hoa)', NULL, 1, 1, 900, 'A khác D; A khác 6,8,9', '0559.BCD.AAA');
INSERT INTO "inventory"."isdn_rule" VALUES (206, 'Lặp 4 (tứ quý)', NULL, 1, 0, 0, 'A khác 6,8,9', '0559.AAAA.BB');
INSERT INTO "inventory"."isdn_rule" VALUES (208, 'Lặp tam hoa', NULL, 1, 0, 0, 'A,B là 6,8,9', '055.999.AAA.B');
INSERT INTO "inventory"."isdn_rule" VALUES (147, 'Đảo 2', NULL, 1, 36, 400, 'A,B khác 9; B khác C,D', '055.9AA9.BCD');
INSERT INTO "inventory"."isdn_rule" VALUES (0, 'No rule', NULL, 1, 0, 50000, '', '0559.ABC.XYZ');
INSERT INTO "inventory"."isdn_rule" VALUES (1, 'Lặp 7 (thất cửu)', NULL, 1, 0, 1000000000, NULL, '0559.999.999');
INSERT INTO "inventory"."isdn_rule" VALUES (2, 'Lặp 6 (lục quý)', NULL, 1, 0, 600000000, 'A là 6,8,9', '0559.AAAAAA');
INSERT INTO "inventory"."isdn_rule" VALUES (3, 'Lặp 5 (ngũ quý)', NULL, 1, 0, 200000000, 'A khác B; A là 6,8,9', '0559.B.AAAAA');
INSERT INTO "inventory"."isdn_rule" VALUES (14, 'Đảo 2', NULL, 1, 0, 45000000, 'A,B là 6,8,9', '0559.BA.AB.BA');
INSERT INTO "inventory"."isdn_rule" VALUES (31, 'Lặp 4 (tứ quý)', NULL, 1, 0, 16500000, 'A là 6,8,9', '0559.AAAA.BB');
INSERT INTO "inventory"."isdn_rule" VALUES (54, 'Đảo 2', NULL, 1, 7, 0, 'A khác 9, A khác B; A và B khác 6,8', '0559.A.ABBA.A');
INSERT INTO "inventory"."isdn_rule" VALUES (86, 'Lùi 4 (D=C-1)', NULL, 1, 0, 650, 'A khác 9; D =C-1 = B-2 = A-3; D khác E', '0559.ABCD.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (118, 'Tiến 2 (B=A+2)', NULL, 1, 12, 400, 'A khác 9; B=A+2; B khác C', '0559.AB.CDEF');
INSERT INTO "inventory"."isdn_rule" VALUES (137, 'Tiến 2 (B=A+3)', NULL, 1, 20, 400, 'C khác 9; C khác D; B=A+3; B khác E', '0559.CD.AB.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (154, 'Năm - Tháng - Ngày', NULL, 1, 0, 400, 'DD từ 01 đến 31, MM từ 01 đến 12, YY từ 00-05 và 50-99', '0559.YY.MM.DD');
INSERT INTO "inventory"."isdn_rule" VALUES (201, 'Lặp 4 (tứ quý)', NULL, 1, 0, 0, 'A khác 6,8,9', '055.9999.AAA');
INSERT INTO "inventory"."isdn_rule" VALUES (207, 'Lặp 4 (tứ quý)', NULL, 1, 0, 0, 'A khác B; A khác 9', '0559.AA.BBBB');
INSERT INTO "inventory"."isdn_rule" VALUES (216, 'Lặp 2', NULL, 1, 3, 900, 'A khác 9; B khác C; C khác 6,8,9', '055.99.A.BB.CC');
INSERT INTO "inventory"."isdn_rule" VALUES (217, 'Lặp 2', NULL, 1, 2, 600, 'A khác 9; A khác B; C,D là 6,8,9', '055.99.AA.BCD');
INSERT INTO "inventory"."isdn_rule" VALUES (218, 'Ngày - Tháng', NULL, 1, NULL, 600, 'DD từ 01 đến 31, MM từ 01 đến 12', '0559.00.DD.MM');
INSERT INTO "inventory"."isdn_rule" VALUES (219, 'Tiến 5 (E=D+2)', NULL, 1, 7, 600, 'A khác 9; E=D+2=C+4=B+6=A+8; E khác F', '0559.ABCDE.F');
INSERT INTO "inventory"."isdn_rule" VALUES (220, 'Tiến 5 (E=D+2)', NULL, 1, 3, 0, 'F khác 9; E=D+2=C+4=B+6=A+8', '0559.F.ABCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (221, 'Lùi 5 (E=D-2)', NULL, 1, 2, 400, 'A khác 9; E=D-2=C-4=B-6=A-8; E khác F', '0559.ABCDE.F');
INSERT INTO "inventory"."isdn_rule" VALUES (222, 'Lùi 5 (E=D-2)', NULL, 1, 1, 350, 'F khác 9; E=D-2=C-4=B-6=A-8', '0559.F.ABCDE');
INSERT INTO "inventory"."isdn_rule" VALUES (223, 'Lùi 4 (D=C-2)', NULL, 1, 2, 350, 'A=7; B=5; C=3; D=1; D khác E', '0559.ABCD.EF');
INSERT INTO "inventory"."isdn_rule" VALUES (224, 'Lặp 2', NULL, 1, 0, 0, 'C khác 9; A khác D; A khác B; B là 6,8,9', '0559.CD.AA.BB');
INSERT INTO "inventory"."isdn_rule" VALUES (225, 'Lặp 2', NULL, 1, 0, 500, 'C khác 9; A khác D; A khác B; B khác 6,8,9', '0559.CD.AA.BB');
INSERT INTO "inventory"."isdn_rule" VALUES (226, 'Tiến 3( D=C+1)', NULL, 1, 0, 0, 'A khác 9; D=C+1=B+2', '0559.AB.AC.AD');
INSERT INTO "inventory"."isdn_rule" VALUES (227, 'Lùi 3 ( D=C-1)', NULL, 1, 0, 450, 'A khác 9; D=C-1=B-2', '0559.AB.AC.AD');
COMMIT;

-- ----------------------------
-- Primary Key structure for table isdn_rule
-- ----------------------------
ALTER TABLE "inventory"."isdn_rule" ADD CONSTRAINT "isdn_rule_copy1_pkey" PRIMARY KEY ("rule_id");

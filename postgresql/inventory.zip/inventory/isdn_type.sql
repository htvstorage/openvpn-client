/*
 Navicat Premium Data Transfer

 Source Server         : UAT_SALE
 Source Server Type    : PostgreSQL
 Source Server Version : 110005
 Source Host           : 192.168.0.79:5432
 Source Catalog        : sale_uat
 Source Schema         : inventory

 Target Server Type    : PostgreSQL
 Target Server Version : 110005
 File Encoding         : 65001

 Date: 11/12/2021 10:54:13
*/


-- ----------------------------
-- Table structure for isdn_type
-- ----------------------------
DROP TABLE IF EXISTS "inventory"."isdn_type";
CREATE TABLE "inventory"."isdn_type" (
  "type_id" int8 NOT NULL,
  "description" varchar(255) COLLATE "pg_catalog"."default",
  "type_name" varchar(255) COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "inventory"."isdn_type" OWNER TO "postgres";
COMMENT ON COLUMN "inventory"."isdn_type"."type_id" IS 'id bản ghi';
COMMENT ON COLUMN "inventory"."isdn_type"."description" IS 'mô tả';
COMMENT ON COLUMN "inventory"."isdn_type"."type_name" IS 'tên kiểu';

-- ----------------------------
-- Records of isdn_type
-- ----------------------------
BEGIN;
INSERT INTO "inventory"."isdn_type" VALUES (0, 'Số bình thường', 'NORMAL');
INSERT INTO "inventory"."isdn_type" VALUES (1, 'Số đặc biệt', 'PRIVATE');
COMMIT;

-- ----------------------------
-- Primary Key structure for table isdn_type
-- ----------------------------
ALTER TABLE "inventory"."isdn_type" ADD CONSTRAINT "isdn_type_pkey" PRIMARY KEY ("type_id");

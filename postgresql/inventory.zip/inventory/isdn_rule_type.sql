/*
 Navicat Premium Data Transfer

 Source Server         : UAT_SALE
 Source Server Type    : PostgreSQL
 Source Server Version : 110005
 Source Host           : 192.168.0.79:5432
 Source Catalog        : sale_uat
 Source Schema         : inventory

 Target Server Type    : PostgreSQL
 Target Server Version : 110005
 File Encoding         : 65001

 Date: 11/12/2021 10:53:59
*/


-- ----------------------------
-- Table structure for isdn_rule_type
-- ----------------------------
DROP TABLE IF EXISTS "inventory"."isdn_rule_type";
CREATE TABLE "inventory"."isdn_rule_type" (
  "id" int8 NOT NULL DEFAULT nextval('"inventory".isdn_rule_type_id_seq'::regclass),
  "rule_type" int8,
  "rule_id" int8,
  "description" text COLLATE "pg_catalog"."default",
  "note" varchar(50) COLLATE "pg_catalog"."default"
)
;
ALTER TABLE "inventory"."isdn_rule_type" OWNER TO "postgres";
COMMENT ON COLUMN "inventory"."isdn_rule_type"."rule_type" IS 'Loại rule ( 1 - Số thường, 2 - Số ngày sinh, 3 - Số đẹp)';

-- ----------------------------
-- Records of isdn_rule_type
-- ----------------------------
BEGIN;
INSERT INTO "inventory"."isdn_rule_type" VALUES (96, 2, 96, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (97, 2, 97, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (150, 2, 150, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (151, 2, 151, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (152, 2, 152, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (153, 2, 153, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (154, 2, 154, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (155, 2, 155, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (228, 1, 0, 'Số thường', NULL);
INSERT INTO "inventory"."isdn_rule_type" VALUES (69, 2, 69, 'Số NTNS', 'LONG');
INSERT INTO "inventory"."isdn_rule_type" VALUES (68, 2, 68, 'Số NTNS', 'LONG');
INSERT INTO "inventory"."isdn_rule_type" VALUES (218, 2, 218, 'Số NTNS', 'SHORT');
INSERT INTO "inventory"."isdn_rule_type" VALUES (3, 3, 3, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (4, 3, 4, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (5, 3, 5, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (7, 3, 7, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (8, 3, 8, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (9, 3, 9, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (11, 3, 11, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (12, 3, 12, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (13, 3, 13, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (14, 3, 14, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (16, 3, 16, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (17, 3, 17, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (18, 3, 18, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (20, 3, 20, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (21, 3, 21, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (22, 3, 22, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (24, 3, 24, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (25, 3, 25, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (26, 3, 26, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (28, 3, 28, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (29, 3, 29, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (30, 3, 30, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (32, 3, 32, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (33, 3, 33, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (34, 3, 34, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (35, 3, 35, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (37, 3, 37, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (38, 3, 38, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (39, 3, 39, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (41, 3, 41, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (42, 3, 42, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (43, 3, 43, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (45, 3, 45, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (46, 3, 46, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (47, 3, 47, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (49, 3, 49, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (50, 3, 50, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (51, 3, 51, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (53, 3, 53, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (54, 3, 54, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (55, 3, 55, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (56, 3, 56, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (58, 3, 58, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (59, 3, 59, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (60, 3, 60, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (62, 3, 62, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (63, 3, 63, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (64, 3, 64, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (66, 3, 66, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (67, 3, 67, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (70, 3, 70, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (72, 3, 72, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (73, 3, 73, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (74, 3, 74, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (76, 3, 76, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (77, 3, 77, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (78, 3, 78, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (79, 3, 79, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (81, 3, 81, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (82, 3, 82, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (83, 3, 83, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (85, 3, 85, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (86, 3, 86, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (87, 3, 87, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (89, 3, 89, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (90, 3, 90, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (91, 3, 91, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (93, 3, 93, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (94, 3, 94, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (95, 3, 95, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (99, 3, 99, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (100, 3, 100, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (101, 3, 101, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (102, 3, 102, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (104, 3, 104, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (105, 3, 105, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (106, 3, 106, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (108, 3, 108, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (109, 3, 109, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (110, 3, 110, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (112, 3, 112, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (1, 3, 1, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (2, 3, 2, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (6, 3, 6, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (10, 3, 10, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (15, 3, 15, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (19, 3, 19, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (23, 3, 23, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (27, 3, 27, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (31, 3, 31, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (114, 3, 114, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (115, 3, 115, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (116, 3, 116, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (118, 3, 118, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (119, 3, 119, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (120, 3, 120, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (122, 3, 122, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (123, 3, 123, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (124, 3, 124, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (126, 3, 126, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (127, 3, 127, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (128, 3, 128, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (129, 3, 129, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (131, 3, 131, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (132, 3, 132, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (133, 3, 133, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (135, 3, 135, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (136, 3, 136, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (137, 3, 137, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (139, 3, 139, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (140, 3, 140, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (141, 3, 141, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (143, 3, 143, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (144, 3, 144, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (145, 3, 145, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (147, 3, 147, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (148, 3, 148, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (149, 3, 149, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (156, 3, 156, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (158, 3, 158, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (159, 3, 159, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (160, 3, 160, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (162, 3, 162, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (163, 3, 163, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (164, 3, 164, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (166, 3, 166, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (167, 3, 167, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (168, 3, 168, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (170, 3, 170, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (171, 3, 171, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (172, 3, 172, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (174, 3, 174, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (175, 3, 175, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (176, 3, 176, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (177, 3, 177, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (179, 3, 179, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (180, 3, 180, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (181, 3, 181, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (183, 3, 183, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (184, 3, 184, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (185, 3, 185, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (187, 3, 187, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (188, 3, 188, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (189, 3, 189, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (191, 3, 191, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (192, 3, 192, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (193, 3, 193, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (195, 3, 195, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (196, 3, 196, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (197, 3, 197, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (198, 3, 198, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (200, 3, 200, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (201, 3, 201, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (202, 3, 202, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (204, 3, 204, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (205, 3, 205, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (206, 3, 206, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (208, 3, 208, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (209, 3, 209, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (210, 3, 210, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (212, 3, 212, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (213, 3, 213, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (214, 3, 214, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (216, 3, 216, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (217, 3, 217, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (219, 3, 219, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (220, 3, 220, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (222, 3, 222, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (223, 3, 223, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (224, 3, 224, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (226, 3, 226, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (227, 3, 227, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (36, 3, 36, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (40, 3, 40, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (44, 3, 44, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (48, 3, 48, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (52, 3, 52, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (57, 3, 57, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (61, 3, 61, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (65, 3, 65, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (71, 3, 71, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (75, 3, 75, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (80, 3, 80, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (84, 3, 84, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (88, 3, 88, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (92, 3, 92, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (98, 3, 98, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (103, 3, 103, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (107, 3, 107, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (111, 3, 111, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (113, 3, 113, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (117, 3, 117, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (121, 3, 121, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (125, 3, 125, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (130, 3, 130, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (134, 3, 134, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (138, 3, 138, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (142, 3, 142, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (146, 3, 146, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (157, 3, 157, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (161, 3, 161, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (165, 3, 165, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (169, 3, 169, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (173, 3, 173, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (178, 3, 178, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (182, 3, 182, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (186, 3, 186, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (190, 3, 190, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (194, 3, 194, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (199, 3, 199, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (203, 3, 203, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (207, 3, 207, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (211, 3, 211, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (215, 3, 215, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (221, 3, 221, 'Số đẹp', 'CYCLE_BEAUTY');
INSERT INTO "inventory"."isdn_rule_type" VALUES (225, 3, 225, 'Số đẹp', 'CYCLE_BEAUTY');
COMMIT;

-- ----------------------------
-- Primary Key structure for table isdn_rule_type
-- ----------------------------
ALTER TABLE "inventory"."isdn_rule_type" ADD CONSTRAINT "rule_type_mapping_pkey" PRIMARY KEY ("id");

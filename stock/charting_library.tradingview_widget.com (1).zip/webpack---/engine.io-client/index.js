
module.exports = require('./lib/index');



//////////////////
// WEBPACK FOOTER
// ./~/engine.io-client/index.js
// module id = 18
// module chunks = 0
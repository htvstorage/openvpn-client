(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [8751], {
        16178: e => {
            e.exports = {
                "close-button": "close-button-WaM0Er9G",
                "close-icon": "close-icon-WaM0Er9G",
                "button-l": "button-l-WaM0Er9G",
                "button-m": "button-m-WaM0Er9G",
                "button-s": "button-s-WaM0Er9G",
                "button-xs": "button-xs-WaM0Er9G",
                "button-xxs": "button-xxs-WaM0Er9G"
            }
        },
        69599: e => {
            e.exports = {
                container: "container-PxtBx6dp",
                "container-danger": "container-danger-PxtBx6dp",
                icon: "icon-PxtBx6dp",
                header: "header-PxtBx6dp",
                "container-warning": "container-warning-PxtBx6dp",
                "container-success": "container-success-PxtBx6dp",
                "container-default": "container-default-PxtBx6dp",
                "text-wrap": "text-wrap-PxtBx6dp",
                "close-button": "close-button-PxtBx6dp"
            }
        },
        3492: e => {
            e.exports = {
                dialog: "dialog-PYbyi588",
                dialogBody: "dialogBody-PYbyi588"
            }
        },
        69951: e => {
            e.exports = {
                positionInfo: "positionInfo-XXMkFz6r",
                title: "title-XXMkFz6r"
            }
        },
        74445: e => {
            e.exports = {
                positionPanel: "positionPanel-tD2yhBS5"
            }
        },
        45283: e => {
            e.exports = {
                positionWidget: "positionWidget-hx2QgjpT",
                separator: "separator-hx2QgjpT",
                brackets: "brackets-hx2QgjpT",
                customFieldsWrapper: "customFieldsWrapper-hx2QgjpT",
                warning: "warning-hx2QgjpT",
                button: "button-hx2QgjpT"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        24115: (e, t, o) => {
            "use strict";
            o.d(t, {
                CloseButton: () => m
            });
            var n = o(59496),
                s = o(97754),
                l = o(72571),
                r = o(58090),
                i = o(91046),
                a = o(56846),
                c = o(86498),
                u = o(22248),
                d = o(16178),
                h = o.n(d);

            function p(e = "l") {
                switch (e) {
                    case "l":
                        return r;
                    case "m":
                        return i;
                    case "s":
                        return a;
                    case "xs":
                        return c;
                    case "xxs":
                        return u;
                    default:
                        return i
                }
            }
            const m = n.forwardRef((e, t) => {
                const {
                    className: o,
                    size: r,
                    ...i
                } = e, a = s(h()["close-button"], h()["button-" + r], o);
                return n.createElement("button", { ...i,
                    type: "button",
                    className: a,
                    ref: t
                }, n.createElement(l.Icon, {
                    icon: p(r),
                    className: h()["close-icon"],
                    "aria-hidden": !0
                }))
            })
        },
        18460: (e, t, o) => {
            "use strict";
            o.d(t, {
                Informer: () => p
            });
            var n = o(59496),
                s = o(97754),
                l = o(72571),
                r = o(24115),
                i = o(37553),
                a = o(60525),
                c = o(3150),
                u = o(69599),
                d = o.n(u);
            const h = {
                danger: i,
                warning: i,
                success: c,
                default: a
            };

            function p(e) {
                const {
                    informerIntent: t,
                    content: o,
                    className: i,
                    header: a,
                    isIconShown: c = !0,
                    isCloseButtonShown: u,
                    icon: p,
                    onCloseClick: m,
                    closeButtonLabel: f = "Close"
                } = e;
                return n.createElement("div", {
                    className: s(d().container, d()["container-" + t], i)
                }, c && n.createElement(l.Icon, {
                    className: d().icon,
                    icon: null != p ? p : h[t]
                }), n.createElement("div", {
                    className: d()["text-wrap"]
                }, n.createElement("span", {
                    className: d().header
                }, a), " ", o), u && n.createElement(r.CloseButton, {
                    "aria-label": f,
                    onClick: m,
                    className: d()["close-button"],
                    size: "xs"
                }))
            }
        },
        10548: (e, t, o) => {
            "use strict";
            o.r(t),
                o.d(t, {
                    closePositionDialog: () => W,
                    mountPositionPanel: () => F,
                    showPositionDialog: () => D,
                    unmountPositionPanel: () => H
                });
            var n = o(59496),
                s = o(87995),
                l = o(30894),
                r = o(40766),
                i = o(30052),
                a = o(1227),
                c = o(80185),
                u = o(18460),
                d = o(51951),
                h = o(74752),
                p = o(88865),
                m = o(99374),
                f = o(63111),
                b = o(64245),
                v = o(69951);

            function g(e) {
                return n.createElement("div", {
                    className: v.positionInfo
                }, n.createElement("div", {
                    className: v.title
                }, e.title), n.createElement(b.InfoTable, {
                    rows: e.infoTableData.rows,
                    header: e.infoTableData.header,
                    disabled: !1,
                    rightAlignedValues: !0
                }))
            }
            class C extends n.PureComponent {
                constructor(e) {
                    super(e), this._updateInfoTableData = e => {
                        this.setState({
                            infoTableData: e
                        })
                    }, this.state = {
                        title: e.model.title(),
                        infoTableData: e.model.infoTableData().value()
                    }
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model)
                }
                componentWillUnmount() {
                    this._unsubscribeFromModel(this.props.model)
                }
                render() {
                    return n.createElement(g, {
                        title: this.state.title,
                        infoTableData: this.state.infoTableData
                    })
                }
                _subscribeToModel(e) {
                    e.infoTableData().subscribe(this._updateInfoTableData)
                }
                _unsubscribeFromModel(e) {
                    e.infoTableData().unsubscribe(this._updateInfoTableData)
                }
            }
            var M = o(40176),
                w = o(95318),
                _ = o(45283);
            const x = (0, d.getLogger)("Trading.OrderPanel");
            class E extends n.PureComponent {
                constructor(e) {
                    super(e), this._block = null, this._setRef = e => {
                        this._block = e
                    }, this._onEnter = e => {
                        const t = (0, c.hashFromEvent)(e);
                        if (!(13 !== t && t !== c.hashShiftPlusEnter || this.props.model.disabled.value())) return a.CheckMobile.any() ? this._blur() : void this.props.model.doneButtonClick()
                    }, this._blur = () => {
                        document.activeElement instanceof HTMLElement ? document.activeElement.blur() : x.logWarn("Failed to deselect: active element is not HTMLElement")
                    }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model), this.props.settings.subscribe(this._callback), null !== this._block && void 0 === this.props.focus && this._block.focus()
                }
                componentWillUnmount() {
                    this._unsubscribeFromModel(this.props.model), this.props.settings.unsubscribe(this._callback)
                }
                render() {
                    const {
                        model: e,
                        settings: t,
                        focus: o
                    } = this.props, s = {
                        value: t.value(),
                        setValue: t.setValue.bind(t)
                    }, l = e.warning.value();
                    return n.createElement(w.SettingsContext.Provider, {
                        value: s
                    }, n.createElement("div", {
                        className: _.positionWidget,
                        onKeyDown: this._onEnter,
                        tabIndex: -1,
                        ref: this._setRef
                    }, n.createElement(h.HeaderContainer, {
                        model: e.headerModel,
                        supportBrackets: !0,
                        currency: e.currency,
                        mode: e.mode.value(),
                        showRiskControls: e.showRiskControls
                    }), n.createElement("div", {
                        className: _.brackets
                    }, n.createElement(p.BracketControlGroup, {
                        model: e,
                        focus: o
                    })), Array.isArray(e.customFieldModels.value()) && e.customFieldModels.value().length > 0 && n.createElement("div", {
                        className: _.customFieldsWrapper
                    }, n.createElement("div", {
                        className: _.separator
                    }), n.createElement(M.CustomFields, {
                        customFieldModels: e.customFieldModels.value(),
                        status: e.status,
                        alwaysShowAttachedErrors: e.isEmptyRequiredCustomFieldsHighlighted
                    })), l && n.createElement(u.Informer, {
                        className: _.warning,
                        content: l,
                        informerIntent: "default"
                    }), void 0 !== e.buttonModel && n.createElement("div", {
                        className: _.button
                    }, n.createElement(m.PlaceAndModifyButtonContainer, {
                        model: e,
                        buttonModel: e.buttonModel
                    })), e.mode.value() === f.OrderEditorDisplayMode.Panel && null !== e.positionInfoModel && e.positionInfoModel.infoTableData().value().rows.length > 0 && n.createElement(n.Fragment, null, n.createElement("div", {
                        className: _.separator
                    }), n.createElement(C, {
                        "data-name": "position-info",
                        model: e.positionInfoModel
                    }))))
                }
                _subscribeToModel(e) {
                    this.props.model.disabled.subscribe(this._callback), this.props.model.loading.subscribe(this._callback), this.props.model.mode.subscribe(this._callback), this.props.model.warning.subscribe(this._callback)
                }
                _unsubscribeFromModel(e) {
                    this.props.model.disabled.unsubscribe(this._callback), this.props.model.loading.unsubscribe(this._callback), this.props.model.mode.unsubscribe(this._callback), this.props.model.warning.unsubscribe(this._callback)
                }
            }
            var k = o(96038),
                y = o(74837),
                T = o(3492);
            const O = n.memo(e => {
                const {
                    model: t,
                    isOpened: o,
                    settings: s,
                    focus: a,
                    onOpen: c,
                    onClose: u
                } = e;
                return (0, y.useCommonDialogHandlers)({
                    isOpened: o,
                    onOpen: c,
                    onClose: u
                }), n.createElement(i.MatchMedia, {
                    rule: k.DialogBreakpoints.TabletSmall
                }, e => n.createElement(r.PopupDialog, {
                    className: T.dialog,
                    isOpened: o,
                    onKeyDown: d,
                    width: 414,
                    fullscreen: e
                }, n.createElement(l.Body, {
                    className: T.dialogBody
                }, t && s && n.createElement(E, {
                    settings: s,
                    model: t,
                    key: t.id,
                    focus: a
                }))));

                function d(e) {
                    27 === e.keyCode && u && u()
                }
            });
            var S = o(74445);
            class P extends n.PureComponent {
                constructor(e) {
                    super(e), this._onKeyDown = e => {
                        27 === e.keyCode && this.props.onCancel && this.props.onCancel()
                    }
                }
                render() {
                    return n.createElement("div", {
                        "data-name": "position-panel",
                        className: S.positionPanel,
                        onKeyDown: this._onKeyDown
                    }, n.createElement(E, {
                        settings: this.props.settings,
                        model: this.props.model,
                        focus: this.props.focus,
                        key: this.props.model.id
                    }))
                }
            }
            let N = null,
                B = !1;

            function D(e) {
                const {
                    viewModel: t,
                    settings: o,
                    focus: n,
                    onClose: l,
                    onOpen: r
                } = e;
                W(l);
                const i = {
                    model: t,
                    settings: o,
                    isOpened: !0,
                    focus: n,
                    onOpen: r,
                    onClose: () => {
                        W(l), t.onDoneButtonClicked.reject(), void 0 !== i.onClose && (t.headerModel.pinButtonClicked().unsubscribe(null, i.onClose), t.headerModel.closeButtonClicked().unsubscribe(null, i.onClose)), N && (s.unmountComponentAtNode(N), B = !1)
                    }
                };
                R(i), B = !0, void 0 !== i.onClose && (t.headerModel.pinButtonClicked().subscribe(null, i.onClose), t.headerModel.closeButtonClicked().subscribe(null, i.onClose))
            }

            function W(e) {
                B && (R({
                    model: null,
                    isOpened: !1
                }), null == e || e())
            }

            function R(e) {
                N || (N = document.createElement("div"), document.body.appendChild(N));
                const t = n.createElement(f.Context.Provider, {
                    value: {
                        mode: e.model && e.model.mode.value() || f.OrderEditorDisplayMode.Panel,
                        supportTrailingStop: Boolean(e.model && e.model.supportTrailingStop)
                    }
                }, n.createElement(O, { ...e
                }));
                s.render(t, N)
            }

            function F(e, t, o, l) {
                H(o);
                const r = {
                    model: e,
                    settings: t,
                    focus: l,
                    onClose: () => {
                        H(o), r.model.headerModel.pinButtonClicked().unsubscribe(null, r.onClose), r.model.headerModel.closeButtonClicked().unsubscribe(null, r.onClose)
                    },
                    onCancel: () => {
                        r.model.headerModel && r.model.headerModel.back()
                    }
                };
                r.model.headerModel.pinButtonClicked().subscribe(null, r.onClose), r.model.headerModel.closeButtonClicked().subscribe(null, r.onClose),
                    function(e, t) {
                        const o = n.createElement(f.Context.Provider, {
                            value: {
                                mode: e.model.mode.value(),
                                supportTrailingStop: Boolean(e.model.supportTrailingStop)
                            }
                        }, n.createElement(P, { ...e
                        }));
                        s.render(o, t)
                    }(r, o)
            }

            function H(e) {
                s.unmountComponentAtNode(e)
            }
        },
        30553: (e, t, o) => {
            "use strict";
            o.d(t, {
                MenuContext: () => n
            });
            const n = o(59496).createContext(null)
        },
        10618: (e, t, o) => {
            "use strict";
            o.d(t, {
                DEFAULT_MENU_THEME: () => b,
                Menu: () => v
            });
            var n = o(59496),
                s = o(97754),
                l = o.n(s),
                r = o(88537),
                i = o(97280),
                a = o(12777),
                c = o(53327),
                u = o(70981),
                d = o(63212),
                h = o(82027),
                p = o(94488),
                m = o(30553),
                f = o(16059);
            const b = f;
            class v extends n.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new d.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                            this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                        }, this._handleScrollWrapRef = e => {
                            this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                        }, this._handleMeasure = ({
                            callback: e,
                            forceRecalcPosition: t
                        } = {}) => {
                            var o, n, s, l;
                            if (this.state.isMeasureValid && !t) return;
                            const {
                                position: a
                            } = this.props, c = (0, r.ensureNotNull)(this._containerRef);
                            let u = c.getBoundingClientRect();
                            const d = document.documentElement.clientHeight,
                                h = document.documentElement.clientWidth,
                                p = null !== (o = this.props.closeOnScrollOutsideOffset) && void 0 !== o ? o : 0;
                            let m = d - 0 - p;
                            const f = u.height > m;
                            if (f) {
                                (0, r.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", u = c.getBoundingClientRect()
                            }
                            const {
                                width: b,
                                height: v
                            } = u, g = "function" == typeof a ? a(b, v, d) : a, C = h - (null !== (n = g.overrideWidth) && void 0 !== n ? n : b) - 0, M = (0, i.clamp)(g.x, 0, Math.max(0, C)), w = 0 + p, _ = d - (null !== (s = g.overrideHeight) && void 0 !== s ? s : v) - 0;
                            let x = (0, i.clamp)(g.y, w, Math.max(w, _));
                            if (g.forbidCorrectYCoord && x < g.y && (m -= g.y - x, x = g.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && g.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                            const E = null !== (l = g.overrideHeight) && void 0 !== l ? l : f ? m : void 0;
                            this.setState({
                                appearingMenuHeight: t ? this.state.appearingMenuHeight : E,
                                appearingMenuWidth: t ? this.state.appearingMenuWidth : g.overrideWidth,
                                appearingPosition: {
                                    x: M,
                                    y: x
                                },
                                isMeasureValid: !0
                            }, () => {
                                this._restoreScrollPosition(), e && e()
                            })
                        }, this._restoreScrollPosition = () => {
                            const e = document.activeElement,
                                t = (0, r.ensureNotNull)(this._containerRef);
                            if (null !== e && t.contains(e)) try {
                                e.scrollIntoView()
                            } catch (e) {} else(0, r.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                        }, this._resizeForced = () => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            })
                        }, this._resize = () => {
                            null === this._raf && (this._raf = requestAnimationFrame(() => {
                                this.setState({
                                    appearingMenuHeight: void 0,
                                    appearingMenuWidth: void 0,
                                    appearingPosition: void 0,
                                    isMeasureValid: void 0
                                }), this._raf = null
                            }))
                        },
                        this._handleGlobalClose = e => {
                            this.props.onClose(e)
                        }, this._handleSlot = e => {
                            this._manager.setContainer(e)
                        }, this._handleScroll = () => {
                            this._scroll = (0, r.ensureNotNull)(this._scrollWrapRef).scrollTop
                        }, this._handleScrollOutsideEnd = () => {
                            clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                                this._handleMeasure({
                                    forceRecalcPosition: !0
                                })
                            }, 80)
                        }, this._handleScrollOutside = e => {
                            e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                                this._handleMeasure({
                                    forceRecalcPosition: !0
                                }), this._scrollRaf = null
                            })))
                        }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = h.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": o,
                        "aria-activedescendant": s,
                        children: r,
                        minWidth: i,
                        theme: u = f,
                        className: d,
                        maxHeight: h,
                        onMouseOver: b,
                        onMouseOut: v,
                        onKeyDown: C,
                        onFocus: M,
                        onBlur: w
                    } = this.props, {
                        appearingMenuHeight: _,
                        appearingMenuWidth: x,
                        appearingPosition: E,
                        isMeasureValid: k
                    } = this.state;
                    return n.createElement(m.MenuContext.Provider, {
                        value: this
                    }, n.createElement(p.SubmenuHandler, null, n.createElement(c.SlotContext.Provider, {
                        value: this._manager
                    }, n.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": o,
                        "aria-activedescendant": s,
                        className: l()(d, u.menuWrap, !k && u.isMeasuring),
                        style: {
                            height: _,
                            left: E && E.x,
                            minWidth: i,
                            position: "fixed",
                            top: E && E.y,
                            width: x
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: a.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: b,
                        onMouseOut: v,
                        onKeyDown: C,
                        onFocus: M,
                        onBlur: w
                    }, n.createElement("div", {
                        className: l()(u.scrollWrap, !this.props.noMomentumBasedScroll && u.momentumBased),
                        style: {
                            overflowY: void 0 !== _ ? "scroll" : "auto",
                            maxHeight: h
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, n.createElement(g, {
                        className: u.menuBox
                    }, r)))), n.createElement(c.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function g(e) {
                const t = (0, r.ensureNotNull)((0, n.useContext)(p.SubmenuContext)),
                    o = n.useRef(null);
                return n.createElement("div", {
                    ref: o,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (n = e.target, null === (s = o.current) || void 0 === s ? void 0 : s.contains(n)))) return;
                        var n, s;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            v.contextType = p.SubmenuContext
        },
        92063: (e, t, o) => {
            "use strict";
            o.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => c,
                PopupMenuItem: () => h
            });
            var n = o(59496),
                s = o(97754),
                l = o(70981),
                r = o(32133),
                i = o(417),
                a = o(23576);
            const c = a;

            function u(e) {
                const {
                    reference: t,
                    ...o
                } = e, s = { ...o,
                    ref: t
                };
                return n.createElement(e.href ? "a" : "div", s)
            }

            function d(e) {
                e.stopPropagation()
            }

            function h(e) {
                const {
                    id: t,
                    role: o,
                    "aria-selected": c,
                    className: h,
                    title: p,
                    labelRowClassName: m,
                    labelClassName: f,
                    shortcut: b,
                    forceShowShortcuts: v,
                    icon: g,
                    isActive: C,
                    isDisabled: M,
                    isHovered: w,
                    appearAsDisabled: _,
                    label: x,
                    link: E,
                    showToolboxOnHover: k,
                    target: y,
                    rel: T,
                    toolbox: O,
                    reference: S,
                    onMouseOut: P,
                    onMouseOver: N,
                    suppressToolboxClick: B = !0,
                    theme: D = a
                } = e, W = (0, i.filterDataProps)(e), R = (0, n.useRef)(null);
                return n.createElement(u, { ...W,
                    id: t,
                    role: o,
                    "aria-selected": c,
                    className: s(h, D.item, g && D.withIcon, {
                        [D.isActive]: C,
                        [D.isDisabled]: M || _,
                        [D.hovered]: w
                    }),
                    title: p,
                    href: E,
                    target: y,
                    rel: T,
                    reference: function(e) {
                        R.current = e, "function" == typeof S && S(e);
                        "object" == typeof S && (S.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: o,
                            onClick: n,
                            onClickArg: s,
                            trackEventObject: i
                        } = e;
                        if (M) return;
                        i && (0, r.trackEvent)(i.category, i.event, i.label);
                        n && n(s, t);
                        o || (0, l.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: o,
                            trackRightClick: n
                        } = e;
                        o && n && (0, r.trackEvent)(o.category, o.event, o.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: o,
                            trackMouseWheelClick: n
                        } = e;
                        if (1 === t.button && E && o) {
                            let e = o.label;
                            n && (e += "_mouseWheelClick"), (0, r.trackEvent)(o.category, o.event, e)
                        }
                    },
                    onMouseOver: N,
                    onMouseOut: P
                }, void 0 !== g && n.createElement("div", {
                    className: D.icon,
                    dangerouslySetInnerHTML: {
                        __html: g
                    }
                }), n.createElement("div", {
                    className: s(D.labelRow, m)
                }, n.createElement("div", {
                    className: s(D.label, f)
                }, x)), (void 0 !== b || v) && n.createElement("div", {
                    className: D.shortcut
                }, (F = b) && F.split("+").join(" + ")), void 0 !== O && n.createElement("div", {
                    onClick: B ? d : void 0,
                    className: s(D.toolbox, {
                        [D.showOnHover]: k
                    })
                }, O));
                var F
            }
        },
        28466: (e, t, o) => {
            "use strict";
            o.d(t, {
                CloseDelegateContext: () => l
            });
            var n = o(59496),
                s = o(70981);
            const l = n.createContext(s.globalCloseDelegate)
        },
        44377: (e, t, o) => {
            "use strict";
            o.d(t, {
                PopupMenu: () => c
            });
            var n = o(59496),
                s = o(87995),
                l = o(8361),
                r = o(10618),
                i = o(28466),
                a = o(61174);

            function c(e) {
                const {
                    controller: t,
                    children: o,
                    isOpened: c,
                    closeOnClickOutside: u = !0,
                    doNotCloseOn: d,
                    onClickOutside: h,
                    onClose: p,
                    ...m
                } = e, f = (0, n.useContext)(i.CloseDelegateContext), b = (0, a.useOutsideEvent)({
                    handler: function(e) {
                        h && h(e);
                        if (!u) return;
                        if (d && e.target instanceof Node) {
                            const t = s.findDOMNode(d);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        p()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return c ? n.createElement(l.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, n.createElement("span", {
                    ref: b,
                    style: {
                        pointerEvents: "auto"
                    }
                }, n.createElement(r.Menu, { ...m,
                    onClose: p,
                    onScroll: function(t) {
                        const {
                            onScroll: o
                        } = e;
                        o && o(t)
                    },
                    customCloseDelegate: f,
                    ref: t
                }, o))) : null
            }
        },
        94488: (e, t, o) => {
            "use strict";
            o.d(t, {
                SubmenuContext: () => s,
                SubmenuHandler: () => l
            });
            var n = o(59496);
            const s = n.createContext(null);

            function l(e) {
                const [t, o] = (0, n.useState)(null), l = (0, n.useRef)(null), r = (0, n.useRef)(new Map);
                return (0, n.useEffect)(() => () => {
                    null !== l.current && clearTimeout(l.current)
                }, []), n.createElement(s.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== l.current && (clearTimeout(l.current), l.current = null);
                            null === t ? o(e) : l.current = setTimeout(() => {
                                l.current = null, o(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return r.current.set(e, t), () => {
                                r.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(r.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        3150: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><path fill="currentColor" fill-rule="evenodd" d="M9 0a9 9 0 1 0 0 18A9 9 0 0 0 9 0zm4.15 5.87a.75.75 0 0 0-1.3-.74l-3.51 6.15-2.31-2.31a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.18-.16l4-7z"/></svg>'
        },
        37553: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><path fill="currentColor" d="M9 0a9 9 0 1 0 0 18A9 9 0 0 0 9 0zM7.75 5.48a1.27 1.27 0 1 1 2.5 0l-.67 4.03a.59.59 0 0 1-1.16 0l-.67-4.03zM8 13a1 1 0 1 1 2 0 1 1 0 0 1-2 0z"/></svg>'
        },
        60525: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><path fill="currentColor" d="M9 0a9 9 0 1 0 0 18A9 9 0 0 0 9 0zm1 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM9 8a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V9a1 1 0 0 1 1-1z"/></svg>'
        },
        58090: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><path stroke="currentColor" stroke-width="1.2" d="M1 1l21 21m0-21L1 22"/></svg>'
        },
        91046: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        56846: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path stroke="currentColor" stroke-width="1.2" d="M1 1l11 11m0-11L1 12"/></svg>'
        },
        86498: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 11" width="11" height="11"><path stroke="currentColor" stroke-width="1.2" d="M1 1l9 9m0-9l-9 9"/></svg>'
        },
        22248: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 9" width="9" height="9"><path stroke="currentColor" stroke-width="1.2" d="M1 1l7 7m0-7L1 8"/></svg>'
        }
    }
]);
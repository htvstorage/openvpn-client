(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [932], {
        90896: e => {
            e.exports = {
                wrapper: "wrapper-oPZWoMdB",
                focused: "focused-oPZWoMdB",
                readonly: "readonly-oPZWoMdB",
                disabled: "disabled-oPZWoMdB",
                "size-small": "size-small-oPZWoMdB",
                "size-medium": "size-medium-oPZWoMdB",
                "size-large": "size-large-oPZWoMdB",
                "font-size-small": "font-size-small-oPZWoMdB",
                "font-size-medium": "font-size-medium-oPZWoMdB",
                "font-size-large": "font-size-large-oPZWoMdB",
                "border-none": "border-none-oPZWoMdB",
                shadow: "shadow-oPZWoMdB",
                "border-thin": "border-thin-oPZWoMdB",
                "border-thick": "border-thick-oPZWoMdB",
                "intent-default": "intent-default-oPZWoMdB",
                "intent-success": "intent-success-oPZWoMdB",
                "intent-warning": "intent-warning-oPZWoMdB",
                "intent-danger": "intent-danger-oPZWoMdB",
                "intent-primary": "intent-primary-oPZWoMdB",
                "corner-top-left": "corner-top-left-oPZWoMdB",
                "corner-top-right": "corner-top-right-oPZWoMdB",
                "corner-bottom-right": "corner-bottom-right-oPZWoMdB",
                "corner-bottom-left": "corner-bottom-left-oPZWoMdB",
                childrenContainer: "childrenContainer-oPZWoMdB"
            }
        },
        58858: e => {
            e.exports = {
                defaultSelect: "defaultSelect-6eXd0Ihx"
            }
        },
        78781: e => {
            e.exports = {
                itemWrap: "itemWrap-YXml6gvK",
                item: "item-YXml6gvK",
                icon: "icon-YXml6gvK",
                selected: "selected-YXml6gvK",
                label: "label-YXml6gvK"
            }
        },
        5717: e => {
            e.exports = {
                lineEndSelect: "lineEndSelect-RMwVB5BV",
                right: "right-RMwVB5BV"
            }
        },
        73084: e => {
            e.exports = {
                lineStyleSelect: "lineStyleSelect-2BDVWQbf",
                multipleStyles: "multipleStyles-2BDVWQbf"
            }
        },
        218: e => {
            e.exports = {
                lineWidthSelect: "lineWidthSelect-TYbMx0kd",
                bar: "bar-TYbMx0kd",
                isActive: "isActive-TYbMx0kd",
                item: "item-TYbMx0kd"
            }
        },
        56994: e => {
            e.exports = {
                container: "container-Wq7zjnRZ",
                active: "active-Wq7zjnRZ",
                disabled: "disabled-Wq7zjnRZ",
                icon: "icon-Wq7zjnRZ"
            }
        },
        21818: e => {
            e.exports = {
                wrap: "wrap-CLB8ZlH6",
                disabled: "disabled-CLB8ZlH6"
            }
        },
        52465: e => {
            e.exports = {
                dropdown: "dropdown-KoV1659s",
                dropdownMenu: "dropdownMenu-KoV1659s",
                firstColorPicker: "firstColorPicker-KoV1659s"
            }
        },
        31650: e => {
            e.exports = {
                row: "row-kB7roDMw",
                wrap: "wrap-kB7roDMw",
                breakpointNormal: "breakpointNormal-kB7roDMw",
                breakpointMedium: "breakpointMedium-kB7roDMw",
                breakpointSmall: "breakpointSmall-kB7roDMw"
            }
        },
        51285: e => {
            e.exports = {
                coordinates: "coordinates-V0LzFOLU",
                input: "input-V0LzFOLU"
            }
        },
        9688: e => {
            e.exports = {
                wrapper: "wrapper-IjSbS0mB",
                checkbox: "checkbox-IjSbS0mB",
                colorSelect: "colorSelect-IjSbS0mB"
            }
        },
        29148: e => {
            e.exports = {
                withoutPadding: "withoutPadding-VwIbEpbX"
            }
        },
        67474: e => {
            e.exports = {
                input: "input-SCyh9tQM",
                control: "control-SCyh9tQM",
                item: "item-SCyh9tQM",
                cell: "cell-SCyh9tQM",
                fragmentCell: "fragmentCell-SCyh9tQM",
                withTitle: "withTitle-SCyh9tQM",
                title: "title-SCyh9tQM"
            }
        },
        55368: e => {
            e.exports = {
                line: "line-er8glV8W",
                control: "control-er8glV8W",
                valueInput: "valueInput-er8glV8W",
                valueUnit: "valueUnit-er8glV8W",
                input: "input-er8glV8W"
            }
        },
        80346: e => {
            e.exports = {
                unit: "unit-yU23iRoD",
                input: "input-yU23iRoD",
                normal: "normal-yU23iRoD",
                big: "big-yU23iRoD",
                dropdown: "dropdown-yU23iRoD",
                dropdownMenu: "dropdownMenu-yU23iRoD"
            }
        },
        89477: e => {
            e.exports = {
                dropdown: "dropdown-TevhCNe0",
                normal: "normal-TevhCNe0",
                big: "big-TevhCNe0",
                dropdownMenu: "dropdownMenu-TevhCNe0"
            }
        },
        94245: e => {
            e.exports = {
                range: "range-DTExo36Q",
                valueInput: "valueInput-DTExo36Q",
                rangeSlider: "rangeSlider-DTExo36Q",
                rangeSlider_mixed: "rangeSlider_mixed-DTExo36Q",
                input: "input-DTExo36Q"
            }
        },
        45449: e => {
            e.exports = {
                colorPicker: "colorPicker-zLqwzQsC",
                fontStyleButton: "fontStyleButton-zLqwzQsC",
                dropdown: "dropdown-zLqwzQsC",
                dropdownMenu: "dropdownMenu-zLqwzQsC"
            }
        },
        35048: e => {
            e.exports = {
                twoColors: "twoColors-0m0hhV3v",
                colorPicker: "colorPicker-0m0hhV3v"
            }
        },
        33126: e => {
            e.exports = {
                dropdown: "dropdown-8h1M1df3",
                menu: "menu-8h1M1df3"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        99339: e => {
            e.exports = {
                wrapper: "wrapper-3LlhL6R6",
                emoji: "emoji-3LlhL6R6"
            }
        },
        83341: e => {
            e.exports = {
                list: "list-mYbRQuGD"
            }
        },
        70358: e => {
            e.exports = {
                wrapper: "wrapper-KYBibz0a"
            }
        },
        39897: e => {
            e.exports = {
                wrapper: "wrapper-EVXZqxr4",
                emojiItem: "emojiItem-EVXZqxr4"
            }
        },
        40681: e => {
            e.exports = {
                wrapper: "wrapper-wFgLbqCx",
                isActive: "isActive-wFgLbqCx"
            }
        },
        88436: e => {
            e.exports = {
                wrapper: "wrapper-z9lPbT43"
            }
        },
        16859: e => {
            e.exports = {
                wrapper: "wrapper-s7880WH7"
            }
        },
        95076: e => {
            e.exports = {
                desktopSize: "desktopSize-iVjStStf",
                drawer: "drawer-iVjStStf",
                menuBox: "menuBox-iVjStStf"
            }
        },
        524: e => {
            e.exports = {
                separator: "separator-GzmeVcFo",
                small: "small-GzmeVcFo",
                normal: "normal-GzmeVcFo",
                large: "large-GzmeVcFo"
            }
        },
        65830: e => {
            e.exports = {
                range: "range-w7rMmNtQ",
                disabled: "disabled-w7rMmNtQ",
                rangeSlider: "rangeSlider-w7rMmNtQ",
                rangeSliderMiddleWrap: "rangeSliderMiddleWrap-w7rMmNtQ",
                rangeSliderMiddle: "rangeSliderMiddle-w7rMmNtQ",
                dragged: "dragged-w7rMmNtQ",
                pointer: "pointer-w7rMmNtQ",
                rangePointerWrap: "rangePointerWrap-w7rMmNtQ"
            }
        },
        73432: e => {
            e.exports = {
                button: "button-SD4Dbbwd",
                disabled: "disabled-SD4Dbbwd",
                active: "active-SD4Dbbwd",
                hidden: "hidden-SD4Dbbwd"
            }
        },
        85673: (e, t, n) => {
            "use strict";
            n.d(t, {
                VerticalAttachEdge: () => o,
                HorizontalAttachEdge: () => r,
                VerticalDropDirection: () => i,
                HorizontalDropDirection: () => a,
                getPopupPositioner: () => c
            });
            var o, r, i, a, l = n(88537);
            ! function(e) {
                e[e.Top = 0] = "Top", e[e.Bottom = 1] = "Bottom"
            }(o || (o = {})),
            function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(r || (r = {})),
            function(e) {
                e[e.FromTopToBottom = 0] = "FromTopToBottom", e[e.FromBottomToTop = 1] = "FromBottomToTop"
            }(i || (i = {})),
            function(e) {
                e[e.FromLeftToRight = 0] = "FromLeftToRight", e[e.FromRightToLeft = 1] = "FromRightToLeft"
            }(a || (a = {}));
            const s = {
                verticalAttachEdge: o.Bottom,
                horizontalAttachEdge: r.Left,
                verticalDropDirection: i.FromTopToBottom,
                horizontalDropDirection: a.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function c(e, t) {
                return (n, c) => {
                    const d = (0, l.ensureNotNull)(e).getBoundingClientRect(),
                        {
                            verticalAttachEdge: u = s.verticalAttachEdge,
                            verticalDropDirection: p = s.verticalDropDirection,
                            horizontalAttachEdge: m = s.horizontalAttachEdge,
                            horizontalDropDirection: h = s.horizontalDropDirection,
                            horizontalMargin: f = s.horizontalMargin,
                            verticalMargin: v = s.verticalMargin,
                            matchButtonAndListboxWidths: g = s.matchButtonAndListboxWidths
                        } = t,
                        b = u === o.Top ? -1 * v : v,
                        y = m === r.Right ? d.right : d.left,
                        w = u === o.Top ? d.top : d.bottom,
                        E = {
                            x: y - (h === a.FromRightToLeft ? n : 0) + f,
                            y: w - (p === i.FromBottomToTop ? c : 0) + b
                        };
                    return g && (E.overrideWidth = d.width), E
                }
            }
        },
        9297: (e, t, n) => {
            "use strict";

            function o(e, t, n) {
                const o = new Map,
                    r = void 0 !== t ? t[0] : e => e,
                    i = void 0 !== t ? void 0 !== t[1] ? t[1] : t[0] : e => e,
                    a = {
                        value: () => r(e.value()),
                        setValue: t => {
                            e.setValue(i(t))
                        },
                        subscribe: (t, n) => {
                            const r = e => {
                                n(a)
                            };
                            o.set(n, r), e.subscribe(t, r)
                        },
                        unsubscribe: (t, n) => {
                            const r = o.get(n);
                            r && (e.unsubscribe(t, r), o.delete(n))
                        },
                        unsubscribeAll: t => {
                            e.unsubscribeAll(t), o.clear()
                        },
                        destroy: () => {
                            null == n || n()
                        }
                    };
                return a
            }

            function r(e) {
                const t = o(e);
                return t.destroy = () => {
                    e.destroy()
                }, t
            }

            function i(e, t, n, r, i, a) {
                const l = o(t, r, a),
                    s = void 0 !== r ? void 0 !== r[1] ? r[1] : r[0] : e => e;
                return l.setValue = null != i ? i : o => e.setProperty(t, s(o), n), l
            }
            n.d(t, {
                makeProxyDefinitionProperty: () => o,
                makeProxyDefinitionPropertyDestroyable: () => r,
                convertToDefinitionProperty: () => i
            })
        },
        1272: (e, t, n) => {
            "use strict";

            function o(e, t) {
                return {
                    propType: "checkable",
                    properties: e,
                    ...t
                }
            }

            function r(e, t, n) {
                return {
                    propType: "checkableSet",
                    properties: e,
                    childrenDefinitions: n,
                    ...t
                }
            }

            function i(e, t) {
                return {
                    propType: "color",
                    properties: e,
                    noAlpha: !1,
                    ...t
                }
            }
            n.d(t, {
                convertFromReadonlyWVToDefinitionProperty: () => H,
                convertFromWVToDefinitionProperty: () => j,
                convertToDefinitionProperty: () => W.convertToDefinitionProperty,
                createCheckablePropertyDefinition: () => o,
                createCheckableSetPropertyDefinition: () => r,
                createColorPropertyDefinition: () => i,
                createCoordinatesPropertyDefinition: () => N,
                createEmojiPropertyDefinition: () => _,
                createLeveledLinePropertyDefinition: () => h,
                createLinePropertyDefinition: () => u,
                createNumberPropertyDefinition: () => f,
                createOptionsPropertyDefinition: () => v,
                createPropertyDefinitionsGeneralGroup: () => L,
                createPropertyDefinitionsLeveledLinesGroup: () => A,
                createRangePropertyDefinition: () => M,
                createSessionPropertyDefinition: () => k,
                createStudyInputsPropertyDefinition: () => B,
                createSymbolPropertyDefinition: () => T,
                createTextPropertyDefinition: () => P,
                createTransparencyPropertyDefinition: () => z,
                createTwoColorsPropertyDefinition: () => V,
                createTwoOptionsPropertyDefinition: () => g,
                destroyDefinitions: () => $,
                getColorDefinitionProperty: () => q,
                getLockPriceScaleDefinitionProperty: () => O,
                getPriceScaleSelectionStrategyDefinitionProperty: () => Z,
                getScaleRatioDefinitionProperty: () => Q,
                getSymbolDefinitionProperty: () => X,
                isPropertyDefinitionsGroup: () => J
            });
            var a = n(6605),
                l = n(46750);
            const s = [l.LINESTYLE_SOLID, l.LINESTYLE_DOTTED, l.LINESTYLE_DASHED],
                c = [1, 2, 3, 4],
                d = [a.LineEnd.Normal, a.LineEnd.Arrow];

            function u(e, t) {
                const n = {
                    propType: "line",
                    properties: e,
                    ...t
                };
                return void 0 !== n.properties.style && (n.styleValues = s), void 0 !== n.properties.width && (n.widthValues = c), void 0 === n.properties.leftEnd && void 0 === n.properties.rightEnd || void 0 !== n.endsValues || (n.endsValues = d), void 0 !== n.properties.value && void 0 === n.valueType && (n.valueType = 1), n
            }
            const p = [l.LINESTYLE_SOLID, l.LINESTYLE_DOTTED, l.LINESTYLE_DASHED],
                m = [1, 2, 3, 4];

            function h(e, t) {
                const n = {
                    propType: "leveledLine",
                    properties: e,
                    ...t
                };
                return void 0 !== n.properties.style && (n.styleValues = p), void 0 !== n.properties.width && (n.widthValues = m), n
            }

            function f(e, t) {
                return {
                    propType: "number",
                    properties: e,
                    type: 1,
                    ...t
                }
            }

            function v(e, t) {
                return {
                    propType: "options",
                    properties: e,
                    ...t
                }
            }

            function g(e, t) {
                return {
                    propType: "twoOptions",
                    properties: e,
                    ...t
                }
            }
            var b = n(25177);
            const y = [{
                    id: "bottom",
                    value: "bottom",
                    title: (0, b.t)("Top")
                }, {
                    id: "middle",
                    value: "middle",
                    title: (0, b.t)("Middle")
                }, {
                    id: "top",
                    value: "top",
                    title: (0, b.t)("Bottom")
                }],
                w = [{
                    id: "left",
                    value: "left",
                    title: (0, b.t)("Left")
                }, {
                    id: "center",
                    value: "center",
                    title: (0, b.t)("Center")
                }, {
                    id: "right",
                    value: "right",
                    title: (0, b.t)("Right")
                }],
                E = [{
                    id: "horizontal",
                    value: "horizontal",
                    title: (0, b.t)("Horizontal")
                }, {
                    id: "vertical",
                    value: "vertical",
                    title: (0, b.t)("Vertical")
                }],
                C = [10, 11, 12, 14, 16, 20, 24, 28, 32, 40].map(e => ({
                    title: String(e),
                    value: e
                })),
                S = [1, 2, 3, 4],
                D = (0, b.t)("Text alignment"),
                x = (0, b.t)("Text orientation");

            function P(e, t) {
                const n = {
                    propType: "text",
                    properties: e,
                    ...t,
                    isEditable: t.isEditable || !1
                };
                return void 0 !== n.properties.size && void 0 === n.sizeItems && (n.sizeItems = C), void 0 !== n.properties.alignmentVertical && void 0 === n.alignmentVerticalItems && (n.alignmentVerticalItems = y), void 0 !== n.properties.alignmentHorizontal && void 0 === n.alignmentHorizontalItems && (n.alignmentHorizontalItems = w), (n.alignmentVerticalItems || n.alignmentHorizontalItems) && void 0 === n.alignmentTitle && (n.alignmentTitle = D), void 0 !== n.properties.orientation && (void 0 === n.orientationItems && (n.orientationItems = E), void 0 === n.orientationTitle && (n.orientationTitle = x)), void 0 !== n.properties.borderWidth && void 0 === n.borderWidthItems && (n.borderWidthItems = S), n
            }

            function V(e, t) {
                return {
                    propType: "twoColors",
                    properties: e,
                    noAlpha1: !1,
                    noAlpha2: !1,
                    ...t
                }
            }

            function N(e, t) {
                return {
                    propType: "coordinates",
                    properties: e,
                    ...t
                }
            }

            function M(e, t) {
                return {
                    propType: "range",
                    properties: e,
                    ...t
                }
            }

            function z(e, t) {
                return {
                    propType: "transparency",
                    properties: e,
                    ...t
                }
            }

            function T(e, t) {
                return {
                    propType: "symbol",
                    properties: e,
                    ...t
                }
            }

            function k(e, t) {
                return {
                    propType: "session",
                    properties: e,
                    ...t
                }
            }

            function _(e, t) {
                return {
                    propType: "emoji",
                    properties: e,
                    ...t
                }
            }

            function B(e, t) {
                return {
                    propType: "studyInputs",
                    properties: e,
                    ...t
                }
            }
            var I = n(94489),
                R = n.n(I);

            function L(e, t, n, o) {
                return {
                    id: t,
                    title: n,
                    visible: o,
                    groupType: "general",
                    definitions: new(R())(e)
                }
            }

            function A(e, t, n) {
                return {
                    id: t,
                    title: n,
                    groupType: "leveledLines",
                    definitions: new(R())(e)
                }
            }
            var W = n(9297);

            function F(e, t) {
                const n = new Map,
                    o = void 0 !== t ? t[0] : e => e,
                    r = void 0 !== t ? void 0 !== t[1] ? t[1] : t[0] : e => e,
                    i = {
                        value: () => o(e.value()),
                        setValue: t => {
                            var n;
                            null === (n = e.setValue) || void 0 === n || n.call(e, r(t))
                        },
                        subscribe: (t, o) => {
                            const r = () => {
                                o(i)
                            };
                            let a = n.get(t);
                            void 0 === a ? (a = new Map, a.set(o, r), n.set(t, a)) : a.set(o, r), e.subscribe(r)
                        },
                        unsubscribe: (t, o) => {
                            const r = n.get(t);
                            if (void 0 !== r) {
                                const t = r.get(o);
                                void 0 !== t && (e.unsubscribe(t), r.delete(o))
                            }
                        },
                        unsubscribeAll: t => {
                            const o = n.get(t);
                            void 0 !== o && (o.forEach((t, n) => {
                                e.unsubscribe(t)
                            }), o.clear())
                        }
                    };
                return i
            }

            function j(e, t, n, o) {
                const r = F(t, o),
                    i = void 0 !== o ? void 0 !== o[1] ? o[1] : o[0] : e => e;
                return r.setValue = o => e.setWatchedValue(t, i(o), n), r
            }

            function H(e, t) {
                return function(e, t, n) {
                    const o = new Map;
                    return F({
                        subscribe: (n, r) => {
                            const i = e => n(t(e));
                            o.set(n, i), e.subscribe(i, r)
                        },
                        unsubscribe: t => {
                            if (t) {
                                const n = o.get(t);
                                n && (e.unsubscribe(n), o.delete(t))
                            } else o.clear(), e.unsubscribe()
                        },
                        value: () => t(e.value())
                    }, n)
                }(e, e => e, t)
            }

            function Z(e, t) {
                const n = (0,
                    W.makeProxyDefinitionProperty)(t);
                return n.setValue = t => e.setPriceScaleSelectionStrategy(t), n
            }

            function O(e, t, n, o) {
                const r = (0, W.makeProxyDefinitionProperty)(t);
                return r.setValue = t => {
                    const r = {
                        lockScale: t
                    };
                    e.setPriceScaleMode(r, n, o)
                }, r
            }

            function Q(e, t, n, o) {
                const r = (0, W.makeProxyDefinitionProperty)(t, o);
                return r.setValue = o => {
                    e.setScaleRatioProperty(t, o, n)
                }, r
            }
            var U = n(24377),
                Y = n(76036),
                K = n(76337);

            function G(e, t) {
                if ((0, Y.isHexColor)(e)) {
                    const n = (0, U.parseRgb)(e);
                    return (0, U.rgbaToString)((0, U.rgba)(n, (100 - t) / 100))
                }
                return e
            }

            function q(e, t, n, o, r) {
                let i;
                if (null !== n) {
                    const e = (0, K.combineProperty)(G, t, n);
                    i = (0, W.makeProxyDefinitionPropertyDestroyable)(e)
                } else i = (0, W.makeProxyDefinitionProperty)(t, [() => G(t.value(), 0), e => e]);
                return i.setValue = n => {
                    r && e.beginUndoMacro(o), e.setProperty(t, n, o), r && e.endUndoMacro()
                }, i
            }

            function X(e, t, n, o, r, i) {
                const a = [(l = n, s = t, e => {
                    const t = l(s);
                    if (e === s.value() && null !== t) {
                        const e = t.ticker || t.full_name;
                        if (e) return e
                    }
                    return e
                }), e => e];
                var l, s;
                const c = (0, W.convertToDefinitionProperty)(e, t, r, a);
                i && (c.setValue = i);
                const d = new Map;
                c.subscribe = (e, n) => {
                    const o = e => {
                        n(c)
                    };
                    d.set(n, o), t.subscribe(e, o)
                }, c.unsubscribe = (e, n) => {
                    const o = d.get(n);
                    o && (t.unsubscribe(e, o), d.delete(n))
                };
                const u = {};
                return o.subscribe(u, () => {
                    d.forEach((e, t) => {
                        t(c)
                    })
                }), c.destroy = () => {
                    o.unsubscribeAll(u), d.clear()
                }, c
            }

            function J(e) {
                return e.hasOwnProperty("groupType")
            }

            function $(e) {
                e.forEach(e => {
                    if (e.hasOwnProperty("propType")) {
                        Object.keys(e.properties).forEach(t => {
                            const n = e.properties[t];
                            void 0 !== n && void 0 !== n.destroy && n.destroy()
                        })
                    } else $(e.definitions.value())
                })
            }
        },
        32668: (e, t, n) => {
            "use strict";
            n.d(t, {
                FontSizeSelect: () => c
            });
            var o = n(59496),
                r = n(97754),
                i = n.n(r),
                a = n(36118),
                l = n(417),
                s = n(58858);

            function c(e) {
                const {
                    id: t,
                    fontSize: n,
                    fontSizes: r = [],
                    className: c,
                    disabled: d,
                    fontSizeChange: u
                } = e;
                return o.createElement(a.Select, {
                    id: t,
                    disabled: d,
                    className: i()(c, s.defaultSelect),
                    menuClassName: s.defaultSelect,
                    items: (p = r, p.map(e => ({
                        value: e.value,
                        content: e.title
                    }))),
                    value: n,
                    onChange: u,
                    ...(0, l.filterDataProps)(e)
                });
                var p
            }
        },
        65588: (e, t, n) => {
            "use strict";
            n.d(t, {
                IconDropdown: () => c,
                DisplayItem: () => d,
                DropItem: () => u
            });
            var o = n(59496),
                r = n(97754),
                i = n.n(r),
                a = n(36118),
                l = n(72571),
                s = n(78781);

            function c(e) {
                const {
                    menuItemClassName: t,
                    ...n
                } = e;
                return o.createElement(a.Select, { ...n,
                    menuItemClassName: i()(t, s.itemWrap)
                })
            }

            function d(e) {
                return o.createElement("div", {
                    className: i()(s.item, s.selected, e.className)
                }, o.createElement(l.Icon, {
                    className: s.icon,
                    icon: e.icon
                }))
            }

            function u(e) {
                return o.createElement("div", {
                    className: s.item
                }, o.createElement(l.Icon, {
                    className: i()(s.icon, e.iconClassName),
                    icon: e.icon
                }), o.createElement("div", {
                    className: s.label
                }, e.label))
            }
        },
        96855: (e, t, n) => {
            "use strict";
            n.d(t, {
                LineStyleSelect: () => f
            });
            var o = n(25177),
                r = n(59496),
                i = n(97754),
                a = n.n(i),
                l = n(46750),
                s = n(65588),
                c = n(47387),
                d = n(87460),
                u = n(22931),
                p = n(47044),
                m = n(73084);
            const h = [{
                type: l.LINESTYLE_SOLID,
                icon: c,
                label: (0, o.t)("Line")
            }, {
                type: l.LINESTYLE_DASHED,
                icon: d,
                label: (0, o.t)("Dashed line")
            }, {
                type: l.LINESTYLE_DOTTED,
                icon: u,
                label: (0, o.t)("Dotted line")
            }];
            class f extends r.PureComponent {
                render() {
                    const {
                        id: e,
                        lineStyle: t,
                        className: n,
                        lineStyleChange: o,
                        disabled: i,
                        additionalItems: l,
                        allowedLineStyles: c
                    } = this.props;
                    let d = function(e) {
                        let t = [...h];
                        return void 0 !== e && (t = t.filter(t => e.includes(t.type))), t.map(e => ({
                            value: e.type,
                            selectedContent: r.createElement(s.DisplayItem, {
                                icon: e.icon
                            }),
                            content: r.createElement(s.DropItem, {
                                icon: e.icon,
                                label: e.label
                            })
                        }))
                    }(c);
                    return l && (d = [{
                        readonly: !0,
                        content: l
                    }, ...d]), r.createElement(s.IconDropdown, {
                        id: e,
                        disabled: i,
                        className: a()(m.lineStyleSelect, n),
                        hideArrowButton: !0,
                        items: d,
                        value: t,
                        onChange: o,
                        "data-name": "line-style-select",
                        addPlaceholderToItems: !1,
                        placeholder: r.createElement(s.DisplayItem, {
                            icon: p,
                            className: m.multipleStyles
                        })
                    })
                }
            }
        },
        54393: (e, t, n) => {
            "use strict";
            n.d(t, {
                LineWidthSelect: () => d
            });
            var o = n(59496),
                r = n(97754),
                i = n(36118),
                a = n(218);
            const l = [1, 2, 3, 4];

            function s(e) {
                const {
                    id: t,
                    value: n,
                    items: s = l,
                    disabled: c,
                    onChange: d
                } = e;
                return o.createElement(i.Select, {
                    id: t,
                    disabled: c,
                    hideArrowButton: !0,
                    className: a.lineWidthSelect,
                    items: (u = s, u.map(e => ({
                        value: e,
                        selectedContent: p(e, !0),
                        content: p(e)
                    }))),
                    value: n,
                    onChange: d,
                    "data-name": "line-width-select"
                });
                var u;

                function p(e, t) {
                    const i = {
                        borderTopWidth: e
                    };
                    return o.createElement("div", {
                        className: a.item
                    }, o.createElement("div", {
                        className: r(a.bar, {
                            [a.isActive]: e === n && !t
                        }),
                        style: i
                    }, " "))
                }
            }
            var c = n(71586);

            function d(e) {
                const {
                    property: t
                } = e, [n, r] = (0, c.useDefinitionProperty)({
                    property: t
                });
                return o.createElement(s, { ...e,
                    value: n,
                    onChange: r
                })
            }
        },
        18356: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlCustomWidthContext: () => r,
                ControlCustomHeightContext: () => i
            });
            var o = n(59496);
            const r = o.createContext({}),
                i = o.createContext({})
        },
        71102: (e, t, n) => {
            "use strict";
            n.d(t, {
                Section: () => tn
            });
            var o = n(59496),
                r = n(1272),
                i = n(93315),
                a = n(71586),
                l = n(55261);

            function s(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            checked: n,
                            disabled: r,
                            visible: i
                        },
                        title: s
                    },
                    offset: c
                } = e, [d] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !1
                }), [u] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !0
                });
                return u ? o.createElement(l.CommonSection, {
                    id: t,
                    offset: c,
                    checked: n,
                    title: s,
                    disabled: e.disabled || d
                }) : null
            }
            var c = n(97754),
                d = n.n(c),
                u = n(14823),
                p = n(96855);

            function m(e) {
                const {
                    property: t
                } = e, [n, r] = (0, a.useDefinitionProperty)({
                    property: t
                });
                return o.createElement(p.LineStyleSelect, { ...e,
                    lineStyle: n,
                    lineStyleChange: r
                })
            }
            var h = n(54393),
                f = n(60521),
                v = n(88537);

            function g(e) {
                return "mixed" === e
            }

            function b(e, t, n) {
                const [r, i] = (0, o.useState)(e), a = (0, o.useRef)(r);
                return (0, o.useEffect)(() => {
                    i(e)
                }, [e, n]), [r, function(e) {
                    a.current = e, i(e)
                }, function() {
                    t(a.current)
                }, function() {
                    a.current = e, i(e)
                }]
            }
            var y = n(80185),
                w = n(76805),
                E = n(97280),
                C = n(8329),
                S = n(1227);

            function D(e) {
                const {
                    property: t,
                    ...n
                } = e, [r, i] = (0, o.useState)(performance.now()), [l, s] = (0, a.useDefinitionProperty)({
                    property: t,
                    handler: () => i(performance.now())
                }), c = b(l, s, r);
                return o.createElement(x, { ...n,
                    valueHash: r,
                    sharedBuffer: c
                })
            }

            function x(e) {
                const {
                    sharedBuffer: t,
                    min: n,
                    max: r,
                    step: i,
                    ...a
                } = e, [l, s, c, d] = t, u = (0, o.useRef)(null), p = (0, o.useRef)(null), m = {
                    flushed: !1
                };
                return o.createElement(V, { ...a,
                    ref: p,
                    onValueChange: function(e, t) {
                        s(e), "step" !== t || m.flushed || (c(), m.flushed = !0)
                    },
                    onKeyDown: function(e) {
                        if (e.defaultPrevented || m.flushed) return;
                        switch ((0, y.hashFromEvent)(e.nativeEvent)) {
                            case 27:
                                d(), m.flushed = !0;
                                break;
                            case 13:
                                e.preventDefault();
                                const t = (0, v.ensureNotNull)(p.current).getClampedValue();
                                null !== t && (s(t), c(), m.flushed = !0)
                        }
                    },
                    onBlur: function(e) {
                        const t = (0, v.ensureNotNull)(u.current);
                        if (!t.contains(document.activeElement) && !t.contains(e.relatedTarget)) {
                            const e = (0, v.ensureNotNull)(p.current).getClampedValue();
                            null === e || m.flushed || (s(e), c(), m.flushed = !0)
                        }
                    },
                    value: l,
                    roundByStep: !1,
                    containerReference: function(e) {
                        u.current = e
                    },
                    inputMode: S.CheckMobile.iOS() ? void 0 : "numeric",
                    min: n,
                    max: r,
                    step: i,
                    stretch: !1
                })
            }
            const P = {
                mode: "float",
                min: -Number.MAX_VALUE,
                max: Number.MAX_VALUE,
                step: 1,
                precision: 0,
                inheritPrecisionFromStep: !0
            };
            class V extends o.PureComponent {
                constructor(e) {
                    super(e), this._selection = null, this._restoreSelection = !1, this._input = null, this._handleSelectionChange = () => {
                        this._restoreSelection || document.activeElement !== (0, v.ensureNotNull)(this._input) || this._saveSelection((0, v.ensureNotNull)(this._input))
                    }, this._handleInputReference = e => {
                        this._input = e, this.props.inputReference && this.props.inputReference(e)
                    }, this._onFocus = e => {
                        this._saveSelection((0, v.ensureNotNull)(this._input)), this.setState({
                            focused: !0
                        }), this.props.onFocus && this.props.onFocus(e)
                    }, this._onBlur = e => {
                        this._selection = null, this.setState({
                            displayValue: z(this.props, this.props.value, T(this.props)),
                            focused: !1
                        }), this.props.onBlur && this.props.onBlur(e)
                    }, this._onValueChange = e => {
                        const t = e.currentTarget,
                            n = t.value,
                            o = function(e, t, n) {
                                switch (n) {
                                    case "integer":
                                        return N.test(t) ? t : e;
                                    case "float":
                                        return t = t.replace(/,/g, "."), M.test(t) ? t : e
                                }
                            }(this.state.displayValue, n, this.props.mode),
                            r = _(o),
                            i = this._checkValueBoundaries(r);
                        var a, l;
                        this.setState({
                            displayValue: o
                        }), o !== n && (a = this.state.displayValue, l = (l = o).replace(/,/g, "."), (a = a.replace(/,/g, ".")).includes(".") || !l.includes(".")) ? (this._restoreSelection = !0, this.forceUpdate()) : this._saveSelection(t), i.value && z(this.props, r) === o && this.props.onValueChange(r, "input")
                    }, this._onValueByStepChange = e => {
                        const {
                            roundByStep: t = !0,
                            step: n = 1
                        } = this.props, o = _(this.state.displayValue);
                        let r;
                        if (isNaN(o)) {
                            const {
                                defaultValue: e
                            } = this.props;
                            if (void 0 === e) return;
                            r = e
                        } else {
                            const i = new f.Big(o),
                                a = new f.Big(n),
                                l = i.mod(a);
                            let s = i.plus(e * n);
                            !l.eq(0) && t && (s = s.plus((e > 0 ? 0 : 1) * n).minus(l)), r = s.toNumber()
                        }
                        this._checkValueBoundaries(r).value && (this.setState({
                            displayValue: z(this.props, r, T(this.props))
                        }), this.props.onValueChange(r, "step"))
                    }, this.state = {
                        value: B(this.props.value),
                        displayValue: z(this.props, this.props.value, T(this.props)),
                        focused: !1,
                        valueHash: this.props.valueHash
                    }
                }
                componentDidMount() {
                    document.addEventListener("selectionchange", this._handleSelectionChange)
                }
                componentWillUnmount() {
                    document.removeEventListener("selectionchange", this._handleSelectionChange)
                }
                componentDidUpdate() {
                    const e = (0, v.ensureNotNull)(this._input),
                        t = this._selection;
                    if (null !== t && this._restoreSelection && document.activeElement === e) {
                        const {
                            start: n,
                            end: o,
                            direction: r
                        } = t;
                        e.setSelectionRange(n, o, r)
                    }
                    this._restoreSelection = !1
                }
                render() {
                    return o.createElement(w.NumberInputView, {
                        type: "text",
                        inputMode: this.props.inputMode,
                        name: this.props.name,
                        fontSizeStyle: "medium",
                        value: this.state.displayValue,
                        className: this.props.className,
                        placeholder: this.props.placeholder,
                        disabled: this.props.disabled,
                        stretch: this.props.stretch,
                        onValueChange: this._onValueChange,
                        onValueByStepChange: this._onValueByStepChange,
                        containerReference: this.props.containerReference,
                        inputReference: this._handleInputReference,
                        onClick: this.props.onClick,
                        onFocus: this._onFocus,
                        onBlur: this._onBlur,
                        onKeyDown: this.props.onKeyDown,
                        autoSelectOnFocus: !0,
                        "data-name": this.props["data-name"]
                    })
                }
                getClampedValue() {
                    const {
                        min: e,
                        max: t
                    } = this.props, n = _(this.state.displayValue);
                    return isNaN(n) ? null : (0, E.clamp)(n, e, t)
                }
                static getDerivedStateFromProps(e, t) {
                    const {
                        valueHash: n
                    } = e, o = B(e.value);
                    if (t.value !== o || t.valueHash !== n) {
                        return {
                            value: o,
                            valueHash: n,
                            displayValue: z(e, o, t.focused && t.valueHash === n ? void 0 : T(e))
                        }
                    }
                    return null
                }
                _saveSelection(e) {
                    const {
                        selectionStart: t,
                        selectionEnd: n,
                        selectionDirection: o
                    } = e;
                    null !== t && null !== n && null !== o && (this._selection = {
                        start: t,
                        end: n,
                        direction: o
                    })
                }
                _checkValueBoundaries(e) {
                    const {
                        min: t,
                        max: n
                    } = this.props;
                    return {
                        value: function(e, t, n) {
                            const o = e >= t,
                                r = e <= n;
                            return {
                                passMin: o,
                                passMax: r,
                                pass: o && r,
                                clamped: (0, E.clamp)(e, t, n)
                            }
                        }(e, t, n).pass
                    }
                }
            }
            V.defaultProps = P;
            const N = /^-?[0-9]*$/,
                M = /^(-?([0-9]+\.?[0-9]*)|(-?[0-9]*))$/;

            function z(e, t, n) {
                return g(t = B(t)) ? "—" : (null !== t && void 0 !== n && (n = Math.max(k(t), n)), function(e, t) {
                    if (null === e) return "";
                    return new C.NumericFormatter(t).format(e)
                }(t, n))
            }

            function T(e) {
                let t = 0;
                return e.inheritPrecisionFromStep && e.step <= 1 && (t = k(e.step)), Math.max(e.precision, t) || void 0
            }

            function k(e) {
                const t = Math.trunc(e).toString();
                return (0, E.clamp)(C.NumericFormatter.formatNoE(e).length - t.length - 1, 0, 15)
            }

            function _(e, t) {
                return new C.NumericFormatter(t).parse(e)
            }

            function B(e) {
                return "number" == typeof e && Number.isFinite(e) || g(e) ? e : null
            }
            var I = n(24377),
                R = n(52315),
                L = n(76036);

            function A(e) {
                const {
                    color: t,
                    thickness: n,
                    thicknessItems: r,
                    noAlpha: i
                } = e, [l, s] = (0, a.useDefinitionProperty)({
                    property: t
                }), [c, d] = (0, a.useDefinitionProperty)(n ? {
                    property: n
                } : {
                    defaultValue: void 0
                });
                return o.createElement(R.ColorSelect, { ...e,
                    color: function() {
                        if (!l) return null;
                        if ("mixed" === l) return "mixed";
                        return (0, I.rgbToHexString)((0, I.parseRgb)(l))
                    }(),
                    onColorChange: function(e) {
                        const t = l && "mixed" !== l ? (0, L.alphaToTransparency)((0, I.parseRgba)(l)[3]) : 0;
                        s((0, L.generateColor)(String(e), t, !0))
                    },
                    thickness: c,
                    thicknessItems: r,
                    onThicknessChange: d,
                    opacity: i ? void 0 : l && "mixed" !== l ? (0, I.parseRgba)(l)[3] : void 0,
                    onOpacityChange: i ? void 0 : function(e) {
                        s((0, L.generateColor)(l, (0, L.alphaToTransparency)(e), !0))
                    }
                })
            }
            var W = n(25177),
                F = n(6605),
                j = n(65588),
                H = n(417),
                Z = n(66058),
                O = n(25785),
                Q = n(5717);
            const U = [{
                type: F.LineEnd.Normal,
                icon: Z,
                label: (0, W.t)("Normal")
            }, {
                type: F.LineEnd.Arrow,
                icon: O,
                label: (0, W.t)("Arrow")
            }];
            class Y extends o.PureComponent {
                constructor(e) {
                    super(e), this._items = [], this._items = U.map(t => ({
                        value: t.type,
                        selectedContent: o.createElement(j.DisplayItem, {
                            icon: t.icon
                        }),
                        content: o.createElement(j.DropItem, {
                            icon: t.icon,
                            iconClassName: d()(e.isRight && Q.right),
                            label: t.label
                        })
                    }))
                }
                render() {
                    const {
                        id: e,
                        lineEnd: t,
                        className: n,
                        lineEndChange: r,
                        isRight: i,
                        disabled: a
                    } = this.props;
                    return o.createElement(j.IconDropdown, {
                        id: e,
                        disabled: a,
                        className: d()(Q.lineEndSelect, i && Q.right, n),
                        items: this._items,
                        value: t,
                        onChange: r,
                        hideArrowButton: !0,
                        ...(0, H.filterDataProps)(this.props)
                    })
                }
            }

            function K(e) {
                const {
                    property: t
                } = e, [n, r] = (0, a.useDefinitionProperty)({
                    property: t
                });
                return o.createElement(Y, { ...e,
                    lineEnd: n,
                    lineEndChange: r
                })
            }
            var G = n(20911),
                q = n(31650);

            function X(e) {
                const {
                    children: t,
                    className: n,
                    breakPoint: r = "Normal"
                } = e;
                return o.createElement(G.CellWrap, {
                    className: c(q.wrap, n, q["breakpoint" + r])
                }, o.Children.map(t, e => o.isValidElement(e) ? o.createElement("span", {
                    key: null === e.key ? void 0 : e.key,
                    className: q.row
                }, e) : e))
            }
            const J = {
                1: "float",
                0: "integer"
            };
            var $ = n(97265),
                ee = n(55368);

            function te(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            checked: n,
                            disabled: r,
                            visible: i,
                            leftEnd: s,
                            rightEnd: d,
                            value: p,
                            extendLeft: f,
                            extendRight: v
                        },
                        title: g,
                        valueMin: b,
                        valueMax: y,
                        valueStep: w,
                        valueUnit: E,
                        extendLeftTitle: C,
                        extendRightTitle: S
                    },
                    offset: x
                } = e, [P] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !0
                }), [V] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !1
                }), [N] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !0
                }), M = (0, $.useWatchedValueReadonly)({
                    watchedValue: b,
                    defaultValue: void 0
                }), z = (0, $.useWatchedValueReadonly)({
                    watchedValue: y,
                    defaultValue: void 0
                }), T = (0, $.useWatchedValueReadonly)({
                    watchedValue: w,
                    defaultValue: void 0
                }), k = (0, $.useWatchedValueReadonly)({
                    watchedValue: E,
                    defaultValue: void 0
                }), _ = e.disabled || !P;
                return N ? o.createElement(o.Fragment, null, o.createElement(l.CommonSection, {
                    id: t,
                    offset: x,
                    checked: n,
                    title: g,
                    disabled: e.disabled || V
                }, o.createElement(X, {
                    className: ee.line,
                    breakPoint: "Small"
                }, o.createElement(o.Fragment, null, function() {
                    const {
                        definition: {
                            properties: {
                                color: n,
                                width: r
                            },
                            widthValues: i
                        }
                    } = e;
                    if (n) return o.createElement("span", {
                        className: ee.control
                    }, o.createElement(A, {
                        color: n,
                        thickness: r,
                        disabled: _,
                        thicknessItems: i
                    }));
                    return r && o.createElement("span", {
                        className: ee.control
                    }, o.createElement(h.LineWidthSelect, {
                        id: (0, u.createDomId)(t, "line-width-select"),
                        items: i,
                        property: r,
                        disabled: _
                    }))
                }(), function() {
                    const {
                        definition: {
                            properties: {
                                style: n
                            }
                        }
                    } = e;
                    return n && o.createElement("span", {
                        className: ee.control
                    }, o.createElement(m, {
                        id: (0, u.createDomId)(t, "line-style-select"),
                        property: n,
                        disabled: _
                    }))
                }()), (s || d || p) && o.createElement(o.Fragment, null, o.createElement(o.Fragment, null, s && o.createElement(K, {
                    id: (0, u.createDomId)(t, "left-end-select"),
                    "data-name": "left-end-select",
                    className: ee.control,
                    property: s,
                    disabled: _
                }), d && o.createElement(K, {
                    id: (0, u.createDomId)(t, "right-end-select"),
                    "data-name": "right-end-select",
                    className: ee.control,
                    property: d,
                    disabled: _,
                    isRight: !0
                })), function() {
                    const {
                        definition: {
                            valueType: t
                        }
                    } = e;
                    return p && o.createElement("span", {
                        className: c(ee.valueInput, ee.control)
                    }, o.createElement(D, {
                        className: ee.input,
                        property: p,
                        min: M,
                        max: z,
                        step: T,
                        disabled: _,
                        mode: void 0 !== t ? J[t] : void 0,
                        name: "line-value-input"
                    }), o.createElement("span", {
                        className: ee.valueUnit
                    }, k))
                }()))), f && o.createElement(l.CommonSection, {
                    id: t + "ExtendLeft",
                    offset: x,
                    checked: f,
                    title: C,
                    disabled: e.disabled || V
                }), v && o.createElement(l.CommonSection, {
                    id: t + "ExtendRight",
                    offset: x,
                    checked: v,
                    title: S,
                    disabled: e.disabled || V
                })) : null
            }
            var ne = n(7553),
                oe = n(36118),
                re = n(85938);

            function ie(e) {
                const {
                    property: t,
                    options: n,
                    ...r
                } = e, [i, l] = (0, a.useDefinitionProperty)({
                    property: t
                }), s = (0, re.useForceUpdate)();
                return (0, o.useEffect)(() => {
                    const e = () => s();
                    return Array.isArray(n) || n.subscribe(e), () => {
                        Array.isArray(n) || n.unsubscribe(e)
                    }
                }, []), o.createElement(oe.Select, { ...r,
                    onChange: l,
                    value: i,
                    items: (Array.isArray(n) ? n : n.value()).map(e => e.readonly ? {
                        content: e.title,
                        readonly: e.readonly
                    } : {
                        content: e.title,
                        value: e.value,
                        disabled: e.disabled,
                        id: e.id
                    })
                })
            }
            var ae = n(52465);
            const le = [{
                title: (0, W.t)("Solid"),
                value: ne.ColorType.Solid
            }, {
                title: (0, W.t)("Gradient"),
                value: ne.ColorType.Gradient
            }];

            function se(e) {
                const {
                    id: t,
                    disabled: n,
                    noAlpha: r,
                    properties: i
                } = e, {
                    color: l,
                    gradientColor1: s,
                    gradientColor2: c,
                    type: d
                } = i, [p] = (0, a.useDefinitionProperty)({
                    property: d,
                    defaultValue: ne.ColorType.Solid
                });
                return o.createElement(X, null, o.createElement(ie, {
                    id: (0, u.createDomId)(t, "background-type-options-dropdown"),
                    "data-name": "background-type-options-dropdown",
                    className: ae.dropdown,
                    menuClassName: ae.dropdownMenu,
                    disabled: n,
                    property: d,
                    options: le
                }), p === ne.ColorType.Solid ? o.createElement(A, {
                    color: l,
                    disabled: n,
                    noAlpha: r
                }) : o.createElement(o.Fragment, null, o.createElement(A, {
                    className: ae.firstColorPicker,
                    color: s,
                    disabled: n,
                    noAlpha: r
                }), o.createElement(A, {
                    color: c,
                    disabled: n,
                    noAlpha: r
                })))
            }

            function ce(e) {
                const {
                    definition: {
                        id: t,
                        properties: n,
                        title: r,
                        noAlpha: i
                    },
                    offset: s
                } = e, {
                    color: c,
                    checked: d,
                    disabled: u,
                    visible: p
                } = n, [m] = (0, a.useDefinitionProperty)({
                    property: d,
                    defaultValue: !0
                }), [h] = (0, a.useDefinitionProperty)({
                    property: u,
                    defaultValue: !1
                }), [f] = (0, a.useDefinitionProperty)({
                    property: p,
                    defaultValue: !0
                }), v = e.disabled || !m;
                return f ? o.createElement(l.CommonSection, {
                    id: t,
                    offset: s,
                    checked: d,
                    title: r,
                    disabled: e.disabled || h
                }, o.createElement(G.CellWrap, null, n.hasOwnProperty("type") ? o.createElement(se, {
                    id: t,
                    properties: n,
                    disabled: v,
                    noAlpha: i
                }) : o.createElement(A, {
                    color: c,
                    disabled: v,
                    noAlpha: i
                }))) : null
            }
            var de = n(39075),
                ue = n(2996),
                pe = n(21818);

            function me(e) {
                const {
                    value: t,
                    disabled: n,
                    onChange: r,
                    className: i
                } = e;
                return o.createElement("div", {
                    className: c(pe.wrap, i, {
                        [pe.disabled]: n
                    })
                }, o.createElement(de.Opacity, {
                    hideInput: !0,
                    color: ue.colorsPalette["color-tv-blue-500"],
                    opacity: 1 - t / 100,
                    onChange: function(e) {
                        n || r(100 - 100 * e)
                    }
                }))
            }

            function he(e) {
                const {
                    property: t,
                    ...n
                } = e, [r, i] = (0, a.useDefinitionProperty)({
                    property: t
                });
                return o.createElement(me, { ...n,
                    value: r,
                    onChange: i
                })
            }

            function fe(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            transparency: n,
                            checked: r,
                            disabled: i,
                            visible: s
                        },
                        title: c
                    },
                    offset: d
                } = e, [u] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !0
                }), [p] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !1
                }), [m] = (0, a.useDefinitionProperty)({
                    property: s,
                    defaultValue: !0
                }), h = e.disabled || !u;
                return m ? o.createElement(l.CommonSection, {
                    id: t,
                    offset: d,
                    checked: r,
                    title: c,
                    disabled: e.disabled || p
                }, o.createElement(G.CellWrap, null, o.createElement(he, {
                    property: n,
                    disabled: h
                }))) : null
            }
            var ve = n(35048);

            function ge(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            color1: n,
                            color2: r,
                            checked: i,
                            disabled: s,
                            visible: c
                        },
                        title: d,
                        noAlpha1: u,
                        noAlpha2: p
                    },
                    offset: m
                } = e, [h] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !0
                }), [f] = (0, a.useDefinitionProperty)({
                    property: s,
                    defaultValue: !1
                }), [v] = (0, a.useDefinitionProperty)({
                    property: c,
                    defaultValue: !0
                }), g = e.disabled || !h || f;
                return v ? o.createElement(l.CommonSection, {
                    id: t,
                    offset: m,
                    checked: i,
                    title: d,
                    disabled: e.disabled || f
                }, o.createElement(G.CellWrap, {
                    className: ve.twoColors
                }, b(n, u), b(r, p))) : null;

                function b(e, t) {
                    return o.createElement("span", {
                        className: ve.colorPicker
                    }, o.createElement(A, {
                        color: e,
                        disabled: g,
                        noAlpha: t
                    }))
                }
            }
            var be = n(18356),
                ye = n(80346);

            function we(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            checked: n,
                            value: r,
                            unitOptionsValue: i,
                            disabled: s,
                            visible: d
                        },
                        min: p,
                        max: m,
                        step: h,
                        title: f,
                        unit: g,
                        unitOptions: b,
                        type: y
                    },
                    offset: w
                } = e, [E] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !0
                }), [C] = (0, a.useDefinitionProperty)({
                    property: s,
                    defaultValue: !1
                }), [S] = (0, a.useDefinitionProperty)({
                    property: d,
                    defaultValue: !0
                }), x = (0, $.useWatchedValueReadonly)({
                    watchedValue: p,
                    defaultValue: void 0
                }), P = (0, $.useWatchedValueReadonly)({
                    watchedValue: m,
                    defaultValue: void 0
                }), V = (0, $.useWatchedValueReadonly)({
                    watchedValue: h,
                    defaultValue: void 0
                }), N = (0, $.useWatchedValueReadonly)({
                    watchedValue: g,
                    defaultValue: void 0
                }), M = (0, o.useContext)(be.ControlCustomWidthContext), z = e.disabled || !E;
                return S ? o.createElement(l.CommonSection, {
                    id: t,
                    offset: w,
                    checked: n,
                    title: f,
                    disabled: e.disabled || C
                }, o.createElement(G.CellWrap, null, o.createElement(X, null, o.createElement(D, {
                    className: c(ye.input, M[t] && ye[M[t]]),
                    property: r,
                    min: x,
                    max: P,
                    step: V,
                    disabled: z,
                    mode: J[y],
                    name: "number-input",
                    "data-name": t
                }), i && o.createElement(ie, {
                    id: (0, u.createDomId)(t, "unit-options-dropdown"),
                    "data-name": "unit-options-dropdown",
                    className: ye.dropdown,
                    menuClassName: ye.dropdownMenu,
                    disabled: z,
                    property: i,
                    options: (0, v.ensureDefined)(b)
                })), o.createElement("span", {
                    className: ye.unit
                }, N))) : null
            }

            function Ee(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            checked: n,
                            disabled: r,
                            visible: i
                        },
                        childrenDefinitions: s,
                        title: c
                    },
                    offset: d
                } = e, [u] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !0
                }), [p] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !1
                }), [m] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !0
                }), h = e.disabled || !u;
                return m ? o.createElement(o.Fragment, null, o.createElement(l.CommonSection, {
                    id: t,
                    offset: d,
                    checked: n,
                    title: c,
                    disabled: e.disabled || p
                }), s.map(e => o.createElement(tn, {
                    key: e.id,
                    disabled: h,
                    definition: e,
                    offset: !0
                }))) : null
            }
            var Ce = n(32668);

            function Se(e) {
                const {
                    property: t
                } = e, [n, r] = (0, a.useDefinitionProperty)({
                    property: t
                });
                return o.createElement(Ce.FontSizeSelect, { ...e,
                    fontSize: n,
                    fontSizeChange: r,
                    "data-name": "font-size-select"
                })
            }
            var De = n(72571),
                xe = n(56994);

            function Pe(e) {
                const {
                    className: t,
                    checked: n,
                    icon: r,
                    disabled: i,
                    onClick: a
                } = e;
                return o.createElement("div", {
                    className: d()(t, xe.container, n && !i && xe.active, i && xe.disabled),
                    onClick: i ? void 0 : a,
                    "data-role": "button",
                    ...(0, H.filterDataProps)(e)
                }, o.createElement(De.Icon, {
                    className: xe.icon,
                    icon: r
                }))
            }

            function Ve(e) {
                const {
                    icon: t,
                    className: n,
                    property: r,
                    disabled: i
                } = e, [l, s] = (0,
                    a.useDefinitionProperty)({
                    property: r
                });
                return o.createElement(Pe, {
                    className: n,
                    icon: t,
                    checked: l,
                    onClick: function() {
                        s(!l)
                    },
                    disabled: i,
                    ...(0, H.filterDataProps)(e)
                })
            }
            var Ne = n(34735),
                Me = n(13143),
                ze = n(58213);

            function Te(e) {
                const {
                    property: t,
                    ...n
                } = e, [r, i] = (0, a.useDefinitionProperty)({
                    property: t
                }), l = (0, o.useCallback)(e => i(e.target.value), [i]);
                return o.createElement(ze.Textarea, { ...n,
                    value: r,
                    onChange: l
                })
            }
            var ke = n(26394),
                _e = n(77111),
                Be = n(45449);
            const Ie = e => ({
                    content: e.title,
                    title: e.title,
                    value: e.value,
                    id: e.id
                }),
                Re = e => ({
                    content: e.title,
                    title: e.title,
                    value: e.value,
                    id: e.id
                });

            function Le(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            color: n,
                            size: r,
                            checked: i,
                            disabled: s,
                            bold: c,
                            italic: d,
                            text: p,
                            alignmentHorizontal: m,
                            alignmentVertical: h,
                            orientation: f,
                            backgroundVisible: v,
                            backgroundColor: g,
                            borderVisible: b,
                            borderColor: y,
                            borderWidth: w,
                            wrap: E
                        },
                        title: C,
                        sizeItems: S,
                        alignmentTitle: D,
                        alignmentHorizontalItems: x,
                        alignmentVerticalItems: P,
                        orientationTitle: V,
                        orientationItems: N,
                        backgroundTitle: M,
                        borderTitle: z,
                        borderWidthItems: T,
                        wrapTitle: k
                    },
                    offset: _
                } = e, B = (0, o.useContext)(be.ControlCustomHeightContext), [I] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !0
                }), [R] = (0, a.useDefinitionProperty)({
                    property: s,
                    defaultValue: !1
                }), [L, W] = (0, a.useDefinitionProperty)({
                    property: h,
                    defaultValue: void 0
                }), [F, j] = (0, a.useDefinitionProperty)({
                    property: f,
                    defaultValue: "horizontal"
                }), [H, Z] = (0, a.useDefinitionProperty)({
                    property: m,
                    defaultValue: void 0
                }), [O] = (0, a.useDefinitionProperty)({
                    property: v,
                    defaultValue: !1
                }), [Q] = (0, a.useDefinitionProperty)({
                    property: b,
                    defaultValue: !1
                }), U = e.disabled || !I;
                return o.createElement(o.Fragment, null, function() {
                    if (C) return o.createElement(l.CommonSection, {
                        id: t,
                        offset: _,
                        checked: i,
                        title: C,
                        disabled: e.disabled || R
                    }, o.createElement(X, {
                        breakPoint: "Small"
                    }, q(), J()));
                    return o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2,
                        offset: _,
                        "data-section-name": t
                    }, q(), J()))
                }(), p && o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                    placement: "first",
                    colSpan: 2,
                    offset: _,
                    "data-section-name": t
                }, o.createElement(Te, {
                    className: Ne.InputClasses.FontSizeMedium,
                    rows: (Y = B[t], "big" === Y ? 9 : 5),
                    stretch: !0,
                    property: p,
                    disabled: U,
                    onFocus: function(e) {
                        e.target.select()
                    },
                    name: "text-input"
                }))), (m || h) && o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                    placement: "first",
                    verticalAlign: "adaptive",
                    offset: _,
                    "data-section-name": t
                }, o.createElement(G.CellWrap, null, D)), o.createElement(Me.PropertyTable.Cell, {
                    placement: "last",
                    verticalAlign: "adaptive",
                    "data-section-name": t
                }, o.createElement(X, {
                    breakPoint: "Small"
                }, void 0 !== L && void 0 !== P && o.createElement(oe.Select, {
                    id: (0, u.createDomId)(t, "alignment-vertical-select"),
                    "data-name": "alignment-vertical-select",
                    className: Be.dropdown,
                    menuClassName: Be.dropdownMenu,
                    disabled: U,
                    value: L,
                    items: P.map(Ie),
                    onChange: W
                }), void 0 !== H && void 0 !== x && o.createElement(oe.Select, {
                    id: (0, u.createDomId)(t, "alignment-horizontal-select"),
                    "data-name": "alignment-horizontal-select",
                    className: Be.dropdown,
                    menuClassName: Be.dropdownMenu,
                    disabled: U,
                    value: H,
                    items: x.map(Ie),
                    onChange: Z
                })))), void 0 !== f && void 0 !== N && o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                    placement: "first",
                    verticalAlign: "adaptive",
                    offset: _,
                    "data-section-name": t
                }, o.createElement(G.CellWrap, null, V)), o.createElement(Me.PropertyTable.Cell, {
                    placement: "last",
                    verticalAlign: "adaptive",
                    "data-section-name": t
                }, o.createElement(X, {
                    breakPoint: "Small"
                }, o.createElement(oe.Select, {
                    id: (0, u.createDomId)(t, "orientation-select"),
                    "data-name": "orientation-select",
                    className: Be.dropdown,
                    menuClassName: Be.dropdownMenu,
                    disabled: U,
                    value: F,
                    items: N.map(Re),
                    onChange: j
                })))), $(M, v, g, !!v && !O), $(z, b, y, !!b && !Q, w, T), E && o.createElement(l.CommonSection, {
                    id: t + "Wrap",
                    offset: _,
                    checked: E,
                    title: k,
                    disabled: e.disabled || R
                }));
                var Y;

                function K(e, t, n) {
                    return e ? o.createElement(Ve, {
                        className: Be.fontStyleButton,
                        icon: t,
                        property: e,
                        disabled: U,
                        "data-name": n
                    }) : null
                }

                function q() {
                    return o.createElement(o.Fragment, null, n && o.createElement("div", {
                        className: Be.colorPicker
                    }, o.createElement(A, {
                        color: n,
                        disabled: U
                    })), r && S && o.createElement(Se, {
                        id: (0, u.createDomId)(t, "font-size-select"),
                        property: r,
                        fontSizes: S,
                        disabled: U
                    }))
                }

                function J() {
                    return o.createElement(o.Fragment, null, K(c, ke, "toggle-bold"), K(d, _e, "toggle-italic"))
                }

                function $(e, n, r, i, a, s) {
                    return r || n ? o.createElement(l.CommonSection, {
                        id: t + "ColorSelect",
                        offset: _,
                        checked: n,
                        title: e,
                        disabled: U
                    }, r && o.createElement(A, {
                        color: r,
                        thickness: a,
                        thicknessItems: s,
                        disabled: U || i
                    })) : null
                }
            }
            var Ae = n(51285);

            function We(e) {
                const {
                    definition: {
                        properties: {
                            x: t,
                            y: n,
                            disabled: r
                        },
                        id: i,
                        minX: a,
                        maxX: l,
                        stepX: s,
                        minY: c,
                        maxY: d,
                        stepY: u,
                        title: p,
                        typeX: m,
                        typeY: h
                    },
                    offset: f
                } = e, v = r && r.value() || e.disabled, g = (0, $.useWatchedValueReadonly)({
                    watchedValue: a,
                    defaultValue: void 0
                }), b = (0, $.useWatchedValueReadonly)({
                    watchedValue: l,
                    defaultValue: void 0
                }), y = (0, $.useWatchedValueReadonly)({
                    watchedValue: s,
                    defaultValue: void 0
                }), w = (0, $.useWatchedValueReadonly)({
                    watchedValue: c,
                    defaultValue: void 0
                }), E = (0, $.useWatchedValueReadonly)({
                    watchedValue: d,
                    defaultValue: void 0
                }), C = (0, $.useWatchedValueReadonly)({
                    watchedValue: u,
                    defaultValue: void 0
                });
                return o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                    verticalAlign: "adaptive",
                    placement: "first",
                    offset: f,
                    "data-section-name": i
                }, o.createElement("span", {
                    className: Ae.coordinates
                }, p)), (t || n) && o.createElement(Me.PropertyTable.Cell, {
                    placement: "last",
                    offset: f,
                    "data-section-name": i
                }, o.createElement(X, {
                    breakPoint: "Medium"
                }, n && o.createElement(D, {
                    className: Ae.input,
                    property: n,
                    min: w,
                    max: E,
                    step: C,
                    disabled: v,
                    name: "y-input",
                    mode: void 0 !== h ? J[h] : "integer"
                }), t && o.createElement(D, {
                    className: Ae.input,
                    property: t,
                    min: g,
                    max: b,
                    step: y,
                    disabled: v,
                    name: "x-input",
                    mode: void 0 !== m ? J[m] : "integer"
                }))))
            }
            var Fe = n(89477);

            function je(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            checked: n,
                            option: r,
                            disabled: i,
                            visible: s
                        },
                        title: c,
                        options: p
                    },
                    offset: m
                } = e, [h] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !0
                }), [f] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !1
                }), [v] = (0, a.useDefinitionProperty)({
                    property: s,
                    defaultValue: !0
                }), g = (0, o.useContext)(be.ControlCustomWidthContext), b = e.disabled || !h;
                return v ? o.createElement(l.CommonSection, {
                    id: t,
                    offset: m,
                    checked: n,
                    title: c,
                    disabled: e.disabled || f
                }, o.createElement(G.CellWrap, null, o.createElement(ie, {
                    id: (0, u.createDomId)(t, "options-dropdown"),
                    "data-name": "options-dropdown",
                    className: d()(Fe.dropdown, g[t] && Fe[g[t]]),
                    menuClassName: d()(Fe.dropdownMenu, g[t] && Fe[g[t]]),
                    disabled: b || f,
                    property: r,
                    options: p
                }))) : null
            }
            var He = n(53898);
            var Ze = n(34581),
                Oe = n(65830);
            class Qe extends o.PureComponent {
                constructor(e) {
                    super(e), this._container = null, this._pointer = null, this._rafPosition = null, this._rafDragStop = null, this._refContainer = e => {
                        this._container = e
                    }, this._refPointer = e => {
                        this._pointer = e
                    }, this._handlePosition = e => {
                        null !== this._rafPosition || this.props.disabled || (this._rafPosition = requestAnimationFrame(() => {
                            const {
                                from: t,
                                to: n,
                                min: o,
                                max: r
                            } = this.props, i = this._getNewPosition(e), a = 1 === this._detectPointerMode(e), l = a ? (0, E.clamp)(i, o, n) : t, s = a ? n : (0, E.clamp)(i, t, r);
                            l <= s && this._handleChange(l, s), this._rafPosition = null
                        }))
                    }, this._handleDragStop = () => {
                        null !== this._rafDragStop || this.props.disabled || (this._rafDragStop = requestAnimationFrame(() => {
                            this.setState({
                                pointerDragMode: 0
                            }), this._rafDragStop = null, this.props.onCommit()
                        }))
                    }, this._onSliderClick = e => {
                        S.CheckMobile.any() || (this._handlePosition(e.nativeEvent), this._dragSubscribe())
                    }, this._mouseUp = e => {
                        this._dragUnsubscribe(), this._handlePosition(e), this._handleDragStop()
                    }, this._mouseMove = e => {
                        this._handlePosition(e)
                    }, this._onTouchStart = e => {
                        this._handlePosition(e.nativeEvent.touches[0])
                    }, this._handleTouch = e => {
                        this._handlePosition(e.nativeEvent.touches[0])
                    }, this._handleTouchEnd = () => {
                        this._handleDragStop()
                    }, this.state = {
                        pointerDragMode: 0
                    }
                }
                componentWillUnmount() {
                    null !== this._rafPosition && (cancelAnimationFrame(this._rafPosition), this._rafPosition = null), null !== this._rafDragStop && (cancelAnimationFrame(this._rafDragStop), this._rafDragStop = null), this._dragUnsubscribe()
                }
                render() {
                    const {
                        className: e,
                        disabled: t,
                        from: n,
                        to: r,
                        min: i,
                        max: a
                    } = this.props, {
                        pointerDragMode: l
                    } = this.state, s = 0 !== l, d = a - i, u = 0 === d ? i : (n - i) / d, p = 0 === d ? a : (r - i) / d, m = (0, Ze.isRtl)() ? "right" : "left";
                    return o.createElement("div", {
                        className: c(e, Oe.range, t && Oe.disabled)
                    }, o.createElement("div", {
                        className: Oe.rangeSlider,
                        ref: this._refContainer,
                        onMouseDown: this._onSliderClick,
                        onTouchStart: this._onTouchStart,
                        onTouchMove: this._handleTouch,
                        onTouchEnd: this._handleTouchEnd
                    }, o.createElement("div", {
                        className: Oe.rangeSliderMiddleWrap
                    }, o.createElement("div", {
                        className: c(Oe.rangeSliderMiddle, s && Oe.dragged),
                        style: {
                            [m]: 100 * u + "%",
                            width: 100 * (p - u) + "%"
                        }
                    })), o.createElement("div", {
                        className: Oe.rangePointerWrap
                    }, o.createElement("div", {
                        className: c(Oe.pointer, s && Oe.dragged),
                        style: {
                            [m]: 100 * u + "%"
                        },
                        ref: this._refPointer
                    })), o.createElement("div", {
                        className: Oe.rangePointerWrap
                    }, o.createElement("div", {
                        className: c(Oe.pointer, s && Oe.dragged),
                        style: {
                            [m]: 100 * p + "%"
                        }
                    }))))
                }
                _dragSubscribe() {
                    const e = (0, v.ensureNotNull)(this._container).ownerDocument;
                    e && (e.addEventListener("mouseup", this._mouseUp), e.addEventListener("mousemove", this._mouseMove))
                }
                _dragUnsubscribe() {
                    const e = (0, v.ensureNotNull)(this._container).ownerDocument;
                    e && (e.removeEventListener("mousemove", this._mouseMove),
                        e.removeEventListener("mouseup", this._mouseUp))
                }
                _getNewPosition(e) {
                    const {
                        min: t,
                        max: n
                    } = this.props, o = n - t, r = (0, v.ensureNotNull)(this._container), i = (0, v.ensureNotNull)(this._pointer), a = r.getBoundingClientRect(), l = i.offsetWidth;
                    let s = e.clientX - l / 2 - a.left;
                    return (0, Ze.isRtl)() && (s = a.width - s - l), (0, E.clamp)(s / (a.width - l), 0, 1) * o + t
                }
                _detectPointerMode(e) {
                    const {
                        from: t,
                        to: n
                    } = this.props, {
                        pointerDragMode: o
                    } = this.state;
                    if (0 !== o) return o;
                    const r = this._getNewPosition(e),
                        i = Math.abs(t - r),
                        a = Math.abs(n - r),
                        l = i === a ? r < t ? 1 : 2 : i < a ? 1 : 2;
                    return this.setState({
                        pointerDragMode: l
                    }), l
                }
                _handleChange(e, t) {
                    const {
                        from: n,
                        to: o,
                        onChange: r
                    } = this.props;
                    e === n && t === o || r(e, t)
                }
            }
            var Ue = n(30052),
                Ye = n(94245);

            function Ke(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            checked: n,
                            disabled: r,
                            from: i,
                            to: s
                        },
                        title: c,
                        max: u,
                        min: p
                    },
                    offset: m,
                    disabled: h
                } = e, [f] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !0
                }), [v] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !1
                }), y = (0, $.useWatchedValueReadonly)({
                    watchedValue: p,
                    defaultValue: void 0
                }), w = (0, $.useWatchedValueReadonly)({
                    watchedValue: u,
                    defaultValue: void 0
                }), [E, C] = (0, a.useDefinitionProperty)({
                    property: i
                }), [S, D] = (0, a.useDefinitionProperty)({
                    property: s
                }), P = g(E) || g(S), V = b(P ? "mixed" : E, (function(e) {
                    if (C(e), g(k)) {
                        const e = w || 100;
                        _(e), D(e)
                    }
                })), [N, M, z] = V, T = b(P ? "mixed" : S, (function(e) {
                    if (D(e), g(N)) {
                        const e = y || 0;
                        M(e), C(e)
                    }
                })), [k, _, B] = T, I = g(N) || g(k), R = h || g(f) || !f, L = {
                    flushed: !1
                };
                return o.createElement(l.CommonSection, {
                    id: t,
                    offset: m,
                    checked: n,
                    title: c,
                    disabled: h || v
                }, o.createElement(G.CellWrap, {
                    className: Ye.range
                }, function() {
                    if (!y || !w) return null;
                    return o.createElement(Ue.MatchMedia, {
                        rule: "screen and (max-width: 460px)"
                    }, e => o.createElement(X, {
                        breakPoint: "Medium"
                    }, o.createElement(o.Fragment, null, o.createElement("span", {
                        className: Ye.valueInput
                    }, o.createElement(x, {
                        className: Ye.input,
                        sharedBuffer: V,
                        min: y,
                        max: g(k) ? w : k,
                        step: 1,
                        disabled: R,
                        name: "from-input",
                        mode: "integer",
                        defaultValue: y
                    }), e ? o.createElement("span", {
                        className: Ye.rangeSlider
                    }, "—") : o.createElement(Qe, {
                        className: d()(Ye.rangeSlider, I && Ye.rangeSlider_mixed),
                        from: I ? y : N,
                        to: I ? w : k,
                        min: y,
                        max: w,
                        onChange: A,
                        onCommit: W,
                        disabled: R
                    }))), o.createElement(o.Fragment, null, o.createElement("span", {
                        className: Ye.valueInput
                    }, o.createElement(x, {
                        className: Ye.input,
                        sharedBuffer: T,
                        min: g(N) ? y : N,
                        max: w,
                        step: 1,
                        disabled: R,
                        name: "to-input",
                        mode: "integer",
                        defaultValue: w
                    })))))
                }()));

                function A(e, t) {
                    M(Math.round(e)), _(Math.round(t))
                }

                function W() {
                    L.flushed || (z(), B(), L.flushed = !0)
                }
            }
            var Ge = n(52830),
                qe = n(76882),
                Xe = n(67474);

            function Je(e) {
                const {
                    definitions: t,
                    name: n,
                    offset: r
                } = e;
                return o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                    className: d()(Xe.cell, Xe.fragmentCell),
                    offset: r,
                    placement: "first",
                    verticalAlign: "adaptive",
                    colSpan: 2,
                    "data-section-name": n,
                    checkableTitle: !0
                }, t.map(e => o.createElement("div", {
                    className: Xe.item,
                    key: e.id,
                    "data-section-name": e.id
                }, o.createElement(et, {
                    definition: e
                })))))
            }

            function $e(e) {
                const {
                    definition: t,
                    offset: n
                } = e;
                return o.createElement(Me.PropertyTable.Row, null, o.createElement(Me.PropertyTable.Cell, {
                    className: Xe.cell,
                    offset: n,
                    placement: "first",
                    verticalAlign: "adaptive",
                    colSpan: 2,
                    checkableTitle: !0
                }, o.createElement(et, {
                    definition: t
                })))
            }

            function et(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            disabled: n,
                            checked: r,
                            color: i,
                            level: l,
                            width: s,
                            style: c
                        },
                        title: p,
                        widthValues: h,
                        styleValues: f
                    }
                } = e, [v] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !0
                }), [g] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !1
                }), b = g || !v;
                return o.createElement(o.Fragment, null, o.createElement(qe.CheckableTitle, {
                    name: "is-enabled-" + t,
                    className: d()(p && Xe.withTitle),
                    title: p && o.createElement("span", {
                        className: Xe.title
                    }, p),
                    property: r,
                    disabled: g
                }), l && o.createElement(D, {
                    className: d()(Xe.input, Xe.control),
                    property: l,
                    disabled: b
                }), i && o.createElement(A, {
                    className: Xe.control,
                    disabled: b,
                    color: i,
                    thickness: s,
                    thicknessItems: h
                }), c && o.createElement(m, {
                    id: (0, u.createDomId)(t, "leveled-line-style-select"),
                    className: Xe.control,
                    property: c,
                    disabled: b,
                    allowedLineStyles: f
                }))
            }
            var tt = n(33126);

            function nt(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            option1: n,
                            option2: r,
                            checked: i,
                            disabled: s
                        },
                        title: c,
                        optionsItems1: d,
                        optionsItems2: p
                    },
                    offset: m
                } = e, [h] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: !0
                }), [f] = (0, a.useDefinitionProperty)({
                    property: s,
                    defaultValue: !1
                }), v = e.disabled || !h;
                return o.createElement(l.CommonSection, {
                    id: t,
                    offset: m,
                    checked: i,
                    title: c,
                    disabled: e.disabled || f
                }, o.createElement(X, {
                    className: tt.twoOptions
                }, o.createElement(ie, {
                    id: (0, u.createDomId)(t, "two-options-dropdown-1"),
                    "data-name": "two-options-dropdown-1",
                    className: tt.dropdown,
                    menuClassName: tt.menu,
                    property: n,
                    disabled: v,
                    options: d
                }), o.createElement(ie, {
                    id: (0, u.createDomId)(t, "two-options-dropdown-2"),
                    "data-name": "two-options-dropdown-2",
                    className: tt.dropdown,
                    menuClassName: tt.menu,
                    property: r,
                    disabled: v,
                    options: p
                })))
            }
            var ot = n(34453),
                rt = n(29148);

            function it(e) {
                const {
                    source: t,
                    inputs: n,
                    model: r,
                    inputsTabProperty: i
                } = e.definition;
                return o.createElement(ot.InputsTabContent, {
                    className: rt.withoutPadding,
                    property: i,
                    model: r,
                    study: t,
                    inputs: n
                })
            }
            var at = n(2946),
                lt = n(70122),
                st = n(74140),
                ct = n(40681);

            function dt(e) {
                const {
                    tab: t,
                    icon: n,
                    isActive: r,
                    onTabClick: i
                } = e;
                return o.createElement("div", {
                    className: d()(ct.wrapper, r && ct.isActive),
                    onClick: function() {
                        i(t)
                    }
                }, o.createElement(De.Icon, {
                    icon: n
                }))
            }
            var ut = n(88436);

            function pt(e) {
                const {
                    activeTab: t,
                    emojis: n,
                    onTabClick: r
                } = e;
                return o.createElement("div", {
                    className: ut.wrapper
                }, n.map(({
                    title: e,
                    icon: n
                }) => o.createElement(dt, {
                    key: e,
                    tab: e,
                    icon: n,
                    isActive: t === e,
                    onTabClick: r
                })))
            }
            var mt = n(83199),
                ht = n(16859);

            function ft(e) {
                const {
                    title: t
                } = e;
                return o.createElement("div", {
                    className: ht.wrapper
                }, t)
            }
            var vt = n(34240),
                gt = n(99339);
            const bt = 34;

            function yt(e) {
                const {
                    className: t,
                    emoji: n,
                    size: r = bt,
                    onClick: i
                } = e, a = (0, vt.getTwemojiUrl)(n, "png");
                return o.createElement("div", {
                    className: d()(gt.wrapper, t),
                    style: {
                        width: r,
                        height: r
                    },
                    onClick: function() {
                        i(n)
                    }
                }, o.createElement("img", {
                    className: gt.emoji,
                    src: a,
                    decoding: "async",
                    width: "24",
                    height: "24",
                    alt: "",
                    draggable: !1,
                    onContextMenu: function(e) {
                        e.preventDefault()
                    }
                }))
            }
            var wt = n(39897);
            const Et = o.memo(e => {
                const {
                    emojis: t,
                    itemSize: n,
                    onEmojiClick: r
                } = e;
                return o.createElement("div", {
                    className: wt.wrapper
                }, t.map(e => o.createElement(yt, {
                    key: e,
                    className: wt.emojiItem,
                    emoji: e,
                    size: n,
                    onClick: r
                })))
            });
            var Ct = n(40976),
                St = n(83341);
            const Dt = o.createContext(null);

            function xt(e) {
                const {
                    listRef: t,
                    emojiGroups: n,
                    emojiSize: r,
                    onSelect: i,
                    onContentRendered: a
                } = e;
                (0, o.useEffect)(() => {
                    var e;
                    return null === (e = t.current) || void 0 === e ? void 0 : e.resetAfterIndex(0, !0)
                }, [n]);
                const l = (0, o.useCallback)(e => "title" === n[e].type ? 30 : 38, [n]),
                    s = (0, o.useCallback)(({
                        visibleStartIndex: e
                    }) => {
                        const {
                            relatedTitle: t
                        } = n[e];
                        a(t)
                    }, [n, a]);
                return o.createElement(Dt.Provider, {
                    value: (0, o.useMemo)(() => ({
                        size: r,
                        onSelect: i
                    }), [r, i])
                }, o.createElement(mt.VariableSizeList, {
                    className: St.list,
                    ref: t,
                    width: "100%",
                    height: Math.min(330, window.innerHeight - 60),
                    itemData: n,
                    itemCount: n.length,
                    children: Pt,
                    onItemsRendered: s,
                    itemSize: l
                }))
            }
            const Pt = o.memo(e => {
                const {
                    style: t,
                    index: n,
                    data: r
                } = e, i = r[n], {
                    size: a,
                    onSelect: l
                } = (0, Ct.useEnsuredContext)(Dt);
                return "title" === i.type ? o.createElement("div", {
                    style: t
                }, o.createElement(ft, {
                    title: i.relatedTitle
                })) : o.createElement("div", {
                    style: t
                }, o.createElement(Et, {
                    emojis: i.content,
                    itemSize: a,
                    onEmojiClick: l
                }))
            });
            var Vt = n(70358);

            function Nt(e) {
                var t;
                const {
                    className: n,
                    emojis: r,
                    onSelect: i
                } = e, a = (0, o.useRef)(null), [l, s] = (0, o.useState)(0), c = (0, o.useMemo)(() => function(e, t) {
                    if (0 === t) return [];
                    const n = [];
                    return e.forEach(({
                        title: e,
                        emojis: o
                    }) => {
                        n.push({
                            type: "title",
                            relatedTitle: e,
                            content: [e]
                        });
                        let r = [];
                        for (const i of o) r.length < t ? r.push(i) : (n.push({
                            type: "emojiRow",
                            relatedTitle: e,
                            content: r
                        }), r = [i]);
                        r.length && n.push({
                            type: "emojiRow",
                            relatedTitle: e,
                            content: r
                        })
                    }), n
                }(r, l), [r, l]), u = (0, st.useResizeObserver)((function(e) {
                    const [t] = e, {
                        width: n
                    } = t.contentRect, o = Math.floor((n - 12) / 38);
                    s(o)
                })), [p, m] = (0, o.useState)((null === (t = c[0]) || void 0 === t ? void 0 : t.relatedTitle) || "");
                return o.createElement("div", {
                    className: d()(Vt.wrapper, n)
                }, o.createElement(pt, {
                    emojis: r,
                    activeTab: p,
                    onTabClick: function(e) {
                        ! function(e) {
                            var t;
                            null === (t = a.current) || void 0 === t || t.scrollToItem(e, "start"), requestAnimationFrame(() => {
                                var t;
                                return null === (t = a.current) || void 0 === t ? void 0 : t.scrollToItem(e, "start")
                            })
                        }(function(e) {
                            return c.findIndex(({
                                relatedTitle: t,
                                type: n
                            }) => "title" === n && t === e)
                        }(e))
                    }
                }), o.createElement("div", {
                    ref: u
                }, o.createElement(xt, {
                    listRef: a,
                    emojiGroups: c,
                    emojiSize: 38,
                    onSelect: i,
                    onContentRendered: m
                })))
            }
            var Mt = n(16875),
                zt = n(1279),
                Tt = n(65532),
                kt = n(49188),
                _t = n(66499),
                Bt = n(39466),
                It = n(80583),
                Rt = n(92154),
                Lt = n(69463);
            const At = [{
                title: (0, W.t)("recently used", {
                    context: "emoji_group"
                }),
                emojis: [],
                icon: Mt
            }, {
                title: (0, W.t)("smiles & people", {
                    context: "emoji_group"
                }),
                emojis: ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "☺️", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗", "🤔", "🤭", "🤫", "🤥", "😶", "😐", "😑", "😬", "🙄", "😯", "😦", "😧", "😮", "😲", "🥱", "😴", "🤤", "😪", "😵", "🤐", "🥴", "🤢", "🤮", "🤧", "😷", "🤒", "🤕", "🤑", "🤠", "😈", "👿", "👹", "👺", "🤡", "💩", "👻", "💀", "☠️", "👽", "👾", "🤖", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾", "👋", "🤚", "🖐", "✋", "🖖", "👌", "🤏", "✌️", "🤞", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏", "✍️", "💅", "🤳", "💪", "🦾", "🦵", "🦿", "🦶", "👂", "🦻", "👃", "🧠", "🦷", "🦴", "👀", "👁", "👅", "👄", "💋", "🩸", "👶", "🧒", "👦", "👧", "🧑", "👱", "👨", "🧔", "👨‍🦰", "👨‍🦱", "👨‍🦳", "👨‍🦲", "👩", "👩‍🦰", "🧑‍🦰", "👩‍🦱", "🧑‍🦱", "👩‍🦳", "🧑‍🦳", "👩‍🦲", "🧑‍🦲", "👱‍♀️", "👱‍♂️", "🧓", "👴", "👵", "🙍", "🙍‍♂️", "🙍‍♀️", "🙎", "🙎‍♂️", "🙎‍♀️", "🙅", "🙅‍♂️", "🙅‍♀️", "🙆", "🙆‍♂️", "🙆‍♀️", "💁", "💁‍♂️", "💁‍♀️", "🙋", "🙋‍♂️", "🙋‍♀️", "🧏", "🧏‍♂️", "🧏‍♀️", "🙇", "🙇‍♂️", "🙇‍♀️", "🤦", "🤦‍♂️", "🤦‍♀️", "🤷", "🤷‍♂️", "🤷‍♀️", "🧑‍⚕️", "👨‍⚕️", "👩‍⚕️", "🧑‍🎓", "👨‍🎓", "👩‍🎓", "🧑‍🏫", "👨‍🏫", "👩‍🏫", "🧑‍⚖️", "👨‍⚖️", "👩‍⚖️", "🧑‍🌾", "👨‍🌾", "👩‍🌾", "🧑‍🍳", "👨‍🍳", "👩‍🍳", "🧑‍🔧", "👨‍🔧", "👩‍🔧", "🧑‍🏭", "👨‍🏭", "👩‍🏭", "🧑‍💼", "👨‍💼", "👩‍💼", "🧑‍🔬", "👨‍🔬", "👩‍🔬", "🧑‍💻", "👨‍💻", "👩‍💻", "🧑‍🎤", "👨‍🎤", "👩‍🎤", "🧑‍🎨", "👨‍🎨", "👩‍🎨", "🧑‍✈️", "👨‍✈️", "👩‍✈️", "🧑‍🚀", "👨‍🚀", "👩‍🚀", "🧑‍🚒", "👨‍🚒", "👩‍🚒", "👮", "👮‍♂️", "👮‍♀️", "🕵", "🕵️‍♂️", "🕵️‍♀️", "💂", "💂‍♂️", "💂‍♀️", "👷", "👷‍♂️", "👷‍♀️", "🤴", "👸", "👳", "👳‍♂️", "👳‍♀️", "👲", "🧕", "🤵", "👰", "🤰", "🤱", "👼", "🎅", "🤶", "🦸", "🦸‍♂️", "🦸‍♀️", "🦹", "🦹‍♂️", "🦹‍♀️", "🧙", "🧙‍♂️", "🧙‍♀️", "🧚", "🧚‍♂️", "🧚‍♀️", "🧛", "🧛‍♂️", "🧛‍♀️", "🧜", "🧜‍♂️", "🧜‍♀️", "🧝", "🧝‍♂️", "🧝‍♀️", "🧞", "🧞‍♂️", "🧞‍♀️", "🧟", "🧟‍♂️", "🧟‍♀️", "💆", "💆‍♂️", "💆‍♀️", "💇", "💇‍♂️", "💇‍♀️", "🚶", "🚶‍♂️", "🚶‍♀️", "🧍", "🧍‍♂️", "🧍‍♀️", "🧎", "🧎‍♂️", "🧎‍♀️", "🧑‍🦯", "👨‍🦯", "👩‍🦯", "🧑‍🦼", "👨‍🦼", "👩‍🦼", "🧑‍🦽", "👨‍🦽", "👩‍🦽", "🏃", "🏃‍♂️", "🏃‍♀️", "💃", "🕺", "🕴", "👯", "👯‍♂️", "👯‍♀️", "🧖", "🧖‍♂️", "🧖‍♀️", "🧑‍🤝‍🧑", "👭", "👫", "👬", "💏", "👨‍❤️‍💋‍👨", "👩‍❤️‍💋‍👩", "💑", "👨‍❤️‍👨", "👩‍❤️‍👩", "👪", "👨‍👩‍👦", "👨‍👩‍👧", "👨‍👩‍👧‍👦", "👨‍👩‍👦‍👦", "👨‍👩‍👧‍👧", "👨‍👨‍👦", "👨‍👨‍👧", "👨‍👨‍👧‍👦", "👨‍👨‍👦‍👦", "👨‍👨‍👧‍👧", "👩‍👩‍👦", "👩‍👩‍👧", "👩‍👩‍👧‍👦", "👩‍👩‍👦‍👦", "👩‍👩‍👧‍👧", "👨‍👦", "👨‍👦‍👦", "👨‍👧", "👨‍👧‍👦", "👨‍👧‍👧", "👩‍👦", "👩‍👦‍👦", "👩‍👧", "👩‍👧‍👦", "👩‍👧‍👧", "🗣", "👤", "👥", "👣"],
                icon: zt
            }, {
                title: (0, W.t)("animals & nature", {
                    context: "emoji_group"
                }),
                emojis: ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐨", "🐯", "🦁", "🐮", "🐷", "🐽", "🐸", "🐵", "🙈", "🙉", "🙊", "🐒", "🐔", "🐧", "🐦", "🐤", "🐣", "🐥", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🐛", "🦋", "🐌", "🐞", "🐜", "🦟", "🦗", "🕷", "🕸", "🦂", "🐢", "🐍", "🦎", "🦖", "🦕", "🐙", "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳", "🐋", "🦈", "🐊", "🐅", "🐆", "🦓", "🦍", "🦧", "🐘", "🦛", "🦏", "🐪", "🐫", "🦒", "🦘", "🐃", "🐂", "🐄", "🐎", "🐖", "🐏", "🐑", "🦙", "🐐", "🦌", "🐕", "🐩", "🦮", "🐕‍🦺", "🐈", "🐓", "🦃", "🦚", "🦜", "🦢", "🦩", "🕊", "🐇", "🦝", "🦨", "🦡", "🦦", "🦥", "🐁", "🐀", "🐿", "🦔", "🐾", "🐉", "🐲", "🌵", "🎄", "🌲", "🌳", "🌴", "🌱", "🌿", "☘️", "🍀", "🎍", "🎋", "🍃", "🍂", "🍁", "🍄", "🐚", "🌾", "💐", "🌷", "🌹", "🥀", "🌺", "🌸", "🌼", "🌻", "🌞", "🌝", "🌛", "🌜", "🌚", "🌕", "🌖", "🌗", "🌘", "🌑", "🌒", "🌓", "🌔", "🌙", "🌎", "🌍", "🌏", "🪐", "💫", "⭐️", "🌟", "✨", "⚡️", "☄️", "💥", "🔥", "🌪", "🌈", "☀️", "🌤", "⛅️", "🌥", "☁️", "🌦", "🌧", "⛈", "🌩", "🌨", "❄️", "☃️", "⛄️", "🌬", "💨", "💧", "💦", "☔️", "🌊", "🌫"],
                icon: Tt
            }, {
                title: (0, W.t)("food & drink", {
                    context: "emoji_group"
                }),
                emojis: ["🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🍆", "🥑", "🥦", "🥬", "🥒", "🌶", "🌽", "🥕", "🧄", "🧅", "🥔", "🍠", "🥐", "🥯", "🍞", "🥖", "🥨", "🧀", "🥚", "🍳", "🧈", "🥞", "🧇", "🥓", "🥩", "🍗", "🍖", "🌭", "🍔", "🍟", "🍕", "🥪", "🥙", "🧆", "🌮", "🌯", "🥗", "🥘", "🥫", "🍝", "🍜", "🍲", "🍛", "🍣", "🍱", "🥟", "🦪", "🍤", "🍙", "🍚", "🍘", "🍥", "🥠", "🥮", "🍢", "🍡", "🍧", "🍨", "🍦", "🥧", "🧁", "🍰", "🎂", "🍮", "🍭", "🍬", "🍫", "🍿", "🍩", "🍪", "🌰", "🥜", "🍯", "🥛", "🍼", "☕️", "🍵", "🧃", "🥤", "🍶", "🍺", "🍻", "🥂", "🍷", "🥃", "🍸", "🍹", "🧉", "🍾", "🧊", "🥄", "🍴", "🍽", "🥣", "🥡", "🥢", "🧂"],
                icon: kt
            }, {
                title: (0, W.t)("activity", {
                    context: "emoji_group"
                }),
                emojis: ["⚽️", "🏀", "🏈", "⚾️", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🥅", "⛳️", "🪁", "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛷", "⛸", "🥌", "🎿", "⛷", "🏂", "🪂", "🏋️", "🏋️‍♂️", "🏋️‍♀️", "🤼", "🤼‍♂️", "🤼‍♀️", "🤸‍♀️", "🤸", "🤸‍♂️", "⛹️", "⛹️‍♂️", "⛹️‍♀️", "🤺", "🤾", "🤾‍♂️", "🤾‍♀️", "🏌️", "🏌️‍♂️", "🏌️‍♀️", "🏇", "🧘", "🧘‍♂️", "🧘‍♀️", "🏄", "🏄‍♂️", "🏄‍♀️", "🏊", "🏊‍♂️", "🏊‍♀️", "🤽", "🤽‍♂️", "🤽‍♀️", "🚣", "🚣‍♂️", "🚣‍♀️", "🧗", "🧗‍♂️", "🧗‍♀️", "🚵", "🚵‍♂️", "🚵‍♀️", "🚴", "🚴‍♂️", "🚴‍♀️", "🏆", "🥇", "🥈", "🥉", "🏅", "🎖", "🏵", "🎗", "🎫", "🎟", "🎪", "🤹", "🤹‍♂️", "🤹‍♀️", "🎭", "🎨", "🎬", "🎤", "🎧", "🎼", "🎹", "🥁", "🎷", "🎺", "🎸", "🪕", "🎻", "🎲", "🎯", "🎳", "🎮", "🎰", "🧩"],
                icon: _t
            }, {
                title: (0, W.t)("travel & places", {
                    context: "emoji_group"
                }),
                emojis: ["🚗", "🚕", "🚙", "🚌", "🚎", "🏎", "🚓", "🚑", "🚒", "🚐", "🚚", "🚛", "🚜", "🦯", "🦽", "🦼", "🛴", "🚲", "🛵", "🏍", "🛺", "🚨", "🚔", "🚍", "🚘", "🚖", "🚡", "🚠", "🚟", "🚃", "🚋", "🚞", "🚝", "🚄", "🚅", "🚈", "🚂", "🚆", "🚇", "🚊", "🚉", "✈️", "🛫", "🛬", "🛩", "💺", "🛰", "🚀", "🛸", "🚁", "🛶", "⛵️", "🚤", "🛥", "🛳", "⛴", "🚢", "⚓️", "⛽️", "🚧", "🚦", "🚥", "🚏", "🗺", "🗿", "🗽", "🗼", "🏰", "🏯", "🏟", "🎡", "🎢", "🎠", "⛲️", "⛱", "🏖", "🏝", "🏜", "🌋", "⛰", "🏔", "🗻", "🏕", "⛺️", "🏠", "🏡", "🏘", "🏚", "🏗", "🏭", "🏢", "🏬", "🏣", "🏤", "🏥", "🏦", "🏨", "🏪", "🏫", "🏩", "💒", "🏛", "⛪️", "🕌", "🕍", "🛕", "🕋", "⛩", "🛤", "🛣", "🗾", "🎑", "🏞", "🌅", "🌄", "🌠", "🎇", "🎆", "🌇", "🌆", "🏙", "🌃", "🌌", "🌉", "🌁"],
                icon: Bt
            }, {
                title: (0, W.t)("objects", {
                    context: "emoji_group"
                }),
                emojis: ["⌚️", "📱", "📲", "💻", "⌨️", "🖥", "🖨", "🖱", "🖲", "🕹", "🗜", "💽", "💾", "💿", "📀", "📼", "📷", "📸", "📹", "🎥", "📽", "🎞", "📞", "☎️", "📟", "📠", "📺", "📻", "🎙", "🎚", "🎛", "🧭", "⏱", "⏲", "⏰", "🕰", "⌛️", "⏳", "📡", "🔋", "🔌", "💡", "🔦", "🕯", "🪔", "🧯", "🛢", "💸", "💵", "💴", "💶", "💷", "💰", "💳", "💎", "⚖️", "🧰", "🔧", "🔨", "⚒", "🛠", "⛏", "🔩", "⚙️", "🧱", "⛓", "🧲", "🔫", "💣", "🧨", "🪓", "🔪", "🗡", "⚔️", "🛡", "🚬", "⚰️", "⚱️", "🏺", "🔮", "📿", "🧿", "💈", "⚗️", "🔭", "🔬", "🕳", "🩹", "🩺", "💊", "💉", "🧬", "🦠", "🧫", "🧪", "🌡", "🧹", "🧺", "🧻", "🚽", "🚰", "🚿", "🛁", "🛀", "🧼", "🪒", "🧽", "🧴", "🛎", "🔑", "🗝", "🚪", "🪑", "🛋", "🛏", "🛌", "🧸", "🖼", "🛍", "🛒", "🎁", "🎈", "🎏", "🎀", "🎊", "🎉", "🎎", "🏮", "🎐", "🧧", "✉️", "📩", "📨", "📧", "💌", "📥", "📤", "📦", "🏷", "📪", "📫", "📬", "📭", "📮", "📯", "📜", "📃", "📄", "📑", "🧾", "📊", "📈", "📉", "🗒", "🗓", "📆", "📅", "🗑", "📇", "🗃", "🗳", "🗄", "📋", "📁", "📂", "🗂", "🗞", "📰", "📓", "📔", "📒", "📕", "📗", "📘", "📙", "📚", "📖", "🔖", "🧷", "🔗", "📎", "🖇", "📐", "📏", "🧮", "📌", "📍", "✂️", "🖊", "🖋", "✒️", "🖌", "🖍", "📝", "✏️", "🔍", "🔎", "🔏", "🔐", "🔒", "🔓", "🧳", "🌂", "☂️", "🧵", "🧶", "👓", "🕶", "🥽", "🥼", "🦺", "👔", "👕", "👖", "🧣", "🧤", "🧥", "🧦", "👗", "👘", "🥻", "🩱", "🩲", "🩳", "👙", "👚", "👛", "👜", "👝", "🎒", "👞", "👟", "🥾", "🥿", "👠", "👡", "🩰", "👢", "👑", "👒", "🎩", "🎓", "🧢", "⛑", "💄", "💍", "💼"],
                icon: It
            }, {
                title: (0, W.t)("symbols", {
                    context: "emoji_group"
                }),
                emojis: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "☮️", "✝️", "☪️", "🕉", "☸️", "✡️", "🔯", "🕎", "☯️", "☦️", "🛐", "⛎", "♈️", "♉️", "♊️", "♋️", "♌️", "♍️", "♎️", "♏️", "♐️", "♑️", "♒️", "♓️", "🆔", "⚛️", "🉑", "☢️", "☣️", "📴", "📳", "🈶", "🈚️", "🈸", "🈺", "🈷️", "✴️", "🆚", "💮", "🉐", "㊙️", "㊗️", "🈴", "🈵", "🈹", "🈲", "🅰️", "🅱️", "🆎", "🆑", "🅾️", "🆘", "❌", "⭕️", "🛑", "⛔️", "📛", "🚫", "💯", "💢", "♨️", "🚷", "🚯", "🚳", "🚱", "🔞", "📵", "🚭", "❗️", "❕", "❓", "❔", "‼️", "⁉️", "🔅", "🔆", "〽️", "⚠️", "🚸", "🔱", "⚜️", "🔰", "♻️", "✅", "🈯️", "💹", "❇️", "✳️", "❎", "🌐", "💠", "Ⓜ️", "🌀", "💤", "🏧", "🚾", "♿️", "🅿️", "🈳", "🈂️", "🛂", "🛃", "🛄", "🛅", "🚹", "🚺", "🚼", "🚻", "🚮", "🎦", "📶", "🈁", "🔣", "ℹ️", "🔤", "🔡", "🔠", "🆖", "🆗", "🆙", "🆒", "🆕", "🆓", "0️⃣", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟", "🔢", "#️⃣", "*️⃣", "⏏️", "▶️", "⏸", "⏯", "⏹", "⏺", "⏭", "⏮", "⏩", "⏪", "⏫", "⏬", "◀️", "🔼", "🔽", "➡️", "⬅️", "⬆️", "⬇️", "↗️", "↘️", "↙️", "↖️", "↕️", "↔️", "↪️", "↩️", "⤴️", "⤵️", "🔀", "🔁", "🔂", "🔄", "🔃", "🎵", "🎶", "➕", "➖", "➗", "✖️", "♾", "💲", "💱", "™️", "©️", "®️", "〰️", "➰", "➿", "🔚", "🔙", "🔛", "🔝", "🔜", "✔️", "☑️", "🔘", "🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "⚫️", "⚪️", "🟤", "🔺", "🔻", "🔸", "🔹", "🔶", "🔷", "🔳", "🔲", "▪️", "▫️", "◾️", "◽️", "◼️", "◻️", "🟥", "🟧", "🟨", "🟩", "🟦", "🟪", "⬛️", "⬜️", "🟫", "🔈", "🔇", "🔉", "🔊", "🔔", "🔕", "📣", "📢", "👁‍🗨", "💬", "💭", "🗯", "♠️", "♣️", "♥️", "♦️", "🃏", "🎴", "🀄️", "🕐", "🕑", "🕒", "🕓", "🕔", "🕕", "🕖", "🕗", "🕘", "🕙", "🕚", "🕛", "🕜", "🕝", "🕞", "🕟", "🕠", "🕡", "🕢", "🕣", "🕤", "🕥", "🕦", "🕧"],
                icon: Rt
            }, {
                title: (0, W.t)("flags", {
                    context: "emoji_group"
                }),
                emojis: ["🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏴‍☠️", "🇦🇫", "🇦🇽", "🇦🇱", "🇩🇿", "🇦🇸", "🇦🇩", "🇦🇴", "🇦🇮", "🇦🇶", "🇦🇬", "🇦🇷", "🇦🇲", "🇦🇼", "🇦🇺", "🇦🇹", "🇦🇿", "🇧🇸", "🇧🇭", "🇧🇩", "🇧🇧", "🇧🇾", "🇧🇪", "🇧🇿", "🇧🇯", "🇧🇲", "🇧🇹", "🇧🇴", "🇧🇦", "🇧🇼", "🇧🇷", "🇮🇴", "🇻🇬", "🇧🇳", "🇧🇬", "🇧🇫", "🇧🇮", "🇰🇭", "🇨🇲", "🇨🇦", "🇮🇨", "🇨🇻", "🇧🇶", "🇰🇾", "🇨🇫", "🇹🇩", "🇨🇱", "🇨🇳", "🇨🇽", "🇨🇨", "🇨🇴", "🇰🇲", "🇨🇬", "🇨🇩", "🇨🇰", "🇨🇷", "🇨🇮", "🇭🇷", "🇨🇺", "🇨🇼", "🇨🇾", "🇨🇿", "🇩🇰", "🇩🇯", "🇩🇲", "🇩🇴", "🇪🇨", "🇪🇬", "🇸🇻", "🇬🇶", "🇪🇷", "🇪🇪", "🇪🇹", "🇪🇺", "🇫🇰", "🇫🇴", "🇫🇯", "🇫🇮", "🇫🇷", "🇬🇫", "🇵🇫", "🇹🇫", "🇬🇦", "🇬🇲", "🇬🇪", "🇩🇪", "🇬🇭", "🇬🇮", "🇬🇷", "🇬🇱", "🇬🇩", "🇬🇵", "🇬🇺", "🇬🇹", "🇬🇬", "🇬🇳", "🇬🇼", "🇬🇾", "🇭🇹", "🇭🇳", "🇭🇰", "🇭🇺", "🇮🇸", "🇮🇳", "🇮🇩", "🇮🇷", "🇮🇶", "🇮🇪", "🇮🇲", "🇮🇱", "🇮🇹", "🇯🇲", "🇯🇵", "🎌", "🇯🇪", "🇯🇴", "🇰🇿", "🇰🇪", "🇰🇮", "🇽🇰", "🇰🇼", "🇰🇬", "🇱🇦", "🇱🇻", "🇱🇧", "🇱🇸", "🇱🇷", "🇱🇾", "🇱🇮", "🇱🇹", "🇱🇺", "🇲🇴", "🇲🇰", "🇲🇬", "🇲🇼", "🇲🇾", "🇲🇻", "🇲🇱", "🇲🇹", "🇲🇭", "🇲🇶", "🇲🇷", "🇲🇺", "🇾🇹", "🇲🇽", "🇫🇲", "🇲🇩", "🇲🇨", "🇲🇳", "🇲🇪", "🇲🇸", "🇲🇦", "🇲🇿", "🇲🇲", "🇳🇦", "🇳🇷", "🇳🇵", "🇳🇱", "🇳🇨", "🇳🇿", "🇳🇮", "🇳🇪", "🇳🇬", "🇳🇺", "🇳🇫", "🇰🇵", "🇲🇵", "🇳🇴", "🇴🇲", "🇵🇰", "🇵🇼", "🇵🇸", "🇵🇦", "🇵🇬", "🇵🇾", "🇵🇪", "🇵🇭", "🇵🇳", "🇵🇱", "🇵🇹", "🇵🇷", "🇶🇦", "🇷🇪", "🇷🇴", "🇷🇺", "🇷🇼", "🇼🇸", "🇸🇲", "🇸🇦", "🇸🇳", "🇷🇸", "🇸🇨", "🇸🇱", "🇸🇬", "🇸🇽", "🇸🇰", "🇸🇮", "🇬🇸", "🇸🇧", "🇸🇴", "🇿🇦", "🇰🇷", "🇸🇸", "🇪🇸", "🇱🇰", "🇧🇱", "🇸🇭", "🇰🇳", "🇱🇨", "🇵🇲", "🇻🇨", "🇸🇩", "🇸🇷", "🇸🇿", "🇸🇪", "🇨🇭", "🇸🇾", "🇹🇼", "🇹🇯", "🇹🇿", "🇹🇭", "🇹🇱", "🇹🇬", "🇹🇰", "🇹🇴", "🇹🇹", "🇹🇳", "🇹🇷", "🇹🇲", "🇹🇨", "🇹🇻", "🇻🇮", "🇺🇬", "🇺🇦", "🇦🇪", "🇬🇧", "🏴󠁧󠁢󠁥󠁮󠁧󠁿", "🏴󠁧󠁢󠁳󠁣󠁴󠁿", "🏴󠁧󠁢󠁷󠁬󠁳󠁿", "🇺🇳", "🇺🇸", "🇺🇾", "🇺🇿", "🇻🇺", "🇻🇦", "🇻🇪", "🇻🇳", "🇼🇫", "🇪🇭", "🇾🇪", "🇿🇲", "🇿🇼"],
                icon: Lt
            }];
            var Wt = n(44377),
                Ft = n(63694),
                jt = n(59339),
                Ht = n(10618),
                Zt = n(93173);
            var Ot = n(85673),
                Qt = n(96038),
                Ut = n(90896);

            function Yt(e) {
                const {
                    children: t,
                    highlight: n,
                    disabled: r,
                    reference: i
                } = e, a = n ? "primary" : "default";
                return o.createElement("div", {
                    ref: i,
                    className: d()(Ut.wrapper, Ut["intent-" + a], Ut["border-thin"], Ut["size-medium"], n && Ut.highlight, n && Ut.focused, r && Ut.disabled),
                    "data-role": "button"
                }, o.createElement("div", {
                    className: d()(Ut.childrenContainer, r && Ut.disabled)
                }, t), n && o.createElement("span", {
                    className: Ut.shadow
                }))
            }
            var Kt = n(95076);
            const Gt = () => null,
                qt = (0, Zt.mergeThemes)(Ht.DEFAULT_MENU_THEME, {
                    menuBox: Kt.menuBox
                });

            function Xt(e) {
                const {
                    value: t,
                    disabled: n,
                    onSelect: r
                } = e, i = (0, o.useRef)(null), {
                    current: a
                } = (0, o.useRef)(lt.getJSON("RecentlyUsedEmojis", [t])), [l, s] = (0, o.useState)(a), [c, d] = (0, o.useState)(!1), u = (0, o.useCallback)(() => d(!1), []);
                var p;
                p = u, (0, o.useEffect)(() => (document.addEventListener("scroll", p), () => {
                    document.removeEventListener("scroll", p)
                }), [p]);
                const m = (0, o.useCallback)(e => {
                        const t = Array.from(new Set([e, ...l])).slice(0, 18);
                        lt.setJSON("RecentlyUsedEmojis", t), s(t), r(e), u()
                    }, [l, r]),
                    h = (f = l, (0, o.useMemo)(() => (At[0].emojis = f, [...At]), [f]));
                var f;
                return o.createElement(o.Fragment, null, o.createElement(Yt, {
                    reference: i,
                    highlight: c,
                    disabled: n
                }, o.createElement(yt, {
                    emoji: t,
                    onClick: function() {
                        n || d(!0)
                    }
                })), o.createElement(Ue.MatchMedia, {
                    rule: Qt.DialogBreakpoints.TabletSmall
                }, e => c && o.createElement(Ft.DrawerManager, null, e ? o.createElement(jt.Drawer, {
                    className: Kt.drawer,
                    position: "Bottom",
                    onClose: u
                }, o.createElement(Nt, {
                    emojis: h,
                    onSelect: m
                })) : o.createElement(Wt.PopupMenu, {
                    theme: qt,
                    isOpened: !0,
                    position: (0, Ot.getPopupPositioner)(i.current, {
                        horizontalDropDirection: Ot.HorizontalDropDirection.FromLeftToRight,
                        horizontalAttachEdge: Ot.HorizontalAttachEdge.Left
                    }),
                    onClickOutside: u,
                    onClose: Gt
                }, o.createElement(Nt, {
                    className: Kt.desktopSize,
                    emojis: h,
                    onSelect: m
                })))))
            }
            var Jt = n(9688);

            function $t(e) {
                const {
                    definition: {
                        title: t,
                        properties: n
                    }
                } = e, {
                    checked: r,
                    emoji: i,
                    backgroundColor: l
                } = n, [s, c] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !1
                }), [d, u] = (0, a.useDefinitionProperty)({
                    property: i,
                    defaultValue: "🙂"
                }), [p, m] = (0, a.useDefinitionProperty)({
                    property: l,
                    defaultValue: ue.colorsPalette["color-tv-blue-a600"]
                });
                return o.createElement("div", {
                    className: Jt.wrapper
                }, o.createElement(at.Checkbox, {
                    className: Jt.checkbox,
                    label: t,
                    checked: s,
                    onChange: function() {
                        c(!s)
                    }
                }), o.createElement(Xt, {
                    value: d,
                    disabled: !s,
                    onSelect: u
                }), o.createElement(R.ColorSelect, {
                    className: Jt.colorSelect,
                    disabled: !s,
                    color: p,
                    onColorChange: m
                }))
            }

            function en(e) {
                const {
                    definition: {
                        id: t,
                        properties: {
                            disabled: n,
                            visible: r
                        },
                        childrenDefinitions: i,
                        title: s
                    },
                    offset: c
                } = e, [d] = (0, a.useDefinitionProperty)({
                    property: n,
                    defaultValue: !1
                }), [u] = (0, a.useDefinitionProperty)({
                    property: r,
                    defaultValue: !0
                }), p = e.disabled;
                return u ? o.createElement(o.Fragment, null, s && o.createElement(l.CommonSection, {
                    id: t,
                    offset: c,
                    title: s,
                    disabled: e.disabled || d
                }), i.map(e => o.createElement(tn, {
                    key: e.id,
                    disabled: p,
                    definition: e,
                    offset: Boolean(s)
                }))) : null
            }

            function tn(e) {
                const {
                    definition: t,
                    offset: n,
                    disabled: a
                } = e;
                if (function(e) {
                        (0, o.useEffect)(() => {
                            if (void 0 === e) return;
                            const t = { ...e.properties
                            };
                            return Object.entries(t).forEach(([n, o]) => {
                                void 0 !== o && o.subscribe(t, () => He.logger.logNormal(`Property "${n}" in definition "${e.id}" was updated to value "${o.value()}"`))
                            }), () => {
                                Object.entries(t).forEach(([, e]) => {
                                    void 0 !== e && e.unsubscribeAll(t)
                                })
                            }
                        }, [e])
                    }((0, r.isPropertyDefinitionsGroup)(t) ? void 0 : t), (0, r.isPropertyDefinitionsGroup)(t)) return o.createElement(nn, {
                    definition: t,
                    offset: n,
                    disabled: a
                });
                switch (t.propType) {
                    case "line":
                        return o.createElement(te, { ...e,
                            definition: t
                        });
                    case "checkable":
                        return o.createElement(s, { ...e,
                            definition: t
                        });
                    case "color":
                        return o.createElement(ce, { ...e,
                            definition: t
                        });
                    case "transparency":
                        return o.createElement(fe, { ...e,
                            definition: t
                        });
                    case "twoColors":
                        return o.createElement(ge, { ...e,
                            definition: t
                        });
                    case "number":
                        return o.createElement(we, { ...e,
                            definition: t
                        });
                    case "symbol":
                        return o.createElement(i.SymbolInputsButton, { ...e,
                            definition: t
                        });
                    case "text":
                        return o.createElement(Le, { ...e,
                            definition: t
                        });
                    case "checkableSet":
                        return o.createElement(Ee, { ...e,
                            definition: t
                        });
                    case "set":
                        return o.createElement(en, { ...e,
                            definition: t
                        });
                    case "options":
                        return o.createElement(je, { ...e,
                            definition: t
                        });
                    case "range":
                        return o.createElement(Ke, { ...e,
                            definition: t
                        });
                    case "coordinates":
                        return o.createElement(We, { ...e,
                            definition: t
                        });
                    case "twoOptions":
                        return o.createElement(nt, { ...e,
                            definition: t
                        });
                    case "leveledLine":
                        return o.createElement($e, { ...e,
                            definition: t
                        });
                    case "emoji":
                        return o.createElement($t, { ...e,
                            definition: t
                        });
                    case "image":
                        return null;
                    case "studyInputs":
                        return o.createElement(it, { ...e,
                            definition: t
                        });
                    default:
                        return null
                }
            }

            function nn(e) {
                const {
                    definition: t
                } = e, n = (0, $.useWatchedValueReadonly)({
                    watchedValue: t.definitions
                });
                return (0, $.useWatchedValueReadonly)({
                    watchedValue: t.visible,
                    defaultValue: !0
                }) ? o.createElement(o.Fragment, null, t.title && o.createElement(Ge.GroupTitleSection, {
                    title: t.title,
                    name: t.id
                }), n && (i = n, i.reduce((e, t) => {
                    if ((0, r.isPropertyDefinitionsGroup)(t) || "leveledLine" !== t.propType) e.push(t);
                    else {
                        const n = e[e.length - 1];
                        Array.isArray(n) ? n.push(t) : e.push([t])
                    }
                    return e
                }, [])).map(n => Array.isArray(n) ? o.createElement(Je, {
                    key: n[0].id,
                    name: t.id,
                    definitions: n
                }) : o.createElement(tn, {
                    key: n.id,
                    ...e,
                    definition: n
                })), "general" === t.groupType && o.createElement(Me.PropertyTable.GroupSeparator, {
                    size: 1
                })) : null;
                var i
            }
        },
        99120: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlDisclosure: () => c
            });
            var o = n(59496),
                r = n(28606),
                i = n(53517),
                a = n(95426),
                l = n(79827),
                s = n(66230);
            const c = o.forwardRef((e, t) => {
                const {
                    id: n,
                    tabIndex: c,
                    disabled: d,
                    highlight: u,
                    intent: p,
                    children: m,
                    onClick: h,
                    onFocus: f,
                    onBlur: v,
                    listboxAria: g,
                    ...b
                } = e, y = (0, o.useRef)({
                    "aria-labelledby": n
                }), {
                    listboxId: w,
                    isOpened: E,
                    isFocused: C,
                    buttonTabIndex: S,
                    listboxTabIndex: D,
                    highlight: x,
                    intent: P,
                    onOpen: V,
                    close: N,
                    toggle: M,
                    buttonFocusBindings: z,
                    onButtonClick: T,
                    buttonRef: k,
                    listboxRef: _,
                    buttonAria: B
                } = (0, l.useControlDisclosure)({
                    id: n,
                    disabled: d,
                    buttonTabIndex: c,
                    intent: p,
                    highlight: u,
                    onFocus: f,
                    onBlur: v,
                    onClick: h
                }), I = (0, i.useKeyboardToggle)(M), R = (0, i.useKeyboardClose)(E, N), L = (0, i.useKeyboardActionHandler)([27], N, (0, o.useCallback)(() => E, [E])), A = (0, i.useKeyboardEventHandler)(I, R), W = (0, i.useKeyboardEventHandler)(L);
                return o.createElement(a.ControlDisclosureView, { ...b,
                    ...z,
                    ...B,
                    id: n,
                    role: "button",
                    tabIndex: S,
                    disabled: d,
                    isOpened: E,
                    isFocused: C,
                    ref: (0, r.useMergedRefs)([k, t]),
                    highlight: x,
                    intent: P,
                    onClose: N,
                    onOpen: V,
                    onClick: T,
                    onKeyDown: A,
                    listboxId: w,
                    listboxTabIndex: D,
                    listboxReference: _,
                    listboxAria: null != g ? g : y.current,
                    onListboxKeyDown: W
                }, m, o.createElement("span", {
                    className: s.invisibleFocusHandler,
                    tabIndex: 0,
                    "aria-hidden": !0,
                    onFocus: N
                }))
            });
            c.displayName = "ControlDisclosure"
        },
        63694: (e, t, n) => {
            "use strict";
            n.d(t, {
                DrawerManager: () => r,
                DrawerContext: () => i
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return o.createElement(i.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const i = o.createContext(null)
        },
        59339: (e, t, n) => {
            "use strict";
            n.d(t, {
                Drawer: () => m
            });
            var o = n(59496),
                r = n(88537),
                i = n(97754),
                a = n(59142),
                l = n(85089),
                s = n(8361),
                c = n(63694),
                d = n(1227),
                u = n(28466),
                p = n(66998);

            function m(e) {
                const {
                    position: t = "Bottom",
                    onClose: n,
                    children: m,
                    className: h,
                    theme: f = p
                } = e, v = (0, r.ensureNotNull)((0, o.useContext)(c.DrawerContext)), [g, b] = (0, o.useState)(0), y = (0, o.useRef)(null), w = (0, o.useContext)(u.CloseDelegateContext);
                return (0, o.useEffect)(() => {
                    const e = (0, r.ensureNotNull)(y.current);
                    return e.focus({
                        preventScroll: !0
                    }), w.subscribe(v, n), 0 === v.currentDrawer && (0, l.setFixedBodyState)(!0), d.CheckMobile.iOS() && (0, a.disableBodyScroll)(e), b(v.addDrawer()), () => {
                        w.unsubscribe(v, n);
                        const t = v.removeDrawer();
                        d.CheckMobile.iOS() && (0, a.enableBodyScroll)(e), 0 === t && (0, l.setFixedBodyState)(!1)
                    }
                }, []), o.createElement(s.Portal, null, o.createElement("div", {
                    className: i(p.wrap, p["position" + t])
                }, g === v.currentDrawer && o.createElement("div", {
                    className: p.backdrop,
                    onClick: n
                }), o.createElement("div", {
                    className: i(p.drawer, f.drawer, p["position" + t], h),
                    ref: y,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, m)))
            }
        },
        74140: (e, t, n) => {
            "use strict";
            n.d(t, {
                useResizeObserver: () => i
            });
            var o = n(59496),
                r = n(59255);

            function i(e, t = []) {
                const n = (0, o.useRef)(null),
                    i = (0, o.useRef)(null),
                    a = (0, o.useRef)(e);
                a.current = e;
                const l = (0, o.useCallback)(e => {
                    n.current = e, null !== i.current && (i.current.disconnect(), null !== e && i.current.observe(e))
                }, [n, i]);
                return (0, o.useEffect)(() => (i.current = new r.default((e, t) => {
                    a.current(e, t)
                }), n.current && l(n.current), () => {
                    var e;
                    null === (e = i.current) || void 0 === e || e.disconnect()
                }), [n, ...t]), l
            }
        },
        17850: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenuSeparator: () => l
            });
            var o = n(59496),
                r = n(97754),
                i = n.n(r),
                a = n(524);

            function l(e) {
                const {
                    size: t = "normal",
                    className: n
                } = e;
                return o.createElement("div", {
                    className: i()(a.separator, "small" === t && a.small, "normal" === t && a.normal, "large" === t && a.large, n)
                })
            }
        },
        72621: (e, t, n) => {
            "use strict";
            n.d(t, {
                RemoveButton: () => d
            });
            var o = n(25177),
                r = n(59496),
                i = n(97754),
                a = n(72571),
                l = n(72351),
                s = n(73432);
            const c = {
                remove: (0, o.t)("Remove")
            };

            function d(e) {
                const {
                    className: t,
                    isActive: n,
                    onClick: o,
                    onMouseDown: d,
                    title: u,
                    hidden: p,
                    "data-name": m = "remove-button",
                    ...h
                } = e;
                return r.createElement(a.Icon, { ...h,
                    "data-name": m,
                    className: i(s.button, "apply-common-tooltip", n && s.active, p && s.hidden, t),
                    icon: l,
                    onClick: o,
                    onMouseDown: d,
                    title: u || c.remove
                })
            }
        },
        93173: (e, t, n) => {
            "use strict";

            function o(e, t, n = {}) {
                const o = Object.assign({}, t);
                for (const r of Object.keys(t)) {
                    const i = n[r] || r;
                    i in e && (o[r] = [e[i], t[r]].join(" "))
                }
                return o
            }

            function r(e, t, n = {}) {
                return Object.assign({}, e, o(e, t, n))
            }
            n.d(t, {
                weakComposeClasses: () => o,
                mergeThemes: () => r
            })
        },
        98584: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fillRule="evenodd" clipRule="evenodd" d="M7.5 13a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM12 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM19 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0z"/></svg>'
        },
        72351: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"><path fill="currentColor" d="M9.707 9l4.647-4.646-.707-.708L9 8.293 4.354 3.646l-.708.708L8.293 9l-4.647 4.646.708.708L9 9.707l4.646 4.647.708-.707L9.707 9z"/></svg>'
        },
        87460: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path fill="currentColor" d="M4 13h5v1H4v-1zM12 13h5v1h-5v-1zM20 13h5v1h-5v-1z"/></svg>'
        },
        22931: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor"><circle cx="9" cy="14" r="1"/><circle cx="4" cy="14" r="1"/><circle cx="14" cy="14" r="1"/><circle cx="19" cy="14" r="1"/><circle cx="24" cy="14" r="1"/></svg>'
        },
        47044: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M5.5 7a.5.5 0 0 0 0 1h17a.5.5 0 0 0 0-1h-17Zm0 6a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3Zm7 0a.5.5 0 0 0 0 1h3a.5.5 0 0 0 0-1h-3Zm6.5.5c0-.28.22-.5.5-.5h3a.5.5 0 0 1 0 1h-3a.5.5 0 0 1-.5-.5ZM7 20a1 1 0 1 1-2 0 1 1 0 0 1 2 0Zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0Zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2Zm5-1a1 1 0 1 1-2 0 1 1 0 0 1 2 0Zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/></svg>'
        },
        47387: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path stroke="currentColor" d="M4 13.5h20"/></svg>'
        },
        25785: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M4.5 13.5H24m-19.5 0L8 17m-3.5-3.5L8 10"/></svg>'
        },
        66058: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8.5 13.5a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm0 0H24"/></svg>'
        },
        26394: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M14 21h-3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h3c2 0 4 1 4 3 0 1 0 2-1.5 3 1.5.5 2.5 2 2.5 4 0 2.75-2.638 4-5 4zM12 9l.004 3c.39.026.82 0 1.25 0C14.908 12 16 11.743 16 10.5c0-1.1-.996-1.5-2.5-1.5-.397 0-.927-.033-1.5 0zm0 5v5h1.5c1.5 0 3.5-.5 3.5-2.5S15 14 13.5 14c-.5 0-.895-.02-1.5 0z"/></svg>'
        },
        77111: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M12.143 20l1.714-12H12V7h5v1h-2.143l-1.714 12H15v1h-5v-1h2.143z"/></svg>'
        },
        66499: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M13.98 6.02L14.5 6c2.18 0 4.16.8 5.66 2.14l-5.66 5.65-2.31-2.3a8.43 8.43 0 0 0 1.55-3.64 14.01 14.01 0 0 0 .24-1.83zm-1.01.12a8.45 8.45 0 0 0-4.13 2l2.64 2.63a7.59 7.59 0 0 0 1.28-3.12c.12-.59.18-1.12.2-1.51zm-4.83 2.7a8.45 8.45 0 0 0-2 4.13c.39-.03.92-.1 1.51-.21a7.59 7.59 0 0 0 3.12-1.28L8.14 8.84zm-2.12 5.14a8.48 8.48 0 0 0 2.12 6.18l5.65-5.66-2.3-2.31a8.43 8.43 0 0 1-3.64 1.55 14.03 14.03 0 0 1-1.83.24zm2.82 6.88a8.46 8.46 0 0 0 5.13 2.12v-.07A8.95 8.95 0 0 1 16.3 17l-1.8-1.8-5.66 5.65zM14.97 23c2-.1 3.8-.9 5.19-2.13L17 17.72a7.94 7.94 0 0 0-2.04 5.27zm5.9-2.83a8.46 8.46 0 0 0 2.11-5.13h-.02a10.62 10.62 0 0 0-5.2 2l3.1 3.13zm2.12-6.13c-.1-2-.9-3.8-2.13-5.19l-5.65 5.66 1.83 1.83a11.6 11.6 0 0 1 5.95-2.3zM14.5 5A9.46 9.46 0 0 0 5 14.5c0 5.28 4.22 9.5 9.5 9.5s9.5-4.22 9.5-9.5S19.78 5 14.5 5z"/></svg>'
        },
        65532: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M4.54 3.2l.78-.59 5.49 4.5 1.43 1.07a5.28 5.28 0 0 1 2.19-2.3 9.19 9.19 0 0 1 1.88-.85h.04l.01-.01.14.48.42-.28v.01l.01.02a3.14 3.14 0 0 1 .16.26l.37.72c.2.45.4 1.02.5 1.64a2.13 2.13 0 0 1 1.89.46l.18.16.03.02.18.16c.22.16.42.27.81.25a5.9 5.9 0 0 0 2.2-.86l.66-.36.09.75a5.98 5.98 0 0 1-1.7 5.1 6.87 6.87 0 0 1-1.7 1.23 19.97 19.97 0 0 1 .48 2.48c.25 1.73.42 4.08.06 6.5A1.46 1.46 0 0 1 19.68 25h-7.71a1.5 1.5 0 0 1-1.4-2.06l1-2.47c-.18.02-.37.03-.58.03a3 3 0 0 1-1.53-.4 6.84 6.84 0 0 1-1.6.64c-1.08.27-2.55.29-3.72-.89a4.06 4.06 0 0 1-.96-3 5.1 5.1 0 0 1 2-3.74 98.5 98.5 0 0 0 2.7-2.24L4.55 3.2zM16.5 5.5l-.14-.48.35-.1.2.3-.41.28zm-7.87 6.06a57.48 57.48 0 0 1-2.19 1.82l.49.26c.65.37 1.48.9 1.97 1.56a5.78 5.78 0 0 1 1.14 4.07l.06.03c.19.1.49.2.9.2.68 0 .95-.11 1.03-.16v-.03l.97.19h-.5.5v.03a.75.75 0 0 1-.01.1.74.74 0 0 1-.09.21l-1.39 3.47a.5.5 0 0 0 .47.69h7.71c.24 0 .43-.17.47-.38a22 22 0 0 0-.06-6.22 24.4 24.4 0 0 0-.56-2.71 11.35 11.35 0 0 0-.94-1.52 7.1 7.1 0 0 0-2.31-2.22l-.62-.31.49-.5A3.03 3.03 0 0 0 17 8.6a1.2 1.2 0 0 0 .01-.1c0-.65-.22-1.33-.46-1.86-.1-.21-.18-.4-.26-.54a8.07 8.07 0 0 0-1.34.64c-.9.54-1.74 1.32-1.95 2.36v.03l-.02.03L12.5 9l.47.16v.02a2.97 2.97 0 0 1-.1.26 5.9 5.9 0 0 1-.31.62c-.27.46-.7 1.07-1.34 1.39-.63.31-1.38.3-1.9.23a5.83 5.83 0 0 1-.7-.12zm3.26-2.39L10.2 7.9l-.02-.01L6.3 4.7l2.57 5.88h.01c.14.04.34.08.57.11.47.06.97.05 1.34-.14.36-.18.68-.57.91-.99.08-.14.15-.27.2-.39zm8.32 4.68a5.47 5.47 0 0 0 1.37-1.02 4.88 4.88 0 0 0 1.46-3.53c-.8.39-1.41.58-1.92.61-.7.05-1.14-.18-1.49-.45a5.6 5.6 0 0 1-.22-.19l-.03-.03-.17-.13a1.4 1.4 0 0 0-.33-.22c-.18-.07-.44-.12-.93 0l-.1.4c-.1.3-.28.69-.58 1.09.87.59 1.6 1.46 2.14 2.2a14.92 14.92 0 0 1 .8 1.27zM9.05 19.19v-.09a4.78 4.78 0 0 0-.96-3.3 5.56 5.56 0 0 0-1.65-1.29c-.3-.17-.6-.3-.8-.4l-.05-.03a4.05 4.05 0 0 0-1.4 2.82 3.1 3.1 0 0 0 .66 2.25c.83.82 1.86.84 2.78.62a5.71 5.71 0 0 0 1.42-.58zm4.26-5.87c-.3.24-.74.54-1.18.66-.37.1-.81.1-1.12.08a6.95 6.95 0 0 1-.54-.06h-.05l.08-.5.08-.5.03.01a5.02 5.02 0 0 0 1.26 0c.24-.06.54-.25.83-.47a6.1 6.1 0 0 0 .42-.37l.02-.02.36.35.35.36h-.01l-.03.04a6.09 6.09 0 0 1-.5.42zM6 17h1v-1H6v1z"/></svg>'
        },
        69463: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M7.5 24v-5.5m0 0s2.7-1.1 4.5-1c2.1.12 2.9 1.88 5 2 1.8.1 4.5-1 4.5-1v-6m-14 6v-6m0 0v-6s2.7-1.1 4.5-1c2.1.12 2.9 1.88 5 2 1.8.1 4.5-1 4.5-1v6m-14 0s2.7-1.1 4.5-1c2.1.12 2.9 1.88 5 2 1.8.1 4.5-1 4.5-1"/></svg>'
        },
        49188: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M12.5 8h1.36l-.85-3.38.98-.24.9 3.62h7.64a1.34 1.34 0 0 1 .2.02c.13.02.31.07.5.16.18.09.38.24.53.46.15.24.24.52.24.86 0 .34-.09.62-.24.86a1.38 1.38 0 0 1-.79.56L22 24.54l-.03.46H6.5c-1 0-1.64-.68-1.99-1.23a4.4 4.4 0 0 1-.38-.78l-.01-.04c-.1-.03-.22-.07-.34-.13a1.36 1.36 0 0 1-.54-.46A1.51 1.51 0 0 1 3 21.5c0-.34.09-.62.24-.86.15-.22.35-.37.54-.46.1-.05.2-.09.28-.11a6.6 6.6 0 0 1 .96-2.34C5.92 16.35 7.56 15 10.5 15c.72 0 1.36.08 1.93.22l-.4-4.3a1.38 1.38 0 0 1-.8-.57A1.51 1.51 0 0 1 11 9.5c0-.34.09-.62.24-.86.15-.22.35-.37.54-.46a1.73 1.73 0 0 1 .7-.18h.02v.5V8zm.96 7.57a5.73 5.73 0 0 1 2.52 2.16 6.86 6.86 0 0 1 .95 2.34 1.38 1.38 0 0 1 .82.58c.16.23.25.51.25.85 0 .34-.09.62-.24.86-.15.22-.35.37-.54.46-.12.06-.24.1-.34.13l-.01.04a4.4 4.4 0 0 1-.54 1.01h4.7l.93-13h-8.91l.41 4.57zM14.5 9h8a.73.73 0 0 1 .28.07c.06.04.11.08.15.13.03.05.07.14.07.3 0 .16-.04.25-.07.3a.38.38 0 0 1-.15.13.73.73 0 0 1-.27.07H12.5a.73.73 0 0 1-.28-.07.38.38 0 0 1-.15-.13.52.52 0 0 1-.07-.3c0-.16.04-.25.07-.3.04-.05.09-.1.15-.13A.73.73 0 0 1 12.5 9h2.01zm1.4 11a5.8 5.8 0 0 0-.76-1.73C14.41 17.15 13.06 16 10.5 16c-2.56 0-3.91 1.15-4.64 2.27A5.86 5.86 0 0 0 5.1 20h10.78zM4.5 21a.72.72 0 0 0-.28.07.38.38 0 0 0-.15.13.52.52 0 0 0-.07.3c0 .16.04.25.07.3.04.05.09.1.15.13a.73.73 0 0 0 .27.07H16.5a.72.72 0 0 0 .28-.07.38.38 0 0 0 .15-.13.52.52 0 0 0 .07-.3.52.52 0 0 0-.07-.3.38.38 0 0 0-.15-.13.73.73 0 0 0-.27-.07H4.5zm.73 2l.13.23c.28.45.65.77 1.14.77h8c.5 0 .86-.32 1.14-.77.05-.07.1-.15.13-.23H5.23zM11 17v1h-1v-1h1zm-3 1h1v1H8v-1zm4 1v-1h1v1h-1z"/></svg>'
        },
        80583: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M9.5 21H9h.5zm8 0H17h.5zm-6-10H11v1h.5v-1zm4 1h.5v-1h-.5v1zm2 7.5h.5-.5zm.29-1.59A7.97 7.97 0 0 0 21 11.5h-1a6.97 6.97 0 0 1-2.79 5.59l.58.82zM21 11.5A7.5 7.5 0 0 0 13.5 4v1a6.5 6.5 0 0 1 6.5 6.5h1zM13.5 4A7.5 7.5 0 0 0 6 11.5h1A6.5 6.5 0 0 1 13.5 5V4zM6 11.5a7.98 7.98 0 0 0 3.21 6.41l.57-.82A6.98 6.98 0 0 1 7 11.5H6zM9 21a1 1 0 0 0 1 1v-1H9zm8 1a1 1 0 0 0 1-1h-1v1zm-6-.5V23h1v-1.5h-1zm0 1.5a1 1 0 0 0 1 1v-1h-1zm1 1h3v-1h-3v1zm3 0a1 1 0 0 0 1-1h-1v1zm1-1v-1.5h-1V23h1zm-3-11.5v6h1v-6h-1zM9.5 20h8v-1h-8v1zM9 17.5v2h1v-2H9zm0 2V21h1v-1.5H9zm9 1.5v-1.5h-1V21h1zm0-1.5v-2h-1v2h1zM9.5 18h4v-1h-4v1zm4 0h4v-1h-4v1zm-2-6h2v-1h-2v1zm2 0h2v-1h-2v1zM10 22h1.5v-1H10v1zm1.5 0h4v-1h-4v1zm4 0H17v-1h-1.5v1z"/></svg>'
        },
        16875: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M6 14.5C6 9.78 9.78 6 14.5 6c4.72 0 8.5 3.78 8.5 8.5 0 4.72-3.78 8.5-8.5 8.5A8.46 8.46 0 0 1 6 14.5zM14.5 5A9.46 9.46 0 0 0 5 14.5c0 5.28 4.22 9.5 9.5 9.5s9.5-4.22 9.5-9.5S19.78 5 14.5 5zM14 16V9h1v6h4v1h-5z"/></svg>'
        },
        1279: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M6 14.5C6 9.78 9.78 6 14.5 6c4.72 0 8.5 3.78 8.5 8.5 0 4.72-3.78 8.5-8.5 8.5A8.46 8.46 0 0 1 6 14.5zM14.5 5A9.46 9.46 0 0 0 5 14.5c0 5.28 4.22 9.5 9.5 9.5s9.5-4.22 9.5-9.5S19.78 5 14.5 5zM12 12a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm4 1a1 1 0 1 1 2 0 1 1 0 0 1-2 0zm-6 4l-.43.26v.01l.03.03a3.55 3.55 0 0 0 .3.4 5.7 5.7 0 0 0 9.22 0 5.42 5.42 0 0 0 .28-.4l.02-.03v-.01L19 17l-.43-.26v.02a2.45 2.45 0 0 1-.24.32c-.17.21-.43.5-.78.79a4.71 4.71 0 0 1-6.88-.8 4.32 4.32 0 0 1-.23-.31l-.01-.02L10 17z"/></svg>'
        },
        92154: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M5.6 15.43A6.19 6.19 0 0 1 14 6.36a6.19 6.19 0 0 1 8.4 9.08l-.03.02-7.3 7.31a1.5 1.5 0 0 1-2.13 0l-7.3-7.3-.03-.03m.71-.7v-.01a5.19 5.19 0 0 1 7.33-7.34v.01c.2.2.51.19.7 0a5.19 5.19 0 0 1 7.34 7.33l-.03.02-7.3 7.31a.5.5 0 0 1-.71 0l-7.3-7.3-.03-.02z"/></svg>'
        },
        39466: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M22.87 6.44c.09-.78-.53-1.4-1.3-1.31-1.43.15-3.43.48-5.42 1.2a11.8 11.8 0 0 0-5.23 3.44L9.86 11.9l6.24 6.24 2.13-1.06a11.8 11.8 0 0 0 3.44-5.23c.72-1.99 1.05-4 1.2-5.41zm-4.93 11.9l-1.72.86-.04.02h-.04l-2.2.67v.01a19.68 19.68 0 0 0-.13 3.33c.01.14.08.22.17.26.08.04.2.05.32-.03a18.83 18.83 0 0 0 2.79-2.26 8.18 8.18 0 0 0 .44-1.1c.16-.51.33-1.12.41-1.76zm-.44 3.16l.35.35-.01.02-.05.05a16.85 16.85 0 0 1-.83.76c-.54.47-1.3 1.08-2.1 1.61a1.3 1.3 0 0 1-2.05-.98 16.46 16.46 0 0 1 .09-3.08l-.16.05a1.5 1.5 0 0 1-1.53-.36l-3.13-3.13c-.4-.4-.54-1-.36-1.53l.05-.16-.36.04c-.7.06-1.62.11-2.54.06a1.3 1.3 0 0 1-1.13-.8c-.18-.42-.13-.94.17-1.35a87.55 87.55 0 0 1 2.15-2.8l.04-.04v-.02l.4.31-.22-.45.03-.01a5.93 5.93 0 0 1 .34-.16c.23-.1.55-.22.94-.35A9.77 9.77 0 0 1 10.26 9a12.9 12.9 0 0 1 5.55-3.61c2.09-.76 4.18-1.1 5.65-1.26 1.41-.15 2.56 1 2.4 2.41a24.04 24.04 0 0 1-1.25 5.65A12.9 12.9 0 0 1 19 17.74a9.77 9.77 0 0 1-.88 3.61 9.18 9.18 0 0 1-.16.34v.03h-.01l-.45-.22zm0 0l.45.22-.04.08-.06.05-.35-.35zm-11-11l-.4-.31.08-.09.1-.05.22.45zm3.16-.44a9.61 9.61 0 0 0-2.84.84l-.13.16a109.83 109.83 0 0 0-1.97 2.58.4.4 0 0 0-.06.38c.04.1.12.17.27.18a16.05 16.05 0 0 0 3.18-.15l.66-2.2.01-.03.02-.04.86-1.72zm5.4 8.45l-5.57-5.56-.51 1.7-.31.92a.5.5 0 0 0 .12.51l3.13 3.13a.5.5 0 0 0 .5.12l.92-.3h.02l1.7-.52zm-10.91.64l2-2 .7.7-2 2-.7-.7zm0 4l4-4 .7.7-4 4-.7-.7zm4 0l2-2 .7.7-2 2-.7-.7zM16 10.5a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0zM17.5 8a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z"/></svg>'
        }
    }
]);
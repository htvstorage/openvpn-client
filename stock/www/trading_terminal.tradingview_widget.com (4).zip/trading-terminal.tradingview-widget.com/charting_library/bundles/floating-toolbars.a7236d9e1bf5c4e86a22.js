(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2306, 3177], {
        66783: t => {
            "use strict";
            var e = Object.prototype.hasOwnProperty;

            function o(t, e) {
                return t === e ? 0 !== t || 0 !== e || 1 / t == 1 / e : t != t && e != e
            }
            t.exports = function(t, i) {
                if (o(t, i)) return !0;
                if ("object" != typeof t || null === t || "object" != typeof i || null === i) return !1;
                var n = Object.keys(t),
                    r = Object.keys(i);
                if (n.length !== r.length) return !1;
                for (var s = 0; s < n.length; s++)
                    if (!e.call(i, n[s]) || !o(t[n[s]], i[n[s]])) return !1;
                return !0
            }
        },
        62632: () => {},
        42024: () => {},
        6539: t => {
            t.exports = {
                button: "button-YKkCvwjV",
                content: "content-YKkCvwjV",
                "icon-only": "icon-only-YKkCvwjV",
                "color-brand": "color-brand-YKkCvwjV",
                "variant-primary": "variant-primary-YKkCvwjV",
                "variant-secondary": "variant-secondary-YKkCvwjV",
                "color-gray": "color-gray-YKkCvwjV",
                "color-green": "color-green-YKkCvwjV",
                "color-red": "color-red-YKkCvwjV",
                "size-xsmall": "size-xsmall-YKkCvwjV",
                "size-small": "size-small-YKkCvwjV",
                "size-medium": "size-medium-YKkCvwjV",
                "size-large": "size-large-YKkCvwjV",
                "size-xlarge": "size-xlarge-YKkCvwjV",
                "with-start-icon": "with-start-icon-YKkCvwjV",
                "with-end-icon": "with-end-icon-YKkCvwjV",
                "start-icon-wrap": "start-icon-wrap-YKkCvwjV",
                "end-icon-wrap": "end-icon-wrap-YKkCvwjV",
                animated: "animated-YKkCvwjV",
                stretch: "stretch-YKkCvwjV",
                grouped: "grouped-YKkCvwjV",
                "adjust-position": "adjust-position-YKkCvwjV",
                "first-row": "first-row-YKkCvwjV",
                "first-col": "first-col-YKkCvwjV",
                "no-corner-top-left": "no-corner-top-left-YKkCvwjV",
                "no-corner-top-right": "no-corner-top-right-YKkCvwjV",
                "no-corner-bottom-right": "no-corner-bottom-right-YKkCvwjV",
                "no-corner-bottom-left": "no-corner-bottom-left-YKkCvwjV"
            }
        },
        99376: () => {},
        24302: () => {},
        55576: t => {
            t.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        64547: t => {
            t.exports = {
                button: "button-SS83RYhy"
            }
        },
        71123: t => {
            t.exports = {
                button: "button-khcLBZEz",
                hover: "hover-khcLBZEz",
                arrow: "arrow-khcLBZEz",
                arrowWrap: "arrowWrap-khcLBZEz",
                newStyles: "newStyles-khcLBZEz",
                isOpened: "isOpened-khcLBZEz"
            }
        },
        69124: t => {
            t.exports = {
                wrap: "wrap-HhKLwxmq",
                icon: "icon-HhKLwxmq",
                colorBg: "colorBg-HhKLwxmq",
                color: "color-HhKLwxmq",
                multicolor: "multicolor-HhKLwxmq",
                white: "white-HhKLwxmq"
            }
        },
        88168: t => {
            t.exports = {
                button: "button-Ou6proUJ"
            }
        },
        2680: t => {
            t.exports = {
                item: "item-Fil3AvDD",
                withIcon: "withIcon-Fil3AvDD",
                icon: "icon-Fil3AvDD",
                labelRow: "labelRow-Fil3AvDD",
                multiWidth: "multiWidth-Fil3AvDD",
                buttonWrap: "buttonWrap-Fil3AvDD",
                buttonLabel: "buttonLabel-Fil3AvDD"
            }
        },
        10667: t => {
            t.exports = {
                container: "container-WiTVOllB",
                sectionTitle: "sectionTitle-WiTVOllB",
                separator: "separator-WiTVOllB",
                customButton: "customButton-WiTVOllB"
            }
        },
        99565: t => {
            t.exports = {
                container: "container-UpS01XRM",
                form: "form-UpS01XRM",
                swatch: "swatch-UpS01XRM",
                inputWrap: "inputWrap-UpS01XRM",
                inputHash: "inputHash-UpS01XRM",
                input: "input-UpS01XRM",
                buttonWrap: "buttonWrap-UpS01XRM",
                hueSaturationWrap: "hueSaturationWrap-UpS01XRM",
                saturation: "saturation-UpS01XRM",
                hue: "hue-UpS01XRM"
            }
        },
        24429: t => {
            t.exports = {
                hue: "hue-oQv2KoOx",
                pointer: "pointer-oQv2KoOx",
                pointerContainer: "pointerContainer-oQv2KoOx"
            }
        },
        15381: t => {
            t.exports = {
                opacity: "opacity-YL5Gjk00",
                opacitySlider: "opacitySlider-YL5Gjk00",
                opacitySliderGradient: "opacitySliderGradient-YL5Gjk00",
                pointer: "pointer-YL5Gjk00",
                dragged: "dragged-YL5Gjk00",
                opacityPointerWrap: "opacityPointerWrap-YL5Gjk00",
                opacityInputWrap: "opacityInputWrap-YL5Gjk00",
                opacityInput: "opacityInput-YL5Gjk00",
                opacityInputPercent: "opacityInputPercent-YL5Gjk00"
            }
        },
        88440: t => {
            t.exports = {
                saturation: "saturation-lJHGRPyu",
                pointer: "pointer-lJHGRPyu"
            }
        },
        24590: t => {
            t.exports = {
                swatches: "swatches-qgksmXjR",
                swatch: "swatch-qgksmXjR",
                hover: "hover-qgksmXjR",
                empty: "empty-qgksmXjR",
                white: "white-qgksmXjR",
                selected: "selected-qgksmXjR",
                contextItem: "contextItem-qgksmXjR"
            }
        },
        40367: t => {
            t.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        28599: (t, e, o) => {
            "use strict";
            o.d(e, {
                Button: () => f
            });
            var i = o(59496),
                n = o(97754),
                r = o(31774),
                s = o(72571),
                a = o(6539),
                l = o.n(a);

            function c(t) {
                const {
                    color: e = "brand",
                    size: o = "medium",
                    variant: i = "primary",
                    stretch: s = !1,
                    icon: a,
                    startIcon: c,
                    endIcon: d,
                    iconOnly: h = !1,
                    className: p,
                    isGrouped: u,
                    cellState: m,
                    disablePositionAdjustment: g = !1
                } = t, _ = function(t) {
                    let e = "";
                    return 0 !== t && (1 & t && (e = n(e, l()["no-corner-top-left"])), 2 & t && (e = n(e, l()["no-corner-top-right"])), 4 & t && (e = n(e, l()["no-corner-bottom-right"])), 8 & t && (e = n(e, l()["no-corner-bottom-left"]))), e
                }((0, r.getGroupCellRemoveRoundBorders)(m));
                return n(p, l().button, l()["size-" + o], l()["color-" + e], l()["variant-" + i], s && l().stretch, (a || c) && l()["with-start-icon"], d && l()["with-end-icon"], h && l()["icon-only"], _, u && l().grouped, u && !g && l()["adjust-position"], u && m.isTop && l()["first-row"], u && m.isLeft && l()["first-col"])
            }

            function d(t) {
                const {
                    size: e,
                    startIcon: o,
                    icon: n,
                    iconOnly: r,
                    children: a,
                    endIcon: c
                } = t, d = null != o ? o : n;
                return i.createElement(i.Fragment, null, d && "xsmall" !== e && i.createElement(s.Icon, {
                    icon: d,
                    className: l()["start-icon-wrap"]
                }), a && i.createElement("span", {
                    className: l().content
                }, a), c && !r && "xsmall" !== e && i.createElement(s.Icon, {
                    icon: c,
                    className: l()["end-icon-wrap"]
                }))
            }
            var h = o(80327),
                p = o(417);

            function u(t) {
                const {
                    className: e,
                    color: o,
                    variant: i,
                    size: n,
                    stretch: r,
                    animated: s,
                    icon: a,
                    iconOnly: l,
                    startIcon: c,
                    endIcon: d,
                    ...h
                } = t;
                return { ...h,
                    ...(0, p.filterDataProps)(t),
                    ...(0, p.filterAriaProps)(t)
                }
            }

            function m(t) {
                const {
                    reference: e,
                    ...o
                } = t, {
                    isGrouped: n,
                    cellState: r,
                    disablePositionAdjustment: s
                } = (0, i.useContext)(h.ControlGroupContext), a = c({ ...o,
                    isGrouped: n,
                    cellState: r,
                    disablePositionAdjustment: s
                });
                return i.createElement("button", { ...u(o),
                    className: a,
                    ref: e
                }, i.createElement(d, { ...o
                }))
            }

            function g(t = "default") {
                switch (t) {
                    case "default":
                        return "primary";
                    case "stroke":
                        return "secondary"
                }
            }

            function _(t = "primary") {
                switch (t) {
                    case "primary":
                        return "brand";
                    case "success":
                        return "green";
                    case "default":
                        return "gray";
                    case "danger":
                        return "red"
                }
            }

            function v(t = "m") {
                switch (t) {
                    case "s":
                        return "xsmall";
                    case "m":
                        return "small";
                    case "l":
                        return "large"
                }
            }

            function w(t) {
                const {
                    intent: e,
                    size: o,
                    appearance: i,
                    useFullWidth: n,
                    icon: r,
                    ...s
                } = t;
                return { ...s,
                    color: _(e),
                    size: v(o),
                    variant: g(i),
                    stretch: n,
                    startIcon: r
                }
            }

            function f(t) {
                return i.createElement(m, { ...w(t)
                })
            }
        },
        80327: (t, e, o) => {
            "use strict";
            o.d(e, {
                ControlGroupContext: () => i
            });
            const i = o(59496).createContext({
                isGrouped: !1,
                cellState: {
                    isTop: !0,
                    isRight: !0,
                    isBottom: !0,
                    isLeft: !0
                }
            })
        },
        31774: (t, e, o) => {
            "use strict";

            function i(t) {
                let e = 0;
                return t.isTop && t.isLeft || (e += 1), t.isTop && t.isRight || (e += 2), t.isBottom && t.isLeft || (e += 8), t.isBottom && t.isRight || (e += 4), e
            }
            o.d(e, {
                getGroupCellRemoveRoundBorders: () => i
            })
        },
        85673: (t, e, o) => {
            "use strict";
            o.d(e, {
                VerticalAttachEdge: () => i,
                HorizontalAttachEdge: () => n,
                VerticalDropDirection: () => r,
                HorizontalDropDirection: () => s,
                getPopupPositioner: () => c
            });
            var i, n, r, s, a = o(88537);
            ! function(t) {
                t[t.Top = 0] = "Top", t[t.Bottom = 1] = "Bottom"
            }(i || (i = {})),
            function(t) {
                t[t.Left = 0] = "Left", t[t.Right = 1] = "Right"
            }(n || (n = {})),
            function(t) {
                t[t.FromTopToBottom = 0] = "FromTopToBottom", t[t.FromBottomToTop = 1] = "FromBottomToTop"
            }(r || (r = {})),
            function(t) {
                t[t.FromLeftToRight = 0] = "FromLeftToRight", t[t.FromRightToLeft = 1] = "FromRightToLeft"
            }(s || (s = {}));
            const l = {
                verticalAttachEdge: i.Bottom,
                horizontalAttachEdge: n.Left,
                verticalDropDirection: r.FromTopToBottom,
                horizontalDropDirection: s.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function c(t, e) {
                return (o, c) => {
                    const d = (0, a.ensureNotNull)(t).getBoundingClientRect(),
                        {
                            verticalAttachEdge: h = l.verticalAttachEdge,
                            verticalDropDirection: p = l.verticalDropDirection,
                            horizontalAttachEdge: u = l.horizontalAttachEdge,
                            horizontalDropDirection: m = l.horizontalDropDirection,
                            horizontalMargin: g = l.horizontalMargin,
                            verticalMargin: _ = l.verticalMargin,
                            matchButtonAndListboxWidths: v = l.matchButtonAndListboxWidths
                        } = e,
                        w = h === i.Top ? -1 * _ : _,
                        f = u === n.Right ? d.right : d.left,
                        y = h === i.Top ? d.top : d.bottom,
                        b = {
                            x: f - (m === s.FromRightToLeft ? o : 0) + g,
                            y: y - (p === r.FromBottomToTop ? c : 0) + w
                        };
                    return v && (b.overrideWidth = d.width), b
                }
            }
        },
        75803: (t, e, o) => {
            "use strict";
            o.d(e, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => l,
                ToolWidgetButton: () => c
            });
            var i = o(59496),
                n = o(97754),
                r = o(72571),
                s = o(4257),
                a = o(55576);
            const l = a,
                c = i.forwardRef((t, e) => {
                    const {
                        icon: o,
                        isActive: l,
                        isOpened: c,
                        isDisabled: d,
                        isGrouped: h,
                        isHovered: p,
                        onClick: u,
                        text: m,
                        textBeforeIcon: g,
                        title: _,
                        theme: v = a,
                        className: w,
                        forceInteractive: f,
                        "data-name": y,
                        ...b
                    } = t, C = n(w, v.button, _ && "apply-common-tooltip", {
                        [v.isActive]: l,
                        [v.isOpened]: c,
                        [v.isInteractive]: (f || Boolean(u)) && !d,
                        [v.isDisabled]: d,
                        [v.isGrouped]: h,
                        [v.hover]: p,
                        [v.newStyles]: s.hasNewHeaderToolbarStyles
                    }), T = o && ("string" == typeof o ? i.createElement(r.Icon, {
                        className: v.icon,
                        icon: o
                    }) : i.cloneElement(o, {
                        className: n(v.icon, o.props.className)
                    }));
                    return i.createElement("div", { ...b,
                        ref: e,
                        "data-role": "button",
                        className: C,
                        onClick: d ? void 0 : u,
                        title: _,
                        "data-name": y
                    }, g && m && i.createElement("div", {
                        className: n("js-button-text", v.text)
                    }, m), T, !g && m && i.createElement("div", {
                        className: n("js-button-text", v.text)
                    }, m))
                })
        },
        5710: (t, e, o) => {
            "use strict";
            o.d(e, {
                ToolWidgetIconButton: () => a
            });
            var i = o(59496),
                n = o(97754),
                r = o(75803),
                s = o(64547);
            const a = i.forwardRef((t, e) => {
                const {
                    className: o,
                    id: a,
                    ...l
                } = t;
                return i.createElement(r.ToolWidgetButton, {
                    "data-name": a,
                    ...l,
                    ref: e,
                    className: n(o, s.button)
                })
            })
        },
        34816: (t, e, o) => {
            "use strict";
            o.d(e, {
                DEFAULT_TOOL_WIDGET_MENU_THEME: () => m,
                ToolWidgetMenu: () => g
            });
            var i = o(59496),
                n = o(97754),
                r = o(44377),
                s = o(15783),
                a = o(417),
                l = o(63694),
                c = o(59339),
                d = o(85673),
                h = o(30052),
                p = o(4257),
                u = o(71123);
            const m = u;
            class g extends i.PureComponent {
                constructor(t) {
                    super(t), this._wrapperRef = null, this._controller = i.createRef(), this._handleWrapperRef = t => {
                        this._wrapperRef = t, this.props.reference && this.props.reference(t)
                    }, this._handleClick = t => {
                        t.target instanceof Node && t.currentTarget.contains(t.target) && (this._handleToggleDropdown(), this.props.onClick && this.props.onClick(t, !this.state.isOpened))
                    }, this._handleToggleDropdown = t => {
                        const {
                            onClose: e,
                            onOpen: o
                        } = this.props, {
                            isOpened: i
                        } = this.state, n = "boolean" == typeof t ? t : !i;
                        this.setState({
                            isOpened: n
                        }), n && o && o(), !n && e && e()
                    }, this._handleClose = () => {
                        this.close()
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        id: t,
                        arrow: e,
                        content: o,
                        isDisabled: r,
                        isDrawer: l,
                        isShowTooltip: c,
                        title: d,
                        className: u,
                        hotKey: m,
                        theme: g,
                        drawerBreakpoint: _
                    } = this.props, {
                        isOpened: v
                    } = this.state, w = n(u, g.button, {
                        "apply-common-tooltip": c || !r,
                        [g.isDisabled]: r,
                        [g.isOpened]: v,
                        [g.newStyles]: p.hasNewHeaderToolbarStyles
                    });
                    return i.createElement("div", {
                        id: t,
                        className: w,
                        onClick: r ? void 0 : this._handleClick,
                        title: d,
                        "data-tooltip-hotkey": m,
                        ref: this._handleWrapperRef,
                        "data-role": "button",
                        ...(0, a.filterDataProps)(this.props)
                    }, o, e && i.createElement("div", {
                        className: g.arrow
                    }, i.createElement("div", {
                        className: g.arrowWrap
                    }, i.createElement(s.ToolWidgetCaret, {
                        dropped: v
                    }))), this.state.isOpened && (_ ? i.createElement(h.MatchMedia, {
                        rule: _
                    }, t => this._renderContent(t)) : this._renderContent(l)))
                }
                close() {
                    this._handleToggleDropdown(!1)
                }
                update() {
                    null !== this._controller.current && this._controller.current.update()
                }
                _renderContent(t) {
                    const {
                        menuDataName: e,
                        minWidth: o,
                        menuClassName: n,
                        maxHeight: s,
                        drawerPosition: a = "Bottom",
                        children: h
                    } = this.props, {
                        isOpened: p
                    } = this.state, u = {
                        horizontalMargin: this.props.horizontalMargin || 0,
                        verticalMargin: this.props.verticalMargin || 2,
                        verticalAttachEdge: this.props.verticalAttachEdge,
                        horizontalAttachEdge: this.props.horizontalAttachEdge,
                        verticalDropDirection: this.props.verticalDropDirection,
                        horizontalDropDirection: this.props.horizontalDropDirection,
                        matchButtonAndListboxWidths: this.props.matchButtonAndListboxWidths
                    }, m = Boolean(p && t && a), g = function(t) {
                        return "function" == typeof t
                    }(h) ? h({
                        isDrawer: m
                    }) : h;
                    return m ? i.createElement(l.DrawerManager, null, i.createElement(c.Drawer, {
                        onClose: this._handleClose,
                        position: a,
                        "data-name": e
                    }, g)) : i.createElement(r.PopupMenu, {
                        controller: this._controller,
                        closeOnClickOutside: this.props.closeOnClickOutside,
                        doNotCloseOn: this,
                        isOpened: p,
                        minWidth: o,
                        onClose: this._handleClose,
                        position: (0, d.getPopupPositioner)(this._wrapperRef, u),
                        className: n,
                        maxHeight: s,
                        "data-name": e
                    }, g)
                }
            }
            g.defaultProps = {
                arrow: !0,
                closeOnClickOutside: !0,
                theme: u
            }
        },
        4257: (t, e, o) => {
            "use strict";
            o.d(e, {
                hasNewHeaderToolbarStyles: () => i
            });
            o(82527);
            const i = !1
        },
        51090: (t, e, o) => {
            "use strict";
            o.r(e), o.d(e, {
                FavoriteDrawingToolbar: () => g
            });
            var i = o(25177),
                n = o(40456),
                r = o(3597),
                s = o(72535),
                a = o(93605),
                l = o(90687),
                c = o(9696),
                d = o(93546),
                h = o(84291),
                p = o(70122),
                u = o(94489),
                m = o.n(u);
            o(99376);
            class g extends n.FloatingToolbar {
                constructor(t) {
                    super({
                        allowSortable: !s.mobiletouch,
                        dragOnlyInsideToolbar: !0,
                        defaultPosition: t,
                        positionSettingsKey: "chart.favoriteDrawingsPosition",
                        positionStorageType: "device"
                    }), this._linetoolsWidgets = {}, this._canBeShownValue = new(m())(!1), this._attachHandlers(), this._loadVisibilityState(), this._hideAction = this._createHideToolbarAction()
                }
                show() {
                    this._canBeShownValue.value() && (p.setValue("ChartFavoriteDrawingToolbarWidget.visible", !0), this.isVisible() || this._renderAllLinetools(), super.show())
                }
                hide() {
                    p.setValue("ChartFavoriteDrawingToolbarWidget.visible", !1), super.hide()
                }
                canBeShown() {
                    return this._canBeShownValue.readonly()
                }
                _correctPosition(t) {
                    super._correctPosition(t);
                    const e = this._getSavedPosition();
                    if (!e) return;
                    const o = this._getCorrectedWidgetRect();
                    if (!o.width) return;
                    const i = window.innerWidth - o.right,
                        n = window.innerHeight - o.bottom;
                    e.left > t.left && i > 0 && (t.left = Math.min(t.left + i, e.left)), e.top > t.top && n > 0 && (t.top = Math.min(t.top + n, e.top))
                }
                _onFavoriteAdded(t) {
                    this._canBeShownValue.setValue(!0), this.addWidget(this._createLinetoolWidget(t)), this.show()
                }
                _onFavoriteRemoved(t) {
                    this.removeWidget(this._linetoolsWidgets[t]), delete this._linetoolsWidgets[t], 0 === r.LinetoolsFavoritesStore.favoritesCount() && (this._canBeShownValue.setValue(!1), this.hide())
                }
                _onFavoriteMoved() {
                    this._renderAllLinetools()
                }
                _onSelectedLinetoolChanged(t) {
                    Object.keys(this._linetoolsWidgets).forEach(e => {
                        this._linetoolsWidgets[e].classList.toggle("i-active", t === e)
                    })
                }
                _createLinetoolWidget(t) {
                    const e = `<span class="tv-favorited-drawings-toolbar__widget apply-common-tooltip ${t===d.tool.value()?"i-active":""}" title="${h.lineToolsInfo[t].localizedName}" data-name="FavoriteToolbar${t}">${h.lineToolsInfo[t].icon}</span>`,
                        o = (0, a.parseHtmlElement)(e);
                    return o.addEventListener("click", e => {
                        e.preventDefault(), d.tool.value() !== t && d.tool.setValue(t)
                    }), this._linetoolsWidgets[t] = o, o
                }
                _renderAllLinetools() {
                    this._linetoolsWidgets = {}, this.removeWidgets(), r.LinetoolsFavoritesStore.favorites().filter(t => h.lineToolsInfo[t]).forEach(t => {
                        this.addWidget(this._createLinetoolWidget(t))
                    })
                }
                _attachHandlers() {
                    r.LinetoolsFavoritesStore.favoriteAdded.subscribe(this, this._onFavoriteAdded), r.LinetoolsFavoritesStore.favoriteRemoved.subscribe(this, this._onFavoriteRemoved), r.LinetoolsFavoritesStore.favoriteMoved.subscribe(this, this._onFavoriteMoved), r.LinetoolsFavoritesStore.favoritesSynced.subscribe(null, () => {
                        this._loadVisibilityState(), this._renderAllLinetools()
                    }), this.onWidgetsReordered().subscribe(this, (t, e) => {
                        if (r.LinetoolsFavoritesStore.favoriteMoved.unsubscribe(this, this._onFavoriteMoved), !r.LinetoolsFavoritesStore.moveFavorite(r.LinetoolsFavoritesStore.favorite(t), e)) throw new Error("Something went wrong");
                        r.LinetoolsFavoritesStore.favoriteMoved.subscribe(this, this._onFavoriteMoved)
                    }), this.onContextMenu(t => {
                        t.preventDefault(), c.ContextMenuManager.showMenu([this._hideAction], t)
                    }), d.tool.subscribe(this._onSelectedLinetoolChanged.bind(this))
                }
                _createHideToolbarAction() {
                    return new l.Action({
                        actionId: "Chart.FavoriteDrawingToolsToolbar.Hide",
                        label: (0,
                            i.t)("Hide Favorite Drawing Tools Toolbar"),
                        onExecute: () => {
                            this.hide()
                        }
                    })
                }
                _loadVisibilityState() {
                    const t = r.LinetoolsFavoritesStore.favoritesCount() > 0;
                    this._canBeShownValue.setValue(t);
                    p.getBool("ChartFavoriteDrawingToolbarWidget.visible", !0) && t ? this.show() : this.hide()
                }
            }
        },
        40456: (t, e, o) => {
            "use strict";
            o.d(e, {
                FLOATING_TOOLBAR_REACT_WIDGETS_CLASS: () => w,
                FloatingToolbar: () => y
            });
            var i = o(70981),
                n = o(72535),
                r = o(85787),
                s = o(70122),
                a = o(97496),
                l = o.n(a),
                c = o(94489),
                d = o.n(c),
                h = o(81370);
            class p extends h.ChunkLoader {
                _startLoading() {
                    return Promise.all([o.e(1553), o.e(2377)]).then(o.bind(o, 77525)).then(t => t.HammerJS)
                }
            }
            var u = o(31595),
                m = o(96818),
                g = o(93605),
                _ = o(32133),
                v = o(74513);
            o(24302);
            const w = "floating-toolbar-react-widgets",
                f = `<div class="tv-floating-toolbar i-closed i-hidden"><div class="tv-floating-toolbar__widget-wrapper"><div class="tv-floating-toolbar__drag js-drag">${v}</div><div class="tv-floating-toolbar__content js-content"></div><div class="${w}"></div></div></div>`;
            class y {
                constructor(t) {
                    this._widget = document.createElement("div"), this._isVertical = !1, this._hiddingTimeoutId = null, this._visibility = new(d())(!1), this._windowResizeListener = this._onWindowResize.bind(this), this._reorderedDelegate = new(l()), this._responsiveResizeFunction = null, this._showTimeStamp = null, this._draggable = null, this._preventClickUntilAnimation = t => {
                        null !== this._showTimeStamp && performance.now() - this._showTimeStamp < this.hideDuration() && t.stopPropagation()
                    }, y._toolbars.push(this), this._options = t, this._widget = (0, g.parseHtmlElement)(f), this._content = this._widget.getElementsByClassName("js-content").item(0), this._reactWidgetsContainer = this._widget.getElementsByClassName(w).item(0), this._setZIndex(y._startZIndex + y._toolbars.length - 1), this._options.addClass && (this._widget.className += " " + this._options.addClass), this._options["data-name"] && (this._widget.dataset.name = this._options["data-name"]), this._options.layout && "auto" !== this._options.layout && (this._isVertical = "vertical" === this._options.layout, this._updateLayoutType(), this._updateAxisOption()), this._widget.addEventListener("click", this._preventClickUntilAnimation, !0)
                }
                destroy() {
                    this.hide(!0), y._toolbars.splice(y._toolbars.indexOf(this), 1), this._widget.removeEventListener("click", this._preventClickUntilAnimation, !0), document.body.contains(this._widget) && document.body.removeChild(this._widget), null !== this._draggable && this._draggable.destroy(), this._widget.innerHTML = "", this._responsiveResizeFunction = null
                }
                setResponsiveResizeFunc(t) {
                    this._responsiveResizeFunction = t
                }
                isVisible() {
                    return this._visibility.value()
                }
                visibility() {
                    return this._visibility.readonly()
                }
                isVertical() {
                    return this._isVertical
                }
                show() {
                    this.isVisible() || (document.body.contains(this._widget) || (this._init(), document.body.appendChild(this._widget)), this._setHiddingTimeout(null), window.addEventListener("resize", this._windowResizeListener), this.raise(), this._visibility.setValue(!0), this._showTimeStamp = performance.now(), this._widget.classList.contains("i-hidden") ? (this._widget.classList.remove("i-hidden"), setTimeout(() => {
                        this.isVisible() && this._widget.classList.remove("i-closed")
                    })) : this._widget.classList.remove("i-closed"), this._onWindowResize())
                }
                hide(t = !1) {
                    if (!this.isVisible()) return;
                    const e = this._widget.classList.contains("i-closed");
                    if (this._widget.classList.add("i-closed"), this._visibility.setValue(!1), t || e) this._setHiddingTimeout(null), this._widget.classList.add("i-hidden");
                    else {
                        const t = setTimeout(() => {
                            this._setHiddingTimeout(null), this._widget.classList.add("i-hidden")
                        }, this.hideDuration());
                        this._setHiddingTimeout(t)
                    }
                    window.removeEventListener("resize", this._windowResizeListener)
                }
                raise() {
                    y._toolbars.length + y._startZIndex !== this._zIndex() && (y._toolbars.splice(y._toolbars.indexOf(this), 1), y._toolbars.push(this), y._updateAllZIndexes())
                }
                hideDuration() {
                    return .75 * r.dur
                }
                addWidget(t, e = {}) {
                    const o = this.widgetsCount();
                    if (void 0 === e.index && (e.index = o), e.index < 0 || e.index > o) throw new Error(`Index must be in [0, ${o}]`);
                    const i = document.createElement("div");
                    i.className = "tv-floating-toolbar__widget js-widget", i.appendChild(t);
                    const n = e.index === o ? null : this._content.childNodes.item(e.index);
                    this._content.insertBefore(i, n), this._onWindowResize()
                }
                getReactWidgetContainer() {
                    return this._reactWidgetsContainer
                }
                removeWidget(t) {
                    const e = this._findWrapperForWidget(t);
                    e && (this._content.removeChild(e), this._onWindowResize())
                }
                widgetsCount() {
                    return this._content.childNodes.length
                }
                showWidget(t) {
                    const e = this._findWrapperForWidget(t);
                    e && e.classList.remove("i-hidden")
                }
                hideWidget(t) {
                    const e = this._findWrapperForWidget(t);
                    e && e.classList.add("i-hidden")
                }
                removeWidgets() {
                    for (; this._content.firstChild;) this._content.removeChild(this._content.firstChild);
                    this._onWindowResize()
                }
                onWidgetsReordered() {
                    return this._reorderedDelegate
                }
                onContextMenu(t) {
                    if (n.mobiletouch) {
                        (new p).load().then(e => {
                            const o = new e(this._widget);
                            o.get("press").set({
                                time: 500
                            }), o.on("press", e => {
                                this._preventWidgetTouchEndEvent(), t(e.srcEvent)
                            })
                        })
                    } else this._widget.addEventListener("contextmenu", t)
                }
                checkPosition() {
                    const t = this._getCorrectedWidgetRect(),
                        e = {
                            left: t.left,
                            top: t.top
                        };
                    this._correctPosition(e), t.left === e.left && t.top === e.top || (this._widget.style.left = e.left + "px", this._widget.style.top = e.top + "px")
                }
                _determineCurrentLayoutVertical(t) {
                    const e = this._isVertical ? t.height : t.width;
                    return window.innerWidth < e && window.innerWidth < window.innerHeight
                }
                _getWidget() {
                    return this._widget
                }
                _findWrapperForWidget(t) {
                    const e = this._content.getElementsByClassName("js-widget");
                    for (let o = 0; o < e.length; ++o) {
                        const i = e.item(o);
                        if (i.contains(t)) return i
                    }
                    return null
                }
                _onVerticalChanged(t, e) {}
                _correctPosition(t) {
                    const e = this._getCorrectedWidgetRect();
                    t.left + e.width > window.innerWidth && (t.left = Math.max(0, window.innerWidth - e.width)), t.top + e.height > window.innerHeight && (t.top = Math.max(0, window.innerHeight - e.height)), t.left = Math.max(0, t.left), t.top = Math.max(0, t.top)
                }
                _getCorrectedWidgetRect() {
                    const t = this._widget.getBoundingClientRect();
                    if (this._widget.classList.contains("i-closed")) {
                        const e = 1 / .925 - 1,
                            o = t.width * e,
                            i = t.height * e;
                        return {
                            bottom: t.bottom + i / 2,
                            height: t.height + i,
                            left: t.left - o / 2,
                            right: t.right + o / 2,
                            top: t.top - i / 2,
                            width: t.width + o
                        }
                    }
                    return t
                }
                _getSavedPosition() {
                    var t;
                    let e;
                    if ("device" === this._options.positionStorageType) {
                        const t = u.TVLocalStorage.getItem(this._options.positionSettingsKey);
                        e = null !== t ? JSON.parse(t) : null
                    } else e = null !== (t = (0, s.getJSON)(this._options.positionSettingsKey)) && void 0 !== t ? t : null;
                    return null !== e && "top" in e && "left" in e ? e : null
                }
                _setHiddingTimeout(t) {
                    null !== this._hiddingTimeoutId && clearTimeout(this._hiddingTimeoutId), this._hiddingTimeoutId = t
                }
                _preventWidgetTouchEndEvent() {
                    const t = e => {
                        e.preventDefault(), this._widget.removeEventListener("touchend", t)
                    };
                    this._widget.addEventListener("touchend", t)
                }
                _updateLayoutType() {
                    this._widget.classList.toggle("i-vertical", this._isVertical)
                }
                _updateAxisOption() {
                    0
                }
                _onWindowResize() {
                    if ("auto" === (this._options.layout || "auto")) {
                        const t = this._isVertical,
                            e = this._getCorrectedWidgetRect();
                        this._isVertical = this._determineCurrentLayoutVertical(e), this._updateLayoutType(), t !== this._isVertical && (this._onVerticalChanged(this._isVertical, t), this._updateAxisOption())
                    }
                    this.checkPosition(), this._resizeResponsive()
                }
                _resizeResponsive() {
                    if (null === this._responsiveResizeFunction) return;
                    let t = this._options.layout || "auto";
                    "auto" === t && (t = this._isVertical ? "vertical" : "horizontal");
                    const e = "vertical" === t ? this._widget.clientHeight : this._widget.clientWidth,
                        o = ("vertical" === t ? window.innerHeight : window.innerWidth) - e;
                    this._responsiveResizeFunction(e, o, t)
                }
                _setZIndex(t) {
                    this._widget.style.zIndex = String(t)
                }
                _zIndex() {
                    return Number(this._widget.style.zIndex)
                }
                _loadPosition() {
                    var t;
                    const e = null !== (t = this._getSavedPosition()) && void 0 !== t ? t : this._options.defaultPosition;
                    this._widget.style.left = Math.round(e.left) + "px", this._widget.style.top = Math.round(e.top) + "px", this._onWindowResize()
                }
                _savePosition() {
                    const t = this._widget.getBoundingClientRect();
                    if ("device" === this._options.positionStorageType) try {
                        u.TVLocalStorage.setItem(this._options.positionSettingsKey, JSON.stringify({
                            left: t.left,
                            top: t.top
                        }))
                    } catch (t) {} else(0, s.setJSON)(this._options.positionSettingsKey, {
                        left: t.left,
                        top: t.top
                    })
                }
                _init() {
                    this._loadPosition(), this._draggable = new m.Draggable({
                        source: this._widget,
                        containment: "window",
                        handle: ".js-drag",
                        start: i.globalCloseMenu,
                        stop: this._savePosition.bind(this)
                    }), this._widget.addEventListener("pointerdown", this.raise.bind(this))
                }
                _initSortable() {
                    let t = -1;
                    lazyJqueryUI(this._content).sortable({
                        start: (e, o) => {
                            t = o.item.index()
                        },
                        stop: (e, o) => {
                            const i = o.item.index();
                            t !== i && ((0, _.trackEvent)("Floating Toolbar", "User Sort"), this._reorderedDelegate.fire(t, i))
                        },
                        tolerance: "pointer",
                        distance: 5,
                        containment: !!this._options.dragOnlyInsideToolbar && "parent",
                        scroll: !1,
                        placeholder: "sortable-placeholder",
                        forcePlaceholderSize: !0
                    }), this._updateAxisOption()
                }
                static _updateAllZIndexes() {
                    y._toolbars.forEach((t, e) => {
                        t._setZIndex(y._startZIndex + e)
                    })
                }
            }
            y._startZIndex = 20, y._toolbars = []
        },
        9371: (t, e, o) => {
            "use strict";
            o.d(e, {
                LineToolPropertiesWidgetBase: () => bt
            });
            var i = o(59496),
                n = o(87995),
                r = o(25177),
                s = o(18517),
                a = o(82527),
                l = o(94489),
                c = o.n(l),
                d = o(2683),
                h = o(5796),
                p = o(93546),
                u = o(86137),
                m = o(88537),
                g = o(86712),
                _ = o.n(g);
            class v extends(_()) {
                constructor(t, e, o) {
                    super(),
                        this._listenersMappers = [], this._isProcess = !1, this._baseProperty = t, this._propertyApplier = e, this._undoText = o
                }
                destroy() {
                    this._baseProperty.destroy()
                }
                value() {
                    return this._baseProperty.value()
                }
                setValue(t) {
                    this._isProcess = !0, this._baseProperty.setValue(t, void 0, {
                        applyValue: (t, e) => this._propertyApplier.setProperty(t, e, this._undoText)
                    }), this._isProcess = !1, this._listenersMappers.forEach(t => {
                        t.method.call(t.obj, this)
                    })
                }
                subscribe(t, e) {
                    const o = o => {
                            this._isProcess || e.call(t, this)
                        },
                        i = {
                            obj: t,
                            method: e,
                            callback: o
                        };
                    this._listenersMappers.push(i), this._baseProperty.subscribe(t, o)
                }
                unsubscribe(t, e) {
                    var o;
                    const i = (0, m.ensureDefined)(null === (o = this._listenersMappers.find(o => o.obj === t && o.method === e)) || void 0 === o ? void 0 : o.callback);
                    this._baseProperty.unsubscribe(t, i)
                }
                unsubscribeAll(t) {
                    this._baseProperty.unsubscribeAll(t)
                }
            }
            var w = o(85067),
                f = o(13739),
                y = o(40456),
                b = o(96038);
            const C = y.FLOATING_TOOLBAR_REACT_WIDGETS_CLASS + "__button";

            function T(t) {
                const {
                    templateButton: e,
                    propertyButtons: o,
                    commonButtons: n,
                    isDrawingFinished: r,
                    activeChartWidget: s
                } = t, a = s.hasModel() && s.model().selection().dataSources();
                return a && a.length ? i.createElement(f.MatchMediaMap, {
                    rules: {
                        isSmallWidth: b.DialogBreakpoints.TabletSmall,
                        isSmallHeight: "screen and (max-height: 428px)"
                    }
                }, ({
                    isSmallWidth: t,
                    isSmallHeight: e
                }) => i.createElement(i.Fragment, null, l(), r && i.createElement(i.Fragment, null, Boolean(o.length) && o.map((o, n) => i.createElement(o.component, { ...o.props,
                    key: `${o.props.title}_${n}`,
                    className: C,
                    isSmallScreen: t || e
                })), Boolean(n.length) && n.map((o, n) => {
                    const r = t || e;
                    return r ? o.showForSmallScreen ? i.createElement(o.component, { ...o.props,
                        isSmallScreen: r,
                        key: `${o.props.title}_${n}`,
                        className: C
                    }) : null : i.createElement(o.component, { ...o.props,
                        key: `${o.props.title}_${n}`,
                        className: C
                    })
                })))) : l();

                function l() {
                    return null === e ? null : i.createElement(e.component, { ...e.props,
                        isDrawingFinished: r,
                        className: C
                    })
                }
            }
            var E = o(32133),
                S = o(5710),
                P = o(97978);

            function x(t) {
                const {
                    title: e,
                    activeChartWidget: o,
                    className: n
                } = t;
                return i.createElement(S.ToolWidgetIconButton, {
                    className: n,
                    icon: P,
                    title: e,
                    onClick: async function() {
                        (0, E.trackEvent)("GUI", "Context action on drawings", "Settings");
                        const t = o.model().selection().lineDataSources(),
                            e = t.length;
                        1 === e ? await o.showChartPropertiesForSource(t[0], void 0, {
                            onWidget: o.onWidget()
                        }) : e > 1 && await o.showChartPropertiesForSources({
                            sources: t
                        })
                    },
                    "data-name": "settings"
                })
            }
            var L = o(34297),
                W = o(97754),
                k = o(30140),
                A = o(88168);

            function B(t) {
                const {
                    className: e,
                    ...o
                } = t;
                return i.createElement(k.ToolButton, {
                    className: W(e, A.button),
                    tooltipPosition: "horizontal",
                    ...o
                })
            }
            var D = o(69840),
                M = o(3992);

            function N(t) {
                const {
                    activeChartWidget: e,
                    className: o
                } = t, n = e.model().selection().lineDataSources();
                if (0 === n.length) return null;
                const s = n[0].properties().frozen,
                    a = (0, L.useProperty)(s),
                    l = a ? {
                        title: (0, r.t)("Unlock"),
                        icon: D
                    } : {
                        title: (0, r.t)("Lock"),
                        icon: M
                    };
                return i.createElement(B, {
                    className: o,
                    isActive: Boolean(a),
                    onClick: function() {
                        (0, E.trackEvent)("GUI", "Context action on drawings", "Lock"), e.toggleLockSelectedObject()
                    },
                    "data-name": Boolean(a) ? "unlock" : "lock",
                    ...l
                })
            }
            var I = o(86312);

            function R(t) {
                const {
                    title: e,
                    activeChartWidget: o,
                    className: n
                } = t;
                return i.createElement(S.ToolWidgetIconButton, {
                    className: n,
                    icon: I,
                    title: e,
                    "data-name": "remove",
                    onClick: function() {
                        (0, E.trackEvent)("GUI", "Context action on drawings", "Remove"), o.removeSelectedSources()
                    }
                })
            }
            var V = o(72571),
                F = o(72535),
                O = o(80185),
                z = o(82027),
                H = o(34816),
                j = o(28786),
                U = o(90687),
                G = o(49161),
                Y = o(9696),
                K = o(50278),
                q = o(98584),
                $ = o(8669),
                X = o(26);

            function Z(t) {
                const {
                    title: e,
                    activeChartWidget: n,
                    isSmallScreen: s,
                    className: a
                } = t, l = n.model(), c = l.selection().lineDataSources(), [d, h] = (0, i.useState)([]), p = (0, i.useRef)(null), u = (0, i.useMemo)(() => new K.ActionsProvider(n), [n]);
                return i.createElement(i.Fragment, null, i.createElement(G.KeyboardDocumentListener, {
                    keyCode: 27,
                    eventType: "keyup",
                    handler: function() {
                        (0, m.ensureNotNull)(p.current).close()
                    }
                }), i.createElement(H.ToolWidgetMenu, {
                    className: a,
                    ref: p,
                    arrow: !1,
                    onOpen: s ? void 0 : function() {
                        const t = [new U.Action({
                                actionId: "Chart.Source.VisualOrder",
                                label: (0, r.t)("Visual order"),
                                icon: $,
                                subItems: g(),
                                name: "visual-order"
                            })],
                            e = function() {
                                const t = [],
                                    e = O.isMacKeyboard ? " +" : "",
                                    i = c.filter(t => t.cloneable());
                                i.length > 0 && t.push(new U.Action({
                                    actionId: "Chart.LineTool.Clone",
                                    name: "clone",
                                    icon: o(56085),
                                    shortcutHint: O.humanReadableModifiers(z.Modifiers.Mod) + e + " Drag",
                                    label: (0, r.t)("Clone"),
                                    onExecute: () => {
                                        l.cloneLineTools(i, !1), (0, E.trackEvent)("GUI", "Context action on drawings", "Clone")
                                    }
                                }));
                                const s = c.filter(t => t.copiable());
                                if (s.length > 0) {
                                    const o = {
                                        actionId: "Chart.Clipboard.CopyLineTools",
                                        name: "copy",
                                        label: (0, r.t)("Copy"),
                                        shortcutHint: O.humanReadableModifiers(z.Modifiers.Mod) + e + " C",
                                        onExecute: () => {
                                            n.chartWidgetCollection().clipboard.uiRequestCopy(s)
                                        }
                                    };
                                    t.push(new U.Action(o, "Copy"))
                                }
                                if (! function() {
                                        if (!(null == n ? void 0 : n.isMultipleLayout())) return !1;
                                        return c.some(t => t.isSynchronizable())
                                    }()) return t;
                                return t.push(...(0, K.createSyncDrawingActions)(n, c)), t
                            }();
                        e.length && t.push(new U.Separator, ...e);
                        t.push(new U.Separator, new U.Action({
                            actionId: "Chart.SelectedObject.Hide",
                            label: (0, r.t)("Hide"),
                            icon: X,
                            onExecute: () => {
                                n.hideSelectedObject()
                            },
                            name: "hide"
                        })), h(J(t))
                    },
                    onClick: s ? function(t) {
                        u.contextMenuActionsForSources(c).then(e => {
                            window.matchMedia(b.DialogBreakpoints.TabletSmall).matches ? Y.ContextMenuManager.showMenu(J(e), t, {
                                mode: "drawer",
                                "data-name": "more-menu"
                            }) : h(J(e))
                        })
                    } : void 0,
                    title: e,
                    content: i.createElement(V.Icon, {
                        icon: q
                    }),
                    "data-name": "more",
                    menuDataName: "more-menu"
                }, i.createElement(j.ActionsTable, {
                    parentIsOpened: !0,
                    items: d
                })));

                function g() {
                    const t = [],
                        e = l.availableZOrderOperations(c),
                        o = new U.Action({
                            actionId: "Chart.Source.VisualOrder.BringToFront",
                            name: "bring-to-front",
                            label: (0, r.t)("Bring to Front"),
                            onExecute: () => {
                                l.bringToFront(c)
                            },
                            disabled: 1 === c.length && !e.bringToFrontEnabled
                        }),
                        i = new U.Action({
                            actionId: "Chart.Source.VisualOrder.SendToBack",
                            name: "send-to-back",
                            label: (0, r.t)("Send to Back"),
                            onExecute: () => {
                                l.sendToBack(c)
                            },
                            disabled: 1 === c.length && !e.sendToBackEnabled
                        }),
                        n = new U.Action({
                            actionId: "Chart.Source.VisualOrder.BringForward",
                            name: "bring-forward",
                            label: (0, r.t)("Bring Forward"),
                            onExecute: () => {
                                l.bringForward(c)
                            },
                            disabled: 1 === c.length && !e.bringForwardEnabled
                        }),
                        s = new U.Action({
                            actionId: "Chart.Source.VisualOrder.SendBackward",
                            name: "send-backward",
                            label: (0, r.t)("Send Backward"),
                            onExecute: () => {
                                l.sendBackward(c)
                            },
                            disabled: 1 === c.length && !e.sendBackwardEnabled
                        });
                    return t.push(o, i, n, s), t
                }
            }

            function J(t) {
                if (F.touch && !window.matchMedia("(pointer:fine)").matches) {
                    const e = t.filter(t => "Copy" !== t.id);
                    if (e.length === t.length) return e;
                    const o = [];
                    return e.forEach(t => {
                        ("separator" !== t.type || o.length > 0 && "separator" !== o[o.length - 1].type) && o.push(t)
                    }), o
                }
                return t
            }
            var Q = o(67912),
                tt = o(47387),
                et = o(87460),
                ot = o(22931);

            function it(t) {
                const {
                    property: e,
                    propertyApplier: o,
                    title: n,
                    undoText: s,
                    className: a
                } = t, l = (0, L.useProperty)(e), c = (0, i.useMemo)(() => [new U.Action({
                    actionId: "Chart.LineTool.Toolbar.ChangeLineStyleToSolid",
                    icon: tt,
                    label: (0, r.t)("Line"),
                    active: Q.LineStyle.Solid === l,
                    onExecute: () => o.setProperty(e, Q.LineStyle.Solid, s)
                }), new U.Action({
                    actionId: "Chart.LineTool.Toolbar.ChangeLineStyleToDashed",
                    icon: et,
                    label: (0, r.t)("Dashed line"),
                    active: Q.LineStyle.Dashed === l,
                    onExecute: () => o.setProperty(e, Q.LineStyle.Dashed, s)
                }), new U.Action({
                    actionId: "Chart.LineTool.Toolbar.ChangeLineStyleToDotted",
                    icon: ot,
                    label: (0, r.t)("Dotted line"),
                    active: Q.LineStyle.Dotted === l,
                    onExecute: () => o.setProperty(e, Q.LineStyle.Dotted, s)
                })], [o, e, l]);
                return i.createElement(H.ToolWidgetMenu, {
                    className: a,
                    arrow: !1,
                    content: i.createElement(V.Icon, {
                        icon: nt(l)
                    }),
                    title: n,
                    "data-name": t["data-name"],
                    menuDataName: t["data-name"] + "-menu"
                }, i.createElement(j.ActionsTable, {
                    items: c
                }))
            }

            function nt(t) {
                switch (t) {
                    case Q.LineStyle.Solid:
                        return tt;
                    case Q.LineStyle.Dashed:
                        return et;
                    case Q.LineStyle.Dotted:
                        return ot;
                    default:
                        return ""
                }
            }
            const rt = [10, 11, 12, 14, 16, 20, 24, 28, 32, 40];

            function st(t) {
                const {
                    property: e,
                    propertyApplier: o,
                    title: n,
                    undoText: r,
                    className: s
                } = t, a = (0, L.useProperty)(e), l = rt.map(t => new U.Action({
                    actionId: "Chart.LineTool.Toolbar.ChangeFontSizeProperty",
                    label: t.toString(),
                    onExecute: () => o.setProperty(e, t, r),
                    active: t === a
                }));
                return i.createElement(H.ToolWidgetMenu, {
                    arrow: !1,
                    content: a,
                    className: s,
                    title: n,
                    "data-name": t["data-name"],
                    menuDataName: t["data-name"] + "-menu"
                }, i.createElement(j.ActionsTable, {
                    items: l
                }))
            }
            var at = o(97496),
                lt = o.n(at);
            o(42024), o(62632);
            class ct extends y.FloatingToolbar {
                constructor(t) {
                    super(ct._prepareOptions(t)), this._onWidgetStateChangedDelegate = new(lt()), this._statedWidgets = [], this._currentPopup = null, this._onWindowClickedListener = this._onWindowClicked.bind(this)
                }
                show() {
                    super.show(), document.addEventListener("mousedown", this._onWindowClickedListener)
                }
                hide(t) {
                    super.hide(t), document.removeEventListener("mousedown", this._onWindowClickedListener)
                }
                destroy() {
                    this._closePopup(), super.destroy()
                }
                addGroupedWidget(t, e = {}) {
                    (0, m.assert)(t.states.length > 0 && -1 !== ct._getStateIndexById(t, t.currentStateId), `Argument is invalid (count: ${t.states.length}, state: ${t.currentStateId})`);
                    const o = document.createElement("div");
                    o.className = "tv-grouped-floating-toolbar__widget-wrapper apply-common-tooltip", t.widgetAddClass && o.classList.add(t.widgetAddClass), o.setAttribute("title", t.tooltip);
                    const i = {
                            isEnabled: !0,
                            statedWidget: t,
                            toolbarWidget: o
                        },
                        n = this._onWidgetClicked.bind(this, i);
                    i.clickListener = n, o.addEventListener("click", n), this._updateWidgetPreview(i), this.addWidget(o, e), this._statedWidgets.push(i)
                }
                findGroupedWidget(t) {
                    const e = this._statedWidgets.length;
                    for (let o = 0; o < e; ++o) {
                        if (this._statedWidgets[o].statedWidget.id === t) return o
                    }
                    return -1
                }
                removeGroupedWidget(t) {
                    const e = this._statedWidgets.length;
                    for (let o = 0; o < e; ++o) {
                        const e = this._statedWidgets[o];
                        if (e.statedWidget.id === t) return this._isPopupCreatedForWidget(t) && this._closePopup(), void 0 !== e.clickListener && e.toolbarWidget.removeEventListener("click", e.clickListener), this.removeWidget(e.toolbarWidget), this._statedWidgets.splice(o, 1), void this._updatePopupPosition()
                    }(0, m.assert)(!1, `Unknown groupId(${t})`)
                }
                updateGroupedWidget(t, e) {
                    this._closePopup();
                    const o = this._ensuredGetWidgetDataForId(t);
                    o.statedWidget.currentStateId = e.currentStateId, o.statedWidget.states = e.states, this._updateWidgetPreview(o)
                }
                setGroupedWidgetEnabled(t, e) {
                    const o = this._ensuredGetWidgetDataForId(t);
                    o.isEnabled = e, o.toolbarWidget.classList.toggle("i-disabled", !e)
                }
                setGroupedWidgetState(t, e) {
                    const o = this._ensuredGetWidgetDataForId(t);
                    (0, m.assert)(-1 !== ct._getStateIndexById(o.statedWidget, e), `Unknown stateId (${e})`), o.statedWidget.currentStateId = e, this._updateSubWidgetsState(o.statedWidget), this._updateWidgetPreview(o)
                }
                onWidgetStateChanged() {
                    return this._onWidgetStateChangedDelegate
                }
                _onVerticalChanged(t, e) {
                    this._updatePopupPosition()
                }
                _ensuredGetWidgetDataForId(t) {
                    for (const e of this._statedWidgets)
                        if (e.statedWidget.id === t) return e;
                    throw new Error(`Unknown groupId(${t})`)
                }
                _onWidgetClicked(t, e) {
                    const o = this._currentPopup && this._isPopupCreatedForWidget(t.statedWidget.id);
                    this._closePopup(), !o && t.isEnabled && this._createPopup(t)
                }
                _createPopup(t) {
                    const e = {
                        createdFor: t.toolbarWidget,
                        element: document.createElement("div"),
                        stateWidgetId: t.statedWidget.id,
                        widgets: []
                    };
                    e.element.className += "tv-grouped-floating-toolbar__popup js-popup";
                    const o = t.statedWidget.states.length;
                    t.statedWidget.states.forEach((i, n) => {
                        const r = this._createSubWidget(t, i),
                            s = this._onSubWidgetClicked.bind(this, t, i.id);
                        r.addEventListener("click", s), e.widgets.push({
                            clickListener: s,
                            stateWidget: i,
                            widget: r
                        }), r.classList.add("tv-grouped-floating-toolbar__sub-widget--slide-right-" + n), r.classList.add("tv-grouped-floating-toolbar__sub-widget--slide-left-" + (o - n + 1)), i.readonly || e.element.appendChild(r)
                    }), this._currentPopup = e, this._updateSubWidgetsState(t.statedWidget), t.toolbarWidget.classList.add("i-dropped"), this._getWidget().appendChild(this._currentPopup.element), Promise.resolve().then(() => {
                        this._currentPopup && this._currentPopup.element.classList.add("i-opened")
                    }), this._updatePopupPosition()
                }
                _closePopup() {
                    if (this._statedWidgets.forEach(t => {
                            t.toolbarWidget.classList.remove("i-dropped")
                        }), !this._currentPopup) return;
                    const t = this._currentPopup.widgets,
                        e = this._currentPopup.element;
                    this._currentPopup = null, t.forEach(t => {
                        t.widget.removeEventListener("click", t.clickListener)
                    }), e.classList.remove("i-opened"), e.addEventListener("transitionend", t => {
                        t.target === e && this._getWidget().removeChild(e)
                    })
                }
                _updateWidgetPreview(t) {
                    const e = ct._getStateIndexById(t.statedWidget, t.statedWidget.currentStateId);
                    (0, m.assert)(-1 !== e, "Unknown state id: " + t.statedWidget.currentStateId);
                    const o = t.statedWidget.states[e].widget.cloneNode(!0);
                    t.toolbarWidget.firstChild ? t.toolbarWidget.replaceChild(o, t.toolbarWidget.firstChild) : (t.toolbarWidget.appendChild(o), t.toolbarWidget.appendChild(ct._createCaret()))
                }
                _updateSubWidgetsState(t) {
                    this._currentPopup && this._isPopupCreatedForWidget(t.id) && this._currentPopup.widgets.forEach(e => {
                        e.widget.classList.toggle(ct._activeSubWidgetClass, e.stateWidget.id === t.currentStateId)
                    })
                }
                _updatePopupPosition() {
                    if (!this._currentPopup) return;
                    const t = this._currentPopup.createdFor,
                        e = this._getWidget().getBoundingClientRect(),
                        o = this._findWrapperForWidget(t);
                    if (!o || !this._currentPopup) throw new Error("Toolbar has no wrapper for preview's widget or there is no popup");
                    const i = o.getBoundingClientRect(),
                        n = this._currentPopup.element.getBoundingClientRect(),
                        r = this._currentPopup.element;
                    if (this.isVertical()) r.classList.remove("tv-grouped-floating-toolbar__popup--at-top"), r.style.top = i.top - e.top + 1 + "px", r.style.left = "", e.left > window.innerWidth - e.right ? r.classList.add("tv-grouped-floating-toolbar__popup--at-left") : r.classList.remove("tv-grouped-floating-toolbar__popup--at-left");
                    else {
                        r.classList.remove("tv-grouped-floating-toolbar__popup--at-left");
                        let t = 0;
                        i.left + n.width > window.innerWidth ? e.left + n.width > window.innerWidth && (t = e.width - n.width) : t = i.left - e.left + 1, r.style.left = t + "px", e.bottom + n.height > window.innerHeight ? r.classList.add("tv-grouped-floating-toolbar__popup--at-top") : (r.classList.remove("tv-grouped-floating-toolbar__popup--at-top"), r.style.top = "")
                    }
                }
                _isPopupCreatedForWidget(t) {
                    return Boolean(this._currentPopup && this._currentPopup.stateWidgetId === t)
                }
                _createSubWidget(t, e) {
                    const o = document.createElement("div");
                    return o.className += "tv-grouped-floating-toolbar__sub-widget", t.statedWidget.stateWidgetAddClass && o.classList.add(t.statedWidget.stateWidgetAddClass), o.appendChild(e.widget), o
                }
                _onSubWidgetClicked(t, e) {
                    this._closePopup(), t.statedWidget.currentStateId !== e && (this.setGroupedWidgetState(t.statedWidget.id, e), this._onWidgetStateChangedDelegate.fire(t.statedWidget.id, e))
                }
                _onWindowClicked(t) {
                    if (this.isVisible() && this._currentPopup && !ct._isEventInElement(t, this._currentPopup.element)) {
                        for (let e = 0; e < this._statedWidgets.length; ++e)
                            if (ct._isEventInElement(t, this._statedWidgets[e].toolbarWidget)) return;
                        this._closePopup()
                    }
                }
                static _getStateIndexById(t, e) {
                    for (let o = 0; o < t.states.length; ++o)
                        if (t.states[o].id === e) return o;
                    return -1
                }
                static _createCaret() {
                    const t = document.createElement("div");
                    return t.className = "tv-caret tv-caret--small tv-caret--colored tv-grouped-floating-toolbar__caret", t
                }
                static _prepareOptions(t) {
                    return t.addClass ? t.addClass += " tv-grouped-floating-toolbar" : t.addClass = " tv-grouped-floating-toolbar", t
                }
                static _isEventInElement(t, e) {
                    return t.target === e || e.contains(t.target)
                }
            }
            ct._activeSubWidgetClass = "tv-grouped-floating-toolbar__sub-widget--current";
            var dt = o(57372),
                ht = o(67407),
                pt = o(64840),
                ut = o(8123);
            const mt = new s.TranslatedString("change line tool(s) font size", (0, r.t)("change line tool(s) font size")),
                gt = new s.TranslatedString("change line tool(s) line style", (0, r.t)("change line tool(s) line style")),
                _t = (0, r.t)("Settings"),
                vt = (0, r.t)("Remove"),
                wt = (0, r.t)("More"),
                ft = (0, r.t)("Style"),
                yt = (0, r.t)("Font size");
            class bt {
                constructor(t) {
                    this._isDrawingFinished = new(c())(!0), this._currentTool = null, this._updateVisibilityTimeout = null, this._lineWidthsProperty = null, this._lineColorsProperty = null, this._currentProperties = null, this._container = null, this._toolbarRendered = !1, this._templatesButton = null, this._propertyButtons = [], this._commonButtons = [], this._handleSourceEdit = t => {
                        p.isDirectionalMovementActive.value() || (t ? this._floatingToolbar.hide(!0) : this._toolbarRendered && this._floatingToolbar.show())
                    }, this._chartWidgetCollection = t, this._floatingToolbar = new ct({
                        defaultPosition: {
                            top: dt.HEADER_TOOLBAR_HEIGHT_EXPANDED + 15,
                            left: window.innerWidth / 2
                        },
                        positionSettingsKey: "properties_toolbar.position",
                        positionStorageType: "device",
                        layout: "horizontal",
                        "data-name": "drawing-toolbar"
                    }), this._container = this._floatingToolbar.getReactWidgetContainer(), this._isToolMovingNowSpawn = p.isToolMovingNow.spawn(), this._isToolEditingNowSpawn = p.isToolEditingNow.spawn(), this._toolSpawn = p.tool.spawn(), this._iconToolSpawn = p.iconTool.spawn(), this._selectedSourcesSpawn = this._chartWidgetCollection.selectedSources.spawn(), this._isToolMovingNowSpawn.subscribe(this._handleSourceEdit), this._isToolEditingNowSpawn.subscribe(this._handleSourceEdit), this._toolSpawn.subscribe(this._onToolChanged.bind(this), {
                        callWithLast: !0
                    }), this._iconToolSpawn.subscribe(() => this._onToolChanged(p.tool.value())), this._selectedSourcesSpawn.subscribe(() => this.onSourceChanged(this.selectedSources())), this._chartWidgetCollection.onAboutToBeDestroyed.subscribe(this, this.destroy, !0)
                }
                destroy() {
                    this._isToolMovingNowSpawn.destroy(), this._isToolEditingNowSpawn.destroy(), this._toolSpawn.destroy(), this._iconToolSpawn.destroy(), this._selectedSourcesSpawn.destroy()
                }
                activeChartWidget() {
                    return this._chartWidgetCollection.activeChartWidget.value()
                }
                selectedSources() {
                    return this._chartWidgetCollection.selectedSources.value().filter(h.isLineTool)
                }
                hide() {
                    var t;
                    this._updateVisibilityTimeout && clearTimeout(this._updateVisibilityTimeout), this._updateVisibilityTimeout = setTimeout(() => {
                        (0, h.unsetNewToolProperties)(), this._floatingToolbar.hide(!0), this._isToolbarRendered() && this._unmountToolbar(), this._clearProperties(), this._clearCommonButtons()
                    }, 0), null === (t = this._lineToolsDoNotAffectChartInvalidation) || void 0 === t || t.destroy(), delete this._lineToolsDoNotAffectChartInvalidation, delete this._propertyApplier
                }
                _propertyApplierImpl() {
                    return this._propertyApplier || (this._lineToolsDoNotAffectChartInvalidation || (this._lineToolsDoNotAffectChartInvalidation = new ut.FeatureToggleWatchedValue("do_not_invalidate_chart_on_changing_line_tools", !1)), this._propertyApplier = new pt.PropertyApplierWithoutSavingChart(() => this.activeChartWidget().model(), this._lineToolsDoNotAffectChartInvalidation)), this._propertyApplier
                }
                _clearProperties() {
                    this._clearPropertyButtons(), this._lineWidthsProperty && (this._lineWidthsProperty.destroy(), this._lineWidthsProperty = null), this._lineColorsProperty && (this._lineColorsProperty.destroy(), this._lineColorsProperty = null), this._currentProperties && (this._currentProperties = null)
                }
                _show() {
                    this._updateVisibilityTimeout && clearTimeout(this._updateVisibilityTimeout), this._updateVisibilityTimeout = setTimeout(() => {
                        this._renderToolbar(), this._floatingToolbar.show(), this._floatingToolbar.checkPosition()
                    }, 0)
                }
                _addPropertyButton(t) {
                    this._propertyButtons.push(t), this._renderToolbar()
                }
                _addCommonButton(t) {
                    this._commonButtons.push(t), this._renderToolbar()
                }
                _addTemplatesButton(t) {
                    this._templatesButton = t
                }
                _renderToolbar() {
                    null !== this._container && this.activeChartWidget() && this.activeChartWidget().hasModel() && (n.render(i.createElement(T, {
                        templateButton: this._templatesButton,
                        propertyButtons: this._propertyButtons,
                        commonButtons: this._commonButtons,
                        isDrawingFinished: this._isDrawingFinished.value(),
                        activeChartWidget: this.activeChartWidget()
                    }), this._container), this._toolbarRendered = !0)
                }
                _unmountToolbar() {
                    null !== this._container && (n.unmountComponentAtNode(this._container), this._toolbarRendered = !1)
                }
                _clearTemplatesButton() {
                    this._templatesButton = null
                }
                _clearPropertyButtons() {
                    this._propertyButtons = []
                }
                _clearCommonButtons() {
                    this._commonButtons = []
                }
                _isToolbarRendered() {
                    return this._toolbarRendered
                }
                _createSettingsButton() {
                    const t = {
                        component: x,
                        props: {
                            title: _t,
                            activeChartWidget: this.activeChartWidget()
                        }
                    };
                    this._addCommonButton(t)
                }
                _createLockButton() {
                    const t = {
                        component: N,
                        props: {
                            title: "Lock",
                            activeChartWidget: this.activeChartWidget()
                        }
                    };
                    this._addCommonButton(t)
                }
                _createRemoveButton() {
                    const t = {
                        component: R,
                        props: {
                            title: vt,
                            activeChartWidget: this.activeChartWidget()
                        },
                        showForSmallScreen: !0
                    };
                    this._addCommonButton(t)
                }
                _createDotsButton() {
                    this._addCommonButton({
                        component: Z,
                        props: {
                            title: wt,
                            activeChartWidget: this.activeChartWidget()
                        },
                        showForSmallScreen: !0
                    })
                }
                _createAlertButton() {}
                _createSourceActions() {
                    this._createLockButton()
                }
                _createLineStyleButton(t) {
                    const e = this.selectedSources();
                    if (0 === e.length) return !1;
                    const o = e[0];
                    if (!(0, ht.isDataSource)(o)) return !1;
                    const i = {
                        component: it,
                        props: {
                            property: o.properties().linestyle || t,
                            title: ft,
                            propertyApplier: this._propertyApplierImpl(),
                            "data-name": "style",
                            undoText: gt
                        }
                    };
                    return this._addPropertyButton(i), !0
                }
                _createFontSizeButton(t) {
                    const e = this.selectedSources();
                    if (0 === e.length) return !1;
                    const o = e[0];
                    if (!(0, ht.isDataSource)(o)) return !1;
                    const i = {
                        component: st,
                        props: {
                            property: o.properties().fontsize || t,
                            title: yt,
                            propertyApplier: this._propertyApplierImpl(),
                            "data-name": "font-size",
                            undoText: mt
                        }
                    };
                    return this._addPropertyButton(i), !0
                }
                _createCommonButtons() {
                    this._commonButtons.length && this._clearCommonButtons(), a.enabled("property_pages") && this._createSettingsButton(), this._createSourceActions(), this._createRemoveButton(), this._createDotsButton()
                }
                _prepareProperties(t) {
                    const e = this.selectedSources().filter(e => e.properties()[t]);
                    if (!(e.filter(e => e.properties()[t].visible()).length < 1)) return e.map(e => e.properties()[t]).filter(d.notNull)
                }
                _createProperty(t, e, o, i) {
                    if (e) {
                        const t = this._prepareProperties(o);
                        if (!t) return;
                        return this._isWidthProperty(t[0]) ? new v(new u.MultipleLineWidthsProperty(t), this._propertyApplierImpl(), i) : new w.CollectibleColorPropertyUndoWrapper(new u.MultipleLineColorsProperty(t), this._propertyApplierImpl(), i)
                    }
                    if (t && t.visible()) return this._isWidthProperty(t) ? new u.MultipleLineWidthsProperty([t]) : new w.CollectibleColorPropertyDirectWrapper(new u.MultipleLineColorsProperty([t]))
                }
                _shouldShowBackgroundProperty(t, e) {
                    return !e || !e.fillBackground || !!e.fillBackground.value()
                }
                _isDrawingToolExcludingCustomUrlEventTool(t) {
                    return Boolean(null == t ? void 0 : t.toLowerCase().includes("linetool")) && "LineToolTweet" !== t && "LineToolIdea" !== t && "LineToolImage" !== t
                }
                _isWidthProperty(t) {
                    return t instanceof u.LineToolWidthsProperty
                }
            }
        },
        67358: (t, e, o) => {
            "use strict";
            o.r(e), o.d(e, {
                LinetoolTemplatesList: () => c
            });
            var i = o(25177),
                n = o(38239),
                r = o(9565),
                s = o(17501),
                a = o(90266),
                l = o(53055);
            class c {
                constructor(t, e) {
                    this._toolName = t, this._applyTemplate = e, this._templatesDeferred = this._loadData()
                }
                getData() {
                    return n.store.getState().templates[this._toolName]
                }
                templatesLoaded() {
                    return this._templatesDeferred
                }
                loadTemplate(t, e) {
                    n.store.dispatch((0, r.loadTemplate)(this._toolName, t, t => {
                        this._applyTemplate(t), null == e || e()
                    }))
                }
                removeTemplate(t) {
                    n.store.dispatch((0, r.startRemoveTemplate)(this._toolName, t))
                }
                saveTemplate(t, e) {
                    const o = (0, s.clean)(t);
                    n.store.dispatch((0, r.saveTemplate)(this._toolName, o, e))
                }
                deleteAction(t) {
                    (0, a.runOrSignIn)(() => {
                        const e = (0, i.t)("Do you really want to delete Drawing Template '{name}' ?", {
                            replace: {
                                name: t
                            }
                        });
                        (0, l.showConfirm)({
                            text: e,
                            onConfirm: e => {
                                this.removeTemplate(t), e.dialogClose()
                            }
                        })
                    }, {
                        source: "Delete line tool template"
                    })
                }
                showSaveDialog(t) {
                    (0, a.runOrSignIn)(() => {
                        (0, l.showRename)({
                            title: (0, i.t)("Save Drawing Template As"),
                            text: (0, i.t)("Template name") + ":",
                            maxLength: 64,
                            onRename: e => {
                                if (-1 !== (this.getData() || []).indexOf(e.newValue)) {
                                    const o = (0, i.t)("Drawing Template '{name}' already exists. Do you really want to replace it?", {
                                        replace: {
                                            name: e.newValue
                                        }
                                    });
                                    (0, l.showConfirm)({
                                        text: o,
                                        onConfirm: o => {
                                            t(e.newValue), o.dialogClose(), e.dialogClose()
                                        },
                                        onClose: e.focusInput
                                    }, e.innerManager)
                                } else t(e.newValue), e.dialogClose()
                            }
                        })
                    }, {
                        source: "Save line tool template",
                        sourceMeta: "Chart"
                    })
                }
                async _loadData() {
                    return new Promise(t => {
                        this.getData() ? t() : n.store.dispatch((0, r.getTemplates)(this._toolName, t))
                    })
                }
            }
        },
        80300: (t, e, o) => {
            "use strict";
            var i = o(25177).t,
                n = o(18517).TranslatedString,
                r = o(93546),
                s = o(67358).LinetoolTemplatesList,
                a = o(62181).TemplateButton,
                l = o(16062).DefaultProperty,
                c = o(9371).LineToolPropertiesWidgetBase,
                d = o(14162).isLineDrawnWithPressedButton;
            const h = o(23847).ColorPickerButton,
                p = o(22598).LineWidthButton;
            var u = o(5796).setNewToolProperties;
            const m = o(82527);
            var g = (!m.enabled("widget") || window.is_authenticated) && m.enabled("linetoolpropertieswidget_template_button"),
                _ = o(65652),
                v = o(65616),
                w = o(48427),
                f = new n("apply drawing template", i("apply drawing template")),
                y = new n("change line tool(s) color", i("change line tool(s) color")),
                b = new n("change line tool(s) background color", i("change line tool(s) background color")),
                C = new n("change line tool(s) text color", i("change line tool(s) text color")),
                T = new n("change line tool(s) line width", i("change line tool(s) line width")),
                E = i("Color"),
                S = i("Line tool colors"),
                P = i("Text color"),
                x = i("Line tool text colors"),
                L = i("Background color"),
                W = i("Line tool backgrounds"),
                k = i("Style"),
                A = i("Font Size"),
                B = i("Line tool width"),
                D = i("Line tool widths"),
                M = i("Profit background color"),
                N = i("Stop background color"),
                I = i("Marker color"),
                R = i("Background color 1"),
                V = i("Background color 2");
            class F extends c {
                constructor(t) {
                    super(t), this._hasAlertWathcedValue = null, this._templatesButton = null
                }
                _onToolChanged(t, e) {
                    this._currentTool = t;
                    const o = this.selectedSources();
                    if (this._isDrawingToolExcludingCustomUrlEventTool(t)) {
                        if (this._isDrawingFinished.setValue(!1), g) {
                            var i = e instanceof l;
                            e = i ? e : u(t, "LineToolIcon" === t ? r.iconTool.value() : void 0, this._chartWidgetCollection.activeChartWidget.value().model().model()), this.showPropertiesOf(t, e, i), this.showTemplatesOf({
                                tool: t,
                                properties: e
                            }), this._toolbarVisible = !0
                        }
                        this._updateVisibility()
                    } else o && o.length ? (o.length > 1 && this._isDrawingFinished.setValue(!0), this.onSourceChanged(this.selectedSources())) : this.hide()
                }
                findSourceOnWidget(t) {
                    for (var e = 0; e < this.activeChartWidget().model().panes().length; e++)
                        for (var o = this.activeChartWidget().model().panes()[e].sourcesByGroup().all(), i = 0; i < o.length; i++)
                            if (o[i] === t) return o[i]
                }
                onSourceChanged(t) {
                    if (this._hasAlertWathcedValue && (this._hasAlertWathcedValue.destroy(), this._hasAlertWathcedValue = null), !t || !t.length) return this._propertiesVisible = !1, this._toolbarVisible = !1, void this.hide();
                    if (this._createCommonButtons(), 1 === t.length) {
                        var e = t[0];
                        e.isAvailableInFloatingWidget() && this.findSourceOnWidget(e) ? (!e.userEditEnabled() || !d(e.toolname) && this.activeChartWidget().model().lineBeingCreated() || (this._isDrawingFinished.setValue(!0), e.canHasAlert() && (this._hasAlertWathcedValue = e.hasAlert.spawn())), this.showPropertiesOf(e.toolname, e.properties(), !0), this.showTemplatesOf({
                            source: e
                        }), this._toolbarVisible = !0) : this.hide()
                    } else this._clearProperties(), this._templatesButton && (this._clearTemplatesButton(), this._templatesButton = null), this._createWidthsButton(void 0, !0), this._createColorsButton(void 0, !0), this._createBackgroundsButton(void 0, !0), this._createTextColorsButton(void 0, !0), this._propertiesVisible = !0;
                    this._updateVisibility()
                }
                _createWidthsButton(t, e) {
                    if (this._lineWidthsProperty && (this._lineWidthsProperty.destroy(), this._lineWidthsProperty = null), this._lineWidthsProperty = this._createProperty(t, e, "linesWidths", T), !this._lineWidthsProperty) return !0;
                    var o = B;
                    e && (1 !== this.selectedSources().filter(t => t.properties().linesWidths).length && (o = D));
                    return this._addPropertyButton({
                        component: p,
                        props: {
                            title: o,
                            multipleProperty: this._lineWidthsProperty,
                            propertyApplier: this._propertyApplierImpl(),
                            "data-name": "line-tool-width",
                            undoText: T
                        }
                    }), !0
                }
                _createColorsButton(t, e) {
                    return this._lineColorsProperty && (this._lineColorsProperty.destroy(), this._lineColorsProperty = null), this._lineColorsProperty = this._createProperty(t, e, "linesColors", y), !this._lineColorsProperty || (this._addPropertyButton({
                        component: h,
                        props: {
                            icon: _,
                            title: S,
                            property: this._lineColorsProperty,
                            propertyApplier: this._propertyApplierImpl(),
                            "data-name": "line-tool-color",
                            undoText: y
                        }
                    }), !0)
                }
                _createBackgroundsButton(t, e) {
                    return this._backgroundsProperty && (this._backgroundsProperty.destroy(), this._backgroundsProperty = null), this._backgroundsProperty = this._createProperty(t, e, "backgroundsColors", b), !this._backgroundsProperty || (this._addPropertyButton({
                        component: h,
                        props: {
                            icon: v,
                            title: W,
                            property: this._backgroundsProperty,
                            propertyApplier: this._propertyApplierImpl(),
                            "data-name": "background-color",
                            undoText: b
                        }
                    }), !0)
                }
                _createTextColorsButton(t, e) {
                    return this._textColorsProperty && (this._textColorsProperty.destroy(), this._textColorsProperty = null), this._textColorsProperty = this._createProperty(t, e, "textsColors", C), !this._textColorsProperty || (this._addPropertyButton({
                        component: h,
                        props: {
                            icon: w,
                            title: x,
                            property: this._textColorsProperty,
                            propertyApplier: this._propertyApplierImpl(),
                            "data-name": "text-color",
                            undoText: C
                        }
                    }), !0)
                }
                showTemplatesOf(t) {
                    if (m.enabled("drawing_templates")) {
                        var e, o, i = t.source;
                        i ? (e = i.toolname, o = i.properties()) : (e = t.tool, o = t.properties), this._templatesButton && (this._clearTemplatesButton(), this._templatesButton = null);
                        var n = this;
                        g && (this._templatesList = new s(e, (function(t) {
                            i ? (n.activeChartWidget().model().applyLineToolTemplate(i, t, f), n.onSourceChanged([i])) : (o.mergeAndFire(t), o.saveDefaults(), n.onToolChanged(e, o))
                        })), this._templatesButton = {
                            component: a,
                            props: {
                                key: "Templates",
                                model: this._templatesList,
                                onSave: i ? () => i.template() : void 0,
                                onRestore: () => {
                                    void 0 !== i ? this.activeChartWidget().model().restorePropertiesForSource(i) : o.restoreFactoryDefaults(), this.showPropertiesOf(e, o)
                                }
                            }
                        }, this._addTemplatesButton(this._templatesButton))
                    }
                }
                templatesList() {
                    return this._templatesList
                }
                _getPossibleProperty(t) {
                    for (var e = [], o = this._defaultToolProperties(), i = 0; i < o.length; i++) {
                        var n = o[i];
                        n.name in t && e.push(n)
                    }
                    return e
                }
                showPropertiesOf(t, e, o) {
                    this._toolExceptionCases || (this._toolExceptionCases = this._createToolExceptionCases());
                    var i = this._toolExceptionCases[t] || this._getPossibleProperty(e);
                    if (this._clearProperties(), this._propertiesVisible = !1, i.length) {
                        for (var n = {}, r = 0; r < i.length; r++) {
                            for (var s = i[r], a = e, l = s.name.split("."), c = 0; c < l.length; ++c) a = a && a[l[c]];
                            var d = s.showIf;
                            if ("function" != typeof d || d(a, e)) {
                                var p = s.factory;
                                if (p && p.call(this, a, o)) continue;
                                if (!a) continue;
                                if (this._propertiesVisible = !0, "combobox" !== s.inputType) {
                                    const t = {
                                        component: h,
                                        props: {
                                            icon: s.iconSvgCode,
                                            title: s.title,
                                            "data-name": s.dataName,
                                            property: a,
                                            propertyApplier: this._propertyApplierImpl(),
                                            undoText: s.undoText
                                        }
                                    };
                                    this._addPropertyButton(t);
                                    continue
                                }
                                n[s.name] = a
                            }
                        }
                        this._currentProperties = n
                    }
                }
                _updateVisibility() {
                    (g || this._isDrawingFinished.value()) && (this._toolbarVisible || this._propertiesVisible) ? this._show(): this.hide()
                }
                refresh() {
                    this.onSourceChanged(this.selectedSources())
                }
                _defaultToolProperties() {
                    return [{
                        name: "linesColors",
                        inputType: "colorPicker",
                        iconSvgCode: _,
                        title: E,
                        factory: F.prototype._createColorsButton,
                        dataName: "line-tool-color"
                    }, {
                        name: "backgroundsColors",
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        title: L,
                        factory: F.prototype._createBackgroundsButton,
                        dataName: "background-color",
                        showIf: this._shouldShowBackgroundProperty
                    }, {
                        name: "textsColors",
                        title: P,
                        inputType: "colorPicker",
                        iconSvgCode: w,
                        factory: F.prototype._createTextColorsButton,
                        dataName: "text-color"
                    }, {
                        name: "linesWidths",
                        inputType: "combobox",
                        factory: F.prototype._createWidthsButton
                    }, {
                        name: "linestyle",
                        title: k,
                        inputType: "combobox",
                        factory: F.prototype._createLineStyleButton
                    }]
                }
                _regressionToolExceptionCases() {
                    return [{
                        name: "linesWidths",
                        inputType: "combobox",
                        factory: F.prototype._createWidthsButton
                    }]
                }
                _pathExceptionCases() {
                    return [{
                        name: "linesColors",
                        inputType: "colorPicker",
                        iconSvgCode: _,
                        title: E,
                        factory: F.prototype._createColorsButton,
                        dataName: "line-tool-color"
                    }, {
                        name: "linesWidths",
                        inputType: "combobox",
                        factory: F.prototype._createWidthsButton
                    }, {
                        name: "lineStyle",
                        title: k,
                        inputType: "combobox",
                        factory: F.prototype._createLineStyleButton
                    }]
                }
                _riskPropertiesExceptionCases() {
                    return [{
                        name: "textcolor",
                        title: P,
                        inputType: "colorPicker",
                        iconSvgCode: w,
                        dataName: "text-color",
                        undoText: C
                    }, {
                        name: "profitBackground",
                        title: M,
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        dataName: "background-color",
                        undoText: b
                    }, {
                        name: "stopBackground",
                        title: N,
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        dataName: "background-color",
                        undoText: b
                    }]
                }
                _rangeExceptionCases() {
                    return [{
                        name: "linecolor",
                        inputType: "colorPicker",
                        iconSvgCode: _,
                        title: E,
                        dataName: "line-tool-color",
                        undoText: y
                    }, {
                        name: "backgroundColor",
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        title: L,
                        dataName: "background-color",
                        showIf: this._shouldShowBackgroundProperty,
                        undoText: b
                    }, {
                        name: "linesWidths",
                        inputType: "combobox",
                        factory: F.prototype._createWidthsButton
                    }]
                }
                _brushPropertiesExceptionCase() {
                    return [{
                        name: "linesColors",
                        inputType: "colorPicker",
                        iconSvgCode: _,
                        title: E,
                        factory: F.prototype._createColorsButton,
                        dataName: "line-tool-color"
                    }, {
                        name: "backgroundsColors",
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        title: L,
                        dataName: "background-color",
                        factory: F.prototype._createBackgroundsButton
                    }, {
                        name: "linesWidths",
                        inputType: "combobox",
                        factory: F.prototype._createWidthsButton
                    }]
                }
                _bezierPropertiesExceptionCases() {
                    return [{
                        name: "linesColors",
                        inputType: "colorPicker",
                        iconSvgCode: _,
                        title: E,
                        factory: F.prototype._createColorsButton,
                        dataName: "line-tool-color"
                    }, {
                        name: "backgroundsColors",
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        dataName: "background-color",
                        title: L,
                        factory: F.prototype._createBackgroundsButton,
                        showIf: this._shouldShowBackgroundProperty
                    }, {
                        name: "linesWidths",
                        inputType: "combobox",
                        factory: F.prototype._createWidthsButton
                    }, {
                        name: "linestyle",
                        title: k,
                        inputType: "combobox",
                        factory: F.prototype._createLineStyleButton
                    }]
                }
                _textPropertiesExceptionCases() {
                    return [{
                        name: "color",
                        title: P,
                        inputType: "colorPicker",
                        iconSvgCode: w,
                        dataName: "text-color",
                        undoText: C
                    }, {
                        name: "backgroundColor",
                        title: L,
                        inputType: "colorPicker",
                        iconSvgCode: v,
                        dataName: "background-color",
                        showIf: this._shouldShowBackgroundProperty,
                        undoText: b
                    }, {
                        name: "fontsize",
                        title: A,
                        inputType: "combobox",
                        factory: F.prototype._createFontSizeButton
                    }]
                }
                _notePropertiesExceptionCases() {
                    return [{
                        name: "markerColor",
                        title: I,
                        inputType: "colorPicker",
                        iconSvgCode: _,
                        dataName: "line-tool-color",
                        undoText: y
                    }, {
                        name: "textColor",
                        title: P,
                        inputType: "colorPicker",
                        iconSvgCode: w,
                        dataName: "text-color",
                        undoText: C
                    }, {
                        name: "fontSize",
                        title: A,
                        inputType: "combobox",
                        factory: F.prototype._createFontSizeButton
                    }]
                }
                _createToolExceptionCases() {
                    return {
                        LineToolBrush: F.prototype._brushPropertiesExceptionCase(),
                        LineToolBezierQuadro: F.prototype._bezierPropertiesExceptionCases(),
                        LineToolBezierCubic: F.prototype._bezierPropertiesExceptionCases(),
                        LineToolText: F.prototype._textPropertiesExceptionCases(),
                        LineToolTextAbsolute: F.prototype._textPropertiesExceptionCases(),
                        LineToolBalloon: F.prototype._textPropertiesExceptionCases(),
                        LineToolCallout: F.prototype._textPropertiesExceptionCases(),
                        LineToolPriceLabel: F.prototype._textPropertiesExceptionCases(),
                        LineToolDateRange: F.prototype._rangeExceptionCases(),
                        LineToolPriceRange: F.prototype._rangeExceptionCases(),
                        LineToolDateAndPriceRange: F.prototype._rangeExceptionCases(),
                        LineToolNote: F.prototype._notePropertiesExceptionCases(),
                        LineToolNoteAbsolute: F.prototype._notePropertiesExceptionCases(),
                        LineToolRiskRewardLong: F.prototype._riskPropertiesExceptionCases(),
                        LineToolRiskRewardShort: F.prototype._riskPropertiesExceptionCases(),
                        LineToolPath: F.prototype._pathExceptionCases(),
                        LineToolRegressionTrend: F.prototype._regressionToolExceptionCases(),
                        LineToolBarsPattern: [{
                            name: "color",
                            title: E,
                            inputType: "colorPicker",
                            iconSvgCode: v,
                            dataName: "background-color",
                            undoText: y
                        }],
                        LineToolProjection: [{
                            name: "color1",
                            title: R,
                            inputType: "colorPicker",
                            iconSvgCode: v,
                            dataName: "background-color",
                            undoText: b
                        }, {
                            name: "color2",
                            title: V,
                            inputType: "colorPicker",
                            iconSvgCode: v,
                            dataName: "background-color",
                            undoText: b
                        }, {
                            name: "linesWidths",
                            inputType: "combobox",
                            factory: F.prototype._createWidthsButton
                        }],
                        LineToolSignpost: [{
                            name: "linesColors",
                            inputType: "colorPicker",
                            iconSvgCode: v,
                            dataName: "background-color",
                            title: E,
                            factory: F.prototype._createBackgroundsButton,
                            showIf: function(t, e) {
                                return e && e.showImage.value()
                            }
                        }, {
                            name: "fontSize",
                            title: A,
                            inputType: "combobox",
                            factory: F.prototype._createFontSizeButton
                        }]
                    }
                }
            }
            t.exports = F
        },
        9565: (t, e, o) => {
            "use strict";
            o.d(e, {
                getTemplates: () => n,
                setTemplates: () => r,
                addTemplate: () => s,
                startRemoveTemplate: () => a,
                removeTemplate: () => l,
                saveTemplate: () => c,
                loadTemplate: () => d,
                applyDefaults: () => h
            });
            var i = o(48583);

            function n(t, e) {
                return {
                    type: i.GET_TEMPLATES,
                    toolName: t,
                    callback: e
                }
            }

            function r(t, e) {
                return {
                    type: i.SET_TEMPLATES,
                    templates: e,
                    toolName: t
                }
            }

            function s(t, e) {
                return {
                    type: i.ADD_TEMPLATE,
                    templateName: e,
                    toolName: t
                }
            }

            function a(t, e) {
                return {
                    type: i.START_REMOVE_TEMPLATE,
                    templateName: e,
                    toolName: t
                }
            }

            function l(t, e) {
                return {
                    type: i.REMOVE_TEMPLATE,
                    templateName: e,
                    toolName: t
                }
            }

            function c(t, e, o) {
                return {
                    type: i.SAVE_TEMPLATE,
                    templateName: e,
                    toolName: t,
                    content: o
                }
            }

            function d(t, e, o) {
                return {
                    type: i.LOAD_TEMPLATE,
                    toolName: t,
                    templateName: e,
                    callback: o
                }
            }

            function h(t, e) {
                return {
                    type: i.APPLY_DEFAULTS,
                    model: t,
                    source: e
                }
            }
        },
        48583: (t, e, o) => {
            "use strict";

            function i(t) {
                return "LINE_TOOL_TEMPLATE__" + t
            }
            o.d(e, {
                GET_TEMPLATES: () => n,
                SET_TEMPLATES: () => r,
                START_REMOVE_TEMPLATE: () => s,
                REMOVE_TEMPLATE: () => a,
                SAVE_TEMPLATE: () => l,
                ADD_TEMPLATE: () => c,
                LOAD_TEMPLATE: () => d,
                APPLY_DEFAULTS: () => h
            });
            const n = i("GET_TEMPLATES"),
                r = i("SET_TEMPLATES"),
                s = i("START_REMOVE_TEMPLATE"),
                a = i("REMOVE_TEMPLATE"),
                l = i("SAVE_TEMPLATE"),
                c = i("ADD_TEMPLATE"),
                d = i("LOAD_TEMPLATE"),
                h = i("APPLY_DEFAULTS")
        },
        38239: (t, e, o) => {
            "use strict";
            o.d(e, {
                store: () => T
            });
            var i = o(83243),
                n = o(54773),
                r = o(36349),
                s = o(88537),
                a = o(48583),
                l = o(51951),
                c = o(9565);

            function d(t, e) {
                return e
            }
            var h = o(19013);
            const p = (0, l.getLogger)("Chart.LineToolTemplatesList");

            function u(t, e) {
                return e
            }

            function* m() {
                for (;;) {
                    const {
                        toolName: t,
                        templateName: e,
                        content: o
                    } = u(a.SAVE_TEMPLATE, yield(0, r.take)(a.SAVE_TEMPLATE));
                    try {
                        yield(0, r.call)(h.backend.saveDrawingTemplate, t, e, o), yield(0, r.put)((0, c.addTemplate)(t, e))
                    } catch (t) {
                        p.logWarn(t)
                    }
                }
            }

            function* g() {
                for (;;) {
                    const {
                        toolName: t,
                        templateName: e
                    } = u(a.START_REMOVE_TEMPLATE, yield(0, r.take)(a.START_REMOVE_TEMPLATE));
                    try {
                        yield(0, r.call)(h.backend.removeDrawingTemplate, t, e), yield(0, r.put)((0, c.removeTemplate)(t, e))
                    } catch (t) {
                        p.logWarn(t)
                    }
                }
            }

            function* _() {
                const t = new Map;
                for (;;) {
                    const {
                        toolName: o,
                        callback: i
                    } = u(a.GET_TEMPLATES, yield(0, r.take)(a.GET_TEMPLATES));
                    t.has(o) ? (0, s.ensureDefined)(t.get(o)).push(i) : (t.set(o, [i]), yield(0, r.fork)(e, o))
                }

                function* e(e) {
                    try {
                        const t = d(h.backend.getDrawingTemplates, yield(0, r.call)(h.backend.getDrawingTemplates, e));
                        yield(0, r.put)((0, c.setTemplates)(e, t))
                    } catch (t) {
                        p.logWarn(t)
                    }(0, s.ensureDefined)(t.get(e)).forEach(t => null == t ? void 0 : t()), t.delete(e)
                }
            }

            function* v() {
                for (;;) {
                    const {
                        toolName: t,
                        templateName: e,
                        callback: o
                    } = u(a.LOAD_TEMPLATE, yield(0, r.take)(a.LOAD_TEMPLATE));
                    try {
                        const i = d(h.backend.loadDrawingTemplate, yield(0, r.call)(h.backend.loadDrawingTemplate, t, e));
                        o && o(i)
                    } catch (t) {
                        p.logWarn(t)
                    }
                }
            }

            function* w() {
                for (;;) {
                    const {
                        model: t,
                        source: e
                    } = u(a.APPLY_DEFAULTS, yield(0, r.take)(a.APPLY_DEFAULTS));
                    try {
                        yield(0, r.call)([t, t.restorePropertiesForSource], e)
                    } catch (t) {
                        p.logWarn(t)
                    }
                }
            }

            function* f() {
                yield(0, r.all)([(0, r.call)(_), (0, r.call)(m), (0, r.call)(g), (0, r.call)(v), (0, r.call)(w)])
            }
            const y = {
                templates: {}
            };

            function b(t, e) {
                return t.localeCompare(e, void 0, {
                    numeric: !0
                })
            }

            function C(t = y, e) {
                switch (e.type) {
                    case a.ADD_TEMPLATE:
                        {
                            const {
                                toolName: o,
                                templateName: i
                            } = e;
                            if (!t.templates[o].includes(i)) {
                                const e = [...t.templates[o], i].sort(b);
                                return { ...t,
                                    templates: { ...t.templates,
                                        [o]: e
                                    }
                                }
                            }
                            return t
                        }
                    case a.SET_TEMPLATES:
                        {
                            const {
                                toolName: o,
                                templates: i
                            } = e;
                            return { ...t,
                                templates: { ...t.templates,
                                    [o]: [...i].sort(b)
                                }
                            }
                        }
                    case a.REMOVE_TEMPLATE:
                        {
                            const {
                                toolName: o,
                                templateName: i
                            } = e;
                            return { ...t,
                                templates: { ...t.templates,
                                    [o]: t.templates[o].filter(t => t !== i)
                                }
                            }
                        }
                    default:
                        return t
                }
            }
            const T = function() {
                const t = (0, n.default)(),
                    e = (0, i.createStore)(C, (0, i.applyMiddleware)(t));
                return t.run(f), e
            }()
        },
        85067: (t, e, o) => {
            "use strict";
            o.d(e, {
                CollectibleColorPropertyUndoWrapper: () => a,
                CollectibleColorPropertyDirectWrapper: () => l
            });
            var i = o(88537),
                n = o(86712),
                r = o.n(n);
            class s extends(r()) {
                constructor(t) {
                    super(), this._listenersMappers = [], this._isProcess = !1, this._baseProperty = t
                }
                destroy() {
                    this._baseProperty.destroy()
                }
                value() {
                    const t = this._baseProperty.value();
                    return "mixed" === t ? "" : t
                }
                visible() {
                    return this._baseProperty.visible()
                }
                setValue(t) {
                    this._isProcess = !0, this._baseProperty.setValue("" === t ? "mixed" : t, void 0, {
                        applyValue: this._applyValue.bind(this)
                    }), this._isProcess = !1, this._listenersMappers.forEach(t => {
                        t.method.call(t.obj, this)
                    })
                }
                subscribe(t, e) {
                    const o = o => {
                            this._isProcess || e.call(t, this)
                        },
                        i = {
                            obj: t,
                            method: e,
                            callback: o
                        };
                    this._listenersMappers.push(i), this._baseProperty.subscribe(t, o)
                }
                unsubscribe(t, e) {
                    var o;
                    const n = (0, i.ensureDefined)(null === (o = this._listenersMappers.find(o => o.obj === t && o.method === e)) || void 0 === o ? void 0 : o.callback);
                    this._baseProperty.unsubscribe(t, n)
                }
                unsubscribeAll(t) {
                    this._baseProperty.unsubscribeAll(t)
                }
            }
            class a extends s {
                constructor(t, e, o) {
                    super(t), this._propertyApplier = e, this._undoText = o
                }
                _applyValue(t, e) {
                    this._propertyApplier.setProperty(t, e, this._undoText)
                }
            }
            class l extends s {
                _applyValue(t, e) {
                    t.setValue(e)
                }
            }
        },
        64840: (t, e, o) => {
            "use strict";
            o.d(e, {
                PropertyApplierWithoutSavingChart: () => i
            });
            class i {
                constructor(t, e) {
                    this._undoModelSupplier = t, this._featureToggle = e
                }
                setProperty(t, e, o) {
                    this._undoModelSupplier().setProperty(t, e, o, this._featureToggle.value())
                }
                beginUndoMacro(t) {
                    return this._undoModelSupplier().beginUndoMacro(t, this._shouldWeKeepChartValidated())
                }
                endUndoMacro() {
                    this._undoModelSupplier().endUndoMacro()
                }
                setWatchedValue(t, e, o) {
                    this._undoModelSupplier().undoHistory().setWatchedValue(t, e, o, !0)
                }
                _shouldWeKeepChartValidated() {
                    const t = this._undoModelSupplier().model().isAutoSaveEnabled().value();
                    return this._featureToggle.value() && t
                }
            }
        },
        96818: (t, e, o) => {
            "use strict";
            o.d(e, {
                Draggable: () => a,
                PointerBackend: () => l
            });
            var i = o(88537),
                n = o(2369),
                r = o(1227),
                s = o(72535);
            class a {
                constructor(t) {
                    var e, o;
                    this._helper = null, this._handleDragStart = t => {
                        var e;
                        if (null !== this._helper) return;
                        const o = this._source;
                        o.classList.add("ui-draggable-dragging");
                        const [i, r] = [(0, n.outerWidth)(o), (0, n.outerHeight)(o)];
                        this._helper = {
                            startTop: parseFloat(o.style.top) || 0,
                            startLeft: parseFloat(o.style.left) || 0,
                            nextTop: null,
                            nextLeft: null,
                            raf: null,
                            size: [i, r],
                            containment: this._containment instanceof HTMLElement ? [parseInt(getComputedStyle(this._containment).borderLeftWidth) + parseInt(getComputedStyle(this._containment).paddingLeft), parseInt(getComputedStyle(this._containment).borderTopWidth) + parseInt(getComputedStyle(this._containment).paddingTop), this._containment.offsetWidth - parseInt(getComputedStyle(this._containment).borderRightWidth) - parseInt(getComputedStyle(this._containment).paddingRight) - parseInt(getComputedStyle(o).marginLeft) - parseInt(getComputedStyle(o).marginRight) - i, this._containment.offsetHeight - parseInt(getComputedStyle(this._containment).borderBottomWidth) - parseInt(getComputedStyle(this._containment).paddingBottom) - parseInt(getComputedStyle(o).marginTop) - parseInt(getComputedStyle(o).marginBottom) - r] : "window" === this._containment ? [window.scrollX, window.scrollY, window.scrollX + document.documentElement.offsetWidth - i, window.scrollY + document.documentElement.offsetHeight - r] : null
                        }, null === (e = this._start) || void 0 === e || e.call(this)
                    }, this._handleDragMove = t => {
                        var e;
                        if (null === this._helper) return;
                        const {
                            current: o,
                            initial: i
                        } = t.detail, n = this._source, r = this._helper.nextTop, s = this._helper.nextLeft, a = "y" === this._axis || !1 === this._axis || 0 !== o.movementY;
                        if (a) {
                            const t = this._helper.startTop;
                            isFinite(t) && (this._helper.nextTop = o.clientY - i.clientY + t)
                        }
                        const l = "x" === this._axis || !1 === this._axis || 0 !== o.movementY;
                        if (l) {
                            const t = this._helper.startLeft;
                            isFinite(t) && (this._helper.nextLeft = o.clientX - i.clientX + t)
                        }
                        if (null !== this._helper.containment) {
                            const [t, e, o, i] = this._helper.containment;
                            a && this._helper.nextTop && (this._helper.nextTop = Math.min(this._helper.nextTop, i), this._helper.nextTop = Math.max(this._helper.nextTop, e)), l && this._helper.nextLeft && (this._helper.nextLeft = Math.min(this._helper.nextLeft, o), this._helper.nextLeft = Math.max(this._helper.nextLeft, t))
                        }
                        null !== this._helper.raf || r === this._helper.nextTop && s === this._helper.nextLeft || (this._helper.raf = requestAnimationFrame(() => {
                            null !== this._helper && (null !== this._helper.nextTop && (n.style.top = this._helper.nextTop + "px", this._helper.nextTop = null), null !== this._helper.nextLeft && (n.style.left = this._helper.nextLeft + "px", this._helper.nextLeft = null), this._helper.raf = null)
                        })), null === (e = this._drag) || void 0 === e || e.call(this)
                    }, this._handleDragStop = t => {
                        var e;
                        if (null === this._helper) return;
                        this._source.classList.remove("ui-draggable-dragging"), this._helper = null, null === (e = this._stop) || void 0 === e || e.call(this)
                    };
                    const i = this._source = t.source;
                    i.classList.add("ui-draggable");
                    const r = this._handle = null !== (e = t.handle ? i.querySelector(t.handle) : null) && void 0 !== e ? e : i;
                    r.classList.add("ui-draggable-handle"), this._start = t.start, this._stop = t.stop, this._drag = t.drag, this._backend = new l({
                        handle: r,
                        onDragStart: this._handleDragStart,
                        onDragMove: this._handleDragMove,
                        onDragStop: this._handleDragStop
                    }), this._axis = null !== (o = t.axis) && void 0 !== o && o, this._containment = t.containment
                }
                destroy() {
                    const t = this._source;
                    t.classList.remove("ui-draggable"), t.classList.remove("ui-draggable-dragging");
                    this._handle.classList.remove("ui-draggable-handle"), this._backend.destroy(),
                        null !== this._helper && (this._helper.raf && cancelAnimationFrame(this._helper.raf), this._helper = null)
                }
            }
            class l {
                constructor(t) {
                    this._initial = null, this._handlePointerDown = t => {
                        if (null !== this._initial) return;
                        if (!(t.target instanceof Element && this._handle.contains(t.target))) return;
                        if (this._initial = t, !this._dispatchEvent(this._createEvent("pointer-drag-start", t))) return void(this._initial = null);
                        t.preventDefault();
                        const e = this._getEventTarget();
                        e.addEventListener("pointermove", this._handlePointerMove), e.addEventListener("pointerup", this._handlePointerUp), e.addEventListener("pointercancel", this._handlePointerUp), e.addEventListener("lostpointercapture", this._handlePointerUp), e.setPointerCapture(t.pointerId)
                    }, this._handlePointerMove = t => {
                        null !== this._initial && this._initial.pointerId === t.pointerId && (t.preventDefault(), this._dispatchEvent(this._createEvent("pointer-drag-move", t)))
                    }, this._handlePointerUp = t => {
                        if (null === this._initial || this._initial.pointerId !== t.pointerId) return;
                        t.preventDefault();
                        const e = this._getEventTarget();
                        e.removeEventListener("pointermove", this._handlePointerMove), e.removeEventListener("pointerup", this._handlePointerUp), e.removeEventListener("pointercancel", this._handlePointerUp), e.removeEventListener("lostpointercapture", this._handlePointerUp), e.releasePointerCapture(this._initial.pointerId), this._dispatchEvent(this._createEvent("pointer-drag-stop", t)), this._initial = null
                    };
                    const e = this._handle = t.handle;
                    this._onDragStart = t.onDragStart, this._onDragMove = t.onDragMove, this._onDragStop = t.onDragStop, e.style.touchAction = "none";
                    this._getEventTarget().addEventListener("pointerdown", this._handlePointerDown)
                }
                destroy() {
                    this._handle.style.touchAction = "";
                    const t = this._getEventTarget();
                    t.removeEventListener("pointerdown", this._handlePointerDown), t.removeEventListener("pointermove", this._handlePointerMove), t.removeEventListener("pointerup", this._handlePointerUp), t.removeEventListener("pointercancel", this._handlePointerUp), t.removeEventListener("lostpointercapture", this._handlePointerUp), null !== this._initial && (t.releasePointerCapture(this._initial.pointerId), this._initial = null)
                }
                _getEventTarget() {
                    return r.CheckMobile.iOS() || (0, r.isMac)() && s.touch ? window.document.documentElement : this._handle
                }
                _dispatchEvent(t) {
                    switch (t.type) {
                        case "pointer-drag-start":
                            this._onDragStart(t);
                            break;
                        case "pointer-drag-move":
                            this._onDragMove(t);
                            break;
                        case "pointer-drag-stop":
                            this._onDragStop(t)
                    }
                    return !t.defaultPrevented
                }
                _createEvent(t, e) {
                    return (0, i.assert)(null !== this._initial), new CustomEvent(t, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: {
                            backend: this,
                            initial: this._initial,
                            current: e
                        }
                    })
                }
            }
        },
        2369: (t, e, o) => {
            "use strict";
            o.d(e, {
                contentHeight: () => n,
                html: () => a,
                outerHeight: () => r,
                outerWidth: () => s,
                position: () => c
            });
            var i = o(88537);

            function n(t) {
                const {
                    paddingTop: e,
                    paddingBottom: o
                } = window.getComputedStyle(t);
                return [e, o].reduce((t, e) => t - Number((e || "").replace("px", "")), t.clientHeight)
            }

            function r(t, e = !1) {
                const o = getComputedStyle(t),
                    i = [o.height];
                return "border-box" !== o.boxSizing && i.push(o.paddingTop, o.paddingBottom, o.borderTopWidth, o.borderBottomWidth),
                    e && i.push(o.marginTop, o.marginBottom), i.reduce((t, e) => t + (parseFloat(e) || 0), 0)
            }

            function s(t, e = !1) {
                const o = getComputedStyle(t),
                    i = [o.width];
                return "border-box" !== o.boxSizing && i.push(o.paddingLeft, o.paddingRight, o.borderLeftWidth, o.borderRightWidth), e && i.push(o.marginLeft, o.marginRight), i.reduce((t, e) => t + (parseFloat(e) || 0), 0)
            }

            function a(t, e) {
                return void 0 === e || (null === e && (t.innerHTML = ""), "string" != typeof e && "number" != typeof e || (t.innerHTML = String(e))), t
            }

            function l(t) {
                if (!t.getClientRects().length) return {
                    top: 0,
                    left: 0
                };
                const e = t.getBoundingClientRect(),
                    o = (0, i.ensureNotNull)(t.ownerDocument.defaultView);
                return {
                    top: e.top + o.pageYOffset,
                    left: e.left + o.pageXOffset
                }
            }

            function c(t) {
                const e = getComputedStyle(t);
                let o, i = {
                    top: 0,
                    left: 0
                };
                if ("fixed" === e.position) o = t.getBoundingClientRect();
                else {
                    o = l(t);
                    const e = t.ownerDocument;
                    let n = t.offsetParent || e.documentElement;
                    for (; n && (n === e.body || n === e.documentElement) && "static" === getComputedStyle(n).position;) n = n.parentElement;
                    n && n !== t && 1 === n.nodeType && (i = l(n), i.top += parseFloat(getComputedStyle(n).borderTopWidth), i.left += parseFloat(getComputedStyle(n).borderLeftWidth))
                }
                return {
                    top: o.top - i.top - parseFloat(e.marginTop),
                    left: o.left - i.left - parseFloat(e.marginLeft)
                }
            }
        },
        23847: (t, e, o) => {
            "use strict";
            o.d(e, {
                ColorPickerButton: () => _
            });
            var i = o(59496),
                n = o(97754),
                r = o.n(n),
                s = o(88537),
                a = o(72571),
                l = o(24377),
                c = o(76036),
                d = o(6397),
                h = o(57630),
                p = o(60184),
                u = o(34816),
                m = o(34297),
                g = o(69124);

            function _(t) {
                const {
                    property: e,
                    icon: o,
                    propertyApplier: n,
                    title: _,
                    undoText: v,
                    className: w
                } = t, f = (0, m.useProperty)(e), y = (0, i.useRef)(null), b = f ? (0, l.parseRgba)(f)[3] : void 0, C = "" === f, T = String(x()).toLowerCase() === p.white, [E, S, P] = (0, d.useCustomColors)();
                return i.createElement(u.ToolWidgetMenu, {
                    className: w,
                    content: i.createElement("div", {
                        className: g.wrap
                    }, i.createElement(a.Icon, {
                        className: g.icon,
                        icon: o
                    }), i.createElement("div", {
                        className: g.colorBg
                    }, i.createElement("div", {
                        className: r()(g.color, C && g.multicolor, T && g.white),
                        style: C ? void 0 : {
                            backgroundColor: f
                        }
                    }))),
                    arrow: !1,
                    title: _,
                    ref: y,
                    "data-name": t["data-name"],
                    menuDataName: t["data-name"] + "-menu"
                }, i.createElement(h.ColorPicker, {
                    color: x(),
                    opacity: b,
                    onColorChange: function(t, e) {
                        const o = f ? (0, c.alphaToTransparency)((0, l.parseRgba)(f)[3]) : 0;
                        L((0, c.generateColor)(String(t), o, true)), e || (0, s.ensureNotNull)(y.current).close()
                    },
                    onOpacityChange: function(t) {
                        L((0, c.generateColor)(f, (0, c.alphaToTransparency)(t), !0))
                    },
                    selectOpacity: void 0 !== b,
                    selectCustom: !0,
                    customColors: E,
                    onAddColor: function(t) {
                        S(t), (0, s.ensureNotNull)(y.current).close()
                    },
                    onRemoveCustomColor: P
                }));

                function x() {
                    return f ? (0, l.rgbToHexString)((0, l.parseRgb)(f)) : null
                }

                function L(t) {
                    n.setProperty(e, t, v)
                }
            }
        },
        22598: (t, e, o) => {
            "use strict";
            o.d(e, {
                LineWidthButton: () => f
            });
            var i = o(59496),
                n = o(97754),
                r = o(88537),
                s = o(72571),
                a = o(34816),
                l = o(34297),
                c = o(92063),
                d = o(93173),
                h = o(59934),
                p = o(29762),
                u = o(98770),
                m = o(32970),
                g = o(28035),
                _ = o(2680);
            const v = (0, d.mergeThemes)(c.DEFAULT_POPUP_MENU_ITEM_THEME, _),
                w = [{
                    value: 1,
                    icon: h
                }, {
                    value: 2,
                    icon: p
                }, {
                    value: 3,
                    icon: u
                }, {
                    value: 4,
                    icon: m
                }];

            function f(t) {
                const {
                    multipleProperty: e,
                    title: o,
                    undoText: d,
                    propertyApplier: h,
                    className: p,
                    isSmallScreen: u
                } = t, m = (0,
                    l.useProperty)((0, r.ensureDefined)(e)), f = "mixed" === m || !m, y = function(t) {
                    const e = w.find(e => e.value === t);
                    if (!e) return g;
                    return e.icon
                }(m);
                return i.createElement(a.ToolWidgetMenu, {
                    className: p,
                    arrow: !1,
                    title: o,
                    "data-name": t["data-name"],
                    menuDataName: t["data-name"] + "-menu",
                    content: i.createElement("div", null, f ? i.createElement("div", {
                        className: _.multiWidth
                    }, i.createElement(s.Icon, {
                        icon: g
                    })) : i.createElement("div", {
                        className: _.buttonWrap
                    }, !u && i.createElement(s.Icon, {
                        icon: y
                    }), i.createElement("div", {
                        className: n(!u && _.buttonLabel)
                    }, m + "px")))
                }, w.map(({
                    value: t,
                    icon: e
                }) => i.createElement(c.PopupMenuItem, {
                    key: t,
                    theme: v,
                    label: t + "px",
                    icon: e,
                    isActive: t === m,
                    onClick: b,
                    onClickArg: t
                })));

                function b(t) {
                    t && e && (h.beginUndoMacro(d), e.setValue(t, void 0, {
                        applyValue: (t, e) => {
                            h.setProperty(t, e, d)
                        }
                    }), h.endUndoMacro())
                }
            }
        },
        62181: (t, e, o) => {
            "use strict";
            o.d(e, {
                TemplateButton: () => u
            });
            var i = o(59496),
                n = o(72571),
                r = o(25177),
                s = o(32133),
                a = o(18833),
                l = o(34816),
                c = o(28786),
                d = o(90687),
                h = o(76821),
                p = o(74852);

            function u(t) {
                const {
                    model: e,
                    onRestore: o,
                    onSave: u,
                    isDrawingFinished: m,
                    className: g,
                    ..._
                } = t, [v, w] = (0, i.useState)(!1), [f, y] = (0, i.useState)(null), b = (0, i.useRef)(null);
                (0, i.useEffect)(() => {
                    var t;
                    null === (t = b.current) || void 0 === t || t.update()
                }, [v]);
                const C = (0, i.useCallback)(() => {
                        const t = JSON.stringify(u());
                        e.showSaveDialog((function(o) {
                            e.saveTemplate(o, t)
                        }))
                    }, [e, u]),
                    T = (0, i.useMemo)(() => {
                        const t = [];
                        return m && t.push(new d.Action({
                            actionId: "Chart.LineTool.Templates.SaveAs",
                            label: (0, a.appendEllipsis)((0, r.t)("Save Drawing Template As")),
                            onExecute: C
                        })), t.push(new d.Action({
                            actionId: "Chart.LineTool.Templates.ApplyDefaults",
                            label: (0, r.t)("Apply Default Drawing Template"),
                            onExecute: o
                        })), v ? t.push(new d.Loader("Chart.LineTool.Templates.Apply")) : !v && (null == f ? void 0 : f.length) && (t.push(new d.Separator), t.push(...f.map(t => new d.Action({
                            actionId: "Chart.LineTool.Templates.Apply",
                            label: t,
                            onExecute: () => function(t) {
                                void 0 !== t && e.loadTemplate(t)
                            }(t),
                            showToolboxOnHover: !0,
                            toolbox: {
                                type: h.ToolboxType.Delete,
                                action: () => e.deleteAction(t)
                            }
                        })))), t
                    }, [u, o, f, e, m, v]);
                return i.createElement(l.ToolWidgetMenu, {
                    title: (0, r.t)("Templates"),
                    content: i.createElement(n.Icon, {
                        icon: p
                    }),
                    onOpen: function() {
                        w(!0), e.templatesLoaded().then(() => {
                            const t = e.getData();
                            void 0 !== t && (y(t), w(!1))
                        }), (0, s.trackEvent)("GUI", "Context action on drawings", "Templates")
                    },
                    arrow: !1,
                    className: g,
                    "data-name": "templates",
                    menuDataName: "templates-menu",
                    ref: b,
                    ..._
                }, i.createElement(c.ActionsTable, {
                    items: T
                }))
            }
        },
        34297: (t, e, o) => {
            "use strict";
            o.d(e, {
                useProperty: () => n
            });
            var i = o(59496);
            const n = t => {
                const [e, o] = (0, i.useState)(t.value());
                return (0, i.useEffect)(() => {
                    const e = t => {
                        o(t.value())
                    };
                    e(t);
                    const i = {};
                    return t.subscribe(i, e), () => t.unsubscribe(i, e)
                }, [t]), e
            }
        },
        90266: (t, e, o) => {
            "use strict";
            o.d(e, {
                runOrSignIn: () => i
            });

            function i(t, e) {
                t()
            }
        },
        57630: (t, e, o) => {
            "use strict";
            o.d(e, {
                ColorPicker: () => B
            });
            var i = o(59496),
                n = o(97754),
                r = o.n(n),
                s = o(25177),
                a = o(24377),
                l = o(88537),
                c = o(1227),
                d = o(44377),
                h = o(92063);
            const p = i.createContext(void 0);
            var u = o(60184),
                m = o(86312),
                g = o(24590);

            function _(t) {
                const {
                    index: e,
                    color: o,
                    selected: r,
                    onSelect: a
                } = t, [_, v] = (0, i.useState)(!1), w = (0,
                    i.useContext)(p), f = (0, i.useRef)(null), y = Boolean(w) && !c.CheckMobile.any();
                return i.createElement(i.Fragment, null, i.createElement("div", {
                    ref: f,
                    style: o ? {
                        color: o
                    } : void 0,
                    className: n(g.swatch, _ && g.hover, r && g.selected, !o && g.empty, String(o).toLowerCase() === u.white && g.white),
                    onClick: function() {
                        a(o)
                    },
                    onContextMenu: y ? b : void 0
                }), y && i.createElement(d.PopupMenu, {
                    isOpened: _,
                    onClose: b,
                    position: function() {
                        const t = (0, l.ensureNotNull)(f.current).getBoundingClientRect();
                        return {
                            x: t.left,
                            y: t.top + t.height + 4
                        }
                    },
                    onClickOutside: b
                }, i.createElement(h.PopupMenuItem, {
                    className: g.contextItem,
                    label: (0, s.t)("Remove color"),
                    icon: m,
                    onClick: function() {
                        b(), (0, l.ensureDefined)(w)(e)
                    },
                    dontClosePopup: !0
                })));

                function b() {
                    v(!_)
                }
            }
            class v extends i.PureComponent {
                constructor() {
                    super(...arguments), this._onSelect = t => {
                        const {
                            onSelect: e
                        } = this.props;
                        e && e(t)
                    }
                }
                render() {
                    const {
                        colors: t,
                        color: e,
                        children: o
                    } = this.props;
                    if (!t) return null;
                    const n = e ? (0, a.parseRgb)(String(e)) : void 0;
                    return i.createElement("div", {
                        className: g.swatches
                    }, t.map((t, e) => i.createElement(_, {
                        key: String(t) + e,
                        index: e,
                        color: t,
                        selected: n && (0, a.areEqualRgb)(n, (0, a.parseRgb)(String(t))),
                        onSelect: this._onSelect
                    })), o)
                }
            }
            var w = o(39075),
                f = o(28599);

            function y(t) {
                const e = "Invalid RGB color: " + t;
                if (null === t) throw new Error(e);
                const o = t.match(/^#?([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})$/i);
                if (null === o) throw new Error(e);
                const [, i, n, r] = o;
                if (!i || !n || !r) throw new Error(e);
                const s = parseInt(i, 16) / 255,
                    a = parseInt(n, 16) / 255,
                    l = parseInt(r, 16) / 255,
                    c = Math.max(s, a, l),
                    d = Math.min(s, a, l);
                let h;
                const p = c,
                    u = c - d,
                    m = 0 === c ? 0 : u / c;
                if (c === d) h = 0;
                else {
                    switch (c) {
                        case s:
                            h = (a - l) / u + (a < l ? 6 : 0);
                            break;
                        case a:
                            h = (l - s) / u + 2;
                            break;
                        case l:
                            h = (s - a) / u + 4;
                            break;
                        default:
                            h = 0
                    }
                    h /= 6
                }
                return {
                    h,
                    s: m,
                    v: p
                }
            }
            var b = o(43370),
                C = o(88440);
            class T extends i.PureComponent {
                constructor() {
                    super(...arguments), this._container = null, this._refContainer = t => {
                        this._container = t
                    }, this._handlePosition = t => {
                        const {
                            hsv: {
                                h: e
                            },
                            onChange: o
                        } = this.props;
                        if (!o) return;
                        const i = (0, l.ensureNotNull)(this._container).getBoundingClientRect(),
                            n = t.clientX - i.left,
                            r = t.clientY - i.top;
                        let s = n / i.width;
                        s < 0 ? s = 0 : s > 1 && (s = 1);
                        let a = 1 - r / i.height;
                        a < 0 ? a = 0 : a > 1 && (a = 1), o({
                            h: e,
                            s,
                            v: a
                        })
                    }, this._mouseDown = t => {
                        window.addEventListener("mouseup", this._mouseUp), window.addEventListener("mousemove", this._mouseMove)
                    }, this._mouseUp = t => {
                        window.removeEventListener("mousemove", this._mouseMove), window.removeEventListener("mouseup", this._mouseUp), this._handlePosition(t)
                    }, this._mouseMove = (0, b.default)(this._handlePosition, 100), this._handleTouch = t => {
                        this._handlePosition(t.nativeEvent.touches[0])
                    }
                }
                render() {
                    const {
                        className: t,
                        hsv: {
                            h: e,
                            s: o,
                            v: n
                        }
                    } = this.props, s = `hsl(${360*e}, 100%, 50%)`;
                    return i.createElement("div", {
                        className: r()(C.saturation, t),
                        style: {
                            backgroundColor: s
                        },
                        ref: this._refContainer,
                        onMouseDown: this._mouseDown,
                        onTouchStart: this._handleTouch,
                        onTouchMove: this._handleTouch
                    }, i.createElement("div", {
                        className: C.pointer,
                        style: {
                            left: 100 * o + "%",
                            top: 100 * (1 - n) + "%"
                        }
                    }))
                }
            }
            var E = o(24429);
            class S extends i.PureComponent {
                constructor() {
                    super(...arguments), this._container = null, this._refContainer = t => {
                        this._container = t
                    }, this._handlePosition = t => {
                        const {
                            hsv: {
                                s: e,
                                v: o
                            },
                            onChange: i
                        } = this.props;
                        if (!i) return;
                        const n = (0, l.ensureNotNull)(this._container).getBoundingClientRect();
                        let r = (t.clientY - n.top) / n.height;
                        r < 0 ? r = 0 : r > 1 && (r = 1), i({
                            h: r,
                            s: e,
                            v: o
                        })
                    }, this._mouseDown = t => {
                        window.addEventListener("mouseup", this._mouseUp), window.addEventListener("mousemove", this._mouseMove)
                    }, this._mouseUp = t => {
                        window.removeEventListener("mousemove", this._mouseMove), window.removeEventListener("mouseup", this._mouseUp), this._handlePosition(t)
                    }, this._mouseMove = (0, b.default)(this._handlePosition, 100), this._handleTouch = t => {
                        this._handlePosition(t.nativeEvent.touches[0])
                    }
                }
                render() {
                    const {
                        className: t,
                        hsv: {
                            h: e
                        }
                    } = this.props;
                    return i.createElement("div", {
                        className: r()(E.hue, t)
                    }, i.createElement("div", {
                        className: E.pointerContainer,
                        ref: this._refContainer,
                        onMouseDown: this._mouseDown,
                        onTouchStart: this._handleTouch,
                        onTouchMove: this._handleTouch
                    }, i.createElement("div", {
                        className: E.pointer,
                        style: {
                            top: 100 * e + "%"
                        }
                    })))
                }
            }
            var P = o(99565);
            const x = (0, s.t)("Add", {
                context: "Color Picker"
            });
            class L extends i.PureComponent {
                constructor(t) {
                    super(t), this._handleHSV = t => {
                        const e = function(t) {
                            const {
                                h: e,
                                s: o,
                                v: i
                            } = t;
                            let n, r, s;
                            const a = Math.floor(6 * e),
                                l = 6 * e - a,
                                c = i * (1 - o),
                                d = i * (1 - l * o),
                                h = i * (1 - (1 - l) * o);
                            switch (a % 6) {
                                case 0:
                                    n = i, r = h, s = c;
                                    break;
                                case 1:
                                    n = d, r = i, s = c;
                                    break;
                                case 2:
                                    n = c, r = i, s = h;
                                    break;
                                case 3:
                                    n = c, r = d, s = i;
                                    break;
                                case 4:
                                    n = h, r = c, s = i;
                                    break;
                                case 5:
                                    n = i, r = c, s = d;
                                    break;
                                default:
                                    n = 0, r = 0, s = 0
                            }
                            return "#" + [255 * n, 255 * r, 255 * s].map(t => ("0" + Math.round(t).toString(16)).replace(/.+?([a-f0-9]{2})$/i, "$1")).join("")
                        }(t) || "#000000";
                        this.setState({
                            color: e,
                            inputColor: e.replace(/^#/, ""),
                            hsv: t
                        }), this.props.onSelect(e)
                    }, this._handleInput = t => {
                        const e = t.currentTarget.value;
                        try {
                            const t = y(e),
                                o = "#" + e;
                            this.setState({
                                color: o,
                                inputColor: e,
                                hsv: t
                            }), this.props.onSelect(o)
                        } catch (t) {
                            this.setState({
                                inputColor: e
                            })
                        }
                    }, this._handleAddColor = () => this.props.onAdd(this.state.color);
                    const e = t.color || "#000000";
                    this.state = {
                        color: e,
                        inputColor: e.replace(/^#/, ""),
                        hsv: y(e)
                    }
                }
                render() {
                    const {
                        color: t,
                        hsv: e,
                        inputColor: o
                    } = this.state;
                    return i.createElement("div", {
                        className: P.container
                    }, i.createElement("div", {
                        className: P.form
                    }, i.createElement("div", {
                        className: P.swatch,
                        style: {
                            backgroundColor: t
                        }
                    }), i.createElement("div", {
                        className: P.inputWrap
                    }, i.createElement("span", {
                        className: P.inputHash
                    }, "#"), i.createElement("input", {
                        type: "text",
                        className: P.input,
                        value: o,
                        onChange: this._handleInput
                    })), i.createElement("div", {
                        className: P.buttonWrap
                    }, i.createElement(f.Button, {
                        size: "s",
                        onClick: this._handleAddColor
                    }, x))), i.createElement("div", {
                        className: P.hueSaturationWrap
                    }, i.createElement(T, {
                        className: P.saturation,
                        hsv: e,
                        onChange: this._handleHSV
                    }), i.createElement(S, {
                        className: P.hue,
                        hsv: e,
                        onChange: this._handleHSV
                    })))
                }
            }
            var W = o(10667);
            const k = (0, s.t)("Add custom color", {
                    context: "Color Picker"
                }),
                A = (0, s.t)("Opacity", {
                    context: "Color Picker"
                });
            class B extends i.PureComponent {
                constructor(t) {
                    super(t), this._handleAddColor = t => {
                        this.setState({
                            isCustom: !1
                        }), this._onToggleCustom(!1);
                        const {
                            onAddColor: e
                        } = this.props;
                        e && e(t)
                    }, this._handleSelectColor = t => {
                        const {
                            onColorChange: e
                        } = this.props, {
                            isCustom: o
                        } = this.state;
                        e && e(t, o)
                    }, this._handleCustomClick = () => {
                        this.setState({
                            isCustom: !0
                        }), this._onToggleCustom(!0)
                    }, this._handleOpacity = t => {
                        const {
                            onOpacityChange: e
                        } = this.props;
                        e && e(t)
                    }, this.state = {
                        isCustom: !1
                    }
                }
                componentDidUpdate(t, e) {
                    t.selectOpacity !== this.props.selectOpacity && this.props.menu && this.props.menu.update()
                }
                render() {
                    const {
                        color: t,
                        opacity: e,
                        selectCustom: o,
                        selectOpacity: n,
                        customColors: s,
                        onRemoveCustomColor: a
                    } = this.props, {
                        isCustom: l
                    } = this.state, c = "number" == typeof e ? e : 1;
                    return l ? i.createElement(L, {
                        color: t,
                        onSelect: this._handleSelectColor,
                        onAdd: this._handleAddColor
                    }) : i.createElement("div", {
                        className: W.container
                    }, i.createElement(v, {
                        colors: u.basic,
                        color: t,
                        onSelect: this._handleSelectColor
                    }), i.createElement(v, {
                        colors: u.extended,
                        color: t,
                        onSelect: this._handleSelectColor
                    }), i.createElement("div", {
                        className: W.separator
                    }), i.createElement(p.Provider, {
                        value: a
                    }, i.createElement(v, {
                        colors: s,
                        color: t,
                        onSelect: this._handleSelectColor
                    }, o && i.createElement("div", {
                        className: r()(W.customButton, "apply-common-tooltip"),
                        onClick: this._handleCustomClick,
                        title: k
                    }))), n && i.createElement(i.Fragment, null, i.createElement("div", {
                        className: W.sectionTitle
                    }, A), i.createElement(w.Opacity, {
                        color: t,
                        opacity: c,
                        onChange: this._handleOpacity
                    })))
                }
                _onToggleCustom(t) {
                    const {
                        onToggleCustom: e
                    } = this.props;
                    e && e(t)
                }
            }
        },
        39075: (t, e, o) => {
            "use strict";
            o.d(e, {
                Opacity: () => l
            });
            var i = o(59496),
                n = o(97754),
                r = o(88537),
                s = o(97280),
                a = o(15381);
            class l extends i.PureComponent {
                constructor(t) {
                    super(t), this._container = null, this._pointer = null, this._raf = null, this._refContainer = t => {
                        this._container = t
                    }, this._refPointer = t => {
                        this._pointer = t
                    }, this._handlePosition = t => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            const e = (0, r.ensureNotNull)(this._container),
                                o = (0, r.ensureNotNull)(this._pointer),
                                i = e.getBoundingClientRect(),
                                n = o.offsetWidth,
                                a = t.clientX - n / 2 - i.left,
                                l = (0, s.clamp)(a / (i.width - n), 0, 1);
                            this.setState({
                                inputOpacity: Math.round(100 * l).toString()
                            }), this.props.onChange(l), this._raf = null
                        }))
                    }, this._onSliderClick = t => {
                        this._handlePosition(t.nativeEvent), this._dragSubscribe()
                    }, this._mouseUp = t => {
                        this.setState({
                            isPointerDragged: !1
                        }), this._dragUnsubscribe(), this._handlePosition(t)
                    }, this._mouseMove = t => {
                        this.setState({
                            isPointerDragged: !0
                        }), this._handlePosition(t)
                    }, this._onTouchStart = t => {
                        this._handlePosition(t.nativeEvent.touches[0])
                    }, this._handleTouch = t => {
                        this.setState({
                            isPointerDragged: !0
                        }), this._handlePosition(t.nativeEvent.touches[0])
                    }, this._handleTouchEnd = () => {
                        this.setState({
                            isPointerDragged: !1
                        })
                    }, this._handleInput = t => {
                        const e = t.currentTarget.value,
                            o = Number(e) / 100;
                        this.setState({
                            inputOpacity: e
                        }), Number.isNaN(o) || o > 1 || this.props.onChange(o)
                    }, this.state = {
                        inputOpacity: Math.round(100 * t.opacity).toString(),
                        isPointerDragged: !1
                    }
                }
                componentWillUnmount() {
                    null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), this._dragUnsubscribe()
                }
                render() {
                    const {
                        color: t,
                        opacity: e,
                        hideInput: o
                    } = this.props, {
                        inputOpacity: r,
                        isPointerDragged: s
                    } = this.state, l = {
                        color: t || void 0
                    };
                    return i.createElement("div", {
                        className: a.opacity
                    }, i.createElement("div", {
                        className: a.opacitySlider,
                        style: l,
                        ref: this._refContainer,
                        onMouseDown: this._onSliderClick,
                        onTouchStart: this._onTouchStart,
                        onTouchMove: this._handleTouch,
                        onTouchEnd: this._handleTouchEnd
                    }, i.createElement("div", {
                        className: a.opacitySliderGradient,
                        style: {
                            backgroundImage: `linear-gradient(90deg, transparent, ${t})`
                        }
                    }), i.createElement("div", {
                        className: a.opacityPointerWrap
                    }, i.createElement("div", {
                        className: n(a.pointer, s && a.dragged),
                        style: {
                            left: 100 * e + "%"
                        },
                        ref: this._refPointer
                    }))), !o && i.createElement("div", {
                        className: a.opacityInputWrap
                    }, i.createElement("input", {
                        type: "text",
                        className: a.opacityInput,
                        value: r,
                        onChange: this._handleInput
                    }), i.createElement("span", {
                        className: a.opacityInputPercent
                    }, "%")))
                }
                _dragSubscribe() {
                    const t = (0, r.ensureNotNull)(this._container).ownerDocument;
                    t && (t.addEventListener("mouseup", this._mouseUp), t.addEventListener("mousemove", this._mouseMove))
                }
                _dragUnsubscribe() {
                    const t = (0, r.ensureNotNull)(this._container).ownerDocument;
                    t && (t.removeEventListener("mousemove", this._mouseMove), t.removeEventListener("mouseup", this._mouseUp))
                }
            }
        },
        60184: (t, e, o) => {
            "use strict";
            o.d(e, {
                white: () => n,
                basic: () => a,
                extended: () => c
            });
            var i = o(2996);
            const n = i.colorsPalette["color-white"],
                r = ["ripe-red", "tan-orange", "banana-yellow", "iguana-green", "minty-green", "sky-blue", "tv-blue", "deep-blue", "grapes-purple", "berry-pink"],
                s = [200, 300, 400, 500, 600, 700, 800, 900].map(t => "color-cold-gray-" + t);
            s.unshift("color-white"), s.push("color-black"), r.forEach(t => {
                s.push(`color-${t}-500`)
            });
            const a = s.map(t => i.colorsPalette[t]),
                l = [];
            [100, 200, 300, 400, 700, 900].forEach(t => {
                r.forEach(e => {
                    l.push(`color-${e}-${t}`)
                })
            });
            const c = l.map(t => i.colorsPalette[t])
        },
        6397: (t, e, o) => {
            "use strict";
            o.d(e, {
                useCustomColors: () => l
            });
            var i = o(59496),
                n = o(70122),
                r = o(59410);

            function s(t, e) {
                (0, i.useEffect)(() => (r.subscribe(t, e, null), () => {
                    r.unsubscribe(t, e, null)
                }), [t, e])
            }
            var a = o(24377);

            function l() {
                const [t, e] = (0, i.useState)((0, n.getJSON)("pickerCustomColors", []));
                s("add_new_custom_color", o => e(c(o, t))), s("remove_custom_color", o => e(d(o, t)));
                const o = (0, i.useCallback)(e => {
                        const o = e ? (0, a.parseRgb)(e) : null;
                        t.some(t => null !== t && null !== o && (0, a.areEqualRgb)((0, a.parseRgb)(t), o)) || (r.emit("add_new_custom_color", e), (0, n.setJSON)("pickerCustomColors", c(e, t)))
                    }, [t]),
                    l = (0, i.useCallback)(e => {
                        (e >= 0 || e < t.length) && (r.emit("remove_custom_color", e), (0, n.setJSON)("pickerCustomColors", d(e, t)))
                    }, [t]);
                return [t, o, l]
            }

            function c(t, e) {
                const o = e.slice();
                return o.push(t), o.length > 29 && o.shift(), o
            }

            function d(t, e) {
                return e.filter((e, o) => t !== o)
            }
        },
        13739: (t, e, o) => {
            "use strict";
            o.d(e, {
                MatchMediaMap: () => s
            });
            var i = o(59496),
                n = o(66783),
                r = o.n(n);
            class s extends i.Component {
                constructor(t) {
                    super(t), this._handleMediaChange = () => {
                        const t = l(this.state.queries, (t, e) => e.matches);
                        let e = !1;
                        for (const o in t)
                            if (t.hasOwnProperty(o) && this.state.matches[o] !== t[o]) {
                                e = !0;
                                break
                            }
                        e && this.setState({
                            matches: t
                        })
                    };
                    const {
                        rules: e
                    } = this.props;
                    this.state = a(e)
                }
                shouldComponentUpdate(t, e) {
                    return !r()(t, this.props) || (!r()(e.rules, this.state.rules) || !r()(e.matches, this.state.matches))
                }
                componentDidMount() {
                    this._migrate(null, this.state.queries)
                }
                componentDidUpdate(t, e) {
                    r()(t.rules, this.props.rules) || this._migrate(e.queries, this.state.queries)
                }
                componentWillUnmount() {
                    this._migrate(this.state.queries, null)
                }
                render() {
                    return this.props.children(this.state.matches)
                }
                static getDerivedStateFromProps(t, e) {
                    if (r()(t.rules, e.rules)) return null;
                    const {
                        rules: o
                    } = t;
                    return a(o)
                }
                _migrate(t, e) {
                    null !== t && l(t, (t, e) => {
                        e.removeListener(this._handleMediaChange)
                    }), null !== e && l(e, (t, e) => {
                        e.addListener(this._handleMediaChange)
                    })
                }
            }

            function a(t) {
                const e = l(t, (t, e) => window.matchMedia(e));
                return {
                    queries: e,
                    matches: l(e, (t, e) => e.matches),
                    rules: { ...t
                    }
                }
            }

            function l(t, e) {
                const o = {};
                for (const i in t) t.hasOwnProperty(i) && (o[i] = e(i, t[i]));
                return o
            }
        },
        15783: (t, e, o) => {
            "use strict";
            o.d(e, {
                ToolWidgetCaret: () => l
            });
            var i = o(59496),
                n = o(97754),
                r = o(72571),
                s = o(40367),
                a = o(21538);

            function l(t) {
                const {
                    dropped: e,
                    className: o
                } = t;
                return i.createElement(r.Icon, {
                    className: n(o, s.icon, {
                        [s.dropped]: e
                    }),
                    icon: a
                })
            }
        },
        21538: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        98584: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fillRule="evenodd" clipRule="evenodd" d="M7.5 13a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM12 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM19 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0z"/></svg>'
        },
        87460: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path fill="currentColor" d="M4 13h5v1H4v-1zM12 13h5v1h-5v-1zM20 13h5v1h-5v-1z"/></svg>'
        },
        22931: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor"><circle cx="9" cy="14" r="1"/><circle cx="4" cy="14" r="1"/><circle cx="14" cy="14" r="1"/><circle cx="19" cy="14" r="1"/><circle cx="24" cy="14" r="1"/></svg>'
        },
        47387: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path stroke="currentColor" d="M4 13.5h20"/></svg>'
        },
        56085: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8 9.5H6.5a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V20m-8-1.5h11a1 1 0 0 0 1-1v-11a1 1 0 0 0-1-1h-11a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1z"/></svg>'
        },
        65616: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="20" height="20" fill="none"><path stroke="currentColor" d="M13.5 6.5l-3-3-7 7 7.59 7.59a2 2 0 0 0 2.82 0l4.18-4.18a2 2 0 0 0 0-2.82L13.5 6.5zm0 0v-4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v6"/><path fill="currentColor" d="M0 16.5C0 15 2.5 12 2.5 12S5 15 5 16.5 4 19 2.5 19 0 18 0 16.5z"/><circle fill="currentColor" cx="9.5" cy="9.5" r="1.5"/></svg>'
        },
        74513: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 8 12" width="8" height="12" fill="currentColor"><rect width="2" height="2" rx="1"/><rect width="2" height="2" rx="1" y="5"/><rect width="2" height="2" rx="1" y="10"/><rect width="2" height="2" rx="1" x="6"/><rect width="2" height="2" rx="1" x="6" y="5"/><rect width="2" height="2" rx="1" x="6" y="10"/></svg>'
        },
        59934: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 1" width="18" height="1"><rect width="18" height="1" fill="currentColor" rx=".5"/></svg>'
        },
        29762: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 2" width="18" height="2"><rect width="18" height="2" fill="currentColor" rx="1"/></svg>'
        },
        98770: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 3" width="18" height="3"><rect width="18" height="3" fill="currentColor" rx="1.5"/></svg>'
        },
        32970: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 4" width="18" height="4"><rect width="18" height="4" fill="currentColor" rx="2"/></svg>'
        },
        28035: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><rect width="18" height="2" rx="1" x="5" y="14"/><rect width="18" height="1" rx=".5" x="5" y="20"/><rect width="18" height="3" rx="1.5" x="5" y="7"/></svg>'
        },
        65652: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="none"><path stroke="currentColor" d="M1.5 11.5l-.7.7a1 1 0 0 0-.3.71v3.59h3.59a1 1 0 0 0 .7-.3l.71-.7m-4-4l9-9m-9 9l2 2m2 2l9-9m-9 9l-2-2m11-7l1.3-1.3a1 1 0 0 0 0-1.4l-2.6-2.6a1 1 0 0 0-1.4 0l-1.3 1.3m4 4l-4-4m-7 11l9-9"/></svg>'
        },
        74852: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none" stroke="currentColor"><path stroke-linecap="round" d="M15.5 18.5h6m-3 3v-6"/><rect width="6" height="6" rx="1.5" x="6.5" y="6.5"/><rect width="6" height="6" rx="1.5" x="15.5" y="6.5"/><rect width="6" height="6" rx="1.5" x="6.5" y="15.5"/></svg>'
        },
        48427: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 15" width="13" height="15" fill="none"><path stroke="currentColor" d="M4 14.5h2.5m2.5 0H6.5m0 0V.5m0 0h-5a1 1 0 0 0-1 1V4m6-3.5h5a1 1 0 0 1 1 1V4"/></svg>'
        },
        97978: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentcolor" fill-rule="evenodd" clip-rule="evenodd" d="M13 5.5c0-.28.22-.5.5-.5h1c.28 0 .5.22.5.5V7.05l.4.09c.9.18 1.73.53 2.46 1.02l.34.23.29-.3.81-.8c.2-.2.52-.2.71 0l.7.7.36-.35-.35.35c.2.2.2.51 0 .7l-.82.82-.29.29.23.34c.49.73.84 1.57 1.02 2.46l.08.4H22.5c.28 0 .5.22.5.5v1a.5.5 0 0 1-.5.5H20.95l-.09.4c-.18.9-.53 1.73-1.02 2.46l-.23.34.3.29.8.81c.2.2.2.52 0 .71l-.7.7a.5.5 0 0 1-.7 0l-.82-.8-.29-.3-.34.23c-.73.49-1.57.84-2.46 1.02l-.4.08V22.5a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5V20.95l-.4-.09a6.96 6.96 0 0 1-2.46-1.02l-.34-.23-.29.3-.81.8.35.36-.35-.35a.5.5 0 0 1-.71 0l-.7-.71a.5.5 0 0 1 0-.7l-.36-.36.35.35.82-.81.29-.29-.23-.34a6.96 6.96 0 0 1-1.02-2.46l-.08-.4H5.5a.5.5 0 0 1-.5-.5v-1c0-.28.22-.5.5-.5H7.05l.09-.4c.18-.9.53-1.73 1.02-2.46l.23-.34-.3-.29-.8-.81a.5.5 0 0 1 0-.71l.7-.7c.2-.2.51-.2.7 0l.82.8.29.3.34-.23a6.96 6.96 0 0 1 2.46-1.02l.4-.08V5.5zm.5-1.5c-.83 0-1.5.67-1.5 1.5v.75c-.73.2-1.43.48-2.06.86l-.54-.53a1.5 1.5 0 0 0-2.12 0l-.7.7a1.5 1.5 0 0 0 0 2.12l.53.54A7.95 7.95 0 0 0 6.25 12H5.5c-.83 0-1.5.67-1.5 1.5v1c0 .83.67 1.5 1.5 1.5h.75c.2.73.48 1.43.86 2.06l-.53.54a1.5 1.5 0 0 0 0 2.12l.7.7a1.5 1.5 0 0 0 2.12 0l.54-.53c.63.38 1.33.67 2.06.86v.75c0 .83.67 1.5 1.5 1.5h1c.83 0 1.5-.67 1.5-1.5v-.75a7.95 7.95 0 0 0 2.06-.86l.54.53a1.5 1.5 0 0 0 2.12 0l.7-.7a1.5 1.5 0 0 0 0-2.12l-.53-.54c.38-.63.67-1.33.86-2.06h.75c.83 0 1.5-.67 1.5-1.5v-1c0-.83-.67-1.5-1.5-1.5h-.75a7.95 7.95 0 0 0-.86-2.06l.53-.54a1.5 1.5 0 0 0 0-2.12l-.7-.7a1.5 1.5 0 0 0-2.12 0l-.54.53A7.95 7.95 0 0 0 16 6.25V5.5c0-.83-.67-1.5-1.5-1.5h-1zM12 14a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm2-3a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>'
        }
    }
]);
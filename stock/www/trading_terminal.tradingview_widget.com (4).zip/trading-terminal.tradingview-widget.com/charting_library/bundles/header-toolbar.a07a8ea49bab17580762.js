(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [3005], {
        77511: e => {
            e.exports = {
                group: "group-T57LDNqT",
                noLeftDecoration: "noLeftDecoration-T57LDNqT",
                noRightDecoration: "noRightDecoration-T57LDNqT",
                noMinimalWidth: "noMinimalWidth-T57LDNqT",
                newStyles: "newStyles-T57LDNqT",
                separator: "separator-T57LDNqT",
                separatorWrap: "separatorWrap-T57LDNqT"
            }
        },
        71747: e => {
            e.exports = {
                "css-value-header-toolbar-height": "38px",
                wrap: "wrap-7mUBPdQo"
            }
        },
        85291: e => {
            e.exports = {
                "css-value-header-toolbar-height": "38px",
                toolbar: "toolbar-ymEQuMuZ",
                isHidden: "isHidden-ymEQuMuZ",
                overflowWrap: "overflowWrap-ymEQuMuZ",
                customButton: "customButton-ymEQuMuZ",
                hovered: "hovered-ymEQuMuZ"
            }
        },
        36971: e => {
            e.exports = {
                wrap: "wrap-zQWNyqoF",
                icon: "icon-zQWNyqoF"
            }
        },
        93067: e => {
            e.exports = {
                "css-value-header-toolbar-height": "38px",
                inner: "inner-Kbdz4qEM",
                fake: "fake-Kbdz4qEM",
                fill: "fill-Kbdz4qEM",
                collapse: "collapse-Kbdz4qEM",
                button: "button-Kbdz4qEM",
                iconButton: "iconButton-Kbdz4qEM",
                hidden: "hidden-Kbdz4qEM",
                content: "content-Kbdz4qEM",
                desktopPublish: "desktopPublish-Kbdz4qEM",
                mobilePublish: "mobilePublish-Kbdz4qEM"
            }
        },
        41814: e => {
            e.exports = {
                wrap: "wrap-sfzcrPlH",
                wrapWithArrowsOuting: "wrapWithArrowsOuting-sfzcrPlH",
                wrapOverflow: "wrapOverflow-sfzcrPlH",
                scrollWrap: "scrollWrap-sfzcrPlH",
                noScrollBar: "noScrollBar-sfzcrPlH",
                icon: "icon-sfzcrPlH",
                scrollLeft: "scrollLeft-sfzcrPlH",
                scrollRight: "scrollRight-sfzcrPlH",
                isVisible: "isVisible-sfzcrPlH",
                iconWrap: "iconWrap-sfzcrPlH",
                fadeLeft: "fadeLeft-sfzcrPlH",
                fadeRight: "fadeRight-sfzcrPlH"
            }
        },
        72571: (e, t, r) => {
            "use strict";
            r.d(t, {
                Icon: () => i
            });
            var n = r(59496);
            const i = n.forwardRef((e, t) => {
                const {
                    icon: r = "",
                    ...i
                } = e;
                return n.createElement("span", { ...i,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: r
                    }
                })
            })
        },
        21714: (e, t, r) => {
            "use strict";
            r.d(t, {
                INTERVALS: () => i
            });
            var n = r(25177);
            const i = [{
                name: "",
                label: (0, n.t)("minutes", {
                    context: "interval"
                })
            }, {
                name: "H",
                label: (0, n.t)("hours", {
                    context: "interval"
                })
            }, {
                name: "D",
                label: (0, n.t)("days", {
                    context: "interval"
                })
            }, {
                name: "W",
                label: (0, n.t)("weeks", {
                    context: "interval"
                })
            }, {
                name: "M",
                label: (0, n.t)("months", {
                    context: "interval"
                })
            }]
        },
        25655: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                HeaderToolbarRenderer: () => ge
            });
            var n = r(59496),
                i = r(87995),
                o = r(88537),
                s = r(97754),
                a = r(85459),
                l = r.n(a),
                u = r(43370),
                c = r(82527),
                d = r(59410),
                h = r(19036),
                p = r(7270),
                f = r(72535),
                m = r(70086),
                v = r(4257),
                y = r(77511);

            function g(e) {
                const {
                    children: t,
                    className: r,
                    noLeftDecoration: i,
                    noRightDecoration: o,
                    noMinimalWidth: a,
                    onClick: l,
                    removeSeparator: u
                } = e;
                return n.createElement(n.Fragment, null, v.hasNewHeaderToolbarStyles && !u && n.createElement("div", {
                    className: y.separatorWrap
                }, n.createElement("div", {
                    className: y.separator
                })), n.createElement("div", {
                    className: s(r, y.group, {
                        [y.noMinimalWidth]: a,
                        [y.noLeftDecoration]: i,
                        [y.noRightDecoration]: o,
                        [y.newStyles]: v.hasNewHeaderToolbarStyles
                    }),
                    onClick: l
                }, t))
            }
            var b = r(71747);
            class S extends n.PureComponent {
                constructor() {
                    super(...arguments), this._handleMeasure = ({
                        width: e
                    }) => {
                        this.props.onWidthChange(e)
                    }
                }
                render() {
                    const {
                        children: e,
                        shouldMeasure: t
                    } = this.props;
                    return n.createElement(p, {
                        shouldMeasure: t,
                        onMeasure: this._handleMeasure,
                        whitelist: ["width"]
                    }, n.createElement("div", {
                        className: b.wrap
                    }, e))
                }
            }
            var w = r(25177),
                _ = r(72571),
                E = r(36971),
                C = r(71485);
            const M = {
                text: (0, w.t)("View Only Mode")
            };

            function T(e) {
                return n.createElement("div", {
                    className: E.wrap
                }, n.createElement(_.Icon, {
                    className: E.icon,
                    icon: C
                }), M.text)
            }
            var k, R = r(86746),
                O = r(12777);
            ! function(e) {
                e.SymbolSearch = "header-toolbar-symbol-search", e.Intervals = "header-toolbar-intervals", e.ChartStyles = "header-toolbar-chart-styles", e.Compare = "header-toolbar-compare", e.Indicators = "header-toolbar-indicators", e.StudyTemplates = "header-toolbar-study-templates", e.Dropdown = "header-toolbar-dropdown", e.Alerts = "header-toolbar-alerts", e.Layouts = "header-toolbar-layouts", e.SaveLoad = "header-toolbar-save-load", e.UndoRedo = "header-toolbar-undo-redo", e.Properties = "header-toolbar-properties", e.PublishDesktop = "header-toolbar-publish-desktop", e.PublishMobile = "header-toolbar-publish-mobile", e.Fullscreen = "header-toolbar-fullscreen", e.Screenshot = "header-toolbar-screenshot", e.Replay = "header-toolbar-replay", e.Financials = "header-toolbar-financials", e.StartTrial = "header-toolbar-start-trial"
            }(k || (k = {}));
            var N = r(21258),
                I = r(23404),
                x = r(93067);
            const P = (0, I.registryContextType)();
            class V extends n.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleMouseOver = e => {
                        (0, N.hoverMouseEventFilter)(e) && this.setState({
                            isHovered: !0
                        })
                    }, this._handleMouseOut = e => {
                        (0, N.hoverMouseEventFilter)(e) && this.setState({
                            isHovered: !1
                        })
                    }, this._handleInnerResize = e => {
                        const {
                            onWidthChange: t
                        } = this.props;
                        t && t(e)
                    }, this._handleMeasureAvailableSpace = ({
                        width: e
                    }) => {
                        const {
                            onAvailableSpaceChange: t
                        } = this.props;
                        t && t(e)
                    }, this._processCustoms = e => {
                        const {
                            isFake: t,
                            displayMode: r
                        } = this.props, {
                            tools: i
                        } = this.context;
                        return e.map(e => n.createElement(g, {
                            key: e.id
                        }, (e => {
                            switch (e.type) {
                                case "Button":
                                    return n.createElement(i.Custom, { ...e.params,
                                        isFake: t
                                    });
                                case "TradingViewStyledButton":
                                    return n.createElement(i.CustomTradingViewStyledButton, { ...e.params,
                                        className: x.button,
                                        displayMode: r
                                    });
                                case "Dropdown":
                                    return n.createElement(i.Dropdown, {
                                        displayMode: r,
                                        params: e.params
                                    });
                                default:
                                    return null
                            }
                        })(e)))
                    }, this._fixLastGroup = (e, t, r) => {
                        if (t === r.length - 1 && n.isValidElement(e) && e.type === g) {
                            const t = void 0 !== this.context.tools.Publish && !this.props.readOnly;
                            return n.cloneElement(e, {
                                noRightDecoration: t
                            })
                        }
                        return e
                    }, (0, I.validateRegistry)(t, {
                        tools: h.any.isRequired
                    }), this.state = {
                        isHovered: !1,
                        isAuthenticated: void 0
                    }
                }
                componentDidMount() {
                    0
                }
                componentWillUnmount() {
                    0
                }
                render() {
                    const {
                        tools: e
                    } = this.context, {
                        features: t,
                        displayMode: r,
                        chartSaver: i,
                        studyMarket: o,
                        readOnly: a,
                        saveLoadSyncEmitter: l,
                        leftCustomElements: u,
                        rightCustomElements: c,
                        showScrollbarWhen: d,
                        isFake: h = !1
                    } = this.props, {
                        isHovered: y,
                        isAuthenticated: b
                    } = this.state, w = this._processCustoms(u), _ = this._processCustoms(c), E = d.includes(r);
                    return n.createElement("div", {
                        className: s(x.inner, {
                            [x.fake]: h
                        }),
                        onContextMenu: O.preventDefaultForContextMenu,
                        "data-is-fake-main-panel": h
                    }, n.createElement(p, {
                        onMeasure: this._handleMeasureAvailableSpace,
                        whitelist: ["width"],
                        shouldMeasure: !h
                    }, n.createElement(R.HorizontalScroll, {
                        isVisibleFade: f.mobiletouch && E,
                        isVisibleButtons: !f.mobiletouch && E && y,
                        isVisibleScrollbar: !1,
                        shouldMeasure: E && !h,
                        onMouseOver: this._handleMouseOver,
                        onMouseOut: this._handleMouseOut
                    }, n.createElement("div", {
                        className: x.content
                    }, n.createElement(S, {
                        onWidthChange: this._handleInnerResize,
                        shouldMeasure: h
                    }, n.createElement(m.FragmentMap, {
                        map: this._fixLastGroup
                    }, !a && n.Children.toArray([e.SymbolSearch && n.createElement(g, {
                        key: "symbol"
                    }, n.createElement(e.SymbolSearch, {
                        id: h ? void 0 : k.SymbolSearch,
                        isActionsVisible: t.allowSymbolSearchSpread
                    }), v.hasNewHeaderToolbarStyles && e.Compare && n.createElement(e.Compare, {
                        id: h ? void 0 : k.Compare,
                        className: x.button,
                        displayMode: r
                    })), e.DateRange && n.createElement(g, {
                        key: "range"
                    }, n.createElement(e.DateRange, null)), e.Intervals && n.createElement(g, {
                        key: "intervals"
                    }, n.createElement(e.Intervals, {
                        id: h ? void 0 : k.Intervals,
                        isShownQuicks: t.allowFavoriting,
                        isFavoritingAllowed: t.allowFavoriting,
                        displayMode: r,
                        isFake: h
                    })), e.Bars && n.createElement(g, {
                        key: "styles"
                    }, n.createElement(e.Bars, {
                        id: h ? void 0 : k.ChartStyles,
                        isShownQuicks: t.allowFavoriting,
                        isFavoritingAllowed: t.allowFavoriting,
                        displayMode: r,
                        isFake: h
                    })), !v.hasNewHeaderToolbarStyles && e.Compare && n.createElement(g, {
                        key: "compare"
                    }, n.createElement(e.Compare, {
                        id: h ? void 0 : k.Compare,
                        className: x.button,
                        displayMode: r
                    })), e.Indicators && n.createElement(g, {
                        key: "indicators"
                    }, n.createElement(e.Indicators, {
                        id: h ? void 0 : k.Indicators,
                        className: x.button,
                        studyMarket: o,
                        displayMode: r
                    }), v.hasNewHeaderToolbarStyles && e.Templates && n.createElement(e.Templates, {
                        id: h ? void 0 : k.StudyTemplates,
                        isShownQuicks: t.allowFavoriting,
                        isFavoritingAllowed: t.allowFavoriting,
                        displayMode: r
                    })), !v.hasNewHeaderToolbarStyles && e.Templates && n.createElement(g, {
                        key: "templates"
                    }, n.createElement(e.Templates, {
                        id: h ? void 0 : k.StudyTemplates,
                        isShownQuicks: t.allowFavoriting,
                        isFavoritingAllowed: t.allowFavoriting,
                        displayMode: r
                    })), e.Alert && n.createElement(g, {
                        key: "alert"
                    }, n.createElement(e.Alert, {
                        id: h ? void 0 : k.Alerts,
                        className: x.button,
                        displayMode: r
                    }), v.hasNewHeaderToolbarStyles && e.Replay && n.createElement(e.Replay, {
                        id: h ? void 0 : k.Replay,
                        className: x.button,
                        displayMode: r
                    })), e.AlertReferral && n.createElement(g, {
                        key: "alert-referral"
                    }, n.createElement(e.AlertReferral, {
                        className: x.button,
                        displayMode: r
                    })), !v.hasNewHeaderToolbarStyles && e.Replay && n.createElement(g, {
                        key: "replay"
                    }, n.createElement(e.Replay, {
                        id: h ? void 0 : k.Replay,
                        className: x.button,
                        displayMode: r
                    })), !v.hasNewHeaderToolbarStyles && e.UndoRedo && n.createElement(g, {
                        key: "undo-redo"
                    }, n.createElement(e.UndoRedo, {
                        id: h ? void 0 : k.UndoRedo
                    })), e.ScalePercentage && n.createElement(g, {
                        key: "percentage"
                    }, n.createElement(e.ScalePercentage, null)), e.ScaleLogarithm && n.createElement(g, {
                        key: "logarithm"
                    }, n.createElement(e.ScaleLogarithm, null)), ...w]), function(e) {
                        const t = e.findIndex(e => n.isValidElement(e) && !!e.key && -1 !== e.key.toString().indexOf("view-only-badge"));
                        return [t].filter(e => e >= 0).forEach(t => {
                            e = n.Children.map(e, (e, r) => {
                                if (n.isValidElement(e)) {
                                    switch ([t - 1, t, t + 1].indexOf(r)) {
                                        case 0:
                                            const t = {
                                                noRightDecoration: !0
                                            };
                                            e = n.cloneElement(e, t);
                                            break;
                                        case 1:
                                            const r = {
                                                noLeftDecoration: !0,
                                                noRightDecoration: !0
                                            };
                                            e = n.cloneElement(e, r);
                                            break;
                                        case 2:
                                            const i = {
                                                noLeftDecoration: !0
                                            };
                                            e = n.cloneElement(e, i)
                                    }
                                }
                                return e
                            })
                        }), e
                    }(n.Children.toArray([a && n.createElement(g, {
                        key: "view-only-badge",
                        removeSeparator: v.hasNewHeaderToolbarStyles
                    }, n.createElement(T, null)), n.createElement(g, {
                        key: "gap",
                        className: s(x.fill, h && x.collapse),
                        removeSeparator: v.hasNewHeaderToolbarStyles
                    }), v.hasNewHeaderToolbarStyles && !a && e.UndoRedo && n.createElement(g, {
                        key: "undo-redo",
                        removeSeparator: !0
                    }, n.createElement(e.UndoRedo, {
                        id: h ? void 0 : k.UndoRedo
                    })), (!a || v.hasNewHeaderToolbarStyles) && e.Layout && n.createElement(g, {
                        key: "layout",
                        removeSeparator: v.hasNewHeaderToolbarStyles && a
                    }, !a && n.createElement(e.Layout, {
                        id: h ? void 0 : k.Layouts
                    }), v.hasNewHeaderToolbarStyles && e.SaveLoad && n.createElement(e.SaveLoad, {
                        id: h ? void 0 : k.SaveLoad,
                        chartSaver: i,
                        isReadOnly: a,
                        displayMode: r,
                        isFake: h,
                        stateSyncEmitter: l
                    })), !v.hasNewHeaderToolbarStyles && e.SaveLoad && n.createElement(g, {
                        key: "save-load-right"
                    }, n.createElement(e.SaveLoad, {
                        id: h ? void 0 : k.SaveLoad,
                        chartSaver: i,
                        isReadOnly: a,
                        displayMode: r,
                        isFake: h,
                        stateSyncEmitter: l
                    })), e.SaveLoadReferral && n.createElement(g, {
                        key: "save-load-referral"
                    }, n.createElement(e.SaveLoadReferral, {
                        isReadOnly: a,
                        displayMode: r
                    })), t.showLaunchInPopupButton && e.OpenPopup && n.createElement(g, {
                        key: "popup"
                    }, n.createElement(e.OpenPopup, null)), (!a || v.hasNewHeaderToolbarStyles) && e.Properties && n.createElement(g, {
                        key: "properties",
                        removeSeparator: v.hasNewHeaderToolbarStyles && a
                    }, !a && n.createElement(e.Properties, {
                        id: h ? void 0 : k.Properties,
                        className: x.iconButton
                    }), v.hasNewHeaderToolbarStyles && n.createElement(n.Fragment, null, !a && e.Fullscreen && n.createElement(e.Fullscreen, {
                        id: h ? void 0 : k.Fullscreen
                    }), e.Screenshot && n.createElement(e.Screenshot, {
                        id: h ? void 0 : k.Screenshot,
                        className: x.iconButton
                    }))), !v.hasNewHeaderToolbarStyles && !a && e.Fullscreen && n.createElement(g, {
                        key: "fullscreen",
                        onClick: this._trackFullscreenButtonClick
                    }, n.createElement(e.Fullscreen, {
                        id: h ? void 0 : k.Fullscreen
                    })), !v.hasNewHeaderToolbarStyles && e.Screenshot && n.createElement(g, {
                        key: "screenshot"
                    }, n.createElement(e.Screenshot, {
                        id: h ? void 0 : k.Screenshot,
                        className: x.iconButton
                    })), !a && e.Publish && n.createElement(g, {
                        key: "publish",
                        className: x.mobilePublish,
                        removeSeparator: v.hasNewHeaderToolbarStyles
                    }, n.createElement(e.Publish, {
                        id: h ? void 0 : k.PublishMobile
                    })), ..._]))))))), e.Publish && !a && !h && n.createElement(e.Publish, {
                        id: k.PublishDesktop,
                        className: x.desktopPublish
                    }))
                }
                _onLoginStateChange() {
                    0
                }
                _trackFullscreenButtonClick() {
                    0
                }
            }
            V.contextType = P;
            var W = r(94489),
                D = r.n(W),
                F = r(36305);
            class L extends F.CommonJsonStoreService {
                constructor(e, t, r = []) {
                    super(e, t, "FAVORITE_CHART_STYLES_CHANGED", "StyleWidget.quicks", r)
                }
            }
            var A = r(2117),
                H = r(80216);
            class B extends F.AbstractJsonStoreService {
                constructor(e, t, r) {
                    super(e, t, "FAVORITE_INTERVALS_CHANGED", "IntervalWidget.quicks", r)
                }
                _serialize(e) {
                    return (0, H.uniq)(e.map(A.normalizeIntervalString))
                }
                _deserialize(e) {
                    return (0, H.uniq)((0, A.convertResolutionsFromSettings)(e).filter(A.isResolutionMultiplierValid).map(A.normalizeIntervalString))
                }
            }
            var z = r(88401),
                j = r(97496),
                q = r.n(j),
                U = r(70122),
                K = r(17866);
            class Q extends F.AbstractJsonStoreService {
                constructor(e, t, r = []) {
                    super(e, t, "CUSTOM_INTERVALS_CHANGED", "IntervalWidget.intervals", r)
                }
                set(e, t) {
                    e.length, this.get().length, super.set(e, t)
                }
                _serialize(e) {
                    return (0, H.uniq)(e.map(A.normalizeIntervalString))
                }
                _deserialize(e) {
                    return (0, H.uniq)((0, A.convertResolutionsFromSettings)(e).filter(A.isResolutionMultiplierValid).map(A.normalizeIntervalString))
                }
            }
            const J = new Q(K.TVXWindowEvents, U);
            var X = r(21714);
            class G {
                constructor(e) {
                    this._customIntervalsService = J, this._supportedIntervalsMayChange = new(q()), this._fireSupportedIntervalsMayChange = () => {
                        this._supportedIntervalsMayChange.fire()
                    }, this._chartApiInstance = e, z.linking.supportedResolutions.subscribe(this._fireSupportedIntervalsMayChange), z.linking.range.subscribe(this._fireSupportedIntervalsMayChange), z.linking.seconds.subscribe(this._fireSupportedIntervalsMayChange), z.linking.ticks.subscribe(this._fireSupportedIntervalsMayChange), z.linking.intraday.subscribe(this._fireSupportedIntervalsMayChange)
                }
                destroy() {
                    z.linking.supportedResolutions.unsubscribe(this._fireSupportedIntervalsMayChange), z.linking.range.unsubscribe(this._fireSupportedIntervalsMayChange), z.linking.seconds.unsubscribe(this._fireSupportedIntervalsMayChange), z.linking.ticks.unsubscribe(this._fireSupportedIntervalsMayChange), z.linking.intraday.unsubscribe(this._fireSupportedIntervalsMayChange)
                }
                getDefaultIntervals() {
                    return null === this._chartApiInstance ? [] : this._chartApiInstance.defaultResolutions().map(A.normalizeIntervalString)
                }
                getCustomIntervals() {
                    return this._customIntervalsService.get()
                }
                add(e, t, r) {
                    if (!this.isValidInterval(e, t)) return null;
                    const n = (0, A.normalizeIntervalString)(`${e}${t}`),
                        i = this.getCustomIntervals();
                    return this._isIntervalDefault(n) || i.includes(n) ? null : (this._customIntervalsService.set((0, A.sortResolutions)([...i, n])), n)
                }
                remove(e) {
                    this._customIntervalsService.set(this.getCustomIntervals().filter(t => t !== e))
                }
                isValidInterval(e, t) {
                    return (0, A.isResolutionMultiplierValid)(`${e}${t}`)
                }
                isSupportedInterval(e) {
                    return (0, A.isAvailable)(e)
                }
                supportedIntervalsMayChange() {
                    return this._supportedIntervalsMayChange
                }
                getOnChange() {
                    return this._customIntervalsService.getOnChange()
                }
                getPossibleIntervals() {
                    return X.INTERVALS
                }
                getResolutionUtils() {
                    return {
                        getMaxResolutionValue: A.getMaxResolutionValue,
                        getTranslatedResolutionModel: A.getTranslatedResolutionModel,
                        mergeResolutions: A.mergeResolutions,
                        sortResolutions: A.sortResolutions
                    }
                }
                _isIntervalDefault(e) {
                    return this.getDefaultIntervals().includes(e)
                }
            }
            var $ = r(57372),
                Y = r(18495),
                Z = r(29257);
            const ee = {};
            let te = null;
            class re {
                constructor(e = U) {
                    this._favorites = [], this._favoritesChanged = new(q()), this._settings = e, K.TVXWindowEvents.on("StudyFavoritesChanged", e => {
                        const t = JSON.parse(e);
                        this._loadFromState(t.favorites || [])
                    }), this._settings.onSync.subscribe(this, this._loadFavs), this._loadFavs()
                }
                isFav(e) {
                    const t = this.favId(e);
                    return -1 !== this._findFavIndex(t)
                }
                toggleFavorite(e) {
                    this.isFav(e) ? this.removeFavorite(e) : this.addFavorite(e)
                }
                addFavorite(e) {
                    const t = this.favId(e);
                    this._favorites.push(ie(t)), this._favoritesChanged.fire(), this._saveFavs()
                }
                removeFavorite(e) {
                    const t = this.favId(e),
                        r = this._findFavIndex(t); - 1 !== r && (this._favorites.splice(r, 1), this._favoritesChanged.fire()), this._saveFavs()
                }
                favId(e) {
                    return (0, Z.isPineIdString)(e) ? e : (0, Z.extractPineId)(e) || (0, Y.extractStudyId)(e)
                }
                favorites() {
                    return this._favorites
                }
                favoritePineIds() {
                    return this._favorites.filter(e => "pine" === e.type).map(e => e.pineId)
                }
                favoritesChanged() {
                    return this._favoritesChanged
                }
                static getInstance() {
                    return null === te && (te = new re), te
                }
                static create(e) {
                    return new re(e)
                }
                _loadFavs() {
                    const e = this._settings.getJSON("studyMarket.favorites", []);
                    this._loadFromState(e)
                }
                _saveFavs() {
                    const e = this._stateToSave();
                    this._settings.setJSON("studyMarket.favorites", e, {
                        forceFlush: !0
                    }), K.TVXWindowEvents.emit("StudyFavoritesChanged", JSON.stringify({
                        favorites: e
                    }))
                }
                _stateToSave() {
                    return this._favorites.map(ne)
                }
                _loadFromState(e) {
                    this._favorites = e.map(e => ie(function(e) {
                        return e in ee ? ee[e] : e
                    }(e))), this._favoritesChanged.fire()
                }
                _findFavIndex(e) {
                    return this._favorites.findIndex(t => e === ne(t))
                }
            }

            function ne(e) {
                return "java" === e.type ? e.studyId : e.pineId
            }

            function ie(e) {
                return (0, Z.isPineIdString)(e) ? {
                    type: "pine",
                    pineId: e
                } : {
                    type: "java",
                    studyId: e
                }
            }
            var oe = r(41083);
            const se = {
                [oe.ResolutionKind.Ticks]: !1,
                [oe.ResolutionKind.Seconds]: !1,
                [oe.ResolutionKind.Minutes]: !1,
                [oe.SpecialResolutionKind.Hours]: !1,
                [oe.ResolutionKind.Days]: !1,
                [oe.ResolutionKind.Range]: !1
            };
            class ae extends F.CommonJsonStoreService {
                constructor(e, t, r = se) {
                    super(e, t, "INTERVALS_MENU_VIEW_STATE_CHANGED", "IntervalWidget.menu.viewState", r)
                }
                isAllowed(e) {
                    return Object.keys(se).includes(e)
                }
            }
            var le = r(36890);
            const ue = {
                    Area: 3,
                    Bars: 0,
                    Candles: 1,
                    "Heiken Ashi": 8,
                    "Hollow Candles": 9,
                    Line: 2,
                    Renko: 4,
                    Kagi: 5,
                    "Point & figure": 6,
                    "Line Break": 7,
                    Baseline: 10
                },
                ce = ["1", "30", "60"];

            function de(e = []) {
                let t = e.map(e => ue[e]) || [1, 4, 5, 6];
                return c.enabled("widget") && (t = [0, 1, 3]), t
            }

            function he(e = []) {
                return (0, A.mergeResolutions)(e, c.enabled("star_some_intervals_by_default") ? ce : [])
            }
            new B(K.TVXWindowEvents, U, he()), new L(K.TVXWindowEvents, U, de()), new le.FavoriteStudyTemplateService(K.TVXWindowEvents, U);
            const pe = {
                tools: h.any.isRequired,
                isFundamental: h.any,
                chartApiInstance: h.any,
                availableTimeFrames: h.any,
                chartWidgetCollection: h.any,
                windowMessageService: h.any,
                favoriteChartStylesService: h.any,
                favoriteIntervalsService: h.any,
                intervalService: h.any,
                favoriteStudyTemplatesService: h.any,
                studyTemplates: h.any,
                chartChangesWatcher: h.any,
                saveChartService: h.any,
                sharingChartService: h.any,
                loadChartService: h.any,
                chartWidget: h.any,
                favoriteScriptsModel: h.any,
                intervalsMenuViewStateService: h.any,
                templatesMenuViewStateService: h.any,
                financialsDialogController: h.any,
                snapshotUrl: h.any
            };
            var fe = r(93605),
                me = r(85291);
            const ve = [];
            class ye extends n.PureComponent {
                constructor(e) {
                    super(e), this._saveLoadSyncEmitter = new(l()), this._handleFullWidthChange = e => {
                        this._fullWidth = e, this.setState({
                            measureValid: !1
                        })
                    }, this._handleFavoritesWidthChange = e => {
                        this._favoritesWidth = e, this.setState({
                            measureValid: !1
                        })
                    }, this._handleCollapseWidthChange = e => {
                        this._collapseWidth = e, this.setState({
                            measureValid: !1
                        })
                    }, this._handleMeasure = e => {
                        this.setState({
                            availableWidth: e,
                            measureValid: !1
                        })
                    };
                    const {
                        tools: t,
                        windowMessageService: r,
                        chartWidgetCollection: n,
                        chartApiInstance: i,
                        availableTimeFrames: s,
                        isFundamental: a,
                        favoriteIntervalsService: d,
                        favoriteChartStylesService: h,
                        favoriteStudyTemplatesService: p,
                        studyTemplates: f,
                        saveChartService: m,
                        sharingChartService: v,
                        loadChartService: y,
                        financialsDialogController: g,
                        snapshotUrl: b
                    } = e;
                    this._showScrollbarWhen = (0, o.ensureDefined)(e.allowedModes).slice(-1), this._panelWidthChangeHandlers = {
                        full: this._handleFullWidthChange,
                        medium: this._handleFavoritesWidthChange,
                        small: this._handleCollapseWidthChange
                    };
                    const {
                        chartChangesWatcher: S
                    } = e;
                    this._chartChangesWatcher = S;
                    const w = de(this.props.defaultFavoriteStyles);
                    this._favoriteChartStylesService = h || new L(K.TVXWindowEvents, U, w);
                    const _ = he(this.props.defaultFavoriteIntervals);
                    this._favoriteIntervalsService = d || new B(K.TVXWindowEvents, U, _), this._intervalsMenuViewStateService = new ae(K.TVXWindowEvents, U), this._intervalService = new G(i), this._registry = {
                        tools: t,
                        isFundamental: a,
                        chartWidgetCollection: n,
                        windowMessageService: r,
                        chartApiInstance: i,
                        availableTimeFrames: s,
                        favoriteStudyTemplatesService: p,
                        studyTemplates: f,
                        saveChartService: m,
                        sharingChartService: v,
                        loadChartService: y,
                        intervalsMenuViewStateService: this._intervalsMenuViewStateService,
                        favoriteChartStylesService: this._favoriteChartStylesService,
                        favoriteIntervalsService: this._favoriteIntervalsService,
                        intervalService: this._intervalService,
                        chartChangesWatcher: this._chartChangesWatcher,
                        chartWidget: n.activeChartWidget.value(),
                        favoriteScriptsModel: re.getInstance(),
                        templatesMenuViewStateService: this._templatesMenuVuewStateService,
                        financialsDialogController: g,
                        snapshotUrl: b
                    }, this.state = {
                        isVisible: !0,
                        availableWidth: 0,
                        displayMode: "full",
                        measureValid: !1,
                        leftCustomElements: [],
                        rightCustomElements: []
                    }, this._readOnly = n.readOnly(), this._features = {
                        allowFavoriting: c.enabled("items_favoriting"),
                        showIdeasButton: Boolean(this.props.ideas),
                        showLaunchInPopupButton: Boolean(this.props.popupButton),
                        allowSymbolSearchSpread: c.enabled("header_symbol_search") && c.enabled("show_spread_operators"),
                        allowToolbarHiding: c.enabled("collapsible_header")
                    }, this._setDisplayMode = (0, u.default)(this._setDisplayMode, 100), this._negotiateResizer()
                }
                componentDidUpdate(e, t) {
                    const {
                        isVisible: r,
                        measureValid: n
                    } = this.state;
                    r !== t.isVisible && (d.emit("toggle_header", r), this._negotiateResizer()), n || this._setDisplayMode()
                }
                render() {
                    const {
                        resizerBridge: e,
                        allowedModes: t,
                        ...r
                    } = this.props, {
                        displayMode: i,
                        isVisible: a,
                        leftCustomElements: l,
                        rightCustomElements: u
                    } = this.state, c = {
                        features: this._features,
                        readOnly: this._readOnly,
                        isFake: !1,
                        saveLoadSyncEmitter: this._saveLoadSyncEmitter,
                        leftCustomElements: l,
                        rightCustomElements: u,
                        ...r
                    }, d = { ...c,
                        isFake: !0,
                        showScrollbarWhen: ve
                    }, h = (0, o.ensureDefined)(t), p = this.props.tools.PublishButtonManager || n.Fragment;
                    return n.createElement(I.RegistryProvider, {
                        value: this._registry,
                        validation: pe
                    }, n.createElement(p, null, n.createElement("div", {
                        className: s(me.toolbar, {
                            [me.isHidden]: !a
                        }),
                        onClick: this.props.onClick
                    }, n.createElement("div", {
                        className: me.overflowWrap
                    }, n.createElement(V, {
                        key: "live",
                        showScrollbarWhen: this._showScrollbarWhen,
                        displayMode: i,
                        onAvailableSpaceChange: this._handleMeasure,
                        ...c
                    }), h.map(e => n.createElement(V, {
                        key: e,
                        displayMode: e,
                        onWidthChange: this._panelWidthChangeHandlers[e],
                        ...d
                    }))))))
                }
                addButton(e, t) {
                    if (!t.useTradingViewStyle) return this._addCustomHTMLButton(e, t.align);
                    this._addCustomTradingViewStyledButton(e, t)
                }
                addDropdown(e, t) {
                    const {
                        leftCustomElements: r,
                        rightCustomElements: n
                    } = this.state, i = {
                        type: "Dropdown",
                        id: e,
                        params: t
                    };
                    "left" === t.align ? this.setState({
                        leftCustomElements: [...r, i]
                    }) : this.setState({
                        rightCustomElements: [...n, i]
                    })
                }
                updateDropdown(e, t) {
                    const r = t => "Dropdown" === t.type && t.id === e,
                        n = this.state.leftCustomElements.find(r) || this.state.rightCustomElements.find(r);
                    void 0 !== n && (n.params = { ...n.params,
                        ...t
                    }, this.setState({
                        leftCustomElements: this.state.leftCustomElements.slice(),
                        rightCustomElements: this.state.rightCustomElements.slice()
                    }))
                }
                removeDropdown(e) {
                    const t = t => "Dropdown" === t.type && t.id !== e,
                        r = this.state.leftCustomElements.filter(t),
                        n = this.state.rightCustomElements.filter(t);
                    this.setState({
                        leftCustomElements: r,
                        rightCustomElements: n
                    })
                }
                _negotiateResizer() {
                    this.props.resizerBridge.negotiateHeight(this.state.isVisible ? $.HEADER_TOOLBAR_HEIGHT_EXPANDED : $.HEADER_TOOLBAR_HEIGHT_COLLAPSED)
                }
                _setDisplayMode() {
                    const {
                        availableWidth: e
                    } = this.state, {
                        allowedModes: t
                    } = this.props, r = {
                        full: this._fullWidth,
                        medium: this._favoritesWidth,
                        small: this._collapseWidth
                    }, n = (0, o.ensureDefined)(t);
                    let i = n.map(e => r[e]).findIndex(t => e >= t); - 1 === i && (i = n.length - 1);
                    const s = n[i];
                    this.setState({
                        measureValid: !0,
                        displayMode: s
                    })
                }
                _addCustomHTMLButton(e, t = "left") {
                    const r = new(D())(0),
                        n = (0, fe.parseHtmlElement)(`<div class="apply-common-tooltip ${me.customButton}">`),
                        i = {
                            type: "Button",
                            id: e,
                            params: {
                                key: Number(new Date),
                                element: n,
                                width: r
                            }
                        };
                    return this._addCustomElementToState(t, i), n
                }
                _addCustomTradingViewStyledButton(e, t) {
                    const r = {
                        type: "TradingViewStyledButton",
                        id: e,
                        params: {
                            key: Number(new Date),
                            text: t.text,
                            title: t.title,
                            onClick: t.onClick
                        }
                    };
                    this._addCustomElementToState(t.align, r)
                }
                _addCustomElementToState(e, t) {
                    const {
                        leftCustomElements: r,
                        rightCustomElements: n
                    } = this.state;
                    "left" === e ? this.setState({
                        leftCustomElements: [...r, t]
                    }) : this.setState({
                        rightCustomElements: [...n, t]
                    })
                }
            }
            ye.defaultProps = {
                allowedModes: ["full", "medium"]
            };
            class ge {
                constructor(e, t) {
                    this._component = null, this._handleRef = e => {
                        this._component = e
                    }, this._container = e, i.render(n.createElement(ye, { ...t,
                        ref: this._handleRef
                    }), this._container)
                }
                destroy() {
                    i.unmountComponentAtNode(this._container)
                }
                getComponent() {
                    return (0, o.ensureNotNull)(this._component)
                }
            }
        },
        4257: (e, t, r) => {
            "use strict";
            r.d(t, {
                hasNewHeaderToolbarStyles: () => n
            });
            r(82527);
            const n = !1
        },
        23404: (e, t, r) => {
            "use strict";
            r.d(t, {
                validateRegistry: () => a,
                RegistryProvider: () => l,
                registryContextType: () => u
            });
            var n = r(59496),
                i = r(19036),
                o = r.n(i);
            const s = n.createContext({});

            function a(e, t) {
                o().checkPropTypes(t, e, "context", "RegistryContext")
            }

            function l(e) {
                const {
                    validation: t,
                    value: r
                } = e;
                return a(r, t), n.createElement(s.Provider, {
                    value: r
                }, e.children)
            }

            function u() {
                return s
            }
        },
        7270: function(e, t, r) {
            var n, i, o;
            e.exports = (n = r(59496), i = r(87995), o = r(59255), function(e) {
                function t(n) {
                    if (r[n]) return r[n].exports;
                    var i = r[n] = {
                        exports: {},
                        id: n,
                        loaded: !1
                    };
                    return e[n].call(i.exports, i, i.exports, t), i.loaded = !0, i.exports
                }
                var r = {};
                return t.m = e, t.c = r, t.p = "dist/", t(0)
            }([function(e, t, r) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var n = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(r(1));
                t.default = n.default, e.exports = t.default
            }, function(e, t, r) {
                "use strict";

                function n(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var i = function() {
                        function e(e, t) {
                            for (var r = 0; r < t.length; r++) {
                                var n = t[r];
                                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                            }
                        }
                        return function(t, r, n) {
                            return r && e(t.prototype, r), n && e(t, n), t
                        }
                    }(),
                    o = r(2),
                    s = (n(o), r(3)),
                    a = n(s),
                    l = n(r(13)),
                    u = n(r(14)),
                    c = n(r(15)),
                    d = function(e) {
                        function t(e) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, t);
                            var r = function(e, t) {
                                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !t || "object" != typeof t && "function" != typeof t ? e : t
                            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                            return r.measure = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r.props.includeMargin;
                                if (r.props.shouldMeasure) {
                                    r._node.parentNode || r._setDOMNode();
                                    var t = r.getDimensions(r._node, e),
                                        n = "function" == typeof r.props.children;
                                    r._propsToMeasure.some((function(e) {
                                        if (t[e] !== r._lastDimensions[e]) return r.props.onMeasure(t), n && void 0 !== r && r.setState({
                                            dimensions: t
                                        }), r._lastDimensions = t, !0
                                    }))
                                }
                            }, r.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, r._node = null, r._propsToMeasure = r._getPropsToMeasure(e), r._lastDimensions = {}, r
                        }
                        return function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                        }(t, e), i(t, [{
                            key: "componentDidMount",
                            value: function() {
                                var e = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new u.default((function() {
                                    return e.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(e) {
                                var t = (e.config, e.whitelist),
                                    r = e.blacklist;
                                this.props.whitelist === t && this.props.blacklist === r || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: t,
                                    blacklist: r
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = l.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, c.default)(e, {
                                    margin: t
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(e) {
                                var t = e.whitelist,
                                    r = e.blacklist;
                                return t.filter((function(e) {
                                    return r.indexOf(e) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.props.children;
                                return o.Children.only("function" == typeof e ? e(this.state.dimensions) : e)
                            }
                        }]), t
                    }(o.Component);
                d.propTypes = {
                    whitelist: a.default.array,
                    blacklist: a.default.array,
                    includeMargin: a.default.bool,
                    useClone: a.default.bool,
                    cloneOptions: a.default.object,
                    shouldMeasure: a.default.bool,
                    onMeasure: a.default.func
                }, d.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, t.default = d, e.exports = t.default
            }, function(e, t) {
                e.exports = n
            }, function(e, t, r) {
                (function(t) {
                    "use strict";
                    var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) {
                        var i = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        e.exports = r(5)((function(e) {
                            return "object" === (void 0 === e ? "undefined" : n(e)) && null !== e && e.$$typeof === i
                        }), !0)
                    } else e.exports = r(12)()
                }).call(t, r(4))
            }, function(e, t) {
                "use strict";

                function r() {
                    throw new Error("setTimeout has not been defined")
                }

                function n() {
                    throw new Error("clearTimeout has not been defined")
                }

                function i(e) {
                    if (u === setTimeout) return setTimeout(e, 0);
                    if ((u === r || !u) && setTimeout) return u = setTimeout, setTimeout(e, 0);
                    try {
                        return u(e, 0)
                    } catch (t) {
                        try {
                            return u.call(null, e, 0)
                        } catch (t) {
                            return u.call(this, e, 0)
                        }
                    }
                }

                function o() {
                    f && h && (f = !1, h.length ? p = h.concat(p) : m = -1, p.length && s())
                }

                function s() {
                    if (!f) {
                        var e = i(o);
                        f = !0;
                        for (var t = p.length; t;) {
                            for (h = p, p = []; ++m < t;) h && h[m].run();
                            m = -1, t = p.length
                        }
                        h = null, f = !1,
                            function(e) {
                                if (c === clearTimeout) return clearTimeout(e);
                                if ((c === n || !c) && clearTimeout) return c = clearTimeout, clearTimeout(e);
                                try {
                                    c(e)
                                } catch (t) {
                                    try {
                                        return c.call(null, e)
                                    } catch (t) {
                                        return c.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function a(e, t) {
                    this.fun = e, this.array = t
                }

                function l() {}
                var u, c, d = e.exports = {};
                ! function() {
                    try {
                        u = "function" == typeof setTimeout ? setTimeout : r
                    } catch (e) {
                        u = r
                    }
                    try {
                        c = "function" == typeof clearTimeout ? clearTimeout : n
                    } catch (e) {
                        c = n
                    }
                }();
                var h, p = [],
                    f = !1,
                    m = -1;
                d.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                    p.push(new a(e, t)), 1 !== p.length || f || i(s)
                }, a.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, d.title = "browser", d.browser = !0, d.env = {}, d.argv = [], d.version = "", d.versions = {}, d.on = l, d.addListener = l, d.once = l, d.off = l, d.removeListener = l, d.removeAllListeners = l, d.emit = l, d.prependListener = l, d.prependOnceListener = l, d.listeners = function(e) {
                    return []
                }, d.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, d.cwd = function() {
                    return "/"
                }, d.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, d.umask = function() {
                    return 0
                }
            }, function(e, t, r) {
                (function(t) {
                    "use strict";
                    var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        },
                        i = r(6),
                        o = r(7),
                        s = r(8),
                        a = r(9),
                        l = r(10),
                        u = r(11);
                    e.exports = function(e, r) {
                        function c(e, t) {
                            return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
                        }

                        function d(e) {
                            this.message = e, this.stack = ""
                        }

                        function h(e) {
                            function n(n, u, c, h, p, f, m) {
                                if (h = h || S, f = f || c, m !== l)
                                    if (r) o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== t.env.NODE_ENV && "undefined" != typeof console) {
                                    var v = h + ":" + c;
                                    !i[v] && a < 3 && (s(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", f, h), i[v] = !0, a++)
                                }
                                return null == u[c] ? n ? new d(null === u[c] ? "The " + p + " `" + f + "` is marked as required in `" + h + "`, but its value is `null`." : "The " + p + " `" + f + "` is marked as required in `" + h + "`, but its value is `undefined`.") : null : e(u, c, h, p, f)
                            }
                            if ("production" !== t.env.NODE_ENV) var i = {},
                                a = 0;
                            var u = n.bind(null, !1);
                            return u.isRequired = n.bind(null, !0), u
                        }

                        function p(e) {
                            return h((function(t, r, n, i, o, s) {
                                var a = t[r];
                                return m(a) !== e ? new d("Invalid " + i + " `" + o + "` of type `" + v(a) + "` supplied to `" + n + "`, expected `" + e + "`.") : null
                            }))
                        }

                        function f(t) {
                            switch (void 0 === t ? "undefined" : n(t)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !t;
                                case "object":
                                    if (Array.isArray(t)) return t.every(f);
                                    if (null === t || e(t)) return !0;
                                    var r = function(e) {
                                        var t = e && (g && e[g] || e[b]);
                                        if ("function" == typeof t) return t
                                    }(t);
                                    if (!r) return !1;
                                    var i, o = r.call(t);
                                    if (r !== t.entries) {
                                        for (; !(i = o.next()).done;)
                                            if (!f(i.value)) return !1
                                    } else
                                        for (; !(i = o.next()).done;) {
                                            var s = i.value;
                                            if (s && !f(s[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function m(e) {
                            var t = void 0 === e ? "undefined" : n(e);
                            return Array.isArray(e) ? "array" : e instanceof RegExp ? "object" : function(e, t) {
                                return "symbol" === e || "Symbol" === t["@@toStringTag"] || "function" == typeof Symbol && t instanceof Symbol
                            }(t, e) ? "symbol" : t
                        }

                        function v(e) {
                            if (null == e) return "" + e;
                            var t = m(e);
                            if ("object" === t) {
                                if (e instanceof Date) return "date";
                                if (e instanceof RegExp) return "regexp"
                            }
                            return t
                        }

                        function y(e) {
                            var t = v(e);
                            switch (t) {
                                case "array":
                                case "object":
                                    return "an " + t;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + t;
                                default:
                                    return t
                            }
                        }
                        var g = "function" == typeof Symbol && Symbol.iterator,
                            b = "@@iterator",
                            S = "<<anonymous>>",
                            w = {
                                array: p("array"),
                                bool: p("boolean"),
                                func: p("function"),
                                number: p("number"),
                                object: p("object"),
                                string: p("string"),
                                symbol: p("symbol"),
                                any: h(i.thatReturnsNull),
                                arrayOf: function(e) {
                                    return h((function(t, r, n, i, o) {
                                        if ("function" != typeof e) return new d("Property `" + o + "` of component `" + n + "` has invalid PropType notation inside arrayOf.");
                                        var s = t[r];
                                        if (!Array.isArray(s)) return new d("Invalid " + i + " `" + o + "` of type `" + m(s) + "` supplied to `" + n + "`, expected an array.");
                                        for (var a = 0; a < s.length; a++) {
                                            var u = e(s, a, n, i, o + "[" + a + "]", l);
                                            if (u instanceof Error) return u
                                        }
                                        return null
                                    }))
                                },
                                element: h((function(t, r, n, i, o) {
                                    var s = t[r];
                                    return e(s) ? null : new d("Invalid " + i + " `" + o + "` of type `" + m(s) + "` supplied to `" + n + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(e) {
                                    return h((function(t, r, n, i, o) {
                                        if (!(t[r] instanceof e)) {
                                            var s = e.name || S;
                                            return new d("Invalid " + i + " `" + o + "` of type `" + function(e) {
                                                return e.constructor && e.constructor.name ? e.constructor.name : S
                                            }(t[r]) + "` supplied to `" + n + "`, expected instance of `" + s + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: h((function(e, t, r, n, i) {
                                    return f(e[t]) ? null : new d("Invalid " + n + " `" + i + "` supplied to `" + r + "`, expected a ReactNode.")
                                })),
                                objectOf: function(e) {
                                    return h((function(t, r, n, i, o) {
                                        if ("function" != typeof e) return new d("Property `" + o + "` of component `" + n + "` has invalid PropType notation inside objectOf.");
                                        var s = t[r],
                                            a = m(s);
                                        if ("object" !== a) return new d("Invalid " + i + " `" + o + "` of type `" + a + "` supplied to `" + n + "`, expected an object.");
                                        for (var u in s)
                                            if (s.hasOwnProperty(u)) {
                                                var c = e(s, u, n, i, o + "." + u, l);
                                                if (c instanceof Error) return c
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(e) {
                                    return Array.isArray(e) ? h((function(t, r, n, i, o) {
                                        for (var s = t[r], a = 0; a < e.length; a++)
                                            if (c(s, e[a])) return null;
                                        return new d("Invalid " + i + " `" + o + "` of value `" + s + "` supplied to `" + n + "`, expected one of " + JSON.stringify(e) + ".")
                                    })) : ("production" !== t.env.NODE_ENV && s(!1, "Invalid argument supplied to oneOf, expected an instance of array."), i.thatReturnsNull)
                                },
                                oneOfType: function(e) {
                                    if (!Array.isArray(e)) return "production" !== t.env.NODE_ENV && s(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), i.thatReturnsNull;
                                    for (var r = 0; r < e.length; r++) {
                                        var n = e[r];
                                        if ("function" != typeof n) return s(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", y(n), r), i.thatReturnsNull
                                    }
                                    return h((function(t, r, n, i, o) {
                                        for (var s = 0; s < e.length; s++)
                                            if (null == (0, e[s])(t, r, n, i, o, l)) return null;
                                        return new d("Invalid " + i + " `" + o + "` supplied to `" + n + "`.")
                                    }))
                                },
                                shape: function(e) {
                                    return h((function(t, r, n, i, o) {
                                        var s = t[r],
                                            a = m(s);
                                        if ("object" !== a) return new d("Invalid " + i + " `" + o + "` of type `" + a + "` supplied to `" + n + "`, expected `object`.");
                                        for (var u in e) {
                                            var c = e[u];
                                            if (c) {
                                                var h = c(s, u, n, i, o + "." + u, l);
                                                if (h) return h
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(e) {
                                    return h((function(t, r, n, i, o) {
                                        var s = t[r],
                                            u = m(s);
                                        if ("object" !== u) return new d("Invalid " + i + " `" + o + "` of type `" + u + "` supplied to `" + n + "`, expected `object`.");
                                        var c = a({}, t[r], e);
                                        for (var h in c) {
                                            var p = e[h];
                                            if (!p) return new d("Invalid " + i + " `" + o + "` key `" + h + "` supplied to `" + n + "`.\nBad object: " + JSON.stringify(t[r], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(e), null, "  "));
                                            var f = p(s, h, n, i, o + "." + h, l);
                                            if (f) return f
                                        }
                                        return null
                                    }))
                                }
                            };
                        return d.prototype = Error.prototype, w.checkPropTypes = u, w.PropTypes = w, w
                    }
                }).call(t, r(4))
            }, function(e, t) {
                "use strict";

                function r(e) {
                    return function() {
                        return e
                    }
                }
                var n = function() {};
                n.thatReturns = r, n.thatReturnsFalse = r(!1), n.thatReturnsTrue = r(!0), n.thatReturnsNull = r(null), n.thatReturnsThis = function() {
                    return this
                }, n.thatReturnsArgument = function(e) {
                    return e
                }, e.exports = n
            }, function(e, t, r) {
                (function(t) {
                    "use strict";
                    var r = function(e) {};
                    "production" !== t.env.NODE_ENV && (r = function(e) {
                        if (void 0 === e) throw new Error("invariant requires an error message argument")
                    }), e.exports = function(e, t, n, i, o, s, a, l) {
                        if (r(t), !e) {
                            var u;
                            if (void 0 === t) u = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var c = [n, i, o, s, a, l],
                                    d = 0;
                                (u = new Error(t.replace(/%s/g, (function() {
                                    return c[d++]
                                })))).name = "Invariant Violation"
                            }
                            throw u.framesToPop = 1, u
                        }
                    }
                }).call(t, r(4))
            }, function(e, t, r) {
                (function(t) {
                    "use strict";
                    var n = r(6);
                    if ("production" !== t.env.NODE_ENV) {
                        var i = function(e) {
                            for (var t = arguments.length, r = Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
                            var i = 0,
                                o = "Warning: " + e.replace(/%s/g, (function() {
                                    return r[i++]
                                }));
                            "undefined" != typeof console && console.error(o);
                            try {
                                throw new Error(o)
                            } catch (e) {}
                        };
                        n = function(e, t) {
                            if (void 0 === t) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== t.indexOf("Failed Composite propType: ") && !e) {
                                for (var r = arguments.length, n = Array(r > 2 ? r - 2 : 0), o = 2; o < r; o++) n[o - 2] = arguments[o];
                                i.apply(void 0, [t].concat(n))
                            }
                        }
                    }
                    e.exports = n
                }).call(t, r(4))
            }, function(e, t) {
                "use strict";

                function r(e) {
                    if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }
                var n = Object.getOwnPropertySymbols,
                    i = Object.prototype.hasOwnProperty,
                    o = Object.prototype.propertyIsEnumerable;
                e.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var e = new String("abc");
                        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                        for (var t = {}, r = 0; r < 10; r++) t["_" + String.fromCharCode(r)] = r;
                        if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                                return t[e]
                            })).join("")) return !1;
                        var n = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                            n[e] = e
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, n)).join("")
                    } catch (e) {
                        return !1
                    }
                }() ? Object.assign : function(e, t) {
                    for (var s, a, l = r(e), u = 1; u < arguments.length; u++) {
                        for (var c in s = Object(arguments[u])) i.call(s, c) && (l[c] = s[c]);
                        if (n) {
                            a = n(s);
                            for (var d = 0; d < a.length; d++) o.call(s, a[d]) && (l[a[d]] = s[a[d]])
                        }
                    }
                    return l
                }
            }, function(e, t) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(e, t, r) {
                (function(t) {
                    "use strict";
                    var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) var i = r(7),
                        o = r(8),
                        s = r(10),
                        a = {};
                    e.exports = function(e, r, l, u, c) {
                        if ("production" !== t.env.NODE_ENV)
                            for (var d in e)
                                if (e.hasOwnProperty(d)) {
                                    var h;
                                    try {
                                        i("function" == typeof e[d], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", u || "React class", l, d, n(e[d])), h = e[d](r, d, u, l, null, s)
                                    } catch (e) {
                                        h = e
                                    }
                                    if (o(!h || h instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", u || "React class", l, d, void 0 === h ? "undefined" : n(h)), h instanceof Error && !(h.message in a)) {
                                        a[h.message] = !0;
                                        var p = c ? c() : "";
                                        o(!1, "Failed %s type: %s%s", l, h.message, null != p ? p : "")
                                    }
                                }
                    }
                }).call(t, r(4))
            }, function(e, t, r) {
                "use strict";
                var n = r(6),
                    i = r(7),
                    o = r(10);
                e.exports = function() {
                    function e(e, t, r, n, s, a) {
                        a !== o && i(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function t() {
                        return e
                    }
                    e.isRequired = e;
                    var r = {
                        array: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: t,
                        element: e,
                        instanceOf: t,
                        node: e,
                        objectOf: t,
                        oneOf: t,
                        oneOfType: t,
                        shape: t,
                        exact: t
                    };
                    return r.checkPropTypes = n, r.PropTypes = r, r
                }
            }, function(e, t) {
                e.exports = i
            }, function(e, t) {
                e.exports = o
            }, function(e, t, r) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        r = e.getBoundingClientRect(),
                        i = void 0,
                        o = void 0,
                        s = void 0;
                    return t.margin && (s = (0, n.default)(getComputedStyle(e))), t.margin ? (i = s.left + r.width + s.right, o = s.top + r.height + s.bottom) : (i = r.width, o = r.height), {
                        width: i,
                        height: o,
                        top: r.top,
                        right: r.right,
                        bottom: r.bottom,
                        left: r.left
                    }
                };
                var n = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(r(16));
                e.exports = t.default
            }, function(e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    return {
                        top: r((e = e || {}).marginTop),
                        right: r(e.marginRight),
                        bottom: r(e.marginBottom),
                        left: r(e.marginLeft)
                    }
                };
                var r = function(e) {
                    return parseInt(e) || 0
                };
                e.exports = t.default
            }]))
        },
        70086: (e, t, r) => {
            "use strict";
            r.d(t, {
                FragmentMap: () => i
            });
            var n = r(59496);

            function i(e) {
                if (e.map) {
                    return n.Children.toArray(e.children).map(e.map)
                }
                return e.children
            }
        },
        21258: (e, t, r) => {
            "use strict";
            r.d(t, {
                hoverMouseEventFilter: () => o,
                useAccurateHover: () => s,
                useHover: () => i
            });
            var n = r(59496);

            function i() {
                const [e, t] = (0, n.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        o(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        o(e) && t(!1)
                    }
                }]
            }

            function o(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function s(e) {
                const [t, r] = (0, n.useState)(!1);
                return (0, n.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const n = e.current.contains(t.target);
                        r(n)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        86746: (e, t, r) => {
            "use strict";
            r.d(t, {
                HorizontalScroll: () => b
            });
            var n = r(59496),
                i = r(97754),
                o = r(7270),
                s = r(88537),
                a = r(72571),
                l = r(42609),
                u = r(85787),
                c = r(34581),
                d = r(86219),
                h = r(41814);
            const p = {
                isVisibleScrollbar: !0,
                shouldMeasure: !0,
                hideButtonsFrom: 1
            };

            function f(e) {
                return n.createElement("div", {
                    className: i(h.fadeLeft, e.className, {
                        [h.isVisible]: e.isVisible
                    })
                })
            }

            function m(e) {
                return n.createElement("div", {
                    className: i(h.fadeRight, e.className, {
                        [h.isVisible]: e.isVisible
                    })
                })
            }

            function v(e) {
                return n.createElement(g, { ...e,
                    className: h.scrollLeft
                })
            }

            function y(e) {
                return n.createElement(g, { ...e,
                    className: h.scrollRight
                })
            }

            function g(e) {
                return n.createElement("div", {
                    className: i(e.className, {
                        [h.isVisible]: e.isVisible
                    }),
                    onClick: e.onClick
                }, n.createElement("div", {
                    className: h.iconWrap
                }, n.createElement(a.Icon, {
                    icon: d,
                    className: h.icon
                })))
            }
            const b = function(e = v, t = y, r = f, a = m) {
                var d;
                return (d = class extends n.PureComponent {
                    constructor(e) {
                        super(e), this._scroll = n.createRef(), this._wrapMeasureRef = n.createRef(), this._contentMeasureRef = n.createRef(), this._handleScrollLeft = () => {
                            if (this.props.onScrollButtonClick) return void this.props.onScrollButtonClick("left");
                            const e = this.props.scrollStepSize || this.state.widthWrap - 50;
                            this.animateTo(Math.max(0, this.currentPosition() - e))
                        }, this._handleScrollRight = () => {
                            if (this.props.onScrollButtonClick) return void this.props.onScrollButtonClick("right");
                            const e = this.props.scrollStepSize || this.state.widthWrap - 50;
                            this.animateTo(Math.min((this.state.widthContent || 0) - (this.state.widthWrap || 0), this.currentPosition() + e))
                        }, this._handleResizeWrap = e => {
                            this.props.onMeasureWrap && this.props.onMeasureWrap(e), this.setState({
                                widthWrap: e.width
                            }), this._checkButtonsVisibility()
                        }, this._handleResizeContent = e => {
                            this.props.onMeasureContent && this.props.onMeasureContent(e);
                            const {
                                shouldDecreaseWidthContent: t,
                                buttonsWidthIfDecreasedWidthContent: r
                            } = this.props;
                            t && r ? this.setState({
                                widthContent: e.width + 2 * r
                            }) : this.setState({
                                widthContent: e.width
                            })
                        }, this._handleScroll = () => {
                            const {
                                onScroll: e
                            } = this.props;
                            e && e(this.currentPosition(), this.isAtLeft(), this.isAtRight()), this._checkButtonsVisibility()
                        }, this._checkButtonsVisibility = () => {
                            const {
                                isVisibleLeftButton: e,
                                isVisibleRightButton: t
                            } = this.state, r = this.isAtLeft(), n = this.isAtRight();
                            r || e ? r && e && this.setState({
                                isVisibleLeftButton: !1
                            }) : this.setState({
                                isVisibleLeftButton: !0
                            }), n || t ? n && t && this.setState({
                                isVisibleRightButton: !1
                            }) : this.setState({
                                isVisibleRightButton: !0
                            })
                        }, this.state = {
                            widthContent: 0,
                            widthWrap: 0,
                            isVisibleRightButton: !1,
                            isVisibleLeftButton: !1
                        }
                    }
                    componentDidMount() {
                        this._checkButtonsVisibility()
                    }
                    componentDidUpdate(e, t) {
                        t.widthWrap === this.state.widthWrap && t.widthContent === this.state.widthContent || this._handleScroll(), this.props.shouldMeasure && this._wrapMeasureRef.current && this._contentMeasureRef.current && (this._wrapMeasureRef.current.measure(), this._contentMeasureRef.current.measure())
                    }
                    currentPosition() {
                        return this._scroll.current ? (0, c.isRtl)() ? (0, c.getLTRScrollLeft)(this._scroll.current) : this._scroll.current.scrollLeft : 0
                    }
                    isAtLeft() {
                        return !this._isOverflowed() || this.currentPosition() <= (0, s.ensureDefined)(this.props.hideButtonsFrom)
                    }
                    isAtRight() {
                        return !this._isOverflowed() || this.currentPosition() + this.state.widthWrap >= this.state.widthContent - (0, s.ensureDefined)(this.props.hideButtonsFrom)
                    }
                    animateTo(e, t = u.dur) {
                        const r = this._scroll.current;
                        r && ((0, c.isRtl)() && (e = (0, c.getLTRScrollLeftOffset)(r, e)), t <= 0 ? r.scrollLeft = Math.round(e) : (0, l.doAnimate)({
                            onStep(e, t) {
                                r.scrollLeft = Math.round(t)
                            },
                            from: r.scrollLeft,
                            to: Math.round(e),
                            easing: u.easingFunc.easeInOutCubic,
                            duration: t
                        }))
                    }
                    render() {
                        const {
                            children: s,
                            isVisibleScrollbar: l,
                            isVisibleFade: u,
                            isVisibleButtons: c,
                            shouldMeasure: d,
                            shouldDecreaseWidthContent: p,
                            buttonsWidthIfDecreasedWidthContent: f,
                            onMouseOver: m,
                            onMouseOut: v,
                            scrollWrapClassName: y,
                            fadeClassName: g
                        } = this.props, {
                            isVisibleRightButton: b,
                            isVisibleLeftButton: S
                        } = this.state, w = p && f;
                        return n.createElement(o, {
                            whitelist: ["width"],
                            onMeasure: this._handleResizeWrap,
                            shouldMeasure: d,
                            ref: this._wrapMeasureRef
                        }, n.createElement("div", {
                            className: h.wrapOverflow,
                            onMouseOver: m,
                            onMouseOut: v
                        }, n.createElement("div", {
                            className: i(h.wrap, w ? h.wrapWithArrowsOuting : "")
                        }, n.createElement("div", {
                            className: i(h.scrollWrap, y, {
                                [h.noScrollBar]: !l
                            }),
                            onScroll: this._handleScroll,
                            ref: this._scroll
                        }, n.createElement(o, {
                            onMeasure: this._handleResizeContent,
                            whitelist: ["width"],
                            shouldMeasure: d,
                            ref: this._contentMeasureRef
                        }, s)), u && n.createElement(r, {
                            isVisible: S,
                            className: g
                        }), u && n.createElement(a, {
                            isVisible: b,
                            className: g
                        }), c && n.createElement(e, {
                            onClick: this._handleScrollLeft,
                            isVisible: S
                        }), c && n.createElement(t, {
                            onClick: this._handleScrollRight,
                            isVisible: b
                        }))))
                    }
                    _isOverflowed() {
                        const {
                            widthContent: e,
                            widthWrap: t
                        } = this.state;
                        return e > t
                    }
                }).defaultProps = p, d
            }(v, y, f, m)
        },
        86219: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 10" width="20" height="10"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 1l8 8 8-8"/></svg>'
        },
        71485: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M4.56 14a10.05 10.05 0 00.52.91c.41.69 1.04 1.6 1.85 2.5C8.58 19.25 10.95 21 14 21c3.05 0 5.42-1.76 7.07-3.58A17.18 17.18 0 0023.44 14a9.47 9.47 0 00-.52-.91c-.41-.69-1.04-1.6-1.85-2.5C19.42 8.75 17.05 7 14 7c-3.05 0-5.42 1.76-7.07 3.58A17.18 17.18 0 004.56 14zM24 14l.45-.21-.01-.03a7.03 7.03 0 00-.16-.32c-.11-.2-.28-.51-.5-.87-.44-.72-1.1-1.69-1.97-2.65C20.08 7.99 17.45 6 14 6c-3.45 0-6.08 2-7.8 3.92a18.18 18.18 0 00-2.64 3.84v.02h-.01L4 14l-.45-.21-.1.21.1.21L4 14l-.45.21.01.03a5.85 5.85 0 00.16.32c.11.2.28.51.5.87.44.72 1.1 1.69 1.97 2.65C7.92 20.01 10.55 22 14 22c3.45 0 6.08-2 7.8-3.92a18.18 18.18 0 002.64-3.84v-.02h.01L24 14zm0 0l.45.21.1-.21-.1-.21L24 14zm-10-3a3 3 0 100 6 3 3 0 000-6zm-4 3a4 4 0 118 0 4 4 0 01-8 0z"/></svg>'
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [1196], {
        37593: e => {
            e.exports = {
                wrapper: "wrapper-5Xd5conM",
                input: "input-5Xd5conM",
                box: "box-5Xd5conM",
                icon: "icon-5Xd5conM",
                noOutline: "noOutline-5Xd5conM",
                "intent-danger": "intent-danger-5Xd5conM",
                check: "check-5Xd5conM",
                dot: "dot-5Xd5conM"
            }
        },
        96670: e => {
            e.exports = {
                checkbox: "checkbox-GxG6nBa7",
                reverse: "reverse-GxG6nBa7",
                label: "label-GxG6nBa7",
                baseline: "baseline-GxG6nBa7"
            }
        },
        62092: e => {
            e.exports = {
                loader: "loader-MuZZSHRY",
                static: "static-MuZZSHRY",
                item: "item-MuZZSHRY",
                "tv-button-loader": "tv-button-loader-MuZZSHRY",
                medium: "medium-MuZZSHRY",
                small: "small-MuZZSHRY",
                black: "black-MuZZSHRY",
                white: "white-MuZZSHRY",
                gray: "gray-MuZZSHRY",
                primary: "primary-MuZZSHRY",
                "loader-initial": "loader-initial-MuZZSHRY",
                "loader-appear": "loader-appear-MuZZSHRY"
            }
        },
        46673: () => {},
        4387: () => {},
        59174: e => {
            e.exports = {
                spinnerWrap: "spinnerWrap-OjdCXkZp"
            }
        },
        2153: e => {
            e.exports = {
                button: "button-4ZvcIHgE",
                withIcon: "withIcon-4ZvcIHgE",
                "a11y-text": "a11y-text-4ZvcIHgE",
                buttonIcon: "buttonIcon-4ZvcIHgE"
            }
        },
        72142: e => {
            e.exports = {
                footer: "footer-C0oTZgbU"
            }
        },
        66415: e => {
            e.exports = {
                footer: "footer-qc8HY6v4",
                shortcuts: "shortcuts-qc8HY6v4",
                buttonGroup: "buttonGroup-qc8HY6v4",
                button: "button-qc8HY6v4",
                withIcon: "withIcon-qc8HY6v4",
                icon: "icon-qc8HY6v4"
            }
        },
        89368: e => {
            e.exports = {
                container: "container-DWvc2EkN",
                leftSlot: "leftSlot-DWvc2EkN",
                rightSlot: "rightSlot-DWvc2EkN",
                rightSlotSeparator: "rightSlotSeparator-DWvc2EkN"
            }
        },
        25362: e => {
            e.exports = {
                button: "button-Tku5kbPR",
                hover: "hover-Tku5kbPR",
                isOpened: "isOpened-Tku5kbPR",
                inner: "inner-Tku5kbPR"
            }
        },
        92707: e => {
            e.exports = {
                node: "node-gXMIBnvN"
            }
        },
        82518: e => {
            e.exports = {
                removeButton: "removeButton-Zl3ogIKX"
            }
        },
        31216: e => {
            e.exports = {
                wrap: "wrap-8XnNs8MY",
                scrollable: "scrollable-8XnNs8MY",
                content: "content-8XnNs8MY",
                empty: "empty-8XnNs8MY",
                centered: "centered-8XnNs8MY",
                separatorDragPreview: "separatorDragPreview-8XnNs8MY"
            }
        },
        27079: () => {},
        94600: () => {},
        80795: e => {
            e.exports = {
                icon: "icon-N9sjpnmg",
                long: "long-N9sjpnmg"
            }
        },
        83240: e => {
            e.exports = {
                wrapper: "wrapper-1ms4EWzs",
                description: "description-1ms4EWzs",
                dot: "dot-1ms4EWzs",
                marketOpen: "marketOpen-1ms4EWzs",
                marketPre: "marketPre-1ms4EWzs",
                marketPost: "marketPost-1ms4EWzs",
                marketClose: "marketClose-1ms4EWzs",
                marketHoliday: "marketHoliday-1ms4EWzs"
            }
        },
        42205: e => {
            e.exports = {
                symbol: "symbol-ghhqKDrt",
                small: "small-ghhqKDrt",
                firstRow: "firstRow-ghhqKDrt",
                selected: "selected-ghhqKDrt",
                touch: "touch-ghhqKDrt",
                removeButton: "removeButton-ghhqKDrt",
                active: "active-ghhqKDrt",
                flag: "flag-ghhqKDrt",
                indicators: "indicators-ghhqKDrt",
                highlighted: "highlighted-ghhqKDrt",
                invalid: "invalid-ghhqKDrt",
                cell: "cell-ghhqKDrt",
                inner: "inner-ghhqKDrt",
                logo: "logo-ghhqKDrt",
                symbolName: "symbolName-ghhqKDrt",
                sfWarningIcon: "sfWarningIcon-ghhqKDrt",
                notes: "notes-ghhqKDrt",
                positions: "positions-ghhqKDrt",
                symbolNameText: "symbolNameText-ghhqKDrt",
                last: "last-ghhqKDrt",
                change: "change-ghhqKDrt",
                changeInPercents: "changeInPercents-ghhqKDrt",
                volume: "volume-ghhqKDrt",
                prePostMarket: "prePostMarket-ghhqKDrt",
                prePostMarketNoPrice: "prePostMarketNoPrice-ghhqKDrt",
                hidden: "hidden-ghhqKDrt",
                plus: "plus-ghhqKDrt",
                minus: "minus-ghhqKDrt",
                firstItem: "firstItem-ghhqKDrt",
                lastItem: "lastItem-ghhqKDrt",
                flexCell: "flexCell-ghhqKDrt",
                highlightUp: "highlightUp-ghhqKDrt",
                highlightDown: "highlightDown-ghhqKDrt",
                overlayEnd: "overlayEnd-ghhqKDrt"
            }
        },
        91871: e => {
            e.exports = {
                wrap: "wrap-jfj9GqNB",
                columnsMenu: "columnsMenu-jfj9GqNB",
                checkbox: "checkbox-jfj9GqNB",
                hovered: "hovered-jfj9GqNB",
                mobile: "mobile-jfj9GqNB"
            }
        },
        68650: e => {
            e.exports = {
                columnHeader: "columnHeader-ZTXPy1eT",
                small: "small-ZTXPy1eT",
                label: "label-ZTXPy1eT",
                sortable: "sortable-ZTXPy1eT",
                flagSortable: "flagSortable-ZTXPy1eT",
                flagWrap: "flagWrap-ZTXPy1eT"
            }
        },
        87529: e => {
            e.exports = {
                placeholder: "placeholder-vMu4au4N",
                wrap: "wrap-vMu4au4N",
                handle: "handle-vMu4au4N",
                separator: "separator-vMu4au4N"
            }
        },
        11817: e => {
            e.exports = {
                wrap: "wrap-ZbPP2GCn",
                menu: "menu-ZbPP2GCn",
                tableHeader: "tableHeader-ZbPP2GCn",
                columnHeader: "columnHeader-ZbPP2GCn",
                readonly: "readonly-ZbPP2GCn",
                symbolName: "symbolName-ZbPP2GCn",
                last: "last-ZbPP2GCn",
                change: "change-ZbPP2GCn",
                changeInPercents: "changeInPercents-ZbPP2GCn",
                volume: "volume-ZbPP2GCn",
                prePostMarket: "prePostMarket-ZbPP2GCn",
                prePostMarketNoPrice: "prePostMarketNoPrice-ZbPP2GCn",
                label: "label-ZbPP2GCn",
                firstItem: "firstItem-ZbPP2GCn",
                lastItem: "lastItem-ZbPP2GCn"
            }
        },
        50032: e => {
            e.exports = {
                item: "item-yUC5pCgf"
            }
        },
        34763: e => {
            e.exports = {
                item: "item-5diyrsmC",
                withIcon: "withIcon-5diyrsmC"
            }
        },
        37911: e => {
            e.exports = {
                container: "container-UDSTkcXu",
                hidden: "hidden-UDSTkcXu",
                watchlistMenu: "watchlistMenu-UDSTkcXu",
                title: "title-UDSTkcXu",
                titleRow: "titleRow-UDSTkcXu",
                flag: "flag-UDSTkcXu",
                headerButton: "headerButton-UDSTkcXu",
                disabled: "disabled-UDSTkcXu",
                mobileMenu: "mobileMenu-UDSTkcXu",
                buttonWrap: "buttonWrap-UDSTkcXu",
                menuWrap: "menuWrap-UDSTkcXu",
                columnsTitle: "columnsTitle-UDSTkcXu",
                small: "small-UDSTkcXu",
                copyLink: "copyLink-UDSTkcXu",
                loaderWrapper: "loaderWrapper-UDSTkcXu",
                loader: "loader-UDSTkcXu",
                switcherMobileLabel: "switcherMobileLabel-UDSTkcXu",
                widgetbarWidgetHeaderLeftSlot: "widgetbarWidgetHeaderLeftSlot-UDSTkcXu",
                widgetbarWidgetHeaderRightSlot: "widgetbarWidgetHeaderRightSlot-UDSTkcXu"
            }
        },
        69283: e => {
            e.exports = {
                toolbox: "toolbox-gBHvPrza"
            }
        },
        20369: e => {
            e.exports = {
                toolbox: "toolbox-QAXyC5q6"
            }
        },
        96049: e => {
            e.exports = {
                item: "item-08JkF94b",
                active: "active-08JkF94b",
                toolboxCount: "toolboxCount-08JkF94b",
                count: "count-08JkF94b",
                removeButton: "removeButton-08JkF94b",
                countVisible: "countVisible-08JkF94b",
                title: "title-08JkF94b",
                flag: "flag-08JkF94b",
                small: "small-08JkF94b",
                touch: "touch-08JkF94b",
                toolboxItem: "toolboxItem-08JkF94b"
            }
        },
        524: e => {
            e.exports = {
                separator: "separator-GzmeVcFo",
                small: "small-GzmeVcFo",
                normal: "normal-GzmeVcFo",
                large: "large-GzmeVcFo"
            }
        },
        73432: e => {
            e.exports = {
                button: "button-SD4Dbbwd",
                disabled: "disabled-SD4Dbbwd",
                active: "active-SD4Dbbwd",
                hidden: "hidden-SD4Dbbwd"
            }
        },
        38031: e => {
            e.exports = {
                renameInput: "renameInput-eBdqxnie"
            }
        },
        8323: (e, t, n) => {
            "use strict";
            n.d(t, {
                CheckboxInput: () => c
            });
            var s = n(59496),
                o = n(97754),
                i = n(72571),
                r = n(57369),
                l = n(37593),
                a = n.n(l);

            function c(e) {
                const t = o(a().box, a()["intent-" + e.intent], {
                        [a().check]: !Boolean(e.indeterminate),
                        [a().dot]: Boolean(e.indeterminate),
                        [a().noOutline]: -1 === e.tabIndex
                    }),
                    n = o(a().wrapper, e.className);
                return s.createElement("span", {
                    className: n,
                    title: e.title
                }, s.createElement("input", {
                    id: e.id,
                    tabIndex: e.tabIndex,
                    className: a().input,
                    type: "checkbox",
                    name: e.name,
                    checked: e.checked,
                    disabled: e.disabled,
                    value: e.value,
                    autoFocus: e.autoFocus,
                    role: e.role,
                    onChange: function() {
                        e.onChange && e.onChange(e.value)
                    },
                    ref: e.reference
                }), s.createElement("span", {
                    className: t
                }, s.createElement(i.Icon, {
                    icon: r,
                    className: a().icon
                })))
            }
        },
        2946: (e, t, n) => {
            "use strict";
            n.d(t, {
                Checkbox: () => c
            });
            var s = n(59496),
                o = n(97754),
                i = n(32834),
                r = n(8323),
                l = n(96670),
                a = n.n(l);
            class c extends s.PureComponent {
                render() {
                    const {
                        inputClassName: e,
                        labelClassName: t,
                        ...n
                    } = this.props, i = o(this.props.className, a().checkbox, {
                        [a().reverse]: Boolean(this.props.labelPositionReverse),
                        [a().baseline]: Boolean(this.props.labelAlignBaseline)
                    }), l = o(a().label, t, {
                        [a().disabled]: this.props.disabled
                    });
                    let c = null;
                    return this.props.label && (c = s.createElement("span", {
                        className: l,
                        title: this.props.title
                    }, this.props.label)), s.createElement("label", {
                        className: i
                    }, s.createElement(r.CheckboxInput, { ...n,
                        className: e
                    }), c)
                }
            }
            c.defaultProps = {
                value: "on"
            };
            (0, i.makeSwitchGroupItem)(c)
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => o
            });
            var s = n(59496);
            const o = s.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...o
                } = e;
                return s.createElement("span", { ...o,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        34404: (e, t, n) => {
            "use strict";
            n.d(t, {
                Loader: () => c
            });
            var s, o = n(59496),
                i = n(97754),
                r = n(49423),
                l = n(62092),
                a = n.n(l);
            ! function(e) {
                e[e.Initial = 0] = "Initial", e[e.Appear = 1] = "Appear", e[e.Active = 2] = "Active"
            }(s || (s = {}));
            class c extends o.PureComponent {
                constructor(e) {
                    super(e), this._stateChangeTimeout = null, this.state = {
                        state: s.Initial
                    }
                }
                render() {
                    const {
                        className: e,
                        color: t = "black",
                        size: n = "medium",
                        staticPosition: s
                    } = this.props, r = i(a().item, a()[t], a()[n]);
                    return o.createElement("span", {
                        className: i(a().loader, s && a().static, this._getStateClass(), e)
                    }, o.createElement("span", {
                        className: r
                    }), o.createElement("span", {
                        className: r
                    }), o.createElement("span", {
                        className: r
                    }))
                }
                componentDidMount() {
                    this.setState({
                        state: s.Appear
                    }), this._stateChangeTimeout = setTimeout(() => {
                        this.setState({
                            state: s.Active
                        })
                    }, 2 * r.dur)
                }
                componentWillUnmount() {
                    this._stateChangeTimeout && (clearTimeout(this._stateChangeTimeout), this._stateChangeTimeout = null)
                }
                _getStateClass() {
                    switch (this.state.state) {
                        case s.Initial:
                            return a()["loader-initial"];
                        case s.Appear:
                            return a()["loader-appear"];
                        default:
                            return ""
                    }
                }
            }
        },
        32834: (e, t, n) => {
            "use strict";
            n.d(t, {
                SwitchGroup: () => i,
                makeSwitchGroupItem: () => r
            });
            var s = n(59496),
                o = n(19036);
            class i extends s.PureComponent {
                constructor() {
                    super(...arguments), this._subscriptions = new Set, this._getName = () => this.props.name, this._getValues = () => this.props.values, this._getOnChange = () => this.props.onChange, this._subscribe = e => {
                        this._subscriptions.add(e)
                    }, this._unsubscribe = e => {
                        this._subscriptions.delete(e)
                    }
                }
                getChildContext() {
                    return {
                        switchGroupContext: {
                            getName: this._getName,
                            getValues: this._getValues,
                            getOnChange: this._getOnChange,
                            subscribe: this._subscribe,
                            unsubscribe: this._unsubscribe
                        }
                    }
                }
                render() {
                    return this.props.children
                }
                componentDidUpdate(e) {
                    this._notify(this._getUpdates(this.props.values, e.values))
                }
                _notify(e) {
                    this._subscriptions.forEach(t => t(e))
                }
                _getUpdates(e, t) {
                    return [...t, ...e].filter(n => t.includes(n) ? !e.includes(n) : e.includes(n))
                }
            }

            function r(e) {
                var t;
                return (t = class extends s.PureComponent {
                    constructor() {
                        super(...arguments), this._onChange = e => {
                            this.context.switchGroupContext.getOnChange()(e)
                        }, this._onUpdate = e => {
                            e.includes(this.props.value) && this.forceUpdate()
                        }
                    }
                    componentDidMount() {
                        this.context.switchGroupContext.subscribe(this._onUpdate)
                    }
                    render() {
                        return s.createElement(e, { ...this.props,
                            name: this._getName(),
                            onChange: this._onChange,
                            checked: this._isChecked()
                        })
                    }
                    componentWillUnmount() {
                        this.context.switchGroupContext.unsubscribe(this._onUpdate)
                    }
                    _getName() {
                        return this.context.switchGroupContext.getName()
                    }
                    _isChecked() {
                        return this.context.switchGroupContext.getValues().includes(this.props.value)
                    }
                }).contextTypes = {
                    switchGroupContext: o.any.isRequired
                }, t
            }
            i.childContextTypes = {
                switchGroupContext: o.any.isRequired
            }
        },
        9970: (e, t, n) => {
            "use strict";
            n.d(t, {
                AbstractIndicator: () => l
            });
            var s = n(51951),
                o = n(16345),
                i = n(21162);
            n(44471);
            const r = (0, s.getLogger)("GUI.Blocks.AbstractIndicator");
            class l {
                constructor(e) {
                    this._classSuffix = "", this._quoteSessionPrefix = "abstract-indicator", this._shortMode = !1, this._showTooltip = !0, this._subscribed = !1, this._tooltipType = "custom", this._lastTooltipText = "", this._quoteSession = e.quoteSession
                }
                getValue() {
                    return this._value
                }
                getTooltipText() {
                    return this._labelMap[this._value] || ""
                }
                getLabel() {
                    return this._labelMap[this._value] || ""
                }
                getElement() {
                    return this._el
                }
                update(e, t) {
                    this._updateValue(e, t), this._render()
                }
                setTooltipEnabled(e = !1) {
                    this._showTooltip !== e && (this._showTooltip = e, this._renderTooltip())
                }
                enableShortMode() {
                    !0 !== this._shortMode && (this._shortMode = !0, this._render())
                }
                disableShortMode() {
                    !1 !== this._shortMode && (this._shortMode = !1, this._render())
                }
                isShortModeEnabled() {
                    return this._shortMode
                }
                start() {
                    !this._subscribed && this._symbolName && (this._quoteSession || (this._quoteSession = (0, i.getQuoteSessionInstance)("simple")), this._quoteSession.subscribe(this._getQuoteSessionId(), this._symbolName, this.update.bind(this)), this._subscribed = !0)
                }
                stop() {
                    this._subscribed && this._quoteSession && this._symbolName && (this._quoteSession.unsubscribe(this._getQuoteSessionId(), this._symbolName), this._subscribed = !1)
                }
                _init(e) {
                    this._el = e.el ? e.el : document.createElement("span"), this._el.innerHTML = "", this._classMap = e.classMap, this._labelMap = e.labelMap, this._showTooltip = e.showTooltip, this._classSuffix = e.classSuffix, this._symbolName = e.symbol, e.tooltipType && (this._tooltipType = e.tooltipType), this._quoteSessionGUID = (0, o.guid)(), !0 === e.short && this.enableShortMode(), e.data && this._updateValue(e.data)
                }
                _clearClasses() {
                    Object.values(this._classMap).map(e => {
                        this._el.classList.remove("" + e), this._el.classList.remove(`${e}${this._classSuffix}`)
                    })
                }
                _render() {
                    this._renderClasses(), this._renderTooltip(), this._renderLabel()
                }
                _renderLabel() {
                    this._el.textContent = this.getLabel()
                }
                _updateValue(e, t) {
                    const n = this._getValueFromData(e);
                    (t || n !== this._value) && (this._value = n)
                }
                _renderClasses() {
                    const e = this._el.classList;
                    e.add(this._componentClass, this._componentClass + this._classSuffix);
                    const t = this._classMap[this._value];
                    for (const n in this._classMap) {
                        const s = this._classMap[n];
                        s && (s === t ? e.add(s, s + this._classSuffix) : e.remove(s, s + this._classSuffix))
                    }!t && this._value && r.logWarn("no className for status " + this._value)
                }
                _renderTooltip() {
                    const e = this._showTooltip ? this.getTooltipText() : "";
                    e !== this._lastTooltipText && (this._lastTooltipText = e, this._el.setAttribute("title", e), "custom" === this._tooltipType && this._el.classList.toggle("apply-common-tooltip", this._showTooltip))
                }
                _getQuoteSessionId() {
                    return `${this._quoteSessionPrefix}.${this._quoteSessionGUID}`
                }
            }
        },
        78100: (e, t, n) => {
            "use strict";
            n.d(t, {
                DataModeIndicator: () => c
            });
            var s = n(25177),
                o = (n(35897), n(46673), n(9970));
            const i = {
                    connecting: (0, s.t)("Connecting"),
                    delayed: (0, s.t)("Delayed"),
                    delayed_streaming: (0, s.t)("Delayed"),
                    endofday: (0, s.t)("End of Day"),
                    forbidden: (0, s.t)("Instrument is not allowed"),
                    realtime: (0, s.t)("Real-time"),
                    snapshot: (0, s.t)("Snapshot"),
                    loading: "",
                    replay: (0, s.t)("Replay Mode")
                },
                r = {
                    connecting: (0, s.t)("C", {
                        context: "data_mode_connecting_letter"
                    }),
                    delayed: (0, s.t)("D", {
                        context: "data_mode_delayed_letter"
                    }),
                    delayed_streaming: (0, s.t)("D", {
                        context: "data_mode_delayed_streaming_letter"
                    }),
                    endofday: (0, s.t)("E", {
                        context: "data_mode_end_of_day_letter"
                    }),
                    forbidden: (0, s.t)("F", {
                        context: "data_mode_forbidden_letter"
                    }),
                    realtime: (0, s.t)("R", {
                        context: "data_mode_realtime_letter"
                    }),
                    snapshot: (0, s.t)("S", {
                        context: "data_mode_snapshot_letter"
                    }),
                    loading: "",
                    replay: (0, s.t)("R", {
                        context: "data_mode_replay_letter"
                    })
                },
                l = {
                    streaming: "realtime"
                },
                a = {
                    classMap: {
                        connecting: "tv-data-mode--connecting",
                        delayed: "tv-data-mode--delayed",
                        delayed_streaming: "tv-data-mode--delayed",
                        endofday: "tv-data-mode--endofday",
                        forbidden: "tv-data-mode--forbidden",
                        realtime: "tv-data-mode--realtime",
                        snapshot: "tv-data-mode--snapshot",
                        loading: "tv-data-mode--loading",
                        replay: "tv-data-mode--replay"
                    },
                    classSuffix: "",
                    data: {
                        values: {
                            update_mode: "connecting"
                        }
                    },
                    labelMap: i,
                    modeInterval: 600,
                    short: !1,
                    shortLabelMap: r,
                    showTooltip: !0,
                    tooltipType: "custom"
                };
            class c extends o.AbstractIndicator {
                constructor(e) {
                    super(e), this._quoteSessionPrefix = "data-mode-indicator", this._componentClass = "tv-data-mode", this._init(e)
                }
                getLabel() {
                    return !0 === this._shortMode ? this._shortLabelMap[this._value] || "" : super.getLabel()
                }
                setMode(e, t) {
                    this.update({
                        values: {
                            update_mode: e,
                            update_mode_seconds: t
                        }
                    })
                }
                hide() {
                    this._el.classList.add("i-hidden")
                }
                show() {
                    this._el.classList.remove("i-hidden")
                }
                getTooltipText() {
                    let e = "";
                    const t = this.getValue();
                    if ("" === t) return e;
                    switch (t) {
                        case "delayed":
                            e = (0, s.t)("Quotes are delayed by {number} min and updated every 30 seconds");
                            break;
                        case "delayed_streaming":
                            e = (0, s.t)("Quotes are delayed by {number} min");
                            break;
                        default:
                            e = this._labelMap[t] || e
                    }
                    return ["delayed", "delayed_streaming"].includes(t) && (e = e.format({
                        number: String(Math.round(this._modeInterval / 60))
                    })), e
                }
                _init(e = {}) {
                    const t = Object.assign({}, a, e);
                    this._modeInterval = t.modeInterval || 600, this._shortLabelMap = t.shortLabelMap || r, super._init(t), this._render()
                }
                _getValueFromData(e) {
                    let t;
                    return t = void 0 !== e.values && void 0 !== e.values.update_mode ? e.values.update_mode : this.getValue(), l[t] || t
                }
                _updateValue(e, t) {
                    void 0 !== e.values && void 0 !== e.values.update_mode_seconds && (this._modeInterval = e.values.update_mode_seconds), super._updateValue(e, t)
                }
            }
        },
        21638: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetMenuSpinner: () => a
            });
            var s = n(59496),
                o = n(97754),
                i = n.n(o),
                r = n(34404),
                l = n(59174);

            function a(e) {
                const {
                    className: t
                } = e;
                return s.createElement("div", {
                    className: i()(l.spinnerWrap, t)
                }, s.createElement(r.Loader, null))
            }
        },
        7053: (e, t, n) => {
            "use strict";
            n.d(t, {
                BrokerService: () => o
            });
            var s = n(88537);
            class o {
                constructor(e) {
                    this._activeBroker = null, this._trading = e, this._trading.onConnectionStatusChange.subscribe(this, this._onStatusChange), this._onStatusChange(this._trading.connectStatus())
                }
                activeBroker() {
                    return this._activeBroker
                }
                trading() {
                    return this._trading
                }
                _stopService() {
                    this.stopService(), (0, s.ensureNotNull)(this._activeBroker).currentAccountUpdate.unsubscribeAll(this)
                }
                _startService() {
                    this.startService(), (0, s.ensureNotNull)(this._activeBroker).currentAccountUpdate.subscribe(this, this._onCurrentAccountUpdate)
                }
                _onStatusChange(e) {
                    const t = this._trading.activeBroker();
                    this._activeBroker === t && 1 === e || (null !== this._activeBroker && (this._stopService(), this._activeBroker = null), null !== t && 1 === e && (this._activeBroker = t, this._startService(), this._lastAccountId = t.currentAccount()))
                }
                _onCurrentAccountUpdate() {
                    const e = (0, s.ensureNotNull)(this._activeBroker);
                    this._lastAccountId !== e.currentAccount() && (this.stopService(), this.startService(), this._lastAccountId = e.currentAccount())
                }
            }
        },
        96818: (e, t, n) => {
            "use strict";
            n.d(t, {
                Draggable: () => l,
                PointerBackend: () => a
            });
            var s = n(88537),
                o = n(2369),
                i = n(1227),
                r = n(72535);
            class l {
                constructor(e) {
                    var t, n;
                    this._helper = null, this._handleDragStart = e => {
                        var t;
                        if (null !== this._helper) return;
                        const n = this._source;
                        n.classList.add("ui-draggable-dragging");
                        const [s, i] = [(0, o.outerWidth)(n), (0, o.outerHeight)(n)];
                        this._helper = {
                            startTop: parseFloat(n.style.top) || 0,
                            startLeft: parseFloat(n.style.left) || 0,
                            nextTop: null,
                            nextLeft: null,
                            raf: null,
                            size: [s, i],
                            containment: this._containment instanceof HTMLElement ? [parseInt(getComputedStyle(this._containment).borderLeftWidth) + parseInt(getComputedStyle(this._containment).paddingLeft), parseInt(getComputedStyle(this._containment).borderTopWidth) + parseInt(getComputedStyle(this._containment).paddingTop), this._containment.offsetWidth - parseInt(getComputedStyle(this._containment).borderRightWidth) - parseInt(getComputedStyle(this._containment).paddingRight) - parseInt(getComputedStyle(n).marginLeft) - parseInt(getComputedStyle(n).marginRight) - s, this._containment.offsetHeight - parseInt(getComputedStyle(this._containment).borderBottomWidth) - parseInt(getComputedStyle(this._containment).paddingBottom) - parseInt(getComputedStyle(n).marginTop) - parseInt(getComputedStyle(n).marginBottom) - i] : "window" === this._containment ? [window.scrollX, window.scrollY, window.scrollX + document.documentElement.offsetWidth - s, window.scrollY + document.documentElement.offsetHeight - i] : null
                        }, null === (t = this._start) || void 0 === t || t.call(this)
                    }, this._handleDragMove = e => {
                        var t;
                        if (null === this._helper) return;
                        const {
                            current: n,
                            initial: s
                        } = e.detail, o = this._source, i = this._helper.nextTop, r = this._helper.nextLeft, l = "y" === this._axis || !1 === this._axis || 0 !== n.movementY;
                        if (l) {
                            const e = this._helper.startTop;
                            isFinite(e) && (this._helper.nextTop = n.clientY - s.clientY + e)
                        }
                        const a = "x" === this._axis || !1 === this._axis || 0 !== n.movementY;
                        if (a) {
                            const e = this._helper.startLeft;
                            isFinite(e) && (this._helper.nextLeft = n.clientX - s.clientX + e)
                        }
                        if (null !== this._helper.containment) {
                            const [e, t, n, s] = this._helper.containment;
                            l && this._helper.nextTop && (this._helper.nextTop = Math.min(this._helper.nextTop, s), this._helper.nextTop = Math.max(this._helper.nextTop, t)), a && this._helper.nextLeft && (this._helper.nextLeft = Math.min(this._helper.nextLeft, n), this._helper.nextLeft = Math.max(this._helper.nextLeft, e))
                        }
                        null !== this._helper.raf || i === this._helper.nextTop && r === this._helper.nextLeft || (this._helper.raf = requestAnimationFrame(() => {
                            null !== this._helper && (null !== this._helper.nextTop && (o.style.top = this._helper.nextTop + "px", this._helper.nextTop = null), null !== this._helper.nextLeft && (o.style.left = this._helper.nextLeft + "px", this._helper.nextLeft = null), this._helper.raf = null)
                        })), null === (t = this._drag) || void 0 === t || t.call(this)
                    }, this._handleDragStop = e => {
                        var t;
                        if (null === this._helper) return;
                        this._source.classList.remove("ui-draggable-dragging"), this._helper = null, null === (t = this._stop) || void 0 === t || t.call(this)
                    };
                    const s = this._source = e.source;
                    s.classList.add("ui-draggable");
                    const i = this._handle = null !== (t = e.handle ? s.querySelector(e.handle) : null) && void 0 !== t ? t : s;
                    i.classList.add("ui-draggable-handle"), this._start = e.start, this._stop = e.stop, this._drag = e.drag, this._backend = new a({
                        handle: i,
                        onDragStart: this._handleDragStart,
                        onDragMove: this._handleDragMove,
                        onDragStop: this._handleDragStop
                    }), this._axis = null !== (n = e.axis) && void 0 !== n && n, this._containment = e.containment
                }
                destroy() {
                    const e = this._source;
                    e.classList.remove("ui-draggable"), e.classList.remove("ui-draggable-dragging");
                    this._handle.classList.remove("ui-draggable-handle"), this._backend.destroy(), null !== this._helper && (this._helper.raf && cancelAnimationFrame(this._helper.raf), this._helper = null)
                }
            }
            class a {
                constructor(e) {
                    this._initial = null, this._handlePointerDown = e => {
                        if (null !== this._initial) return;
                        if (!(e.target instanceof Element && this._handle.contains(e.target))) return;
                        if (this._initial = e, !this._dispatchEvent(this._createEvent("pointer-drag-start", e))) return void(this._initial = null);
                        e.preventDefault();
                        const t = this._getEventTarget();
                        t.addEventListener("pointermove", this._handlePointerMove), t.addEventListener("pointerup", this._handlePointerUp), t.addEventListener("pointercancel", this._handlePointerUp), t.addEventListener("lostpointercapture", this._handlePointerUp), t.setPointerCapture(e.pointerId)
                    }, this._handlePointerMove = e => {
                        null !== this._initial && this._initial.pointerId === e.pointerId && (e.preventDefault(), this._dispatchEvent(this._createEvent("pointer-drag-move", e)))
                    }, this._handlePointerUp = e => {
                        if (null === this._initial || this._initial.pointerId !== e.pointerId) return;
                        e.preventDefault();
                        const t = this._getEventTarget();
                        t.removeEventListener("pointermove", this._handlePointerMove), t.removeEventListener("pointerup", this._handlePointerUp), t.removeEventListener("pointercancel", this._handlePointerUp), t.removeEventListener("lostpointercapture", this._handlePointerUp), t.releasePointerCapture(this._initial.pointerId), this._dispatchEvent(this._createEvent("pointer-drag-stop", e)), this._initial = null
                    };
                    const t = this._handle = e.handle;
                    this._onDragStart = e.onDragStart, this._onDragMove = e.onDragMove, this._onDragStop = e.onDragStop, t.style.touchAction = "none";
                    this._getEventTarget().addEventListener("pointerdown", this._handlePointerDown)
                }
                destroy() {
                    this._handle.style.touchAction = "";
                    const e = this._getEventTarget();
                    e.removeEventListener("pointerdown", this._handlePointerDown), e.removeEventListener("pointermove", this._handlePointerMove), e.removeEventListener("pointerup", this._handlePointerUp), e.removeEventListener("pointercancel", this._handlePointerUp), e.removeEventListener("lostpointercapture", this._handlePointerUp), null !== this._initial && (e.releasePointerCapture(this._initial.pointerId), this._initial = null)
                }
                _getEventTarget() {
                    return i.CheckMobile.iOS() || (0, i.isMac)() && r.touch ? window.document.documentElement : this._handle
                }
                _dispatchEvent(e) {
                    switch (e.type) {
                        case "pointer-drag-start":
                            this._onDragStart(e);
                            break;
                        case "pointer-drag-move":
                            this._onDragMove(e);
                            break;
                        case "pointer-drag-stop":
                            this._onDragStop(e)
                    }
                    return !e.defaultPrevented
                }
                _createEvent(e, t) {
                    return (0, s.assert)(null !== this._initial), new CustomEvent(e, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: {
                            backend: this,
                            initial: this._initial,
                            current: t
                        }
                    })
                }
            }
        },
        70086: (e, t, n) => {
            "use strict";
            n.d(t, {
                FragmentMap: () => o
            });
            var s = n(59496);

            function o(e) {
                if (e.map) {
                    return s.Children.toArray(e.children).map(e.map)
                }
                return e.children
            }
        },
        2369: (e, t, n) => {
            "use strict";
            n.d(t, {
                contentHeight: () => o,
                html: () => l,
                outerHeight: () => i,
                outerWidth: () => r,
                position: () => c
            });
            var s = n(88537);

            function o(e) {
                const {
                    paddingTop: t,
                    paddingBottom: n
                } = window.getComputedStyle(e);
                return [t, n].reduce((e, t) => e - Number((t || "").replace("px", "")), e.clientHeight)
            }

            function i(e, t = !1) {
                const n = getComputedStyle(e),
                    s = [n.height];
                return "border-box" !== n.boxSizing && s.push(n.paddingTop, n.paddingBottom, n.borderTopWidth, n.borderBottomWidth), t && s.push(n.marginTop, n.marginBottom), s.reduce((e, t) => e + (parseFloat(t) || 0), 0)
            }

            function r(e, t = !1) {
                const n = getComputedStyle(e),
                    s = [n.width];
                return "border-box" !== n.boxSizing && s.push(n.paddingLeft, n.paddingRight, n.borderLeftWidth, n.borderRightWidth), t && s.push(n.marginLeft, n.marginRight), s.reduce((e, t) => e + (parseFloat(t) || 0), 0)
            }

            function l(e, t) {
                return void 0 === t || (null === t && (e.innerHTML = ""), "string" != typeof t && "number" != typeof t || (e.innerHTML = String(t))), e
            }

            function a(e) {
                if (!e.getClientRects().length) return {
                    top: 0,
                    left: 0
                };
                const t = e.getBoundingClientRect(),
                    n = (0, s.ensureNotNull)(e.ownerDocument.defaultView);
                return {
                    top: t.top + n.pageYOffset,
                    left: t.left + n.pageXOffset
                }
            }

            function c(e) {
                const t = getComputedStyle(e);
                let n, s = {
                    top: 0,
                    left: 0
                };
                if ("fixed" === t.position) n = e.getBoundingClientRect();
                else {
                    n = a(e);
                    const t = e.ownerDocument;
                    let o = e.offsetParent || t.documentElement;
                    for (; o && (o === t.body || o === t.documentElement) && "static" === getComputedStyle(o).position;) o = o.parentElement;
                    o && o !== e && 1 === o.nodeType && (s = a(o), s.top += parseFloat(getComputedStyle(o).borderTopWidth), s.left += parseFloat(getComputedStyle(o).borderLeftWidth))
                }
                return {
                    top: n.top - s.top - parseFloat(t.marginTop),
                    left: n.left - s.left - parseFloat(t.marginLeft)
                }
            }
        },
        52275: (e, t, n) => {
            "use strict";
            n.d(t, {
                saveTextFile: () => o,
                escapeCSVValue: () => a
            });
            var s = n(1227);

            function o(e, t, n = "text/plain") {
                const o = new Blob([t], {
                    type: n
                });
                if (s.CheckMobile.iOS()) {
                    const t = new FileReader;
                    return t.onload = () => {
                        t.result && i(e, t.result.toString())
                    }, void t.readAsDataURL(o)
                }
                const r = window.URL.createObjectURL(o);
                navigator.msSaveOrOpenBlob ? navigator.msSaveOrOpenBlob(o, e) : window.navigator.msSaveBlob ? window.navigator.msSaveBlob(o, e) : (i(e, r), window.URL.revokeObjectURL(r))
            }

            function i(e, t) {
                const n = document.createElement("a");
                n.style.display = "none", document.body.appendChild(n), n.href = t, n.download = e, n.click(), document.body.removeChild(n)
            }
            const r = /[",\r\n]/,
                l = /"/g;

            function a(e) {
                return r.test(e) ? `"${e.replace(l,'""')}"` : e
            }
        },
        90410: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogHeaderContext: () => s
            });
            const s = n(59496).createContext({
                setHideClose: () => {}
            })
        },
        66171: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchDialogFooter: () => l
            });
            var s = n(59496),
                o = n(97754),
                i = n.n(o),
                r = n(72142);

            function l(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return s.createElement("div", {
                    className: i()(r.footer, t)
                }, n)
            }
        },
        12015: (e, t, n) => {
            "use strict";
            n.d(t, {
                isPlatformMobile: () => o
            });
            var s = n(69111);
            n(82527), n(1227);

            function o() {
                return !(0, s.isOnMobileAppPage)("any") && (window.matchMedia("(min-width: 602px) and (min-height: 445px)").matches, !1)
            }
        },
        84327: (e, t, n) => {
            "use strict";

            function s(e) {
                return "" === e.value()
            }

            function o(e, t) {
                return e.filter(e => e.includes(t))
            }

            function i(e) {
                const t = new Map;
                return e.forEach(e => {
                    t.has(e.group()) ? t.get(e.group()).push(e) : t.set(e.group(), [e])
                }), t
            }

            function r(e, t) {
                return t.map(t => new e(t))
            }
            n.d(t, {
                isAllSearchSourcesSelected: () => s,
                filterSearchSources: () => o,
                splitSearchSourcesByGroup: () => i,
                createSearchSources: () => r
            })
        },
        44080: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchItemsDialogContext: () => s
            });
            const s = n(59496).createContext(null)
        },
        21167: (e, t, n) => {
            "use strict";
            n.d(t, {
                exchangeSelectDisabled: () => m,
                getAllSymbolTypesValue: () => h,
                getAvailableExchanges: () => c,
                getAvailableSearchSources: () => a,
                getAvailableSymbolTypes: () => d,
                getDefaultSearchSource: () => l,
                getSymbolFullName: () => r,
                isOpenFirstContractEnabled: () => p
            });
            var s = n(25177),
                o = n(84327);
            class i {
                constructor(e) {
                    this._exchange = e
                }
                value() {
                    return this._exchange.value
                }
                name() {
                    return (0, o.isAllSearchSourcesSelected)(this) ? (0, s.t)("All sources") : this._exchange.name
                }
                description() {
                    return this._exchange.desc
                }
                country() {
                    return this._exchange.country
                }
                providerId() {
                    return this._exchange.providerId
                }
                group() {
                    return this._exchange.group
                }
                includes(e) {
                    return function(e, t) {
                        const n = t.toLowerCase(),
                            {
                                name: s,
                                desc: o,
                                searchTerms: i
                            } = e;
                        return s.toLowerCase().includes(n) || o.toLowerCase().includes(n) || void 0 !== i && i.some(e => e.toLowerCase().includes(n))
                    }(this._exchange, e)
                }
                getRequestExchangeValue() {
                    return this._exchange.value
                }
                getRequestCountryValue() {}
            }

            function r(e) {
                if (e.fullName) return e.fullName;
                let t;
                return t = e.prefix || e.exchange ? (e.prefix || e.exchange) + ":" + e.name : e.name, t.replace(/<\/?[^>]+(>|$)/g, "")
            }

            function l() {
                const e = a();
                return e.find(o.isAllSearchSourcesSelected) || e[0] || null
            }

            function a() {
                return (0, o.createSearchSources)(i, u())
            }

            function c() {
                return u()
            }

            function u() {
                return window.ChartApiInstance.supportedExchangesList().map(e => ({ ...e,
                    country: "",
                    providerId: "",
                    flag: ""
                }))
            }

            function d() {
                return window.ChartApiInstance.supportedSymbolsTypes()
            }

            function h() {
                return ""
            }

            function m() {
                return !1
            }
            const p = !1
        },
        32402: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                watchListSaga: () => R
            });
            var s = n(36349),
                o = n(54773),
                i = n(33080),
                r = n(88537),
                l = n(7053),
                a = n(97496),
                c = n.n(a);
            class u extends l.BrokerService {
                constructor(e) {
                    super(e), this.positionsUpdate = new(c()), this._symbols = [], this._symbolPositions = {}
                }
                positions(e) {
                    return -1 !== this._symbols.indexOf(e) ? this._symbolPositions[e] : []
                }
                setSymbols(e) {
                    const t = Object.keys(this._symbolPositions);
                    this._symbols.forEach(n => {
                        -1 === e.indexOf(n) && -1 !== t.indexOf(n) && delete this._symbolPositions[n]
                    });
                    const n = [];
                    e.forEach(e => {
                        -1 === this._symbols.indexOf(e) && (n.push(e), this._symbolPositions[e] = [])
                    }), this._symbols = e, n.length && this._requestPositions(n)
                }
                stopService() {
                    this._clearPositions();
                    (0, r.ensure)(this.activeBroker()).positionUpdate.unsubscribe(this, this._positionUpdate)
                }
                startService() {
                    this._symbols && this._requestPositions(this._symbols);
                    (0, r.ensure)(this.activeBroker()).positionUpdate.subscribe(this, this._positionUpdate)
                }
                _clearPositions() {
                    Object.keys(this._symbolPositions).forEach(e => {
                        this._symbolPositions[e].length && (this._symbolPositions[e] = [], this.positionsUpdate.fire(e, []))
                    })
                }
                _positionUpdate(e) {
                    const t = e.symbol;
                    if (-1 === this._symbols.indexOf(t)) return;
                    const n = this._symbolPositions[t],
                        s = n.reduce((t, n, s) => n.id === e.id ? s : t, -1),
                        o = 0 === e.qty; - 1 !== s && o ? n.splice(s, 1) : -1 !== s || o ? n[s] = e : n.push(e), this.positionsUpdate.fire(t, n)
                }
                _requestPositions(e) {
                    const t = this.activeBroker();
                    t && e.length && t.positions().then(t => {
                        t.forEach(t => {
                            -1 !== e.indexOf(t.symbol) && this._positionUpdate(t)
                        })
                    })
                }
            }
            var d = n(19769),
                h = n(1373),
                m = n(6474);
            const p = (0, n(51951).getLogger)("Platform.Model.Watchlist");

            function* g(e) {
                const t = (n = e, (0, o.eventChannel)(e => {
                    const t = {};
                    return n.positionsUpdate.subscribe(t, (t, n) => {
                        const [s] = n;
                        e((0, d.updatePosition)(t, s ? (0, m.toPositionRecord)(s) : void 0))
                    }), () => n.positionsUpdate.unsubscribeAll(t)
                }));
                var n;
                try {
                    for (;;) {
                        const e = yield(0, s.take)(t), n = (0, h.positionSelector)(yield(0, s.select)(), e.symbol);
                        (!n || !e.position || e.position && n.side !== e.position.side) && (yield(0, s.put)(e))
                    }
                } finally {
                    t.close()
                }
            }

            function* f(e) {
                const t = yield(0, s.call)(i.waitTradingService), n = new u(t);
                yield(0, s.fork)(g, n);
                let o = null;

                function* r() {
                    const t = (0, h.getCurrentViewableListByWidgetId)(yield(0, s.select)(), e);
                    if (o !== t) {
                        const e = null === t ? [] : t.symbols;
                        p.logNormal("Setting watched positions: " + e), n.setSymbols(e);
                        const i = {};
                        for (const t of e) {
                            const [e] = n.positions(t);
                            i[t] = e ? (0, m.toPositionRecord)(e) : void 0
                        }
                        yield(0, s.put)((0, d.updateBulkPositions)(i)), o = t
                    }
                }
                yield(0, s.call)(r), yield(0, s.takeEvery)("*", r)
            }
            var v = n(70644),
                b = n(79359),
                _ = n(30401),
                y = n(88401),
                S = n(63940),
                w = n(97169),
                x = n(23506);

            function* E() {
                yield(0, s.takeLatest)(v.INIT_WIDGET, (function*(e) {
                    yield(0, s.call)(C)
                }))
            }

            function* k() {
                0
            }

            function* C() {
                const e = (0, h.getGlobalActiveID)(yield(0, s.select)());
                null === e && (yield(0, s.put)((0, w.asAction)((0, S.getActiveWatchlistThunk)(null)))), yield(0, s.put)((0, d.updateWidget)(b.WATCHLIST_WIDGET_ID, {
                    listId: e
                }));
                const t = y.linking.symbol.value();
                t && (yield(0, s.put)((0, d.updateWidget)(b.WATCHLIST_WIDGET_ID, {
                    scrollToId: {
                        id: t
                    }
                })))
            }

            function* T() {
                let e = (0, h.getGlobalActiveID)(yield(0, s.select)());
                for (;;) {
                    yield(0, s.take)("*");
                    const t = (0, h.getGlobalActiveID)(yield(0, s.select)());
                    e !== t && (e = t, yield(0, s.put)((0, d.updateWidget)(b.WATCHLIST_WIDGET_ID, {
                        listId: t,
                        selectedSymbols: []
                    })))
                }
            }

            function* I() {
                yield(0, s.takeEvery)(v.UPDATE_WIDGET, M), yield(0, s.takeEvery)(v.UPDATE_WIDGET_OPTIONS, D)
            }

            function* M(e) {
                const t = new _.WatchlistWidgetViewState;
                void 0 !== e.widget.columns && t.setColumns(e.widget.columns), void 0 !== e.widget.tickerType && (0, x.setInitialTickerType)(e.widget.tickerType)
            }

            function* D(e) {
                const t = new _.WatchlistWidgetViewState;
                void 0 !== e.options.isLogoEnabled && t.setIsLogoEnabled(e.options.isLogoEnabled)
            }
            n(26800);
            var N = n(7898);

            function* L(e) {
                const t = (0, o.eventChannel)(t => {
                    const n = () => {
                        t((0, N.updateScrollToIdThunk)(e, y.linking.symbol.value()))
                    };
                    return y.linking.symbol.subscribe(n), () => y.linking.symbol.unsubscribe(n)
                });
                try {
                    for (;;) yield(0, s.put)(yield(0, s.take)(t))
                } finally {
                    t.close()
                }
            }

            function* P() {
                yield(0, s.takeLatest)(v.SELECT_NEXT_AVAILABLE_SYMBOL, (function*(e) {
                    const {
                        widgetId: t,
                        currentSymbol: n,
                        keyboardAction: o,
                        cancelSetOnChart: i
                    } = e, r = (0, h.getCurrentViewableListByWidgetId)(yield(0, s.select)(), t);
                    if (null === r) return;
                    const {
                        symbols: l
                    } = r, a = (0, m.findNextAvailableSymbol)(l.indexOf(n), l, o);
                    a && (yield(0, s.put)((0, d.updateWidget)(t, {
                        selectedSymbols: [a]
                    })), i || y.linking.symbol.setValue(a))
                }))
            }

            function* W() {
                0
            }

            function* A(e) {
                yield(0, s.takeLatest)(v.SELECT_ALL_SYMBOLS, (function*(t) {
                    const {
                        widgetId: n
                    } = t;
                    if (e !== n) return;
                    const o = (0, h.getCurrentViewableListByWidgetId)(yield(0, s.select)(), n);
                    null !== o && (yield(0, s.put)((0, d.updateWidget)(n, {
                        selectedSymbols: o.symbols
                    })))
                }))
            }
            var B = n(1227);

            function* R() {
                yield(0, s.fork)(E), yield(0, s.fork)(T), yield(0, s.fork)(A, b.WATCHLIST_WIDGET_ID), yield(0, s.fork)(W), yield(0, s.fork)(L, b.WATCHLIST_WIDGET_ID), yield(0, s.fork)(P), (0, B.onWidget)() || (yield(0, s.fork)(f, b.WATCHLIST_WIDGET_ID), yield(0, s.fork)(k)), yield(0, s.fork)(I)
            }
        },
        25091: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                WatchListApi: () => h
            });
            var s = n(88537),
                o = n(40662),
                i = n(6474),
                r = n(16345),
                l = n(51951),
                a = n(1373),
                c = n(63940);
            const u = (0, l.getLogger)("WatchList.Api");

            function d(e) {
                return {
                    id: e.id,
                    symbols: e.symbols,
                    title: e.name
                }
            }
            class h {
                constructor(e, t) {
                    this._store = t, this._chartApiInstance = e
                }
                defaultList() {
                    return this._chartApiInstance.defaultWatchlistSymbols()
                }
                getList(e) {
                    const t = this._store.getState();
                    if (!e) {
                        const e = this.getActiveListId();
                        return e ? (0, s.ensureNotNull)((0, a.getCustomListById)(t, e)).symbols : null
                    }
                    const n = (0, a.getCustomListById)(t, e);
                    return null === n ? null : n.symbols
                }
                getActiveListId() {
                    return (0,
                        a.getGlobalActiveID)(this._store.getState())
                }
                setActiveList(e) {
                    this._store.dispatch((0, c.setActiveWatchlistThunk)(null, e))
                }
                getAllLists() {
                    const e = (0, a.getCustomLists)(this._store.getState()),
                        t = {};
                    return e.forEach(e => {
                        t[e.id] = d(e)
                    }), 0 === Object.keys(t).length ? null : t
                }
                setList(e) {
                    const t = this.getActiveListId();
                    t && (u.logWarn("`setList` is deprecated. Use `updateList` instead"), this.updateList(t, e))
                }
                updateList(e, t) {
                    const n = (0, a.getCustomListById)(this._store.getState(), e);
                    null !== n && this._store.dispatch((0, c.replaceWatchlistSymbolsThunk)(null, n, t))
                }
                renameList(e, t) {
                    const n = (0, a.getCustomListById)(this._store.getState(), e);
                    null !== n && this._store.dispatch((0, c.renameWatchlistThunk)(null, n, t))
                }
                createList(e, t = []) {
                    if (void 0 === e) return null;
                    let n = (0, r.randomHash)();
                    for (; null !== this.getList(n);) n = (0, r.randomHash)();
                    const s = (0, i.createWatchList)(n, e, t);
                    return this._store.dispatch((0, c.createWatchlistThunk)(s)), d(s)
                }
                saveList(e) {
                    const {
                        id: t,
                        title: n,
                        symbols: s
                    } = e, o = (0, a.getCustomListsMap)(this._store.getState()), r = (0, i.createWatchList)(t, n, s);
                    return void 0 !== o[t] ? (this._store.dispatch((0, c.putCustomWatchlistsThunk)(null, r)), !1) : (this._store.dispatch((0, c.createWatchlistThunk)(r)), !0)
                }
                deleteList(e) {
                    const t = (0, a.getCustomListById)(this._store.getState(), e);
                    null !== t && this._store.dispatch((0, c.removeWatchlistThunk)(null, t))
                }
                onListChanged() {
                    return o.onListChanged
                }
                onActiveListChanged() {
                    return o.onActiveListChanged
                }
                onListAdded() {
                    return o.onListAdded
                }
                onListRemoved() {
                    return o.onListRemoved
                }
                onListRenamed() {
                    return o.onListRenamed
                }
            }
        },
        62641: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                WatchList: () => et
            });
            var s = n(79049),
                o = n(83243),
                i = n(59496),
                r = n(25177),
                l = n(23506),
                a = n(80185),
                c = n(97754),
                u = n.n(c),
                d = n(88537),
                h = n(32455),
                m = n(74140),
                p = n(28466),
                g = n(26800),
                f = n(92707);

            function v(e) {
                const {
                    id: t,
                    className: n
                } = e;
                return i.createElement("div", {
                    className: u()(f.node, n)
                }, (0, g.safeShortName)(t))
            }
            var b = n(17447),
                _ = n(19769),
                y = (n(5797), n(296)),
                S = n(7898),
                w = n(82518),
                x = n(72351);
            const E = (0, s.connect)(null, (function(e) {
                return (0, o.bindActionCreators)({
                    removeSymbol: S.removeSymbolsThunk
                }, e)
            }))((function(e) {
                return i.createElement(y.ListItemButton, {
                    onClick: function(t) {
                        const {
                            widgetId: n,
                            removeSymbol: s,
                            symbolName: o
                        } = e;
                        t.preventDefault(), s(n, o)
                    },
                    className: u()(e.className, w.removeButton),
                    icon: x
                })
            }));
            var k = n(35842),
                C = n(1397);

            function T(e, t) {
                const n = t.parentNode;
                if (!n) return;
                const s = t.nextSibling;
                s ? n.insertBefore(e, s) : n.appendChild(e)
            }

            function I(e) {
                const t = function e(t) {
                    if (3 === t.nodeType && t.data.trim()) return t;
                    if (t.childNodes)
                        for (let n = t.childNodes.length; n--;) {
                            const s = e(t.childNodes[n]);
                            if (s) return s
                        }
                    return null
                }(e);
                if (t) {
                    const e = t.data;
                    if (t.parentNode && t.parentNode.tagName && "sup" === t.parentNode.tagName.toLowerCase()) return;
                    const n = /^([^]*)(\S)(\s*)$/.exec(e);
                    if (n) {
                        t.data = n[1];
                        const e = document.createElement("sup");
                        e.textContent = n[2], T(e, t), n[3] && T(document.createTextNode(n[3]), e)
                    }
                }
            }
            var M = n(42205);
            class D extends i.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._highlightTimeout = null, this._context = null, this._values = null, this._handleRef = e => {
                        this._ref = e
                    }
                }
                componentWillUnmount() {
                    this._highlightTimeout && clearTimeout(this._highlightTimeout)
                }
                render() {
                    const {
                        isHidden: e,
                        className: t
                    } = this.props;
                    return i.createElement("span", {
                        className: c(t, M.cell, M.last, e && M.hidden)
                    }, i.createElement("span", {
                        className: M.inner,
                        ref: this._handleRef
                    }))
                }
                update(e) {
                    const {
                        values: t
                    } = e, n = this._values;
                    if (void 0 === t.last_price || null === this._ref) return;
                    const s = null === n || n.pricescale !== t.pricescale || n.minmov !== t.minmov || n.fractional !== t.fractional || n.minmove2 !== t.minmove2,
                        o = null === n || n.last_price !== t.last_price;
                    if (!s && !o) return;
                    this._values = { ...t
                    };
                    const i = new C.PriceFormatter(t.pricescale || 100, t.minmov || 1, t.fractional, t.minmove2),
                        r = t.last_price,
                        l = i.format(t.last_price),
                        a = null !== this._context ? this._context.currentText : null,
                        c = null !== this._context ? this._context.currentValue : null,
                        u = this._context = {
                            formatter: i,
                            currentValue: r,
                            currentText: l,
                            previousValue: c,
                            previousText: a
                        };
                    this._ref.innerText = l, this._processHighlight(this._ref, u);
                    i.hasForexAdditionalPrecision() && I(this._ref)
                }
                _processNumericDiff(e) {
                    const {
                        previousValue: t,
                        previousText: n,
                        currentValue: s,
                        currentText: o,
                        formatter: i
                    } = e;
                    if (null === t || null === n || null === this._ref) return;
                    const r = c(s > t && M.plus, s < t && M.minus),
                        l = Math.min(n.length, o.length);
                    let a = 0;
                    for (; a < l && n.charAt(a) === o.charAt(a);) a++;
                    const u = o.slice(0, a),
                        d = o.slice(a);
                    d.length && r ? this._ref.innerHTML = u + `<span class="${r}">${d}</span>` : this._ref.innerText = o;
                    i.hasForexAdditionalPrecision() && I(this._ref)
                }
                _processHighlight(e, t) {
                    const {
                        previousValue: n,
                        currentValue: s
                    } = t;
                    null !== n && n !== s && (null !== this._highlightTimeout && (clearTimeout(this._highlightTimeout), this._highlightTimeout = null), e.classList.toggle(M.highlightUp, s > n), e.classList.toggle(M.highlightDown, s < n), this._highlightTimeout = setTimeout(() => {
                        e.classList.remove(M.highlightUp, M.highlightDown), this._processNumericDiff(t)
                    }, 500))
                }
            }
            class N extends i.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._handleRef = e => {
                        this._ref = e
                    }
                }
                render() {
                    const {
                        isHidden: e,
                        className: t
                    } = this.props;
                    return i.createElement("span", {
                        className: c(t, M.cell, M.change, e && M.hidden)
                    }, i.createElement("span", {
                        className: M.inner,
                        ref: this._handleRef
                    }))
                }
                update(e) {
                    const {
                        values: t
                    } = e, n = t.change;
                    if (void 0 === n || null === this._ref) return;
                    const s = new C.PriceFormatter(t.pricescale || 100, t.minmov || 1, t.fractional, t.minmove2);
                    this._ref.innerText = s.format(n), 0 !== n && (this._ref.classList.remove(M.plus, M.minus), this._ref.classList.add(n > 0 ? M.plus : M.minus))
                }
            }
            const L = new(n(42419).PercentageFormatter);
            class P extends i.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._handleRef = e => {
                        this._ref = e
                    }
                }
                render() {
                    const {
                        isHidden: e,
                        className: t
                    } = this.props;
                    return i.createElement("span", {
                        className: c(t, M.cell, M.changeInPercents, e && M.hidden)
                    }, i.createElement("span", {
                        className: M.inner,
                        ref: this._handleRef
                    }))
                }
                update(e) {
                    const {
                        values: t
                    } = e, n = t.change_percent;
                    void 0 !== n && null !== this._ref && (this._ref.innerText = L.format(n), 0 !== n && (this._ref.classList.remove(M.plus, M.minus), this._ref.classList.add(n > 0 ? M.plus : M.minus)))
                }
            }
            const W = new(n(35687).VolumeFormatter);
            class A extends i.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null,
                        this._handleRef = e => {
                            this._ref = e
                        }
                }
                render() {
                    const {
                        isHidden: e,
                        className: t
                    } = this.props;
                    return i.createElement("span", {
                        className: c(t, M.cell, M.volume, e && M.hidden)
                    }, i.createElement("span", {
                        className: M.inner,
                        ref: this._handleRef
                    }))
                }
                update(e) {
                    const {
                        values: t
                    } = e, n = t.volume;
                    void 0 === n || null === this._ref || Math.abs(n) >= 1e100 || (this._ref.innerText = W.format(n), this._ref.setAttribute("data-value", "" + n))
                }
            }
            var B = n(64858),
                R = n(78100),
                F = (n(4387), n(9970));
            const H = {
                classMap: {
                    invalid: "tv-market-status--invalid",
                    market: "tv-market-status--market",
                    out_of_session: "tv-market-status--out-of-session",
                    post_market: "tv-market-status--post-market",
                    pre_market: "tv-market-status--pre-market",
                    loading: "tv-market-status--loading",
                    holiday: "tv-market-status--holiday",
                    replay: "tv-market-status--replay"
                },
                classSuffix: "",
                data: {},
                extraTitle: "",
                labelMap: {
                    invalid: (0, r.t)("Invalid Symbol"),
                    market: (0, r.t)("Market Open"),
                    out_of_session: (0, r.t)("Market Closed"),
                    post_market: (0, r.t)("Post Market"),
                    pre_market: (0, r.t)("Pre Market"),
                    loading: (0, r.t)("Loading"),
                    holiday: (0, r.t)("Holiday"),
                    replay: ""
                },
                short: !1,
                showTooltip: !0,
                tooltipType: "custom"
            };
            class U extends F.AbstractIndicator {
                constructor(e) {
                    super(e), this._quoteSessionPrefix = "market-status-indicator", this._componentClass = "tv-market-status", this._extraTitle = "", this._init(e)
                }
                setStatus(e, t) {
                    const n = {
                        values: {
                            current_session: e
                        }
                    };
                    this.update(n, t)
                }
                getTooltipText() {
                    let e = super.getTooltipText();
                    return "" === e || "" !== this._extraTitle && (e = `${e}, ${this._extraTitle}`), e
                }
                setExtraTitle(e) {
                    this._extraTitle = e
                }
                reset() {
                    this._clearClasses(), this._labelEl.textContent = "", this._extraTitle = "", this._el.setAttribute("title", ""), this._value = ""
                }
                enableShortMode(e = !0) {
                    void 0 !== this._labelEl && this._labelEl.classList.add("i-hidden"), super.enableShortMode()
                }
                disableShortMode() {
                    void 0 !== this._labelEl && this._labelEl.classList.remove("i-hidden"), super.disableShortMode()
                }
                _renderLabel() {
                    this._labelEl.textContent = this.getLabel()
                }
                _getValueFromData(e) {
                    return void 0 !== e.values && void 0 !== e.values.current_session ? e.values.current_session : this.getValue()
                }
                _render() {
                    this._renderLabelElement(), this._renderDotElement(), super._render()
                }
                _init(e) {
                    const t = Object.assign({}, H, e);
                    super._init(t), this.setExtraTitle(t.extraTitle), this._render()
                }
                _renderLabelElement() {
                    void 0 === this._labelEl && (this._labelEl = document.createElement("span"), this._labelEl.classList.add(this._componentClass + "__label"), this._labelEl.classList.add(`${this._componentClass}__label${this._classSuffix}`), this._el.appendChild(this._labelEl))
                }
                _renderDotElement() {
                    void 0 === this._dotEl && (this._dotEl = document.createElement("span"), this._dotEl.classList.add(this._componentClass + "__dot"), this._dotEl.classList.add(`${this._componentClass}__dot${this._classSuffix}`), this._el.appendChild(this._dotEl))
                }
            }
            var z = n(72571),
                O = n(37914),
                V = n(99774),
                q = n(52203),
                G = n(80795);

            function Z(e, t) {
                const n = O.quoteSessionAdapters.get(e).getLastSymbolData(t.symbol);
                if (!n) return "";
                const s = n.values,
                    o = new C.PriceFormatter(s.pricescale || 100, s.minmov || 1, s.fractional, s.minmove2);
                return `${1===t.side?(0,r.t)("Long"):(0,
r.t)("Short")} ${Math.abs(t.qty)} @ ${o.format(t.avgPrice)}`
            }
            var X = n(1373);
            const K = (0, s.connect)((function(e, t) {
                return {
                    position: (0, X.positionSelector)(e, t.symbolName)
                }
            }))((function(e) {
                const {
                    position: t,
                    className: n,
                    widgetId: s
                } = e;
                if (void 0 === t) return null;
                const o = 1 === t.side;
                return i.createElement(z.Icon, {
                    className: c("apply-common-tooltip", G.icon, o && G.long, n),
                    icon: o ? V : q,
                    title: Z(s, t)
                })
            }));
            var $ = n(62654);
            n(94600), n(27079);
            const Y = (e, t) => ({
                classSuffix: "--for-symbol-list",
                el: e,
                short: !0,
                symbol: t,
                manualUpdate: !0,
                tooltipType: "custom"
            });
            class j extends i.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._marketStatusIndicator = null, this._dataModeIndicator = null, this._description = null, this._handleNameContentSet = () => {
                        if (null === this._ref) return;
                        const {
                            tickerType: e,
                            symbolName: t
                        } = this.props, n = {
                            [$.TickerType.Description]: () => this._description || (0, g.safeShortName)(t),
                            [$.TickerType.Ticker]: () => (0, g.safeShortName)(t)
                        };
                        this._ref.textContent = n[e]()
                    }, this._handleRef = e => {
                        this._ref = e
                    }, this._handleMarketStatusRef = e => {
                        const {
                            symbolName: t
                        } = this.props;
                        null !== e && (this._marketStatusIndicator = new U(Y(e, t)))
                    }, this._handleDataModeRef = e => {
                        const {
                            symbolName: t
                        } = this.props;
                        null !== e && (this._dataModeIndicator = new R.DataModeIndicator(Y(e, t)))
                    }
                }
                componentDidMount() {
                    null !== this._ref && this._handleNameContentSet()
                }
                componentDidUpdate(e) {
                    null !== this._ref && e.tickerType !== this.props.tickerType && this._handleNameContentSet()
                }
                render() {
                    const {
                        isInvalid: e,
                        symbolName: t,
                        shouldDisplayPositions: n,
                        widgetId: s,
                        className: o,
                        hasSFWarning: r,
                        logoUrls: l
                    } = this.props;
                    return i.createElement("div", {
                        className: u()(o, M.symbolName)
                    }, i.createElement("span", {
                        className: u()(M.cell, M.flexCell)
                    }, !1, i.createElement("span", {
                        className: u()(M.inner, M.symbolNameText),
                        ref: this._handleRef
                    }), !e && i.createElement(i.Fragment, null, !1, !r && i.createElement(i.Fragment, null, i.createElement("span", {
                        ref: this._handleDataModeRef
                    }), i.createElement("span", {
                        ref: this._handleMarketStatusRef
                    }), n && i.createElement(K, {
                        widgetId: s,
                        className: M.positions,
                        symbolName: t
                    }))), !1))
                }
                update(e) {
                    if (null === this._ref) return;
                    const {
                        values: t
                    } = e;
                    this._marketStatusIndicator && this._marketStatusIndicator.update({
                        values: t
                    }), this._dataModeIndicator && this._dataModeIndicator.update({
                        values: t
                    }), this._description = (0, B.getTranslatedSymbolDescription)(t), this._handleNameContentSet()
                }
            }
            var J = n(44471),
                Q = n(72535),
                ee = n(88401),
                te = n(1227),
                ne = n(70086),
                se = n(6474),
                oe = n(96796),
                ie = n(83240);
            const re = {
                    market: "marketOpen",
                    pre_market: "marketPre",
                    post_market: "marketPost",
                    out_of_session: "marketClose",
                    holiday: "marketHoliday"
                },
                le = {
                    market: (0, r.t)("Market open"),
                    pre_market: (0, r.t)("Pre market"),
                    post_market: (0, r.t)("Post market"),
                    out_of_session: (0, r.t)("Market closed"),
                    holiday: (0, r.t)("Holiday")
                },
                ae = {
                    delayed_streaming: (0, r.t)("Delayed"),
                    pulsed: (0, r.t)("Delayed"),
                    streaming: (0, r.t)("Real-time"),
                    endofday: (0, r.t)("End of Day")
                };

            function ce(e) {
                const t = le[e];
                return `<span class="${ie[re[e]]}">${(0,oe.htmlEscape)(t)}</span>`
            }
            var ue = n(98171);
            class de extends i.PureComponent {
                constructor(e) {
                    super(e), this._observer = null, this._ref = null, this._raf = null, this._injectListClasses = (e, t) => {
                        if (!i.isValidElement(e)) return e;
                        const n = ["short_name", "last_price", "change", "change_percent", "volume", "rchp"].map((e, t) => [t, e]).filter(([e, t]) => this.props.columns.includes(t)),
                            [s] = n[0];
                        t === s && (e = i.cloneElement(e, {
                            className: c(e.props.className, M.firstItem)
                        }));
                        const [o] = n[n.length - 1];
                        return t === o && (e = i.cloneElement(e, {
                            className: c(e.props.className, M.lastItem)
                        })), e
                    }, this._onData = e => {
                        this._data = e, null === this._raf && (this._raf = requestAnimationFrame(() => {
                            const {
                                id: e
                            } = this.props, {
                                logoUrls: t
                            } = this.state, n = (0, d.ensureDefined)(this._data), {
                                symbolname: s,
                                status: o
                            } = n;
                            e === s && (this._ref && this._ref.setAttribute("data-status", "resolved"), "error" === o ? this.setState({
                                isInvalid: !0
                            }) : "sf_data" === o ? this.setState({
                                hasSFWarning: !0
                            }) : (null !== this._symbolName.current && this._symbolName.current.update(n), null !== this._lastPrice.current && this._lastPrice.current.update(n), null !== this._change.current && this._change.current.update(n), null !== this._changeInPercents.current && this._changeInPercents.current.update(n), null !== this._volume.current && this._volume.current.update(n))), this._handleCustomTooltipSetter("error" === o, n), this._raf = null
                        }))
                    }, this._handleCustomTooltipSetter = (e, t) => {
                        if (null === this._ref) return;
                        if (e) return void this._ref.setAttribute("data-tooltip", "");
                        const n = function(e) {
                            const {
                                description: t,
                                exchange: n,
                                updateMode: s,
                                marketStatus: o
                            } = e, i = t ? `<div class="${ie.description}">${(0,oe.htmlEscape)(t)}</div>` : null, r = `<span class="${ie.dot}">•</span>`, l = [n ? `<span>${(0,oe.htmlEscape)(n)}</span>` : null, s ? `<span>${(0,oe.htmlEscape)(ae[s])}</span>` : null, o ? ce(o) : null].filter(e => null !== e).join(r), a = i ? [i, l].join("") : l;
                            return `<div class="${ie.wrapper}">${a}</div>`
                        }(this._getSymbolTooltipData(t));
                        n && this._ref.getAttribute("data-tooltip") !== n && this._ref.setAttribute("data-tooltip", n)
                    }, this._handleRef = e => {
                        if (null !== e) {
                            const t = .25;
                            this._observer = new IntersectionObserver(e => {
                                e[e.length - 1].intersectionRatio < t ? this._onInvisible() : this._onVisible()
                            }, {
                                threshold: [0, .25, .5, .75, 1],
                                root: null,
                                rootMargin: "0px"
                            }), this._observer.observe(e)
                        }
                        this._ref = e
                    }, this._handleContextMenu = e => {
                        e.preventDefault(), this._showContextMenu(e, 0)
                    }, this._handleSmallContextMenu = e => {
                        this._showContextMenu(e, 1)
                    }, this._showContextMenu = (e, t) => {
                        e.persist();
                        const {
                            showContextMenu: n,
                            id: s,
                            widgetId: o
                        } = this.props;
                        n(o, s, e, t)
                    }, this._onSymbolChanged = e => {
                        const t = this._computeActive(e);
                        t !== this.state.isActive && this.setState({
                            isActive: t
                        }), (0, J.hide)()
                    }, this._lastPrice = i.createRef(), this._change = i.createRef(), this._changeInPercents = i.createRef(), this._volume = i.createRef(), this._prePostMarket = i.createRef(), this._symbolName = i.createRef();
                    this._getLastSymbolData();
                    const t = [];
                    this.state = {
                        isInvalid: !1,
                        hasSFWarning: !1,
                        isActive: this._computeActive(ee.linking.symbol.value()),
                        logoUrls: t
                    }
                }
                componentDidMount() {
                    const {
                        id: e,
                        widgetId: t
                    } = this.props;
                    null !== this._ref && this._ref.setAttribute("data-status", "pending");
                    const n = O.quoteSessionAdapters.get(t),
                        s = this._getLastSymbolData();
                    s && this._onData(s), n.addSymbolDataHandler(e, this._onData), ee.linking.symbol.subscribe(this._onSymbolChanged)
                }
                componentWillUnmount() {
                    const {
                        id: e,
                        widgetId: t
                    } = this.props;
                    O.quoteSessionAdapters.get(t).removeSymbolDataHandler(e), this._observer && this._observer.disconnect(), ee.linking.symbol.unsubscribe(this._onSymbolChanged), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null)
                }
                render() {
                    const {
                        id: e,
                        columns: t,
                        tickerType: n,
                        isSelected: s,
                        isHighlighted: o,
                        widgetId: r,
                        isDeletable: l,
                        enableContextMenu: a,
                        shouldDisplayPositions: u,
                        isContainedByMultiSelection: d,
                        isFirstListItem: h,
                        isLogoEnabled: m
                    } = this.props, {
                        isInvalid: p,
                        hasSFWarning: f,
                        isActive: v,
                        logoUrls: b
                    } = this.state, {
                        size: _
                    } = this.context, y = v ? d : s, S = (0, ue.isSeparatorItem)(e) || p;
                    return i.createElement("div", {
                        className: c(M.symbol, 1 === _ && M.small, y && M.selected, v && M.active, Q.mobiletouch && M.touch, o && M.highlighted, S && M.invalid, h && M.firstRow, "common-tooltip-html", "common-tooltip-vertical", "apply-common-tooltip"),
                        ref: this._handleRef,
                        "data-tooltip-delay": 1500,
                        "data-symbol-full": e,
                        "data-symbol-short": (0, g.safeShortName)(e),
                        "data-active": v,
                        "data-selected": s,
                        onClick: 1 === _ && a ? this._handleSmallContextMenu : void 0,
                        onContextMenu: 0 === _ && a ? this._handleContextMenu : void 0
                    }, i.createElement("div", {
                        className: c(M.indicators, v && M.active)
                    }, !(0, te.onWidget)() && !1), i.createElement(ne.FragmentMap, {
                        map: this._injectListClasses
                    }, i.createElement(j, {
                        symbolName: e,
                        shouldDisplayPositions: u,
                        ref: this._symbolName,
                        hasSFWarning: f,
                        isInvalid: p,
                        widgetId: r,
                        tickerType: n,
                        logoUrls: void 0
                    }), i.createElement(D, {
                        ref: this._lastPrice,
                        isHidden: !t.includes("last_price")
                    }), i.createElement(N, {
                        ref: this._change,
                        isHidden: !t.includes("change")
                    }), i.createElement(P, {
                        ref: this._changeInPercents,
                        isHidden: !t.includes("change_percent")
                    }), i.createElement(A, {
                        ref: this._volume,
                        isHidden: !t.includes("volume")
                    }), !1), l && i.createElement("div", {
                        className: M.overlayEnd
                    }, i.createElement(E, {
                        className: M.removeButton,
                        widgetId: r,
                        symbolName: e
                    })))
                }
                _onVisible() {
                    const {
                        id: e,
                        widgetId: t
                    } = this.props;
                    O.quoteSessionAdapters.get(t).addFastSymbol(e)
                }
                _onInvisible() {
                    const {
                        id: e,
                        widgetId: t
                    } = this.props;
                    O.quoteSessionAdapters.get(t).removeFastSymbol(e)
                }
                _getSymbolTooltipData(e) {
                    const {
                        values: t
                    } = e;
                    let n;
                    return n = t.exchange || null, {
                        description: (0, B.getTranslatedSymbolDescription)(t) || null,
                        exchange: n,
                        updateMode: t.update_mode || null,
                        marketStatus: t.current_session || null
                    }
                }
                _computeActive(e) {
                    return void 0 !== e && (0, se.compareSymbols)(e, this.props.id)
                }
                _getLastSymbolData() {
                    const {
                        id: e,
                        widgetId: t
                    } = this.props;
                    return O.quoteSessionAdapters.get(t).getLastSymbolData(e)
                }
            }
            de.contextType = k.SizeContext;
            const he = (0, s.connect)((function() {
                const e = (0, X.makeGetIsContainedByMultiSelection)();
                return (t, n) => {
                    const {
                        isDeletable: s,
                        enableContextMenu: o,
                        isLogoEnabled: i
                    } = (0, X.widgetOptionsSelector)(t, n.widgetId), r = (0, X.highlightedSymbolsSelector)(t, n.widgetId);
                    return {
                        isDeletable: s,
                        enableContextMenu: o,
                        isContainedByMultiSelection: e(t, {
                            widgetId: n.widgetId,
                            symbol: n.id
                        }),
                        isLogoEnabled: i,
                        shouldDisplayPositions: (0, X.shouldDisplayPositionsSelector)(t, n.widgetId),
                        columns: (0, X.columnsSelector)(t, n.widgetId),
                        tickerType: (0, X.tickerTypeSelector)(t, n.widgetId),
                        isHighlighted: !!r && r.includes(n.id)
                    }
                }
            }), (function(e) {
                return (0, o.bindActionCreators)({
                    showContextMenu: _.showContextMenu
                }, e)
            }))(de);
            var me = n(34816),
                pe = n(32133),
                ge = n(2946),
                fe = n(91871);
            const ve = [{
                column: "last_price",
                label: (0, r.t)("Last")
            }, {
                column: "change",
                label: (0, r.t)("Change")
            }, {
                column: "change_percent",
                label: (0, r.t)("Change %")
            }, {
                column: "volume",
                label: (0, r.t)("Volume")
            }];

            function be(e) {
                const {
                    columns: t,
                    updateWidget: n,
                    widgetId: s
                } = e, {
                    size: o
                } = (0, i.useContext)(k.SizeContext), r = 1 === o;
                return i.createElement(i.Fragment, null, ve.map(e => {
                    const {
                        column: n,
                        label: s
                    } = e;
                    return i.createElement(ge.Checkbox, {
                        key: n,
                        className: u()(fe.checkbox, r && fe.mobile),
                        name: n,
                        label: s,
                        checked: t.includes(n),
                        onChange: l(n)
                    })
                }));

                function l(e) {
                    return () => {
                        const o = [...t];
                        o.includes(e) ? o.splice(o.indexOf(e), 1) : o.push(e), n(s, {
                            columns: o
                        })
                    }
                }
            }
            var _e = n(37988);
            const ye = (0, s.connect)((function(e, t) {
                return {
                    columns: (0, X.columnsSelector)(e, t.widgetId)
                }
            }), (function(e) {
                return (0, o.bindActionCreators)({
                    updateWidget: _.updateWidget
                }, e)
            }))((function(e) {
                const {
                    columns: t,
                    updateWidget: n,
                    className: s,
                    widgetId: o
                } = e, {
                    size: r
                } = (0, i.useContext)(k.SizeContext), l = 1 === r;
                return i.createElement("div", {
                    className: u()(fe.wrap, s)
                }, i.createElement(me.ToolWidgetMenu, {
                    content: i.createElement(z.Icon, {
                        className: fe.icon,
                        icon: _e
                    }),
                    arrow: !1,
                    className: fe.columnsMenu,
                    onClose: function() {
                        (0, pe.trackEvent)("Watchlist", "Change columns", t.join(", "))
                    },
                    isDrawer: l,
                    drawerPosition: "Bottom"
                }, i.createElement(be, {
                    widgetId: o,
                    columns: t,
                    updateWidget: n
                })))
            }));
            var Se = n(21258);
            const we = i.createContext({});
            var xe = n(34581),
                Ee = n(96818),
                ke = n(87529);
            const Ce = (0, xe.isRtl)();

            function Te(e) {
                const {
                    column: t
                } = e, {
                    columnResizeDelegate: n,
                    columnResizeStopDelegate: s
                } = (0, i.useContext)(we), o = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    const e = new Ee.PointerBackend({
                        handle: (0, d.ensureNotNull)(o.current),
                        onDragStart: () => {},
                        onDragMove: e => {
                            const {
                                current: s,
                                initial: o
                            } = e.detail, i = s.pageX - o.pageX;
                            null == n || n.fire(t, i * (Ce ? 1 : -1))
                        },
                        onDragStop: () => {
                            null == s || s.fire()
                        }
                    });
                    return () => {
                        e.destroy()
                    }
                }, [t, n, s]), i.createElement("div", {
                    className: ke.placeholder
                }, i.createElement("div", {
                    ref: o,
                    className: ke.wrap
                }, i.createElement("div", {
                    className: ke.handle
                }), i.createElement("div", {
                    className: ke.separator
                })))
            }
            var Ie = n(26532),
                Me = n(42701),
                De = n(68650);
            const Ne = (0, s.connect)((function(e, t) {
                const {
                    isSortable: n
                } = (0, X.widgetOptionsSelector)(e, t.widgetId);
                return {
                    isSortable: n,
                    sorting: (0, X.sortingSelector)(e, t.widgetId)
                }
            }), (function(e) {
                return (0, o.bindActionCreators)({
                    sortSymbols: S.sortSymbolsThunk
                }, e)
            }))((function(e) {
                const {
                    widgetId: t,
                    isSortable: n,
                    tickerType: s,
                    column: o,
                    className: l,
                    sortSymbols: a,
                    label: u,
                    sorting: h
                } = e, m = (0, i.useRef)(null), g = (0, i.useRef)(null), [f, v] = (0, Se.useHover)(), {
                    size: b
                } = (0, i.useContext)(k.SizeContext), _ = (0, i.useContext)(p.CloseDelegateContext), y = 1 === b, {
                    columnResizeDelegate: S,
                    requestColumnInitWidthDelegate: w,
                    setColumnInitWidthDelegate: x
                } = (0, i.useContext)(we), E = (0, i.useMemo)(() => function(e, t, n, s) {
                    if (!t) return "";
                    const o = (0, r.t)("Click to sort by {columnLabel}").format({
                        columnLabel: n
                    });
                    if (null !== e && e.column === s) return 1 === e.direction ? `${o} ${Me}` : (0, r.t)("Click to return to customized order");
                    return `${o} ${Ie}`
                }(h, n, u, o), [h, n, u, o]);
                return (0, i.useEffect)(() => {
                    const e = e => {
                        e === o && (null == x || x.fire(o, (0, d.ensureNotNull)(m.current).getBoundingClientRect().width))
                    };
                    return null == w || w.subscribe(null, e), () => null == w ? void 0 : w.unsubscribe(null, e)
                }, [w, x, o]), (0, i.useEffect)(() => (_.subscribe(null, J.hide), () => _.unsubscribe(null, J.hide)), []), (0, i.useEffect)(() => {
                    n && (f ? (0, J.showOnElement)((0, d.ensureNotNull)(g.current), {
                        content: {
                            type: "html",
                            data: E
                        }
                    }) : (0, J.hide)())
                }, [f, E]), i.createElement(i.Fragment, null, i.createElement("span", {
                    ref: m,
                    key: o,
                    className: c(De.columnHeader, l, y && De.small)
                }, i.createElement("span", { ...v,
                    ref: g,
                    className: c(De.label, n && De.sortable),
                    onClick: n ? function() {
                        let e = {
                            column: o,
                            direction: 1
                        };
                        null !== h && h.column === o && (e = 1 === h.direction ? { ...h,
                            direction: -1
                        } : null);
                        a(t, e, s);
                        const n = e ? 1 === e.direction ? "ascending" : "descending" : "default";
                        (0, pe.trackEvent)("Watchlist", "Sort", `Sort by ${o} ${n}`)
                    } : void 0,
                    "data-column-type": o
                }, u)), S && i.createElement(Te, {
                    column: o
                }))
            }));
            var Le = n(11817);
            const Pe = (0, s.connect)((function(e, t) {
                const {
                    shouldDisplayColumnsMenu: n,
                    isSortable: s
                } = (0, X.widgetOptionsSelector)(e, t.widgetId), o = (0, X.getCurrentViewableListByWidgetId)(e, t.widgetId);
                return {
                    shouldDisplayColumnsMenu: n,
                    columns: (0, X.columnsSelector)(e, t.widgetId),
                    tickerType: (0, X.tickerTypeSelector)(e, t.widgetId),
                    hasFlagColumn: "custom" === (null == o ? void 0 : o.type) && s
                }
            }))((function(e) {
                const {
                    columns: t,
                    widgetId: n,
                    shouldDisplayColumnsMenu: s,
                    tickerType: o,
                    hasFlagColumn: l
                } = e, a = (0, i.useMemo)(() => function(e, t, n) {
                    const s = {
                        [$.TickerType.Ticker]: (0, r.t)("Symbol"),
                        [$.TickerType.Description]: (0, r.t)("Description")
                    };
                    0;
                    return [{
                        column: "short_name",
                        label: s[t],
                        className: Le.symbolName
                    }, {
                        column: "last_price",
                        label: (0, r.t)("Last"),
                        className: Le.last
                    }, {
                        column: "change",
                        label: (0, r.t)("Chg"),
                        className: Le.change
                    }, {
                        column: "change_percent",
                        label: (0, r.t)("Chg%"),
                        className: Le.changeInPercents
                    }, {
                        column: "volume",
                        label: (0, r.t)("Vol"),
                        className: Le.volume
                    }].filter(t => e.includes(t.column) || n && "flag" === t.column)
                }(t, o, l), [t, o, l]);
                return i.createElement("div", {
                    className: Le.wrap
                }, s && i.createElement(ye, {
                    widgetId: n,
                    className: Le.menu
                }), i.createElement("div", {
                    className: Le.tableHeader
                }, a.map((e, t, s) => i.createElement(Ne, {
                    widgetId: n,
                    key: e.column,
                    tickerType: o,
                    label: e.label,
                    column: e.column,
                    className: u()(e.className, 0 === t && Le.firstItem, t === a.length - 1 && Le.lastItem)
                }))))
            }));
            var We = n(12777),
                Ae = n(97496),
                Be = n.n(Ae);
            var Re = n(97280),
                Fe = n(31216);
            const He = {
                    32: "next",
                    [32 + a.Modifiers.Shift]: "previous"
                },
                Ue = Q.mobiletouch ? "touch" : "native",
                ze = ["flag", "short_name", "last_price", "change", "change_percent", "volume", "rchp"];

            function Oe(e) {
                return Array.from(e).sort((e, t) => ze.indexOf(e) - ze.indexOf(t))
            }

            function Ve(e, t, n, s) {
                let o = 16,
                    i = 32;
                const r = Oe(t);
                return r.forEach((t, l) => {
                    const a = Math.max(32, n - o - 32 * (r.length - l - 1));
                    t === e && (i = a);
                    const c = s.get(t);
                    if (c) {
                        const e = (0, Re.clamp)(c * n, 32, a);
                        o += e
                    }
                }), qe(i)
            }

            function qe(e) {
                return Math.round(10 * e) / 10
            }

            function Ge(e) {
                const {
                    dropType: t,
                    boundBox: n
                } = e, {
                    top: s,
                    bottom: o,
                    left: i
                } = (0, d.ensureDefined)(n);
                return [i, "before" === t || "inside" === t ? s + .5 : o - .5]
            }

            function Ze(e) {
                return i.createElement("div", {
                    className: Fe.empty
                }, i.createElement("div", {
                    className: Fe.centered
                }, e.children))
            }

            function Xe(e, t) {
                const {
                    listId: n
                } = e.widgets[t];
                return null !== n ? "custom" : null
            }
            const Ke = (0, s.connect)((function(e, t) {
                const {
                    isMovable: n
                } = (0, X.widgetOptionsSelector)(e, t.widgetId), s = (0, X.getCurrentViewableListByWidgetId)(e, t.widgetId);
                return {
                    columns: (0, X.columnsSelector)(e, t.widgetId),
                    isMovable: n,
                    isLoading: (0, X.isLoadingSelector)(e, t.widgetId),
                    selectedSymbols: (0, X.selectedSymbolsSelector)(e, t.widgetId),
                    scrollToId: (0, X.scrollToIdSelector)(e, t.widgetId),
                    listType: Xe(e, t.widgetId),
                    isHotlist: Boolean("hot" === (null == s ? void 0 : s.type))
                }
            }), (function(e) {
                return (0, o.bindActionCreators)({
                    updateWidget: _.updateWidget,
                    selectNextAvailableSymbol: _.selectNextAvailableSymbol
                }, e)
            }))((function(e) {
                const {
                    columns: t,
                    symbols: n,
                    icon: s,
                    isLoading: o,
                    noSymbolsPlaceholder: r,
                    selectedSymbols: u,
                    updateWidget: g,
                    selectNextAvailableSymbol: f,
                    onKeyDown: _,
                    isMovable: y,
                    widgetId: S,
                    scrollToId: w,
                    listType: x,
                    isHotlist: E,
                    viewState: C,
                    ...T
                } = e, I = (0, i.useMemo)(() => (0, l.createNodes)(n), [n]), M = (0, i.useContext)(p.CloseDelegateContext), {
                    size: D
                } = (0, i.useContext)(k.SizeContext), N = 1 === D, L = (0, i.useRef)(performance.now()), P = (0, i.useRef)(null), W = (0, i.useCallback)(e => ((0, se.isValidSeparatorItem)(e.id), i.createElement(he, { ...e,
                    widgetId: S
                })), [S]), A = (0, i.useCallback)(e => i.createElement(v, { ...e,
                    widgetId: S,
                    id: (0, se.isValidSeparatorItem)(e.id) ? (0, se.separatorValToDisplayVal)(e.id) : e.id,
                    className: c((0, se.isValidSeparatorItem)(e.id) && Fe.separatorDragPreview)
                }), [S]), B = (0, i.useCallback)((e, t) => {
                    switch (t.type) {
                        case "node":
                            return (0, se.isValidSeparatorItem)(t.node.props.id) ? 36 : 30;
                        case "separator":
                            return 13
                    }
                }, []), R = (0, i.useCallback)((e, t) => {
                    var n;
                    0 !== e.button || 0 !== (0, a.modifiersFromEvent)(e) || (0, se.isValidSeparatorItem)(t) || (1 === e.nativeEvent.detail && ee.linking.symbol.setValue(t), 2 === e.nativeEvent.detail && (null === (n = ee.linking.getChartWidget()) || void 0 === n || n.chartWidgetCollection().setSymbolAll(t)))
                }, []), F = (0, i.useCallback)(e => {
                    (0, se.isValidSeparatorItem)(e) || ee.linking.symbol.setValue(e)
                }, []), H = (0, i.useCallback)((e, t) => t && 1 === e.length && (0, se.isValidSeparatorItem)(e[0]) ? f(S, e[0], t) : g(S, {
                    selectedSymbols: e
                }), [S, f, g]), [U, V] = (0, i.useState)(void 0), [q, G] = (0, i.useState)((function() {
                    var e;
                    return null !== (e = null == C ? void 0 : C.getColumnsPercentages()) && void 0 !== e ? e : new Map
                }));
                (0, i.useEffect)(() => {
                    const e = O.quoteSessionAdapters.get(S);
                    return e.addToSubscriptionSet(n), e.commitSubscriptionChanges(), ee.linking.symbol.subscribe(Q), () => {
                        e.addToCancelSubscriptionSet(n), ee.linking.symbol.unsubscribe(Q)
                    }
                }, [n]), (0, i.useEffect)(() => () => {
                    const e = O.quoteSessionAdapters.get(S);
                    e.clearSubscriptionSet(), e.commitSubscriptionChanges()
                }, []);
                const [Z, X] = (0, i.useState)(() => ({
                    height: 0,
                    width: 0
                })), K = (0, m.useResizeObserver)(e => {
                    const [t] = e, {
                        width: n,
                        height: s
                    } = t.contentRect;
                    X(e => e.width === n && e.height === s ? e : {
                        height: s,
                        width: n
                    })
                }), $ = (0, i.useRef)(null), Y = (0, i.useMemo)(() => Boolean(null == C ? void 0 : C.canResizeColumns()) ? {
                    requestColumnInitWidthDelegate: new(Be()),
                    setColumnInitWidthDelegate: new(Be()),
                    columnResizeStartDelegate: new(Be()),
                    columnResizeDelegate: new(Be()),
                    columnResizeStopDelegate: new(Be())
                } : {}, [C]), j = function(e, t, n) {
                    const s = {},
                        o = Oe(e);
                    return Array.from(n.entries()).forEach(([i, r]) => {
                        if (!o.includes(i)) return;
                        if (o.indexOf(i) === o.length - 1) return void("change_percent" === i && (s[`--tv-symbol-list-column-${i}-flex`] = "1 1"));
                        const l = Ve(i, e, t, n);
                        s[`--tv-symbol-list-column-${i}-flex`] = `0 0 ${(0,Re.clamp)(qe(r*t),32,l)}px`
                    }), s
                }(t, Z.width, q), J = (0, i.useCallback)((e, t) => {
                    const {
                        requestColumnInitWidthDelegate: n,
                        setColumnInitWidthDelegate: s
                    } = Y;
                    let o = !1;
                    return t.forEach(t => {
                        if (!e.has(t)) {
                            o = !0;
                            const i = (t, n) => e.set(t, n / Z.width);
                            null == s || s.subscribe(null, i, !0), null == n || n.fire(t), null == s || s.unsubscribeAll(null)
                        }
                    }), Array.from(e.keys()).forEach(n => {
                        -1 === t.indexOf(n) && (o = !0, e.delete(n))
                    }), o
                }, [Z, Y]);
                return (0, i.useEffect)(() => {
                    var e;
                    if (q.size > 0 && (null == C ? void 0 : C.canResizeColumns())) {
                        const n = new Map(q);
                        J(n, t) && (G(n), null === (e = C.saveColumnsPercentages) || void 0 === e || e.call(C, n))
                    }
                }, [t, q, J, C]), (0, i.useEffect)(() => {
                    const {
                        columnResizeDelegate: e
                    } = Y, n = (e, n) => {
                        G(s => {
                            const o = new Map(s);
                            J(o, t);
                            const i = n => (0, Re.clamp)(n, 32, Ve(e, t, Z.width, o));
                            null === P.current && (P.current = i((0, d.ensureDefined)(o.get(e)) * Z.width));
                            const r = i(P.current - n);
                            return o.set(e, r / Z.width), o
                        })
                    };
                    return null == e || e.subscribe(null, n), () => null == e ? void 0 : e.unsubscribe(null, n)
                }, [t, Z, Y, J]), (0, i.useEffect)(() => {
                    const {
                        columnResizeStopDelegate: e
                    } = Y, t = () => {
                        var e;
                        P.current = null, null === (e = null == C ? void 0 : C.saveColumnsPercentages) || void 0 === e || e.call(C, q)
                    };
                    return null == e || e.subscribe(null, t), () => null == e ? void 0 : e.unsubscribe(null, t)
                }, [q, Y, C]), i.createElement(we.Provider, {
                    value: Y
                }, i.createElement("div", {
                    className: Fe.wrap,
                    style: j,
                    onContextMenu: We.preventDefaultForContextMenu
                }, i.createElement(Pe, {
                    widgetId: S
                }), i.createElement("div", {
                    ref: K,
                    className: Fe.content
                }, i.createElement("div", {
                    className: c(Fe.scrollable, 0 === n.length && Fe.noData),
                    onMouseDown: function(e) {
                        if (!(e.target instanceof Element) || null === $.current) return;
                        const {
                            activeElement: t
                        } = document;
                        e.target === $.current && ($.current.contains(t) && e.preventDefault(), te())
                    },
                    onKeyDown: function(e) {
                        27 === (0, a.hashFromEvent)(e) && (e.preventDefault(), te());
                        if (1 === u.length && (null == U ? void 0 : U.id) !== u[0] && (null == U ? void 0 : U.id) === ee.linking.symbol.value()) {
                            if (40 === (0, a.hashFromEvent)(e)) return void ee.linking.symbol.setValue(u[0]);
                            if (38 === (0, a.hashFromEvent)(e)) return void f(S, u[0], "previous")
                        }
                        _ && _(e)
                    },
                    onScrollCapture: function() {
                        if (L.current + 500 > performance.now()) return;
                        M.fire()
                    }
                }, !o && n.length > 0 && 0 !== Z.width && i.createElement(b.Tree, { ...T,
                    key: String(x),
                    height: Z.height,
                    width: Z.width,
                    navigationKeys: He,
                    nodeRenderer: W,
                    drag: Ue,
                    dragPreviewRenderer: A,
                    nodes: I,
                    onClick: N ? void 0 : R,
                    selectedIds: u,
                    onSelect: H,
                    readOnly: !y,
                    rowHeight: B,
                    scrollToId: w,
                    onKeyboardSelect: F,
                    dropLayerTransform: Ge,
                    lastFocusedNodeObject: U,
                    outerRef: function(e) {
                        $.current = e
                    },
                    lastSyncTimestampRef: L
                }), o && i.createElement(h.Spinner, null), !o && r && 0 === n.length && i.createElement(Ze, null, i.createElement("div", null, s && i.createElement(z.Icon, {
                    icon: s
                }), i.createElement("div", null, r)))))));

                function Q(e) {
                    const t = (0, se.getSymbolFromList)(e, n);
                    t && !(0, se.isValidSeparatorItem)(t) && (H([t]), V({
                        id: t
                    }))
                }

                function te() {
                    Q(ee.linking.symbol.value())
                }
            }));
            var $e = n(97265),
                Ye = n(2054),
                je = n(51049),
                Je = n(3736),
                Qe = n(92185);
            const et = (0, s.connect)((function() {
                const e = [],
                    t = (t, n) => {
                        const s = (0, X.getCurrentViewableListByWidgetId)(t, n);
                        return null === s || "hot" === s.type ? e : s.symbols
                    };
                return (e, n) => ({
                    symbols: t(e, n.widgetId)
                })
            }), (function(e) {
                return (0, o.bindActionCreators)({
                    reorderSymbols: S.reorderSymbolsThunk,
                    removeSelectedSymbols: S.removeSelectedSymbolsThunk,
                    markSymbol: S.markSymbolsThunk,
                    selectAllSymbols: _.selectAllSymbols
                }, e)
            }))((function(e) {
                const {
                    symbols: t,
                    reorderSymbols: n,
                    widgetId: s,
                    removeSelectedSymbols: o,
                    markSymbol: c,
                    selectAllSymbols: u,
                    viewState: d
                } = e, h = (0, $e.useWatchedValueReadonly)({
                    watchedValue: Ye.watchedTheme
                }) === je.StdTheme.Dark ? Je : Qe;
                return i.createElement(Ke, {
                    widgetId: s,
                    onMove: function(e) {
                        n(s, e[l.ROOT_ID].children)
                    },
                    onDrop: function(e) {
                        const {
                            detail: {
                                nodes: t
                            }
                        } = e;
                        t.length > 1 ? (0, pe.trackEvent)("Watchlist", "Multi select", "Drag") : (0, pe.trackEvent)("Watchlist", "Drag")
                    },
                    symbols: t,
                    onKeyDown: function(e) {
                        const t = (0, a.hashFromEvent)(e);
                        46 !== t && 8 !== t || (e.preventDefault(), o(s));
                        t === a.Modifiers.Alt + 13 && (e.preventDefault(), window.runOrSignIn(() => c(s, void 0, void 0, !0), {
                            source: "Set symbol color"
                        }), (0, pe.trackEvent)("Watchlist", "Alt+Enter"));
                        t === a.Modifiers.Mod + 65 && (e.preventDefault(), u(s), (0, pe.trackEvent)("Watchlist", "Ctrl+A"));
                        27 === t && (0, pe.trackEvent)("Watchlist", "Esc")
                    },
                    noSymbolsPlaceholder: (0, r.t)("Hmmm, seems that you didn’t have any symbols in watchlist. You can add symbol above."),
                    icon: h,
                    viewState: d
                })
            }))
        },
        56022: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                Header: () => Pe
            });
            var s = n(83243),
                o = n(79049),
                i = n(59496),
                r = n(97754),
                l = n.n(r),
                a = n(88537),
                c = n(25177),
                u = n(6474),
                d = n(92063),
                h = n(53055);

            function m(e, t, n) {
                (0, i.useRef)(null);
                (0, i.useEffect)(() => () => {
                    0
                }, [e.current, t, n])
            }
            var p = n(72535),
                g = n(32133),
                f = n(35842),
                v = n(93173),
                b = n(98171),
                _ = n(72621),
                y = n(96049),
                S = n(69283),
                w = n(20369);
            const x = (0, v.mergeThemes)(d.DEFAULT_POPUP_MENU_ITEM_THEME, S),
                E = (0, v.mergeThemes)(d.DEFAULT_POPUP_MENU_ITEM_THEME, w);
            var k = n(7898),
                C = n(1373),
                T = n(63940);
            const I = (0, o.connect)(null, {
                removeWatchList: function(e) {
                    return async (t, n) => {
                        const s = n(); {
                            const n = (0, a.ensureNotNull)((0, C.getCustomListById)(s, e));
                            await t((0, T.removeWatchlistThunk)(null, n))
                        }
                    }
                },
                selectWatchList: k.selectSymbolListThunk
            })((function(e) {
                const {
                    watchList: t,
                    selectWatchList: n,
                    removeWatchList: s,
                    hideRemoveButton: o,
                    isActive: r,
                    isSmallSize: u,
                    onSelect: v
                } = e, {
                    size: S
                } = (0, i.useContext)(f.SizeContext), {
                    color: w = null
                } = t, k = t.symbols.filter(e => !(0, b.isSeparatorItem)(e)).length, C = (0, i.useRef)(null), T = !o && null === w && !r;
                m(C, w, y.flag);
                let I = t.name;
                return I || (I = (0, c.t)("Watchlist")), i.createElement(d.PopupMenuItem, {
                    key: t.id,
                    theme: u ? E : x,
                    className: l()(y.item, r && y.active, 1 === S && y.small, !T && y.countVisible),
                    label: i.createElement("div", null, i.createElement("span", {
                        className: y.title,
                        ref: C
                    }, I), u && i.createElement("span", {
                        className: y.count
                    }, (0, c.t)("{count} symbol", {
                        plural: "{count} symbols",
                        count: k
                    }))),
                    toolbox: i.createElement(i.Fragment, null, T && i.createElement(_.RemoveButton, {
                        className: l()(y.removeButton, y.toolboxItem, p.touch && y.touch, u && y.small),
                        isActive: r,
                        onClick: function() {
                            const e = t.name || getColoredListTitle((0, a.ensureDefined)(t.color)),
                                n = (0, c.t)("Do you really want to delete Watchlist '{name}' ?").format({
                                    name: e
                                });
                            (0, h.showConfirm)({
                                text: n,
                                onConfirm: async ({
                                    dialogClose: e
                                }) => {
                                    await s(t.id), e()
                                }
                            }), (0, g.trackEvent)("Watchlist", "Popup menu", "Remove list")
                        }
                    }), i.createElement("span", {
                        className: l()(y.toolboxCount, y.toolboxItem, (u || p.touch) && y.touch)
                    }, k)),
                    onClick: function() {
                        var e;
                        r || (n(null, null !== (e = t.color) && void 0 !== e ? e : t.id), null == v || v(), (0, g.trackEvent)("Watchlist", "Popup menu", "Change active list"))
                    }
                })
            }));
            var M = n(17850),
                D = n(30553),
                N = n(21638),
                L = n(23506);

            function P(e) {
                const {
                    isLoading: t,
                    list: n,
                    current: s,
                    isSmallSize: o,
                    isReadonly: r,
                    onSelect: l
                } = e, a = (0, i.useContext)(D.MenuContext);
                (0, i.useEffect)(() => {
                    a && a.update()
                }, [n]);
                const c = [],
                    u = [];
                for (const e of n) c.push(e);
                c.sort(L.sortComparator);
                const d = [
                    [], c
                ];
                return u.length && d.push(u), i.createElement(i.Fragment, null, t && i.createElement(N.ToolWidgetMenuSpinner, null), !t && d.map((e, t, n) => e.length > 0 && i.createElement(i.Fragment, {
                    key: t
                }, e.map(e => i.createElement(I, {
                    key: e.id,
                    watchList: e,
                    isActive: null !== s && s.id === e.id,
                    hideRemoveButton: 1 === c.length || r || !1,
                    isSmallSize: o,
                    onSelect: l
                })), t !== n.length - 1 && 0 !== e.length && i.createElement(M.PopupMenuSeparator, null))))
            }
            var W = n(34816),
                A = n(25362);
            const B = (0, v.mergeThemes)(W.DEFAULT_TOOL_WIDGET_MENU_THEME, {
                button: A.button,
                hover: A.hover,
                isOpened: A.isOpened
            });

            function R(e) {
                const {
                    className: t,
                    content: n,
                    ...s
                } = e;
                return i.createElement(W.ToolWidgetMenu, { ...s,
                    theme: B,
                    className: l()(t),
                    content: i.createElement("span", {
                        className: l()(A.inner)
                    }, n)
                })
            }
            var F = n(28466),
                H = n(54936),
                U = n(12777),
                z = n(80185),
                O = n(38031);

            function V(e) {
                const {
                    name: t,
                    maxLength: n,
                    onSubmit: s,
                    onClose: o,
                    isRenaming: l,
                    children: a,
                    inputClassName: c,
                    size: u
                } = e, [d, h] = (0, i.useState)(t), m = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    h(t)
                }, [t]), (0, i.useEffect)(() => {
                    l && null !== m.current && (m.current.focus(), m.current.setSelectionRange(0, d.length))
                }, [l]), l ? i.createElement(H.InputControl, {
                    value: d,
                    onChange: function(e) {
                        h(e.currentTarget.value)
                    },
                    onClick: U.preventDefault,
                    className: r(O.renameInput),
                    inputClassName: c,
                    onKeyDown: function(e) {
                        27 === (0, z.hashFromEvent)(e) ? p() : 13 === (0, z.hashFromEvent)(e) && g()
                    },
                    reference: function(e) {
                        m.current = e
                    },
                    onBlur: g,
                    onDragStart: function(e) {
                        e.preventDefault(), e.stopPropagation()
                    },
                    size: u,
                    maxLength: n,
                    draggable: !0,
                    stretch: !0
                }) : a;

                function p() {
                    h(t), o()
                }

                function g() {
                    "" !== d ? s(d) : p()
                }
            }
            var q = n(1227),
                G = n(82527),
                Z = n(90410),
                X = n(18833),
                K = n(5710),
                $ = n(13060);

            function Y(e) {
                const {
                    targetSymbol: t,
                    store: n,
                    children: s,
                    handleTargetSymbolRemoved: r
                } = e, [l, a] = (0, i.useState)(null), [c, u] = (0, i.useState)(t), [d, h] = (0, i.useState)(null), m = (0, i.useRef)(null), p = (0, i.useMemo)(() => ({
                    selectedAction: l,
                    setSelectedAction: e => a(e),
                    isSpreadOrMultipleMode: j,
                    addAfter: c,
                    clearTargetSymbol: g,
                    highlighted: d,
                    highlight: f
                }), [l, a, c, d, h]);
                return (0, i.useEffect)(() => () => {
                    null !== m.current && clearTimeout(m.current)
                }, []), i.createElement(o.Provider, {
                    store: n
                }, i.createElement($.SymbolSearchWatchlistContext.Provider, {
                    value: p
                }, s));

                function g() {
                    u(void 0), r()
                }

                function f(e) {
                    h(e), null !== m.current && clearTimeout(m.current),
                        m.current = setTimeout(() => h(null), 500)
                }
            }

            function j(e, t) {
                const n = !!t.current && t.current.value.includes(",");
                return e || n
            }

            function J(e, t, n) {
                return s => i.createElement(Y, { ...s,
                    store: e,
                    targetSymbol: n,
                    handleTargetSymbolRemoved: t
                })
            }
            var Q = n(43717),
                ee = n(79359),
                te = n(21167);

            function ne(e, t) {
                const n = (0, C.getCurrentViewableListByWidgetId)(e, ee.WATCHLIST_WIDGET_ID),
                    {
                        fullSymbolName: s,
                        isOffset: o,
                        onExpandClick: i
                    } = t,
                    r = !1 === o && Boolean(i);
                return null === n || void 0 === s || r && !te.isOpenFirstContractEnabled ? {} : {
                    existInWatchlist: n.symbols.includes(s)
                }
            }

            function se(e) {
                return (0, s.bindActionCreators)({
                    addToWatchlist: k.addSymbolsThunk,
                    removeFromWatchlist: k.removeSymbolsThunk,
                    findInWatchlist: k.findInWatchlistThunk
                }, e)
            }

            function oe(e) {
                return (0, s.bindActionCreators)({
                    addToWatchlist: k.addSymbolsThunk,
                    removeFromWatchlist: k.removeSymbolsThunk,
                    findInWatchlist: k.findInWatchlistThunk
                }, e)
            }
            var ie = n(11411),
                re = n(44080),
                le = n(66171),
                ae = n(72571),
                ce = n(2153);

            function ue(e) {
                const {
                    icon: t,
                    title: n,
                    className: s,
                    iconClassName: o,
                    a11yLabel: l
                } = e, a = Boolean(t);
                return i.createElement("kbd", {
                    className: r(ce.button, a && ce.withIcon, s)
                }, a ? i.createElement(i.Fragment, null, i.createElement(ae.Icon, {
                    "aria-hidden": !0,
                    className: r(ce.buttonIcon, o),
                    icon: t
                }), i.createElement("span", {
                    className: ce["a11y-text"]
                }, n)) : l ? i.createElement(i.Fragment, null, i.createElement("span", {
                    "aria-hidden": !0
                }, n), i.createElement("span", {
                    className: ce["a11y-text"]
                }, l)) : n)
            }
            var de = n(23835),
                he = n(66415);

            function me(e) {
                const {
                    searchRef: t,
                    searchSpreads: n
                } = (0, a.ensureNotNull)((0, i.useContext)(re.SymbolSearchItemsDialogContext)), {
                    isSpreadOrMultipleMode: s
                } = (0, a.ensureNotNull)((0, i.useContext)($.SymbolSearchWatchlistContext)), o = s(n, t);
                return i.createElement(le.SymbolSearchDialogFooter, {
                    className: he.footer
                }, i.createElement("div", {
                    className: he.shortcuts
                }, o ? i.createElement("div", {
                    className: he.buttonGroup
                }, i.createElement(ue, {
                    title: "Enter",
                    className: he.button
                })) : i.createElement(i.Fragment, null, i.createElement("div", {
                    className: he.buttonGroup
                }, r(), "+", i.createElement(ue, {
                    title: (0, c.t)("Click"),
                    className: he.button
                })), (0, c.t)("or"), i.createElement("div", {
                    className: he.buttonGroup
                }, r(), "+", i.createElement(ue, {
                    title: "Enter",
                    className: he.button
                })))), i.createElement("div", {
                    className: he.text
                }, (0, c.t)("to add symbol and close dialog")));

                function r() {
                    return z.isMacKeyboard ? i.createElement(ue, {
                        title: "Shift",
                        icon: de,
                        className: l()(he.button, he.withIcon),
                        iconClassName: he.icon
                    }) : i.createElement(ue, {
                        title: "Shift",
                        className: he.button
                    })
                }
            }
            n(12015);
            let pe = null;
            var ge = n(90266);
            const fe = n(89368);

            function ve(e) {
                const {
                    leftSlot: t,
                    rightSlot: n,
                    withRightSlotSeparator: s,
                    theme: o = fe
                } = e;
                return i.createElement("div", {
                    className: o.container
                }, i.createElement("div", {
                    className: o.leftSlot
                }, t), i.createElement("div", {
                    className: r(o.rightSlot, s && o.rightSlotSeparator)
                }, n))
            }
            var be = n(52275),
                _e = n(58876),
                ye = n(56085),
                Se = n(3922),
                we = n(99923),
                xe = n(96427),
                Ee = n(57553),
                ke = n(34763),
                Ce = n(50032),
                Te = n(46832),
                Ie = n(37911);
            const Me = (0, v.mergeThemes)(fe, {
                    leftSlot: Ie.widgetbarWidgetHeaderLeftSlot,
                    rightSlot: Ie.widgetbarWidgetHeaderRightSlot
                }),
                De = (0,
                    v.mergeThemes)(d.DEFAULT_POPUP_MENU_ITEM_THEME, ke),
                Ne = (0, v.mergeThemes)(d.DEFAULT_POPUP_MENU_ITEM_THEME, Ce);
            var Le = n(19769);
            const Pe = (0, o.connect)((function() {
                const e = (e, t) => {
                        const n = (0, C.getCurrentViewableListByWidgetId)(e, t);
                        return null === n ? null : "custom" === n.type ? {
                            id: n.id,
                            name: n.name,
                            description: n.description,
                            symbols: n.symbols,
                            shared: n.shared
                        } : null
                    },
                    t = e => {
                        const t = [];
                        return t.push(...(0, C.getCustomLists)(e)), t
                    };
                return (n, s) => {
                    const {
                        enableAddSymbolsByAnon: o,
                        shouldDisplaySymbolSearch: i,
                        isDeletable: r,
                        isLogoEnabled: l
                    } = (0, C.widgetOptionsSelector)(n, s.widgetId);
                    return {
                        isLoading: !(0, C.getIsReadyCustomLists)(n),
                        enableAddSymbolsByAnon: o,
                        shouldDisplaySymbolSearch: i,
                        isLogoEnabled: l,
                        list: t(n),
                        current: e(n, s.widgetId),
                        columns: (0, C.columnsSelector)(n, s.widgetId),
                        tickerType: (0, C.tickerTypeSelector)(n, s.widgetId),
                        isReadonly: !r
                    }
                }
            }), (function(e) {
                const t = {
                    createNewWatchList: k.userCreateWatchlistThunk,
                    saveListAs: k.saveListAsThunk,
                    renameWatchList: k.renameSymbolListThunk,
                    clearWatchList: k.clearSymbolListThunk,
                    getWatchLists: () => (0, T.getCustomWatchlistsThunk)(null),
                    addSymbols: k.addSymbolsThunk,
                    insertSymbolBefore: k.insertSymbolBeforeThunk,
                    scrollToSymbol: k.findInWatchlistThunk,
                    updateWidget: Le.updateWidget,
                    updateWidgetOptions: Le.updateWidgetOptions
                };
                return (0, s.bindActionCreators)(t, e)
            }))((function(e) {
                var t;
                const {
                    isLoading: n,
                    list: s,
                    current: l,
                    getWatchLists: v,
                    createNewWatchList: b,
                    saveListAs: _,
                    enableAddSymbolsByAnon: y,
                    shouldDisplaySymbolSearch: S,
                    renameWatchList: w,
                    clearWatchList: x,
                    addSymbols: E,
                    insertSymbolBefore: k,
                    widgetId: C,
                    isReadonly: T,
                    scrollToSymbol: I,
                    shareList: D,
                    isLogoEnabled: N
                } = e, {
                    size: L
                } = (0, i.useContext)(f.SizeContext), W = (0, i.useContext)(F.CloseDelegateContext), {
                    setHideClose: A
                } = (0, i.useContext)(Z.DialogHeaderContext), B = (0, i.useRef)(null), H = (0, i.useRef)(null), [U, z] = (0, i.useState)(!1), O = (0, i.useRef)([]), $ = (0, i.useRef)(void 0), Y = (0, i.useRef)(null);
                Y.current = function() {
                    const e = O.current;
                    O.current = [], $.current = void 0, !1;
                    y ? We(e) : (0, ge.runOrSignIn)(() => We(e), {
                        source: "add symbol to watchlist"
                    })
                };
                const [j, ee] = (0, i.useState)(!1);
                m(B, null !== (t = null == l ? void 0 : l.color) && void 0 !== t ? t : null, Ie.flag);
                const te = function() {
                        const e = (0, c.t)("Watchlist");
                        if (!l) return e;
                        0;
                        return l.name || e
                    }(),
                    re = !((0, q.onWidget)() || T && 1 === s.length),
                    le = 1 === L,
                    ae = le ? Ne : De;
                return (0, i.useRef)(null), (0, i.useRef)(null), i.createElement("div", {
                    className: r(Ie.container, le && Ie.mobile),
                    onClick: function() {
                        j || le || W.fire()
                    }
                }, i.createElement(V, {
                    name: te,
                    isRenaming: U,
                    onSubmit: function(e) {
                        fe(!1), null !== l && w(l.id, e)
                    },
                    onClose: function() {
                        fe(!1)
                    },
                    maxLength: 128
                }, i.createElement(ve, {
                    leftSlot: re ? i.createElement(R, {
                        className: r(le && Ie.mobileMenu),
                        onOpen: v,
                        menuClassName: Ie.watchlistMenu,
                        content: i.createElement("span", {
                            className: Ie.titleRow
                        }, te, i.createElement("span", {
                            ref: B
                        })),
                        isDrawer: le,
                        "data-name": "watchlists-button"
                    }, !T && i.createElement(i.Fragment, null, i.createElement(d.PopupMenuItem, {
                        key: "new",
                        theme: ae,
                        icon: _e,
                        label: (0, X.appendEllipsis)((0, c.t)("Create new list")),
                        onClick: function() {
                            W.fire(), Le(() => b(null), "new"), Ae("Create new list")
                        }
                    }), G.enabled("watchlist_import_export") && !1, Be(), i.createElement(M.PopupMenuSeparator, null)), i.createElement(P, {
                        isLoading: n,
                        list: s,
                        current: l,
                        isSmallSize: le,
                        isReadonly: T,
                        onSelect: le ? () => W.fire() : void 0
                    })) : i.createElement("div", {
                        className: Ie.title
                    }, (0, c.t)("Watchlist")),
                    rightSlot: S && !T && i.createElement("div", {
                        className: Ie.buttonWrap
                    }, i.createElement(K.ToolWidgetIconButton, {
                        title: (0, c.t)("Add symbol"),
                        className: Ie.headerButton,
                        icon: Te,
                        onClick: function() {
                            (function(e) {
                                const {
                                    fullscreen: t,
                                    onSearchComplete: n,
                                    targetSymbol: s
                                } = e;
                                let r = !1;
                                const l = {
                                        dialogTitle: (0, c.t)("Add symbol"),
                                        fullscreen: t,
                                        onSearchComplete: e => r ? n(e) : n(e, s)
                                    },
                                    u = () => r = !0;
                                (0, Q.initSymbolListService)().then(e => {
                                    const t = pe = (0, ie.loadNewSymbolSearch)().then(n => {
                                        if (t !== pe) return;
                                        const {
                                            showSymbolSearchItemsDialog: r,
                                            Components: d
                                        } = n;
                                        var h, m;
                                        r({ ...l,
                                            wrapper: J(e.store, u, s),
                                            dialog: (m = (0, a.ensureNotNull)(d.SymbolSearchWatchlistDialog), (0, o.connect)(null, oe)(m)),
                                            contentItem: (h = (0, a.ensureNotNull)(d.SymbolSearchWatchlistDialogContentItem), (0, o.connect)(ne, se)(h)),
                                            placeholder: (0, c.t)("Search"),
                                            footer: p.mobiletouch ? void 0 : i.createElement(me)
                                        })
                                    })
                                })
                            })({
                                fullscreen: le,
                                onSearchComplete: e => {
                                    (0, ge.runOrSignIn)(() => {
                                        for (const t of e) Pe(t.symbol)
                                    }, {
                                        source: "add symbol to watchlist"
                                    })
                                }
                            }), (0, g.trackEvent)("GUI", "SS", "watchlist")
                        },
                        "data-name": "add-symbol-button",
                        "data-role": "button",
                        isDisabled: !1
                    }), !1, !1),
                    withRightSlotSeparator: le,
                    theme: Me
                })), G.enabled("watchlist_import_export") && i.createElement("form", {
                    className: Ie.hidden
                }, i.createElement("input", {
                    accept: "text/plain",
                    type: "file",
                    ref: function(e) {
                        G.enabled("watchlist_import_export") && (H.current = e)
                    },
                    onChange: function(e) {
                        if (G.enabled("watchlist_import_export")) {
                            const t = (0, a.ensureNotNull)(e.target.files)[0];
                            if (!t) return void ce(H.current);
                            const n = t.size / 1024,
                                s = 250;
                            if (n > s) return ce(H.current), void(0, h.showWarning)({
                                title: (0, c.t)("File limit exceeded"),
                                text: (0, c.t)("This file is too big. Max size is {fileLimit} KB", {
                                    replace: {
                                        fileLimit: String(s)
                                    }
                                })
                            });
                            const o = new FileReader;
                            ce(H.current), o.onload = () => {
                                (0, u.isImportDataValid)(o.result) ? b(null, {
                                    name: t.name.replace(/^(.+)\..+$/, "$1"),
                                    symbols: String(o.result).toUpperCase().split(/[\t\r\n,]+/).filter(Boolean)
                                }): (0, h.showWarning)({
                                    title: (0, c.t)("Invalid data format"),
                                    text: (0, c.t)('File contains incorrectly formatted data. Please correct the format and try again. Examples: "NYSE:GE,NYSE:F,NASDAQ:MSFT" or "F,GE,MSFT"')
                                })
                            }, o.readAsText(t)
                        }
                    }
                })));

                function ce(e) {
                    e && (e.value = "")
                }

                function ue() {
                    function e() {
                        (0, a.ensureNotNull)(H.current).click()
                    }
                    G.enabled("watchlist_import_export") && e()
                }

                function de() {
                    function e() {
                        const {
                            name: e,
                            color: t,
                            symbols: n
                        } = (0, a.ensureNotNull)(l);
                        ! function(e, t) {
                            (0, be.saveTextFile)(e + ".txt", t.join(","))
                        }(e || t || "watchlist", n)
                    }
                    G.enabled("watchlist_import_export") && e()
                }

                function he() {
                    null !== l && ((0, h.showConfirm)({
                        text: (0, c.t)("Do you really want to clear all symbols?"),
                        onConfirm: ({
                            dialogClose: e
                        }) => {
                            x(l.id), e()
                        }
                    }), Ae("Clear list"))
                }

                function fe(e) {
                    z(e), A(e)
                }

                function ke() {
                    (() => {
                        fe(!0)
                    })(), Ae("Rename")
                }

                function Ce() {
                    Le(() => _(e.widgetId, (0, a.ensureNotNull)(l).symbols), "saveAs"), Ae("Make a copy")
                }

                function Le(e, t) {
                    e()
                }

                function Pe(e) {
                    O.current.push(e), $.current || ($.current = setTimeout(() => {
                        null !== Y.current && Y.current()
                    }, 0))
                }

                function We(e) {
                    E(C, Array.from(new Set(e)))
                }

                function Ae(e) {
                    (0, g.trackEvent)("Watchlist", "Popup menu", e)
                }

                function Be() {
                    return null === l ? null : i.createElement(i.Fragment, null, !1, i.createElement(d.PopupMenuItem, {
                        key: "copy",
                        theme: ae,
                        icon: ye,
                        label: (0, X.appendEllipsis)((0, c.t)("Make a copy")),
                        onClick: Ce
                    }), i.createElement(d.PopupMenuItem, {
                        key: "rename",
                        theme: ae,
                        icon: Se,
                        label: (0, c.t)("Rename"),
                        onClick: ke,
                        isDisabled: !1
                    }), G.enabled("watchlist_import_export") && !le && i.createElement(i.Fragment, null, i.createElement(d.PopupMenuItem, {
                        key: "import",
                        theme: De,
                        icon: we,
                        label: (0, X.appendEllipsis)((0, c.t)("Import list")),
                        onClick: ue
                    }), i.createElement(d.PopupMenuItem, {
                        key: "export",
                        theme: De,
                        icon: xe,
                        label: (0, c.t)("Export list"),
                        onClick: de
                    })), i.createElement(d.PopupMenuItem, {
                        key: "clear",
                        theme: ae,
                        icon: Ee,
                        label: (0, c.t)("Clear list"),
                        onClick: he
                    }), !1)
                }
            }))
        },
        13060: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchWatchlistContext: () => s
            });
            const s = n(59496).createContext(null)
        },
        90266: (e, t, n) => {
            "use strict";
            n.d(t, {
                runOrSignIn: () => s
            });

            function s(e, t) {
                e()
            }
        },
        21258: (e, t, n) => {
            "use strict";
            n.d(t, {
                hoverMouseEventFilter: () => i,
                useAccurateHover: () => r,
                useHover: () => o
            });
            var s = n(59496);

            function o() {
                const [e, t] = (0, s.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        i(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        i(e) && t(!1)
                    }
                }]
            }

            function i(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function r(e) {
                const [t, n] = (0, s.useState)(!1);
                return (0, s.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const s = e.current.contains(t.target);
                        n(s)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        74140: (e, t, n) => {
            "use strict";
            n.d(t, {
                useResizeObserver: () => i
            });
            var s = n(59496),
                o = n(59255);

            function i(e, t = []) {
                const n = (0, s.useRef)(null),
                    i = (0, s.useRef)(null),
                    r = (0, s.useRef)(e);
                r.current = e;
                const l = (0, s.useCallback)(e => {
                    n.current = e, null !== i.current && (i.current.disconnect(), null !== e && i.current.observe(e))
                }, [n, i]);
                return (0, s.useEffect)(() => (i.current = new o.default((e, t) => {
                    r.current(e, t)
                }), n.current && l(n.current), () => {
                    var e;
                    null === (e = i.current) || void 0 === e || e.disconnect()
                }), [n, ...t]), l
            }
        },
        17850: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenuSeparator: () => l
            });
            var s = n(59496),
                o = n(97754),
                i = n.n(o),
                r = n(524);

            function l(e) {
                const {
                    size: t = "normal",
                    className: n
                } = e;
                return s.createElement("div", {
                    className: i()(r.separator, "small" === t && r.small, "normal" === t && r.normal, "large" === t && r.large, n)
                })
            }
        },
        72621: (e, t, n) => {
            "use strict";
            n.d(t, {
                RemoveButton: () => u
            });
            var s = n(25177),
                o = n(59496),
                i = n(97754),
                r = n(72571),
                l = n(72351),
                a = n(73432);
            const c = {
                remove: (0, s.t)("Remove")
            };

            function u(e) {
                const {
                    className: t,
                    isActive: n,
                    onClick: s,
                    onMouseDown: u,
                    title: d,
                    hidden: h,
                    "data-name": m = "remove-button",
                    ...p
                } = e;
                return o.createElement(r.Icon, { ...p,
                    "data-name": m,
                    className: i(a.button, "apply-common-tooltip", n && a.active, h && a.hidden, t),
                    icon: l,
                    onClick: s,
                    onMouseDown: u,
                    title: d || c.remove
                })
            }
        },
        32455: (e, t, n) => {
            "use strict";
            n.d(t, {
                Spinner: () => r
            });
            var s = n(59496),
                o = n(97754),
                i = n(63654);
            n(24780);

            function r(e) {
                const t = o(e.className, "tv-spinner", "tv-spinner--shown", "tv-spinner--size_" + i.spinnerSizeMap[e.size || i.DEFAULT_SIZE]);
                return s.createElement("div", {
                    className: t,
                    style: e.style,
                    role: "progressbar"
                })
            }
        },
        93173: (e, t, n) => {
            "use strict";

            function s(e, t, n = {}) {
                const s = Object.assign({}, t);
                for (const o of Object.keys(t)) {
                    const i = n[o] || o;
                    i in e && (s[o] = [e[i], t[o]].join(" "))
                }
                return s
            }

            function o(e, t, n = {}) {
                return Object.assign({}, e, s(e, t, n))
            }
            n.d(t, {
                weakComposeClasses: () => s,
                mergeThemes: () => o
            })
        },
        57369: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 9" width="11" height="9" fill="none"><path stroke-width="2" d="M0.999878 4L3.99988 7L9.99988 1"/></svg>'
        },
        23835: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M9 4.5l4.39 3.61a.5.5 0 0 1-.32.89h-1.18v4.5H6.11V9H4.93a.5.5 0 0 1-.32-.89L9 4.5z"/></svg>'
        },
        46832: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" d="M7 13h7V6h1v7h7v1h-7v7h-1v-7H7v-1z"/></svg>'
        },
        42701: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 7 9" width="7" height="9" fill="none"><path stroke="currentColor" d="M6 5L3.5 7.5L1 5M3.5 7.5V0"/></svg>'
        },
        26532: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 7 9" width="7" height="9" fill="none"><path stroke="currentColor" d="M6 4L3.5 1.5L1 4M3.5 9V2"/></svg>'
        },
        57553: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 16.5c1 3 7 7 11 7 2-4 2-8.5 2-8.5s-1-3.5-2-4-4.5.5-4.5.5-3 3.5-6.5 5z"/><path stroke="currentColor" d="M15.5 11l3-6s.5-1 1.5-.5.5 1.5.5 1.5l-3 6M12 11.5l6.5 3.5M7.5 19c2-.5 4-2.5 4-2.5m0 5.5c2-1 3-3.5 3-3.5"/></svg>'
        },
        96427: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M6.5 16v4.5a1 1 0 001 1h14a1 1 0 001-1V16M14.5 18V5.5m-4 4l4-4l4 4"/></svg>'
        },
        99923: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M6.5 16v4.5a1 1 0 001 1h14a1 1 0 001-1V16M14.5 5V17m-4-3.5l4 4l4-4"/></svg>'
        },
        37988: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="11" height="20" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M5.5 14a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm0-5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM7 5.5a1.5 1.5 0 1 0-3 0 1.5 1.5 0 0 0 3 0z"/></svg>'
        },
        99774: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none"><circle stroke="currentColor" cx="6" cy="6" r="5.5"/><path fill="currentColor" d="M4.5 8.523V2.8h.928v4.826H8.5v.897h-4z"/></svg>'
        },
        52203: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none"><circle stroke="#F44336" cx="6" cy="6" r="5.5"/><path fill="#F44336" d="M4.267 8.636l.31-.73c.159.11.355.2.59.274.238.071.45.107.638.107.33 0 .597-.084.798-.253a.806.806 0 0 0 .302-.646.945.945 0 0 0-.17-.542c-.11-.17-.391-.353-.841-.551l-.501-.218c-.425-.185-.722-.404-.892-.657-.167-.254-.251-.559-.251-.915 0-.433.164-.792.493-1.077C5.07 3.143 5.493 3 6.008 3c.689 0 1.167.104 1.436.313l-.25.689a2.019 2.019 0 0 0-.519-.222 2.21 2.21 0 0 0-.645-.107c-.29 0-.517.077-.684.23a.77.77 0 0 0-.246.59c0 .148.03.283.089.404.06.121.141.223.246.305.108.082.326.197.654.345l.51.225c.425.188.722.412.892.674.173.258.259.588.259.99 0 .435-.188.805-.565 1.109C6.811 8.848 6.31 9 5.681 9c-.552 0-1.023-.121-1.414-.364z"/></svg>'
        },
        3736: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120" fill="none"><path fill="none" d="M0 0h120v120H0V0z"/><g clip-path="url(#a3hxvgxzo)"><path fill="none" d="M10 10h101.05v101.05H10z"/><path fill="#2A2E39" fill-rule="evenodd" clip-rule="evenodd" d="M55.47 95.26a8.1 8.1 0 0 1 6.15.04 26.05 26.05 0 0 0 31.23-8.79A26 26 0 1 0 58.9 48.7a5.54 5.54 0 0 1-4.54.42c-2.9-1-5.91-1.43-8.9-1.32a.09.09 0 0 1-.07-.14A16.29 16.29 0 0 0 41.7 24.9a16.29 16.29 0 0 0-22.73 3.7 16.28 16.28 0 0 0 5.91 24.1c1.82.92 2.64 3.66 1.45 5.3a24.63 24.63 0 0 0 5.55 34.4 24.58 24.58 0 0 0 23.58 2.85z"/><rect width="38.5" height="12.5" fill="#1E222D" stroke="#B2B5BE" stroke-width="1.5" rx="2.25" x="21.75" y="53.75"/><circle stroke="#B2B5BE" stroke-linecap="round" stroke-width="1.5" cx="28.52" cy="60" r="3"/><path stroke="#B2B5BE" stroke-linecap="round" stroke-width="1.5" d="M35.25 59.75h5.22M49.4 58.75h5.22M47.17 62.25h7.45"/><rect width="38.5" height="12.5" fill="#1E222D" stroke="#B2B5BE" stroke-width="1.5" rx="2.25" x="21.75" y="73.75"/><circle stroke="#B2B5BE" stroke-linecap="round" stroke-width="1.5" cx="28.52" cy="80" r="3"/><path stroke="#B2B5BE" stroke-linecap="round" stroke-width="1.5" d="M35.25 79.75h5.22M49.4 78.75h5.22M47.17 82.25h7.45"/><path fill="#1E222D" stroke="#B2B5BE" stroke-width="1.5" d="M43.75 29c0-2.35 1.9-4.25 4.25-4.25h34c2.35 0 4.25 1.9 4.25 4.25v60c0 2.35-1.9 4.25-4.25 4.25H48A4.25 4.25 0 0 1 43.75 89V29z"/><rect width="38.5" height="12.5" fill="#1E222D" stroke="#B2B5BE" stroke-width="1.5" rx="2.25" x="32.75" y="33.75"/><circle stroke="#B2B5BE" stroke-linecap="round" stroke-width="1.5" cx="39.52" cy="40" r="3"/><path stroke="#B2B5BE" stroke-linecap="round" stroke-width="1.5" d="M45.25 39.75h5.22M54.5 39.75h3.71M62.5 39.75h4.12M27.63 38.25h-7M27.63 41.25h-4"/><circle fill="#1848CC" cx="64.75" cy="61.75" r="10.75"/><path fill="#D1D4DC" d="M65.48 56.79a.75.75 0 0 0-1.5 0h1.5zm-1.5 10.1a.75.75 0 0 0 1.5 0h-1.5zm0-10.1v10.1h1.5V56.8h-1.5z"/><path fill="#D1D4DC" d="M59.68 61.09a.75.75 0 0 0 0 1.5v-1.5zm10.1 1.5a.75.75 0 0 0 0-1.5v1.5zm-10.1 0h10.1v-1.5h-10.1v1.5z"/></g><defs><clipPath id="a3hxvgxzo"><path fill="#fff" d="M10 10h101.05v101.05H10z"/></clipPath></defs></svg>'
        },
        92185: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120" fill="none"><path fill="#fff" d="M0 0h120v120H0V0z"/><g clip-path="url(#aercrx3gr)"><path fill="#fff" d="M10 10h101.05v101.05H10z"/><path fill="#F0F3FA" fill-rule="evenodd" clip-rule="evenodd" d="M55.47 95.26a8.1 8.1 0 0 1 6.15.04 26.05 26.05 0 0 0 31.23-8.79A26 26 0 1 0 58.9 48.7a5.54 5.54 0 0 1-4.54.42c-2.9-1-5.91-1.43-8.9-1.32a.09.09 0 0 1-.07-.14A16.29 16.29 0 0 0 41.7 24.9a16.29 16.29 0 0 0-22.73 3.7 16.28 16.28 0 0 0 5.91 24.1c1.82.92 2.64 3.66 1.45 5.3a24.63 24.63 0 0 0 5.55 34.4 24.58 24.58 0 0 0 23.58 2.85z"/><rect width="38.5" height="12.5" fill="#fff" stroke="#1E222D" stroke-width="1.5" rx="2.25" x="21.75" y="53.75"/><circle stroke="#1E222D" stroke-linecap="round" stroke-width="1.5" cx="28.52" cy="60" r="3"/><path stroke="#1E222D" stroke-linecap="round" stroke-width="1.5" d="M35.25 59.75h5.22M49.4 58.75h5.22M47.17 62.25h7.45"/><rect width="38.5" height="12.5" fill="#fff" stroke="#1E222D" stroke-width="1.5" rx="2.25" x="21.75" y="73.75"/><circle stroke="#1E222D" stroke-linecap="round" stroke-width="1.5" cx="28.52" cy="80" r="3"/><path stroke="#1E222D" stroke-linecap="round" stroke-width="1.5" d="M35.25 79.75h5.22M49.4 78.75h5.22M47.17 82.25h7.45"/><path fill="#fff" stroke="#1E222D" stroke-width="1.5" d="M43.75 29c0-2.35 1.9-4.25 4.25-4.25h34c2.35 0 4.25 1.9 4.25 4.25v60c0 2.35-1.9 4.25-4.25 4.25H48A4.25 4.25 0 0 1 43.75 89V29z"/><rect width="38.5" height="12.5" fill="#fff" stroke="#1E222D" stroke-width="1.5" rx="2.25" x="32.75" y="33.75"/><circle stroke="#1E222D" stroke-linecap="round" stroke-width="1.5" cx="39.52" cy="40" r="3"/><path stroke="#1E222D" stroke-linecap="round" stroke-width="1.5" d="M45.25 39.75h5.22M54.5 39.75h3.71M62.5 39.75h4.12M27.63 38.25h-7M27.63 41.25h-4"/><circle fill="#2962FF" cx="64.75" cy="61.75" r="10.75"/><path fill="#fff" d="M65.48 56.79a.75.75 0 0 0-1.5 0h1.5zm-1.5 10.1a.75.75 0 0 0 1.5 0h-1.5zm0-10.1v10.1h1.5V56.8h-1.5z"/><path fill="#fff" d="M59.68 61.09a.75.75 0 0 0 0 1.5v-1.5zm10.1 1.5a.75.75 0 0 0 0-1.5v1.5zm-10.1 0h10.1v-1.5h-10.1v1.5z"/></g><defs><clipPath id="aercrx3gr"><path fill="#fff" d="M10 10h101.05v101.05H10z"/></clipPath></defs></svg>'
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [6265], {
        54627: e => {
            e.exports = {
                switcher: "switcher-GT7Z98Io",
                "disable-cursor-pointer": "disable-cursor-pointer-GT7Z98Io",
                input: "input-GT7Z98Io",
                "thumb-wrapper": "thumb-wrapper-GT7Z98Io",
                "size-small": "size-small-GT7Z98Io",
                "size-large": "size-large-GT7Z98Io",
                "intent-default": "intent-default-GT7Z98Io",
                "disable-active-state-styles": "disable-active-state-styles-GT7Z98Io",
                "intent-select": "intent-select-GT7Z98Io",
                track: "track-GT7Z98Io",
                thumb: "thumb-GT7Z98Io"
            }
        },
        95707: e => {
            e.exports = {
                wrapper: "wrapper-IbP2mmCe",
                hovered: "hovered-IbP2mmCe",
                labelRow: "labelRow-IbP2mmCe",
                label: "label-IbP2mmCe",
                labelHint: "labelHint-IbP2mmCe",
                labelOn: "labelOn-IbP2mmCe"
            }
        },
        20959: e => {
            e.exports = {
                smallStyleControl: "smallStyleControl-tMebfShj",
                additionalSelect: "additionalSelect-tMebfShj",
                childRowContainer: "childRowContainer-tMebfShj",
                defaultSelect: "defaultSelect-tMebfShj",
                defaultSelectItem: "defaultSelectItem-tMebfShj",
                block: "block-tMebfShj",
                group: "group-tMebfShj",
                wrapGroup: "wrapGroup-tMebfShj",
                textMarkGraphicBlock: "textMarkGraphicBlock-tMebfShj",
                textMarkGraphicWrapGroup: "textMarkGraphicWrapGroup-tMebfShj"
            }
        },
        942: e => {
            e.exports = {
                scrollable: "scrollable-pm9AiChK"
            }
        },
        84662: e => {
            e.exports = {
                defaultsButtonText: "defaultsButtonText-4BZduqY4",
                defaultsButtonItem: "defaultsButtonItem-4BZduqY4",
                defaultsButtonIcon: "defaultsButtonIcon-4BZduqY4"
            }
        },
        85623: e => {
            e.exports = {
                themesButtonText: "themesButtonText-KBqedPzF",
                themesButtonIcon: "themesButtonIcon-KBqedPzF",
                defaultsButtonText: "defaultsButtonText-KBqedPzF",
                defaultsButtonItem: "defaultsButtonItem-KBqedPzF"
            }
        },
        47922: e => {
            e.exports = {
                slider: "slider-Q7h4o6oW",
                inner: "inner-Q7h4o6oW"
            }
        },
        42545: e => {
            e.exports = {
                scrollWrap: "scrollWrap-VabV7Fn8",
                tabsWrap: "tabsWrap-VabV7Fn8",
                tabs: "tabs-VabV7Fn8",
                withoutBorder: "withoutBorder-VabV7Fn8",
                tab: "tab-VabV7Fn8",
                withHover: "withHover-VabV7Fn8",
                headerBottomSeparator: "headerBottomSeparator-VabV7Fn8",
                fadeWithoutSlider: "fadeWithoutSlider-VabV7Fn8",
                withBadge: "withBadge-VabV7Fn8"
            }
        },
        41814: e => {
            e.exports = {
                wrap: "wrap-sfzcrPlH",
                wrapWithArrowsOuting: "wrapWithArrowsOuting-sfzcrPlH",
                wrapOverflow: "wrapOverflow-sfzcrPlH",
                scrollWrap: "scrollWrap-sfzcrPlH",
                noScrollBar: "noScrollBar-sfzcrPlH",
                icon: "icon-sfzcrPlH",
                scrollLeft: "scrollLeft-sfzcrPlH",
                scrollRight: "scrollRight-sfzcrPlH",
                isVisible: "isVisible-sfzcrPlH",
                iconWrap: "iconWrap-sfzcrPlH",
                fadeLeft: "fadeLeft-sfzcrPlH",
                fadeRight: "fadeRight-sfzcrPlH"
            }
        },
        37740: e => {
            e.exports = {
                tabs: "tabs-rKFlMYkc",
                tab: "tab-rKFlMYkc",
                noBorder: "noBorder-rKFlMYkc",
                disabled: "disabled-rKFlMYkc",
                active: "active-rKFlMYkc",
                defaultCursor: "defaultCursor-rKFlMYkc",
                slider: "slider-rKFlMYkc",
                content: "content-rKFlMYkc"
            }
        },
        45545: (e, t, l) => {
            "use strict";
            l.d(t, {
                DEFAULT_MENU_ITEM_SWITCHER_THEME: () => u,
                MenuItemSwitcher: () => m
            });
            var r = l(59496),
                n = l(97754),
                o = l.n(n);
            const s = (0, r.createContext)({
                enablePointerOnHover: !0,
                enableActiveStateStyles: !0
            });
            var i = l(54627),
                a = l.n(i);

            function c(e) {
                const t = (0, r.useContext)(s),
                    {
                        className: l,
                        intent: o = "default",
                        size: i = "small",
                        enablePointerOnHover: c = t.enablePointerOnHover,
                        enableActiveStateStyles: p = t.enableActiveStateStyles
                    } = e;
                return n(l, a().switcher, a()["size-" + i], a()["intent-" + o], !c && a()["disable-cursor-pointer"], !p && a()["disable-active-state-styles"])
            }

            function p(e) {
                const {
                    reference: t,
                    size: l,
                    intent: n,
                    ...o
                } = e;
                return r.createElement("div", {
                    className: c(e)
                }, r.createElement("input", { ...o,
                    type: "checkbox",
                    className: a().input,
                    ref: t
                }), r.createElement("div", {
                    className: a()["thumb-wrapper"]
                }, r.createElement("div", {
                    className: a().track
                }), r.createElement("div", {
                    className: a().thumb
                })))
            }
            var d = l(417),
                h = l(95707);
            const u = h;

            function m(e) {
                const {
                    className: t,
                    checked: l,
                    id: n,
                    label: s,
                    labelDescription: i,
                    value: a,
                    preventLabelHighlight: c,
                    reference: u,
                    switchReference: m,
                    theme: y = h,
                    disabled: g
                } = e, v = o()(y.label, l && !c && y.labelOn), b = o()(t, y.wrapper, l && y.wrapperWithOnLabel);
                return r.createElement("label", {
                    className: b,
                    htmlFor: n,
                    ref: u
                }, r.createElement("div", {
                    className: y.labelRow
                }, r.createElement("div", {
                    className: v
                }, s), i && r.createElement("div", {
                    className: y.labelHint
                }, i)), r.createElement(p, {
                    disabled: g,
                    className: y.switch,
                    reference: m,
                    checked: l,
                    onChange: function(t) {
                        const l = t.target.checked;
                        void 0 !== e.onChange && e.onChange(l)
                    },
                    value: a,
                    tabIndex: -1,
                    id: n,
                    ...(0, d.filterDataProps)(e)
                }))
            }
        },
        38658: (e, t, l) => {
            "use strict";
            l.r(t), l.d(t, {
                createPropertyPage: () => o
            });
            var r = l(94489),
                n = l.n(r);

            function o(e, t, l, r = null) {
                var o;
                const s = {
                    id: t,
                    title: l,
                    definitions: new(n())(e.definitions),
                    visible: null !== (o = e.visible) && void 0 !== o ? o : new(n())(!0).readonly()
                };
                return null !== r && (s.icon = r), s
            }
        },
        53913: (e, t, l) => {
            "use strict";
            l.r(t), l.d(t, {
                getIntervalsVisibilitiesPropertiesDefinitions: () => ce,
                getSelectionIntervalsVisibilitiesPropertiesDefinition: () => pe
            });
            var r = l(25177),
                n = l(18517),
                o = l(82527),
                s = l(1272),
                i = l(94489),
                a = l.n(i),
                c = l(2117),
                p = l(86137),
                d = l(25814);
            const h = new n.TranslatedString("change {title} visibility on ticks", (0, r.t)("change {title} visibility on ticks")),
                u = new n.TranslatedString("change {title} visibility on seconds", (0, r.t)("change {title} visibility on seconds")),
                m = new n.TranslatedString("change {title} seconds from", (0, r.t)("change {title} seconds from")),
                y = new n.TranslatedString("change {title} seconds to", (0, r.t)("change {title} seconds to")),
                g = new n.TranslatedString("change {title} visibility on minutes", (0, r.t)("change {title} visibility on minutes")),
                v = new n.TranslatedString("change {title} minutes from", (0, r.t)("change {title} minutes from")),
                b = new n.TranslatedString("change {title} minutes to", (0, r.t)("change {title} minutes to")),
                f = new n.TranslatedString("change {title} visibility on hours", (0, r.t)("change {title} visibility on hours")),
                w = new n.TranslatedString("change {title} hours from", (0, r.t)("change {title} hours from")),
                S = new n.TranslatedString("change {title} hours to", (0, r.t)("change {title} hours to")),
                C = new n.TranslatedString("change {title} visibility on days", (0, r.t)("change {title} visibility on days")),
                P = new n.TranslatedString("change {title} days from", (0, r.t)("change {title} days from")),
                T = new n.TranslatedString("change {title} days to", (0, r.t)("change {title} days to")),
                E = new n.TranslatedString("change {title} visibility on weeks", (0,
                    r.t)("change {title} visibility on weeks")),
                _ = new n.TranslatedString("change {title} weeks from", (0, r.t)("change {title} weeks from")),
                k = new n.TranslatedString("change {title} weeks to", (0, r.t)("change {title} weeks to")),
                L = new n.TranslatedString("change {title} visibility on months", (0, r.t)("change {title} visibility on months")),
                x = new n.TranslatedString("change {title} months from", (0, r.t)("change {title} months from")),
                M = new n.TranslatedString("change {title} months to", (0, r.t)("change {title} months to")),
                I = (new n.TranslatedString("change {title} visibility on ranges", (0, r.t)("change {title} visibility on ranges")), (0, r.t)("Ticks")),
                D = (0, r.t)("Seconds"),
                R = (0, r.t)("Minutes"),
                V = (0, r.t)("Hours"),
                N = (0, r.t)("Days"),
                B = (0, r.t)("Weeks"),
                A = (0, r.t)("Months"),
                W = ((0, r.t)("Ranges"), new n.TranslatedString("ticks", (0, r.t)("ticks"))),
                F = new n.TranslatedString("seconds", (0, r.t)("seconds")),
                z = new n.TranslatedString("seconds from", (0, r.t)("seconds from")),
                H = new n.TranslatedString("seconds to", (0, r.t)("seconds to")),
                O = new n.TranslatedString("minutes", (0, r.t)("minutes")),
                G = new n.TranslatedString("minutes from", (0, r.t)("minutes from")),
                U = new n.TranslatedString("minutes to", (0, r.t)("minutes to")),
                j = new n.TranslatedString("hours", (0, r.t)("hours")),
                Y = new n.TranslatedString("hours from", (0, r.t)("hours from")),
                K = new n.TranslatedString("hours to", (0, r.t)("hours to")),
                Z = new n.TranslatedString("days", (0, r.t)("days")),
                q = new n.TranslatedString("days from", (0, r.t)("days from")),
                Q = new n.TranslatedString("days to", (0, r.t)("days to")),
                X = new n.TranslatedString("weeks", (0, r.t)("weeks")),
                J = new n.TranslatedString("weeks from", (0, r.t)("weeks from")),
                $ = new n.TranslatedString("weeks to", (0, r.t)("weeks to")),
                ee = new n.TranslatedString("months", (0, r.t)("months")),
                te = new n.TranslatedString("months from", (0, r.t)("months from")),
                le = new n.TranslatedString("months to", (0, r.t)("months to")),
                re = (new n.TranslatedString("ranges", (0, r.t)("ranges")), [1, 59]),
                ne = [1, 59],
                oe = [1, 24],
                se = [1, 366],
                ie = [1, 52],
                ae = [1, 12];

            function ce(e, t, l) {
                const r = [];
                if (o.enabled("tick_resolution")) {
                    const n = (0, s.createCheckablePropertyDefinition)({
                        checked: (0, s.convertToDefinitionProperty)(e, t.ticks, h.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesTicks",
                        title: I
                    });
                    r.push(n)
                }
                if ((0, c.isSecondsEnabled)()) {
                    const n = (0, s.createRangePropertyDefinition)({
                        checked: (0, s.convertToDefinitionProperty)(e, t.seconds, u.format({
                            title: l
                        })),
                        from: (0, s.convertToDefinitionProperty)(e, t.secondsFrom, m.format({
                            title: l
                        })),
                        to: (0, s.convertToDefinitionProperty)(e, t.secondsTo, y.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesSecond",
                        title: D,
                        min: new(a())(re[0]),
                        max: new(a())(re[1])
                    });
                    r.push(n)
                }
                const n = (0, s.createRangePropertyDefinition)({
                        checked: (0, s.convertToDefinitionProperty)(e, t.minutes, g.format({
                            title: l
                        })),
                        from: (0, s.convertToDefinitionProperty)(e, t.minutesFrom, v.format({
                            title: l
                        })),
                        to: (0, s.convertToDefinitionProperty)(e, t.minutesTo, b.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesMinutes",
                        title: R,
                        min: new(a())(ne[0]),
                        max: new(a())(ne[1])
                    }),
                    i = (0, s.createRangePropertyDefinition)({
                        checked: (0,
                            s.convertToDefinitionProperty)(e, t.hours, f.format({
                            title: l
                        })),
                        from: (0, s.convertToDefinitionProperty)(e, t.hoursFrom, w.format({
                            title: l
                        })),
                        to: (0, s.convertToDefinitionProperty)(e, t.hoursTo, S.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesHours",
                        title: V,
                        min: new(a())(oe[0]),
                        max: new(a())(oe[1])
                    }),
                    p = (0, s.createRangePropertyDefinition)({
                        checked: (0, s.convertToDefinitionProperty)(e, t.days, C.format({
                            title: l
                        })),
                        from: (0, s.convertToDefinitionProperty)(e, t.daysFrom, P.format({
                            title: l
                        })),
                        to: (0, s.convertToDefinitionProperty)(e, t.daysTo, T.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesDays",
                        title: N,
                        min: new(a())(se[0]),
                        max: new(a())(se[1])
                    });
                r.push(n, i, p);
                const d = (0, s.createRangePropertyDefinition)({
                        checked: (0, s.convertToDefinitionProperty)(e, t.weeks, E.format({
                            title: l
                        })),
                        from: (0, s.convertToDefinitionProperty)(e, t.weeksFrom, _.format({
                            title: l
                        })),
                        to: (0, s.convertToDefinitionProperty)(e, t.weeksTo, k.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesWeeks",
                        title: B,
                        min: new(a())(ie[0]),
                        max: new(a())(ie[1])
                    }),
                    W = (0, s.createRangePropertyDefinition)({
                        checked: (0, s.convertToDefinitionProperty)(e, t.months, L.format({
                            title: l
                        })),
                        from: (0, s.convertToDefinitionProperty)(e, t.monthsFrom, x.format({
                            title: l
                        })),
                        to: (0, s.convertToDefinitionProperty)(e, t.monthsTo, M.format({
                            title: l
                        }))
                    }, {
                        id: "IntervalsVisibilitiesMonths",
                        title: A,
                        min: new(a())(ae[0]),
                        max: new(a())(ae[1])
                    });
                return r.push(d, W), {
                    definitions: r
                }
            }

            function pe(e, t) {
                const l = [];
                if (o.enabled("tick_resolution")) {
                    const r = (0, s.createCheckablePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.ticks), W, t)
                    }, {
                        id: "IntervalsVisibilitiesTicks",
                        title: I
                    });
                    l.push(r)
                }
                if ((0, c.isSecondsEnabled)()) {
                    const r = (0, s.createRangePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.seconds), F, t),
                        from: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.secondsFrom), z, t),
                        to: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.secondsTo), H, t)
                    }, {
                        id: "IntervalsVisibilitiesSecond",
                        title: D,
                        min: new(a())(re[0]),
                        max: new(a())(re[1])
                    });
                    l.push(r)
                }
                const r = (0, s.createRangePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.minutes), O, t),
                        from: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.minutesFrom), G, t),
                        to: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.minutesTo), U, t)
                    }, {
                        id: "IntervalsVisibilitiesMinutes",
                        title: R,
                        min: new(a())(ne[0]),
                        max: new(a())(ne[1])
                    }),
                    n = (0, s.createRangePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.hours), j, t),
                        from: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.hoursFrom), Y, t),
                        to: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.hoursTo), K, t)
                    }, {
                        id: "IntervalsVisibilitiesHours",
                        title: V,
                        min: new(a())(oe[0]),
                        max: new(a())(oe[1])
                    }),
                    i = (0, s.createRangePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.days), Z, t),
                        from: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.daysFrom), q, t),
                        to: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.daysTo), Q, t)
                    }, {
                        id: "IntervalsVisibilitiesDays",
                        title: N,
                        min: new(a())(se[0]),
                        max: new(a())(se[1])
                    });
                l.push(r, n, i);
                const h = (0, s.createRangePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.weeks), X, t),
                        from: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.weeksFrom), J, t),
                        to: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.weeksTo), $, t)
                    }, {
                        id: "IntervalsVisibilitiesWeeks",
                        title: B,
                        min: new(a())(ie[0]),
                        max: new(a())(ie[1])
                    }),
                    u = (0, s.createRangePropertyDefinition)({
                        checked: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.months), ee, t),
                        from: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.monthsFrom), te, t),
                        to: new d.CollectiblePropertyUndoWrapper(new p.LineToolCollectedProperty(e.monthsTo), le, t)
                    }, {
                        id: "IntervalsVisibilitiesMonths",
                        title: A,
                        min: new(a())(ae[0]),
                        max: new(a())(ae[1])
                    });
                return l.push(h, u), {
                    definitions: l
                }
            }
        },
        9565: (e, t, l) => {
            "use strict";
            l.d(t, {
                getTemplates: () => n,
                setTemplates: () => o,
                addTemplate: () => s,
                startRemoveTemplate: () => i,
                removeTemplate: () => a,
                saveTemplate: () => c,
                loadTemplate: () => p,
                applyDefaults: () => d
            });
            var r = l(48583);

            function n(e, t) {
                return {
                    type: r.GET_TEMPLATES,
                    toolName: e,
                    callback: t
                }
            }

            function o(e, t) {
                return {
                    type: r.SET_TEMPLATES,
                    templates: t,
                    toolName: e
                }
            }

            function s(e, t) {
                return {
                    type: r.ADD_TEMPLATE,
                    templateName: t,
                    toolName: e
                }
            }

            function i(e, t) {
                return {
                    type: r.START_REMOVE_TEMPLATE,
                    templateName: t,
                    toolName: e
                }
            }

            function a(e, t) {
                return {
                    type: r.REMOVE_TEMPLATE,
                    templateName: t,
                    toolName: e
                }
            }

            function c(e, t, l) {
                return {
                    type: r.SAVE_TEMPLATE,
                    templateName: t,
                    toolName: e,
                    content: l
                }
            }

            function p(e, t, l) {
                return {
                    type: r.LOAD_TEMPLATE,
                    toolName: e,
                    templateName: t,
                    callback: l
                }
            }

            function d(e, t) {
                return {
                    type: r.APPLY_DEFAULTS,
                    model: e,
                    source: t
                }
            }
        },
        48583: (e, t, l) => {
            "use strict";

            function r(e) {
                return "LINE_TOOL_TEMPLATE__" + e
            }
            l.d(t, {
                GET_TEMPLATES: () => n,
                SET_TEMPLATES: () => o,
                START_REMOVE_TEMPLATE: () => s,
                REMOVE_TEMPLATE: () => i,
                SAVE_TEMPLATE: () => a,
                ADD_TEMPLATE: () => c,
                LOAD_TEMPLATE: () => p,
                APPLY_DEFAULTS: () => d
            });
            const n = r("GET_TEMPLATES"),
                o = r("SET_TEMPLATES"),
                s = r("START_REMOVE_TEMPLATE"),
                i = r("REMOVE_TEMPLATE"),
                a = r("SAVE_TEMPLATE"),
                c = r("ADD_TEMPLATE"),
                p = r("LOAD_TEMPLATE"),
                d = r("APPLY_DEFAULTS")
        },
        38239: (e, t, l) => {
            "use strict";
            l.d(t, {
                store: () => P
            });
            var r = l(83243),
                n = l(54773),
                o = l(36349),
                s = l(88537),
                i = l(48583),
                a = l(51951),
                c = l(9565);

            function p(e, t) {
                return t
            }
            var d = l(19013);
            const h = (0, a.getLogger)("Chart.LineToolTemplatesList");

            function u(e, t) {
                return t
            }

            function* m() {
                for (;;) {
                    const {
                        toolName: e,
                        templateName: t,
                        content: l
                    } = u(i.SAVE_TEMPLATE, yield(0, o.take)(i.SAVE_TEMPLATE));
                    try {
                        yield(0, o.call)(d.backend.saveDrawingTemplate, e, t, l), yield(0, o.put)((0, c.addTemplate)(e, t))
                    } catch (e) {
                        h.logWarn(e)
                    }
                }
            }

            function* y() {
                for (;;) {
                    const {
                        toolName: e,
                        templateName: t
                    } = u(i.START_REMOVE_TEMPLATE, yield(0, o.take)(i.START_REMOVE_TEMPLATE));
                    try {
                        yield(0, o.call)(d.backend.removeDrawingTemplate, e, t), yield(0, o.put)((0, c.removeTemplate)(e, t))
                    } catch (e) {
                        h.logWarn(e)
                    }
                }
            }

            function* g() {
                const e = new Map;
                for (;;) {
                    const {
                        toolName: l,
                        callback: r
                    } = u(i.GET_TEMPLATES, yield(0, o.take)(i.GET_TEMPLATES));
                    e.has(l) ? (0, s.ensureDefined)(e.get(l)).push(r) : (e.set(l, [r]), yield(0, o.fork)(t, l))
                }

                function* t(t) {
                    try {
                        const e = p(d.backend.getDrawingTemplates, yield(0, o.call)(d.backend.getDrawingTemplates, t));
                        yield(0, o.put)((0, c.setTemplates)(t, e))
                    } catch (e) {
                        h.logWarn(e)
                    }(0, s.ensureDefined)(e.get(t)).forEach(e => null == e ? void 0 : e()), e.delete(t)
                }
            }

            function* v() {
                for (;;) {
                    const {
                        toolName: e,
                        templateName: t,
                        callback: l
                    } = u(i.LOAD_TEMPLATE, yield(0, o.take)(i.LOAD_TEMPLATE));
                    try {
                        const r = p(d.backend.loadDrawingTemplate, yield(0, o.call)(d.backend.loadDrawingTemplate, e, t));
                        l && l(r)
                    } catch (e) {
                        h.logWarn(e)
                    }
                }
            }

            function* b() {
                for (;;) {
                    const {
                        model: e,
                        source: t
                    } = u(i.APPLY_DEFAULTS, yield(0, o.take)(i.APPLY_DEFAULTS));
                    try {
                        yield(0, o.call)([e, e.restorePropertiesForSource], t)
                    } catch (e) {
                        h.logWarn(e)
                    }
                }
            }

            function* f() {
                yield(0, o.all)([(0, o.call)(g), (0, o.call)(m), (0, o.call)(y), (0, o.call)(v), (0, o.call)(b)])
            }
            const w = {
                templates: {}
            };

            function S(e, t) {
                return e.localeCompare(t, void 0, {
                    numeric: !0
                })
            }

            function C(e = w, t) {
                switch (t.type) {
                    case i.ADD_TEMPLATE:
                        {
                            const {
                                toolName: l,
                                templateName: r
                            } = t;
                            if (!e.templates[l].includes(r)) {
                                const t = [...e.templates[l], r].sort(S);
                                return { ...e,
                                    templates: { ...e.templates,
                                        [l]: t
                                    }
                                }
                            }
                            return e
                        }
                    case i.SET_TEMPLATES:
                        {
                            const {
                                toolName: l,
                                templates: r
                            } = t;
                            return { ...e,
                                templates: { ...e.templates,
                                    [l]: [...r].sort(S)
                                }
                            }
                        }
                    case i.REMOVE_TEMPLATE:
                        {
                            const {
                                toolName: l,
                                templateName: r
                            } = t;
                            return { ...e,
                                templates: { ...e.templates,
                                    [l]: e.templates[l].filter(e => e !== r)
                                }
                            }
                        }
                    default:
                        return e
                }
            }
            const P = function() {
                const e = (0, n.default)(),
                    t = (0, r.createStore)(C, (0, r.applyMiddleware)(e));
                return e.run(f), t
            }()
        },
        25814: (e, t, l) => {
            "use strict";
            l.d(t, {
                CollectiblePropertyUndoWrapper: () => c
            });
            var r = l(88537),
                n = l(25177),
                o = l(18517),
                s = l(86712),
                i = l.n(s);
            const a = new o.TranslatedString("change {propertyName} property", (0, n.t)("change {propertyName} property"));
            class c extends(i()) {
                constructor(e, t, l) {
                    super(), this._isProcess = !1, this._listenersMappers = [], this._valueApplier = {
                        applyValue: (e, t) => {
                            this._propertyApplier.setProperty(e, t, a)
                        }
                    }, this._baseProperty = e, this._propertyApplier = l, this._propertyName = t
                }
                destroy() {
                    this._baseProperty.destroy()
                }
                value() {
                    return this._baseProperty.value()
                }
                setValue(e, t) {
                    this._propertyApplier.beginUndoMacro(a.format({
                        propertyName: this._propertyName
                    })), this._isProcess = !0, this._baseProperty.setValue(e, void 0, this._valueApplier), this._isProcess = !1, this._propertyApplier.endUndoMacro(), this._listenersMappers.forEach(e => {
                        e.method.call(e.obj, this)
                    })
                }
                subscribe(e, t) {
                    const l = () => {
                        this._isProcess || t.call(e, this)
                    };
                    this._listenersMappers.push({
                        obj: e,
                        method: t,
                        callback: l
                    }), this._baseProperty.subscribe(e, l)
                }
                unsubscribe(e, t) {
                    var l;
                    const n = (0, r.ensureDefined)(null === (l = this._listenersMappers.find(l => l.obj === e && l.method === t)) || void 0 === l ? void 0 : l.callback);
                    this._baseProperty.unsubscribe(e, n)
                }
                unsubscribeAll(e) {
                    this._baseProperty.unsubscribeAll(e)
                }
            }
        },
        57960: (e, t, l) => {
            "use strict";
            l.r(t), l.d(t, {
                EditObjectDialogRenderer: () => el
            });
            var r = l(87995),
                n = l(59496),
                o = l(88537),
                s = l(25177),
                i = l(18517),
                a = l(17501),
                c = l(70122),
                p = l(82527),
                d = l(59410),
                h = l(32133),
                u = l(64730),
                m = l(74609),
                y = l(76669),
                g = l(70981),
                v = l(42554),
                b = l(93065),
                f = l(80865),
                w = l(5796),
                S = l(61012),
                C = l(942);
            class P extends n.PureComponent {
                constructor(e) {
                    super(e), this._handleClose = e => {
                        (null == e ? void 0 : e.target) && e.target.closest('[data-dialog-name="gopro"]') || this.props.onClose()
                    }, this._renderFooterLeft = e => {
                        const {
                            source: t,
                            model: l
                        } = this.props;
                        if ((0, w.isLineTool)(t)) return n.createElement(S.FooterMenu, {
                            source: t,
                            model: l
                        });
                        if ((0, b.isStudy)(t)) return n.createElement(m.StudyDefaultsManager, {
                            model: l,
                            source: t,
                            mode: e ? "compact" : "normal"
                        });
                        throw new TypeError("Unsupported source type.")
                    }, this._handleSelect = e => {
                        this.setState({
                            activeTabId: e
                        }, () => {
                            this._requestResize && this._requestResize()
                        }), this.props.onActiveTabChanged && this.props.onActiveTabChanged(e)
                    }, this._handleScroll = () => {
                        g.globalCloseDelegate.fire()
                    }, this._handleSubmit = () => {
                        this.props.onSubmit(), this.props.onClose()
                    };
                    const {
                        pages: t,
                        initialActiveTab: l
                    } = this.props;
                    this.state = {
                        activeTabId: t.allIds.includes(l) ? l : t.allIds[0]
                    }
                }
                render() {
                    const {
                        title: e,
                        onCancel: t,
                        onClose: l
                    } = this.props, {
                        activeTabId: r
                    } = this.state;
                    return n.createElement(y.AdaptiveConfirmDialog, {
                        dataName: "indicator-properties-dialog",
                        title: e,
                        isOpened: !0,
                        onSubmit: this._handleSubmit,
                        onCancel: t,
                        onClickOutside: this._handleClose,
                        onClose: l,
                        footerLeftRenderer: this._renderFooterLeft,
                        render: this._renderChildren(r),
                        submitOnEnterKey: !1
                    })
                }
                _renderChildren(e) {
                    return ({
                        requestResize: t
                    }) => {
                        this._requestResize = t;
                        const {
                            pages: l,
                            source: r,
                            model: o
                        } = this.props, s = l.byId[e], i = "Component" in s ? void 0 : s.page;
                        return n.createElement(n.Fragment, null, n.createElement(u.DialogTabs, {
                            activeTabId: e,
                            onSelect: this._handleSelect,
                            tabs: l
                        }), n.createElement(v.TouchScrollContainer, {
                            className: C.scrollable,
                            onScroll: this._handleScroll
                        }, "Component" in s ? n.createElement(s.Component, {
                            source: r,
                            model: o
                        }) : n.createElement(f.PropertiesEditorTab, {
                            page: i,
                            tableKey: e
                        })))
                    }
                }
            }
            var T = l(34453),
                E = l(70473);
            class _ extends n.PureComponent {
                constructor(e) {
                    super(e), this._properties = this.props.source.properties(), this._inputs = new E.MetaInfoHelper(this.props.source.metaInfo()).getUserEditableInputs()
                }
                render() {
                    return n.createElement(T.InputsTabContent, {
                        property: this._properties,
                        model: this.props.model,
                        study: this.props.source,
                        inputs: this._inputs
                    })
                }
            }
            var k = l(14823),
                L = l(51870),
                x = l(10392),
                M = l.n(x),
                I = l(26175),
                D = l(29699),
                R = l(56988);
            const V = new i.TranslatedString("change visibility", (0, s.t)("change visibility"));
            class N extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            visible: l
                        } = this.props;
                        l && (0, R.setPropertyValue)(l, l => t(l, e, V))
                    }
                }
                render() {
                    const {
                        id: e,
                        title: t,
                        visible: l,
                        disabled: r
                    } = this.props, o = (0, a.clean)((0, s.t)(t, {
                        context: "input"
                    }), !0);
                    return n.createElement(D.BoolInputComponent, {
                        label: o,
                        disabled: r,
                        input: {
                            id: e,
                            type: "bool",
                            defval: !0,
                            name: "visible"
                        },
                        value: !l || (0, R.getPropertyValue)(l),
                        onChange: this._onChange
                    })
                }
            }
            N.contextType = I.StylePropertyContext;
            var B = l(39747),
                A = l(17850),
                W = l(45545),
                F = l(65588),
                z = l(69047),
                H = l(23181),
                O = l(70153),
                G = l(51494),
                U = l(95621),
                j = l(29422),
                Y = l(16616),
                K = l(13790),
                Z = l(58061),
                q = l(66647);
            const Q = {
                    [L.LineStudyPlotStyle.Line]: {
                        type: L.LineStudyPlotStyle.Line,
                        order: 0,
                        icon: z,
                        label: (0, s.t)("Line")
                    },
                    [L.LineStudyPlotStyle.LineWithBreaks]: {
                        type: L.LineStudyPlotStyle.LineWithBreaks,
                        order: 1,
                        icon: H,
                        label: (0, s.t)("Line with breaks")
                    },
                    [L.LineStudyPlotStyle.StepLine]: {
                        type: L.LineStudyPlotStyle.StepLine,
                        order: 2,
                        icon: O,
                        label: (0, s.t)("Step line")
                    },
                    [L.LineStudyPlotStyle.StepLineWithDiamonds]: {
                        type: L.LineStudyPlotStyle.StepLineWithDiamonds,
                        order: 3,
                        icon: G,
                        label: (0, s.t)("Step line with diamonds")
                    },
                    [L.LineStudyPlotStyle.Histogram]: {
                        type: L.LineStudyPlotStyle.Histogram,
                        order: 4,
                        icon: U,
                        label: (0, s.t)("Histogram")
                    },
                    [L.LineStudyPlotStyle.Cross]: {
                        type: L.LineStudyPlotStyle.Cross,
                        order: 5,
                        icon: j,
                        label: (0, s.t)("Cross", {
                            context: "chart_type"
                        })
                    },
                    [L.LineStudyPlotStyle.Area]: {
                        type: L.LineStudyPlotStyle.Area,
                        order: 6,
                        icon: Y,
                        label: (0, s.t)("Area")
                    },
                    [L.LineStudyPlotStyle.AreaWithBreaks]: {
                        type: L.LineStudyPlotStyle.AreaWithBreaks,
                        order: 7,
                        icon: K,
                        label: (0, s.t)("Area with breaks")
                    },
                    [L.LineStudyPlotStyle.Columns]: {
                        type: L.LineStudyPlotStyle.Columns,
                        order: 8,
                        icon: Z,
                        label: (0, s.t)("Columns")
                    },
                    [L.LineStudyPlotStyle.Circles]: {
                        type: L.LineStudyPlotStyle.Circles,
                        order: 9,
                        icon: q,
                        label: (0, s.t)("Circles")
                    }
                },
                X = Object.values(Q).sort((e, t) => e.order - t.order).map(e => ({
                    value: e.type,
                    selectedContent: n.createElement(F.DisplayItem, {
                        icon: e.icon
                    }),
                    content: n.createElement(F.DropItem, {
                        icon: e.icon,
                        label: e.label
                    })
                })),
                J = (0, s.t)("Price line");
            class $ extends n.PureComponent {
                render() {
                    const {
                        id: e,
                        plotType: t,
                        className: l,
                        priceLine: r,
                        plotTypeChange: o,
                        priceLineChange: s,
                        disabled: i
                    } = this.props;
                    if (!(t in Q)) return null;
                    const a = {
                        readonly: !0,
                        content: n.createElement(n.Fragment, null, n.createElement(W.MenuItemSwitcher, {
                            id: "PlotTypePriceLineSwitch",
                            checked: r,
                            label: J,
                            preventLabelHighlight: !0,
                            value: "priceLineSwitcher",
                            onChange: s
                        }), n.createElement(A.PopupMenuSeparator, null))
                    };
                    return n.createElement(F.IconDropdown, {
                        id: e,
                        disabled: i,
                        className: l,
                        hideArrowButton: !0,
                        items: [a, ...X],
                        value: t,
                        onChange: o
                    })
                }
            }
            var ee = l(91409),
                te = l(20959);
            const le = new i.TranslatedString("change plot type", (0, s.t)("change plot type")),
                re = new i.TranslatedString("change price line visibility", (0, s.t)("change price line visibility"));
            class ne extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onPlotTypeChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            styleProp: {
                                plottype: l
                            }
                        } = this.props;
                        l && t(l, e, le)
                    }, this._onPriceLineChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            styleProp: {
                                trackPrice: l
                            }
                        } = this.props;
                        l && t(l, e, re)
                    }
                }
                render() {
                    const {
                        id: e,
                        paletteColor: t,
                        paletteColorProps: l,
                        styleProp: r,
                        isLine: o,
                        hasPlotTypeSelect: i,
                        grouped: a,
                        offset: c
                    } = this.props, p = l.childs();
                    return n.createElement(B.InputRow, {
                        grouped: a,
                        label: n.createElement("div", {
                            className: te.childRowContainer
                        }, (0, s.t)(t.name, {
                            context: "input"
                        })),
                        offset: c
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !r.visible.value(),
                        color: p.color,
                        transparency: r.transparency,
                        thickness: o ? p.width : void 0,
                        isPaletteColor: !0
                    }), o && i && r.plottype && r.trackPrice ? n.createElement($, {
                        id: (0, k.createDomId)(e, "plot-type-select"),
                        disabled: !r.visible.value(),
                        className: te.smallStyleControl,
                        plotType: r.plottype.value(),
                        priceLine: r.trackPrice.value(),
                        plotTypeChange: this._onPlotTypeChange,
                        priceLineChange: this._onPriceLineChange
                    }) : null)
                }
            }
            ne.contextType = I.StylePropertyContext;
            var oe = l(13143);
            class se extends n.PureComponent {
                render() {
                    const {
                        plot: e,
                        area: t,
                        palette: l,
                        paletteProps: r,
                        hideVisibilitySwitch: s,
                        styleProp: i,
                        showOnlyTitle: a,
                        showSeparator: c = !0,
                        offset: p
                    } = this.props, d = e ? e.id : (0, o.ensureDefined)(t).id, h = !d.startsWith("fill") && e && (0, L.isLinePlot)(e);
                    return n.createElement(n.Fragment, null, !s && n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2,
                        offset: p
                    }, a ? n.createElement("div", null, t ? t.title : i.title.value()) : n.createElement(N, {
                        id: d,
                        title: t ? t.title : i.title.value(),
                        visible: i.visible
                    }))), function(e, t, l, r, s, i) {
                        const a = t.colors,
                            c = l.colors;
                        return Object.keys(a).map((t, l) => n.createElement(ne, {
                            key: t,
                            id: e,
                            grouped: !0,
                            paletteColor: (0, o.ensureDefined)(a[t]),
                            paletteColorProps: (0, o.ensureDefined)(c[t]),
                            styleProp: r,
                            isLine: s,
                            hasPlotTypeSelect: 0 === l,
                            offset: i
                        }))
                    }(d, l, r, i, h, p), c && n.createElement(oe.PropertyTable.GroupSeparator, null))
                }
            }
            se.contextType = I.StylePropertyContext;
            var ie = l(54393);
            const ae = new i.TranslatedString("change plot type", (0, s.t)("change plot type")),
                ce = new i.TranslatedString("change price line visibility", (0, s.t)("change price line visibility"));
            class pe extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onPlotTypeChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            property: {
                                plottype: l
                            }
                        } = this.props;
                        l && t(l, e, ae)
                    }, this._onPriceLineChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            property: {
                                trackPrice: l
                            }
                        } = this.props;
                        l && t(l, e, ce)
                    }
                }
                render() {
                    const {
                        id: e,
                        isRGB: t,
                        isFundamental: l,
                        property: {
                            title: r,
                            color: o,
                            plottype: s,
                            linewidth: i,
                            transparency: a,
                            trackPrice: c,
                            visible: p
                        }
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        label: n.createElement(N, {
                            id: e,
                            title: r.value(),
                            visible: p
                        })
                    }, t && !l ? this._getInputForRgb() : n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !p.value(),
                        color: o,
                        transparency: a,
                        thickness: i
                    }), n.createElement($, {
                        id: (0, k.createDomId)(e, "plot-type-select"),
                        disabled: !p.value(),
                        className: te.smallStyleControl,
                        plotType: s.value(),
                        priceLine: c.value(),
                        plotTypeChange: this._onPlotTypeChange,
                        priceLineChange: this._onPriceLineChange
                    }))
                }
                _getInputForRgb() {
                    const {
                        id: e,
                        showLineWidth: t,
                        property: l
                    } = this.props, {
                        linewidth: r,
                        visible: o
                    } = l;
                    return r && t ? n.createElement(ie.LineWidthSelect, {
                        id: (0, k.createDomId)(e, "line-width-select"),
                        property: r,
                        disabled: !o.value()
                    }) : null
                }
            }
            pe.contextType = I.StylePropertyContext;
            const de = n.createContext(null);
            class he extends n.PureComponent {
                render() {
                    const {
                        id: e,
                        isRGB: t,
                        title: l,
                        visible: r,
                        color: o,
                        transparency: s,
                        thickness: i,
                        children: a,
                        switchable: c = !0,
                        offset: p,
                        grouped: d
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        label: c ? n.createElement(N, {
                            id: e,
                            title: l,
                            visible: r
                        }) : l,
                        offset: p,
                        grouped: d
                    }, t ? null : n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: r && !(Array.isArray(r) ? r[0].value() : r.value()),
                        color: o,
                        transparency: s,
                        thickness: i
                    }), a)
                }
            }
            he.contextType = I.StylePropertyContext;
            class ue extends n.PureComponent {
                render() {
                    const {
                        id: e,
                        isRGB: t,
                        property: {
                            colorup: l,
                            colordown: r,
                            transparency: s,
                            visible: i
                        }
                    } = this.props;
                    return n.createElement(de.Consumer, null, a => n.createElement(n.Fragment, null, n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2,
                        grouped: !0
                    }, n.createElement(N, {
                        id: e,
                        title: Ge((0, o.ensureNotNull)(a), e),
                        visible: i
                    }))), !t && n.createElement(n.Fragment, null, n.createElement(he, {
                        id: e,
                        title: Ae,
                        color: l,
                        transparency: s,
                        visible: i,
                        switchable: !1,
                        offset: !0,
                        grouped: !0
                    }), n.createElement(he, {
                        id: e,
                        title: We,
                        color: r,
                        transparency: s,
                        visible: i,
                        switchable: !1,
                        offset: !0,
                        grouped: !0
                    })), n.createElement(oe.PropertyTable.GroupSeparator, null)))
                }
            }
            ue.contextType = I.StylePropertyContext;
            var me = l(87795),
                ye = l.n(me),
                ge = l(97754),
                ve = l(54936),
                be = l(36118),
                fe = l(67912);
            const we = {
                    [fe.MarkLocation.AboveBar]: {
                        value: fe.MarkLocation.AboveBar,
                        content: (0, s.t)("Above bar"),
                        order: 0
                    },
                    [fe.MarkLocation.BelowBar]: {
                        value: fe.MarkLocation.BelowBar,
                        content: (0, s.t)("Below bar"),
                        order: 1
                    },
                    [fe.MarkLocation.Top]: {
                        value: fe.MarkLocation.Top,
                        content: (0, s.t)("Top"),
                        order: 2
                    },
                    [fe.MarkLocation.Bottom]: {
                        value: fe.MarkLocation.Bottom,
                        content: (0, s.t)("Bottom"),
                        order: 3
                    },
                    [fe.MarkLocation.Absolute]: {
                        value: fe.MarkLocation.Absolute,
                        content: (0, s.t)("Absolute"),
                        order: 4
                    }
                },
                Se = Object.values(we).sort((e, t) => e.order - t.order);
            class Ce extends n.PureComponent {
                render() {
                    const {
                        id: e,
                        shapeLocation: t,
                        className: l,
                        menuItemClassName: r,
                        shapeLocationChange: o,
                        disabled: s
                    } = this.props;
                    return n.createElement(be.Select, {
                        id: e,
                        disabled: s,
                        className: l,
                        menuItemClassName: r,
                        items: Se,
                        value: t,
                        onChange: o
                    })
                }
            }
            const Pe = new i.TranslatedString("change char", (0, s.t)("change char")),
                Te = new i.TranslatedString("change location", (0, s.t)("change location"));
            class Ee extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onCharChange = e => {
                        const {
                            setValue: t
                        } = this.context, l = e.currentTarget.value.trim(), r = ye()(l), n = 0 === r.length ? "" : r[r.length - 1], {
                            property: {
                                char: o
                            }
                        } = this.props;
                        t(o, n, Pe)
                    }, this._onLocationChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            property: {
                                location: l
                            }
                        } = this.props;
                        t(l, e, Te)
                    }
                }
                render() {
                    const {
                        id: e,
                        isRGB: t,
                        property: {
                            title: l,
                            color: r,
                            transparency: o,
                            char: s,
                            location: i,
                            visible: a
                        },
                        hasPalette: c
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        grouped: c,
                        label: n.createElement(N, {
                            id: e,
                            title: l.value(),
                            visible: a
                        })
                    }, !c && !t && n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !a.value(),
                        color: r,
                        transparency: o
                    }), n.createElement(ve.InputControl, {
                        disabled: !a.value(),
                        className: te.smallStyleControl,
                        value: s.value(),
                        onChange: this._onCharChange
                    }), n.createElement(Ce, {
                        id: (0, k.createDomId)(e, "shape-style-select"),
                        disabled: !a.value(),
                        className: ge(te.defaultSelect, te.additionalSelect),
                        menuItemClassName: te.defaultSelectItem,
                        shapeLocation: i.value(),
                        shapeLocationChange: this._onLocationChange
                    }))
                }
            }
            Ee.contextType = I.StylePropertyContext;
            var _e = l(83802);
            const ke = {
                arrow_down: l(56514),
                arrow_up: l(25115),
                circle: l(1038),
                cross: l(38074),
                diamond: l(66438),
                flag: l(43469),
                label_down: l(29634),
                label_up: l(49461),
                square: l(16925),
                triangle_down: l(12465),
                triangle_up: l(41038),
                x_cross: l(747)
            };

            function Le(e) {
                return ke[e]
            }
            const xe = [];
            Object.keys(_e.plotShapesData).forEach(e => {
                const t = _e.plotShapesData[e];
                xe.push({
                    id: t.id,
                    value: t.id,
                    selectedContent: n.createElement(F.DisplayItem, {
                        icon: Le(t.icon)
                    }),
                    content: n.createElement(F.DropItem, {
                        icon: Le(t.icon),
                        label: t.guiName
                    })
                })
            });
            class Me extends n.PureComponent {
                render() {
                    const {
                        id: e,
                        shapeStyleId: t,
                        className: l,
                        shapeStyleChange: r,
                        disabled: o
                    } = this.props;
                    return n.createElement(F.IconDropdown, {
                        id: e,
                        disabled: o,
                        className: l,
                        hideArrowButton: !0,
                        items: xe,
                        value: t,
                        onChange: r
                    })
                }
            }
            const Ie = new i.TranslatedString("change shape", (0, s.t)("change shape")),
                De = new i.TranslatedString("change location", (0, s.t)("change location"));
            class Re extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onPlotTypeChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            property: {
                                plottype: l
                            }
                        } = this.props;
                        t(l, e, Ie)
                    }, this._onLocationChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            property: {
                                location: l
                            }
                        } = this.props;
                        t(l, e, De)
                    }
                }
                render() {
                    const {
                        id: e,
                        isRGB: t,
                        hasPalette: l,
                        property: {
                            title: r,
                            color: o,
                            transparency: s,
                            plottype: i,
                            location: a,
                            visible: c
                        }
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        grouped: l,
                        label: n.createElement(N, {
                            id: e,
                            title: r.value(),
                            visible: c
                        })
                    }, !l && !t && n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !c.value(),
                        color: o,
                        transparency: s
                    }), n.createElement(Me, {
                        id: (0, k.createDomId)(e, "shape-style-select"),
                        disabled: !c.value(),
                        className: te.smallStyleControl,
                        shapeStyleId: i.value(),
                        shapeStyleChange: this._onPlotTypeChange
                    }), n.createElement(Ce, {
                        id: (0, k.createDomId)(e, "shape-location-select"),
                        disabled: !c.value(),
                        className: ge(te.defaultSelect, te.additionalSelect),
                        menuItemClassName: te.defaultSelectItem,
                        shapeLocation: a.value(),
                        shapeLocationChange: this._onLocationChange
                    }))
                }
            }
            Re.contextType = I.StylePropertyContext;
            var Ve = l(51951),
                Ne = l(39881);
            const Be = (0, Ve.getLogger)("Chart.Study.PropertyPage"),
                Ae = (0, s.t)("Up"),
                We = (0, s.t)("Down"),
                Fe = (0, s.t)("Body"),
                ze = (0, s.t)("Wick"),
                He = (0, s.t)("Border");
            class Oe extends n.PureComponent {
                render() {
                    const {
                        plot: e,
                        palettes: t,
                        study: l
                    } = this.props, r = e.id, o = l.properties().styles[r], s = e.type, i = t.main, a = !!l.metaInfo().isRGB;
                    if ("line" === s || "bar_colorer" === s || "bg_colorer" === s) return i && i.palette && i.paletteProps ? n.createElement(se, {
                        plot: e,
                        palette: i.palette,
                        paletteProps: i.paletteProps,
                        styleProp: o
                    }) : n.createElement(pe, {
                        id: r,
                        property: o,
                        isRGB: a,
                        isFundamental: !1,
                        showLineWidth: "line" === s
                    });
                    if ("arrows" === s) {
                        const s = this._getPlotSwitch(r, Ge(l, r), o.visible);
                        if (a) return s;
                        const i = t.up,
                            c = t.down;
                        return i || c ? n.createElement(n.Fragment, null, s, i && i.palette && i.paletteProps ? n.createElement(se, {
                            plot: e,
                            palette: i.palette,
                            paletteProps: i.paletteProps,
                            styleProp: { ...o,
                                title: (0, Ne.createPrimitiveProperty)(Ae)
                            },
                            showSeparator: !1,
                            showOnlyTitle: !0,
                            offset: !0
                        }) : n.createElement(he, {
                            id: r,
                            isRGB: a,
                            title: Ae,
                            color: o.colorup,
                            visible: o.visible,
                            transparency: o.transparency,
                            switchable: !1,
                            grouped: !0,
                            offset: !0
                        }), c && c.palette && c.paletteProps ? n.createElement(se, {
                            plot: e,
                            palette: c.palette,
                            paletteProps: c.paletteProps,
                            styleProp: { ...o,
                                title: (0, Ne.createPrimitiveProperty)(We)
                            },
                            showSeparator: !1,
                            showOnlyTitle: !0,
                            offset: !0
                        }) : n.createElement(he, {
                            id: r,
                            isRGB: a,
                            title: We,
                            color: o.colordown,
                            visible: o.visible,
                            transparency: o.transparency,
                            switchable: !1,
                            grouped: !0,
                            offset: !0
                        }), n.createElement(oe.PropertyTable.GroupSeparator, null)) : n.createElement(ue, {
                            id: r,
                            property: o,
                            isRGB: a,
                            plot: e,
                            palettes: t,
                            styleProp: o
                        })
                    }
                    if ("chars" === s || "shapes" === s) return n.createElement(n.Fragment, null, "chars" === s ? n.createElement(Ee, {
                        id: r,
                        property: o,
                        hasPalette: Boolean(i && i.palette),
                        isRGB: a
                    }) : n.createElement(Re, {
                        id: r,
                        property: o,
                        hasPalette: Boolean(i && i.palette),
                        isRGB: a
                    }), i && i.palette && i.paletteProps && n.createElement(se, {
                        plot: e,
                        palette: i.palette,
                        paletteProps: i.paletteProps,
                        hideVisibilitySwitch: !0,
                        styleProp: o
                    }));
                    if ((0, L.isOhlcPlot)(e)) {
                        const o = e.target,
                            s = l.properties().ohlcPlots[o],
                            c = this._getPlotSwitch(r, s.title.value(), s.visible);
                        if (a) return c;
                        const p = t.wick && t.wick.palette && t.wick.paletteProps,
                            d = t.border && t.border.palette && t.border.paletteProps;
                        return n.createElement(n.Fragment, null, c, i && i.palette && i.paletteProps ? n.createElement(se, {
                            plot: e,
                            palette: i.palette,
                            paletteProps: i.paletteProps,
                            styleProp: { ...s,
                                title: (0, Ne.createPrimitiveProperty)(Fe)
                            },
                            showSeparator: !1,
                            showOnlyTitle: !0,
                            offset: !0
                        }) : n.createElement(he, {
                            id: r,
                            isRGB: a,
                            title: Fe,
                            visible: s.visible,
                            color: s.color,
                            transparency: s.transparency,
                            switchable: !1,
                            grouped: !0,
                            offset: !0
                        }), t.wick && t.wick.palette && t.wick.paletteProps && n.createElement(se, {
                            plot: e,
                            palette: t.wick.palette,
                            paletteProps: t.wick.paletteProps,
                            styleProp: { ...s,
                                title: (0, Ne.createPrimitiveProperty)(ze)
                            },
                            showSeparator: !1,
                            showOnlyTitle: !0,
                            offset: !0
                        }), Boolean(!p && s.wickColor) && n.createElement(he, {
                            id: r,
                            isRGB: a,
                            title: ze,
                            visible: s.visible,
                            color: s.wickColor,
                            transparency: s.transparency,
                            switchable: !1,
                            grouped: !0,
                            offset: !0
                        }), t.border && t.border.palette && t.border.paletteProps && n.createElement(se, {
                            plot: e,
                            palette: t.border.palette,
                            paletteProps: t.border.paletteProps,
                            styleProp: { ...s,
                                title: (0, Ne.createPrimitiveProperty)(He)
                            },
                            showSeparator: !1,
                            showOnlyTitle: !0,
                            offset: !0
                        }), Boolean(!d && s.borderColor) && n.createElement(he, {
                            id: r,
                            isRGB: a,
                            title: He,
                            visible: s.visible,
                            color: s.borderColor,
                            transparency: s.transparency,
                            switchable: !1,
                            grouped: !0,
                            offset: !0
                        }), n.createElement(oe.PropertyTable.GroupSeparator, null))
                    }
                    return Be.logError("Unknown plot type: " + s), null
                }
                _getPlotSwitch(e, t, l) {
                    return n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: e,
                        title: t,
                        visible: l
                    })))
                }
            }

            function Ge(e, t) {
                const l = (0, o.ensureDefined)(e.metaInfo().styles),
                    {
                        title: r
                    } = (0, o.ensureDefined)(l[t]);
                return (0, o.ensureDefined)(r)
            }
            var Ue = l(15955),
                je = l(96855);
            const Ye = new i.TranslatedString("change line style", (0, s.t)("change line style"));
            class Ke extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onLineStyleChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            lineStyle: l
                        } = this.props;
                        (0, R.setPropertyValue)(l, l => t(l, e, Ye))
                    }
                }
                render() {
                    const {
                        lineStyle: e,
                        ...t
                    } = this.props;
                    return n.createElement(je.LineStyleSelect, { ...t,
                        lineStyle: (0, R.getPropertyValue)(e),
                        lineStyleChange: this._onLineStyleChange
                    })
                }
            }
            Ke.contextType = I.StylePropertyContext;
            const Ze = new i.TranslatedString("change value", (0, s.t)("change value"));
            class qe extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onValueChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            value: l
                        } = this.props.property;
                        t(l, e, Ze)
                    }
                }
                render() {
                    const {
                        id: e,
                        property: {
                            name: t,
                            color: l,
                            linestyle: r,
                            linewidth: o,
                            transparency: s,
                            value: i,
                            visible: a
                        }
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        labelAlign: "adaptive",
                        label: n.createElement(N, {
                            id: e,
                            title: t.value(),
                            visible: a
                        })
                    }, n.createElement("div", {
                        className: te.block
                    }, n.createElement("div", {
                        className: te.group
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !a.value(),
                        color: l,
                        transparency: s,
                        thickness: o
                    }), n.createElement(Ke, {
                        id: (0, k.createDomId)(e, "line-style-select"),
                        disabled: !a.value(),
                        className: te.smallStyleControl,
                        lineStyle: r
                    })), n.createElement("div", {
                        className: ge(te.wrapGroup, te.defaultSelect, te.additionalSelect)
                    }, n.createElement(Ue.FloatInputComponent, {
                        input: {
                            id: "",
                            name: "",
                            type: "float",
                            defval: 0
                        },
                        value: i.value(),
                        disabled: !a.value(),
                        onChange: this._onValueChange
                    }))))
                }
            }
            qe.contextType = I.StylePropertyContext;
            class Qe extends n.PureComponent {
                render() {
                    const {
                        orders: {
                            visible: e,
                            showLabels: t,
                            showQty: l
                        }
                    } = this.props;
                    return n.createElement(n.Fragment, null, n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "chart-orders-switch",
                        title: (0, s.t)("Trades on chart"),
                        visible: e
                    }))), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "chart-orders-labels-switch",
                        title: (0, s.t)("Signal labels"),
                        visible: t
                    }))), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "chart-orders-qty-switch",
                        title: (0, s.t)("Quantity"),
                        visible: l
                    }))))
                }
            }
            Qe.contextType = I.StylePropertyContext;
            var Xe = l(74051),
                Je = l(74598);
            const $e = new i.TranslatedString("change percent width", (0, s.t)("change percent width")),
                et = new i.TranslatedString("change placement", (0, s.t)("change placement")),
                tt = new i.TranslatedString("change values visibility", (0, s.t)("change values visibility")),
                lt = [{
                    value: Xe.HHistDirection.LeftToRight,
                    content: (0, s.t)("Left")
                }, {
                    value: Xe.HHistDirection.RightToLeft,
                    content: (0, s.t)("Right")
                }],
                rt = (0, s.t)("Width (% of the box)"),
                nt = (0, s.t)("Placement"),
                ot = (0, s.t)("Values"),
                st = (0, s.t)("Text color");
            class it extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onPercentWidthChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            percentWidth: l
                        } = this.props.property.childs();
                        t(l, e, $e)
                    }, this._onPlacementChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            direction: l
                        } = this.props.property.childs();
                        t(l, e, et)
                    }, this._onShowValuesChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            showValues: l
                        } = this.props.property.childs();
                        t(l, e, tt)
                    }
                }
                render() {
                    const {
                        title: e,
                        percentWidth: t,
                        direction: l,
                        showValues: r,
                        valuesColor: o,
                        visible: s
                    } = this.props.property.childs();
                    return n.createElement(n.Fragment, null, n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2,
                        grouped: !0
                    }, n.createElement(N, {
                        id: e.value(),
                        title: e.value(),
                        visible: s
                    }))), n.createElement(B.InputRow, {
                        label: n.createElement("div", {
                            className: te.childRowContainer
                        }, rt),
                        grouped: !0
                    }, n.createElement(Je.IntegerInputComponent, {
                        input: {
                            id: "",
                            name: "",
                            type: "integer",
                            defval: 0
                        },
                        value: t.value(),
                        disabled: !s.value(),
                        onChange: this._onPercentWidthChange
                    })), n.createElement(B.InputRow, {
                        label: n.createElement("div", {
                            className: te.childRowContainer
                        }, nt),
                        grouped: !0
                    }, n.createElement(be.Select, {
                        id: "hhist-graphic-placement-select",
                        disabled: !s.value(),
                        className: te.defaultSelect,
                        menuItemClassName: te.defaultSelectItem,
                        items: lt,
                        value: l.value(),
                        onChange: this._onPlacementChange
                    })), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        className: te.childRowContainer,
                        placement: "first",
                        colSpan: 2,
                        grouped: !0
                    }, n.createElement(D.BoolInputComponent, {
                        label: ot,
                        input: {
                            id: e.value() + "_showValues",
                            type: "bool",
                            defval: !0,
                            name: "visible"
                        },
                        value: !r || r.value(),
                        disabled: !s.value(),
                        onChange: this._onShowValuesChange
                    }))), n.createElement(B.InputRow, {
                        label: n.createElement("div", {
                            className: te.childRowContainer
                        }, st),
                        grouped: !0
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: s && !s.value(),
                        color: o
                    })), this._renderColors(), n.createElement(oe.PropertyTable.GroupSeparator, null))
                }
                _renderColors() {
                    const {
                        colors: e,
                        titles: t,
                        transparencies: l,
                        visible: r
                    } = this.props.property.childs();
                    return e.childNames().map(o => n.createElement(B.InputRow, {
                        key: o,
                        grouped: !0,
                        label: n.createElement("div", {
                            className: te.childRowContainer
                        }, t.childs()[o].value())
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !r.value(),
                        color: e.childs()[o],
                        transparency: l.childs()[o]
                    })))
                }
            }
            it.contextType = I.StylePropertyContext;
            class at extends n.PureComponent {
                render() {
                    const {
                        title: e
                    } = this.props, {
                        color: t,
                        transparency: l,
                        width: r,
                        style: o,
                        visible: s
                    } = this.props.property.childs();
                    return n.createElement(B.InputRow, {
                        label: n.createElement(N, {
                            id: e.value(),
                            title: e.value(),
                            visible: s
                        })
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !s.value(),
                        color: t,
                        transparency: l,
                        thickness: r
                    }), n.createElement(Ke, {
                        id: (0, k.createDomId)(e.value(), "line-style-select"),
                        disabled: !s.value(),
                        className: te.smallStyleControl,
                        lineStyle: o
                    }))
                }
            }
            at.contextType = I.StylePropertyContext;
            class ct extends n.PureComponent {
                render() {
                    const {
                        graphicType: e,
                        study: t
                    } = this.props, l = t.metaInfo().graphics, r = t.properties().graphics, s = (0, o.ensureDefined)(l[e]);
                    return Object.keys(s).map((t, l) => {
                        const o = r[e][t];
                        return "horizlines" === e || "vertlines" === e || "lines" === e ? n.createElement(at, {
                            key: t,
                            title: "lines" === e ? o.title : o.name,
                            property: o
                        }) : "hhists" === e ? n.createElement(it, {
                            key: t,
                            property: o
                        }) : null
                    })
                }
            }
            var pt = l(32668);
            const dt = new i.TranslatedString("change font size", (0, s.t)("change font size")),
                ht = [10, 11, 12, 14, 16, 20, 24, 28, 32, 40].map(e => ({
                    value: e,
                    title: e.toString()
                }));
            class ut extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onFontSizeChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            fontSize: l
                        } = this.props;
                        t(l, e, dt)
                    }
                }
                render() {
                    const {
                        fontSize: e,
                        ...t
                    } = this.props;
                    return n.createElement(pt.FontSizeSelect, { ...t,
                        fontSizes: ht,
                        fontSize: e.value(),
                        fontSizeChange: this._onFontSizeChange
                    })
                }
            }
            ut.contextType = I.StylePropertyContext;
            const mt = new i.TranslatedString("change visibility", (0, s.t)("change visibility")),
                yt = (0, s.t)("Labels font"),
                gt = (0, s.t)("Labels"),
                vt = {
                    Traditional: new Set(["S5/R5", "S4/R4", "S3/R3", "S2/R2", "S1/R1", "P"]),
                    Fibonacci: new Set(["S3/R3", "S2/R2", "S1/R1", "P"]),
                    Woodie: new Set(["S4/R4", "S3/R3", "S2/R2", "S1/R1", "P"]),
                    Classic: new Set(["S4/R4", "S3/R3", "S2/R2", "S1/R1", "P"]),
                    DM: new Set(["S1/R1", "P"]),
                    DeMark: new Set(["S1/R1", "P"]),
                    Camarilla: new Set(["S4/R4", "S3/R3", "S2/R2", "S1/R1", "P"])
                };
            class bt extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            levelsStyle: l
                        } = this.props.property.childs(), {
                            showLabels: r
                        } = l.childs();
                        t(r, e, mt)
                    }
                }
                render() {
                    const {
                        fontsize: e,
                        levelsStyle: t
                    } = this.props.property.childs();
                    return n.createElement(n.Fragment, null, n.createElement(B.InputRow, {
                        labelAlign: "adaptive",
                        label: n.createElement("span", null, yt)
                    }, n.createElement("div", {
                        className: te.block
                    }, n.createElement("div", {
                        className: ge(te.wrapGroup, te.additionalSelect)
                    }, n.createElement(ut, {
                        id: "pivot-points-standard-font-size-select",
                        fontSize: e
                    })))), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(D.BoolInputComponent, {
                        label: gt,
                        input: {
                            id: "ShowLabels",
                            type: "bool",
                            defval: !0,
                            name: "visible"
                        },
                        value: t.childs().showLabels.value(),
                        onChange: this._onChange
                    }))), this._renderColors())
                }
                _renderColors() {
                    const {
                        levelsStyle: e,
                        inputs: t
                    } = this.props.property.childs(), {
                        colors: l,
                        widths: r,
                        visibility: s
                    } = e.childs(), {
                        kind: i
                    } = t.childs(), a = (0, o.ensureDefined)(vt[i.value()]);
                    return l.childNames().filter(e => a.has(e)).map(e => n.createElement(he, {
                        key: e,
                        id: e,
                        title: e,
                        color: l.childs()[e],
                        visible: s.childs()[e],
                        thickness: r.childs()[e]
                    }))
                }
            }
            bt.contextType = I.StylePropertyContext;
            const ft = new i.TranslatedString("change visibility", (0, s.t)("change visibility")),
                wt = (0, s.t)("Volume profile"),
                St = (0, s.t)("Values"),
                Ct = (0, s.t)("Width (% of the box)"),
                Pt = (0, s.t)("Placement"),
                Tt = (0, s.t)("Developing VA"),
                Et = (0, s.t)("Values in status line"),
                _t = (0, s.t)("Labels on price scale"),
                kt = [{
                    value: Xe.HHistDirection.RightToLeft,
                    content: (0, s.t)("Right")
                }, {
                    value: Xe.HHistDirection.LeftToRight,
                    content: (0, s.t)("Left")
                }];
            class Lt extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        this._setHhistsProperty("visible", e)
                    }, this._onShowValuesChange = e => {
                        this._setHhistsProperty("showValues", e)
                    }, this._onValueChange = e => {
                        this._setHhistsProperty("percentWidth", e)
                    }, this._onDirectionChange = e => {
                        this._setHhistsProperty("direction", e)
                    }
                }
                render() {
                    var e, t, l, r, i, a;
                    const {
                        metaInfo: c
                    } = this.props, {
                        graphics: p,
                        styles: d,
                        showLabelsOnPriceScale: h,
                        showLegendValues: u
                    } = this.props.property.childs(), {
                        hhists: m,
                        horizlines: y,
                        polygons: g
                    } = p.childs(), v = (0,
                        o.ensureDefined)(c.graphics.hhists), b = Object.keys(v), f = m.childs()[b[0]], w = f.childs().visible, S = b.map(e => m.childs()[e].childs().showValues), C = f.childs().percentWidth, P = f.childs().direction, T = b.map(e => m.childs()[e].childs().valuesColor), E = null === (e = y.childs()) || void 0 === e ? void 0 : e.vahLines, _ = null === (t = c.graphics.horizlines) || void 0 === t ? void 0 : t.vahLines, k = null === (l = y.childs()) || void 0 === l ? void 0 : l.valLines, L = null === (r = c.graphics.horizlines) || void 0 === r ? void 0 : r.valLines, x = y.childs().pocLines, M = (0, o.ensureDefined)(null === (i = c.graphics.horizlines) || void 0 === i ? void 0 : i.pocLines), I = d.childs().developingPoc, R = (0, o.ensureDefined)(null === (a = c.styles) || void 0 === a ? void 0 : a.developingPoc), V = d.childs().developingVAHigh, A = d.childs().developingVALow, W = c.graphics.polygons && c.graphics.polygons.histBoxBg;
                    return n.createElement(n.Fragment, null, n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(D.BoolInputComponent, {
                        label: wt,
                        input: {
                            id: "VolumeProfile",
                            type: "bool",
                            defval: !0,
                            name: "visible"
                        },
                        value: w.value(),
                        onChange: this._onChange
                    }))), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first"
                    }, n.createElement("div", {
                        className: te.childRowContainer
                    }, n.createElement(D.BoolInputComponent, {
                        disabled: !w.value(),
                        label: St,
                        input: {
                            id: "ShowValues",
                            type: "bool",
                            defval: !0,
                            name: "visible"
                        },
                        value: S[0].value(),
                        onChange: this._onShowValuesChange
                    }))), n.createElement(oe.PropertyTable.Cell, {
                        placement: "last"
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        disabled: !w.value() || !S[0].value(),
                        color: T
                    }))), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first"
                    }, n.createElement("div", {
                        className: te.childRowContainer
                    }, Ct)), n.createElement(oe.PropertyTable.Cell, {
                        placement: "last"
                    }, n.createElement(Je.IntegerInputComponent, {
                        disabled: !w.value(),
                        input: {
                            id: "",
                            name: "",
                            type: "integer",
                            defval: 0
                        },
                        value: C.value(),
                        onChange: this._onValueChange
                    }))), n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first"
                    }, n.createElement("div", {
                        className: te.childRowContainer
                    }, Pt)), n.createElement(oe.PropertyTable.Cell, {
                        placement: "last"
                    }, n.createElement(be.Select, {
                        id: "hhist-direction-select",
                        disabled: !w.value(),
                        className: te.defaultSelect,
                        menuItemClassName: te.defaultSelectItem,
                        items: kt,
                        value: P.value(),
                        onChange: this._onDirectionChange
                    }))), b.map(e => n.createElement(n.Fragment, {
                        key: e
                    }, m.childs()[e].childs().colors.childNames().map((t, l) => {
                        const r = v[e];
                        return n.createElement(B.InputRow, {
                            key: l,
                            label: n.createElement("div", {
                                className: te.childRowContainer
                            }, r && (0, s.t)(r.titles[l]) || "")
                        }, n.createElement(ee.ColorWithThicknessSelect, {
                            disabled: !w.value(),
                            color: m.childs()[e].childs().colors.childs()[l],
                            transparency: m.childs()[e].childs().transparencies.childs()[l]
                        }))
                    }))), _ && E && n.createElement(he, {
                        id: "vahLines",
                        title: _.name,
                        color: E.childs().color,
                        visible: E.childs().visible,
                        thickness: E.childs().width
                    }, n.createElement(Ke, {
                        id: "vah-lines-line-style-select",
                        disabled: !E.childs().visible.value(),
                        className: te.smallStyleControl,
                        lineStyle: E.childs().style
                    })), L && k && n.createElement(he, {
                        id: "valLines",
                        title: L.name,
                        color: k.childs().color,
                        visible: k.childs().visible,
                        thickness: k.childs().width
                    }, n.createElement(Ke, {
                        id: "val-lines-line-style-select",
                        disabled: !k.childs().visible.value(),
                        className: te.smallStyleControl,
                        lineStyle: k.childs().style
                    })), n.createElement(he, {
                        id: "pocLines",
                        title: M.name,
                        color: x.childs().color,
                        visible: x.childs().visible,
                        thickness: x.childs().width
                    }, n.createElement(Ke, {
                        id: "poc-lines-line-style-select",
                        disabled: !x.childs().visible.value(),
                        className: te.smallStyleControl,
                        lineStyle: x.childs().style
                    })), I && n.createElement(he, {
                        id: "developingPoc",
                        title: R.title && (0, s.t)(R.title) || "",
                        color: I.childs().color,
                        visible: I.childs().visible,
                        thickness: I.childs().linewidth
                    }, n.createElement(Ke, {
                        id: "developing-poc-line-style-select",
                        disabled: !I.childs().visible.value(),
                        className: te.smallStyleControl,
                        lineStyle: I.childs().linestyle
                    })), V && A && n.createElement(he, {
                        id: "developingPoc",
                        title: Tt,
                        color: [V.childs().color, A.childs().color],
                        visible: [V.childs().visible, A.childs().visible],
                        thickness: [V.childs().linewidth, A.childs().linewidth]
                    }, n.createElement(Ke, {
                        id: "developing-VA-line-style-select",
                        disabled: !V.childs().visible.value() && !A.childs().visible.value(),
                        className: te.smallStyleControl,
                        lineStyle: [V.childs().linestyle, A.childs().linestyle]
                    })), g && n.createElement(B.InputRow, {
                        label: n.createElement("div", null, W && (0, s.t)(W.name) || "")
                    }, n.createElement(ee.ColorWithThicknessSelect, {
                        color: g.childs().histBoxBg.childs().color,
                        transparency: g.childs().histBoxBg.childs().transparency
                    })), "VbPFixed" !== c.shortId && n.createElement(n.Fragment, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "showLabelsOnPriceScale",
                        title: _t,
                        visible: h
                    })), n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "showLegendValues",
                        title: Et,
                        visible: u
                    }))))
                }
                _setHhistsProperty(e, t) {
                    const {
                        setValue: l
                    } = this.context, {
                        metaInfo: r,
                        property: n
                    } = this.props, s = n.childs().graphics.childs().hhists, i = Object.keys((0, o.ensureDefined)(r.graphics.hhists));
                    for (let r = 0; r < i.length; r++) {
                        const n = s.childs()[i[r]].child(e);
                        l((0, o.ensureDefined)(n), t, ft)
                    }
                }
            }

            function xt() {
                const e = (0, o.ensureNotNull)((0, n.useContext)(de)),
                    t = e.metaInfo(),
                    l = e.properties();
                return n.createElement(Lt, {
                    metaInfo: t,
                    property: l
                })
            }
            Lt.contextType = I.StylePropertyContext;
            var Mt = l(59816);
            const It = {
                VbPFixed: xt,
                PivotPointsStandard: function() {
                    const e = (0, o.ensureNotNull)((0, n.useContext)(de)).properties();
                    return n.createElement(bt, {
                        property: e
                    })
                },
                VbPVisible: xt
            };
            class Dt extends n.PureComponent {
                render() {
                    const e = (0, o.ensureNotNull)(this.context);
                    return n.createElement(de.Consumer, null, t => n.createElement(I.StylePropertyContainer, {
                        property: (0, o.ensureNotNull)(t).properties(),
                        model: e
                    }, n.createElement(oe.PropertyTable, null, this._renderCustomContent((0, o.ensureNotNull)(t).metaInfo().shortId))))
                }
                _renderCustomContent(e) {
                    if (e in It) {
                        const t = It[e];
                        return n.createElement(t, null)
                    }
                    return null
                }
            }
            Dt.contextType = Mt.ModelContext;
            var Rt = l(88644);
            const Vt = new i.TranslatedString("change precision", (0,
                    s.t)("change precision")),
                Nt = (0, s.t)("Default"),
                Bt = (0, s.t)("Precision"),
                At = [{
                    value: "default",
                    content: Nt
                }];
            for (let e = 0; e <= 8; e++) At.push({
                value: e,
                content: e.toString()
            });
            class Wt extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            precision: l
                        } = this.props;
                        t(l, e, Vt)
                    }
                }
                render() {
                    const {
                        id: e,
                        precision: t
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        label: Bt
                    }, n.createElement(be.Select, {
                        id: e,
                        className: te.defaultSelect,
                        menuItemClassName: te.defaultSelectItem,
                        items: At,
                        value: t.value(),
                        onChange: this._onChange
                    }))
                }
            }
            Wt.contextType = I.StylePropertyContext;
            const Ft = new i.TranslatedString("change min tick", (0, s.t)("change min tick")),
                zt = (0, s.t)("Default"),
                Ht = (0, s.t)("Override min tick"),
                Ot = [{
                    priceScale: 1,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 10,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 100,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e3,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e4,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e5,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e6,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e7,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e8,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 2,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 4,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 8,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 16,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 32,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 64,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 128,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 320,
                    minMove: 1,
                    frac: !0
                }],
                Gt = [{
                    id: "tick-default",
                    value: "default",
                    content: zt
                }];
            for (let e = 0; e < Ot.length; e++) {
                const t = Ot[e];
                Gt.push({
                    value: t.priceScale + "," + t.minMove + "," + t.frac,
                    content: t.minMove + "/" + t.priceScale
                })
            }
            class Ut extends n.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            setValue: t
                        } = this.context, {
                            minTick: l
                        } = this.props;
                        t(l, e, Ft)
                    }
                }
                render() {
                    const {
                        id: e,
                        minTick: t
                    } = this.props;
                    return n.createElement(B.InputRow, {
                        label: Ht
                    }, n.createElement(be.Select, {
                        id: e,
                        className: te.defaultSelect,
                        menuItemClassName: te.defaultSelectItem,
                        items: Gt,
                        value: t.value(),
                        onChange: this._onChange
                    }))
                }
            }
            Ut.contextType = I.StylePropertyContext;
            var jt = l(55640),
                Yt = l(52830);
            const Kt = (0, s.t)("Outputs");
            class Zt extends n.PureComponent {
                constructor() {
                    super(...arguments), this._findPlotPalettes = e => {
                        const {
                            study: t
                        } = this.props, l = t.metaInfo(), r = (0, o.ensureDefined)(l.palettes);
                        return (0, L.isBarColorerPlot)(e) || (0, L.isBgColorerPlot)(e) ? {
                            main: {
                                palette: r[e.palette],
                                paletteProps: t.properties().palettes[e.palette]
                            }
                        } : this._findPalettesByTargetId(e.id)
                    }
                }
                render() {
                    const {
                        study: e
                    } = this.props, t = e.metaInfo();
                    if ((0, Rt.isCustomStudy)(t.shortId)) return n.createElement(Dt, null);
                    const l = e.properties(),
                        {
                            precision: r,
                            strategy: o,
                            minTick: s,
                            showLabelsOnPriceScale: i,
                            showLegendValues: a
                        } = l,
                        c = t.plots.length > 0,
                        p = t.plots.some(e => !(0, L.isPlotWithTechnicalValues)(e)),
                        d = c || t.inputs.some(e => "price" === e.type),
                        h = (0, jt.createAdapter)(e).canOverrideMinTick();
                    return n.createElement(oe.PropertyTable, null, this._plotsElement(), this._bandsElement(), this._bandsBackgroundsElement(), this._areasBackgroundsElement(), this._filledAreasElement(), this._graphicsElement(), h && n.createElement(Ut, {
                        id: (0, k.createDomId)(t.id, "min-tick-select"),
                        minTick: s
                    }), M().isScriptStrategy(t) && n.createElement(Qe, {
                        orders: o.orders
                    }), (d || p) && n.createElement(oe.PropertyTable.Row, null, n.createElement(oe.PropertyTable.GroupSeparator, {
                        size: 1
                    }), n.createElement(Yt.GroupTitleSection, {
                        title: Kt,
                        name: Kt
                    }), d && n.createElement(Wt, {
                        id: (0, k.createDomId)(t.id, "precision-select"),
                        precision: r
                    }), p && n.createElement(n.Fragment, null, n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "showLabelsOnPriceScale",
                        title: "Labels on price scale",
                        visible: i
                    })), n.createElement(oe.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, n.createElement(N, {
                        id: "showLegendValues",
                        title: "Values in status line",
                        visible: a
                    })))))
                }
                _plotsElement() {
                    const {
                        study: e
                    } = this.props, t = e.metaInfo();
                    return new E.MetaInfoHelper(t).getUserEditablePlots().filter(e => !((0, L.isUpColorerPlot)(e) || (0, L.isDownColorerPlot)(e) || (0, L.isCandleBorderColorerPlot)(e) || (0, L.isCandleWickColorerPlot)(e))).map(t => {
                        const l = (0, L.isOhlcPlot)(t) ? { ...t,
                                id: t.target
                            } : t,
                            r = this._findPlotPalettes(l);
                        return n.createElement(Oe, {
                            key: t.id,
                            plot: t,
                            palettes: r,
                            study: e
                        })
                    })
                }
                _bandsElement() {
                    const {
                        study: e
                    } = this.props, t = e.properties(), {
                        bands: l
                    } = t;
                    return l && l.childNames().map((e, t) => {
                        const r = l.child(e);
                        if (!r.isHidden || !r.isHidden.value()) return n.createElement(qe, {
                            key: t,
                            id: r.name.value(),
                            property: r
                        })
                    })
                }
                _bandsBackgroundsElement() {
                    const {
                        study: e
                    } = this.props, t = e.properties(), {
                        bandsBackground: l
                    } = t;
                    return l && n.createElement(he, {
                        id: "bandsBackground",
                        title: "Background",
                        visible: l.fillBackground,
                        color: l.backgroundColor,
                        transparency: l.transparency
                    })
                }
                _areasBackgroundsElement() {
                    const {
                        study: e
                    } = this.props, t = e.metaInfo(), l = e.properties(), {
                        areaBackground: r
                    } = l;
                    return t.isRGB ? null : r && n.createElement(he, {
                        id: "areaBackground",
                        title: "Background",
                        visible: r.fillBackground,
                        color: r.backgroundColor,
                        transparency: r.transparency
                    })
                }
                _filledAreasElement() {
                    const {
                        study: e
                    } = this.props, t = e.metaInfo(), l = t.filledAreas;
                    return !l || t.isRGB ? [] : l.map(t => {
                        if (t.isHidden) return null;
                        const l = e.properties().filledAreasStyle[t.id],
                            r = t.title || "Background";
                        if (t.palette) {
                            const e = this._findPalettesByTargetId(t.id),
                                r = (0, o.ensureDefined)(e.main);
                            return n.createElement(se, {
                                key: t.id,
                                area: t,
                                palette: (0, o.ensureDefined)(r.palette),
                                paletteProps: (0, o.ensureDefined)(r.paletteProps),
                                styleProp: l
                            })
                        }
                        return n.createElement(he, {
                            key: t.id,
                            id: t.id,
                            title: r,
                            color: l.color,
                            visible: l.visible,
                            transparency: l.transparency
                        })
                    })
                }
                _graphicsElement() {
                    const {
                        study: e
                    } = this.props, t = e.metaInfo().graphics;
                    return t && Object.keys(t).map((t, l) => n.createElement(ct, {
                        key: t,
                        graphicType: t,
                        study: e
                    }))
                }
                _findPalettesByTargetId(e) {
                    const {
                        study: t
                    } = this.props, l = t.metaInfo(), r = l.plots, n = (0, o.ensureDefined)(l.palettes), s = {};
                    for (const l of r)((0, L.isColorerPlot)(l) || (0, L.isOhlcColorerPlot)(l)) && l.target === e && (s.main = {
                        palette: n[l.palette],
                        paletteProps: t.properties().palettes[l.palette]
                    }), (0, L.isUpColorerPlot)(l) && l.target === e && (s.up = {
                        palette: n[l.palette],
                        paletteProps: t.properties().palettes[l.palette]
                    }), (0, L.isDownColorerPlot)(l) && l.target === e && (s.down = {
                        palette: n[l.palette],
                        paletteProps: t.properties().palettes[l.palette]
                    }), (0, L.isCandleWickColorerPlot)(l) && l.target === e && (s.wick = {
                        palette: n[l.palette],
                        paletteProps: t.properties().palettes[l.palette]
                    }), (0, L.isCandleBorderColorerPlot)(l) && l.target === e && (s.border = {
                        palette: n[l.palette],
                        paletteProps: t.properties().palettes[l.palette]
                    });
                    return s
                }
            }

            function qt(e) {
                return (0, I.bindPropertyContext)(Zt, { ...e,
                    property: e.study.properties()
                })
            }
            class Qt extends n.PureComponent {
                render() {
                    return n.createElement(Mt.ModelContext.Provider, {
                        value: this.props.model
                    }, n.createElement(de.Provider, {
                        value: this.props.source
                    }, n.createElement(qt, {
                        study: this.props.source
                    })))
                }
            }
            var Xt = l(38658),
                Jt = l(89014),
                $t = l(53913);
            class el extends Jt.DialogRenderer {
                constructor(e, t, l, n) {
                    super(), this._timeout = null, this._handleClose = () => {
                        r.unmountComponentAtNode(this._container), this._setVisibility(!1), this._subscription.unsubscribe(this, this._handleCollectionChanged)
                    }, this._handleCancel = () => {
                        this._model.undoToCheckpoint(this._checkpoint)
                    }, this._handleSubmit = () => {}, this._handleActiveTabChanged = e => {
                        c.setValue(this._activeTabSettingsName(), e)
                    }, this._source = e, this._model = t, this._propertyPages = n, this._checkpoint = this._ensureCheckpoint(l), this._subscription = this._model.model().dataSourceCollectionChanged(), this._subscription.subscribe(this, this._handleCollectionChanged)
                }
                hide(e) {
                    e ? this._handleCancel() : this._handleSubmit(), this._handleClose()
                }
                isVisible() {
                    return this.visible().value()
                }
                show(e = {}) {
                    if (!p.enabled("property_pages")) return;
                    const t = this._source.metaInfo();
                    if ((0, w.isLineTool)(this._source) && (0, h.trackEvent)("GUI", "Drawing Properties", this._source.name()), (0, b.isStudy)(this._source)) {
                        const e = !this._source.isPine() || this._source.isStandardPine() ? t.description : "Custom Pine";
                        (0, h.trackEvent)("GUI", "Study Properties", e)
                    }
                    let l = {
                        byId: {
                            inputs: {
                                title: (0, s.t)("Inputs"),
                                Component: _
                            },
                            style: {
                                title: (0, s.t)("Style"),
                                Component: Qt
                            }
                        },
                        allIds: []
                    };
                    const o = new E.MetaInfoHelper(t);
                    o.hasUserEditableInputs() && l.allIds.push("inputs"), o.hasUserEditableProperties(), o.hasUserEditableStyles() && l.allIds.push("style"), this._propertyPages || (l.byId.visibilities = {
                        title: (0, s.t)("Visibility"),
                        page: this._createVisibilitiesPropertyPage()
                    }, l.allIds.push("visibilities")), l = this._getPagesForStudyLineTool(l);
                    const i = e.initialTab || c.getValue(this._activeTabSettingsName()) || "inputs";
                    let u = (0, a.clean)(t.shortDescription, !0);
                    r.render(n.createElement(P, {
                        title: u,
                        model: this._model,
                        source: this._source,
                        initialActiveTab: l.allIds.includes(i) ? i : l.allIds[0],
                        pages: l,
                        onSubmit: this._handleSubmit,
                        onCancel: this._handleCancel,
                        onClose: this._handleClose,
                        onActiveTabChanged: this._handleActiveTabChanged
                    }), this._container), this._setVisibility(!0), d.emit("edit_object_dialog", {
                        objectType: "study",
                        scriptTitle: this._source.title()
                    })
                }
                _createVisibilitiesPropertyPage() {
                    const e = this._source.properties().childs().intervalsVisibilities.childs();
                    return (0, Xt.createPropertyPage)((0, $t.getIntervalsVisibilitiesPropertiesDefinitions)(this._model, e, new i.TranslatedString(this._source.name(!0), this._source.title(!0))), "visibility", (0, s.t)("Visibility"))
                }
                _activeTabSettingsName() {
                    return "properties_dialog.active_tab.study"
                }
                _ensureCheckpoint(e) {
                    return void 0 === e && (e = this._model.createUndoCheckpoint()), e
                }
                _getPagesForStudyLineTool(e) {
                    if (this._propertyPages) {
                        const t = this._propertyPages.filter(e => "coordinates" === e.id || "visibility" === e.id),
                            l = {
                                allIds: t.map(e => e.id),
                                byId: t.reduce((e, t) => ({ ...e,
                                    [t.id]: {
                                        title: t.title,
                                        page: t
                                    }
                                }), {})
                            };
                        return {
                            allIds: [...e.allIds, ...l.allIds],
                            byId: { ...e.byId,
                                ...l.byId
                            }
                        }
                    }
                    return e
                }
                _handleCollectionChanged() {
                    null === this._timeout && (this._timeout = setTimeout(() => {
                        this._closeDialogIfSourceIsDeleted(), this._timeout = null
                    }))
                }
                _closeDialogIfSourceIsDeleted() {
                    null === this._model.model().dataSourceForId(this._source.id()) && this._handleClose()
                }
            }
        },
        74609: (e, t, l) => {
            "use strict";
            l.d(t, {
                StudyDefaultsManager: () => u
            });
            var r = l(59496),
                n = l(97754),
                o = l.n(n),
                s = l(72571),
                i = l(25177),
                a = l(99120),
                c = l(92063),
                p = l(98584),
                d = l(84662);
            const h = {
                reset: (0, i.t)("Reset settings"),
                saveAsDefault: (0, i.t)("Save as default"),
                defaults: (0, i.t)("Defaults")
            };
            class u extends r.PureComponent {
                constructor() {
                    super(...arguments), this._handleResetToDefaults = () => {
                        this.props.model.restorePropertiesForSource(this.props.source)
                    }, this._handleSaveAsDefaults = () => {
                        this.props.source.properties().saveDefaults()
                    }
                }
                render() {
                    const {
                        mode: e
                    } = this.props;
                    return r.createElement(a.ControlDisclosure, {
                        id: "study-defaults-manager",
                        className: o()("normal" === e && d.defaultsButtonText),
                        hideArrowButton: "compact" === e,
                        buttonChildren: this._getPlaceHolderItem("compact" === e)
                    }, r.createElement(c.PopupMenuItem, {
                        className: d.defaultsButtonItem,
                        isActive: !1,
                        label: h.reset,
                        onClick: this._handleResetToDefaults
                    }), r.createElement(c.PopupMenuItem, {
                        className: d.defaultsButtonItem,
                        isActive: !1,
                        label: h.saveAsDefault,
                        onClick: this._handleSaveAsDefaults
                    }))
                }
                _getPlaceHolderItem(e) {
                    return e ? r.createElement(s.Icon, {
                        className: d.defaultsButtonIcon,
                        icon: p
                    }) : h.defaults
                }
            }
        },
        94101: (e, t, l) => {
            "use strict";
            l.d(t, {
                FooterMenu: () => d
            });
            var r = l(59496),
                n = l(25177),
                o = l(72571),
                s = l(99120),
                i = l(30052),
                a = l(85623),
                c = l(98584);

            function p(e) {
                return e.isTabletWidth ? r.createElement(o.Icon, {
                    className: a.themesButtonIcon,
                    icon: c
                }) : r.createElement(r.Fragment, null, (0, n.t)("Template"))
            }

            function d(e) {
                return r.createElement(i.MatchMedia, {
                    rule: "screen and (max-width: 768px)"
                }, t => r.createElement(s.ControlDisclosure, {
                    className: !t && a.themesButtonText,
                    hideArrowButton: t,
                    buttonChildren: r.createElement(p, {
                        isTabletWidth: t
                    })
                }, e.children))
            }
        },
        57174: (e, t, l) => {
            "use strict";
            l.d(t, {
                TemplateMenuItem: () => c
            });
            var r = l(59496),
                n = l(92063),
                o = l(72621),
                s = l(21258),
                i = l(72535),
                a = l(85623);

            function c(e) {
                const {
                    name: t,
                    onRemove: l,
                    onClick: c
                } = e, [p, d] = (0, s.useHover)(), h = r.useCallback(() => c(t), [c, t]), u = r.useCallback(() => {
                    l && l(t)
                }, [l, t]);
                return r.createElement("div", { ...d
                }, r.createElement(n.PopupMenuItem, {
                    className: a.defaultsButtonItem,
                    isActive: !1,
                    label: t,
                    onClick: h,
                    toolbox: l && r.createElement(o.RemoveButton, {
                        hidden: !i.mobiletouch && !p,
                        onClick: u
                    })
                }))
            }
        },
        80865: (e, t, l) => {
            "use strict";
            l.d(t, {
                PropertiesEditorTab: () => c
            });
            var r = l(59496),
                n = l(18356);
            const o = {
                    "Elliott Impulse Wave (12345)Degree": "normal",
                    "Elliott Triangle Wave (ABCDE)Degree": "normal",
                    "Elliott Triple Combo Wave (WXYXZ)Degree": "normal",
                    "Elliott Correction Wave (ABC)Degree": "normal",
                    "Elliott Double Combo Wave (WXY)Degree": "normal",
                    BarsPatternMode: "normal",
                    StudyInputSource: "normal"
                },
                s = {
                    TextText: "big",
                    AnchoredTextText: "big",
                    NoteText: "big",
                    AnchoredNoteText: "big",
                    CalloutText: "big",
                    BalloonText: "big"
                };
            var i = l(13143),
                a = l(71102);

            function c(e) {
                const {
                    page: t,
                    pageRef: l,
                    tableKey: c
                } = e;
                return r.createElement(n.ControlCustomHeightContext.Provider, {
                    value: s
                }, r.createElement(n.ControlCustomWidthContext.Provider, {
                    value: o
                }, t && r.createElement(i.PropertyTable, {
                    reference: l,
                    key: c
                }, t.definitions.value().map(e => r.createElement(a.Section, {
                    key: e.id,
                    definition: e
                })))))
            }
        },
        61012: (e, t, l) => {
            "use strict";
            l.d(t, {
                FooterMenu: () => f
            });
            var r = l(59496),
                n = l(79049),
                o = l(1227),
                s = l(25177),
                i = l(18517),
                a = l(94101),
                c = l(57174),
                p = l(17850),
                d = l(53055),
                h = l(53327),
                u = l(18833);
            var m = l(9565);
            const y = (0, n.connect)((function(e, t) {
                    const l = t.source.toolname;
                    return {
                        templates: e.templates[l]
                    }
                }), (function(e) {
                    return {
                        getTemplates: t => e((0, m.getTemplates)(t)),
                        loadTemplate: (t, l, r) => {
                            e((0, m.loadTemplate)(l.toolname, r, e => t.applyLineToolTemplate(l, e, g)))
                        },
                        removeTemplate: (t, l) => e((0, m.startRemoveTemplate)(t, l)),
                        saveTemplate: (t, l, r) => e((0, m.saveTemplate)(t, l, r)),
                        applyDefaults: (t, l) => e((0, m.applyDefaults)(t, l))
                    }
                }))((function(e) {
                    const {
                        model: t,
                        source: l,
                        templates: n = [],
                        getTemplates: o
                    } = e, i = l.toolname;
                    (0, r.useEffect)(() => (e.templates || o(i), () => {}), [i]);
                    const m = (0, r.useContext)(h.SlotContext);
                    return r.createElement(a.FooterMenu, null, r.createElement(c.TemplateMenuItem, {
                        onClick: function() {
                            window.runOrSignIn(() => {
                                (0, d.showRename)({
                                    title: (0, s.t)("Save drawing template as"),
                                    text: (0, s.t)("Template name") + ":",
                                    maxLength: 64,
                                    onRename: ({
                                        newValue: e,
                                        focusInput: t,
                                        dialogClose: l,
                                        innerManager: r
                                    }) => {
                                        if (-1 !== n.indexOf(e)) {
                                            const n = (0, s.t)("Drawing template '{name}' already exists. Do you really want to replace it?").format({
                                                name: e
                                            });
                                            (0, d.showConfirm)({
                                                text: n,
                                                onConfirm: ({
                                                    dialogClose: t
                                                }) => {
                                                    v(e), t(), l()
                                                },
                                                onClose: t
                                            }, r)
                                        } else v(e), l()
                                    }
                                }, m)
                            }, {
                                source: "Save line tool template",
                                sourceMeta: "Chart"
                            })
                        },
                        name: (0, u.appendEllipsis)((0, s.t)("Save as"))
                    }), r.createElement(c.TemplateMenuItem, {
                        onClick: function() {
                            const {
                                applyDefaults: r
                            } = e;
                            r(t, l)
                        },
                        name: (0, s.t)("Apply defaults")
                    }), n.length > 0 && r.createElement(r.Fragment, null, r.createElement(p.PopupMenuSeparator, null), n.map(e => r.createElement(c.TemplateMenuItem, {
                        key: e,
                        name: e,
                        onRemove: y,
                        onClick: g
                    }))));

                    function y(t) {
                        const {
                            removeTemplate: l
                        } = e;
                        window.runOrSignIn(() => {
                            const e = (0, s.t)("Do you really want to delete drawing template '{name}' ?").format({
                                name: t
                            });
                            (0, d.showConfirm)({
                                text: e,
                                onConfirm: ({
                                    dialogClose: e
                                }) => {
                                    l(i, t), e()
                                }
                            }, m)
                        }, {
                            source: "Delete line tool template"
                        })
                    }

                    function g(r) {
                        const {
                            loadTemplate: n
                        } = e;
                        n(t, l, r)
                    }

                    function v(t) {
                        const l = JSON.stringify(e.source.template());
                        e.saveTemplate(i, t, l)
                    }
                })),
                g = new i.TranslatedString("apply drawing template", (0, s.t)("apply drawing template"));
            var v = l(38239);

            function b(e) {
                const {
                    model: t,
                    source: l
                } = e;
                return r.createElement(a.FooterMenu, null, r.createElement(c.TemplateMenuItem, {
                    onClick: function() {
                        t.restorePropertiesForSource(l)
                    },
                    name: (0, s.t)("Apply Defaults")
                }))
            }

            function f(e) {
                return (0, o.onWidget)() ? r.createElement(b, { ...e
                }) : r.createElement(n.Provider, {
                    store: v.store
                }, r.createElement(y, { ...e
                }))
            }
        },
        64730: (e, t, l) => {
            "use strict";
            l.d(t, {
                DialogTabs: () => m
            });
            var r = l(59496),
                n = l(97754),
                o = l(68766),
                s = l(93173),
                i = l(47922);
            const a = (0, s.mergeThemes)(o.DEFAULT_SLIDER_THEME, i);
            var c = l(86746),
                p = l(72535),
                d = l(42545);
            const h = d,
                u = (0, o.factory)((function(e) {
                    return r.createElement("div", {
                        className: a.slider,
                        ref: e.reference
                    }, r.createElement("div", {
                        className: a.inner
                    }))
                }));
            class m extends r.PureComponent {
                constructor() {
                    super(...arguments), this._createClickHandler = e => () => {
                        this.props.onSelect(e)
                    }
                }
                render() {
                    const {
                        theme: e = h,
                        hiddenBottomBorders: t,
                        fadedSlider: l = !0,
                        ScrollComponent: o = c.HorizontalScroll
                    } = this.props, s = this._generateDialogTabs();
                    return r.createElement("div", {
                        className: n(e.scrollWrap)
                    }, !t && r.createElement("div", {
                        className: e.headerBottomSeparator
                    }), r.createElement(o, {
                        isVisibleFade: p.mobiletouch,
                        isVisibleButtons: !p.mobiletouch,
                        isVisibleScrollbar: !1,
                        fadeClassName: n({
                            [e.fadeWithoutSlider]: !l
                        })
                    }, r.createElement("div", {
                        className: e.tabsWrap
                    }, r.createElement(u, {
                        className: n(e.tabs, t && e.withoutBorder)
                    }, s))))
                }
                _generateDialogTabs() {
                    const {
                        activeTabId: e,
                        tabs: t,
                        theme: l = h
                    } = this.props;
                    return t.allIds.map(s => {
                        const i = e === s,
                            a = t.byId[s].withNotificationsBadge;
                        return r.createElement(o.SliderItem, {
                            key: s,
                            value: s,
                            className: n(l.tab, !i && l.withHover, a && d.withBadge),
                            isActive: i,
                            onClick: this._createClickHandler(s)
                        }, t.byId[s].title)
                    })
                }
            }
        },
        86746: (e, t, l) => {
            "use strict";
            l.d(t, {
                HorizontalScroll: () => f
            });
            var r = l(59496),
                n = l(97754),
                o = l(7270),
                s = l(88537),
                i = l(72571),
                a = l(42609),
                c = l(85787),
                p = l(34581),
                d = l(86219),
                h = l(41814);
            const u = {
                isVisibleScrollbar: !0,
                shouldMeasure: !0,
                hideButtonsFrom: 1
            };

            function m(e) {
                return r.createElement("div", {
                    className: n(h.fadeLeft, e.className, {
                        [h.isVisible]: e.isVisible
                    })
                })
            }

            function y(e) {
                return r.createElement("div", {
                    className: n(h.fadeRight, e.className, {
                        [h.isVisible]: e.isVisible
                    })
                })
            }

            function g(e) {
                return r.createElement(b, { ...e,
                    className: h.scrollLeft
                })
            }

            function v(e) {
                return r.createElement(b, { ...e,
                    className: h.scrollRight
                })
            }

            function b(e) {
                return r.createElement("div", {
                    className: n(e.className, {
                        [h.isVisible]: e.isVisible
                    }),
                    onClick: e.onClick
                }, r.createElement("div", {
                    className: h.iconWrap
                }, r.createElement(i.Icon, {
                    icon: d,
                    className: h.icon
                })))
            }
            const f = function(e = g, t = v, l = m, i = y) {
                var d;
                return (d = class extends r.PureComponent {
                    constructor(e) {
                        super(e), this._scroll = r.createRef(), this._wrapMeasureRef = r.createRef(), this._contentMeasureRef = r.createRef(), this._handleScrollLeft = () => {
                            if (this.props.onScrollButtonClick) return void this.props.onScrollButtonClick("left");
                            const e = this.props.scrollStepSize || this.state.widthWrap - 50;
                            this.animateTo(Math.max(0, this.currentPosition() - e))
                        }, this._handleScrollRight = () => {
                            if (this.props.onScrollButtonClick) return void this.props.onScrollButtonClick("right");
                            const e = this.props.scrollStepSize || this.state.widthWrap - 50;
                            this.animateTo(Math.min((this.state.widthContent || 0) - (this.state.widthWrap || 0), this.currentPosition() + e))
                        }, this._handleResizeWrap = e => {
                            this.props.onMeasureWrap && this.props.onMeasureWrap(e), this.setState({
                                widthWrap: e.width
                            }), this._checkButtonsVisibility()
                        }, this._handleResizeContent = e => {
                            this.props.onMeasureContent && this.props.onMeasureContent(e);
                            const {
                                shouldDecreaseWidthContent: t,
                                buttonsWidthIfDecreasedWidthContent: l
                            } = this.props;
                            t && l ? this.setState({
                                widthContent: e.width + 2 * l
                            }) : this.setState({
                                widthContent: e.width
                            })
                        }, this._handleScroll = () => {
                            const {
                                onScroll: e
                            } = this.props;
                            e && e(this.currentPosition(), this.isAtLeft(), this.isAtRight()), this._checkButtonsVisibility()
                        }, this._checkButtonsVisibility = () => {
                            const {
                                isVisibleLeftButton: e,
                                isVisibleRightButton: t
                            } = this.state, l = this.isAtLeft(), r = this.isAtRight();
                            l || e ? l && e && this.setState({
                                isVisibleLeftButton: !1
                            }) : this.setState({
                                isVisibleLeftButton: !0
                            }), r || t ? r && t && this.setState({
                                isVisibleRightButton: !1
                            }) : this.setState({
                                isVisibleRightButton: !0
                            })
                        }, this.state = {
                            widthContent: 0,
                            widthWrap: 0,
                            isVisibleRightButton: !1,
                            isVisibleLeftButton: !1
                        }
                    }
                    componentDidMount() {
                        this._checkButtonsVisibility()
                    }
                    componentDidUpdate(e, t) {
                        t.widthWrap === this.state.widthWrap && t.widthContent === this.state.widthContent || this._handleScroll(), this.props.shouldMeasure && this._wrapMeasureRef.current && this._contentMeasureRef.current && (this._wrapMeasureRef.current.measure(), this._contentMeasureRef.current.measure())
                    }
                    currentPosition() {
                        return this._scroll.current ? (0, p.isRtl)() ? (0, p.getLTRScrollLeft)(this._scroll.current) : this._scroll.current.scrollLeft : 0
                    }
                    isAtLeft() {
                        return !this._isOverflowed() || this.currentPosition() <= (0, s.ensureDefined)(this.props.hideButtonsFrom)
                    }
                    isAtRight() {
                        return !this._isOverflowed() || this.currentPosition() + this.state.widthWrap >= this.state.widthContent - (0, s.ensureDefined)(this.props.hideButtonsFrom)
                    }
                    animateTo(e, t = c.dur) {
                        const l = this._scroll.current;
                        l && ((0, p.isRtl)() && (e = (0, p.getLTRScrollLeftOffset)(l, e)), t <= 0 ? l.scrollLeft = Math.round(e) : (0, a.doAnimate)({
                            onStep(e, t) {
                                l.scrollLeft = Math.round(t)
                            },
                            from: l.scrollLeft,
                            to: Math.round(e),
                            easing: c.easingFunc.easeInOutCubic,
                            duration: t
                        }))
                    }
                    render() {
                        const {
                            children: s,
                            isVisibleScrollbar: a,
                            isVisibleFade: c,
                            isVisibleButtons: p,
                            shouldMeasure: d,
                            shouldDecreaseWidthContent: u,
                            buttonsWidthIfDecreasedWidthContent: m,
                            onMouseOver: y,
                            onMouseOut: g,
                            scrollWrapClassName: v,
                            fadeClassName: b
                        } = this.props, {
                            isVisibleRightButton: f,
                            isVisibleLeftButton: w
                        } = this.state, S = u && m;
                        return r.createElement(o, {
                            whitelist: ["width"],
                            onMeasure: this._handleResizeWrap,
                            shouldMeasure: d,
                            ref: this._wrapMeasureRef
                        }, r.createElement("div", {
                            className: h.wrapOverflow,
                            onMouseOver: y,
                            onMouseOut: g
                        }, r.createElement("div", {
                            className: n(h.wrap, S ? h.wrapWithArrowsOuting : "")
                        }, r.createElement("div", {
                            className: n(h.scrollWrap, v, {
                                [h.noScrollBar]: !a
                            }),
                            onScroll: this._handleScroll,
                            ref: this._scroll
                        }, r.createElement(o, {
                            onMeasure: this._handleResizeContent,
                            whitelist: ["width"],
                            shouldMeasure: d,
                            ref: this._contentMeasureRef
                        }, s)), c && r.createElement(l, {
                            isVisible: w,
                            className: b
                        }), c && r.createElement(i, {
                            isVisible: f,
                            className: b
                        }), p && r.createElement(e, {
                            onClick: this._handleScrollLeft,
                            isVisible: w
                        }), p && r.createElement(t, {
                            onClick: this._handleScrollRight,
                            isVisible: f
                        }))))
                    }
                    _isOverflowed() {
                        const {
                            widthContent: e,
                            widthWrap: t
                        } = this.state;
                        return e > t
                    }
                }).defaultProps = u, d
            }(g, v, m, y)
        },
        68766: (e, t, l) => {
            "use strict";
            l.d(t, {
                DEFAULT_SLIDER_THEME: () => i,
                SliderItem: () => a,
                factory: () => c,
                SliderRow: () => p
            });
            var r = l(59496),
                n = l(97754),
                o = l(88537),
                s = l(37740);
            const i = s;

            function a(e) {
                const t = n(e.className, s.tab, {
                    [s.active]: e.isActive,
                    [s.disabled]: e.isDisabled,
                    [s.defaultCursor]: !!e.shouldUseDefaultCursor,
                    [s.noBorder]: !!e.noBorder
                });
                return r.createElement("div", {
                    className: t,
                    onClick: e.onClick,
                    ref: e.reference,
                    "data-type": "tab-item",
                    "data-value": e.value,
                    "data-name": "tab-item-" + e.value.toString().toLowerCase()
                }, e.children)
            }

            function c(e) {
                return class extends r.PureComponent {
                    constructor() {
                        super(...arguments), this.activeTab = {
                            current: null
                        }
                    }
                    componentDidUpdate() {
                        (0, o.ensureNotNull)(this._slider).style.transition = "transform 350ms", this._componentDidUpdate()
                    }
                    componentDidMount() {
                        this._componentDidUpdate()
                    }
                    render() {
                        const {
                            className: t
                        } = this.props, l = this._generateTabs();
                        return r.createElement("div", {
                            className: n(t, s.tabs),
                            "data-name": this.props["data-name"]
                        }, l, r.createElement(e, {
                            reference: e => {
                                this._slider = e
                            }
                        }))
                    }
                    _generateTabs() {
                        return this.activeTab.current = null, r.Children.map(this.props.children, e => {
                            const t = e,
                                l = Boolean(t.props.isActive),
                                n = {
                                    reference: e => {
                                        l && (this.activeTab.current = e), t.props.reference && t.props.reference(e)
                                    }
                                };
                            return r.cloneElement(t, n)
                        })
                    }
                    _componentDidUpdate() {
                        const e = (0, o.ensureNotNull)(this._slider).style;
                        if (this.activeTab.current) {
                            const t = this.activeTab.current.offsetWidth,
                                l = this.activeTab.current.offsetLeft;
                            e.transform = `translateX(${l}px)`, e.width = t + "px", e.opacity = "1"
                        } else e.opacity = "0"
                    }
                }
            }
            const p = c((function(e) {
                return r.createElement("div", {
                    className: s.slider,
                    ref: e.reference
                })
            }))
        },
        86219: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 10" width="20" height="10"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 1l8 8 8-8"/></svg>'
        },
        56514: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M14 21l7.424-6.114a.5.5 0 0 0-.318-.886H18.5V7h-9v7H6.894a.5.5 0 0 0-.318.886L14 21z"/></svg>'
        },
        25115: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M14 7l7.424 6.114a.5.5 0 0 1-.318.886H18.5v7h-9v-7H6.894a.5.5 0 0 1-.318-.886L14 7z"/></svg>'
        },
        1038: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><circle stroke="currentColor" cx="14" cy="14" r="6.5"/></svg>'
        },
        38074: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path stroke="currentColor" d="M9 14.5h11M14.5 20V9"/></svg>'
        },
        66438: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M14.354 6.646L14 6.293l-.354.353-7 7-.353.354.353.354 7 7 .354.353.354-.353 7-7 .353-.354-.353-.354-7-7z"/></svg>'
        },
        43469: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8.5 22v-5.5m0 0v-8L12 7l4 2.5 3.5-1v8l-3.5 1-4-2.5-3.5 1.5z"/></svg>'
        },
        29634: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M11 8.5h-.5v9.707l.146.147 3 3 .354.353.354-.353 3-3 .146-.147V8.5H11z"/></svg>'
        },
        49461: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M11 18.5h-.5V8.793l.146-.147 3-3L14 5.293l.354.353 3 3 .146.147V18.5H11z"/></svg>'
        },
        16925: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M7.5 7.5h13v13h-13z"/></svg>'
        },
        12465: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M19.424 11.265l.478-.765H8.098l.478.765 5 8 .424.678.424-.678 5-8z"/></svg>'
        },
        41038: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M19.424 16.735l.478.765H8.098l.478-.765 5-8L14 8.057l.424.678 5 8z"/></svg>'
        },
        747: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path stroke="currentColor" d="M9 9l11 11M9 20L20 9"/></svg>'
        },
        13790: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M13 11.5l-1.915-1.532a1 1 0 0 0-1.198-.039l-3.96 2.772a1 1 0 0 0-.427.82V18.5a1 1 0 0 0 1 1H13m3.5-7l4.293-4.293c.63-.63 1.707-.184 1.707.707V18.5a1 1 0 0 1-1 1H16"/><path fill="currentColor" d="M14 6h1v2h-1zM14 11h1v2h-1zM14 16h1v2h-1zM14 21h1v2h-1z"/></svg>'
        },
        16616: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 13.52v4.98a1 1 0 0 0 1 1h15a1 1 0 0 0 1-1V8.914c0-.89-1.077-1.337-1.707-.707l-4.66 4.66a1 1 0 0 1-1.332.074l-3.716-2.973a1 1 0 0 0-1.198-.039l-3.96 2.772a1 1 0 0 0-.427.82z"/></svg>'
        },
        66647: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M10.5 13a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0zM16.5 19a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0zM22.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/></svg>'
        },
        58061: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M6.5 12.5v8h3v-8h-3zM12.5 7.5v13h3v-13h-3zM18.5 15.5v5h3v-5h-3z"/></svg>'
        },
        29422: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path stroke="currentColor" d="M17 8.5h7M20.5 12V5M10 19.5h7M13.5 23v-7M3 12.5h7M6.5 16V9"/></svg>'
        },
        95621: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path stroke="currentColor" d="M4.5 20v-7m3 7V10m3 10V8m3 12V10m3 10v-8m3 8V10m3 10V8"/></svg>'
        },
        23181: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 16.5l5-5a1.414 1.414 0 0 1 2 0m11-1l-5 5a1.414 1.414 0 0 1-2 0"/><path fill="currentColor" d="M14 5h1v2h-1zM14 10h1v2h-1zM14 15h1v2h-1zM14 20h1v2h-1z"/></svg>'
        },
        69047: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 16.5l4.586-4.586a2 2 0 0 1 2.828 0l3.172 3.172a2 2 0 0 0 2.828 0L23.5 10.5"/></svg>'
        },
        51494: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" d="M9.8 2.7l.7-.7.7.7 2.1 2.1.2.2H18v9.5l.2.2 2.1 2.1.2.2H24v1h-3.5l-.2.2-2.1 2.1-.7.7-.7-.7-2.1-2.1-.7-.7.7-.7 2.1-2.1.2-.2V6h-3.5l-.2.2-2.1 2.1-.2.2V24H5.5v-1H10V8.5l-.2-.2-2.1-2.1-.7-.7.7-.7 2.1-2.1zM8.4 5.5l2.09 2.09 2.09-2.09-2.09-2.09L8.41 5.5zm9.09 14.09l-2.09-2.09 2.09-2.09 2.09 2.09-2.09 2.09z"/></svg>'
        },
        70153: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 17v5.5h4v-18h4v12h4v-9h4V21"/></svg>'
        }
    }
]);
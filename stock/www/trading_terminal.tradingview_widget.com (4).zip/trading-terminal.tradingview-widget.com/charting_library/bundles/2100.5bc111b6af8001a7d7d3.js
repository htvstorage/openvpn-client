(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2100], {
        37593: e => {
            e.exports = {
                wrapper: "wrapper-5Xd5conM",
                input: "input-5Xd5conM",
                box: "box-5Xd5conM",
                icon: "icon-5Xd5conM",
                noOutline: "noOutline-5Xd5conM",
                "intent-danger": "intent-danger-5Xd5conM",
                check: "check-5Xd5conM",
                dot: "dot-5Xd5conM"
            }
        },
        96670: e => {
            e.exports = {
                checkbox: "checkbox-GxG6nBa7",
                reverse: "reverse-GxG6nBa7",
                label: "label-GxG6nBa7",
                baseline: "baseline-GxG6nBa7"
            }
        },
        33588: e => {
            e.exports = {
                "icon-size": "18px",
                wrapper: "wrapper-tRWJvmIi",
                help: "help-tRWJvmIi"
            }
        },
        73992: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                menuButton: "menuButton-Fu0IL4Qw",
                select: "select-Fu0IL4Qw",
                selectMenu: "selectMenu-Fu0IL4Qw",
                title: "title-Fu0IL4Qw",
                titleWithError: "titleWithError-Fu0IL4Qw"
            }
        },
        74545: e => {
            e.exports = {
                icon: "icon-7SFmYgD6",
                button: "button-7SFmYgD6",
                wrapper: "wrapper-7SFmYgD6",
                infoContainer: "infoContainer-7SFmYgD6",
                title: "title-7SFmYgD6",
                link: "link-7SFmYgD6",
                text: "text-7SFmYgD6"
            }
        },
        82506: e => {
            e.exports = {
                delayedDataTitleColor: "#F57C00",
                batsQuotesTitleColor: "#C2185B",
                header: "header-x4Cr5IeU",
                wrapper: "wrapper-x4Cr5IeU",
                text: "text-x4Cr5IeU",
                button: "button-x4Cr5IeU",
                settingsButton: "settingsButton-x4Cr5IeU button-x4Cr5IeU",
                settingsPopupMenu: "settingsPopupMenu-x4Cr5IeU",
                delayedDataIcon: "delayedDataIcon-x4Cr5IeU",
                batsQuotesIcon: "batsQuotesIcon-x4Cr5IeU"
            }
        },
        55576: e => {
            e.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        64547: e => {
            e.exports = {
                button: "button-SS83RYhy"
            }
        },
        71123: e => {
            e.exports = {
                button: "button-khcLBZEz",
                hover: "hover-khcLBZEz",
                arrow: "arrow-khcLBZEz",
                arrowWrap: "arrowWrap-khcLBZEz",
                newStyles: "newStyles-khcLBZEz",
                isOpened: "isOpened-khcLBZEz"
            }
        },
        66230: e => {
            e.exports = {
                button: "button-h8C3IU2n",
                "button-children": "button-children-h8C3IU2n",
                hiddenArrow: "hiddenArrow-h8C3IU2n",
                invisibleFocusHandler: "invisibleFocusHandler-h8C3IU2n"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        99171: e => {
            e.exports = {
                button: "button-1ARG85Og",
                disabled: "disabled-1ARG85Og",
                hidden: "hidden-1ARG85Og",
                icon: "icon-1ARG85Og",
                dropped: "dropped-1ARG85Og"
            }
        },
        79756: e => {
            e.exports = {
                placeholder: "placeholder-fKHYe1Lk"
            }
        },
        91998: e => {
            e.exports = {
                checkbox: "checkbox-HU5RMv36"
            }
        },
        40367: e => {
            e.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        8323: (e, t, n) => {
            "use strict";
            n.d(t, {
                CheckboxInput: () => c
            });
            var o = n(59496),
                r = n(97754),
                s = n(72571),
                i = n(57369),
                a = n(37593),
                l = n.n(a);

            function c(e) {
                const t = r(l().box, l()["intent-" + e.intent], {
                        [l().check]: !Boolean(e.indeterminate),
                        [l().dot]: Boolean(e.indeterminate),
                        [l().noOutline]: -1 === e.tabIndex
                    }),
                    n = r(l().wrapper, e.className);
                return o.createElement("span", {
                    className: n,
                    title: e.title
                }, o.createElement("input", {
                    id: e.id,
                    tabIndex: e.tabIndex,
                    className: l().input,
                    type: "checkbox",
                    name: e.name,
                    checked: e.checked,
                    disabled: e.disabled,
                    value: e.value,
                    autoFocus: e.autoFocus,
                    role: e.role,
                    onChange: function() {
                        e.onChange && e.onChange(e.value)
                    },
                    ref: e.reference
                }), o.createElement("span", {
                    className: t
                }, o.createElement(s.Icon, {
                    icon: i,
                    className: l().icon
                })))
            }
        },
        2946: (e, t, n) => {
            "use strict";
            n.d(t, {
                Checkbox: () => c
            });
            var o = n(59496),
                r = n(97754),
                s = n(32834),
                i = n(8323),
                a = n(96670),
                l = n.n(a);
            class c extends o.PureComponent {
                render() {
                    const {
                        inputClassName: e,
                        labelClassName: t,
                        ...n
                    } = this.props, s = r(this.props.className, l().checkbox, {
                        [l().reverse]: Boolean(this.props.labelPositionReverse),
                        [l().baseline]: Boolean(this.props.labelAlignBaseline)
                    }), a = r(l().label, t, {
                        [l().disabled]: this.props.disabled
                    });
                    let c = null;
                    return this.props.label && (c = o.createElement("span", {
                        className: a,
                        title: this.props.title
                    }, this.props.label)), o.createElement("label", {
                        className: s
                    }, o.createElement(i.CheckboxInput, { ...n,
                        className: e
                    }), c)
                }
            }
            c.defaultProps = {
                value: "on"
            };
            (0, s.makeSwitchGroupItem)(c)
        },
        32834: (e, t, n) => {
            "use strict";
            n.d(t, {
                SwitchGroup: () => s,
                makeSwitchGroupItem: () => i
            });
            var o = n(59496),
                r = n(19036);
            class s extends o.PureComponent {
                constructor() {
                    super(...arguments), this._subscriptions = new Set, this._getName = () => this.props.name, this._getValues = () => this.props.values, this._getOnChange = () => this.props.onChange, this._subscribe = e => {
                        this._subscriptions.add(e)
                    }, this._unsubscribe = e => {
                        this._subscriptions.delete(e)
                    }
                }
                getChildContext() {
                    return {
                        switchGroupContext: {
                            getName: this._getName,
                            getValues: this._getValues,
                            getOnChange: this._getOnChange,
                            subscribe: this._subscribe,
                            unsubscribe: this._unsubscribe
                        }
                    }
                }
                render() {
                    return this.props.children
                }
                componentDidUpdate(e) {
                    this._notify(this._getUpdates(this.props.values, e.values))
                }
                _notify(e) {
                    this._subscriptions.forEach(t => t(e))
                }
                _getUpdates(e, t) {
                    return [...t, ...e].filter(n => t.includes(n) ? !e.includes(n) : e.includes(n))
                }
            }

            function i(e) {
                var t;
                return (t = class extends o.PureComponent {
                    constructor() {
                        super(...arguments), this._onChange = e => {
                            this.context.switchGroupContext.getOnChange()(e)
                        }, this._onUpdate = e => {
                            e.includes(this.props.value) && this.forceUpdate()
                        }
                    }
                    componentDidMount() {
                        this.context.switchGroupContext.subscribe(this._onUpdate)
                    }
                    render() {
                        return o.createElement(e, { ...this.props,
                            name: this._getName(),
                            onChange: this._onChange,
                            checked: this._isChecked()
                        })
                    }
                    componentWillUnmount() {
                        this.context.switchGroupContext.unsubscribe(this._onUpdate)
                    }
                    _getName() {
                        return this.context.switchGroupContext.getName()
                    }
                    _isChecked() {
                        return this.context.switchGroupContext.getValues().includes(this.props.value)
                    }
                }).contextTypes = {
                    switchGroupContext: r.any.isRequired
                }, t
            }
            s.childContextTypes = {
                switchGroupContext: r.any.isRequired
            }
        },
        14823: (e, t, n) => {
            "use strict";
            n.d(t, {
                createDomId: () => l,
                joinDomIds: () => c
            });
            const o = /\s/g;

            function r(e) {
                return "string" == typeof e
            }

            function s(e) {
                switch (typeof e) {
                    case "string":
                        return e;
                    case "number":
                    case "bigint":
                        return e.toString(10);
                    case "boolean":
                    case "symbol":
                        return e.toString();
                    default:
                        return null
                }
            }

            function i(e) {
                return e.trim().length > 0
            }

            function a(e) {
                return e.replace(o, "-")
            }

            function l(...e) {
                const t = e.map(s).filter(r).filter(i).map(a);
                return (t.length > 0 && t[0].startsWith("id_") ? t : ["id", ...t]).join("_")
            }

            function c(...e) {
                return e.map(s).filter(r).filter(i).join(" ")
            }
        },
        49688: (e, t, n) => {
            "use strict";
            n.d(t, {
                CheckboxCustomField: () => d
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(2946),
                a = n(72571),
                l = n(1317),
                c = n(33588),
                u = n(31616);

            function d(e) {
                const {
                    title: t,
                    help: n,
                    disabled: r,
                    checked: d,
                    onControlFocused: h
                } = e, [p, m] = (0, l.useWatchedValue)(d);
                return o.createElement("div", {
                    className: c.wrapper,
                    onFocus: function() {
                        null == h || h.fire()
                    }
                }, o.createElement(i.Checkbox, {
                    label: t,
                    checked: p,
                    onChange: function() {
                        m(!p)
                    },
                    disabled: r
                }), void 0 !== n && "" !== n && o.createElement(a.Icon, {
                    icon: u,
                    className: s()("apply-common-tooltip", c.help),
                    title: n
                }))
            }
        },
        87374: (e, t, n) => {
            "use strict";
            n.d(t, {
                CustomComboboxContainer: () => f
            });
            var o = n(59496),
                r = n(25177),
                s = n(97754),
                i = n.n(s),
                a = n(1227),
                l = n(36118),
                c = n(61428),
                u = n(69842),
                d = n(28606);
            const h = o.forwardRef((e, t) => {
                var n;
                const {
                    intent: r,
                    onFocus: s,
                    onBlur: i,
                    onMouseOver: a,
                    onMouseOut: h,
                    hasErrors: p,
                    hasWarnings: m,
                    errors: b,
                    warnings: g,
                    alwaysShowAttachedErrors: f,
                    messagesPosition: v,
                    messagesAttachment: C,
                    inheritMessagesWidthFromTarget: x,
                    ...w
                } = e, E = (0, c.useControlValidationLayout)({
                    hasErrors: p,
                    hasWarnings: m,
                    errors: b,
                    warnings: g,
                    alwaysShowAttachedErrors: f,
                    messagesPosition: v,
                    messagesAttachment: C,
                    iconHidden: !0,
                    inheritMessagesWidthFromTarget: x
                }), k = (0, u.createSafeMulticastEventHandler)(s, E.onFocus), S = (0, u.createSafeMulticastEventHandler)(i, E.onBlur), D = (0, u.createSafeMulticastEventHandler)(a, E.onMouseOver), I = (0, u.createSafeMulticastEventHandler)(h, E.onMouseOut);
                return o.createElement(o.Fragment, null, o.createElement(l.Select, { ...w,
                    intent: null !== (n = E.intent) && void 0 !== n ? n : r,
                    onFocus: k,
                    onBlur: S,
                    onMouseOver: D,
                    onMouseOut: I,
                    ref: (0, d.useMergedRefs)([E.containerReference, t])
                }), E.renderedErrors)
            });
            h.displayName = "FormSelect";
            var p = n(92063),
                m = n(34816),
                b = n(73992);

            function g(e) {
                const {
                    items: t,
                    forceUserToSelectValue: n,
                    alwaysShowAttachedErrors: s,
                    selectedItem: l,
                    disabled: u,
                    title: d,
                    onClick: g,
                    onItemSelected: f,
                    onClose: v
                } = e, C = (0, o.useMemo)(() => function(e) {
                    return e.map(e => ({
                        value: e.value,
                        content: e.text
                    }))
                }(t), [t]), x = (0, o.useMemo)(() => Object.values(C).map((e, t) => {
                    var n;
                    return o.createElement(p.PopupMenuItem, {
                        key: e.value,
                        label: null !== (n = e.content) && void 0 !== n ? n : e.value,
                        onClickArg: t,
                        onClick: S
                    })
                }), [C]), w = void 0 === l && n, E = o.createElement(h, {
                    value: l,
                    items: C,
                    className: b.select,
                    menuClassName: b.selectMenu,
                    onClick: function() {
                        void 0 !== g && g()
                    },
                    onChange: function(e) {
                        f(e)
                    },
                    disabled: u,
                    placeholder: void 0 === l ? (0, r.t)("Select value") : void 0,
                    addPlaceholderToItems: !1,
                    hasErrors: w,
                    messagesPosition: c.MessagesPosition.Static,
                    inheritMessagesWidthFromTarget: !0,
                    hideArrowButton: C.length <= 1,
                    stretch: !0,
                    alwaysShowAttachedErrors: s && w,
                    matchButtonAndListboxWidths: !0
                });
                return o.createElement(o.Fragment, null, o.createElement("div", {
                    className: i()(b.title, w && b.titleWithError)
                }, w ? (0, r.t)("{fieldTitle} (required)", {
                    replace: {
                        fieldTitle: String(d)
                    }
                }) : d), a.CheckMobile.any() ? o.createElement(m.ToolWidgetMenu, {
                    className: b.menuButton,
                    content: E,
                    children: x,
                    arrow: !1,
                    onClose: k,
                    isDrawer: !0,
                    closeOnClickOutside: !0
                }) : E);

                function k() {
                    void 0 !== v && v()
                }

                function S(e) {
                    f(t[e || 0].value), k()
                }
            }
            class f extends o.PureComponent {
                constructor(e) {
                    super(e),
                        this._onItemSelected = e => {
                            this.props.selectedItem.setValue(e)
                        }, this._onClick = () => {
                            this.props.onControlFocused && this.props.onControlFocused.fire()
                        }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this.props.selectedItem.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.props.selectedItem.unsubscribe(this._callback)
                }
                render() {
                    return o.createElement(g, {
                        title: this.props.title,
                        items: this.props.items,
                        selectedItem: this.props.selectedItem.value(),
                        onItemSelected: this._onItemSelected,
                        disabled: this.props.disabled,
                        onClick: this._onClick,
                        onClose: this.props.onClose,
                        forceUserToSelectValue: this.props.forceUserToSelectValue,
                        alwaysShowAttachedErrors: this.props.alwaysShowAttachedErrors
                    })
                }
            }
        },
        26909: (e, t, n) => {
            "use strict";
            n.d(t, {
                Header: () => M
            });
            var o = n(25177),
                r = n(72571),
                s = n(59496),
                i = n(97754),
                a = n.n(i),
                l = n(30052),
                c = n(34816),
                u = n(5710),
                d = n(96038),
                h = n(96796),
                p = n(63111),
                m = n(12334),
                b = n(85673),
                g = n(74545);

            function f(e) {
                const {
                    icon: t,
                    iconClassName: n,
                    title: o,
                    titleColor: i,
                    text: l,
                    solutionId: u
                } = e;
                return s.createElement(c.ToolWidgetMenu, {
                    arrow: !1,
                    content: s.createElement(r.Icon, {
                        icon: t
                    }),
                    className: a()(g.icon, g.button, n),
                    drawerBreakpoint: m.TradingLayoutBreakpoint.Mobile,
                    title: o,
                    horizontalAttachEdge: b.HorizontalAttachEdge.Right,
                    horizontalDropDirection: b.HorizontalDropDirection.FromRightToLeft
                }, s.createElement("div", {
                    className: g.wrapper
                }, s.createElement(r.Icon, {
                    icon: t,
                    className: a()(g.icon, n)
                }), s.createElement("div", {
                    className: g.infoContainer
                }, s.createElement("span", {
                    className: g.title,
                    style: {
                        color: i
                    }
                }, o), s.createElement("span", {
                    className: g.text
                }, l), !1)))
            }
            var v = n(88902),
                C = n(25118),
                x = n(79810),
                w = n(55702),
                E = n(12142),
                k = n(74300),
                S = n(82506);
            const D = (0, o.t)("Cboe BZX"),
                I = (0, h.htmlEscape)((0, o.t)("{exchange} by {originalExchange}")),
                N = (0, h.htmlEscape)((0, o.t)("Real-time data for {symbolName} is provided by {exchange} exchange.")),
                y = (0, h.htmlEscape)((0, o.t)("This data is real-time, but it’s slightly different to its official counterpart coming from {exchange}."));
            class M extends s.PureComponent {
                render() {
                    const e = this.context.mode === p.OrderEditorDisplayMode.Popup ? {
                        "data-dragg-area": !0
                    } : {};
                    let t;
                    if (this.props.hasDelayedWarning && (t = {
                            icon: E,
                            iconClassName: S.delayedDataIcon,
                            title: (0, o.t)("Delayed data"),
                            titleColor: S.delayedDataTitleColor,
                            text: this.props.delayedWarningMessage
                        }), this.props.hasBatsQuotes) {
                        const [e, n] = this.props.symbol.split(":"), o = `${N.replace("{symbolName}",n).replace("{exchange}",D)} ${y.replace("{exchange}",e)}`;
                        t = {
                            icon: k,
                            iconClassName: S.batsQuotesIcon,
                            title: I.format({
                                exchange: e,
                                originalExchange: D
                            }),
                            titleColor: S.batsQuotesTitleColor,
                            text: o,
                            solutionId: 43000473924
                        }
                    }
                    return s.createElement("div", {
                        className: i(S.header, this.props.className)
                    }, this.props.hasBackButton && s.createElement(u.ToolWidgetIconButton, {
                        title: (0, o.t)("Back"),
                        onClick: this.props.back,
                        className: S.button,
                        "data-name": "button-back",
                        icon: v
                    }), s.createElement("div", {
                        className: S.wrapper,
                        ...e
                    }, s.createElement("span", {
                        className: S.text
                    }, this.props.title, this.props.description)), void 0 !== t && s.createElement(f, { ...t
                    }), this.props.hasCancelButton && s.createElement(u.ToolWidgetIconButton, {
                        title: (0,
                            o.t)("Cancel"),
                        onClick: this.props.cancel,
                        className: S.button,
                        "data-name": "button-cancel",
                        icon: C
                    }), 0 !== s.Children.count(this.props.settingsItems) && s.createElement(l.MatchMedia, {
                        rule: d.DialogBreakpoints.TabletSmall
                    }, e => s.createElement(c.ToolWidgetMenu, {
                        className: S.settingsButton,
                        content: s.createElement(r.Icon, {
                            icon: w
                        }),
                        menuClassName: S.settingsPopupMenu,
                        children: this.props.settingsItems,
                        isDrawer: e,
                        title: (0, o.t)("Settings"),
                        arrow: !1,
                        closeOnClickOutside: !0,
                        "data-name": "order-ticket-settings"
                    })), this.props.hasCloseButton && s.createElement(u.ToolWidgetIconButton, {
                        title: (0, o.t)("Close", {
                            context: "input"
                        }),
                        onClick: this.props.close,
                        className: S.button,
                        "data-name": "button-close",
                        icon: x
                    }))
                }
            }
            M.contextType = p.Context
        },
        85673: (e, t, n) => {
            "use strict";
            n.d(t, {
                VerticalAttachEdge: () => o,
                HorizontalAttachEdge: () => r,
                VerticalDropDirection: () => s,
                HorizontalDropDirection: () => i,
                getPopupPositioner: () => c
            });
            var o, r, s, i, a = n(88537);
            ! function(e) {
                e[e.Top = 0] = "Top", e[e.Bottom = 1] = "Bottom"
            }(o || (o = {})),
            function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(r || (r = {})),
            function(e) {
                e[e.FromTopToBottom = 0] = "FromTopToBottom", e[e.FromBottomToTop = 1] = "FromBottomToTop"
            }(s || (s = {})),
            function(e) {
                e[e.FromLeftToRight = 0] = "FromLeftToRight", e[e.FromRightToLeft = 1] = "FromRightToLeft"
            }(i || (i = {}));
            const l = {
                verticalAttachEdge: o.Bottom,
                horizontalAttachEdge: r.Left,
                verticalDropDirection: s.FromTopToBottom,
                horizontalDropDirection: i.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function c(e, t) {
                return (n, c) => {
                    const u = (0, a.ensureNotNull)(e).getBoundingClientRect(),
                        {
                            verticalAttachEdge: d = l.verticalAttachEdge,
                            verticalDropDirection: h = l.verticalDropDirection,
                            horizontalAttachEdge: p = l.horizontalAttachEdge,
                            horizontalDropDirection: m = l.horizontalDropDirection,
                            horizontalMargin: b = l.horizontalMargin,
                            verticalMargin: g = l.verticalMargin,
                            matchButtonAndListboxWidths: f = l.matchButtonAndListboxWidths
                        } = t,
                        v = d === o.Top ? -1 * g : g,
                        C = p === r.Right ? u.right : u.left,
                        x = d === o.Top ? u.top : u.bottom,
                        w = {
                            x: C - (m === i.FromRightToLeft ? n : 0) + b,
                            y: x - (h === s.FromBottomToTop ? c : 0) + v
                        };
                    return f && (w.overrideWidth = u.width), w
                }
            }
        },
        75803: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => l,
                ToolWidgetButton: () => c
            });
            var o = n(59496),
                r = n(97754),
                s = n(72571),
                i = n(4257),
                a = n(55576);
            const l = a,
                c = o.forwardRef((e, t) => {
                    const {
                        icon: n,
                        isActive: l,
                        isOpened: c,
                        isDisabled: u,
                        isGrouped: d,
                        isHovered: h,
                        onClick: p,
                        text: m,
                        textBeforeIcon: b,
                        title: g,
                        theme: f = a,
                        className: v,
                        forceInteractive: C,
                        "data-name": x,
                        ...w
                    } = e, E = r(v, f.button, g && "apply-common-tooltip", {
                        [f.isActive]: l,
                        [f.isOpened]: c,
                        [f.isInteractive]: (C || Boolean(p)) && !u,
                        [f.isDisabled]: u,
                        [f.isGrouped]: d,
                        [f.hover]: h,
                        [f.newStyles]: i.hasNewHeaderToolbarStyles
                    }), k = n && ("string" == typeof n ? o.createElement(s.Icon, {
                        className: f.icon,
                        icon: n
                    }) : o.cloneElement(n, {
                        className: r(f.icon, n.props.className)
                    }));
                    return o.createElement("div", { ...w,
                        ref: t,
                        "data-role": "button",
                        className: E,
                        onClick: u ? void 0 : p,
                        title: g,
                        "data-name": x
                    }, b && m && o.createElement("div", {
                        className: r("js-button-text", f.text)
                    }, m), k, !b && m && o.createElement("div", {
                        className: r("js-button-text", f.text)
                    }, m))
                })
        },
        5710: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetIconButton: () => a
            });
            var o = n(59496),
                r = n(97754),
                s = n(75803),
                i = n(64547);
            const a = o.forwardRef((e, t) => {
                const {
                    className: n,
                    id: a,
                    ...l
                } = e;
                return o.createElement(s.ToolWidgetButton, {
                    "data-name": a,
                    ...l,
                    ref: t,
                    className: r(n, i.button)
                })
            })
        },
        34816: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_MENU_THEME: () => m,
                ToolWidgetMenu: () => b
            });
            var o = n(59496),
                r = n(97754),
                s = n(44377),
                i = n(15783),
                a = n(417),
                l = n(63694),
                c = n(59339),
                u = n(85673),
                d = n(30052),
                h = n(4257),
                p = n(71123);
            const m = p;
            class b extends o.PureComponent {
                constructor(e) {
                    super(e), this._wrapperRef = null, this._controller = o.createRef(), this._handleWrapperRef = e => {
                        this._wrapperRef = e, this.props.reference && this.props.reference(e)
                    }, this._handleClick = e => {
                        e.target instanceof Node && e.currentTarget.contains(e.target) && (this._handleToggleDropdown(), this.props.onClick && this.props.onClick(e, !this.state.isOpened))
                    }, this._handleToggleDropdown = e => {
                        const {
                            onClose: t,
                            onOpen: n
                        } = this.props, {
                            isOpened: o
                        } = this.state, r = "boolean" == typeof e ? e : !o;
                        this.setState({
                            isOpened: r
                        }), r && n && n(), !r && t && t()
                    }, this._handleClose = () => {
                        this.close()
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        arrow: t,
                        content: n,
                        isDisabled: s,
                        isDrawer: l,
                        isShowTooltip: c,
                        title: u,
                        className: p,
                        hotKey: m,
                        theme: b,
                        drawerBreakpoint: g
                    } = this.props, {
                        isOpened: f
                    } = this.state, v = r(p, b.button, {
                        "apply-common-tooltip": c || !s,
                        [b.isDisabled]: s,
                        [b.isOpened]: f,
                        [b.newStyles]: h.hasNewHeaderToolbarStyles
                    });
                    return o.createElement("div", {
                        id: e,
                        className: v,
                        onClick: s ? void 0 : this._handleClick,
                        title: u,
                        "data-tooltip-hotkey": m,
                        ref: this._handleWrapperRef,
                        "data-role": "button",
                        ...(0, a.filterDataProps)(this.props)
                    }, n, t && o.createElement("div", {
                        className: b.arrow
                    }, o.createElement("div", {
                        className: b.arrowWrap
                    }, o.createElement(i.ToolWidgetCaret, {
                        dropped: f
                    }))), this.state.isOpened && (g ? o.createElement(d.MatchMedia, {
                        rule: g
                    }, e => this._renderContent(e)) : this._renderContent(l)))
                }
                close() {
                    this._handleToggleDropdown(!1)
                }
                update() {
                    null !== this._controller.current && this._controller.current.update()
                }
                _renderContent(e) {
                    const {
                        menuDataName: t,
                        minWidth: n,
                        menuClassName: r,
                        maxHeight: i,
                        drawerPosition: a = "Bottom",
                        children: d
                    } = this.props, {
                        isOpened: h
                    } = this.state, p = {
                        horizontalMargin: this.props.horizontalMargin || 0,
                        verticalMargin: this.props.verticalMargin || 2,
                        verticalAttachEdge: this.props.verticalAttachEdge,
                        horizontalAttachEdge: this.props.horizontalAttachEdge,
                        verticalDropDirection: this.props.verticalDropDirection,
                        horizontalDropDirection: this.props.horizontalDropDirection,
                        matchButtonAndListboxWidths: this.props.matchButtonAndListboxWidths
                    }, m = Boolean(h && e && a), b = function(e) {
                        return "function" == typeof e
                    }(d) ? d({
                        isDrawer: m
                    }) : d;
                    return m ? o.createElement(l.DrawerManager, null, o.createElement(c.Drawer, {
                        onClose: this._handleClose,
                        position: a,
                        "data-name": t
                    }, b)) : o.createElement(s.PopupMenu, {
                        controller: this._controller,
                        closeOnClickOutside: this.props.closeOnClickOutside,
                        doNotCloseOn: this,
                        isOpened: h,
                        minWidth: n,
                        onClose: this._handleClose,
                        position: (0, u.getPopupPositioner)(this._wrapperRef, p),
                        className: r,
                        maxHeight: i,
                        "data-name": t
                    }, b)
                }
            }
            b.defaultProps = {
                arrow: !0,
                closeOnClickOutside: !0,
                theme: p
            }
        },
        4257: (e, t, n) => {
            "use strict";
            n.d(t, {
                hasNewHeaderToolbarStyles: () => o
            });
            n(82527);
            const o = !1
        },
        95426: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlDisclosureView: () => f
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(28606),
                a = n(34735),
                l = n(2691),
                c = n(44377),
                u = n(88537);

            function d(e, t) {
                return (0, o.useCallback)(() => function(e, t) {
                    const n = (0, u.ensureNotNull)(e).getBoundingClientRect(),
                        o = {
                            x: n.left,
                            y: n.top + n.height
                        };
                    return t && (o.overrideWidth = n.width), o
                }(e.current, t), [e, t])
            }
            var h = n(86240);
            const p = parseInt(h["size-header-height"]);

            function m(e) {
                const {
                    button: t,
                    popupChildren: n,
                    buttonRef: r,
                    listboxId: s,
                    listboxClassName: i,
                    listboxTabIndex: a,
                    matchButtonAndListboxWidths: l,
                    isOpened: u,
                    scrollWrapReference: h,
                    listboxReference: m,
                    onClose: b,
                    onOpen: g,
                    onListboxFocus: f,
                    onListboxBlur: v,
                    onListboxKeyDown: C,
                    listboxAria: x,
                    repositionOnScroll: w = !0,
                    closeOnHeaderOverlap: E = !1
                } = e, k = d(r, l), S = E ? p : 0;
                return o.createElement(o.Fragment, null, t, o.createElement(c.PopupMenu, { ...x,
                    id: s,
                    className: i,
                    tabIndex: a,
                    isOpened: u,
                    position: k,
                    repositionOnScroll: w,
                    onClose: b,
                    onOpen: g,
                    doNotCloseOn: r.current,
                    reference: m,
                    scrollWrapReference: h,
                    onFocus: f,
                    onBlur: v,
                    onKeyDown: C,
                    closeOnScrollOutsideOffset: S
                }, n))
            }
            var b = n(63802),
                g = n(66230);
            const f = o.forwardRef((e, t) => {
                const {
                    listboxId: n,
                    className: r,
                    listboxClassName: c,
                    listboxTabIndex: u,
                    hideArrowButton: d,
                    matchButtonAndListboxWidths: h,
                    disabled: p,
                    isOpened: f,
                    scrollWrapReference: v,
                    repositionOnScroll: C,
                    closeOnHeaderOverlap: x,
                    listboxReference: w,
                    size: E = "medium",
                    onClose: k,
                    onOpen: S,
                    onListboxFocus: D,
                    onListboxBlur: I,
                    onListboxKeyDown: N,
                    buttonChildren: y,
                    children: M,
                    caretClassName: B,
                    listboxAria: _,
                    ...O
                } = e, T = (0, o.useRef)(null), A = !d && o.createElement(l.EndSlot, null, o.createElement(b.Caret, {
                    isDropped: f,
                    disabled: p,
                    className: B
                }));
                return o.createElement(m, {
                    buttonRef: T,
                    listboxId: n,
                    listboxClassName: c,
                    listboxTabIndex: u,
                    isOpened: f,
                    onClose: k,
                    onOpen: S,
                    listboxReference: w,
                    scrollWrapReference: v,
                    onListboxFocus: D,
                    onListboxBlur: I,
                    onListboxKeyDown: N,
                    listboxAria: _,
                    matchButtonAndListboxWidths: h,
                    button: o.createElement(a.ControlSkeleton, { ...O,
                        "data-role": "listbox",
                        disabled: p,
                        className: s()(g.button, r),
                        size: E,
                        ref: (0, i.useMergedRefs)([T, t]),
                        middleSlot: o.createElement(l.MiddleSlot, null, o.createElement("span", {
                            className: s()(g["button-children"], d && g.hiddenArrow)
                        }, y)),
                        endSlot: A
                    }),
                    popupChildren: M,
                    repositionOnScroll: C,
                    closeOnHeaderOverlap: x
                })
            });
            f.displayName = "ControlDisclosureView"
        },
        79827: (e, t, n) => {
            "use strict";
            n.d(t, {
                useControlDisclosure: () => c
            });
            var o = n(59496),
                r = n(88537),
                s = n(83836),
                i = n(69842),
                a = n(14823),
                l = n(98043);

            function c(e) {
                const {
                    intent: t,
                    highlight: n,
                    ...c
                } = e, {
                    isFocused: u,
                    ...d
                } = function(e) {
                    const {
                        id: t,
                        disabled: n,
                        buttonTabIndex: c = 0,
                        onFocus: u,
                        onBlur: d,
                        onClick: h
                    } = e, [p, m] = (0, o.useState)(!1), [b, g] = (0, s.useFocus)(), f = b || p, v = void 0 !== t ? (0, a.createDomId)(t, "listbox") : void 0, C = (0, o.useRef)(null), x = (0, o.useCallback)(e => (0, r.ensureNotNull)(C.current).focus(e), [C]), w = (0, o.useRef)(null), E = (0, o.useCallback)(() => (0, r.ensureNotNull)(w.current).focus(), [w]), k = (0, o.useCallback)(() => m(!0), [m]), S = (0, o.useCallback)((e = !1) => {
                        m(!1);
                        const {
                            activeElement: t
                        } = document;
                        t && (0, l.isTextEditingField)(t) || x({
                            preventScroll: e
                        })
                    }, [m, x]), D = (0, o.useCallback)(() => {
                        p ? S() : k()
                    }, [p, S, k]), I = n ? [] : [u, g.onFocus], N = n ? [] : [d, g.onBlur], y = n ? [] : [h, D], M = (0, i.createSafeMulticastEventHandler)(...I), B = (0, i.createSafeMulticastEventHandler)(...N), _ = (0, i.createSafeMulticastEventHandler)(...y);
                    return {
                        listboxId: v,
                        isOpened: p,
                        isFocused: f,
                        buttonTabIndex: n ? -1 : c,
                        listboxTabIndex: -1,
                        open: k,
                        close: S,
                        toggle: D,
                        onOpen: E,
                        buttonFocusBindings: {
                            onFocus: M,
                            onBlur: B
                        },
                        onButtonClick: _,
                        buttonRef: C,
                        listboxRef: w,
                        buttonAria: {
                            "aria-controls": p ? v : void 0,
                            "aria-expanded": p,
                            "aria-disabled": n
                        }
                    }
                }(c);
                return { ...d,
                    isFocused: u,
                    highlight: null != n ? n : u,
                    intent: null != t ? t : u ? "primary" : "default"
                }
            }
        },
        63694: (e, t, n) => {
            "use strict";
            n.d(t, {
                DrawerManager: () => r,
                DrawerContext: () => s
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return o.createElement(s.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const s = o.createContext(null)
        },
        59339: (e, t, n) => {
            "use strict";
            n.d(t, {
                Drawer: () => p
            });
            var o = n(59496),
                r = n(88537),
                s = n(97754),
                i = n(59142),
                a = n(85089),
                l = n(8361),
                c = n(63694),
                u = n(1227),
                d = n(28466),
                h = n(66998);

            function p(e) {
                const {
                    position: t = "Bottom",
                    onClose: n,
                    children: p,
                    className: m,
                    theme: b = h
                } = e, g = (0, r.ensureNotNull)((0, o.useContext)(c.DrawerContext)), [f, v] = (0, o.useState)(0), C = (0, o.useRef)(null), x = (0, o.useContext)(d.CloseDelegateContext);
                return (0, o.useEffect)(() => {
                    const e = (0, r.ensureNotNull)(C.current);
                    return e.focus({
                        preventScroll: !0
                    }), x.subscribe(g, n), 0 === g.currentDrawer && (0, a.setFixedBodyState)(!0), u.CheckMobile.iOS() && (0, i.disableBodyScroll)(e), v(g.addDrawer()), () => {
                        x.unsubscribe(g, n);
                        const t = g.removeDrawer();
                        u.CheckMobile.iOS() && (0, i.enableBodyScroll)(e), 0 === t && (0, a.setFixedBodyState)(!1)
                    }
                }, []), o.createElement(l.Portal, null, o.createElement("div", {
                    className: s(h.wrap, h["position" + t])
                }, f === g.currentDrawer && o.createElement("div", {
                    className: h.backdrop,
                    onClick: n
                }), o.createElement("div", {
                    className: s(h.drawer, b.drawer, h["position" + t], m),
                    ref: C,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, p)))
            }
        },
        53517: (e, t, n) => {
            "use strict";
            n.d(t, {
                useKeyboardActionHandler: () => i,
                useComposedKeyboardActionHandlers: () => a,
                useKeyboardEventHandler: () => l,
                useKeyboardToggle: () => c,
                useKeyboardClose: () => u,
                useKeyboardOpen: () => d
            });
            var o = n(59496),
                r = n(80185);
            const s = () => !0;

            function i(e, t, n = s) {
                return (0, o.useCallback)(o => {
                    const r = e.map(e => "function" == typeof e ? e() : e);
                    return !(!n() || !r.includes(o)) && (t(), !0)
                }, [...e, t, n])
            }

            function a(...e) {
                return (0, o.useCallback)(t => {
                    for (const n of e)
                        if (n(t)) return !0;
                    return !1
                }, [...e])
            }

            function l(...e) {
                const t = a(...e);
                return (0, o.useCallback)(e => {
                    t((0, r.hashFromEvent)(e)) && e.preventDefault()
                }, [t])
            }

            function c(e) {
                return i([13, 32], e)
            }

            function u(e, t) {
                return i([9, (0, o.useCallback)(() => r.Modifiers.Shift + 9, []), 27], t, (0, o.useCallback)(() => e, [e]))
            }

            function d(e, t) {
                return i([40, 38], t, (0, o.useCallback)(() => !e, [e]))
            }
        },
        61851: (e, t, n) => {
            "use strict";
            n.d(t, {
                useObservable: () => r
            });
            var o = n(59496);

            function r(e, t) {
                const [n, r] = (0, o.useState)(t);
                return (0, o.useEffect)(() => {
                    const t = e.subscribe(r);
                    return () => t.unsubscribe()
                }, [e]), n
            }
        },
        97265: (e, t, n) => {
            "use strict";
            n.d(t, {
                useWatchedValueReadonly: () => r
            });
            var o = n(59496);
            const r = (e, t = !1) => {
                const n = "watchedValue" in e ? e.watchedValue : void 0,
                    r = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                    [s, i] = (0, o.useState)(n ? n.value() : r);
                return (t ? o.useLayoutEffect : o.useEffect)(() => {
                    if (n) {
                        i(n.value());
                        const e = e => i(e);
                        return n.subscribe(e), () => n.unsubscribe(e)
                    }
                    return () => {}
                }, [n]), s
            }
        },
        1317: (e, t, n) => {
            "use strict";
            n.d(t, {
                useWatchedValue: () => r
            });
            var o = n(59496);
            const r = e => {
                const [t, n] = (0, o.useState)(e.value());
                return (0, o.useEffect)(() => {
                    const t = e => n(e);
                    return e.subscribe(t), () => e.unsubscribe(t)
                }, [e]), [t, t => e.setValue(t)]
            }
        },
        63802: (e, t, n) => {
            "use strict";
            n.d(t, {
                Caret: () => u,
                CaretButton: () => d
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(72571),
                a = n(76758),
                l = n(99171);

            function c(e) {
                const {
                    isDropped: t
                } = e;
                return o.createElement(i.Icon, {
                    className: s()(l.icon, t && l.dropped),
                    icon: a
                })
            }

            function u(e) {
                const {
                    className: t,
                    disabled: n,
                    isDropped: r
                } = e;
                return o.createElement("span", {
                    className: s()(l.button, n && l.disabled, t)
                }, o.createElement(c, {
                    isDropped: r
                }))
            }

            function d(e) {
                const {
                    className: t,
                    tabIndex: n = -1,
                    disabled: r,
                    isDropped: i,
                    ...a
                } = e;
                return o.createElement("button", { ...a,
                    type: "button",
                    tabIndex: n,
                    disabled: r,
                    className: s()(l.button, r && l.disabled, t)
                }, o.createElement(c, {
                    isDropped: i
                }))
            }
        },
        36118: (e, t, n) => {
            "use strict";
            n.d(t, {
                Select: () => N
            });
            var o = n(59496),
                r = n(14823),
                s = n(28606),
                i = n(88537),
                a = n(49423);
            const l = {
                    duration: 200,
                    additionalScroll: 0
                },
                c = {
                    vertical: {
                        scrollSize: "scrollHeight",
                        clientSize: "clientHeight",
                        start: "top",
                        end: "bottom",
                        size: "height"
                    },
                    horizontal: {
                        scrollSize: "scrollWidth",
                        clientSize: "clientWidth",
                        start: "left",
                        end: "right",
                        size: "width"
                    }
                };

            function u(e, t) {
                const n = c[e];
                return t[n.scrollSize] > t[n.clientSize]
            }

            function d(e, t, n, o, r, s) {
                const i = function(e, t, n, o = 0) {
                    const r = c[e];
                    return {
                        start: -1 * o,
                        middle: -1 * (Math.floor(n[r.size] / 2) - Math.floor(t[r.size] / 2)),
                        end: -1 * (n[r.size] - t[r.size]) + o
                    }
                }(e, o, r, s.additionalScroll);
                let l = 0;
                if (function(e, t, n) {
                        const o = c[e];
                        return t[o.start] < n[o.start] - n[o.size] / 2 || t[o.end] > n[o.end] + n[o.size] / 2
                    }(e, o, r)) l = i.middle;
                else {
                    const t = function(e) {
                        const {
                            start: t,
                            middle: n,
                            end: o
                        } = e, r = new Map([
                            [Math.abs(t), {
                                key: "start",
                                value: Math.sign(t)
                            }],
                            [Math.abs(n), {
                                key: "middle",
                                value: Math.sign(n)
                            }],
                            [Math.abs(o), {
                                key: "end",
                                value: Math.sign(o)
                            }]
                        ]), s = Math.min(...r.keys());
                        return r.get(s)
                    }(function(e, t, n, o = 0) {
                        const r = c[e],
                            s = t[r.start] + Math.floor(t[r.size] / 2),
                            i = n[r.start] + Math.floor(n[r.size] / 2);
                        return {
                            start: t[r.start] - n[r.start] - o,
                            middle: s - i,
                            end: t[r.end] - n[r.end] + o
                        }
                    }(e, o, r, s.additionalScroll));
                    l = void 0 !== t ? i[t.key] : 0
                }
                return function(e) {
                    const {
                        additionalScroll: t = 0,
                        duration: n = a.dur,
                        func: o = a.easingFunc.easeInOutCubic,
                        onScrollEnd: r,
                        target: s,
                        wrap: i,
                        direction: l = "vertical"
                    } = e;
                    let {
                        targetRect: c,
                        wrapRect: u
                    } = e;
                    c = null != c ? c : s.getBoundingClientRect(), u = null != u ? u : i.getBoundingClientRect();
                    const d = ("vertical" === l ? c.top - u.top : c.left - u.left) + t,
                        h = "vertical" === l ? "scrollTop" : "scrollLeft",
                        p = i ? i[h] : 0;
                    let m, b = 0;
                    return b = window.requestAnimationFrame((function e(t) {
                            let s;
                            if (m ? s = t - m : (s = 0, m = t), s >= n) return i[h] = p + d, void(r && r());
                            const a = p + d * o(s / n);
                            i[h] = Math.floor(a), b = window.requestAnimationFrame(e)
                        })),
                        function() {
                            window.cancelAnimationFrame(b), r && r()
                        }
                }({ ...s,
                    target: t,
                    targetRect: o,
                    wrap: n,
                    wrapRect: r,
                    additionalScroll: l,
                    direction: e
                })
            }
            class h {
                constructor(e = null) {
                    this._container = null, this._lastScrolledElement = null, this._stopVerticalScroll = null, this._stopHorizontalScroll = null, this._container = e
                }
                scrollTo(e, t = l) {
                    if (null !== this._container && null !== e && ! function(e, t) {
                            const n = e.getBoundingClientRect(),
                                o = t.getBoundingClientRect();
                            return n.top >= o.top && n.bottom <= o.bottom && n.left >= o.left && n.right <= o.right
                        }(e, this._container)) {
                        const n = e.getBoundingClientRect(),
                            o = this._container.getBoundingClientRect();
                        this.stopScroll(), u("vertical", this._container) && (this._stopVerticalScroll = d("vertical", e, this._container, n, o, this._modifyOptions("vertical", t))), u("horizontal", this._container) && (this._stopHorizontalScroll = d("horizontal", e, this._container, n, o, this._modifyOptions("horizontal", t)))
                    }
                    this._lastScrolledElement = e
                }
                scrollToLastElement(e) {
                    this.scrollTo(this._lastScrolledElement, e)
                }
                stopScroll() {
                    null !== this._stopVerticalScroll && this._stopVerticalScroll(), null !== this._stopHorizontalScroll && this._stopHorizontalScroll()
                }
                getContainer() {
                    return this._container
                }
                setContainer(e) {
                    var t;
                    this._container = e, (null === (t = this._container) || void 0 === t ? void 0 : t.contains(this._lastScrolledElement)) || (this._lastScrolledElement = null)
                }
                destroy() {
                    this.stopScroll(), this._container = null, this._lastScrolledElement = null
                }
                _handleScrollEnd(e) {
                    "vertical" === e ? this._stopVerticalScroll = null : this._stopHorizontalScroll = null
                }
                _modifyOptions(e, t) {
                    return Object.assign({}, t, {
                        onScrollEnd: () => {
                            this._handleScrollEnd(e), void 0 !== t.onScrollEnd && t.onScrollEnd()
                        }
                    })
                }
            }

            function p(e, t) {
                const n = (0, o.useRef)(null),
                    r = (0, o.useRef)(new WeakMap),
                    s = function(e) {
                        const t = (0, o.useRef)(null);
                        return (0, o.useEffect)(() => (t.current = new h(e), () => (0, i.ensureNotNull)(t.current).destroy()), []), t
                    }(n.current),
                    a = (0, o.useCallback)(() => {
                        null !== s.current && null !== n.current && s.current.getContainer() !== n.current && s.current.setContainer(n.current)
                    }, [s, n]),
                    l = (0, o.useCallback)(e => {
                        n.current = e
                    }, [n]),
                    c = (0, o.useCallback)((e, t) => {
                        r.current.set(e, t)
                    }, [r]),
                    u = (0, o.useCallback)((e, t) => {
                        if (!e) return;
                        const n = r.current.get(e);
                        n && (a(), (0, i.ensureNotNull)(s.current).scrollTo(n, t))
                    }, [r, s]);
                return (0, o.useEffect)(() => u(e, t), [u, e]), [l, c, u]
            }
            var m = n(92063),
                b = n(4889),
                g = n(43370);
            var f = n(34581),
                v = n(53517);

            function C(e, t) {
                return e >= 0 ? e % t : (t - Math.abs(e) % t) % t
            }
            const x = {
                next: [40, () => (0, f.isRtl)() ? 37 : 39],
                previous: [38, () => (0, f.isRtl)() ? 39 : 37],
                first: [33, 36],
                last: [34, 35]
            };
            var w = n(95426),
                E = n(79827),
                k = n(79756);

            function S(e) {
                return !e.readonly
            }

            function D(e, t) {
                var n;
                return null !== (n = null == t ? void 0 : t.id) && void 0 !== n ? n : (0, r.createDomId)(e, "item", null == t ? void 0 : t.value)
            }

            function I(e) {
                var t, n;
                const {
                    selectedItem: r,
                    placeholder: s
                } = e;
                if (!r) return o.createElement("span", {
                    className: k.placeholder
                }, s);
                const i = null !== (n = null !== (t = r.selectedContent) && void 0 !== t ? t : r.content) && void 0 !== n ? n : r.value;
                return o.createElement("span", null, i)
            }
            const N = o.forwardRef((e, t) => {
                const {
                    id: n,
                    menuClassName: i,
                    menuItemClassName: a,
                    tabIndex: l,
                    disabled: c,
                    highlight: u,
                    intent: d,
                    hideArrowButton: h,
                    placeholder: f,
                    addPlaceholderToItems: k = !0,
                    value: N,
                    "aria-labelledby": y,
                    onFocus: M,
                    onBlur: B,
                    onClick: _,
                    onChange: O,
                    repositionOnScroll: T = !0,
                    ...A
                } = e;
                let {
                    items: R
                } = e;
                if (f && k) {
                    R = [{
                        value: void 0,
                        content: f,
                        id: (0, r.createDomId)(n, "placeholder")
                    }, ...R]
                }
                const {
                    listboxId: F,
                    isOpened: z,
                    isFocused: L,
                    buttonTabIndex: W,
                    listboxTabIndex: H,
                    highlight: P,
                    intent: V,
                    open: U,
                    onOpen: G,
                    close: K,
                    toggle: Q,
                    buttonFocusBindings: X,
                    onButtonClick: Y,
                    buttonRef: j,
                    listboxRef: J,
                    buttonAria: Z
                } = (0, E.useControlDisclosure)({
                    id: n,
                    disabled: c,
                    buttonTabIndex: l,
                    intent: d,
                    highlight: u,
                    onFocus: M,
                    onBlur: B,
                    onClick: _
                }), q = R.filter(S), $ = q.find(e => e.value === N), [ee, te, ne] = p($), oe = (0, r.joinDomIds)(y, n), re = oe.length > 0 ? oe : void 0, se = (0, o.useMemo)(() => ({
                    role: "listbox",
                    "aria-labelledby": y,
                    "aria-activedescendant": D(n, $)
                }), [y, $]), ie = (0, o.useCallback)(e => e.value === N, [N]), ae = (0, o.useCallback)(e => O && O(e.value), [O]), le = function(e, t, n, r = !0, s = {}) {
                    const i = (0, o.useCallback)(() => {
                            const o = e.findIndex(t);
                            if (o === e.length - 1 && !r) return;
                            const s = C(o + 1, e.length);
                            n && n(e[s])
                        }, [e, t, n, r]),
                        a = (0, o.useCallback)(() => {
                            const o = e.findIndex(t);
                            if (0 === o && !r) return;
                            const s = C(o - 1, e.length);
                            n && n(e[s])
                        }, [e, t, n, r]),
                        l = (0, o.useCallback)(() => {
                            n && n(e[0])
                        }, [n, e]),
                        c = (0, o.useCallback)(() => {
                            n && n(e[e.length - 1])
                        }, [n, e]),
                        {
                            next: u = x.next,
                            previous: d = x.previous,
                            first: h = x.first,
                            last: p = x.last
                        } = s;
                    return (0, v.useComposedKeyboardActionHandlers)((0, v.useKeyboardActionHandler)(u, i), (0, v.useKeyboardActionHandler)(d, a), (0, v.useKeyboardActionHandler)(h, l), (0, v.useKeyboardActionHandler)(p, c))
                }(q, ie, ae, !1, {
                    next: [40],
                    previous: [38]
                }), ce = (0, v.useKeyboardToggle)(Q), ue = (0, v.useKeyboardClose)(z, K), de = (0, v.useKeyboardOpen)(z, U), he = (0, v.useKeyboardEventHandler)(ce, ue, de), pe = (0, v.useKeyboardEventHandler)(le, ce, ue), me = function(e) {
                    const t = (0, o.useRef)(""),
                        n = (0, o.useMemo)(() => (0, b.default)(() => {
                            t.current = ""
                        }, 500), []),
                        r = (0, o.useMemo)(() => (0, g.default)(e, 200), [e]);
                    return (0, o.useCallback)(e => {
                        e.key.length > 0 && e.key.length < 3 && (t.current += e.key, r(t.current, e), n())
                    }, [n, r])
                }((e, t) => {
                    const n = function(e, t) {
                        return e.find(e => {
                            var n;
                            const o = t.toLowerCase();
                            return !e.readonly && (!e.readonly && ("string" == typeof e.content && e.content.toLowerCase().startsWith(o) || String(null !== (n = e.value) && void 0 !== n ? n : "").toLowerCase().startsWith(o)))
                        })
                    }(q, e);
                    void 0 !== n && O && (t.stopPropagation(), z || U(), O(n.value))
                });
                return o.createElement(w.ControlDisclosureView, { ...A,
                    ...Z,
                    ...X,
                    id: n,
                    role: "button",
                    tabIndex: W,
                    "aria-owns": Z["aria-controls"],
                    "aria-haspopup": "listbox",
                    "aria-labelledby": re,
                    disabled: c,
                    hideArrowButton: h,
                    isFocused: L,
                    isOpened: z,
                    highlight: P,
                    intent: V,
                    ref: (0, s.useMergedRefs)([j, t]),
                    onClick: Y,
                    onOpen: function() {
                        ne($, {
                            duration: 0
                        }), G()
                    },
                    onClose: K,
                    onKeyDown: function(e) {
                        he(e), e.defaultPrevented || me(e)
                    },
                    listboxId: F,
                    listboxTabIndex: H,
                    listboxClassName: i,
                    listboxAria: se,
                    listboxReference: J,
                    scrollWrapReference: ee,
                    onListboxKeyDown: function(e) {
                        pe(e), e.defaultPrevented || me(e)
                    },
                    buttonChildren: o.createElement(I, {
                        selectedItem: $,
                        placeholder: f
                    }),
                    repositionOnScroll: T
                }, R.map((e, t) => {
                    var r;
                    if (e.readonly) return o.createElement(o.Fragment, {
                        key: "readonly_item_" + t
                    }, e.content);
                    const s = D(n, e);
                    return o.createElement(m.PopupMenuItem, {
                        key: s,
                        id: s,
                        className: a,
                        role: "option",
                        "aria-selected": N === e.value,
                        isActive: N === e.value,
                        label: null !== (r = e.content) && void 0 !== r ? r : e.value,
                        onClick: be,
                        onClickArg: e.value,
                        isDisabled: e.disabled,
                        reference: t => te(e, t)
                    })
                }));

                function be(e) {
                    O && O(e)
                }
            });
            N.displayName = "Select"
        },
        79266: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenuItemToggle: () => l
            });
            var o = n(59496),
                r = n(97754),
                s = n(92063),
                i = n(2946),
                a = n(91998);

            function l(e) {
                const {
                    isDisabled: t,
                    hint: n,
                    label: l,
                    isChecked: c,
                    checkboxClassName: u,
                    labelClassName: d,
                    indeterminate: h,
                    ...p
                } = e;
                return o.createElement(s.PopupMenuItem, { ...p,
                    isDisabled: t,
                    shortcut: n,
                    dontClosePopup: !0,
                    labelRowClassName: d,
                    label: o.createElement(i.Checkbox, {
                        disabled: t,
                        label: l,
                        checked: c,
                        indeterminate: h,
                        className: r(a.checkbox, u)
                    })
                })
            }
        },
        15783: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetCaret: () => l
            });
            var o = n(59496),
                r = n(97754),
                s = n(72571),
                i = n(40367),
                a = n(21538);

            function l(e) {
                const {
                    dropped: t,
                    className: n
                } = e;
                return o.createElement(s.Icon, {
                    className: r(n, i.icon, {
                        [i.dropped]: t
                    }),
                    icon: a
                })
            }
        },
        57369: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 9" width="11" height="9" fill="none"><path stroke-width="2" d="M0.999878 4L3.99988 7L9.99988 1"/></svg>'
        },
        88902: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentcolor" stroke-width="1.2" d="M17 21l-7.5-7.5L17 6"/></svg>'
        },
        25118: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="20" height="20" fill="none" stroke="currentcolor"><path d="M3.5 10A6.5 6.5 0 1 0 10 3.5H5.233M7.5 6.5l-3-3 3-3"/></svg>'
        },
        76758: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 7" width="11" height="7" fill="none"><path stroke="currentColor" stroke-width="1.3" d="M.5 1.5l5 4 5-4"/></svg>'
        },
        79810: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" stroke-width="1.2" d="M7 6l15 15m0-15L7 21"/></svg>'
        },
        12142: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><path fill="currentColor" d="M7.84 13.7H5.78V4.4l2.48-.06c1.35 0 2.42.4 3.22 1.2.8.78 1.19 1.83 1.19 3.15 0 3.34-1.61 5.01-4.83 5.01zm-.41-7.85v6.35c.26.02.55.03.86.03.83 0 1.48-.3 1.95-.9.48-.6.72-1.46.72-2.54 0-2-.93-2.99-2.78-2.99-.18 0-.43.02-.75.05z"/></svg>'
        },
        74300: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><path fill="currentColor" d="M13.4 5.9c-.41 1.62-1.16 2.43-2.25 2.43-.52 0-1.25-.15-2.2-.45-.93-.3-1.58-.45-1.96-.45-.55 0-.98.3-1.27.9H4.66c.1-.67.36-1.24.76-1.71.4-.48.86-.72 1.4-.72.56 0 1.31.16 2.27.46.95.3 1.62.45 2.01.45.64 0 1.06-.3 1.27-.9h1.03zm0 3.87c-.41 1.62-1.16 2.43-2.25 2.43-.52 0-1.25-.15-2.2-.45-.93-.3-1.58-.46-1.96-.46-.55 0-.98.3-1.27.9H4.66c.1-.67.36-1.24.76-1.7.4-.48.86-.72 1.4-.72.56 0 1.31.15 2.27.46.95.3 1.62.44 2.01.44.64 0 1.06-.3 1.27-.9h1.03z"/></svg>'
        },
        31616: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="22px" height="22px"><g fill-rule="evenodd"><path d="M12 16h-2v-6h2v6zm0-8h-2V6h2v2z"/><path d="M11.016.25C5.09.25.282 5.06.282 10.984c0 5.925 4.81 10.734 10.734 10.734 5.925 0 10.734-4.81 10.734-10.734S16.94.25 11.016.25zm0 1.5c5.096 0 9.234 4.138 9.234 9.234s-4.138 9.234-9.234 9.234-9.234-4.138-9.234-9.234S5.92 1.75 11.016 1.75z"/></g></svg>'
        },
        55702: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M7.5 13a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM5 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM12 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0zm9.5-1.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM19 14.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0z"/></svg>'
        },
        86240: e => {
            "use strict";
            e.exports = JSON.parse('{"size-header-height":"64px","media-phone-vertical":"screen and (max-width: 479px)","media-mf-phone-landscape":"screen and (min-width: 568px)"}')
        }
    }
]);
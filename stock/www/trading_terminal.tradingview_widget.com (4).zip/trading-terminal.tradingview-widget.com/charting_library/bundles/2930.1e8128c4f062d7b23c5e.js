"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2930], {
        46123: (e, t, r) => {
            function n(e, t) {
                for (var r = arguments.length, n = new Array(r > 2 ? r - 2 : 0), i = 2; i < r; i++) n[i - 2] = arguments[i];
                if (!e) {
                    var o;
                    if (void 0 === t) o = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                    else {
                        var a = 0;
                        (o = new Error(t.replace(/%s/g, (function() {
                            return n[a++]
                        })))).name = "Invariant Violation"
                    }
                    throw o.framesToPop = 1, o
                }
            }
            r.d(t, {
                invariant: () => n
            })
        },
        1633: (e, t, r) => {
            function n(e, t, r, n) {
                var i = r ? r.call(n, e, t) : void 0;
                if (void 0 !== i) return !!i;
                if (e === t) return !0;
                if ("object" != typeof e || !e || "object" != typeof t || !t) return !1;
                var o = Object.keys(e),
                    a = Object.keys(t);
                if (o.length !== a.length) return !1;
                for (var u = Object.prototype.hasOwnProperty.bind(t), s = 0; s < o.length; s++) {
                    var c = o[s];
                    if (!u(c)) return !1;
                    var l = e[c],
                        d = t[c];
                    if (!1 === (i = r ? r.call(n, l, d, c) : void 0) || void 0 === i && l !== d) return !1
                }
                return !0
            }
            r.d(t, {
                shallowEqual: () => n
            })
        },
        53408: (e, t, r) => {
            var n;

            function i() {
                return n || ((n = new Image).src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="), n
            }
            r.d(t, {
                getEmptyImage: () => i
            })
        },
        11307: (e, t, r) => {
            r.d(t, {
                HTML5Backend: () => R
            });
            var n = {};

            function i(e) {
                var t = null;
                return function() {
                    return null == t && (t = e()), t
                }
            }

            function o(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            r.r(n), r.d(n, {
                FILE: () => v,
                HTML: () => b,
                TEXT: () => y,
                URL: () => p
            });
            var a = function() {
                    function e(t) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.entered = [], this.isNodeInDocument = t
                    }
                    var t, r, n;
                    return t = e, (r = [{
                        key: "enter",
                        value: function(e) {
                            var t = this,
                                r = this.entered.length;
                            return this.entered = function(e, t) {
                                var r = new Set,
                                    n = function(e) {
                                        return r.add(e)
                                    };
                                e.forEach(n), t.forEach(n);
                                var i = [];
                                return r.forEach((function(e) {
                                    return i.push(e)
                                })), i
                            }(this.entered.filter((function(r) {
                                return t.isNodeInDocument(r) && (!r.contains || r.contains(e))
                            })), [e]), 0 === r && this.entered.length > 0
                        }
                    }, {
                        key: "leave",
                        value: function(e) {
                            var t, r, n = this.entered.length;
                            return this.entered = (t = this.entered.filter(this.isNodeInDocument), r = e, t.filter((function(e) {
                                return e !== r
                            }))), n > 0 && 0 === this.entered.length
                        }
                    }, {
                        key: "reset",
                        value: function() {
                            this.entered = []
                        }
                    }]) && o(t.prototype, r), n && o(t, n), e
                }(),
                u = i((function() {
                    return /firefox/i.test(navigator.userAgent)
                })),
                s = i((function() {
                    return Boolean(window.safari)
                }));

            function c(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var l = function() {
                function e(t, r) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e);
                    for (var n = t.length, i = [], o = 0; o < n; o++) i.push(o);
                    i.sort((function(e, r) {
                        return t[e] < t[r] ? -1 : 1
                    }));
                    for (var a, u, s = [], c = [], l = [], d = 0; d < n - 1; d++) a = t[d + 1] - t[d], u = r[d + 1] - r[d], c.push(a), s.push(u), l.push(u / a);
                    for (var f = [l[0]], g = 0; g < c.length - 1; g++) {
                        var h = l[g],
                            v = l[g + 1];
                        if (h * v <= 0) f.push(0);
                        else {
                            a = c[g];
                            var p = c[g + 1],
                                y = a + p;
                            f.push(3 * y / ((y + p) / h + (y + a) / v))
                        }
                    }
                    f.push(l[l.length - 1]);
                    for (var b, m = [], O = [], D = 0; D < f.length - 1; D++) {
                        b = l[D];
                        var S = f[D],
                            T = 1 / c[D],
                            w = S + f[D + 1] - b - b;
                        m.push((b - S - w) * T), O.push(w * T * T)
                    }
                    this.xs = t, this.ys = r, this.c1s = f, this.c2s = m, this.c3s = O
                }
                var t, r, n;
                return t = e, (r = [{
                    key: "interpolate",
                    value: function(e) {
                        var t = this.xs,
                            r = this.ys,
                            n = this.c1s,
                            i = this.c2s,
                            o = this.c3s,
                            a = t.length - 1;
                        if (e === t[a]) return r[a];
                        for (var u, s = 0, c = o.length - 1; s <= c;) {
                            var l = t[u = Math.floor(.5 * (s + c))];
                            if (l < e) s = u + 1;
                            else {
                                if (!(l > e)) return r[u];
                                c = u - 1
                            }
                        }
                        var d = e - t[a = Math.max(0, c)],
                            f = d * d;
                        return r[a] + n[a] * d + i[a] * f + o[a] * d * f
                    }
                }]) && c(t.prototype, r), n && c(t, n), e
            }();

            function d(e) {
                var t = 1 === e.nodeType ? e : e.parentElement;
                if (!t) return null;
                var r = t.getBoundingClientRect(),
                    n = r.top;
                return {
                    x: r.left,
                    y: n
                }
            }

            function f(e) {
                return {
                    x: e.clientX,
                    y: e.clientY
                }
            }

            function g(e, t, r, n, i) {
                var o, a, c, f = "IMG" === (o = t).nodeName && (u() || !(null !== (a = document.documentElement) && void 0 !== a && a.contains(o))),
                    g = d(f ? e : t),
                    h = {
                        x: r.x - g.x,
                        y: r.y - g.y
                    },
                    v = e.offsetWidth,
                    p = e.offsetHeight,
                    y = n.anchorX,
                    b = n.anchorY,
                    m = function(e, t, r, n) {
                        var i = e ? t.width : r,
                            o = e ? t.height : n;
                        return s() && e && (o /= window.devicePixelRatio, i /= window.devicePixelRatio), {
                            dragPreviewWidth: i,
                            dragPreviewHeight: o
                        }
                    }(f, t, v, p),
                    O = m.dragPreviewWidth,
                    D = m.dragPreviewHeight,
                    S = i.offsetX,
                    T = i.offsetY,
                    w = 0 === T || T;
                return {
                    x: 0 === S || S ? S : new l([0, .5, 1], [h.x, h.x / v * O, h.x + O - v]).interpolate(y),
                    y: w ? T : (c = new l([0, .5, 1], [h.y, h.y / p * D, h.y + D - p]).interpolate(b), s() && f && (c += (window.devicePixelRatio - 1) * D), c)
                }
            }
            var h, v = "__NATIVE_FILE__",
                p = "__NATIVE_URL__",
                y = "__NATIVE_TEXT__",
                b = "__NATIVE_HTML__";

            function m(e, t, r) {
                var n = t.reduce((function(t, r) {
                    return t || e.getData(r)
                }), "");
                return null != n ? n : r
            }

            function O(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var D = (O(h = {}, v, {
                exposeProperties: {
                    files: function(e) {
                        return Array.prototype.slice.call(e.files)
                    },
                    items: function(e) {
                        return e.items
                    }
                },
                matchesTypes: ["Files"]
            }), O(h, b, {
                exposeProperties: {
                    html: function(e, t) {
                        return m(e, t, "")
                    }
                },
                matchesTypes: ["Html", "text/html"]
            }), O(h, p, {
                exposeProperties: {
                    urls: function(e, t) {
                        return m(e, t, "").split("\n")
                    }
                },
                matchesTypes: ["Url", "text/uri-list"]
            }), O(h, y, {
                exposeProperties: {
                    text: function(e, t) {
                        return m(e, t, "")
                    }
                },
                matchesTypes: ["Text", "text/plain"]
            }), h);

            function S(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var T = function() {
                function e(t) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this.config = t, this.item = {}, this.initializeExposedProperties()
                }
                var t, r, n;
                return t = e, (r = [{
                    key: "initializeExposedProperties",
                    value: function() {
                        var e = this;
                        Object.keys(this.config.exposeProperties).forEach((function(t) {
                            Object.defineProperty(e.item, t, {
                                configurable: !0,
                                enumerable: !0,
                                get: function() {
                                    return console.warn("Browser doesn't allow reading \"".concat(t, '" until the drop event.')), null
                                }
                            })
                        }))
                    }
                }, {
                    key: "loadDataTransfer",
                    value: function(e) {
                        var t = this;
                        if (e) {
                            var r = {};
                            Object.keys(this.config.exposeProperties).forEach((function(n) {
                                r[n] = {
                                    value: t.config.exposeProperties[n](e, t.config.matchesTypes),
                                    configurable: !0,
                                    enumerable: !0
                                }
                            })), Object.defineProperties(this.item, r)
                        }
                    }
                }, {
                    key: "canDrag",
                    value: function() {
                        return !0
                    }
                }, {
                    key: "beginDrag",
                    value: function() {
                        return this.item
                    }
                }, {
                    key: "isDragging",
                    value: function(e, t) {
                        return t === e.getSourceId()
                    }
                }, {
                    key: "endDrag",
                    value: function() {}
                }]) && S(t.prototype, r), n && S(t, n), e
            }();

            function w(e) {
                if (!e) return null;
                var t = Array.prototype.slice.call(e.types || []);
                return Object.keys(D).filter((function(e) {
                    return D[e].matchesTypes.some((function(e) {
                        return t.indexOf(e) > -1
                    }))
                }))[0] || null
            }

            function I(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var E = function() {
                function e(t, r) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this.ownerDocument = null, this.globalContext = t, this.optionsArgs = r
                }
                var t, r, n;
                return t = e, (r = [{
                    key: "window",
                    get: function() {
                        return this.globalContext ? this.globalContext : "undefined" != typeof window ? window : void 0
                    }
                }, {
                    key: "document",
                    get: function() {
                        var e;
                        return null !== (e = this.globalContext) && void 0 !== e && e.document ? this.globalContext.document : this.window ? this.window.document : void 0
                    }
                }, {
                    key: "rootElement",
                    get: function() {
                        var e;
                        return (null === (e = this.optionsArgs) || void 0 === e ? void 0 : e.rootElement) || this.window
                    }
                }]) && I(t.prototype, r), n && I(t, n), e
            }();

            function k(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function C(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? k(Object(r), !0).forEach((function(t) {
                        P(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : k(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function P(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function N(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var j = function() {
                    function e(t, r, n) {
                        var i = this;
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.sourcePreviewNodes = new Map, this.sourcePreviewNodeOptions = new Map, this.sourceNodes = new Map, this.sourceNodeOptions = new Map, this.dragStartSourceIds = null, this.dropTargetIds = [], this.dragEnterTargetIds = [], this.currentNativeSource = null, this.currentNativeHandle = null, this.currentDragSourceNode = null, this.altKeyPressed = !1, this.mouseMoveTimeoutTimer = null, this.asyncEndDragFrameId = null, this.dragOverTargetIds = null, this.getSourceClientOffset = function(e) {
                            var t = i.sourceNodes.get(e);
                            return t && d(t) || null
                        }, this.endDragNativeItem = function() {
                            i.isDraggingNativeItem() && (i.actions.endDrag(), i.currentNativeHandle && i.registry.removeSource(i.currentNativeHandle),
                                i.currentNativeHandle = null, i.currentNativeSource = null)
                        }, this.isNodeInDocument = function(e) {
                            return Boolean(e && i.document && i.document.body && document.body.contains(e))
                        }, this.endDragIfSourceWasRemovedFromDOM = function() {
                            var e = i.currentDragSourceNode;
                            null == e || i.isNodeInDocument(e) || i.clearCurrentDragSourceNode() && i.monitor.isDragging() && i.actions.endDrag()
                        }, this.handleTopDragStartCapture = function() {
                            i.clearCurrentDragSourceNode(), i.dragStartSourceIds = []
                        }, this.handleTopDragStart = function(e) {
                            if (!e.defaultPrevented) {
                                var t = i.dragStartSourceIds;
                                i.dragStartSourceIds = null;
                                var r = f(e);
                                i.monitor.isDragging() && i.actions.endDrag(), i.actions.beginDrag(t || [], {
                                    publishSource: !1,
                                    getSourceClientOffset: i.getSourceClientOffset,
                                    clientOffset: r
                                });
                                var n = e.dataTransfer,
                                    o = w(n);
                                if (i.monitor.isDragging()) {
                                    if (n && "function" == typeof n.setDragImage) {
                                        var a = i.monitor.getSourceId(),
                                            u = i.sourceNodes.get(a),
                                            s = i.sourcePreviewNodes.get(a) || u;
                                        if (s) {
                                            var c = i.getCurrentSourcePreviewNodeOptions(),
                                                l = g(u, s, r, {
                                                    anchorX: c.anchorX,
                                                    anchorY: c.anchorY
                                                }, {
                                                    offsetX: c.offsetX,
                                                    offsetY: c.offsetY
                                                });
                                            n.setDragImage(s, l.x, l.y)
                                        }
                                    }
                                    try {
                                        null == n || n.setData("application/json", {})
                                    } catch (e) {}
                                    i.setCurrentDragSourceNode(e.target), i.getCurrentSourcePreviewNodeOptions().captureDraggingState ? i.actions.publishDragSource() : setTimeout((function() {
                                        return i.actions.publishDragSource()
                                    }), 0)
                                } else if (o) i.beginDragNativeItem(o);
                                else {
                                    if (n && !n.types && (e.target && !e.target.hasAttribute || !e.target.hasAttribute("draggable"))) return;
                                    e.preventDefault()
                                }
                            }
                        }, this.handleTopDragEndCapture = function() {
                            i.clearCurrentDragSourceNode() && i.monitor.isDragging() && i.actions.endDrag()
                        }, this.handleTopDragEnterCapture = function(e) {
                            if (i.dragEnterTargetIds = [], i.enterLeaveCounter.enter(e.target) && !i.monitor.isDragging()) {
                                var t = e.dataTransfer,
                                    r = w(t);
                                r && i.beginDragNativeItem(r, t)
                            }
                        }, this.handleTopDragEnter = function(e) {
                            var t = i.dragEnterTargetIds;
                            (i.dragEnterTargetIds = [], i.monitor.isDragging()) && (i.altKeyPressed = e.altKey, t.length > 0 && i.actions.hover(t, {
                                clientOffset: f(e)
                            }), t.some((function(e) {
                                return i.monitor.canDropOnTarget(e)
                            })) && (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = i.getCurrentDropEffect())))
                        }, this.handleTopDragOverCapture = function() {
                            i.dragOverTargetIds = []
                        }, this.handleTopDragOver = function(e) {
                            var t = i.dragOverTargetIds;
                            if (i.dragOverTargetIds = [], !i.monitor.isDragging()) return e.preventDefault(), void(e.dataTransfer && (e.dataTransfer.dropEffect = "none"));
                            i.altKeyPressed = e.altKey, i.actions.hover(t || [], {
                                clientOffset: f(e)
                            }), (t || []).some((function(e) {
                                return i.monitor.canDropOnTarget(e)
                            })) ? (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = i.getCurrentDropEffect())) : i.isDraggingNativeItem() ? e.preventDefault() : (e.preventDefault(), e.dataTransfer && (e.dataTransfer.dropEffect = "none"))
                        }, this.handleTopDragLeaveCapture = function(e) {
                            i.isDraggingNativeItem() && e.preventDefault(), i.enterLeaveCounter.leave(e.target) && i.isDraggingNativeItem() && setTimeout((function() {
                                return i.endDragNativeItem()
                            }), 0)
                        }, this.handleTopDropCapture = function(e) {
                            var t;
                            (i.dropTargetIds = [], i.isDraggingNativeItem()) && (e.preventDefault(),
                                null === (t = i.currentNativeSource) || void 0 === t || t.loadDataTransfer(e.dataTransfer));
                            i.enterLeaveCounter.reset()
                        }, this.handleTopDrop = function(e) {
                            var t = i.dropTargetIds;
                            i.dropTargetIds = [], i.actions.hover(t, {
                                clientOffset: f(e)
                            }), i.actions.drop({
                                dropEffect: i.getCurrentDropEffect()
                            }), i.isDraggingNativeItem() ? i.endDragNativeItem() : i.monitor.isDragging() && i.actions.endDrag()
                        }, this.handleSelectStart = function(e) {
                            var t = e.target;
                            "function" == typeof t.dragDrop && ("INPUT" === t.tagName || "SELECT" === t.tagName || "TEXTAREA" === t.tagName || t.isContentEditable || (e.preventDefault(), t.dragDrop()))
                        }, this.options = new E(r, n), this.actions = t.getActions(), this.monitor = t.getMonitor(), this.registry = t.getRegistry(), this.enterLeaveCounter = new a(this.isNodeInDocument)
                    }
                    var t, r, i;
                    return t = e, (r = [{
                        key: "profile",
                        value: function() {
                            var e, t;
                            return {
                                sourcePreviewNodes: this.sourcePreviewNodes.size,
                                sourcePreviewNodeOptions: this.sourcePreviewNodeOptions.size,
                                sourceNodeOptions: this.sourceNodeOptions.size,
                                sourceNodes: this.sourceNodes.size,
                                dragStartSourceIds: (null === (e = this.dragStartSourceIds) || void 0 === e ? void 0 : e.length) || 0,
                                dropTargetIds: this.dropTargetIds.length,
                                dragEnterTargetIds: this.dragEnterTargetIds.length,
                                dragOverTargetIds: (null === (t = this.dragOverTargetIds) || void 0 === t ? void 0 : t.length) || 0
                            }
                        }
                    }, {
                        key: "window",
                        get: function() {
                            return this.options.window
                        }
                    }, {
                        key: "document",
                        get: function() {
                            return this.options.document
                        }
                    }, {
                        key: "rootElement",
                        get: function() {
                            return this.options.rootElement
                        }
                    }, {
                        key: "setup",
                        value: function() {
                            var e = this.rootElement;
                            if (void 0 !== e) {
                                if (e.__isReactDndBackendSetUp) throw new Error("Cannot have two HTML5 backends at the same time.");
                                e.__isReactDndBackendSetUp = !0, this.addEventListeners(e)
                            }
                        }
                    }, {
                        key: "teardown",
                        value: function() {
                            var e, t = this.rootElement;
                            void 0 !== t && (t.__isReactDndBackendSetUp = !1, this.removeEventListeners(this.rootElement), this.clearCurrentDragSourceNode(), this.asyncEndDragFrameId && (null === (e = this.window) || void 0 === e || e.cancelAnimationFrame(this.asyncEndDragFrameId)))
                        }
                    }, {
                        key: "connectDragPreview",
                        value: function(e, t, r) {
                            var n = this;
                            return this.sourcePreviewNodeOptions.set(e, r), this.sourcePreviewNodes.set(e, t),
                                function() {
                                    n.sourcePreviewNodes.delete(e), n.sourcePreviewNodeOptions.delete(e)
                                }
                        }
                    }, {
                        key: "connectDragSource",
                        value: function(e, t, r) {
                            var n = this;
                            this.sourceNodes.set(e, t), this.sourceNodeOptions.set(e, r);
                            var i = function(t) {
                                    return n.handleDragStart(t, e)
                                },
                                o = function(e) {
                                    return n.handleSelectStart(e)
                                };
                            return t.setAttribute("draggable", "true"), t.addEventListener("dragstart", i), t.addEventListener("selectstart", o),
                                function() {
                                    n.sourceNodes.delete(e), n.sourceNodeOptions.delete(e), t.removeEventListener("dragstart", i), t.removeEventListener("selectstart", o), t.setAttribute("draggable", "false")
                                }
                        }
                    }, {
                        key: "connectDropTarget",
                        value: function(e, t) {
                            var r = this,
                                n = function(t) {
                                    return r.handleDragEnter(t, e)
                                },
                                i = function(t) {
                                    return r.handleDragOver(t, e)
                                },
                                o = function(t) {
                                    return r.handleDrop(t, e)
                                };
                            return t.addEventListener("dragenter", n), t.addEventListener("dragover", i), t.addEventListener("drop", o),
                                function() {
                                    t.removeEventListener("dragenter", n), t.removeEventListener("dragover", i),
                                        t.removeEventListener("drop", o)
                                }
                        }
                    }, {
                        key: "addEventListeners",
                        value: function(e) {
                            e.addEventListener && (e.addEventListener("dragstart", this.handleTopDragStart), e.addEventListener("dragstart", this.handleTopDragStartCapture, !0), e.addEventListener("dragend", this.handleTopDragEndCapture, !0), e.addEventListener("dragenter", this.handleTopDragEnter), e.addEventListener("dragenter", this.handleTopDragEnterCapture, !0), e.addEventListener("dragleave", this.handleTopDragLeaveCapture, !0), e.addEventListener("dragover", this.handleTopDragOver), e.addEventListener("dragover", this.handleTopDragOverCapture, !0), e.addEventListener("drop", this.handleTopDrop), e.addEventListener("drop", this.handleTopDropCapture, !0))
                        }
                    }, {
                        key: "removeEventListeners",
                        value: function(e) {
                            e.removeEventListener && (e.removeEventListener("dragstart", this.handleTopDragStart), e.removeEventListener("dragstart", this.handleTopDragStartCapture, !0), e.removeEventListener("dragend", this.handleTopDragEndCapture, !0), e.removeEventListener("dragenter", this.handleTopDragEnter), e.removeEventListener("dragenter", this.handleTopDragEnterCapture, !0), e.removeEventListener("dragleave", this.handleTopDragLeaveCapture, !0), e.removeEventListener("dragover", this.handleTopDragOver), e.removeEventListener("dragover", this.handleTopDragOverCapture, !0), e.removeEventListener("drop", this.handleTopDrop), e.removeEventListener("drop", this.handleTopDropCapture, !0))
                        }
                    }, {
                        key: "getCurrentSourceNodeOptions",
                        value: function() {
                            var e = this.monitor.getSourceId(),
                                t = this.sourceNodeOptions.get(e);
                            return C({
                                dropEffect: this.altKeyPressed ? "copy" : "move"
                            }, t || {})
                        }
                    }, {
                        key: "getCurrentDropEffect",
                        value: function() {
                            return this.isDraggingNativeItem() ? "copy" : this.getCurrentSourceNodeOptions().dropEffect
                        }
                    }, {
                        key: "getCurrentSourcePreviewNodeOptions",
                        value: function() {
                            var e = this.monitor.getSourceId();
                            return C({
                                anchorX: .5,
                                anchorY: .5,
                                captureDraggingState: !1
                            }, this.sourcePreviewNodeOptions.get(e) || {})
                        }
                    }, {
                        key: "isDraggingNativeItem",
                        value: function() {
                            var e = this.monitor.getItemType();
                            return Object.keys(n).some((function(t) {
                                return n[t] === e
                            }))
                        }
                    }, {
                        key: "beginDragNativeItem",
                        value: function(e, t) {
                            this.clearCurrentDragSourceNode(), this.currentNativeSource = function(e, t) {
                                var r = new T(D[e]);
                                return r.loadDataTransfer(t), r
                            }(e, t), this.currentNativeHandle = this.registry.addSource(e, this.currentNativeSource), this.actions.beginDrag([this.currentNativeHandle])
                        }
                    }, {
                        key: "setCurrentDragSourceNode",
                        value: function(e) {
                            var t = this;
                            this.clearCurrentDragSourceNode(), this.currentDragSourceNode = e, this.mouseMoveTimeoutTimer = setTimeout((function() {
                                var e;
                                return null === (e = t.rootElement) || void 0 === e ? void 0 : e.addEventListener("mousemove", t.endDragIfSourceWasRemovedFromDOM, !0)
                            }), 1e3)
                        }
                    }, {
                        key: "clearCurrentDragSourceNode",
                        value: function() {
                            var e;
                            return !!this.currentDragSourceNode && (this.currentDragSourceNode = null, this.rootElement && (null === (e = this.window) || void 0 === e || e.clearTimeout(this.mouseMoveTimeoutTimer || void 0), this.rootElement.removeEventListener("mousemove", this.endDragIfSourceWasRemovedFromDOM, !0)), this.mouseMoveTimeoutTimer = null, !0)
                        }
                    }, {
                        key: "handleDragStart",
                        value: function(e, t) {
                            e.defaultPrevented || (this.dragStartSourceIds || (this.dragStartSourceIds = []), this.dragStartSourceIds.unshift(t))
                        }
                    }, {
                        key: "handleDragEnter",
                        value: function(e, t) {
                            this.dragEnterTargetIds.unshift(t)
                        }
                    }, {
                        key: "handleDragOver",
                        value: function(e, t) {
                            null === this.dragOverTargetIds && (this.dragOverTargetIds = []), this.dragOverTargetIds.unshift(t)
                        }
                    }, {
                        key: "handleDrop",
                        value: function(e, t) {
                            this.dropTargetIds.unshift(t)
                        }
                    }]) && N(t.prototype, r), i && N(t, i), e
                }(),
                R = function(e, t, r) {
                    return new j(e, t, r)
                }
        },
        89742: (e, t, r) => {
            r.d(t, {
                DndContext: () => n
            });
            var n = (0, r(59496).createContext)({
                dragDropManager: void 0
            })
        },
        86416: (e, t, r) => {
            r.d(t, {
                DndProvider: () => Ze
            });
            var n = r(96349),
                i = r(59496),
                o = r(46123),
                a = "dnd-core/INIT_COORDS",
                u = "dnd-core/BEGIN_DRAG",
                s = "dnd-core/PUBLISH_DRAG_SOURCE",
                c = "dnd-core/HOVER",
                l = "dnd-core/DROP",
                d = "dnd-core/END_DRAG";

            function f(e, t) {
                return {
                    type: a,
                    payload: {
                        sourceClientOffset: t || null,
                        clientOffset: e || null
                    }
                }
            }

            function g(e) {
                return (g = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function h(e, t, r) {
                return t.split(".").reduce((function(e, t) {
                    return e && e[t] ? e[t] : r || null
                }), e)
            }

            function v(e, t) {
                return e.filter((function(e) {
                    return e !== t
                }))
            }

            function p(e) {
                return "object" === g(e)
            }

            function y(e, t) {
                var r = new Map,
                    n = function(e) {
                        r.set(e, r.has(e) ? r.get(e) + 1 : 1)
                    };
                e.forEach(n), t.forEach(n);
                var i = [];
                return r.forEach((function(e, t) {
                    1 === e && i.push(t)
                })), i
            }
            var b = {
                type: a,
                payload: {
                    clientOffset: null,
                    sourceClientOffset: null
                }
            };

            function m(e) {
                return function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                        r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                            publishSource: !0
                        },
                        n = r.publishSource,
                        i = void 0 === n || n,
                        o = r.clientOffset,
                        a = r.getSourceClientOffset,
                        s = e.getMonitor(),
                        c = e.getRegistry();
                    e.dispatch(f(o)), O(t, s, c);
                    var l = T(t, s);
                    if (null !== l) {
                        var d = null;
                        if (o) {
                            if (!a) throw new Error("getSourceClientOffset must be defined");
                            D(a), d = a(l)
                        }
                        e.dispatch(f(o, d));
                        var g = c.getSource(l),
                            h = g.beginDrag(s, l);
                        if (null != h) {
                            S(h), c.pinSource(l);
                            var v = c.getSourceType(l);
                            return {
                                type: u,
                                payload: {
                                    itemType: v,
                                    item: h,
                                    sourceId: l,
                                    clientOffset: o || null,
                                    sourceClientOffset: d || null,
                                    isSourcePublic: !!i
                                }
                            }
                        }
                    } else e.dispatch(b)
                }
            }

            function O(e, t, r) {
                (0, o.invariant)(!t.isDragging(), "Cannot call beginDrag while dragging."), e.forEach((function(e) {
                    (0, o.invariant)(r.getSource(e), "Expected sourceIds to be registered.")
                }))
            }

            function D(e) {
                (0, o.invariant)("function" == typeof e, "When clientOffset is provided, getSourceClientOffset must be a function.")
            }

            function S(e) {
                (0, o.invariant)(p(e), "Item must be an object.")
            }

            function T(e, t) {
                for (var r = null, n = e.length - 1; n >= 0; n--)
                    if (t.canDragSource(e[n])) {
                        r = e[n];
                        break
                    }
                return r
            }

            function w(e) {
                return function() {
                    if (e.getMonitor().isDragging()) return {
                        type: s
                    }
                }
            }

            function I(e, t) {
                return null === t ? null === e : Array.isArray(e) ? e.some((function(e) {
                    return e === t
                })) : e === t
            }

            function E(e) {
                return function(t) {
                    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = r.clientOffset;
                    k(t);
                    var i = t.slice(0),
                        o = e.getMonitor(),
                        a = e.getRegistry();
                    C(i, o, a);
                    var u = o.getItemType();
                    return P(i, a, u), N(i, o, a), {
                        type: c,
                        payload: {
                            targetIds: i,
                            clientOffset: n || null
                        }
                    }
                }
            }

            function k(e) {
                (0, o.invariant)(Array.isArray(e), "Expected targetIds to be an array.")
            }

            function C(e, t, r) {
                (0, o.invariant)(t.isDragging(), "Cannot call hover while not dragging."), (0, o.invariant)(!t.didDrop(), "Cannot call hover after drop.");
                for (var n = 0; n < e.length; n++) {
                    var i = e[n];
                    (0, o.invariant)(e.lastIndexOf(i) === n, "Expected targetIds to be unique in the passed array.");
                    var a = r.getTarget(i);
                    (0, o.invariant)(a, "Expected targetIds to be registered.")
                }
            }

            function P(e, t, r) {
                for (var n = e.length - 1; n >= 0; n--) {
                    var i = e[n];
                    I(t.getTargetType(i), r) || e.splice(n, 1)
                }
            }

            function N(e, t, r) {
                e.forEach((function(e) {
                    r.getTarget(e).hover(t, e)
                }))
            }

            function j(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function R(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? j(Object(r), !0).forEach((function(t) {
                        x(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : j(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function x(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function A(e) {
                return function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        r = e.getMonitor(),
                        n = e.getRegistry();
                    M(r);
                    var i = _(r);
                    i.forEach((function(i, o) {
                        var a = L(i, o, n, r),
                            u = {
                                type: l,
                                payload: {
                                    dropResult: R(R({}, t), a)
                                }
                            };
                        e.dispatch(u)
                    }))
                }
            }

            function M(e) {
                (0, o.invariant)(e.isDragging(), "Cannot call drop while not dragging."), (0, o.invariant)(!e.didDrop(), "Cannot call drop twice during one drag operation.")
            }

            function L(e, t, r, n) {
                var i = r.getTarget(e),
                    a = i ? i.drop(n, e) : void 0;
                return function(e) {
                    (0, o.invariant)(void 0 === e || p(e), "Drop result must either be an object or undefined.")
                }(a), void 0 === a && (a = 0 === t ? {} : n.getDropResult()), a
            }

            function _(e) {
                var t = e.getTargetIds().filter(e.canDropOnTarget, e);
                return t.reverse(), t
            }

            function H(e) {
                return function() {
                    var t = e.getMonitor(),
                        r = e.getRegistry();
                    ! function(e) {
                        (0, o.invariant)(e.isDragging(), "Cannot call endDrag while not dragging.")
                    }(t);
                    var n = t.getSourceId();
                    null != n && (r.getSource(n, !0).endDrag(t, n), r.unpinSource());
                    return {
                        type: d
                    }
                }
            }

            function U(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var B = function() {
                    function e(t, r) {
                        var n = this;
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.isSetUp = !1, this.handleRefCountChange = function() {
                            var e = n.store.getState().refCount > 0;
                            n.backend && (e && !n.isSetUp ? (n.backend.setup(), n.isSetUp = !0) : !e && n.isSetUp && (n.backend.teardown(), n.isSetUp = !1))
                        }, this.store = t, this.monitor = r, t.subscribe(this.handleRefCountChange)
                    }
                    var t, r, n;
                    return t = e, (r = [{
                        key: "receiveBackend",
                        value: function(e) {
                            this.backend = e
                        }
                    }, {
                        key: "getMonitor",
                        value: function() {
                            return this.monitor
                        }
                    }, {
                        key: "getBackend",
                        value: function() {
                            return this.backend
                        }
                    }, {
                        key: "getRegistry",
                        value: function() {
                            return this.monitor.registry
                        }
                    }, {
                        key: "getActions",
                        value: function() {
                            var e = this,
                                t = this.store.dispatch,
                                r = function(e) {
                                    return {
                                        beginDrag: m(e),
                                        publishDragSource: w(e),
                                        hover: E(e),
                                        drop: A(e),
                                        endDrag: H(e)
                                    }
                                }(this);
                            return Object.keys(r).reduce((function(n, i) {
                                var o, a = r[i];
                                return n[i] = (o = a, function() {
                                    for (var r = arguments.length, n = new Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                                    var a = o.apply(e, n);
                                    void 0 !== a && t(a)
                                }), n
                            }), {})
                        }
                    }, {
                        key: "dispatch",
                        value: function(e) {
                            this.store.dispatch(e)
                        }
                    }]) && U(t.prototype, r), n && U(t, n), e
                }(),
                F = r(83243),
                G = function(e, t) {
                    return e === t
                };

            function X(e, t) {
                return !e && !t || !(!e || !t) && (e.x === t.x && e.y === t.y)
            }

            function Y(e, t) {
                var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : G;
                if (e.length !== t.length) return !1;
                for (var n = 0; n < e.length; ++n)
                    if (!r(e[n], t[n])) return !1;
                return !0
            }

            function V(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function W(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? V(Object(r), !0).forEach((function(t) {
                        q(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : V(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function q(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var K = {
                initialSourceClientOffset: null,
                initialClientOffset: null,
                clientOffset: null
            };

            function z() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : K,
                    t = arguments.length > 1 ? arguments[1] : void 0,
                    r = t.payload;
                switch (t.type) {
                    case a:
                    case u:
                        return {
                            initialSourceClientOffset: r.sourceClientOffset,
                            initialClientOffset: r.clientOffset,
                            clientOffset: r.clientOffset
                        };
                    case c:
                        return X(e.clientOffset, r.clientOffset) ? e : W(W({}, e), {}, {
                            clientOffset: r.clientOffset
                        });
                    case d:
                    case l:
                        return K;
                    default:
                        return e
                }
            }
            var $ = "dnd-core/ADD_SOURCE",
                Q = "dnd-core/ADD_TARGET",
                J = "dnd-core/REMOVE_SOURCE",
                Z = "dnd-core/REMOVE_TARGET";

            function ee(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function te(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? ee(Object(r), !0).forEach((function(t) {
                        re(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ee(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function re(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var ne = {
                itemType: null,
                item: null,
                sourceId: null,
                targetIds: [],
                dropResult: null,
                didDrop: !1,
                isSourcePublic: null
            };

            function ie() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ne,
                    t = arguments.length > 1 ? arguments[1] : void 0,
                    r = t.payload;
                switch (t.type) {
                    case u:
                        return te(te({}, e), {}, {
                            itemType: r.itemType,
                            item: r.item,
                            sourceId: r.sourceId,
                            isSourcePublic: r.isSourcePublic,
                            dropResult: null,
                            didDrop: !1
                        });
                    case s:
                        return te(te({}, e), {}, {
                            isSourcePublic: !0
                        });
                    case c:
                        return te(te({}, e), {}, {
                            targetIds: r.targetIds
                        });
                    case Z:
                        return -1 === e.targetIds.indexOf(r.targetId) ? e : te(te({}, e), {}, {
                            targetIds: v(e.targetIds, r.targetId)
                        });
                    case l:
                        return te(te({}, e), {}, {
                            dropResult: r.dropResult,
                            didDrop: !0,
                            targetIds: []
                        });
                    case d:
                        return te(te({}, e), {}, {
                            itemType: null,
                            item: null,
                            sourceId: null,
                            dropResult: null,
                            didDrop: !1,
                            isSourcePublic: null,
                            targetIds: []
                        });
                    default:
                        return e
                }
            }

            function oe() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                    t = arguments.length > 1 ? arguments[1] : void 0;
                switch (t.type) {
                    case $:
                    case Q:
                        return e + 1;
                    case J:
                    case Z:
                        return e - 1;
                    default:
                        return e
                }
            }
            var ae = [],
                ue = [];

            function se(e, t) {
                return e !== ae && (e === ue || void 0 === t || (r = e, t.filter((function(e) {
                    return r.indexOf(e) > -1
                }))).length > 0);
                var r
            }

            function ce() {
                var e = arguments.length > 1 ? arguments[1] : void 0;
                switch (e.type) {
                    case c:
                        break;
                    case $:
                    case Q:
                    case Z:
                    case J:
                        return ae;
                    case u:
                    case s:
                    case d:
                    case l:
                    default:
                        return ue
                }
                var t = e.payload,
                    r = t.targetIds,
                    n = void 0 === r ? [] : r,
                    i = t.prevTargetIds,
                    o = void 0 === i ? [] : i,
                    a = y(n, o),
                    f = a.length > 0 || !Y(n, o);
                if (!f) return ae;
                var g = o[o.length - 1],
                    h = n[n.length - 1];
                return g !== h && (g && a.push(g), h && a.push(h)), a
            }

            function le() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                return e + 1
            }

            function de(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function fe(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? de(Object(r), !0).forEach((function(t) {
                        ge(e, t, r[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : de(Object(r)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    }))
                }
                return e
            }

            function ge(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function he() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments.length > 1 ? arguments[1] : void 0;
                return {
                    dirtyHandlerIds: ce(e.dirtyHandlerIds, {
                        type: t.type,
                        payload: fe(fe({}, t.payload), {}, {
                            prevTargetIds: h(e, "dragOperation.targetIds", [])
                        })
                    }),
                    dragOffset: z(e.dragOffset, t),
                    refCount: oe(e.refCount, t),
                    dragOperation: ie(e.dragOperation, t),
                    stateId: le(e.stateId)
                }
            }

            function ve(e, t) {
                return {
                    x: e.x - t.x,
                    y: e.y - t.y
                }
            }

            function pe(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            ae.__IS_NONE__ = !0, ue.__IS_ALL__ = !0;
            var ye, be = function() {
                    function e(t, r) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.store = t, this.registry = r
                    }
                    var t, r, n;
                    return t = e, (r = [{
                        key: "subscribeToStateChange",
                        value: function(e) {
                            var t = this,
                                r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                    handlerIds: void 0
                                },
                                n = r.handlerIds;
                            (0, o.invariant)("function" == typeof e, "listener must be a function."), (0, o.invariant)(void 0 === n || Array.isArray(n), "handlerIds, when specified, must be an array of strings.");
                            var i = this.store.getState().stateId,
                                a = function() {
                                    var r = t.store.getState(),
                                        o = r.stateId;
                                    try {
                                        o === i || o === i + 1 && !se(r.dirtyHandlerIds, n) || e()
                                    } finally {
                                        i = o
                                    }
                                };
                            return this.store.subscribe(a)
                        }
                    }, {
                        key: "subscribeToOffsetChange",
                        value: function(e) {
                            var t = this;
                            (0, o.invariant)("function" == typeof e, "listener must be a function.");
                            var r = this.store.getState().dragOffset;
                            return this.store.subscribe((function() {
                                var n = t.store.getState().dragOffset;
                                n !== r && (r = n, e())
                            }))
                        }
                    }, {
                        key: "canDragSource",
                        value: function(e) {
                            if (!e) return !1;
                            var t = this.registry.getSource(e);
                            return (0, o.invariant)(t, "Expected to find a valid source. sourceId=".concat(e)), !this.isDragging() && t.canDrag(this, e)
                        }
                    }, {
                        key: "canDropOnTarget",
                        value: function(e) {
                            if (!e) return !1;
                            var t = this.registry.getTarget(e);
                            return (0, o.invariant)(t, "Expected to find a valid target. targetId=".concat(e)), !(!this.isDragging() || this.didDrop()) && I(this.registry.getTargetType(e), this.getItemType()) && t.canDrop(this, e)
                        }
                    }, {
                        key: "isDragging",
                        value: function() {
                            return Boolean(this.getItemType())
                        }
                    }, {
                        key: "isDraggingSource",
                        value: function(e) {
                            if (!e) return !1;
                            var t = this.registry.getSource(e, !0);
                            return (0, o.invariant)(t, "Expected to find a valid source. sourceId=".concat(e)), !(!this.isDragging() || !this.isSourcePublic()) && this.registry.getSourceType(e) === this.getItemType() && t.isDragging(this, e)
                        }
                    }, {
                        key: "isOverTarget",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                                shallow: !1
                            };
                            if (!e) return !1;
                            var r = t.shallow;
                            if (!this.isDragging()) return !1;
                            var n = this.registry.getTargetType(e),
                                i = this.getItemType();
                            if (i && !I(n, i)) return !1;
                            var o = this.getTargetIds();
                            if (!o.length) return !1;
                            var a = o.indexOf(e);
                            return r ? a === o.length - 1 : a > -1
                        }
                    }, {
                        key: "getItemType",
                        value: function() {
                            return this.store.getState().dragOperation.itemType
                        }
                    }, {
                        key: "getItem",
                        value: function() {
                            return this.store.getState().dragOperation.item
                        }
                    }, {
                        key: "getSourceId",
                        value: function() {
                            return this.store.getState().dragOperation.sourceId
                        }
                    }, {
                        key: "getTargetIds",
                        value: function() {
                            return this.store.getState().dragOperation.targetIds
                        }
                    }, {
                        key: "getDropResult",
                        value: function() {
                            return this.store.getState().dragOperation.dropResult
                        }
                    }, {
                        key: "didDrop",
                        value: function() {
                            return this.store.getState().dragOperation.didDrop
                        }
                    }, {
                        key: "isSourcePublic",
                        value: function() {
                            return Boolean(this.store.getState().dragOperation.isSourcePublic)
                        }
                    }, {
                        key: "getInitialClientOffset",
                        value: function() {
                            return this.store.getState().dragOffset.initialClientOffset
                        }
                    }, {
                        key: "getInitialSourceClientOffset",
                        value: function() {
                            return this.store.getState().dragOffset.initialSourceClientOffset
                        }
                    }, {
                        key: "getClientOffset",
                        value: function() {
                            return this.store.getState().dragOffset.clientOffset
                        }
                    }, {
                        key: "getSourceClientOffset",
                        value: function() {
                            return e = this.store.getState().dragOffset, n = e.clientOffset, i = e.initialClientOffset,
                                o = e.initialSourceClientOffset, n && i && o ? ve((r = o, {
                                    x: (t = n).x + r.x,
                                    y: t.y + r.y
                                }), i) : null;
                            var e, t, r, n, i, o
                        }
                    }, {
                        key: "getDifferenceFromInitialOffset",
                        value: function() {
                            return e = this.store.getState().dragOffset, t = e.clientOffset, r = e.initialClientOffset, t && r ? ve(t, r) : null;
                            var e, t, r
                        }
                    }]) && pe(t.prototype, r), n && pe(t, n), e
                }(),
                me = 0;

            function Oe(e) {
                return (Oe = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function De(e, t) {
                t && Array.isArray(e) ? e.forEach((function(e) {
                    return De(e, !1)
                })) : (0, o.invariant)("string" == typeof e || "symbol" === Oe(e), t ? "Type can only be a string, a symbol, or an array of either." : "Type can only be a string or a symbol.")
            }

            function Se(e) {
                we.length || (Te(), !0), we[we.length] = e
            }! function(e) {
                e.SOURCE = "SOURCE", e.TARGET = "TARGET"
            }(ye || (ye = {}));
            var Te, we = [],
                Ie = 0;

            function Ee() {
                for (; Ie < we.length;) {
                    var e = Ie;
                    if (Ie += 1, we[e].call(), Ie > 1024) {
                        for (var t = 0, r = we.length - Ie; t < r; t++) we[t] = we[t + Ie];
                        we.length -= Ie, Ie = 0
                    }
                }
                we.length = 0, Ie = 0, !1
            }
            var ke, Ce, Pe, Ne = void 0 !== r.g ? r.g : self,
                je = Ne.MutationObserver || Ne.WebKitMutationObserver;

            function Re(e) {
                return function() {
                    var t = setTimeout(n, 0),
                        r = setInterval(n, 50);

                    function n() {
                        clearTimeout(t), clearInterval(r), e()
                    }
                }
            }
            "function" == typeof je ? (ke = 1, Ce = new je(Ee), Pe = document.createTextNode(""), Ce.observe(Pe, {
                characterData: !0
            }), Te = function() {
                ke = -ke, Pe.data = ke
            }) : Te = Re(Ee), Se.requestFlush = Te, Se.makeRequestCallFromTimer = Re;
            var xe = [],
                Ae = [],
                Me = Se.makeRequestCallFromTimer((function() {
                    if (Ae.length) throw Ae.shift()
                }));

            function Le(e) {
                var t;
                (t = xe.length ? xe.pop() : new _e).task = e, Se(t)
            }
            var _e = function() {
                function e() {}
                return e.prototype.call = function() {
                    try {
                        this.task.call()
                    } catch (e) {
                        Le.onerror ? Le.onerror(e) : (Ae.push(e), Me())
                    } finally {
                        this.task = null, xe[xe.length] = this
                    }
                }, e
            }();

            function He(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }

            function Ue(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var r = [],
                        n = !0,
                        i = !1,
                        o = void 0;
                    try {
                        for (var a, u = e[Symbol.iterator](); !(n = (a = u.next()).done) && (r.push(a.value), !t || r.length !== t); n = !0);
                    } catch (e) {
                        i = !0, o = e
                    } finally {
                        try {
                            n || null == u.return || u.return()
                        } finally {
                            if (i) throw o
                        }
                    }
                    return r
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return Be(e, t);
                    var r = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === r && e.constructor && (r = e.constructor.name);
                    if ("Map" === r || "Set" === r) return Array.from(e);
                    if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Be(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function Be(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n
            }

            function Fe(e) {
                var t = (me++).toString();
                switch (e) {
                    case ye.SOURCE:
                        return "S".concat(t);
                    case ye.TARGET:
                        return "T".concat(t);
                    default:
                        throw new Error("Unknown Handler Role: ".concat(e))
                }
            }

            function Ge(e) {
                switch (e[0]) {
                    case "S":
                        return ye.SOURCE;
                    case "T":
                        return ye.TARGET;
                    default:
                        (0, o.invariant)(!1, "Cannot parse handler ID: ".concat(e))
                }
            }

            function Xe(e, t) {
                var r = e.entries(),
                    n = !1;
                do {
                    var i = r.next(),
                        o = i.done;
                    if (Ue(i.value, 2)[1] === t) return !0;
                    n = !!o
                } while (!n);
                return !1
            }
            var Ye = function() {
                function e(t) {
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this.types = new Map, this.dragSources = new Map, this.dropTargets = new Map, this.pinnedSourceId = null, this.pinnedSource = null, this.store = t
                }
                var t, r, n;
                return t = e, (r = [{
                    key: "addSource",
                    value: function(e, t) {
                        De(e),
                            function(e) {
                                (0, o.invariant)("function" == typeof e.canDrag, "Expected canDrag to be a function."), (0, o.invariant)("function" == typeof e.beginDrag, "Expected beginDrag to be a function."), (0, o.invariant)("function" == typeof e.endDrag, "Expected endDrag to be a function.")
                            }(t);
                        var r = this.addHandler(ye.SOURCE, e, t);
                        return this.store.dispatch(function(e) {
                            return {
                                type: $,
                                payload: {
                                    sourceId: e
                                }
                            }
                        }(r)), r
                    }
                }, {
                    key: "addTarget",
                    value: function(e, t) {
                        De(e, !0),
                            function(e) {
                                (0, o.invariant)("function" == typeof e.canDrop, "Expected canDrop to be a function."), (0, o.invariant)("function" == typeof e.hover, "Expected hover to be a function."), (0, o.invariant)("function" == typeof e.drop, "Expected beginDrag to be a function.")
                            }(t);
                        var r = this.addHandler(ye.TARGET, e, t);
                        return this.store.dispatch(function(e) {
                            return {
                                type: Q,
                                payload: {
                                    targetId: e
                                }
                            }
                        }(r)), r
                    }
                }, {
                    key: "containsHandler",
                    value: function(e) {
                        return Xe(this.dragSources, e) || Xe(this.dropTargets, e)
                    }
                }, {
                    key: "getSource",
                    value: function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        (0, o.invariant)(this.isSourceId(e), "Expected a valid source ID.");
                        var r = t && e === this.pinnedSourceId,
                            n = r ? this.pinnedSource : this.dragSources.get(e);
                        return n
                    }
                }, {
                    key: "getTarget",
                    value: function(e) {
                        return (0, o.invariant)(this.isTargetId(e), "Expected a valid target ID."), this.dropTargets.get(e)
                    }
                }, {
                    key: "getSourceType",
                    value: function(e) {
                        return (0, o.invariant)(this.isSourceId(e), "Expected a valid source ID."), this.types.get(e)
                    }
                }, {
                    key: "getTargetType",
                    value: function(e) {
                        return (0, o.invariant)(this.isTargetId(e), "Expected a valid target ID."), this.types.get(e)
                    }
                }, {
                    key: "isSourceId",
                    value: function(e) {
                        return Ge(e) === ye.SOURCE
                    }
                }, {
                    key: "isTargetId",
                    value: function(e) {
                        return Ge(e) === ye.TARGET
                    }
                }, {
                    key: "removeSource",
                    value: function(e) {
                        var t = this;
                        (0, o.invariant)(this.getSource(e), "Expected an existing source."), this.store.dispatch(function(e) {
                            return {
                                type: J,
                                payload: {
                                    sourceId: e
                                }
                            }
                        }(e)), Le((function() {
                            t.dragSources.delete(e), t.types.delete(e)
                        }))
                    }
                }, {
                    key: "removeTarget",
                    value: function(e) {
                        (0, o.invariant)(this.getTarget(e), "Expected an existing target."), this.store.dispatch(function(e) {
                            return {
                                type: Z,
                                payload: {
                                    targetId: e
                                }
                            }
                        }(e)), this.dropTargets.delete(e), this.types.delete(e)
                    }
                }, {
                    key: "pinSource",
                    value: function(e) {
                        var t = this.getSource(e);
                        (0, o.invariant)(t, "Expected an existing source."), this.pinnedSourceId = e, this.pinnedSource = t
                    }
                }, {
                    key: "unpinSource",
                    value: function() {
                        (0,
                            o.invariant)(this.pinnedSource, "No source is pinned at the time."), this.pinnedSourceId = null, this.pinnedSource = null
                    }
                }, {
                    key: "addHandler",
                    value: function(e, t, r) {
                        var n = Fe(e);
                        return this.types.set(n, t), e === ye.SOURCE ? this.dragSources.set(n, r) : e === ye.TARGET && this.dropTargets.set(n, r), n
                    }
                }]) && He(t.prototype, r), n && He(t, n), e
            }();

            function Ve(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
                    r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                    i = We(n),
                    o = new be(i, new Ye(i)),
                    a = new B(i, o),
                    u = e(a, t, r);
                return a.receiveBackend(u), a
            }

            function We(e) {
                var t = "undefined" != typeof window && window.__REDUX_DEVTOOLS_EXTENSION__;
                return (0, F.createStore)(he, e && t && t({
                    name: "dnd-core",
                    instanceId: "dnd-core"
                }))
            }
            var qe = r(89742);

            function Ke(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(e))) return;
                    var r = [],
                        n = !0,
                        i = !1,
                        o = void 0;
                    try {
                        for (var a, u = e[Symbol.iterator](); !(n = (a = u.next()).done) && (r.push(a.value), !t || r.length !== t); n = !0);
                    } catch (e) {
                        i = !0, o = e
                    } finally {
                        try {
                            n || null == u.return || u.return()
                        } finally {
                            if (i) throw o
                        }
                    }
                    return r
                }(e, t) || function(e, t) {
                    if (!e) return;
                    if ("string" == typeof e) return ze(e, t);
                    var r = Object.prototype.toString.call(e).slice(8, -1);
                    "Object" === r && e.constructor && (r = e.constructor.name);
                    if ("Map" === r || "Set" === r) return Array.from(e);
                    if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ze(e, t)
                }(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function ze(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                return n
            }

            function $e(e, t) {
                if (null == e) return {};
                var r, n, i = function(e, t) {
                    if (null == e) return {};
                    var r, n, i = {},
                        o = Object.keys(e);
                    for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || (i[r] = e[r]);
                    return i
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (i[r] = e[r])
                }
                return i
            }
            var Qe = 0,
                Je = Symbol.for("__REACT_DND_CONTEXT_INSTANCE__"),
                Ze = (0, i.memo)((function(e) {
                    var t = e.children,
                        r = Ke(function(e) {
                            if ("manager" in e) {
                                return [{
                                    dragDropManager: e.manager
                                }, !1]
                            }
                            var t = function(e) {
                                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : et(),
                                        r = arguments.length > 2 ? arguments[2] : void 0,
                                        n = arguments.length > 3 ? arguments[3] : void 0,
                                        i = t;
                                    i[Je] || (i[Je] = {
                                        dragDropManager: Ve(e, t, r, n)
                                    });
                                    return i[Je]
                                }(e.backend, e.context, e.options, e.debugMode),
                                r = !e.context;
                            return [t, r]
                        }($e(e, ["children"])), 2),
                        o = r[0],
                        a = r[1];
                    return (0, i.useEffect)((function() {
                        if (a) {
                            var e = et();
                            return ++Qe,
                                function() {
                                    0 == --Qe && (e[Je] = null)
                                }
                        }
                    }), []), (0, n.jsx)(qe.DndContext.Provider, Object.assign({
                        value: o
                    }, {
                        children: t
                    }), void 0)
                }));

            function et() {
                return void 0 !== r.g ? r.g : window
            }
        },
        55585: (e, t, r) => {
            r.d(t, {
                DragSourceMonitorImpl: () => u
            });
            var n = r(46123);

            function i(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0),
                        Object.defineProperty(e, n.key, n)
                }
            }
            var o = !1,
                a = !1,
                u = function() {
                    function e(t) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.sourceId = null, this.internalMonitor = t.getMonitor()
                    }
                    var t, r, u;
                    return t = e, (r = [{
                        key: "receiveHandlerId",
                        value: function(e) {
                            this.sourceId = e
                        }
                    }, {
                        key: "getHandlerId",
                        value: function() {
                            return this.sourceId
                        }
                    }, {
                        key: "canDrag",
                        value: function() {
                            (0, n.invariant)(!o, "You may not call monitor.canDrag() inside your canDrag() implementation. Read more: http://react-dnd.github.io/react-dnd/docs/api/drag-source-monitor");
                            try {
                                return o = !0, this.internalMonitor.canDragSource(this.sourceId)
                            } finally {
                                o = !1
                            }
                        }
                    }, {
                        key: "isDragging",
                        value: function() {
                            if (!this.sourceId) return !1;
                            (0, n.invariant)(!a, "You may not call monitor.isDragging() inside your isDragging() implementation. Read more: http://react-dnd.github.io/react-dnd/docs/api/drag-source-monitor");
                            try {
                                return a = !0, this.internalMonitor.isDraggingSource(this.sourceId)
                            } finally {
                                a = !1
                            }
                        }
                    }, {
                        key: "subscribeToStateChange",
                        value: function(e, t) {
                            return this.internalMonitor.subscribeToStateChange(e, t)
                        }
                    }, {
                        key: "isDraggingSource",
                        value: function(e) {
                            return this.internalMonitor.isDraggingSource(e)
                        }
                    }, {
                        key: "isOverTarget",
                        value: function(e, t) {
                            return this.internalMonitor.isOverTarget(e, t)
                        }
                    }, {
                        key: "getTargetIds",
                        value: function() {
                            return this.internalMonitor.getTargetIds()
                        }
                    }, {
                        key: "isSourcePublic",
                        value: function() {
                            return this.internalMonitor.isSourcePublic()
                        }
                    }, {
                        key: "getSourceId",
                        value: function() {
                            return this.internalMonitor.getSourceId()
                        }
                    }, {
                        key: "subscribeToOffsetChange",
                        value: function(e) {
                            return this.internalMonitor.subscribeToOffsetChange(e)
                        }
                    }, {
                        key: "canDragSource",
                        value: function(e) {
                            return this.internalMonitor.canDragSource(e)
                        }
                    }, {
                        key: "canDropOnTarget",
                        value: function(e) {
                            return this.internalMonitor.canDropOnTarget(e)
                        }
                    }, {
                        key: "getItemType",
                        value: function() {
                            return this.internalMonitor.getItemType()
                        }
                    }, {
                        key: "getItem",
                        value: function() {
                            return this.internalMonitor.getItem()
                        }
                    }, {
                        key: "getDropResult",
                        value: function() {
                            return this.internalMonitor.getDropResult()
                        }
                    }, {
                        key: "didDrop",
                        value: function() {
                            return this.internalMonitor.didDrop()
                        }
                    }, {
                        key: "getInitialClientOffset",
                        value: function() {
                            return this.internalMonitor.getInitialClientOffset()
                        }
                    }, {
                        key: "getInitialSourceClientOffset",
                        value: function() {
                            return this.internalMonitor.getInitialSourceClientOffset()
                        }
                    }, {
                        key: "getSourceClientOffset",
                        value: function() {
                            return this.internalMonitor.getSourceClientOffset()
                        }
                    }, {
                        key: "getClientOffset",
                        value: function() {
                            return this.internalMonitor.getClientOffset()
                        }
                    }, {
                        key: "getDifferenceFromInitialOffset",
                        value: function() {
                            return this.internalMonitor.getDifferenceFromInitialOffset()
                        }
                    }]) && i(t.prototype, r), u && i(t, u), e
                }()
        },
        74584: (e, t, r) => {
            r.d(t, {
                DropTargetMonitorImpl: () => a
            });
            var n = r(46123);

            function i(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var o = !1,
                a = function() {
                    function e(t) {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.targetId = null,
                            this.internalMonitor = t.getMonitor()
                    }
                    var t, r, a;
                    return t = e, (r = [{
                        key: "receiveHandlerId",
                        value: function(e) {
                            this.targetId = e
                        }
                    }, {
                        key: "getHandlerId",
                        value: function() {
                            return this.targetId
                        }
                    }, {
                        key: "subscribeToStateChange",
                        value: function(e, t) {
                            return this.internalMonitor.subscribeToStateChange(e, t)
                        }
                    }, {
                        key: "canDrop",
                        value: function() {
                            if (!this.targetId) return !1;
                            (0, n.invariant)(!o, "You may not call monitor.canDrop() inside your canDrop() implementation. Read more: http://react-dnd.github.io/react-dnd/docs/api/drop-target-monitor");
                            try {
                                return o = !0, this.internalMonitor.canDropOnTarget(this.targetId)
                            } finally {
                                o = !1
                            }
                        }
                    }, {
                        key: "isOver",
                        value: function(e) {
                            return !!this.targetId && this.internalMonitor.isOverTarget(this.targetId, e)
                        }
                    }, {
                        key: "getItemType",
                        value: function() {
                            return this.internalMonitor.getItemType()
                        }
                    }, {
                        key: "getItem",
                        value: function() {
                            return this.internalMonitor.getItem()
                        }
                    }, {
                        key: "getDropResult",
                        value: function() {
                            return this.internalMonitor.getDropResult()
                        }
                    }, {
                        key: "didDrop",
                        value: function() {
                            return this.internalMonitor.didDrop()
                        }
                    }, {
                        key: "getInitialClientOffset",
                        value: function() {
                            return this.internalMonitor.getInitialClientOffset()
                        }
                    }, {
                        key: "getInitialSourceClientOffset",
                        value: function() {
                            return this.internalMonitor.getInitialSourceClientOffset()
                        }
                    }, {
                        key: "getSourceClientOffset",
                        value: function() {
                            return this.internalMonitor.getSourceClientOffset()
                        }
                    }, {
                        key: "getClientOffset",
                        value: function() {
                            return this.internalMonitor.getClientOffset()
                        }
                    }, {
                        key: "getDifferenceFromInitialOffset",
                        value: function() {
                            return this.internalMonitor.getDifferenceFromInitialOffset()
                        }
                    }]) && i(t.prototype, r), a && i(t, a), e
                }()
        },
        70494: (e, t, r) => {
            r.d(t, {
                SourceConnector: () => u
            });
            var n = r(53502),
                i = r(83040),
                o = r(1633);

            function a(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var u = function() {
                function e(t) {
                    var r = this;
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this.hooks = (0, n.wrapConnectorHooks)({
                        dragSource: function(e, t) {
                            r.clearDragSource(), r.dragSourceOptions = t || null, (0, i.isRef)(e) ? r.dragSourceRef = e : r.dragSourceNode = e, r.reconnectDragSource()
                        },
                        dragPreview: function(e, t) {
                            r.clearDragPreview(), r.dragPreviewOptions = t || null, (0, i.isRef)(e) ? r.dragPreviewRef = e : r.dragPreviewNode = e, r.reconnectDragPreview()
                        }
                    }), this.handlerId = null, this.dragSourceRef = null, this.dragSourceOptionsInternal = null, this.dragPreviewRef = null, this.dragPreviewOptionsInternal = null, this.lastConnectedHandlerId = null, this.lastConnectedDragSource = null, this.lastConnectedDragSourceOptions = null, this.lastConnectedDragPreview = null, this.lastConnectedDragPreviewOptions = null, this.backend = t
                }
                var t, r, u;
                return t = e, (r = [{
                    key: "receiveHandlerId",
                    value: function(e) {
                        this.handlerId !== e && (this.handlerId = e, this.reconnect())
                    }
                }, {
                    key: "connectTarget",
                    get: function() {
                        return this.dragSource
                    }
                }, {
                    key: "dragSourceOptions",
                    get: function() {
                        return this.dragSourceOptionsInternal
                    },
                    set: function(e) {
                        this.dragSourceOptionsInternal = e
                    }
                }, {
                    key: "dragPreviewOptions",
                    get: function() {
                        return this.dragPreviewOptionsInternal
                    },
                    set: function(e) {
                        this.dragPreviewOptionsInternal = e
                    }
                }, {
                    key: "reconnect",
                    value: function() {
                        this.reconnectDragSource(), this.reconnectDragPreview()
                    }
                }, {
                    key: "reconnectDragSource",
                    value: function() {
                        var e = this.dragSource,
                            t = this.didHandlerIdChange() || this.didConnectedDragSourceChange() || this.didDragSourceOptionsChange();
                        t && this.disconnectDragSource(), this.handlerId && (e ? t && (this.lastConnectedHandlerId = this.handlerId, this.lastConnectedDragSource = e, this.lastConnectedDragSourceOptions = this.dragSourceOptions, this.dragSourceUnsubscribe = this.backend.connectDragSource(this.handlerId, e, this.dragSourceOptions)) : this.lastConnectedDragSource = e)
                    }
                }, {
                    key: "reconnectDragPreview",
                    value: function() {
                        var e = this.dragPreview,
                            t = this.didHandlerIdChange() || this.didConnectedDragPreviewChange() || this.didDragPreviewOptionsChange();
                        t && this.disconnectDragPreview(), this.handlerId && (e ? t && (this.lastConnectedHandlerId = this.handlerId, this.lastConnectedDragPreview = e, this.lastConnectedDragPreviewOptions = this.dragPreviewOptions, this.dragPreviewUnsubscribe = this.backend.connectDragPreview(this.handlerId, e, this.dragPreviewOptions)) : this.lastConnectedDragPreview = e)
                    }
                }, {
                    key: "didHandlerIdChange",
                    value: function() {
                        return this.lastConnectedHandlerId !== this.handlerId
                    }
                }, {
                    key: "didConnectedDragSourceChange",
                    value: function() {
                        return this.lastConnectedDragSource !== this.dragSource
                    }
                }, {
                    key: "didConnectedDragPreviewChange",
                    value: function() {
                        return this.lastConnectedDragPreview !== this.dragPreview
                    }
                }, {
                    key: "didDragSourceOptionsChange",
                    value: function() {
                        return !(0, o.shallowEqual)(this.lastConnectedDragSourceOptions, this.dragSourceOptions)
                    }
                }, {
                    key: "didDragPreviewOptionsChange",
                    value: function() {
                        return !(0, o.shallowEqual)(this.lastConnectedDragPreviewOptions, this.dragPreviewOptions)
                    }
                }, {
                    key: "disconnectDragSource",
                    value: function() {
                        this.dragSourceUnsubscribe && (this.dragSourceUnsubscribe(), this.dragSourceUnsubscribe = void 0)
                    }
                }, {
                    key: "disconnectDragPreview",
                    value: function() {
                        this.dragPreviewUnsubscribe && (this.dragPreviewUnsubscribe(), this.dragPreviewUnsubscribe = void 0, this.dragPreviewNode = null, this.dragPreviewRef = null)
                    }
                }, {
                    key: "dragSource",
                    get: function() {
                        return this.dragSourceNode || this.dragSourceRef && this.dragSourceRef.current
                    }
                }, {
                    key: "dragPreview",
                    get: function() {
                        return this.dragPreviewNode || this.dragPreviewRef && this.dragPreviewRef.current
                    }
                }, {
                    key: "clearDragSource",
                    value: function() {
                        this.dragSourceNode = null, this.dragSourceRef = null
                    }
                }, {
                    key: "clearDragPreview",
                    value: function() {
                        this.dragPreviewNode = null, this.dragPreviewRef = null
                    }
                }]) && a(t.prototype, r), u && a(t, u), e
            }()
        },
        92337: (e, t, r) => {
            r.d(t, {
                TargetConnector: () => u
            });
            var n = r(1633),
                i = r(53502),
                o = r(83040);

            function a(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var u = function() {
                function e(t) {
                    var r = this;
                    ! function(e, t) {
                        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                    }(this, e), this.hooks = (0, i.wrapConnectorHooks)({
                            dropTarget: function(e, t) {
                                r.clearDropTarget(), r.dropTargetOptions = t, (0, o.isRef)(e) ? r.dropTargetRef = e : r.dropTargetNode = e, r.reconnect()
                            }
                        }),
                        this.handlerId = null, this.dropTargetRef = null, this.dropTargetOptionsInternal = null, this.lastConnectedHandlerId = null, this.lastConnectedDropTarget = null, this.lastConnectedDropTargetOptions = null, this.backend = t
                }
                var t, r, u;
                return t = e, (r = [{
                    key: "connectTarget",
                    get: function() {
                        return this.dropTarget
                    }
                }, {
                    key: "reconnect",
                    value: function() {
                        var e = this.didHandlerIdChange() || this.didDropTargetChange() || this.didOptionsChange();
                        e && this.disconnectDropTarget();
                        var t = this.dropTarget;
                        this.handlerId && (t ? e && (this.lastConnectedHandlerId = this.handlerId, this.lastConnectedDropTarget = t, this.lastConnectedDropTargetOptions = this.dropTargetOptions, this.unsubscribeDropTarget = this.backend.connectDropTarget(this.handlerId, t, this.dropTargetOptions)) : this.lastConnectedDropTarget = t)
                    }
                }, {
                    key: "receiveHandlerId",
                    value: function(e) {
                        e !== this.handlerId && (this.handlerId = e, this.reconnect())
                    }
                }, {
                    key: "dropTargetOptions",
                    get: function() {
                        return this.dropTargetOptionsInternal
                    },
                    set: function(e) {
                        this.dropTargetOptionsInternal = e
                    }
                }, {
                    key: "didHandlerIdChange",
                    value: function() {
                        return this.lastConnectedHandlerId !== this.handlerId
                    }
                }, {
                    key: "didDropTargetChange",
                    value: function() {
                        return this.lastConnectedDropTarget !== this.dropTarget
                    }
                }, {
                    key: "didOptionsChange",
                    value: function() {
                        return !(0, n.shallowEqual)(this.lastConnectedDropTargetOptions, this.dropTargetOptions)
                    }
                }, {
                    key: "disconnectDropTarget",
                    value: function() {
                        this.unsubscribeDropTarget && (this.unsubscribeDropTarget(), this.unsubscribeDropTarget = void 0)
                    }
                }, {
                    key: "dropTarget",
                    get: function() {
                        return this.dropTargetNode || this.dropTargetRef && this.dropTargetRef.current
                    }
                }, {
                    key: "clearDropTarget",
                    value: function() {
                        this.dropTargetRef = null, this.dropTargetNode = null
                    }
                }]) && a(t.prototype, r), u && a(t, u), e
            }()
        },
        83040: (e, t, r) => {
            function n(e) {
                return (n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function i(e) {
                return null !== e && "object" === n(e) && Object.prototype.hasOwnProperty.call(e, "current")
            }
            r.d(t, {
                isRef: () => i
            })
        },
        83030: (e, t, r) => {
            function n(e, t, r) {
                var n = r.getRegistry(),
                    i = n.addTarget(e, t);
                return [i, function() {
                    return n.removeTarget(i)
                }]
            }

            function i(e, t, r) {
                var n = r.getRegistry(),
                    i = n.addSource(e, t);
                return [i, function() {
                    return n.removeSource(i)
                }]
            }
            r.d(t, {
                registerTarget: () => n,
                registerSource: () => i
            })
        },
        53502: (e, t, r) => {
            r.d(t, {
                wrapConnectorHooks: () => a
            });
            var n = r(46123),
                i = r(59496);

            function o(e) {
                if ("string" != typeof e.type) {
                    var t = e.type.displayName || e.type.name || "the component";
                    throw new Error("Only native element nodes can now be passed to React DnD connectors." + "You can either wrap ".concat(t, " into a <div>, or turn it into a ") + "drag source or a drop target itself.")
                }
            }

            function a(e) {
                var t = {};
                return Object.keys(e).forEach((function(r) {
                    var n = e[r];
                    if (r.endsWith("Ref")) t[r] = e[r];
                    else {
                        var a = function(e) {
                            return function() {
                                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                                    r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                                if (!(0, i.isValidElement)(t)) {
                                    var n = t;
                                    return e(n, r), n
                                }
                                var a = t;
                                o(a);
                                var u = r ? function(t) {
                                    return e(t, r)
                                } : e;
                                return s(a, u)
                            }
                        }(n);
                        t[r] = function() {
                            return a
                        }
                    }
                })), t
            }

            function u(e, t) {
                "function" == typeof e ? e(t) : e.current = t
            }

            function s(e, t) {
                var r = e.ref;
                return (0, n.invariant)("string" != typeof r, "Cannot connect React DnD to an element with an existing string ref. Please convert it to use a callback ref instead, or wrap it into a <span> or <div>. Read more: https://reactjs.org/docs/refs-and-the-dom.html#callback-refs"), r ? (0, i.cloneElement)(e, {
                    ref: function(e) {
                        u(r, e), u(t, e)
                    }
                }) : (0, i.cloneElement)(e, {
                    ref: t
                })
            }
        }
    }
]);
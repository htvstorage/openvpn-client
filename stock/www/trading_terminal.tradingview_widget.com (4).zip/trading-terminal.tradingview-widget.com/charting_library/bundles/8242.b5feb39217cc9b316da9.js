(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [8242], {
        2742: e => {
            e.exports = {
                body: "body-sm3KMBIc"
            }
        },
        13520: e => {
            e.exports = {
                header: "header-Dtkdqc5O",
                close: "close-Dtkdqc5O"
            }
        },
        82561: e => {
            e.exports = {
                message: "message-d3vP5HJI",
                error: "error-d3vP5HJI"
            }
        },
        57999: e => {
            e.exports = {
                container: "container-S6pFxv8I",
                top: "top-S6pFxv8I"
            }
        },
        44295: e => {
            e.exports = {
                wrap: "wrap-gy86FjXS",
                list: "list-gy86FjXS",
                item: "item-gy86FjXS",
                selected: "selected-gy86FjXS",
                bluishItem: "bluishItem-gy86FjXS",
                noPadding: "noPadding-gy86FjXS"
            }
        },
        72737: e => {
            e.exports = {
                list: "list-bD5V6t9X",
                item: "item-bD5V6t9X"
            }
        },
        79370: e => {
            e.exports = {
                group: "group-7eb3l0ph"
            }
        },
        62092: e => {
            e.exports = {
                loader: "loader-MuZZSHRY",
                static: "static-MuZZSHRY",
                item: "item-MuZZSHRY",
                "tv-button-loader": "tv-button-loader-MuZZSHRY",
                medium: "medium-MuZZSHRY",
                small: "small-MuZZSHRY",
                black: "black-MuZZSHRY",
                white: "white-MuZZSHRY",
                gray: "gray-MuZZSHRY",
                primary: "primary-MuZZSHRY",
                "loader-initial": "loader-initial-MuZZSHRY",
                "loader-appear": "loader-appear-MuZZSHRY"
            }
        },
        9346: e => {
            e.exports = {
                labels: "labels-au9TlaAn",
                rewardRisk: "rewardRisk-au9TlaAn",
                rewardRiskText: "rewardRiskText-au9TlaAn",
                bracketControl: "bracketControl-au9TlaAn",
                control: "control-au9TlaAn",
                wait: "wait-au9TlaAn",
                checkboxLabel: "checkboxLabel-au9TlaAn",
                clickableTextColor: "clickableTextColor-au9TlaAn",
                checkboxWrapper: "checkboxWrapper-au9TlaAn",
                slCheckboxWrapper: "slCheckboxWrapper-au9TlaAn",
                checkboxLabelWrapper: "checkboxLabelWrapper-au9TlaAn",
                checkbox: "checkbox-au9TlaAn",
                inputGroup: "inputGroup-au9TlaAn",
                rightBlock: "rightBlock-au9TlaAn",
                label: "label-au9TlaAn",
                bracketInCurrency: "bracketInCurrency-au9TlaAn",
                bracketInPercent: "bracketInPercent-au9TlaAn",
                bracketInPips: "bracketInPips-au9TlaAn",
                bracketInPrice: "bracketInPrice-au9TlaAn"
            }
        },
        30824: e => {
            e.exports = {
                title: "title-Xoy6cb9W",
                input: "input-Xoy6cb9W",
                wait: "wait-Xoy6cb9W",
                checkboxWrapper: "checkboxWrapper-Xoy6cb9W",
                checkboxLabel: "checkboxLabel-Xoy6cb9W"
            }
        },
        80081: e => {
            e.exports = {
                customField: "customField-QNjr4p9l"
            }
        },
        95795: e => {
            e.exports = {
                pinLabel: "pinLabel-1GFzlUAB"
            }
        },
        84322: e => {
            e.exports = {
                wrapper: "wrapper-xSgWpcKi",
                row: "row-xSgWpcKi",
                disabled: "disabled-xSgWpcKi",
                header: "header-xSgWpcKi",
                cell: "cell-xSgWpcKi",
                cellValue: "cellValue-xSgWpcKi",
                cellRightAligned: "cellRightAligned-xSgWpcKi",
                cellSideBuy: "cellSideBuy-xSgWpcKi",
                cellSideSell: "cellSideSell-xSgWpcKi",
                marker: "marker-xSgWpcKi"
            }
        },
        53072: e => {
            e.exports = {
                button: "button-AUtedaek",
                popup: "popup-AUtedaek",
                wait: "wait-AUtedaek",
                hiddenText: "hiddenText-AUtedaek",
                text: "text-AUtedaek",
                wrapper: "wrapper-AUtedaek",
                buy: "buy-AUtedaek",
                disabled: "disabled-AUtedaek",
                sell: "sell-AUtedaek"
            }
        },
        78634: e => {
            e.exports = {
                clickableText: "clickableText-0Qx2pmF1",
                clickableTextColor: "clickableTextColor-0Qx2pmF1"
            }
        },
        37062: e => {
            e.exports = {
                footer: "footer-hDDUbPct"
            }
        },
        524: e => {
            e.exports = {
                separator: "separator-GzmeVcFo",
                small: "small-GzmeVcFo",
                normal: "normal-GzmeVcFo",
                large: "large-GzmeVcFo"
            }
        },
        93455: (e, t, s) => {
            "use strict";
            s.d(t, {
                ControlGroup: () => c
            });
            var o = s(59496),
                r = s(97754),
                n = s(80327),
                i = s(79370),
                a = s.n(i);

            function l(e, t, s) {
                return {
                    isTop: e < t,
                    isRight: e % t == t - 1,
                    isBottom: e >= t * (s - 1),
                    isLeft: e % t == 0
                }
            }

            function c(e) {
                const {
                    children: t,
                    rows: s,
                    cols: i,
                    disablePositionAdjustment: c,
                    className: p,
                    ...h
                } = e, d = o.Children.count(t), u = null != i ? i : d, m = null != s ? s : function(e, t) {
                    return Math.ceil(e / t)
                }(d, u), b = (0, o.useMemo)(() => {
                    const e = [];
                    for (let t = 0; t < d; t++) e.push({
                        isGrouped: !0,
                        cellState: l(t, u, m),
                        disablePositionAdjustment: c
                    });
                    return e
                }, [d, u, m, c]), k = o.Children.map(t, (e, t) => o.createElement(n.ControlGroupContext.Provider, {
                    value: b[t]
                }, e)), C = {
                    "--ui-lib-control-group-cols": u.toString(10),
                    "--ui-lib-control-group-rows": m.toString(10)
                };
                return o.createElement("span", {
                    className: r(a().group, p),
                    style: C,
                    ...h
                }, k)
            }
        },
        34404: (e, t, s) => {
            "use strict";
            s.d(t, {
                Loader: () => c
            });
            var o, r = s(59496),
                n = s(97754),
                i = s(49423),
                a = s(62092),
                l = s.n(a);
            ! function(e) {
                e[e.Initial = 0] = "Initial", e[e.Appear = 1] = "Appear", e[e.Active = 2] = "Active"
            }(o || (o = {}));
            class c extends r.PureComponent {
                constructor(e) {
                    super(e), this._stateChangeTimeout = null, this.state = {
                        state: o.Initial
                    }
                }
                render() {
                    const {
                        className: e,
                        color: t = "black",
                        size: s = "medium",
                        staticPosition: o
                    } = this.props, i = n(l().item, l()[t], l()[s]);
                    return r.createElement("span", {
                        className: n(l().loader, o && l().static, this._getStateClass(), e)
                    }, r.createElement("span", {
                        className: i
                    }), r.createElement("span", {
                        className: i
                    }), r.createElement("span", {
                        className: i
                    }))
                }
                componentDidMount() {
                    this.setState({
                        state: o.Appear
                    }), this._stateChangeTimeout = setTimeout(() => {
                        this.setState({
                            state: o.Active
                        })
                    }, 2 * i.dur)
                }
                componentWillUnmount() {
                    this._stateChangeTimeout && (clearTimeout(this._stateChangeTimeout), this._stateChangeTimeout = null)
                }
                _getStateClass() {
                    switch (this.state.state) {
                        case o.Initial:
                            return l()["loader-initial"];
                        case o.Appear:
                            return l()["loader-appear"];
                        default:
                            return ""
                    }
                }
            }
        },
        88865: (e, t, s) => {
            "use strict";
            s.d(t, {
                BracketControlGroup: () => y
            });
            var o = s(59496),
                r = s(97754),
                n = s(25177),
                i = s(61851),
                a = s(72535),
                l = s(24818),
                c = s(93455),
                p = s(2946),
                h = s(63111),
                d = s(87125);

            function u(e) {
                const {
                    inputMode: t,
                    control: s,
                    className: r,
                    error: n,
                    errorMessage: a,
                    errorHandler: l,
                    onFocus: c,
                    inputReference: p,
                    intent: h,
                    highlight: u,
                    highlightRemoveRoundBorder: m,
                    disabled: b,
                    fontSizeStyle: k
                } = e, C = (0, i.useObservable)(s.value$, s.getValue());
                return o.createElement(d.NumberInput, {
                    inputMode: t,
                    intent: h,
                    highlight: u,
                    highlightRemoveRoundBorder: m,
                    value: C,
                    onValueChange: e => {
                        var t;
                        null == c || c(), s.setValue(e), null === (t = s.onModifiedCallback) || void 0 === t || t.call(s)
                    },
                    formatter: s.formatter,
                    className: r,
                    step: s.step,
                    error: n,
                    errorMessage: a,
                    errorHandler: l,
                    onFocus: c,
                    inputReference: p,
                    disabled: b,
                    fontSizeStyle: k
                })
            }
            var m = s(95318),
                b = s(78634);

            function k(e) {
                const {
                    theme: t = b
                } = e;
                return o.createElement("span", {
                    className: r(b.clickableText, t.clickableTextColor, e.className),
                    ref: e.reference,
                    tabIndex: e.tabIndex,
                    onClick: e.onClick,
                    onKeyDown: e.onKeyDown
                }, e.text)
            }
            var C = s(1614),
                g = s(23235),
                x = s(9346);
            const v = {
                    [l.BracketType.StopLoss]: (0, n.t)("Stop Loss"),
                    [l.BracketType.TakeProfit]: (0, n.t)("Take Profit"),
                    [l.BracketType.TrailingStop]: (0, n.t)("Trailing Stop")
                },
                _ = (0, n.t)("Change stop order type");
            class S extends o.PureComponent {
                constructor(e) {
                    super(e), this._slTypeElement = null, this._slTypeDropdown = null, this._setSLTypeElement = e => {
                        this._slTypeElement = e
                    }, this._setSlTypeDropdownRef = e => {
                        this._slTypeDropdown = e
                    }, this._typeToggle = () => {
                        this.setState(e => ({
                            isSLTypeOpened: !e.isSLTypeOpened
                        })), this.props.enabled || this.props.onToggleEnabled()
                    }, this._onSLTypeSelect = e => {
                        this.props.setBracketType(this.props.stopLossTypes[e]), this.setState({
                            isSLTypeOpened: !1
                        })
                    }, this._onClickOutside = e => {
                        this._slTypeDropdown && this._slTypeDropdown.contains(e.target) || this.setState({
                            isSLTypeOpened: !1
                        })
                    }, this._focusHandler = e => () => this.props.onFocus(e), this.state = {
                        isSLTypeOpened: !1
                    }
                }
                render() {
                    const {
                        inputDisabled: e,
                        labelDisabled: t,
                        checkboxDisabled: s
                    } = this.props.controlState, n = this.props.type !== l.BracketType.TakeProfit, i = v[this.props.type], a = n && this.context.supportTrailingStop;
                    let h;
                    h = a && !t ? o.createElement(g.OutsideEvent, {
                        click: !0,
                        mouseDown: !0,
                        touchStart: !0,
                        handler: this._onClickOutside
                    }, e => o.createElement("span", {
                        className: x.checkboxLabelWrapper,
                        ref: e
                    }, o.createElement(k, {
                        className: x.checkboxLabel,
                        text: i,
                        tabIndex: -1,
                        onClick: this._typeToggle,
                        reference: this._setSLTypeElement,
                        theme: x.clickableTextColor
                    }), o.createElement(C.DropdownList, {
                        root: "document",
                        isOpened: this.state.isSLTypeOpened,
                        items: this._mapSLTypesNames(),
                        target: this._slTypeElement || void 0,
                        inheritWidthFromTarget: !1,
                        onSelect: this._onSLTypeSelect,
                        reference: this._setSlTypeDropdownRef
                    }))) : o.createElement("span", {
                        className: x.checkboxLabel
                    }, i);
                    const d = o.createElement("div", {
                            className: r(a ? x.slCheckboxWrapper : x.checkboxWrapper, "apply-common-tooltip"),
                            title: a ? _ : i
                        }, a && h, o.createElement(p.Checkbox, {
                            className: x.checkbox,
                            checked: this.props.enabled,
                            label: a ? void 0 : h,
                            labelPositionReverse: n,
                            tabIndex: -1,
                            onChange: this.props.onToggleEnabled,
                            disabled: s
                        })),
                        b = Boolean(this.props.error && this.props.error.res),
                        S = this.props.error && this.props.error.msg,
                        f = this.props.isCryptoBracket ? "showCryptoBracketsInCurrency" : "showBracketsInCurrency",
                        y = this.props.isCryptoBracket ? "showCryptoBracketsInPercent" : "showBracketsInPercent";
                    return o.createElement(m.SettingsContext.Consumer, null, t => o.createElement("div", {
                        className: r(x.bracketControl, n && x.rightBlock)
                    }, d, o.createElement(c.ControlGroup, {
                        cols: 1,
                        className: x.inputGroup
                    }, !this.props.isPipsControlHidden && o.createElement(u, { ...this._generateControlProps(0),
                        control: this.props.pips,
                        className: this._generateClassName(0),
                        onFocus: this._focusHandler(0),
                        errorHandler: this.props.errorHandler,
                        error: b && this._isSelectedControl(0),
                        errorMessage: S,
                        inputReference: this.props.handlePipsInputRef,
                        disabled: e,
                        fontSizeStyle: this.props.fontSizeStyle
                    }), o.createElement(u, { ...this._generateControlProps(1),
                        control: this.props.price,
                        className: this._generateClassName(1),
                        onFocus: this._focusHandler(1),
                        errorHandler: this.props.errorHandler,
                        error: b && this._isSelectedControl(1),
                        errorMessage: S,
                        inputReference: this.props.handlePriceInputRef,
                        disabled: e,
                        fontSizeStyle: this.props.fontSizeStyle,
                        inputMode: "text"
                    }), this.props.showRiskControls && t.value[f] && o.createElement(u, { ...this._generateControlProps(2),
                        control: this.props.riskInCurrency,
                        className: this._generateClassName(2),
                        onFocus: this._focusHandler(2),
                        errorHandler: this.props.errorHandler,
                        error: b && this._isSelectedControl(2),
                        errorMessage: S,
                        disabled: e,
                        fontSizeStyle: this.props.fontSizeStyle
                    }), this.props.showRiskControls && t.value[y] && o.createElement(u, { ...this._generateControlProps(3),
                        control: this.props.riskInPercent,
                        className: this._generateClassName(3),
                        onFocus: this._focusHandler(3),
                        errorHandler: this.props.errorHandler,
                        error: b && this._isSelectedControl(3),
                        errorMessage: S,
                        disabled: e,
                        fontSizeStyle: this.props.fontSizeStyle
                    }))))
                }
                _mapSLTypesNames() {
                    return this.props.stopLossTypes.map(e => ({
                        index: e,
                        elem: o.createElement("span", null, v[e])
                    }))
                }
                _isSelectedControl(e) {
                    return this.props.enabled && this.props.focusedControl === e
                }
                _generateClassName(e) {
                    return r(x.control, !this.props.enabled && x.wait, 0 === e && x.bracketInPips, 1 === e && x.bracketInPrice, 2 === e && x.bracketInCurrency, 3 === e && x.bracketInPercent)
                }
                _generateControlProps(e) {
                    const t = {
                        highlightRemoveRoundBorder: 0
                    };
                    return this._isSelectedControl(e) && (t.highlight = !0), Boolean(this.props.error && this.props.error.res) && this._isSelectedControl(e) && (t.intent = "danger"), t
                }
            }

            function f(e) {
                const {
                    model: t,
                    isCryptoBracket: s,
                    showRiskControls: r,
                    orderTicketFocus: n
                } = e, {
                    enabled$: c,
                    error$: p,
                    focusedControl$: h,
                    bracketType$: d,
                    stopLossTypes: u,
                    pips: m,
                    price: b,
                    riskInCurrency: k,
                    riskInPercent: C,
                    roundToStopLimitPriceStepRequired: g,
                    isValuesInitialized: x,
                    controlState: v,
                    onControlFocused: _,
                    getFocusedControl: f,
                    getEnabled: y,
                    getBracketType: T,
                    getError: w,
                    setFocusedControl: N,
                    setEnabled: P,
                    setBracketType: E,
                    setControlError: M
                } = t, I = (0, i.useObservable)(h, f()), B = (0, i.useObservable)(d, T()), R = (0, i.useObservable)(c, y()), W = (0, i.useObservable)(p, w()), D = (0, o.useRef)(null), L = (0, o.useRef)(null);
                return (0, o.useEffect)(() => {
                    if (a.mobiletouch || !R) return;
                    const e = e => {
                        null !== e && x && (e.focus(), e.setSelectionRange(e.value.length, e.value.length))
                    };
                    (B === l.BracketType.TakeProfit && 3 === n || B === l.BracketType.StopLoss && 4 === n) && e(L.current), B === l.BracketType.TrailingStop && 4 === n && e(D.current)
                }, [x]), o.createElement(S, {
                    type: B,
                    enabled: R,
                    error: W,
                    stopLossTypes: u,
                    pips: m,
                    price: b,
                    riskInCurrency: k,
                    riskInPercent: C,
                    focusedControl: I,
                    onFocus: function(e) {
                        R || P(!0);
                        I !== e && N(e);
                        _.fire()
                    },
                    onToggleEnabled: function() {
                        P(!R), _.fire()
                    },
                    errorHandler: function(e) {
                        M(e)
                    },
                    handlePipsInputRef: e => D.current = e,
                    handlePriceInputRef: e => L.current = e,
                    setBracketType: E,
                    isPipsControlHidden: g,
                    controlState: v,
                    isCryptoBracket: s,
                    showRiskControls: r,
                    fontSizeStyle: "medium"
                })
            }
            S.contextType = h.Context;
            class y extends o.PureComponent {
                constructor(e) {
                    super(e), this._updateMode = e => {
                        this.setState({
                            mode: e
                        })
                    }, this.state = {
                        mode: e.model.mode.value()
                    }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model)
                }
                componentWillUnmount() {
                    this._unsubscribeFromModel(this.props.model)
                }
                render() {
                    const e = this.props.model,
                        t = e.takeProfitModel && e.takeProfitModel.roundToStopLimitPriceStepRequired || e.stopLossModel && e.stopLossModel.roundToStopLimitPriceStepRequired,
                        s = "supportCryptoBrackets" in e && !0 === e.supportCryptoBrackets,
                        i = s ? "showCryptoBracketsInCurrency" : "showBracketsInCurrency",
                        a = s ? "showCryptoBracketsInPercent" : "showBracketsInPercent",
                        l = e.showRiskControls;
                    return o.createElement(m.SettingsContext.Consumer, null, c => o.createElement(o.Fragment, null, e.takeProfitModel && o.createElement(f, {
                        model: e.takeProfitModel,
                        orderTicketFocus: this.props.focus,
                        isCryptoBracket: s,
                        showRiskControls: l
                    }), e.takeProfitModel && e.stopLossModel && o.createElement("div", {
                        className: x.labels
                    }, o.createElement("div", {
                        className: r(x.rewardRisk, "apply-common-tooltip"),
                        title: (0, n.t)("Risk/Reward")
                    }, o.createElement("span", {
                        className: x.rewardRiskText
                    }, e.rewardRisk.value())), !t && o.createElement("span", null, "forex" === e.symbolType ? (0, n.t)("Pips") : (0, n.t)("Ticks")), o.createElement("span", null, (0, n.t)("Price")), l && c.value[i] && o.createElement("span", null, e.takeProfitModel ? e.takeProfitModel.currency : ""), l && c.value[a] && o.createElement("span", {
                        className: r("apply-common-tooltip"),
                        title: (0, n.t)("Profit & loss as a percentage of the account balance")
                    }, "%")), e.stopLossModel && o.createElement(f, {
                        model: e.stopLossModel,
                        orderTicketFocus: this.props.focus,
                        isCryptoBracket: s,
                        showRiskControls: l
                    })))
                }
                _subscribeToModel(e) {
                    e.rewardRisk.subscribe(this._callback), e.mode.subscribe(this._updateMode)
                }
                _unsubscribeFromModel(e) {
                    e.rewardRisk.unsubscribe(this._callback), e.mode.unsubscribe(this._updateMode)
                }
            }
        },
        40176: (e, t, s) => {
            "use strict";
            s.d(t, {
                CustomFields: () => m
            });
            var o = s(59496),
                r = s(97265),
                n = s(63111),
                i = (s(25177), s(94087)),
                a = s(2946),
                l = s(30824);

            function c(e) {
                const t = o.createElement("span", {
                    className: l.checkboxLabel
                }, e.checkboxTitle);
                return o.createElement("div", null, e.title && e.title.length > 0 && o.createElement("div", {
                    className: l.title
                }, e.title), o.createElement(i.InputWithError, {
                    className: e.className,
                    inputClassName: l.input,
                    type: e.inputType,
                    value: e.text,
                    placeholder: e.placeholder,
                    onChange: e.onInputChange,
                    onClick: e.onClick
                }), o.createElement("div", {
                    className: l.checkboxWrapper
                }, o.createElement(a.Checkbox, {
                    checked: e.checked,
                    label: t,
                    onChange: e.onCheckboxToggle
                })))
            }
            class p extends o.PureComponent {
                constructor(e) {
                    super(e), this._onClick = () => {
                        this.props.onControlFocused.fire()
                    }, this._onInputChange = e => {
                        this.setState({
                            text: e.currentTarget.value
                        }, () => {
                            this.props.text.setValue(this.state.text)
                        })
                    }, this._onCheckboxToggle = () => {
                        this.setState({
                            checked: !this.state.checked
                        }, () => {
                            this.props.checked.setValue(this.state.checked)
                        }), this.props.onControlFocused.fire()
                    }, this._updateText = e => {
                        this.setState({
                            text: e
                        })
                    }, this._updateCheckboxValue = e => {
                        this.setState({
                            checked: e
                        })
                    }, this._updateStatus = e => {
                        this.setState({
                            status: e
                        })
                    }, this.state = {
                        text: this.props.text.value(),
                        checked: this.props.checked.value(),
                        status: this.props.status.value()
                    }
                }
                componentDidMount() {
                    this.props.text.subscribe(this._updateText), this.props.checked.subscribe(this._updateCheckboxValue), this.props.status.subscribe(this._updateStatus)
                }
                componentDidUpdate(e) {
                    e.text !== this.props.text && (e.text.unsubscribe(this._updateText), this.props.text.subscribe(this._updateText)), e.checked !== this.props.checked && (e.checked.unsubscribe(this._updateCheckboxValue), this.props.checked.subscribe(this._updateCheckboxValue))
                }
                componentWillUnmount() {
                    this.props.text.unsubscribe(this._updateText), this.props.checked.unsubscribe(this._updateCheckboxValue),
                        this.props.status.unsubscribe(this._updateStatus)
                }
                render() {
                    return o.createElement("div", {
                        className: l.customFieldWithCheckboxContainer
                    }, o.createElement(c, {
                        className: this.state.status === n.OrderPanelStatus.Wait && l.wait,
                        inputType: this.props.inputType,
                        text: this.state.text,
                        checked: this.state.checked,
                        title: this.props.title,
                        checkboxTitle: this.props.checkboxTitle,
                        placeholder: this.props.placeholder,
                        status: this.state.status,
                        onInputChange: this._onInputChange,
                        onCheckboxToggle: this._onCheckboxToggle,
                        onClick: this._onClick
                    }))
                }
            }
            var h = s(87374),
                d = s(49688),
                u = s(80081);

            function m(e) {
                const {
                    customFieldModels: t,
                    status: s,
                    alwaysShowAttachedErrors: i,
                    onClose: a
                } = e, l = (0, r.useWatchedValueReadonly)({
                    watchedValue: s
                }), c = (0, r.useWatchedValueReadonly)({
                    watchedValue: i
                });
                return o.createElement(o.Fragment, null, t.map(e => o.createElement("div", {
                    key: e.id,
                    className: u.customField
                }, "TextWithCheckBox" === e.type && o.createElement(p, {
                    inputType: e.inputType,
                    text: e.text,
                    placeholder: e.placeholder,
                    checked: e.checked,
                    title: e.title,
                    checkboxTitle: e.checkboxTitle,
                    status: s,
                    onControlFocused: e.onControlFocused
                }), "Checkbox" === e.type && o.createElement(d.CheckboxCustomField, {
                    title: e.title,
                    help: e.help,
                    checked: e.checked,
                    disabled: e.disabled,
                    onControlFocused: e.onControlFocused
                }), "ComboBox" === e.type && o.createElement(h.CustomComboboxContainer, {
                    title: e.title,
                    items: e.items,
                    selectedItem: e.selectedItem,
                    onControlFocused: e.onControlFocused,
                    onClose: a,
                    disabled: e.items.length <= 1,
                    forceUserToSelectValue: l === n.OrderPanelStatus.Active,
                    alwaysShowAttachedErrors: c
                }))))
            }
        },
        74837: (e, t, s) => {
            "use strict";
            s.d(t, {
                useCommonDialogHandlers: () => l
            });
            var o = s(59496),
                r = s(33054),
                n = s(59410),
                i = s(6594),
                a = s(96038);

            function l(e) {
                const {
                    isOpened: t,
                    onOpen: s,
                    onClose: l
                } = e;
                (0, o.useEffect)(() => {
                    const e = () => {
                        null == l || l()
                    };
                    n.subscribe(i.CLOSE_POPUPS_AND_DIALOGS_COMMAND, e, null);
                    const o = window.matchMedia(a.DialogBreakpoints.TabletSmall),
                        c = window.matchMedia("(orientation: portrait)"),
                        p = () => {
                            t ? null == s || s(o.matches) : null == l || l()
                        };
                    return p(), (0, r.mediaQueryAddEventListener)(c, p), () => {
                        n.unsubscribe(i.CLOSE_POPUPS_AND_DIALOGS_COMMAND, e, null), (0, r.mediaQueryRemoveEventListener)(c, p)
                    }
                }, [t, l, s])
            }
        },
        74752: (e, t, s) => {
            "use strict";
            s.d(t, {
                HeaderContainer: () => T
            });
            var o = s(59496),
                r = s(25177),
                n = s(26909),
                i = s(82527),
                a = s(79266),
                l = s(17850),
                c = s(92063),
                p = s(72571),
                h = s(95318),
                d = s(63111),
                u = s(11093),
                m = s(8711),
                b = s(95795);
            const k = (0, r.t)("Show Quantity in {units} Risk"),
                C = (0, r.t)("Show Amount in {units} Risk"),
                g = (0, r.t)("Show TP/SL inputs in {units}"),
                x = (0, r.t)("Show order confirmations"),
                v = (0, r.t)("Show Order Price in Ticks"),
                _ = (0, r.t)("You are seeing delayed data in the Order Panel. You need to get the data from your broker, if you want to see it real-time."),
                S = (0, r.t)("Dock to right"),
                f = (0, r.t)("Undock"),
                y = i.enabled("order_panel_undock");
            class T extends o.PureComponent {
                constructor(e) {
                    super(e), this._callback = () => this.forceUpdate(), this._back = e.model.back.bind(e.model), this._close = e.model.close.bind(e.model), this._cancel = e.model.cancel.bind(e.model), this._pin = e.model.pin.bind(e.model)
                }
                componentDidMount() {
                    this.props.model.status.subscribe(this._callback),
                        this.props.model.hasBackButton.subscribe(this._callback), this.props.model.hasCloseButton.subscribe(this._callback), this.props.model.hasCancelButton.subscribe(this._callback), this.props.model.hasDelayedWarning.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.props.model.status.unsubscribe(this._callback), this.props.model.hasBackButton.unsubscribe(this._callback), this.props.model.hasCloseButton.unsubscribe(this._callback), this.props.model.hasCancelButton.unsubscribe(this._callback), this.props.model.hasDelayedWarning.subscribe(this._callback)
                }
                render() {
                    const e = this.props.mode === d.OrderEditorDisplayMode.Panel,
                        t = this.props.model,
                        s = this.props.showQuantityInsteadOfAmount ? k : C,
                        r = [];
                    t.status.value() !== d.OrderPanelStatus.Preview && t.isTradable && (y && t.isTradingPanelVisible && r.push(o.createElement(c.PopupMenuItem, {
                        onClick: this._pin,
                        label: o.createElement("div", {
                            className: b.pinLabel,
                            "data-name": "dock-undock-order-panel-button"
                        }, o.createElement(p.Icon, {
                            icon: e ? u : m
                        }), o.createElement("span", null, e ? f : S))
                    })), this.props.hideRelativePriceSettingsItem || r.push(o.createElement(a.PopupMenuItemToggle, {
                        label: v,
                        isChecked: !!this.context.value.showRelativePriceControl,
                        onClick: this._createClickHandler("showRelativePriceControl")
                    })), this.props.showRiskControls && (r.push(o.createElement(o.Fragment, null, o.createElement(a.PopupMenuItemToggle, {
                        label: s.format({
                            units: this.props.currency || "Money"
                        }),
                        isChecked: !!this.context.value.showCurrencyRiskInQty,
                        onClick: this._createClickHandler("showCurrencyRiskInQty")
                    }), o.createElement(a.PopupMenuItemToggle, {
                        label: s.format({
                            units: "%"
                        }),
                        isChecked: !!this.context.value.showPercentRiskInQty,
                        onClick: this._createClickHandler("showPercentRiskInQty")
                    }))), this.props.supportBrackets && r.push(o.createElement(o.Fragment, null, o.createElement(a.PopupMenuItemToggle, {
                        label: g.format({
                            units: this.props.currency || "Money"
                        }),
                        isChecked: !!this.context.value.showBracketsInCurrency,
                        onClick: this._createClickHandler("showBracketsInCurrency")
                    }), o.createElement(a.PopupMenuItemToggle, {
                        label: g.format({
                            units: "%"
                        }),
                        isChecked: !!this.context.value.showBracketsInPercent,
                        onClick: this._createClickHandler("showBracketsInPercent")
                    })))), this.props.supportOrderPreview && r.push(o.createElement(a.PopupMenuItemToggle, {
                        label: x,
                        isChecked: !!this.context.value.showOrderPreview,
                        onClick: this._createClickHandler("showOrderPreview")
                    })));
                    const i = r.map((e, t, s) => o.createElement(o.Fragment, {
                        key: t
                    }, e, s[t + 1] && o.createElement(l.PopupMenuSeparator, null)));
                    return o.createElement(n.Header, {
                        title: t.title,
                        description: t.description,
                        symbol: t.symbol,
                        settingsItems: i,
                        delayedWarningMessage: _,
                        className: this.props.className,
                        hasBackButton: t.hasBackButton.value(),
                        hasCloseButton: t.hasCloseButton.value(),
                        hasCancelButton: t.hasCancelButton.value(),
                        hasDelayedWarning: t.hasDelayedWarning.value(),
                        hasBatsQuotes: t.hasBatsQuotes,
                        back: this._back,
                        close: this._close,
                        cancel: this._cancel
                    })
                }
                _createClickHandler(e) {
                    const t = this.context.value;
                    return () => this.context.setValue({ ...t,
                        [e]: !t[e]
                    })
                }
            }
            T.contextType = h.SettingsContext
        },
        64245: (e, t, s) => {
            "use strict";
            s.d(t, {
                InfoTable: () => i
            });
            var o = s(59496),
                r = s(97754),
                n = s(84322);

            function i(e) {
                const t = e.rows.map((t, s) => o.createElement("div", {
                    key: s,
                    className: r(n.row, e.disabled && n.disabled),
                    "data-name": "info-table-row"
                }, o.createElement("div", {
                    className: r(n.cell, n.cellTitle, t.listMarker && n.marker),
                    "data-name": "info-table-cell-title"
                }, t.title), void 0 !== t.value && o.createElement("div", {
                    className: r(n.cell, n.cellValue, e.rightAlignedValues && n.cellRightAligned, void 0 !== t.type && a(t.type)),
                    "data-name": "info-table-cell-value"
                }, t.value)));
                return o.createElement("div", {
                    className: n.wrapper
                }, e.header && o.createElement("div", {
                    className: n.header
                }, e.header), t)
            }

            function a(e) {
                switch (e) {
                    case 0:
                        return n.cellSideBuy;
                    case 1:
                        return n.cellSideSell;
                    default:
                        return
                }
            }
        },
        99374: (e, t, s) => {
            "use strict";
            s.d(t, {
                PlaceAndModifyButtonContainer: () => u
            });
            var o = s(59496),
                r = s(23869),
                n = s(1317);
            var i = s(61851),
                a = s(97754),
                l = s(63111),
                c = s(34404),
                p = s(88537),
                h = s(53072);
            class d extends o.PureComponent {
                constructor(e) {
                    super(e), this._minSize = 14, this._maxSize = 24, this._text = null, this._hiddenText = null, this._wrapper = null, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this._updateFontSize(), this.context.resizerWidth && this.context.resizerWidth.subscribe(this._callback)
                }
                componentDidUpdate() {
                    this._updateFontSize()
                }
                componentWillUnmount() {
                    this.context.resizerWidth && this.context.resizerWidth.unsubscribe(this._callback)
                }
                render() {
                    const {
                        disabled: e,
                        loading: t,
                        side: s,
                        text: r,
                        status: n
                    } = this.props, i = this.context.mode, p = a(h.button, 1 === s && h.buy, -1 === s && h.sell, i === l.OrderEditorDisplayMode.Popup && h.popup, e && h.disabled, n === l.OrderPanelStatus.Wait && h.wait);
                    let d = o.createElement("span", {
                        className: h.text,
                        ref: e => this._text = e
                    }, r);
                    return t && (d = o.createElement("span", {
                        className: h.loader
                    }, o.createElement(c.Loader, null))), o.createElement("button", {
                        className: p,
                        disabled: e,
                        onClick: this.props.onClick,
                        ref: this.props.reference
                    }, o.createElement("div", {
                        className: h.wrapper,
                        ref: e => this._wrapper = e
                    }, o.createElement("span", {
                        className: h.hiddenText,
                        ref: e => this._hiddenText = e
                    }, r), d))
                }
                _updateFontSize() {
                    if (this._text)
                        if (this.props.status === l.OrderPanelStatus.Wait) this._text.style.fontSize = "16px";
                        else {
                            (0, p.ensureNotNull)(this._hiddenText).style.fontSize = this._maxSize + "px";
                            const e = Math.max(258, (0, p.ensureNotNull)(this._wrapper).clientWidth),
                                t = e / ((0, p.ensureNotNull)(this._hiddenText).getBoundingClientRect().width || 1),
                                s = this._maxSize,
                                o = Math.floor(s * t),
                                r = Math.max(this._minSize, Math.min(o, this._maxSize));
                            this._text.style.fontSize = (0, p.ensureNotNull)(this._hiddenText).style.fontSize = r + "px", r > this._minSize && (0, p.ensureNotNull)(this._hiddenText).getBoundingClientRect().width > e && (this._text.style.fontSize = r - 1 + "px")
                        }
                }
            }

            function u(e) {
                const {
                    model: t,
                    reference: s,
                    buttonModel: a
                } = e, l = t.hasOwnProperty("sideModel") && "sideModel" in t ? t.sideModel.value$ : r.EMPTY, {
                    value$: c,
                    getValue: p
                } = a, [h] = (e => {
                    const [t, s] = (0, o.useState)(e.value());
                    return (0, o.useLayoutEffect)(() => {
                        const t = e => s(e);
                        return e.subscribe(t), () => e.unsubscribe(t)
                    }, [e]), [t, t => e.setValue(t)]
                })(t.disabled), [u] = (0, n.useWatchedValue)(t.loading), m = (0, i.useObservable)(c, p()), b = (0, i.useObservable)(l, t.side());
                return o.createElement(d, {
                    disabled: h,
                    loading: u,
                    side: b,
                    text: m,
                    onClick: t.doneButtonClick.bind(t),
                    reference: s,
                    status: t.status.value()
                })
            }
            d.contextType = l.Context
        },
        30894: (e, t, s) => {
            "use strict";
            s.d(t, {
                Body: () => p,
                Header: () => l
            });
            var o = s(59496),
                r = s(97754),
                n = s(13520),
                i = s(90841),
                a = s(72571);

            function l(e) {
                const t = e.hideIcon ? null : o.createElement(a.Icon, {
                    className: n.close,
                    icon: i,
                    onClick: e.onClose
                });
                return o.createElement("div", {
                    className: r(n.header, e.className),
                    "data-dragg-area": !0,
                    ref: e.reference
                }, e.children, t)
            }
            s(37062);
            var c = s(2742);

            function p(e) {
                return o.createElement("div", {
                    className: r(c.body, e.className),
                    ref: e.reference
                }, e.children)
            }
            s(61174), s(82561)
        },
        1614: (e, t, s) => {
            "use strict";
            s.d(t, {
                DropdownList: () => y
            });
            var o = s(59496),
                r = s(44295),
                n = s(97754),
                i = s(87995),
                a = s(7270),
                l = s(72737);
            class c extends o.PureComponent {
                constructor(e) {
                    super(e)
                }
                render() {
                    return o.createElement("div", {
                        className: this.props.className,
                        onClick: this.props.onClick,
                        ref: this.props.reference
                    }, this.props.children)
                }
            }
            class p extends o.PureComponent {
                constructor(e) {
                    super(e)
                }
                render() {
                    const {
                        theme: e = l
                    } = this.props, t = n(e.list, {
                        [this.props.className]: Boolean(this.props.className)
                    }), {
                        fontSize: s = 13
                    } = this.props, r = {
                        bottom: this.props.bottom,
                        fontSize: s,
                        left: this.props.left,
                        height: this.props.height || "auto",
                        right: this.props.right,
                        top: this.props.top,
                        width: this.props.width,
                        zIndex: this.props.zIndex
                    };
                    return o.createElement(a, {
                        whitelist: ["height", "width"],
                        shouldMeasure: !!this.props.onMeasure,
                        onMeasure: this.props.onMeasure
                    }, o.createElement("div", {
                        className: t,
                        style: r,
                        ref: this.props.reference
                    }, this._wrapItems(this.props.items, this.props.selected)))
                }
                componentDidMount() {
                    if (this._el = i.findDOMNode(this), void 0 !== this.props.selected && this.props.shouldScrollIfNotVisible) {
                        const e = this._items[this.props.selected];
                        e && this._scrollIfNotVisible(e)
                    }
                }
                componentDidUpdate() {
                    if (void 0 !== this.props.selected && this.props.shouldScrollIfNotVisible) {
                        const e = this._items[this.props.selected];
                        e && this._scrollIfNotVisible(e)
                    }
                }
                _wrapItems(e = [], t) {
                    this._items = [];
                    const {
                        itemWrap: s = c,
                        theme: r = l
                    } = this.props, i = s;
                    return e.map((e, s) => {
                        const a = n(r.item, {
                            [this.props.itemsClassName]: Boolean(this.props.itemsClassName),
                            [this.props.selectedClassName]: t === s
                        });
                        return o.createElement(i, {
                            reference: t => {
                                t && this._items.push({
                                    elem: t,
                                    index: s,
                                    value: e
                                })
                            },
                            key: s,
                            onClick: () => this._onSelect(s),
                            className: a
                        }, e.elem)
                    })
                }
                _onSelect(e) {
                    this.props.onSelect && this.props.onSelect(e, this._items[e].value)
                }
                _scrollIfNotVisible(e) {
                    const t = this._el.scrollTop,
                        s = this._el.scrollTop + this._el.clientHeight,
                        o = e.elem.offsetTop,
                        r = o + e.elem.clientHeight;
                    o <= t ? e.elem.scrollIntoView(!0) : r >= s && e.elem.scrollIntoView(!1)
                }
            }
            p.defaultProps = {
                shouldScrollIfNotVisible: !0
            };
            var h = s(41037),
                d = s(74485);
            class u extends o.PureComponent {
                render() {
                    const e = {
                        position: "absolute",
                        top: this.props.top,
                        width: this.props.width,
                        height: this.props.height,
                        bottom: this.props.bottom,
                        right: this.props.right,
                        left: this.props.left,
                        zIndex: this.props.zIndex
                    };
                    return o.createElement(a, {
                        onMeasure: this.props.onResize
                    }, o.createElement("div", {
                        className: this.props.className,
                        style: e,
                        ref: this.props.reference
                    }, this.props.children))
                }
            }
            u.displayName = "Dropdown Container";
            const m = (0, d.makeOverlapable)((0, h.makeAttachable)(u));
            var b = s(57999),
                k = s(88537);
            class C extends o.PureComponent {
                constructor() {
                    super(...arguments), this._container = null, this._setContainerRef = e => {
                        "function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e), this._container = e
                    }
                }
                componentDidMount() {
                    this.props.onDropdownWheelNoPassive && this._addPassiveListenerOnWheel(this.props.onDropdownWheelNoPassive)
                }
                componentDidUpdate(e) {
                    this.props.onDropdownWheelNoPassive !== e.onDropdownWheelNoPassive && this._updatePassiveListenerOnWheel(e.onDropdownWheelNoPassive)
                }
                componentWillUnmount() {
                    this.props.onDropdownWheelNoPassive && this._removePassiveListenerOnWheel(this.props.onDropdownWheelNoPassive)
                }
                render() {
                    const {
                        shadow: e = "bottom",
                        children: t,
                        className: s
                    } = this.props, r = n(b.container, b[e], s), i = {
                        maxHeight: this.props.maxHeight
                    };
                    return o.createElement("div", {
                        ref: this._setContainerRef,
                        style: i,
                        className: r,
                        onTouchStart: this.props.onDropdownTouchStart,
                        onTouchMove: this.props.onDropdownTouchMove,
                        onTouchEnd: this.props.onDropdownTouchEnd,
                        onWheel: this.props.onDropdownWheel
                    }, t)
                }
                _updatePassiveListenerOnWheel(e) {
                    e && this._removePassiveListenerOnWheel(e), this.props.onDropdownWheelNoPassive && this._addPassiveListenerOnWheel(this.props.onDropdownWheelNoPassive)
                }
                _addPassiveListenerOnWheel(e) {
                    (0, k.ensureNotNull)(this._container).addEventListener("wheel", e, {
                        passive: !1
                    })
                }
                _removePassiveListenerOnWheel(e) {
                    (0, k.ensureNotNull)(this._container).removeEventListener("wheel", e)
                }
            }
            var g = s(79184);
            const x = (v = p, (_ = class extends o.PureComponent {
                constructor(e) {
                    super(e), this._items = this.props.items
                }
                componentDidUpdate(e) {
                    if (e.command !== this.props.command && this.props.command) switch (this.props.command.name) {
                        case "next":
                            this._next();
                            break;
                        case "prev":
                            this._prev()
                    }
                    e.items !== this.props.items && (this._items = this.props.items)
                }
                render() {
                    return o.createElement(v, { ...this.props
                    }, this.props.children)
                }
                _next() {
                    const {
                        selected: e = -1
                    } = this.props, t = e + 1;
                    this._items.length - 1 >= t ? this._navigateTo(t) : this._navigateTo(0)
                }
                _prev() {
                    const {
                        selected: e = -1
                    } = this.props, t = e - 1, s = this._items.length - 1;
                    0 <= t ? this._navigateTo(t) : this._navigateTo(s)
                }
                _navigateTo(e) {
                    this.props.onNavigate && this.props.onNavigate(e, this._items[e])
                }
            }).displayName = "Navigateable Component", _);
            var v, _;
            const S = (0, g.makeAnchorable)(m),
                f = {
                    top: "top",
                    bottom: "bottom",
                    topRight: "top"
                };
            class y extends o.PureComponent {
                render() {
                    const {
                        anchor: e = "bottom",
                        fontSize: t = 14,
                        root: s = "parent"
                    } = this.props, i = n(r.list, r[e]), {
                        dropdownClassName: a,
                        height: l,
                        ...c
                    } = this.props;
                    return o.createElement(S, { ...c,
                        className: a,
                        root: s
                    }, o.createElement(C, {
                        className: this.props.dropdownContainerClassName,
                        shadow: f[e],
                        maxHeight: this.props.maxHeight,
                        onDropdownTouchStart: this.props.onDropdownTouchStart ? this.props.onDropdownTouchStart : void 0,
                        onDropdownTouchMove: this.props.onDropdownTouchMove ? this.props.onDropdownTouchMove : void 0,
                        onDropdownTouchEnd: this.props.onDropdownTouchEnd ? this.props.onDropdownTouchEnd : void 0,
                        onDropdownWheelNoPassive: this.props.onDropdownWheelNoPassive ? this.props.onDropdownWheelNoPassive : void 0
                    }, o.createElement(x, { ...c,
                        width: this.props.width,
                        height: l,
                        className: this.props.className || i,
                        itemsClassName: this.props.itemsClassName || r.item,
                        selectedClassName: this.props.selectedClassName || r.selected,
                        fontSize: t,
                        reference: this.props.reference
                    })))
                }
            }
        },
        17850: (e, t, s) => {
            "use strict";
            s.d(t, {
                PopupMenuSeparator: () => a
            });
            var o = s(59496),
                r = s(97754),
                n = s.n(r),
                i = s(524);

            function a(e) {
                const {
                    size: t = "normal",
                    className: s
                } = e;
                return o.createElement("div", {
                    className: n()(i.separator, "small" === t && i.small, "normal" === t && i.normal, "large" === t && i.large, s)
                })
            }
        },
        11093: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9 6h11v.5c0 1.115-.442 2.004-1.273 2.593-.7.498-1.637.755-2.727.814v2.267c2.867.677 5 3.252 5 6.326v.5h-6v4h-1v-4H8v-.5a6.502 6.502 0 0 1 5-6.326V9.907c-1.09-.059-2.027-.316-2.727-.814C9.443 8.503 9 7.615 9 6.5V6zm1.043 1c.102.56.383.976.809 1.278.57.405 1.452.642 2.648.642h.5V13.006l-.417.07A5.503 5.503 0 0 0 9.023 18h10.955a5.503 5.503 0 0 0-4.56-4.924l-.418-.07V8.92h.5c1.196 0 2.078-.237 2.648-.642A1.93 1.93 0 0 0 18.958 7h-8.915z"/></svg>'
        },
        8711: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M16.621 4.6l.354.354 7.07 7.071.354.354-.353.353c-.789.789-1.73 1.104-2.734.934-.847-.144-1.691-.624-2.504-1.353l-1.603 1.603a6.502 6.502 0 0 1-.937 8.008l-.354.354-.354-.354-3.889-3.889-2.828 2.829-.707-.707 2.828-2.829-3.889-3.889-.353-.353.353-.354a6.502 6.502 0 0 1 8.009-.937l1.603-1.604c-.73-.812-1.21-1.656-1.353-2.503-.17-1.005.145-1.945.934-2.734l.353-.354zm.03 1.445a1.93 1.93 0 0 0-.331 1.476c.117.689.573 1.48 1.418 2.326l.354.354-.354.353-2.236 2.237-.3.299-.344-.246a5.503 5.503 0 0 0-6.706.258l3.873 3.873 3.873 3.873a5.503 5.503 0 0 0 .257-6.706l-.245-.345.299-.3 2.236-2.236.354-.353.354.353c.845.846 1.637 1.302 2.326 1.419a1.93 1.93 0 0 0 1.476-.332l-6.303-6.303z"/></svg>'
        },
        90841: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="currentColor" d="M5.18 6.6L1.3 2.7.6 2 2 .59l.7.7 3.9 3.9 3.89-3.9.7-.7L12.61 2l-.71.7L8 6.6l3.89 3.89.7.7-1.4 1.42-.71-.71L6.58 8 2.72 11.9l-.71.7-1.41-1.4.7-.71 3.9-3.9z"/></svg>'
        }
    }
]);
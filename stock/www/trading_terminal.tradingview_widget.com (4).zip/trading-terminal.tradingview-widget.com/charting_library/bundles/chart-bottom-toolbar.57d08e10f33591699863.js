(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [7260], {
        62092: e => {
            e.exports = {
                loader: "loader-MuZZSHRY",
                static: "static-MuZZSHRY",
                item: "item-MuZZSHRY",
                "tv-button-loader": "tv-button-loader-MuZZSHRY",
                medium: "medium-MuZZSHRY",
                small: "small-MuZZSHRY",
                black: "black-MuZZSHRY",
                white: "white-MuZZSHRY",
                gray: "gray-MuZZSHRY",
                primary: "primary-MuZZSHRY",
                "loader-initial": "loader-initial-MuZZSHRY",
                "loader-appear": "loader-appear-MuZZSHRY"
            }
        },
        32925: e => {
            e.exports = {
                button: "button-WhrIKIq9",
                hover: "hover-WhrIKIq9",
                inner: "inner-WhrIKIq9"
            }
        },
        55576: e => {
            e.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        71123: e => {
            e.exports = {
                button: "button-khcLBZEz",
                hover: "hover-khcLBZEz",
                arrow: "arrow-khcLBZEz",
                arrowWrap: "arrowWrap-khcLBZEz",
                newStyles: "newStyles-khcLBZEz",
                isOpened: "isOpened-khcLBZEz"
            }
        },
        43527: e => {
            e.exports = {
                toolbar: "toolbar-sFd8og5Y",
                dateRangeWrapper: "dateRangeWrapper-sFd8og5Y",
                seriesControlWrapper: "seriesControlWrapper-sFd8og5Y",
                dateRangeExpanded: "dateRangeExpanded-sFd8og5Y",
                dateRangeCollapsed: "dateRangeCollapsed-sFd8og5Y",
                item: "item-sFd8og5Y",
                first: "first-sFd8og5Y",
                last: "last-sFd8og5Y",
                inline: "inline-sFd8og5Y",
                timezone: "timezone-sFd8og5Y",
                session: "session-sFd8og5Y",
                icon: "icon-sFd8og5Y",
                hidden: "hidden-sFd8og5Y",
                collapsed: "collapsed-sFd8og5Y"
            }
        },
        47393: e => {
            e.exports = {
                button: "button-YwWuPcCo",
                separator: "separator-YwWuPcCo"
            }
        },
        25033: e => {
            e.exports = {
                button: "button-wNyKS1Qc",
                hover: "hover-wNyKS1Qc",
                icon: "icon-wNyKS1Qc"
            }
        },
        71922: e => {
            e.exports = {
                separator: "separator-ArqK8T1e"
            }
        },
        17963: e => {
            e.exports = {
                button: "button-U8Px2hz6"
            }
        },
        22880: e => {
            e.exports = {
                item: "item-G1QqQDLk",
                hover: "hover-G1QqQDLk",
                isActive: "isActive-G1QqQDLk",
                isFirst: "isFirst-G1QqQDLk",
                isLast: "isLast-G1QqQDLk"
            }
        },
        72767: e => {
            e.exports = {
                slider: "slider-eR7xmZ00",
                inner: "inner-eR7xmZ00"
            }
        },
        38952: e => {
            e.exports = {
                sliderRow: "sliderRow-DtHrLXA3"
            }
        },
        19119: e => {
            e.exports = {
                item: "item-tPYeYcJa",
                interactive: "interactive-tPYeYcJa",
                hovered: "hovered-tPYeYcJa",
                disabled: "disabled-tPYeYcJa",
                active: "active-tPYeYcJa",
                shortcut: "shortcut-tPYeYcJa",
                normal: "normal-tPYeYcJa",
                big: "big-tPYeYcJa",
                iconCell: "iconCell-tPYeYcJa",
                icon: "icon-tPYeYcJa",
                checkmark: "checkmark-tPYeYcJa",
                content: "content-tPYeYcJa",
                label: "label-tPYeYcJa",
                checked: "checked-tPYeYcJa",
                toolbox: "toolbox-tPYeYcJa",
                showToolboxOnHover: "showToolboxOnHover-tPYeYcJa",
                arrowIcon: "arrowIcon-tPYeYcJa",
                subMenu: "subMenu-tPYeYcJa",
                invisibleHotkey: "invisibleHotkey-tPYeYcJa"
            }
        },
        61999: e => {
            e.exports = {
                item: "item-zoYF2FPa",
                emptyIcons: "emptyIcons-zoYF2FPa",
                loading: "loading-zoYF2FPa",
                disabled: "disabled-zoYF2FPa",
                interactive: "interactive-zoYF2FPa",
                hovered: "hovered-zoYF2FPa",
                normal: "normal-zoYF2FPa",
                big: "big-zoYF2FPa",
                icon: "icon-zoYF2FPa",
                label: "label-zoYF2FPa",
                title: "title-zoYF2FPa",
                nested: "nested-zoYF2FPa",
                shortcut: "shortcut-zoYF2FPa",
                remove: "remove-zoYF2FPa"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        91626: e => {
            e.exports = {
                separator: "separator-jtAq6E4V"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        524: e => {
            e.exports = {
                separator: "separator-GzmeVcFo",
                small: "small-GzmeVcFo",
                normal: "normal-GzmeVcFo",
                large: "large-GzmeVcFo"
            }
        },
        37740: e => {
            e.exports = {
                tabs: "tabs-rKFlMYkc",
                tab: "tab-rKFlMYkc",
                noBorder: "noBorder-rKFlMYkc",
                disabled: "disabled-rKFlMYkc",
                active: "active-rKFlMYkc",
                defaultCursor: "defaultCursor-rKFlMYkc",
                slider: "slider-rKFlMYkc",
                content: "content-rKFlMYkc"
            }
        },
        40367: e => {
            e.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => i
            });
            var s = n(59496);
            const i = s.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...i
                } = e;
                return s.createElement("span", { ...i,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        34404: (e, t, n) => {
            "use strict";
            n.d(t, {
                Loader: () => c
            });
            var s, i = n(59496),
                o = n(97754),
                a = n(49423),
                r = n(62092),
                l = n.n(r);
            ! function(e) {
                e[e.Initial = 0] = "Initial", e[e.Appear = 1] = "Appear", e[e.Active = 2] = "Active"
            }(s || (s = {}));
            class c extends i.PureComponent {
                constructor(e) {
                    super(e), this._stateChangeTimeout = null, this.state = {
                        state: s.Initial
                    }
                }
                render() {
                    const {
                        className: e,
                        color: t = "black",
                        size: n = "medium",
                        staticPosition: s
                    } = this.props, a = o(l().item, l()[t], l()[n]);
                    return i.createElement("span", {
                        className: o(l().loader, s && l().static, this._getStateClass(), e)
                    }, i.createElement("span", {
                        className: a
                    }), i.createElement("span", {
                        className: a
                    }), i.createElement("span", {
                        className: a
                    }))
                }
                componentDidMount() {
                    this.setState({
                        state: s.Appear
                    }), this._stateChangeTimeout = setTimeout(() => {
                        this.setState({
                            state: s.Active
                        })
                    }, 2 * a.dur)
                }
                componentWillUnmount() {
                    this._stateChangeTimeout && (clearTimeout(this._stateChangeTimeout), this._stateChangeTimeout = null)
                }
                _getStateClass() {
                    switch (this.state.state) {
                        case s.Initial:
                            return l()["loader-initial"];
                        case s.Appear:
                            return l()["loader-appear"];
                        default:
                            return ""
                    }
                }
            }
        },
        417: (e, t, n) => {
            "use strict";

            function s(e) {
                return o(e, a)
            }

            function i(e) {
                return o(e, r)
            }

            function o(e, t) {
                const n = Object.entries(e).filter(t),
                    s = {};
                for (const [e, t] of n) s[e] = t;
                return s
            }

            function a(e) {
                const [t, n] = e;
                return 0 === t.indexOf("data-") && "string" == typeof n
            }

            function r(e) {
                return 0 === e[0].indexOf("aria-")
            }
            n.d(t, {
                filterDataProps: () => s,
                filterAriaProps: () => i,
                filterProps: () => o,
                isDataAttribute: () => a,
                isAriaAttribute: () => r
            })
        },
        85673: (e, t, n) => {
            "use strict";
            n.d(t, {
                VerticalAttachEdge: () => s,
                HorizontalAttachEdge: () => i,
                VerticalDropDirection: () => o,
                HorizontalDropDirection: () => a,
                getPopupPositioner: () => c
            });
            var s, i, o, a, r = n(88537);
            ! function(e) {
                e[e.Top = 0] = "Top", e[e.Bottom = 1] = "Bottom"
            }(s || (s = {})),
            function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(i || (i = {})),
            function(e) {
                e[e.FromTopToBottom = 0] = "FromTopToBottom", e[e.FromBottomToTop = 1] = "FromBottomToTop"
            }(o || (o = {})),
            function(e) {
                e[e.FromLeftToRight = 0] = "FromLeftToRight", e[e.FromRightToLeft = 1] = "FromRightToLeft"
            }(a || (a = {}));
            const l = {
                verticalAttachEdge: s.Bottom,
                horizontalAttachEdge: i.Left,
                verticalDropDirection: o.FromTopToBottom,
                horizontalDropDirection: a.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function c(e, t) {
                return (n, c) => {
                    const h = (0, r.ensureNotNull)(e).getBoundingClientRect(),
                        {
                            verticalAttachEdge: d = l.verticalAttachEdge,
                            verticalDropDirection: u = l.verticalDropDirection,
                            horizontalAttachEdge: p = l.horizontalAttachEdge,
                            horizontalDropDirection: m = l.horizontalDropDirection,
                            horizontalMargin: g = l.horizontalMargin,
                            verticalMargin: v = l.verticalMargin,
                            matchButtonAndListboxWidths: _ = l.matchButtonAndListboxWidths
                        } = t,
                        b = d === s.Top ? -1 * v : v,
                        f = p === i.Right ? h.right : h.left,
                        C = d === s.Top ? h.top : h.bottom,
                        x = {
                            x: f - (m === a.FromRightToLeft ? n : 0) + g,
                            y: C - (u === o.FromBottomToTop ? c : 0) + b
                        };
                    return _ && (x.overrideWidth = h.width), x
                }
            }
        },
        75803: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => l,
                ToolWidgetButton: () => c
            });
            var s = n(59496),
                i = n(97754),
                o = n(72571),
                a = n(4257),
                r = n(55576);
            const l = r,
                c = s.forwardRef((e, t) => {
                    const {
                        icon: n,
                        isActive: l,
                        isOpened: c,
                        isDisabled: h,
                        isGrouped: d,
                        isHovered: u,
                        onClick: p,
                        text: m,
                        textBeforeIcon: g,
                        title: v,
                        theme: _ = r,
                        className: b,
                        forceInteractive: f,
                        "data-name": C,
                        ...x
                    } = e, y = i(b, _.button, v && "apply-common-tooltip", {
                        [_.isActive]: l,
                        [_.isOpened]: c,
                        [_.isInteractive]: (f || Boolean(p)) && !h,
                        [_.isDisabled]: h,
                        [_.isGrouped]: d,
                        [_.hover]: u,
                        [_.newStyles]: a.hasNewHeaderToolbarStyles
                    }), S = n && ("string" == typeof n ? s.createElement(o.Icon, {
                        className: _.icon,
                        icon: n
                    }) : s.cloneElement(n, {
                        className: i(_.icon, n.props.className)
                    }));
                    return s.createElement("div", { ...x,
                        ref: t,
                        "data-role": "button",
                        className: y,
                        onClick: h ? void 0 : p,
                        title: v,
                        "data-name": C
                    }, g && m && s.createElement("div", {
                        className: i("js-button-text", _.text)
                    }, m), S, !g && m && s.createElement("div", {
                        className: i("js-button-text", _.text)
                    }, m))
                })
        },
        34816: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_MENU_THEME: () => m,
                ToolWidgetMenu: () => g
            });
            var s = n(59496),
                i = n(97754),
                o = n(44377),
                a = n(15783),
                r = n(417),
                l = n(63694),
                c = n(59339),
                h = n(85673),
                d = n(30052),
                u = n(4257),
                p = n(71123);
            const m = p;
            class g extends s.PureComponent {
                constructor(e) {
                    super(e), this._wrapperRef = null, this._controller = s.createRef(), this._handleWrapperRef = e => {
                        this._wrapperRef = e, this.props.reference && this.props.reference(e)
                    }, this._handleClick = e => {
                        e.target instanceof Node && e.currentTarget.contains(e.target) && (this._handleToggleDropdown(), this.props.onClick && this.props.onClick(e, !this.state.isOpened))
                    }, this._handleToggleDropdown = e => {
                        const {
                            onClose: t,
                            onOpen: n
                        } = this.props, {
                            isOpened: s
                        } = this.state, i = "boolean" == typeof e ? e : !s;
                        this.setState({
                            isOpened: i
                        }), i && n && n(), !i && t && t()
                    }, this._handleClose = () => {
                        this.close()
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        arrow: t,
                        content: n,
                        isDisabled: o,
                        isDrawer: l,
                        isShowTooltip: c,
                        title: h,
                        className: p,
                        hotKey: m,
                        theme: g,
                        drawerBreakpoint: v
                    } = this.props, {
                        isOpened: _
                    } = this.state, b = i(p, g.button, {
                        "apply-common-tooltip": c || !o,
                        [g.isDisabled]: o,
                        [g.isOpened]: _,
                        [g.newStyles]: u.hasNewHeaderToolbarStyles
                    });
                    return s.createElement("div", {
                        id: e,
                        className: b,
                        onClick: o ? void 0 : this._handleClick,
                        title: h,
                        "data-tooltip-hotkey": m,
                        ref: this._handleWrapperRef,
                        "data-role": "button",
                        ...(0, r.filterDataProps)(this.props)
                    }, n, t && s.createElement("div", {
                        className: g.arrow
                    }, s.createElement("div", {
                        className: g.arrowWrap
                    }, s.createElement(a.ToolWidgetCaret, {
                        dropped: _
                    }))), this.state.isOpened && (v ? s.createElement(d.MatchMedia, {
                        rule: v
                    }, e => this._renderContent(e)) : this._renderContent(l)))
                }
                close() {
                    this._handleToggleDropdown(!1)
                }
                update() {
                    null !== this._controller.current && this._controller.current.update()
                }
                _renderContent(e) {
                    const {
                        menuDataName: t,
                        minWidth: n,
                        menuClassName: i,
                        maxHeight: a,
                        drawerPosition: r = "Bottom",
                        children: d
                    } = this.props, {
                        isOpened: u
                    } = this.state, p = {
                        horizontalMargin: this.props.horizontalMargin || 0,
                        verticalMargin: this.props.verticalMargin || 2,
                        verticalAttachEdge: this.props.verticalAttachEdge,
                        horizontalAttachEdge: this.props.horizontalAttachEdge,
                        verticalDropDirection: this.props.verticalDropDirection,
                        horizontalDropDirection: this.props.horizontalDropDirection,
                        matchButtonAndListboxWidths: this.props.matchButtonAndListboxWidths
                    }, m = Boolean(u && e && r), g = function(e) {
                        return "function" == typeof e
                    }(d) ? d({
                        isDrawer: m
                    }) : d;
                    return m ? s.createElement(l.DrawerManager, null, s.createElement(c.Drawer, {
                        onClose: this._handleClose,
                        position: r,
                        "data-name": t
                    }, g)) : s.createElement(o.PopupMenu, {
                        controller: this._controller,
                        closeOnClickOutside: this.props.closeOnClickOutside,
                        doNotCloseOn: this,
                        isOpened: u,
                        minWidth: n,
                        onClose: this._handleClose,
                        position: (0, h.getPopupPositioner)(this._wrapperRef, p),
                        className: i,
                        maxHeight: a,
                        "data-name": t
                    }, g)
                }
            }
            g.defaultProps = {
                arrow: !0,
                closeOnClickOutside: !0,
                theme: p
            }
        },
        82294: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                BottomToolbarRenderer: () => tt
            });
            var s = n(59496),
                i = n(87995),
                o = n(25177),
                a = n(19036),
                r = n(97754),
                l = n(7270),
                c = n(82527),
                h = n(34816),
                d = n(85673),
                u = n(70981),
                p = n(30052),
                m = n(92063),
                g = n(17850),
                v = n(88537),
                _ = n(32133),
                b = n(23404),
                f = n(97496),
                C = n.n(f),
                x = n(42148);
            class y {
                constructor(e) {
                    this._state = {
                        ranges: []
                    }, this._change = new(C()), this._rangeChangedListenerBound = this._onRangeChanged.bind(this);
                    const {
                        chartWidget: t
                    } = this._context = e;
                    t.withModel(null, () => {
                        const e = t.model(),
                            n = e.mainSeries();
                        n.onStatusChanged().subscribe(this, this._updateAvailableRanges), c.enabled("update_timeframes_set_on_symbol_resolve") && n.dataEvents().symbolResolved().subscribe(this, this._updateAvailableRanges), n.priceScale().properties().childs().lockScale.subscribe(this, this._updateAvailableRanges);
                        const s = e.model().appliedTimeFrame();
                        s.subscribe(this._rangeChangedListenerBound), this._rangeChangedListenerBound(s.value()), this._updateAvailableRanges()
                    })
                }
                state() {
                    return this._state
                }
                onChange() {
                    return this._change
                }
                selectRange(e) {
                    this._setState({
                        activeRange: e.value.value
                    });
                    const {
                        chartWidgetCollection: t
                    } = this._context, n = {
                        val: e.value,
                        res: e.targetResolution
                    };
                    t.setTimeFrame(n)
                }
                destroy() {
                    const {
                        chartWidget: e
                    } = this._context;
                    e.withModel(null, () => {
                        const t = e.model(),
                            n = t.mainSeries();
                        n.onStatusChanged().unsubscribe(this, this._updateAvailableRanges), c.enabled("update_timeframes_set_on_symbol_resolve") && n.dataEvents().symbolResolved().unsubscribe(this, this._updateAvailableRanges), n.priceScale().properties().childs().lockScale.unsubscribe(this, this._updateAvailableRanges), t.model().appliedTimeFrame().unsubscribe(this._rangeChangedListenerBound)
                    }), this._change.destroy()
                }
                _setState(e) {
                    this._state = Object.assign({}, this._state, e), this._change.fire(this._state)
                }
                _onRangeChanged(e) {
                    let t;
                    null !== e && "period-back" === e.val.type && (t = e.val.value), this._setState({
                        activeRange: t
                    })
                }
                _updateAvailableRanges() {
                    const {
                        availableTimeFrames: e,
                        chartWidget: t
                    } = this._context;
                    if (!t.hasModel()) return;
                    const n = t.model().mainSeries(),
                        s = n.status();
                    if (s === x.STATUS_LOADING || s === x.STATUS_RESOLVING) return;
                    const i = e(n.symbolInfo(), n.status());
                    0 !== i.length && this._setState({
                        ranges: i
                    })
                }
            }
            const S = (0, b.registryContextType)();

            function E(e) {
                var t;
                return (t = class extends s.PureComponent {
                    constructor(e, t) {
                        super(e, t), this._handleUpdate = e => {
                            this.setState(e)
                        }, this._handleSelectRange = e => {
                            var t, n;
                            (0, _.trackEvent)("GUI", "Chart Bottom Toolbar", "range " + e.value), null === (n = (t = this.props).onSelectRange) || void 0 === n || n.call(t, e), this._binding.selectRange(e)
                        }, (0, b.validateRegistry)(t, {
                            availableTimeFrames: a.any.isRequired,
                            chartWidgetCollection: a.any.isRequired,
                            chartWidget: a.any.isRequired
                        }), w.has(t.chartWidget) || w.set(t.chartWidget, new y(t));
                        const n = this._binding = (0, v.ensureDefined)(w.get(t.chartWidget));
                        this.state = n.state()
                    }
                    componentDidMount() {
                        this._binding.onChange().subscribe(this, this._handleUpdate)
                    }
                    componentWillUnmount() {
                        this._binding.onChange().unsubscribe(this, this._handleUpdate)
                    }
                    render() {
                        return s.createElement(e, {
                            goToDateButton: this.props.goToDateButton,
                            className: this.props.className,
                            ranges: this.state.ranges,
                            activeRange: this.state.activeRange,
                            onSelectRange: this._handleSelectRange
                        })
                    }
                }).contextType = S, t
            }
            const w = new WeakMap;
            var M = n(88180),
                R = n(29624),
                T = n(94707),
                k = n(18833),
                N = n(9856),
                D = n(47393);

            function W(e) {
                const {
                    ranges: t,
                    activeRange: n,
                    onSelectRange: i
                } = e;
                return s.createElement(s.Fragment, null, t.map(e => s.createElement(R.ContextMenuItem, {
                    key: e.value.value,
                    label: e.description || e.text,
                    active: n === e.value.value,
                    checked: n === e.value.value,
                    checkable: !0,
                    disabled: !1,
                    onClick: o.bind(null, e),
                    doNotCloseOnClick: !1,
                    subItems: []
                })));

                function o(e) {
                    e && i && i(e), (0, u.globalCloseMenu)()
                }
            }

            function A(e) {
                const {
                    onGoToDateClick: t
                } = e;
                return s.createElement(s.Fragment, null, s.createElement(T.Separator, {
                    className: D.separator
                }), s.createElement(R.ContextMenuItem, {
                    icon: N,
                    label: (0, k.appendEllipsis)((0, o.t)("Go to")),
                    onClick: t,
                    active: !1,
                    checked: !1,
                    checkable: !1,
                    disabled: !1,
                    doNotCloseOnClick: !1,
                    subItems: []
                }))
            }
            const P = {
                    title: (0, o.t)("Date Range"),
                    goToDate: (0, k.appendEllipsis)((0, o.t)("Go to"))
                },
                F = (0, b.registryContextType)();
            class B extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleGoToDateClick = () => {
                        const {
                            chartWidget: e
                        } = this.context;
                        (0,
                            M.showGoToDateDialog)(e), (0, u.globalCloseMenu)()
                    }, this._handleRangeSelect = e => {
                        e && this.props.onSelectRange && this.props.onSelectRange(e), (0, u.globalCloseMenu)()
                    }, this._renderChildren = e => {
                        const {
                            ranges: t,
                            activeRange: n,
                            goToDateButton: i
                        } = this.props;
                        return e ? s.createElement(s.Fragment, null, s.createElement(W, {
                            ranges: t,
                            activeRange: n,
                            onSelectRange: this._handleRangeSelect
                        }), i && s.createElement(A, {
                            onGoToDateClick: this._handleGoToDateClick
                        })) : s.createElement(s.Fragment, null, t.map(e => s.createElement(m.PopupMenuItem, {
                            key: e.value.value,
                            label: e.description || e.text,
                            isActive: n === e.value.value,
                            onClick: this._handleRangeSelect,
                            onClickArg: e
                        })), i && s.createElement(g.PopupMenuSeparator, null), i && s.createElement(m.PopupMenuItem, {
                            label: P.goToDate,
                            onClick: this._handleGoToDateClick
                        }))
                    }, (0, b.validateRegistry)(t, {
                        chartWidget: a.any.isRequired
                    })
                }
                render() {
                    return s.createElement(p.MatchMedia, {
                        rule: "screen and (max-width: 428px)"
                    }, e => s.createElement(h.ToolWidgetMenu, {
                        className: D.button,
                        content: P.title,
                        arrow: !0,
                        verticalAttachEdge: d.VerticalAttachEdge.Top,
                        verticalDropDirection: d.VerticalDropDirection.FromBottomToTop,
                        horizontalMargin: 4,
                        "data-name": "date-ranges-menu",
                        isDrawer: e,
                        onClick: this._trackClick
                    }, this._renderChildren(e)))
                }
                _trackClick() {
                    0
                }
            }
            B.contextType = F;
            const L = E(B);
            var z = n(68766),
                O = n(22880);

            function H(e) {
                const t = r(e.className, O.item, {
                    [O.isActive]: e.isActive,
                    [O.isFirst]: e.isFirst,
                    [O.isLast]: e.isLast
                });
                return s.createElement("div", {
                    className: t,
                    onClick: e.onClick,
                    ref: e.reference
                }, e.children)
            }
            var I = n(93173),
                Y = n(72767);
            const G = (0, I.mergeThemes)(z.DEFAULT_SLIDER_THEME, Y);
            var j = n(38952);
            const Z = (0, z.factory)((function(e) {
                return s.createElement("div", {
                    className: r(e.className, G.slider),
                    ref: e.reference
                }, s.createElement("div", {
                    className: G.inner
                }))
            }));
            const V = E((function(e) {
                const {
                    className: t,
                    ranges: n,
                    activeRange: i,
                    onSelectRange: o
                } = e;
                return s.createElement(Z, {
                    className: r(j.sliderRow, t),
                    "data-name": "date-ranges-tabs"
                }, n.map((e, t) => s.createElement(H, {
                    key: e.value.value,
                    value: e.value.value,
                    isFirst: 0 === t,
                    isLast: t === n.length - 1,
                    isActive: i === e.value.value,
                    onClick: o && o.bind(null, e)
                }, s.createElement("div", {
                    title: e.description || e.text,
                    className: "apply-common-tooltip"
                }, e.text))))
            }));
            var U = n(72571),
                q = n(25784),
                K = n(80185),
                J = n(61996),
                Q = n(25033);
            const X = (0, q.hotKeySerialize)({
                    keys: [(0, K.humanReadableModifiers)(K.Modifiers.Alt, !1), "G"],
                    text: "{0} + {1}"
                }),
                $ = (0, b.registryContextType)();
            class ee extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidget: e
                        } = this.context;
                        (0, _.trackEvent)("GUI", "Chart Bottom Toolbar", "go to"), (0, M.showGoToDateDialog)(e)
                    }, (0, b.validateRegistry)(t, {
                        chartWidget: a.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e,
                        ranges: t
                    } = this.props;
                    return t.length > 0 && s.createElement("div", {
                        className: r("apply-common-tooltip", Q.button, e),
                        "data-name": "go-to-date",
                        "data-tooltip-hotkey": X,
                        onClick: this._handleClick,
                        title: (0, o.t)("Go to")
                    }, s.createElement(U.Icon, {
                        className: Q.icon,
                        icon: J
                    }))
                }
            }
            ee.contextType = $;
            const te = E(ee);
            var ne = n(32925);

            function se(e) {
                const {
                    reference: t,
                    className: n,
                    children: i,
                    ...o
                } = e;
                return s.createElement("button", { ...o,
                    className: r(n, ne.button),
                    ref: t
                }, s.createElement("span", {
                    className: ne.inner
                }, i))
            }
            var ie = n(76099),
                oe = n(89963),
                ae = n(90687),
                re = n(9696);
            class le extends s.PureComponent {
                constructor(e) {
                    super(e), this._element = null, this._menuShown = !1, this._preventShowingMenu = !1, this._handleRef = e => {
                        this._element = e
                    }, this._onMouseDown = () => {
                        this._preventShowingMenu = this._menuShown
                    }, this._showMenu = () => {
                        if (this._preventShowingMenu) return void re.ContextMenuManager.hideAll();
                        const {
                            getActions: e
                        } = this.props, t = (0, v.ensureNotNull)(this._element), n = e();
                        if (0 === n.length) return;
                        const s = t.getBoundingClientRect();
                        re.ContextMenuManager.showMenu(n, {
                            clientX: s.left,
                            clientY: s.top,
                            attachToYBy: "bottom"
                        }, void 0, {
                            menuName: "TimezoneMenuContextMenu"
                        }, () => {
                            this._menuShown = !1
                        }).then(() => {
                            this._menuShown = !0
                        })
                    }
                }
                render() {
                    const {
                        children: e
                    } = this.props;
                    return s.createElement("span", {
                        onClick: this._showMenu,
                        onMouseDown: this._onMouseDown,
                        ref: this._handleRef
                    }, e)
                }
            }
            var ce = n(93540),
                he = n(17963);
            const de = {
                hint: (0, o.t)("Timezone")
            };
            const ue = (0, b.registryContextType)();
            class pe extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._timeFormatter = new oe.TimeFormatter, this._tickInterval = void 0, this._tickClock = () => {
                        const {
                            chartApiInstance: e
                        } = this.context;
                        if (void 0 !== this._timezone) {
                            const t = (0, ce.utc_to_cal)(this._timezone, e.serverTime());
                            this.setState({
                                time: this._timeFormatter.format(t)
                            })
                        }
                    }, this._getActions = () => {
                        if (!this.props.withMenu) return [];
                        const {
                            chartWidget: e
                        } = this.context;
                        return function(e) {
                            e.updateActions();
                            const t = e.actions();
                            return t && t.applyTimeZone instanceof ae.Action ? t.applyTimeZone.getSubItems() : []
                        }(e)
                    }, (0, b.validateRegistry)(t, {
                        chartWidget: a.any.isRequired,
                        chartApiInstance: a.any.isRequired
                    }), this.state = {
                        time: ""
                    }
                }
                componentDidMount() {
                    const {
                        chartWidget: e
                    } = this.context;
                    this._tickInterval = setInterval(this._tickClock, 1e3), e.withModel(null, () => {
                        const t = e.model();
                        t.model().mainSeries().dataEvents().symbolResolved().subscribe(this, this.updateTimezonesButton), t.model().properties().childs().timezone.subscribe(this, this.updateTimezonesButton)
                    })
                }
                componentWillUnmount() {
                    const {
                        chartWidget: e
                    } = this.context;
                    clearInterval(this._tickInterval), e.withModel(null, () => {
                        const t = e.model();
                        t.model().mainSeries().dataEvents().symbolResolved().unsubscribe(this, this.updateTimezonesButton), t.model().properties().childs().timezone.unsubscribe(this, this.updateTimezonesButton)
                    })
                }
                render() {
                    const {
                        className: e,
                        withMenu: t
                    } = this.props, {
                        time: n
                    } = this.state, i = void 0 !== this._timezone ? (0, ie.parseTzOffset)(this._timezone.name()).string : null;
                    return s.createElement(le, {
                        getActions: this._getActions
                    }, s.createElement(se, {
                        className: r(e, he.button, "apply-common-tooltip"),
                        title: t ? de.hint : void 0,
                        disabled: !t,
                        "data-name": "time-zone-menu"
                    }, n && i && `${n} (${i})`))
                }
                updateTimezonesButton() {
                    const {
                        chartWidget: e
                    } = this.context;
                    if (!e.hasModel()) return;
                    if (null === e.model().mainSeries().symbolInfo()) return;
                    let t = e.model().model().timezone();
                    if ("exchange" === t) {
                        const n = (0, v.ensureNotNull)(e.model().mainSeries().symbolInfo()).timezone;
                        n && (t = n)
                    }
                    this._timezone = (0, ce.get_timezone)(t), this._tickClock()
                }
            }
            pe.contextType = ue;
            var me = n(71922);

            function ge(e) {
                return s.createElement("span", {
                    className: r(me.separator, e.className)
                })
            }
            var ve = n(75803),
                _e = n(18517),
                be = n(1227);
            class fe {
                constructor(e, t, n) {
                    this._highlighted = !1, this._chartWidget = e, this._priceScaleGetter = t, this._owner = n, this._setHighlight = this._setHighlight.bind(this), this._removeHighlight = this._removeHighlight.bind(this)
                }
                destroy() {
                    this._highlighted && this._removeHighlight()
                }
                handlers() {
                    const e = be.CheckMobile.any();
                    return {
                        onMouseEnter: e ? void 0 : this._setHighlight,
                        onMouseLeave: e ? void 0 : this._removeHighlight
                    }
                }
                _setHighlight() {
                    if (!this._chartWidget.hasModel()) return;
                    const e = this._chartWidget.model().model(),
                        t = e.paneForSource(e.mainSeries()),
                        n = this._priceScaleGetter();
                    if (null === t || null === n) return;
                    const s = this._chartWidget.paneByState(t);
                    if (null !== s) {
                        const t = s.rightPriceAxisesContainer().findAxisWidgetForScale(n);
                        let i = null;
                        null !== t && (i = t.axisInfo());
                        const o = s.leftPriceAxisesContainer().findAxisWidgetForScale(n);
                        null !== o && (i = o.axisInfo());
                        const a = s.highlightedPriceAxis();
                        null !== i && a.value().axis !== i && (a.setValue({
                            owner: this._owner,
                            axis: i
                        }), e.lightUpdate(), this._highlighted = !0)
                    }
                }
                _removeHighlight() {
                    if (!this._chartWidget.hasModel()) return;
                    const e = this._chartWidget.model().model(),
                        t = e.paneForSource(e.mainSeries());
                    if (null === t) return;
                    const n = this._chartWidget.paneByState(t);
                    if (null !== n) {
                        const t = n.highlightedPriceAxis(),
                            s = t.value();
                        null !== s.axis && s.owner === this._owner && (t.setValue({
                            owner: this._owner,
                            axis: null
                        }), e.lightUpdate(), this._highlighted = !1)
                    }
                }
            }
            const Ce = (0, b.registryContextType)(),
                xe = new _e.TranslatedString("toggle log scale", (0, o.t)("toggle log scale"));
            const ye = (0, b.registryContextType)(),
                Se = new _e.TranslatedString("toggle auto scale", (0, o.t)("toggle auto scale"));
            const Ee = (0, b.registryContextType)(),
                we = new _e.TranslatedString("toggle percentage scale", (0, o.t)("toggle percentage scale"));
            const Me = (0, b.registryContextType)();
            var Re = n(70086),
                Te = n(12777),
                ke = n(85473),
                Ne = n(58198),
                De = n(53030);
            const We = (0, b.registryContextType)();
            class Ae extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            resizerDetacher: e,
                            chartWidgetCollection: t
                        } = this.context;
                        t.setViewMode(ke.CollectionViewMode.Multichart), e.exitFullscreen()
                    }, (0, b.validateRegistry)(t, {
                        chartWidgetCollection: a.any.isRequired,
                        resizerDetacher: a.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e
                    } = this.props;
                    return s.createElement(ve.ToolWidgetButton, {
                        icon: De,
                        className: e,
                        onClick: this._handleClick
                    })
                }
            }
            Ae.contextType = We;
            var Pe = n(90795),
                Fe = n(46930),
                Be = n(43527);
            const Le = {
                    extLabel: (0, o.t)("ext"),
                    extHint: (0, o.t)("Extended Hours is available only for intraday charts"),
                    percentageHint: (0, o.t)("Toggle Percentage"),
                    logLabel: (0, o.t)("log", {
                        context: "scale"
                    }),
                    logHint: (0, o.t)("Toggle Log Scale"),
                    autoLabel: (0, o.t)("auto", {
                        context: "scale"
                    }),
                    autoHint: (0, o.t)("Toggle Auto Scale"),
                    fullscreenHint: (0, o.t)("Toggle Maximize Chart"),
                    adjLabel: (0, o.t)("adj", {
                        context: "adjustments"
                    }),
                    adjHint: (0, o.t)("Adjust data for dividends"),
                    adjForDividendsOnlyHint: (0, o.t)("Main symbol data is adjusted for dividends only"),
                    adjForSplitsOnlyHint: (0, o.t)("Main symbol data is adjusted for splits only"),
                    backAdjustLabel: (0, o.t)("b-adj", {
                        context: "adjustments"
                    }),
                    backAdjustHint: (0, o.t)("Adjust for contract changes"),
                    settlementAsCloseLabel: (0, o.t)("set", {
                        context: "adjustments"
                    }),
                    settlementAsCloseHint: (0, o.t)("Use settlement as close on daily interval")
                },
                ze = (Oe = e => s.createElement(ve.ToolWidgetButton, {
                    text: Le.logLabel,
                    title: Le.logHint,
                    className: e.className,
                    isActive: e.isLogarithm,
                    isGrouped: !0,
                    onClick: Ke(e.onClick, "log", e.isLogarithm),
                    onMouseEnter: e.onMouseEnter,
                    onMouseLeave: e.onMouseLeave,
                    "data-name": "logarithm"
                }), (He = class extends s.PureComponent {
                    constructor(e, t) {
                        super(e, t), this._priceScale = null, this._handleSelect = () => {
                            const e = this.context.chartWidget.model(),
                                t = (0, v.ensureNotNull)(this.state.series),
                                n = t.priceScale(),
                                s = n.mode();
                            t.priceScale().isLockScale() || e.setPriceScaleMode({
                                log: !s.log
                            }, n, xe)
                        }, (0, b.validateRegistry)(t, {
                            chartWidget: a.any.isRequired
                        }), this.state = {
                            isActive: !1,
                            series: null
                        }, this._priceAxisHighlighter = new fe(this.context.chartWidget, () => this._priceScale, "logarithm")
                    }
                    componentDidMount() {
                        const e = this.context.chartWidget;
                        e.withModel(null, () => {
                            const t = e.model().mainSeries(),
                                n = t.priceScale();
                            this._handleMainSeriesPriceScaleChanged(n), t.priceScaleChanged().subscribe(this, this._handleMainSeriesPriceScaleChanged), this._handleModeChanged({}, n.mode()), this.setState({
                                isActive: t.priceScale().isLog(),
                                series: t
                            })
                        })
                    }
                    componentWillUnmount() {
                        const e = this.context.chartWidget;
                        e.withModel(null, () => {
                            e.model().mainSeries().priceScaleChanged().unsubscribe(this, this._handleMainSeriesPriceScaleChanged)
                        }), null !== this._priceScale && (this._priceScale.modeChanged().unsubscribeAll(this), this._priceScale = null), this._priceAxisHighlighter.destroy()
                    }
                    render() {
                        const {
                            className: e
                        } = this.props, {
                            isActive: t,
                            series: n
                        } = this.state;
                        return s.createElement(Oe, { ...this._priceAxisHighlighter.handlers(),
                            className: e,
                            isLogarithm: t,
                            isDisabled: null === n,
                            onClick: this._handleSelect
                        })
                    }
                    _handleMainSeriesPriceScaleChanged(e) {
                        null !== this._priceScale && this._priceScale.modeChanged().unsubscribe(this, this._handleModeChanged), this._priceScale = e, this._priceScale.modeChanged().subscribe(this, this._handleModeChanged), this._handleModeChanged({}, e.mode())
                    }
                    _handleModeChanged(e, t) {
                        Boolean(t.log) !== this.state.isActive && this.setState({
                            isActive: Boolean(t.log)
                        })
                    }
                }).contextType = Ce, He);
            var Oe, He;
            const Ie = function(e) {
                    var t;
                    return (t = class extends s.PureComponent {
                        constructor(e, t) {
                            super(e, t), this._priceScale = null, this._handleSelect = () => {
                                const e = this.context.chartWidget.model(),
                                    t = (0, v.ensureNotNull)(this.state.series).priceScale(),
                                    n = t.mode();
                                e.setPriceScaleMode({
                                    autoScale: !n.autoScale
                                }, t, Se)
                            }, (0, b.validateRegistry)(t, {
                                chartWidget: a.any.isRequired
                            }), this.state = {
                                isActive: !1,
                                series: null
                            }, this._priceAxisHighlighter = new fe(this.context.chartWidget, () => this._priceScale, "auto")
                        }
                        componentDidMount() {
                            const e = this.context.chartWidget;
                            e.withModel(null, () => {
                                const t = e.model().mainSeries(),
                                    n = t.priceScale();
                                this._handleMainSeriesPriceScaleChanged(n), t.priceScaleChanged().subscribe(this, this._handleMainSeriesPriceScaleChanged), this._handleModeChanged({}, n.mode()), this.setState({
                                    isActive: t.priceScale().isAutoScale(),
                                    series: t
                                })
                            })
                        }
                        componentWillUnmount() {
                            const e = this.context.chartWidget;
                            e.withModel(null, () => {
                                e.model().mainSeries().priceScaleChanged().unsubscribe(this, this._handleMainSeriesPriceScaleChanged)
                            }), null !== this._priceScale && (this._priceScale.modeChanged().unsubscribeAll(this), this._priceScale = null), this._priceAxisHighlighter.destroy()
                        }
                        render() {
                            const {
                                className: t
                            } = this.props, {
                                isActive: n,
                                series: i
                            } = this.state;
                            return s.createElement(e, { ...this._priceAxisHighlighter.handlers(),
                                className: t,
                                isAuto: n,
                                isDisabled: null === i,
                                onClick: this._handleSelect
                            })
                        }
                        _handleMainSeriesPriceScaleChanged(e) {
                            null !== this._priceScale && this._priceScale.modeChanged().unsubscribe(this, this._handleModeChanged), this._priceScale = e, this._priceScale.modeChanged().subscribe(this, this._handleModeChanged), this._handleModeChanged({}, e.mode())
                        }
                        _handleModeChanged(e, t) {
                            Boolean(t.autoScale) !== this.state.isActive && this.setState({
                                isActive: Boolean(t.autoScale)
                            })
                        }
                    }).contextType = ye, t
                }(e => s.createElement(ve.ToolWidgetButton, {
                    text: Le.autoLabel,
                    title: Le.autoHint,
                    className: e.className,
                    isActive: e.isAuto,
                    isGrouped: !0,
                    onClick: Ke(e.onClick, "auto", e.isAuto),
                    onMouseEnter: e.onMouseEnter,
                    onMouseLeave: e.onMouseLeave,
                    "data-name": "auto"
                })),
                Ye = function(e) {
                    var t;
                    return (t = class extends s.PureComponent {
                        constructor(e, t) {
                            super(e, t), this._priceScale = null, this._handleSelect = () => {
                                const e = this.context.chartWidget.model(),
                                    t = (0, v.ensureNotNull)(this.state.series),
                                    n = t.priceScale(),
                                    s = n.mode();
                                t.priceScale().isLockScale() || e.setPriceScaleMode({
                                    percentage: !s.percentage
                                }, n, we)
                            }, (0, b.validateRegistry)(t, {
                                chartWidget: a.any.isRequired
                            }), this.state = {
                                isActive: !1,
                                series: null
                            }, this._priceAxisHighlighter = new fe(this.context.chartWidget, () => this._priceScale, "percentage")
                        }
                        componentDidMount() {
                            const e = this.context.chartWidget;
                            e.withModel(null, () => {
                                const t = e.model().mainSeries(),
                                    n = t.priceScale();
                                this._handleMainSeriesPriceScaleChanged(n), t.priceScaleChanged().subscribe(this, this._handleMainSeriesPriceScaleChanged), this._handleScaleChange({}, n.mode()), this.setState({
                                    isActive: t.priceScale().isPercentage(),
                                    series: t
                                })
                            })
                        }
                        componentWillUnmount() {
                            const e = this.context.chartWidget;
                            e.withModel(null, () => {
                                e.model().mainSeries().priceScaleChanged().unsubscribe(this, this._handleMainSeriesPriceScaleChanged)
                            }), null !== this._priceScale && (this._priceScale.modeChanged().unsubscribeAll(this), this._priceScale = null), this._priceAxisHighlighter.destroy()
                        }
                        render() {
                            const {
                                className: t
                            } = this.props, {
                                isActive: n,
                                series: i
                            } = this.state;
                            return s.createElement(e, { ...this._priceAxisHighlighter.handlers(),
                                className: t,
                                isPercentage: n,
                                isDisabled: null === i,
                                onClick: this._handleSelect
                            })
                        }
                        _handleMainSeriesPriceScaleChanged(e) {
                            null !== this._priceScale && this._priceScale.modeChanged().unsubscribe(this, this._handleScaleChange), this._priceScale = e, this._priceScale.modeChanged().subscribe(this, this._handleScaleChange), this._handleScaleChange({}, e.mode())
                        }
                        _handleScaleChange(e, t) {
                            Boolean(t.percentage) !== this.state.isActive && this.setState({
                                isActive: Boolean(t.percentage)
                            })
                        }
                    }).contextType = Ee, t
                }(e => s.createElement(ve.ToolWidgetButton, {
                    icon: Pe,
                    title: Le.percentageHint,
                    className: e.className,
                    isActive: e.isPercentage,
                    isDisabled: e.isDisabled,
                    isGrouped: !0,
                    onClick: Ke(e.onClick, "percent", e.isPercentage),
                    onMouseEnter: e.onMouseEnter,
                    onMouseLeave: e.onMouseLeave,
                    "data-name": "percentage"
                }));
            const Ge = (0, q.hotKeySerialize)({
                    keys: [(0, K.humanReadableModifiers)(K.Modifiers.Alt, !1), "Enter"],
                    text: "{0} + {1}"
                }),
                je = function(e) {
                    var t;
                    return (t = class extends s.PureComponent {
                        constructor(e, t) {
                            super(e, t), this._handleClick = e => {
                                const {
                                    resizerDetacher: t,
                                    chartWidgetCollection: n
                                } = this.context;
                                e.shiftKey && t.detachable.value() ? t.detach() : this.state.isFullscreen ? t.exitFullscreen() : t.requestFullscreen()
                            }, this._handleLayoutChange = e => {
                                this.setState({
                                    isFullscreen: e
                                })
                            }, this._handlePhoneSize = () => {
                                0
                            }, (0, b.validateRegistry)(t, {
                                chartWidgetCollection: a.any.isRequired,
                                resizerDetacher: a.any.isRequired
                            });
                            const {
                                resizerDetacher: n
                            } = t;
                            this.state = {
                                isFullscreen: n.fullscreen.value(),
                                isChangeLayoutButton: this._isChangeLayoutButton()
                            }
                        }
                        componentDidMount() {
                            const {
                                resizerDetacher: e,
                                chartWidgetCollection: t
                            } = this.context, {
                                mobileChangeLayoutEnabled: n
                            } = this.props;
                            e.fullscreen.subscribe(this._handleLayoutChange)
                        }
                        componentWillUnmount() {
                            const {
                                resizerDetacher: e,
                                chartWidgetCollection: t
                            } = this.context, {
                                mobileChangeLayoutEnabled: n
                            } = this.props;
                            e.fullscreen.unsubscribe(this._handleLayoutChange)
                        }
                        render() {
                            const {
                                className: t
                            } = this.props, {
                                isFullscreen: n,
                                isChangeLayoutButton: i
                            } = this.state;
                            return s.createElement(e, {
                                className: t,
                                isFullscreen: n,
                                onClick: this._handleClick
                            })
                        }
                        _isChangeLayoutButton() {
                            return !1
                        }
                    }).contextType = Me, t
                }(e => s.createElement(ve.ToolWidgetButton, {
                    icon: Fe,
                    title: Le.fullscreenHint,
                    className: e.className,
                    isActive: e.isFullscreen,
                    onClick: Ke(e.onClick, "maximize chart", e.isFullscreen),
                    "data-tooltip-hotkey": Ge,
                    "data-name": "fullscreen"
                })),
                Ze = {
                    properties: !0,
                    fullscreen: !0,
                    preventPhoneLayout: !0
                },
                Ve = {
                    fullscreen: Number.MIN_SAFE_INTEGER,
                    preventPhoneLayout: Number.MIN_SAFE_INTEGER,
                    properties: Number.MIN_SAFE_INTEGER,
                    separator: -2,
                    timeZones: -1,
                    auto: 0,
                    logarithm: 1,
                    percentage: 2,
                    session: 3,
                    adj: 4,
                    backAdj: 5,
                    settlementAsClose: 6
                },
                Ue = (() => {
                    const e = new Map;
                    return e.set(ze, "logarithm"), e.set(Ye, "percentage"), e.set(Ie, "auto"), e.set(je, "fullscreen"), e.set(Ae, "preventPhoneLayout"), e
                })();

            function qe(e) {
                0
            }

            function Ke(e, t, n) {
                return t => {
                    e(t)
                }
            }
            const Je = {
                    dateRangeMode: "hidden",
                    separator: !0,
                    timeZones: !0,
                    fullscreen: !0,
                    preventPhoneLayout: !0,
                    properties: !0,
                    auto: !0,
                    logarithm: !0,
                    percentage: !0,
                    session: !0,
                    adj: !0,
                    backAdj: !0,
                    settlementAsClose: !0
                },
                Qe = (0, b.registryContextType)();
            class Xe extends s.PureComponent {
                constructor(e, t) {
                    var n, o;
                    super(e, t), this._timezoneButtonRef = null, this._layout = Object.assign({}, Je), this._raf = null, this._toolbar = null, this._rangeExpanded = null, this._rangeCollapsed = null, this._seriesComponents = {}, this._injector = (n = () => this._layout, o = (e, t) => this._seriesComponents[t] = e, (e, t, i) => {
                        if (s.isValidElement(e) && "string" != typeof e.type) {
                            const {
                                props: a
                            } = e;
                            if ("string" == typeof a.className) {
                                const l = {
                                        className: r(a.className, 0 === t && Be.first, t === i.length - 1 && Be.last)
                                    },
                                    c = n(),
                                    h = (0, v.ensureDefined)(Ue.get(e.type));
                                return s.createElement("div", {
                                    key: null === e.key ? void 0 : e.key,
                                    className: r(Be.inline, c[h] && Be.collapsed),
                                    ref: e => o(e, h),
                                    onClick: () => qe()
                                }, s.cloneElement(e, l))
                            }
                        }
                        return e
                    }), this._updateButtonsVisibility = () => {
                        0
                    }, this._handleResize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            const e = this._layout,
                                t = (0, v.ensureNotNull)(this._toolbar),
                                n = (0, v.ensureNotNull)(this._rangeExpanded),
                                s = (o = function(e) {
                                    const t = {};
                                    return Object.keys(e).forEach(n => {
                                        const s = e[n];
                                        if (null !== s) {
                                            const e = i.findDOMNode(s);
                                            null !== e && (t[n] = e)
                                        }
                                    }), t
                                }(this._seriesComponents), Object.keys(o).map(e => ({
                                    name: e,
                                    width: o[e].offsetWidth
                                })).sort((e, t) => Ve[e.name] - Ve[t.name]));
                            var o;
                            const a = t.offsetWidth,
                                r = s.reduce((e, t) => e + t.width, 0),
                                l = n.offsetWidth,
                                c = !Boolean(n.textContent) || a - r - l <= 0 ? "collapsed" : "expanded";
                            if (Object.assign(e, {
                                    dateRangeMode: c
                                }), "expanded" !== c) {
                                const t = a - (0, v.ensureNotNull)(this._rangeCollapsed).offsetWidth - 0;
                                let n = 0,
                                    i = 0;
                                for (const o of s) n += o.width, o.name in Ze ? (i += o.width, Object.assign(e, {
                                    [o.name]: !1
                                })) : Object.assign(e, {
                                    [o.name]: t <= n
                                });
                                t <= i && Object.assign(e, {
                                    dateRangeMode: "hidden"
                                })
                            } else Object.assign(e, {
                                separator: !1,
                                timeZones: !1,
                                fullscreen: !1,
                                preventPhoneLayout: !1,
                                properties: !1,
                                auto: !1,
                                logarithm: !1,
                                percentage: !1,
                                session: !1,
                                adj: !1,
                                settlementAsClose: !1,
                                backAdj: !1
                            });
                            this._applyResizing(), this._raf = null
                        }))
                    }, this._handleTimezoneButtonRef = e => {
                        this._timezoneButtonRef = e
                    }, this._handleMeasure = () => {
                        null !== this._toolbar && this.resizeUI()
                    }, this._handleFullscreenableChange = e => {
                        this._setStateWithResize({
                            isFullscreenable: e
                        }), this._handlePreventPhoneLayoutButtonVisibility()
                    }, this._handlePreventPhoneLayoutButtonVisibility = () => {
                        this._setStateWithResize({
                            isPreventPhoneLayoutButton: this._isPreventPhoneLayoutButton()
                        })
                    }, this._handleToolbarRef = e => this._toolbar = e, this._handleRangeCollapsedRef = e => this._rangeCollapsed = e, this._handleRangeExpandedRef = e => this._rangeExpanded = e, this._handleTimeZonesRef = e => {
                        this._seriesComponents.timeZones = e
                    }, this._handleSessionsRef = e => {
                        this._seriesComponents.session = e
                    }, this._handleSeparatorRef = e => {
                        this._seriesComponents.separator = e
                    }, (0, b.validateRegistry)(t, {
                        onContentBoxChanged: a.any.isRequired,
                        chartApiInstance: a.any.isRequired,
                        chartWidget: a.any.isRequired,
                        chartWidgetCollection: a.any.isRequired,
                        resizerDetacher: a.any.isRequired
                    });
                    const {
                        resizerDetacher: l
                    } = this.context;
                    this.state = {
                        isFullscreenable: l.fullscreenable.value(),
                        isPreventPhoneLayoutButton: this._isPreventPhoneLayoutButton()
                    }
                }
                componentDidMount() {
                    const {
                        onContentBoxChanged: e,
                        resizerDetacher: t,
                        chartWidgetCollection: n,
                        chartWidget: s
                    } = this.context;
                    e.subscribe(this, this._handleResize), Ne.mediaState.on("changeDevice", this._handlePreventPhoneLayoutButtonVisibility), n.viewMode.subscribe(this._handlePreventPhoneLayoutButtonVisibility), t.fullscreenable.subscribe(this._handleFullscreenableChange), this.updateTimezonesButton(), this.resizeUI()
                }
                componentWillUnmount() {
                    const {
                        onContentBoxChanged: e,
                        resizerDetacher: t,
                        chartWidgetCollection: n,
                        chartWidget: s
                    } = this.context;
                    e.unsubscribe(this, this._handleResize), Ne.mediaState.off("changeDevice", this._handlePreventPhoneLayoutButtonVisibility), n.viewMode.unsubscribe(this._handlePreventPhoneLayoutButtonVisibility),
                        t.fullscreenable.unsubscribe(this._handleFullscreenableChange), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null)
                }
                render() {
                    const e = this._layout,
                        {
                            timeFramesWidgetEnabled: t,
                            timeWidgetEnabled: n,
                            percentageScaleButtonEnabled: i,
                            logScaleButtonEnabled: o,
                            autoScaleButtonEnabled: a,
                            fullscreenButtonEnabled: h
                        } = this.props;
                    return s.createElement("div", {
                        className: Be.toolbar,
                        ref: this._handleToolbarRef,
                        onContextMenu: Te.preventDefault
                    }, t && s.createElement(Re.FragmentMap, null, s.createElement("div", {
                        className: r(Be.dateRangeWrapper, "collapsed" !== e.dateRangeMode && Be.collapsed),
                        ref: this._handleRangeCollapsedRef
                    }, s.createElement("div", {
                        className: r(Be.dateRangeCollapsed)
                    }, s.createElement(L, {
                        goToDateButton: this.props.goToDateEnabled
                    }))), s.createElement(l, {
                        onMeasure: this._handleMeasure
                    }, s.createElement("div", {
                        className: r(Be.dateRangeWrapper, "expanded" !== e.dateRangeMode && Be.collapsed),
                        ref: this._handleRangeExpandedRef
                    }, s.createElement("div", {
                        className: r(Be.dateRangeExpanded)
                    }, s.createElement(V, {
                        onSelectRange: this._trackRangeButtonClick
                    }), this.props.goToDateEnabled && s.createElement(ge, null), this.props.goToDateEnabled && s.createElement(te, null))))), s.createElement("div", {
                        className: Be.seriesControlWrapper
                    }, n && s.createElement(l, {
                        onMeasure: this._handleMeasure
                    }, s.createElement("div", {
                        className: r(Be.inline, e.timeZones && Be.collapsed),
                        ref: this._handleTimeZonesRef
                    }, s.createElement("div", {
                        className: Be.inline,
                        onClick: this._trackTimezonesButtonClick
                    }, s.createElement(pe, {
                        className: Be.timezone,
                        withMenu: this.props.timezoneMenuEnabled,
                        ref: this._handleTimezoneButtonRef
                    })))), !1, s.createElement("div", {
                        ref: this._handleSeparatorRef,
                        className: r(Be.inline, e.separator && Be.collapsed)
                    }, s.createElement(ge, null)), s.createElement(Re.FragmentMap, {
                        map: this._injector
                    }, !1, !1, !1, i && !c.enabled("fundamental_widget") && s.createElement(Ye, {
                        className: Be.icon
                    }), o && s.createElement(ze, {
                        className: Be.item
                    }), a && s.createElement(Ie, {
                        className: Be.item
                    }), h && this.state.isFullscreenable && s.createElement(je, {
                        className: Be.icon,
                        mobileChangeLayoutEnabled: this.props.mobileChangeLayoutEnabled
                    }), this.props.fullscreenButtonEnabled && this.props.mobileChangeLayoutEnabled && this.state.isPreventPhoneLayoutButton && s.createElement(Ae, {
                        className: Be.icon
                    }))))
                }
                updateTimezonesButton() {
                    null !== this._timezoneButtonRef && this._timezoneButtonRef.updateTimezonesButton()
                }
                resizeUI() {
                    this._handleResize()
                }
                _trackRangeButtonClick(e) {
                    0
                }
                _trackTimezonesButtonClick() {
                    qe()
                }
                _setStateWithResize(e) {
                    Object.assign(this._layout, Je), this._applyResizing(), this.setState(e, () => this._handleResize())
                }
                _applyResizing() {
                    const {
                        dateRangeMode: e,
                        ...t
                    } = this._layout;
                    this._rangeExpanded && this._rangeExpanded.classList.toggle(Be.collapsed, "expanded" !== e), this._rangeCollapsed && this._rangeCollapsed.classList.toggle(Be.collapsed, "collapsed" !== e), Object.keys(t).forEach(e => {
                        const n = e,
                            s = this._seriesComponents[n];
                        s && s.classList.toggle(Be.collapsed, t[n])
                    })
                }
                _isPreventPhoneLayoutButton() {
                    {
                        const {
                            chartWidgetCollection: e,
                            resizerDetacher: t
                        } = this.context;
                        return t.fullscreenable.value() && be.CheckMobile.any() && Ne.mediaState.isPhoneSizeDevice() && e.viewMode.value() === ke.CollectionViewMode.ForceFullscreen
                    }
                }
            }
            Xe.contextType = Qe;
            const $e = {
                onContentBoxChanged: a.any,
                computeContentBox: a.any,
                chartWidget: a.any,
                chartApiInstance: a.any,
                chartWidgetCollection: a.any,
                resizerDetacher: a.any,
                availableTimeFrames: a.any
            };
            class et extends s.PureComponent {
                constructor(e) {
                    super(e), this._setActiveChart = e => {
                        this._defineRegistry(e), this.setState({
                            chartWidget: e
                        })
                    };
                    const t = this.props.chartWidgetCollection.activeChartWidget.value();
                    this.state = {
                        chartWidget: t
                    }, this._defineRegistry(t)
                }
                componentDidMount() {
                    this.props.chartWidgetCollection.activeChartWidget.subscribe(this._setActiveChart)
                }
                componentWillUnmount() {
                    this.props.chartWidgetCollection.activeChartWidget.unsubscribe(this._setActiveChart)
                }
                render() {
                    const {
                        chartWidget: e
                    } = this.state;
                    if (!e) return null;
                    const {
                        options: t
                    } = this.props, n = {
                        timeFramesWidgetEnabled: t.timeFramesWidgetEnabled,
                        goToDateEnabled: t.timeFramesWidget.goToDateEnabled,
                        timeWidgetEnabled: t.timeWidgetEnabled,
                        timezoneMenuEnabled: t.timeWidget && t.timeWidget.timezoneMenuEnabled,
                        sessionIdButtonEnabled: t.sessionIdButtonEnabled,
                        backAdjustmentButtonEnabled: t.backAdjustmentButtonEnabled,
                        settlementAsCloseButtonEnabled: t.settlementAsCloseButtonEnabled,
                        adjustForDividendsButtonEnabled: t.adjustForDividendsButtonEnabled,
                        logScaleButtonEnabled: t.logScaleButtonEnabled,
                        percentageScaleButtonEnabled: t.percentageScaleButtonEnabled,
                        autoScaleButtonEnabled: t.autoScaleButtonEnabled,
                        fullscreenButtonEnabled: t.fullscreenButtonEnabled,
                        mobileChangeLayoutEnabled: t.mobileChangeLayoutEnabled
                    };
                    return s.createElement(b.RegistryProvider, {
                        validation: $e,
                        value: this._registry
                    }, s.createElement(Xe, {
                        key: e.id(),
                        ...n
                    }))
                }
                _defineRegistry(e) {
                    const {
                        onContentBoxChanged: t,
                        computeContentBox: n,
                        chartApiInstance: s,
                        chartWidgetCollection: i,
                        options: {
                            timeFramesWidgetEnabled: o,
                            timeFramesWidget: a
                        }
                    } = this.props, r = o ? a.availableTimeFrames : void 0;
                    this._registry = {
                        onContentBoxChanged: t,
                        computeContentBox: n,
                        chartWidget: e,
                        availableTimeFrames: r,
                        chartApiInstance: s,
                        chartWidgetCollection: i,
                        resizerDetacher: e.getResizerDetacher()
                    }
                }
            }
            class tt {
                constructor(e, t, n, o, a, r, l) {
                    this._container = e;
                    const c = s.createElement(et, {
                        onContentBoxChanged: t,
                        computeContentBox: n,
                        chartWidgetCollection: o,
                        chartApiInstance: a,
                        chartWidgetOptions: r,
                        options: l
                    });
                    i.render(c, e), e.setAttribute("data-initialized", "true")
                }
                destroy() {
                    i.unmountComponentAtNode(this._container), this._container.removeAttribute("data-initialized")
                }
            }
        },
        4257: (e, t, n) => {
            "use strict";
            n.d(t, {
                hasNewHeaderToolbarStyles: () => s
            });
            n(82527);
            const s = !1
        },
        23404: (e, t, n) => {
            "use strict";
            n.d(t, {
                validateRegistry: () => r,
                RegistryProvider: () => l,
                registryContextType: () => c
            });
            var s = n(59496),
                i = n(19036),
                o = n.n(i);
            const a = s.createContext({});

            function r(e, t) {
                o().checkPropTypes(t, e, "context", "RegistryContext")
            }

            function l(e) {
                const {
                    validation: t,
                    value: n
                } = e;
                return r(n, t), s.createElement(a.Provider, {
                    value: n
                }, e.children)
            }

            function c() {
                return a
            }
        },
        21709: (e, t, n) => {
            "use strict";

            function s(e, t, n, s, i) {
                function o(i) {
                    if (e > i.timeStamp) return;
                    const o = i.target;
                    void 0 !== n && null !== t && null !== o && o.ownerDocument === s && (t.contains(o) || n(i))
                }
                return i.click && s.addEventListener("click", o, !1), i.mouseDown && s.addEventListener("mousedown", o, !1), i.touchEnd && s.addEventListener("touchend", o, !1), i.touchStart && s.addEventListener("touchstart", o, !1), () => {
                    s.removeEventListener("click", o, !1), s.removeEventListener("mousedown", o, !1), s.removeEventListener("touchend", o, !1), s.removeEventListener("touchstart", o, !1)
                }
            }
            n.d(t, {
                addOutsideEventListener: () => s
            })
        },
        70086: (e, t, n) => {
            "use strict";
            n.d(t, {
                FragmentMap: () => i
            });
            var s = n(59496);

            function i(e) {
                if (e.map) {
                    return s.Children.toArray(e.children).map(e.map)
                }
                return e.children
            }
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => l
            });
            var s = n(35922);
            const i = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                o = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let a = 0,
                r = !1;

            function l(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++a) {
                    const e = (0, s.getCSSProperty)(t, "overflow"),
                        i = (0, s.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, s.setStyle)(n, "right", (0, s.getScrollbarWidth)() + "px"), t.style.paddingRight = i + (0, s.getScrollbarWidth)() + "px", r = !0), t.classList.add("i-no-scroll")
                } else if (!e && a > 0 && 0 == --a && (t.classList.remove("i-no-scroll"), r)) {
                    (0, s.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (l = (0, s.getContentWidth)(n), i() ? 0 : o() ? 46 : Math.min(Math.max(l, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, s.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", r = !1
                }
                var l
            }
        },
        68620: (e, t, n) => {
            "use strict";
            n.d(t, {
                Hint: () => r
            });
            var s = n(59496),
                i = n(97754),
                o = n.n(i),
                a = n(19119);

            function r(e) {
                const {
                    text: t = "",
                    className: n
                } = e;
                return s.createElement("span", {
                    className: o()(a.shortcut, n)
                }, t)
            }
        },
        29624: (e, t, n) => {
            "use strict";
            n.d(t, {
                ContextMenuItem: () => m
            });
            var s = n(59496),
                i = n(97754),
                o = n.n(i),
                a = n(72571),
                r = n(34404),
                l = n(34064),
                c = n(68620),
                h = n(711),
                d = n(58991),
                u = n(45355),
                p = n(61999);

            function m(e) {
                const {
                    isTitle: t,
                    isLoading: n,
                    isHovered: i,
                    active: m,
                    checkable: g,
                    disabled: v,
                    checked: _,
                    icon: b,
                    iconChecked: f,
                    hint: C,
                    subItems: x,
                    label: y,
                    onClick: S,
                    children: E,
                    toolbox: w,
                    jsxLabel: M,
                    size: R = "normal"
                } = e, T = (0, s.useContext)(l.EmptyIconsContext), k = !!x.length;
                return n ? s.createElement("li", {
                    className: o()(p.item, p.loading, p[R])
                }, s.createElement(r.Loader, null)) : s.createElement("li", {
                    className: o()(p.item, p.interactive, t && p.title, v && p.disabled, i && p.hovered, m && p.active, T && p.emptyIcons, p[R]),
                    onClick: S
                }, s.createElement(a.Icon, {
                    className: o()(p.icon),
                    icon: function() {
                        if (g && _) return f || b || h;
                        return b
                    }()
                }), s.createElement("span", {
                    className: o()(p.label)
                }, null != M ? M : y), !!w && s.createElement(a.Icon, {
                    onClick: function() {
                        w && w.action()
                    },
                    className: p.remove,
                    icon: u
                }), !k && C && s.createElement(c.Hint, {
                    className: p.shortcut,
                    text: C
                }), k && s.createElement(a.Icon, {
                    className: p.nested,
                    icon: d
                }), E)
            }
        },
        34064: (e, t, n) => {
            "use strict";
            n.d(t, {
                EmptyIconsContext: () => s
            });
            const s = n(59496).createContext(!1)
        },
        63694: (e, t, n) => {
            "use strict";
            n.d(t, {
                DrawerManager: () => i,
                DrawerContext: () => o
            });
            var s = n(59496);
            class i extends s.PureComponent {
                constructor(e) {
                    super(e),
                        this._addDrawer = () => {
                            const e = this.state.currentDrawer + 1;
                            return this.setState({
                                currentDrawer: e
                            }), e
                        }, this._removeDrawer = () => {
                            const e = this.state.currentDrawer - 1;
                            return this.setState({
                                currentDrawer: e
                            }), e
                        }, this.state = {
                            currentDrawer: 0
                        }
                }
                render() {
                    return s.createElement(o.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const o = s.createContext(null)
        },
        59339: (e, t, n) => {
            "use strict";
            n.d(t, {
                Drawer: () => p
            });
            var s = n(59496),
                i = n(88537),
                o = n(97754),
                a = n(59142),
                r = n(85089),
                l = n(8361),
                c = n(63694),
                h = n(1227),
                d = n(28466),
                u = n(66998);

            function p(e) {
                const {
                    position: t = "Bottom",
                    onClose: n,
                    children: p,
                    className: m,
                    theme: g = u
                } = e, v = (0, i.ensureNotNull)((0, s.useContext)(c.DrawerContext)), [_, b] = (0, s.useState)(0), f = (0, s.useRef)(null), C = (0, s.useContext)(d.CloseDelegateContext);
                return (0, s.useEffect)(() => {
                    const e = (0, i.ensureNotNull)(f.current);
                    return e.focus({
                        preventScroll: !0
                    }), C.subscribe(v, n), 0 === v.currentDrawer && (0, r.setFixedBodyState)(!0), h.CheckMobile.iOS() && (0, a.disableBodyScroll)(e), b(v.addDrawer()), () => {
                        C.unsubscribe(v, n);
                        const t = v.removeDrawer();
                        h.CheckMobile.iOS() && (0, a.enableBodyScroll)(e), 0 === t && (0, r.setFixedBodyState)(!1)
                    }
                }, []), s.createElement(l.Portal, null, s.createElement("div", {
                    className: o(u.wrap, u["position" + t])
                }, _ === v.currentDrawer && s.createElement("div", {
                    className: u.backdrop,
                    onClick: n
                }), s.createElement("div", {
                    className: o(u.drawer, g.drawer, u["position" + t], m),
                    ref: f,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, p)))
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => o
            });
            var s = n(59496),
                i = n(21709);

            function o(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: o,
                    touchStart: a,
                    handler: r,
                    reference: l,
                    ownerDocument: c = document
                } = e, h = (0, s.useRef)(null), d = (0, s.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, s.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: o,
                            touchStart: a
                        },
                        s = l ? l.current : h.current;
                    return (0, i.addOutsideEventListener)(d.current, s, r, c, e)
                }, [t, n, o, a, r]), l || h
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => i
            });
            var s = n(59496);
            class i extends s.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        30553: (e, t, n) => {
            "use strict";
            n.d(t, {
                MenuContext: () => s
            });
            const s = n(59496).createContext(null)
        },
        10618: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_MENU_THEME: () => v,
                Menu: () => _
            });
            var s = n(59496),
                i = n(97754),
                o = n.n(i),
                a = n(88537),
                r = n(97280),
                l = n(12777),
                c = n(53327),
                h = n(70981),
                d = n(63212),
                u = n(82027),
                p = n(94488),
                m = n(30553),
                g = n(16059);
            const v = g;
            class _ extends s.PureComponent {
                constructor(e) {
                    super(e),
                        this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new d.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                            this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                        }, this._handleScrollWrapRef = e => {
                            this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                        }, this._handleMeasure = ({
                            callback: e,
                            forceRecalcPosition: t
                        } = {}) => {
                            var n, s, i, o;
                            if (this.state.isMeasureValid && !t) return;
                            const {
                                position: l
                            } = this.props, c = (0, a.ensureNotNull)(this._containerRef);
                            let h = c.getBoundingClientRect();
                            const d = document.documentElement.clientHeight,
                                u = document.documentElement.clientWidth,
                                p = null !== (n = this.props.closeOnScrollOutsideOffset) && void 0 !== n ? n : 0;
                            let m = d - 0 - p;
                            const g = h.height > m;
                            if (g) {
                                (0, a.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", h = c.getBoundingClientRect()
                            }
                            const {
                                width: v,
                                height: _
                            } = h, b = "function" == typeof l ? l(v, _, d) : l, f = u - (null !== (s = b.overrideWidth) && void 0 !== s ? s : v) - 0, C = (0, r.clamp)(b.x, 0, Math.max(0, f)), x = 0 + p, y = d - (null !== (i = b.overrideHeight) && void 0 !== i ? i : _) - 0;
                            let S = (0, r.clamp)(b.y, x, Math.max(x, y));
                            if (b.forbidCorrectYCoord && S < b.y && (m -= b.y - S, S = b.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && b.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                            const E = null !== (o = b.overrideHeight) && void 0 !== o ? o : g ? m : void 0;
                            this.setState({
                                appearingMenuHeight: t ? this.state.appearingMenuHeight : E,
                                appearingMenuWidth: t ? this.state.appearingMenuWidth : b.overrideWidth,
                                appearingPosition: {
                                    x: C,
                                    y: S
                                },
                                isMeasureValid: !0
                            }, () => {
                                this._restoreScrollPosition(), e && e()
                            })
                        }, this._restoreScrollPosition = () => {
                            const e = document.activeElement,
                                t = (0, a.ensureNotNull)(this._containerRef);
                            if (null !== e && t.contains(e)) try {
                                e.scrollIntoView()
                            } catch (e) {} else(0, a.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                        }, this._resizeForced = () => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            })
                        }, this._resize = () => {
                            null === this._raf && (this._raf = requestAnimationFrame(() => {
                                this.setState({
                                    appearingMenuHeight: void 0,
                                    appearingMenuWidth: void 0,
                                    appearingPosition: void 0,
                                    isMeasureValid: void 0
                                }), this._raf = null
                            }))
                        }, this._handleGlobalClose = e => {
                            this.props.onClose(e)
                        }, this._handleSlot = e => {
                            this._manager.setContainer(e)
                        }, this._handleScroll = () => {
                            this._scroll = (0, a.ensureNotNull)(this._scrollWrapRef).scrollTop
                        }, this._handleScrollOutsideEnd = () => {
                            clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                                this._handleMeasure({
                                    forceRecalcPosition: !0
                                })
                            }, 80)
                        }, this._handleScrollOutside = e => {
                            e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                                this._handleMeasure({
                                    forceRecalcPosition: !0
                                }), this._scrollRaf = null
                            })))
                        }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = h.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = u.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = h.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": i,
                        children: a,
                        minWidth: r,
                        theme: h = g,
                        className: d,
                        maxHeight: u,
                        onMouseOver: v,
                        onMouseOut: _,
                        onKeyDown: f,
                        onFocus: C,
                        onBlur: x
                    } = this.props, {
                        appearingMenuHeight: y,
                        appearingMenuWidth: S,
                        appearingPosition: E,
                        isMeasureValid: w
                    } = this.state;
                    return s.createElement(m.MenuContext.Provider, {
                        value: this
                    }, s.createElement(p.SubmenuHandler, null, s.createElement(c.SlotContext.Provider, {
                        value: this._manager
                    }, s.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": i,
                        className: o()(d, h.menuWrap, !w && h.isMeasuring),
                        style: {
                            height: y,
                            left: E && E.x,
                            minWidth: r,
                            position: "fixed",
                            top: E && E.y,
                            width: S
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: l.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: v,
                        onMouseOut: _,
                        onKeyDown: f,
                        onFocus: C,
                        onBlur: x
                    }, s.createElement("div", {
                        className: o()(h.scrollWrap, !this.props.noMomentumBasedScroll && h.momentumBased),
                        style: {
                            overflowY: void 0 !== y ? "scroll" : "auto",
                            maxHeight: u
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, s.createElement(b, {
                        className: h.menuBox
                    }, a)))), s.createElement(c.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function b(e) {
                const t = (0, a.ensureNotNull)((0, s.useContext)(p.SubmenuContext)),
                    n = s.useRef(null);
                return s.createElement("div", {
                    ref: n,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (s = e.target, null === (i = n.current) || void 0 === i ? void 0 : i.contains(s)))) return;
                        var s, i;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            _.contextType = p.SubmenuContext
        },
        94707: (e, t, n) => {
            "use strict";
            n.d(t, {
                Separator: () => a
            });
            var s = n(59496),
                i = n(97754),
                o = n(91626);

            function a(e) {
                return s.createElement("div", {
                    className: i(o.separator, e.className)
                })
            }
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => o,
                getRootOverlapManager: () => r
            });
            var s = n(88537);
            class i {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class o {
                constructor(e = document) {
                    this._storage = new i, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const s = this._document.createElement("div");
                    if (s.style.position = t.position, s.style.zIndex = this._index.toString(), s.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(s);
                        else if (t.index <= 0) this._container.insertBefore(s, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(s, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(s, this._container.firstChild) : this._container.appendChild(s);
                    return this._windows.set(e, s), ++this._index, s
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const a = new WeakMap;

            function r(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, s.ensureDefined)(a.get(t)); {
                    const t = new o(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return a.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        92063: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => c,
                PopupMenuItem: () => u
            });
            var s = n(59496),
                i = n(97754),
                o = n(70981),
                a = n(32133),
                r = n(417),
                l = n(23576);
            const c = l;

            function h(e) {
                const {
                    reference: t,
                    ...n
                } = e, i = { ...n,
                    ref: t
                };
                return s.createElement(e.href ? "a" : "div", i)
            }

            function d(e) {
                e.stopPropagation()
            }

            function u(e) {
                const {
                    id: t,
                    role: n,
                    "aria-selected": c,
                    className: u,
                    title: p,
                    labelRowClassName: m,
                    labelClassName: g,
                    shortcut: v,
                    forceShowShortcuts: _,
                    icon: b,
                    isActive: f,
                    isDisabled: C,
                    isHovered: x,
                    appearAsDisabled: y,
                    label: S,
                    link: E,
                    showToolboxOnHover: w,
                    target: M,
                    rel: R,
                    toolbox: T,
                    reference: k,
                    onMouseOut: N,
                    onMouseOver: D,
                    suppressToolboxClick: W = !0,
                    theme: A = l
                } = e, P = (0, r.filterDataProps)(e), F = (0, s.useRef)(null);
                return s.createElement(h, { ...P,
                    id: t,
                    role: n,
                    "aria-selected": c,
                    className: i(u, A.item, b && A.withIcon, {
                        [A.isActive]: f,
                        [A.isDisabled]: C || y,
                        [A.hovered]: x
                    }),
                    title: p,
                    href: E,
                    target: M,
                    rel: R,
                    reference: function(e) {
                        F.current = e, "function" == typeof k && k(e);
                        "object" == typeof k && (k.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: n,
                            onClick: s,
                            onClickArg: i,
                            trackEventObject: r
                        } = e;
                        if (C) return;
                        r && (0, a.trackEvent)(r.category, r.event, r.label);
                        s && s(i, t);
                        n || (0, o.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: n,
                            trackRightClick: s
                        } = e;
                        n && s && (0, a.trackEvent)(n.category, n.event, n.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: n,
                            trackMouseWheelClick: s
                        } = e;
                        if (1 === t.button && E && n) {
                            let e = n.label;
                            s && (e += "_mouseWheelClick"), (0, a.trackEvent)(n.category, n.event, e)
                        }
                    },
                    onMouseOver: D,
                    onMouseOut: N
                }, void 0 !== b && s.createElement("div", {
                    className: A.icon,
                    dangerouslySetInnerHTML: {
                        __html: b
                    }
                }), s.createElement("div", {
                    className: i(A.labelRow, m)
                }, s.createElement("div", {
                    className: i(A.label, g)
                }, S)), (void 0 !== v || _) && s.createElement("div", {
                    className: A.shortcut
                }, (B = v) && B.split("+").join(" + ")), void 0 !== T && s.createElement("div", {
                    onClick: W ? d : void 0,
                    className: i(A.toolbox, {
                        [A.showOnHover]: w
                    })
                }, T));
                var B
            }
        },
        17850: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenuSeparator: () => r
            });
            var s = n(59496),
                i = n(97754),
                o = n.n(i),
                a = n(524);

            function r(e) {
                const {
                    size: t = "normal",
                    className: n
                } = e;
                return s.createElement("div", {
                    className: o()(a.separator, "small" === t && a.small, "normal" === t && a.normal, "large" === t && a.large, n)
                })
            }
        },
        28466: (e, t, n) => {
            "use strict";
            n.d(t, {
                CloseDelegateContext: () => o
            });
            var s = n(59496),
                i = n(70981);
            const o = s.createContext(i.globalCloseDelegate)
        },
        44377: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenu: () => c
            });
            var s = n(59496),
                i = n(87995),
                o = n(8361),
                a = n(10618),
                r = n(28466),
                l = n(61174);

            function c(e) {
                const {
                    controller: t,
                    children: n,
                    isOpened: c,
                    closeOnClickOutside: h = !0,
                    doNotCloseOn: d,
                    onClickOutside: u,
                    onClose: p,
                    ...m
                } = e, g = (0, s.useContext)(r.CloseDelegateContext), v = (0, l.useOutsideEvent)({
                    handler: function(e) {
                        u && u(e);
                        if (!h) return;
                        if (d && e.target instanceof Node) {
                            const t = i.findDOMNode(d);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        p()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return c ? s.createElement(o.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, s.createElement("span", {
                    ref: v,
                    style: {
                        pointerEvents: "auto"
                    }
                }, s.createElement(a.Menu, { ...m,
                    onClose: p,
                    onScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    },
                    customCloseDelegate: g,
                    ref: t
                }, n))) : null
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => l,
                PortalContext: () => c
            });
            var s = n(59496),
                i = n(87995),
                o = n(16345),
                a = n(63212),
                r = n(53327);
            class l extends s.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, o.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", i.createPortal(s.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, a.getRootOverlapManager)() : this.context
                }
            }
            l.contextType = r.SlotContext;
            const c = s.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => i,
                SlotContext: () => o
            });
            var s = n(59496);
            class i extends s.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return s.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const o = s.createContext(null)
        },
        94488: (e, t, n) => {
            "use strict";
            n.d(t, {
                SubmenuContext: () => i,
                SubmenuHandler: () => o
            });
            var s = n(59496);
            const i = s.createContext(null);

            function o(e) {
                const [t, n] = (0, s.useState)(null), o = (0, s.useRef)(null), a = (0, s.useRef)(new Map);
                return (0, s.useEffect)(() => () => {
                    null !== o.current && clearTimeout(o.current)
                }, []), s.createElement(i.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== o.current && (clearTimeout(o.current), o.current = null);
                            null === t ? n(e) : o.current = setTimeout(() => {
                                o.current = null, n(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return a.current.set(e, t), () => {
                                a.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(a.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        68766: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_SLIDER_THEME: () => r,
                SliderItem: () => l,
                factory: () => c,
                SliderRow: () => h
            });
            var s = n(59496),
                i = n(97754),
                o = n(88537),
                a = n(37740);
            const r = a;

            function l(e) {
                const t = i(e.className, a.tab, {
                    [a.active]: e.isActive,
                    [a.disabled]: e.isDisabled,
                    [a.defaultCursor]: !!e.shouldUseDefaultCursor,
                    [a.noBorder]: !!e.noBorder
                });
                return s.createElement("div", {
                    className: t,
                    onClick: e.onClick,
                    ref: e.reference,
                    "data-type": "tab-item",
                    "data-value": e.value,
                    "data-name": "tab-item-" + e.value.toString().toLowerCase()
                }, e.children)
            }

            function c(e) {
                return class extends s.PureComponent {
                    constructor() {
                        super(...arguments), this.activeTab = {
                            current: null
                        }
                    }
                    componentDidUpdate() {
                        (0, o.ensureNotNull)(this._slider).style.transition = "transform 350ms", this._componentDidUpdate()
                    }
                    componentDidMount() {
                        this._componentDidUpdate()
                    }
                    render() {
                        const {
                            className: t
                        } = this.props, n = this._generateTabs();
                        return s.createElement("div", {
                            className: i(t, a.tabs),
                            "data-name": this.props["data-name"]
                        }, n, s.createElement(e, {
                            reference: e => {
                                this._slider = e
                            }
                        }))
                    }
                    _generateTabs() {
                        return this.activeTab.current = null, s.Children.map(this.props.children, e => {
                            const t = e,
                                n = Boolean(t.props.isActive),
                                i = {
                                    reference: e => {
                                        n && (this.activeTab.current = e), t.props.reference && t.props.reference(e)
                                    }
                                };
                            return s.cloneElement(t, i)
                        })
                    }
                    _componentDidUpdate() {
                        const e = (0, o.ensureNotNull)(this._slider).style;
                        if (this.activeTab.current) {
                            const t = this.activeTab.current.offsetWidth,
                                n = this.activeTab.current.offsetLeft;
                            e.transform = `translateX(${n}px)`, e.width = t + "px", e.opacity = "1"
                        } else e.opacity = "0"
                    }
                }
            }
            const h = c((function(e) {
                return s.createElement("div", {
                    className: a.slider,
                    ref: e.reference
                })
            }))
        },
        15783: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetCaret: () => l
            });
            var s = n(59496),
                i = n(97754),
                o = n(72571),
                a = n(40367),
                r = n(21538);

            function l(e) {
                const {
                    dropped: t,
                    className: n
                } = e;
                return s.createElement(o.Icon, {
                    className: i(n, a.icon, {
                        [a.dropped]: t
                    }),
                    icon: r
                })
            }
        },
        93173: (e, t, n) => {
            "use strict";

            function s(e, t, n = {}) {
                const s = Object.assign({}, t);
                for (const i of Object.keys(t)) {
                    const o = n[i] || i;
                    o in e && (s[i] = [e[o], t[i]].join(" "))
                }
                return s
            }

            function i(e, t, n = {}) {
                return Object.assign({}, e, s(e, t, n))
            }
            n.d(t, {
                weakComposeClasses: () => s,
                mergeThemes: () => i
            })
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        58991: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M8 5l3.5 3.5L8 12"/></svg>'
        },
        46930: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"><path fill="none" stroke="currentColor" d="M11 1.5h3.5a2 2 0 0 1 2 2V7m0 5v2.5a2 2 0 0 1-2 2H11m-4 0H3.5a2 2 0 0 1-2-2V11m0-4V3.5a2 2 0 0 1 2-2H7"/></svg>'
        },
        90795: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"><g fill="none" stroke="currentColor"><circle cx="3.5" cy="3.5" r="2"/><circle cx="10.5" cy="10.5" r="2"/><path stroke-linecap="square" d="M9.5 1.5l-5 11"/></g></svg>'
        },
        53030: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18"><path fill="currentColor" d="M11 2v2.5A2.5 2.5 0 0 0 13.5 7H16V6h-2.5A1.5 1.5 0 0 1 12 4.5V2h-1zm2.5 9a2.5 2.5 0 0 0-2.5 2.5V16h1v-2.5c0-.83.67-1.5 1.5-1.5H16v-1h-2.5zm-9 1H2v-1h2.5A2.5 2.5 0 0 1 7 13.5V16H6v-2.5c0-.83-.67-1.5-1.5-1.5zM7 4.5V2H6v2.5C6 5.33 5.33 6 4.5 6H2v1h2.5A2.5 2.5 0 0 0 7 4.5z"/></svg>'
        },
        711: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" stroke-linecap="round" stroke-width="1.5" d="M7 15l5 5L23 9"/></svg>'
        },
        45355: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9.7 9l4.65-4.65-.7-.7L9 8.29 4.35 3.65l-.7.7L8.29 9l-4.64 4.65.7.7L9 9.71l4.65 4.64.7-.7L9.71 9z"/></svg>'
        },
        9856: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 13v-2.5m8.5 11h6.5a2 2 0 0 0 2-2v-9m-17 0v-2c0-1.1.9-2 2-2h13a2 2 0 0 1 2 2v2m-17 0h17"/><path fill="currentColor" d="M10 4h1v4h-1V4zM17 4h1v4h-1V4z"/><path stroke="currentColor" d="M4 18.5h7.5m0 0L8 22m3.5-3.5L8 15"/></svg>'
        },
        61996: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M1.5 8V6.5m7.5 9h5.5a2 2 0 0 0 2-2v-7m-15 0v-2c0-1.1.9-2 2-2h11a2 2 0 0 1 2 2v2m-15 0h15"/><path fill="currentColor" d="M5 1h1v3H5V1zM12 1h1v3h-1V1z"/><path stroke="currentColor" d="M0 12.5h7.5m0 0L4 16m3.5-3.5L4 9"/></svg>'
        }
    }
]);
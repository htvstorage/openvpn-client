(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [3596], {
        1212: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                ChartPropertyDefinitionsViewModel: () => ci
            });
            var n = i(88537),
                r = i(25177),
                o = i(82527),
                a = i(1962),
                s = i(33080),
                l = i(94489),
                c = i.n(l),
                p = i(1272),
                d = i(38658),
                h = i(87067),
                g = i(53226),
                y = i(22332),
                u = i(83092),
                b = i(56046),
                v = i(18517),
                P = i(76337),
                f = i(15706),
                m = i(55563);
            const w = new v.TranslatedString("change symbol description visibility", (0, r.t)("change symbol description visibility")),
                S = new v.TranslatedString("change symbol legend format", (0, r.t)("change symbol legend format")),
                D = new v.TranslatedString("change open market status visibility", (0, r.t)("change open market status visibility")),
                T = new v.TranslatedString("change OHLC values visibility", (0, r.t)("change OHLC values visibility")),
                k = new v.TranslatedString("change bar change visibility", (0, r.t)("change bar change visibility")),
                _ = new v.TranslatedString("change indicator arguments visibility", (0, r.t)("change indicator arguments visibility")),
                C = new v.TranslatedString("change indicator titles visibility", (0, r.t)("change indicator titles visibility")),
                L = new v.TranslatedString("change indicator values visibility", (0, r.t)("change indicator values visibility")),
                V = new v.TranslatedString("change legend background visibility", (0, r.t)("change legend background visibility")),
                x = new v.TranslatedString("change legend background transparency", (0, r.t)("change legend background transparency")),
                O = new v.TranslatedString("change volume values visibility", (0, r.t)("change volume values visibility")),
                M = (0, r.t)("Symbol"),
                z = (0, r.t)("OHLC values"),
                E = (0, r.t)("Bar change values"),
                G = (0, r.t)("Volume"),
                A = (0, r.t)("Indicator titles"),
                R = (0, r.t)("Indicator arguments"),
                W = (0, r.t)("Indicator values"),
                H = (0, r.t)("Background"),
                B = (0, r.t)("Open market status");
            var F = i(9297),
                N = i(12865),
                j = i(29310),
                I = i(88331),
                U = i(68034);
            const q = o.enabled("show_average_close_price_line_and_label"),
                J = new v.TranslatedString("change symbol labels visibility", (0, r.t)("change symbol labels visibility")),
                K = new v.TranslatedString("change symbol last value visibility", (0, r.t)("change symbol last value visibility")),
                Q = new v.TranslatedString("change symbol last value mode", (0, r.t)("change symbol last value mode")),
                X = new v.TranslatedString("change symbol previous close value visibility", (0, r.t)("change symbol previous close value visibility")),
                Y = new v.TranslatedString("change bid and ask labels visibility", (0, r.t)("change bid and ask labels visibility")),
                Z = (new v.TranslatedString("change pre/post market price label visibility", (0, r.t)("change pre/post market price label visibility")), new v.TranslatedString("change high and low price labels visibility", (0, r.t)("change high and low price labels visibility"))),
                $ = new v.TranslatedString("change average close price label visibility", (0, r.t)("change average close price label visibility")),
                ee = (new v.TranslatedString("change indicators and financials name labels visibility", (0, r.t)("change indicators and financials name labels visibility")),
                    new v.TranslatedString("change indicators name labels visibility", (0, r.t)("change indicators name labels visibility"))),
                te = (new v.TranslatedString("change indicators and financials value labels visibility", (0, r.t)("change indicators and financials value labels visibility")), new v.TranslatedString("change indicators value labels visibility", (0, r.t)("change indicators value labels visibility"))),
                ie = new v.TranslatedString("change no overlapping labels", (0, r.t)("change no overlapping labels")),
                ne = new v.TranslatedString("change countdown to bar close visibility", (0, r.t)("change countdown to bar close visibility")),
                re = new v.TranslatedString("change currency label visibility", (0, r.t)("change currency label visibility")),
                oe = new v.TranslatedString("change unit label visibility", (0, r.t)("change unit label visibility")),
                ae = new v.TranslatedString("change currency and unit labels visibility", (0, r.t)("change currency and unit labels visibility")),
                se = new v.TranslatedString("change plus button visibility", (0, r.t)("change plus button visibility")),
                le = new v.TranslatedString("toggle lock scale", (0, r.t)("toggle lock scale")),
                ce = new v.TranslatedString("change price to bar ratio", (0, r.t)("change price to bar ratio")),
                pe = new v.TranslatedString("change date format", (0, r.t)("change date format")),
                de = (0, r.t)("Symbol name label"),
                he = (0, r.t)("Symbol last price label"),
                ge = (0, r.t)("Symbol previous day close price label"),
                ye = ((0, r.t)("Indicators and financials name labels"), (0, r.t)("Indicators name labels")),
                ue = ((0, r.t)("Indicators and financials value labels"), (0, r.t)("Indicators value labels")),
                be = (0, r.t)("Bid and ask labels"),
                ve = ((0, r.t)("Pre/post market price label"), (0, r.t)("Average close price label")),
                Pe = (0, r.t)("Countdown to bar close"),
                fe = (0, r.t)("Currency"),
                me = (0, r.t)("Unit"),
                we = (0, r.t)("Currency and Unit"),
                Se = (0, r.t)("Plus button"),
                De = (0, r.t)("Scales placement"),
                Te = (0, r.t)("Date format"),
                ke = (0, r.t)("Lock price to bar ratio"),
                _e = (0, r.t)("No overlapping labels"),
                Ce = [{
                    value: N.PriceAxisLastValueMode.LastPriceAndPercentageValue,
                    title: (0, r.t)("Price and percentage value")
                }, {
                    value: N.PriceAxisLastValueMode.LastValueAccordingToScale,
                    title: (0, r.t)("Value according to scale")
                }];
            const Le = new v.TranslatedString("change chart background color", (0, r.t)("change chart background color")),
                Ve = new v.TranslatedString("change chart background type", (0, r.t)("change chart background type")),
                xe = new v.TranslatedString("change vert grid lines color", (0, r.t)("change vert grid lines color")),
                Oe = new v.TranslatedString("change vert grid lines style", (0, r.t)("change vert grid lines style")),
                Me = new v.TranslatedString("change horz grid lines color", (0, r.t)("change horz grid lines color")),
                ze = new v.TranslatedString("change horz grid lines style", (0, r.t)("change horz grid lines style")),
                Ee = new v.TranslatedString("change sessions breaks visibility", (0, r.t)("change sessions breaks visibility")),
                Ge = new v.TranslatedString("change sessions breaks color", (0, r.t)("change sessions breaks color")),
                Ae = new v.TranslatedString("change sessions breaks width", (0,
                    r.t)("change sessions breaks width")),
                Re = new v.TranslatedString("change sessions breaks style", (0, r.t)("change sessions breaks style")),
                We = new v.TranslatedString("change scales text color", (0, r.t)("change scales text color")),
                He = new v.TranslatedString("change scales font size", (0, r.t)("change scales font size")),
                Be = new v.TranslatedString("change scales lines color", (0, r.t)("change scales lines color")),
                Fe = new v.TranslatedString("change pane separators color", (0, r.t)("change pane separators color")),
                Ne = new v.TranslatedString("change crosshair color", (0, r.t)("change crosshair color")),
                je = new v.TranslatedString("change crosshair width", (0, r.t)("change crosshair width")),
                Ie = new v.TranslatedString("change crosshair style", (0, r.t)("change crosshair style")),
                Ue = new v.TranslatedString("change symbol watermark visibility", (0, r.t)("change symbol watermark visibility")),
                qe = new v.TranslatedString("change symbol watermark color", (0, r.t)("change symbol watermark color")),
                Je = new v.TranslatedString("change navigation buttons visibility", (0, r.t)("change navigation buttons visibility")),
                Ke = new v.TranslatedString("change pane buttons visibility", (0, r.t)("change pane buttons visibility")),
                Qe = new v.TranslatedString("change top margin", (0, r.t)("change top margin")),
                Xe = new v.TranslatedString("change bottom margin", (0, r.t)("change bottom margin")),
                Ye = new v.TranslatedString("change right margin", (0, r.t)("change right margin")),
                Ze = (0, r.t)("Background"),
                $e = (0, r.t)("Vert grid lines"),
                et = (0, r.t)("Horz grid lines"),
                tt = (0, r.t)("Session breaks"),
                it = (0, r.t)("Scales text"),
                nt = (0, r.t)("Scales lines"),
                rt = (0, r.t)("Pane separators"),
                ot = (0, r.t)("Crosshair"),
                at = (0, r.t)("Watermark"),
                st = (0, r.t)("Top margin"),
                lt = (0, r.t)("Navigation buttons"),
                ct = (0, r.t)("Pane buttons"),
                pt = (0, r.t)("Bottom margin"),
                dt = (0, r.t)("Right margin"),
                ht = (0, r.t)("bars", {
                    context: "unit"
                });
            var gt = i(831),
                yt = i(21577),
                ut = i(52647);
            const bt = new v.TranslatedString("change buy/sell buttons visibility", (0, r.t)("change buy/sell buttons visibility")),
                vt = (0, r.t)("Buy/sell buttons");
            new v.TranslatedString("change brackets PL visibility", (0, r.t)("change brackets PL visibility")), new v.TranslatedString("change brackets PL display mode", (0, r.t)("change brackets PL display mode"));
            const Pt = new v.TranslatedString("change positions PL visibility", (0, r.t)("change positions PL visibility")),
                ft = new v.TranslatedString("change positions PL display mode", (0, r.t)("change positions PL display mode")),
                mt = new v.TranslatedString("change reverse button visibility", (0, r.t)("change reverse button visibility")),
                wt = new v.TranslatedString("change order confirmation state", (0, r.t)("change order confirmation state")),
                St = new v.TranslatedString("change play sound on order execution", (0, r.t)("change play sound on order execution")),
                Dt = new v.TranslatedString("change notifications state", (0, r.t)("change notifications state")),
                Tt = new v.TranslatedString("change positions visibility", (0, r.t)("change positions visibility")),
                kt = new v.TranslatedString("change orders visibility", (0,
                    r.t)("change orders visibility")),
                _t = new v.TranslatedString("change executions visibility", (0, r.t)("change executions visibility")),
                Ct = new v.TranslatedString("change executions labels visibility", (0, r.t)("change executions labels visibility")),
                Lt = new v.TranslatedString("change extend lines left", (0, r.t)("change extend lines left")),
                Vt = new v.TranslatedString("change position trading objects on chart", (0, r.t)("change position trading objects on chart")),
                xt = (0, r.t)("Positions"),
                Ot = (0, r.t)("Reverse button"),
                Mt = (0, r.t)("Orders"),
                zt = ((0, r.t)("Brackets Profit & Loss in"), (0, r.t)("Extended price line for positions & orders")),
                Et = (0, r.t)("Executions"),
                Gt = (0, r.t)("Executions labels"),
                At = (0, r.t)("Instant orders placement"),
                Rt = (0, r.t)("Rejection notifications only"),
                Wt = (0, r.t)("Sound notifications for executions"),
                Ht = (0, r.t)("Profit & loss in"),
                Bt = (0, r.t)("Orders & positions alignment"),
                Ft = (0, r.t)("Left"),
                Nt = (0, r.t)("Center"),
                jt = (0, r.t)("Right"),
                It = (0, r.t)("general"),
                Ut = (0, r.t)("appearance"),
                qt = [{
                    value: a.TradingSourcesHorizontalAlignment.Left,
                    title: Ft
                }, {
                    value: a.TradingSourcesHorizontalAlignment.Center,
                    title: Nt
                }, {
                    value: a.TradingSourcesHorizontalAlignment.Right,
                    title: jt
                }];

            function Jt(e, t, i, n) {
                const r = t.positionPL.childs(),
                    a = (0, p.createOptionsPropertyDefinition)({
                        checked: (0, p.convertToDefinitionProperty)(e, r.visibility, Pt),
                        option: (0, p.convertToDefinitionProperty)(e, r.display, ft)
                    }, {
                        id: "positionPLDisplay",
                        title: Ht,
                        options: n
                    }),
                    s = (0, p.createCheckablePropertyDefinition)({
                        checked: (0, p.convertToDefinitionProperty)(e, t.showReverse, mt)
                    }, {
                        id: "reverseButton",
                        title: Ot
                    }),
                    l = [],
                    d = function(e, t) {
                        if (null === t || !o.enabled("buy_sell_buttons")) return null;
                        const i = (0, P.createWVFromGetterAndSubscription)(e.model().isInReplay.bind(e.model()), e.model().onInReplayStateChanged());
                        return (0, p.createCheckablePropertyDefinition)({
                            disabled: (0, p.convertFromReadonlyWVToDefinitionProperty)(i),
                            checked: (0, p.convertFromWVToDefinitionProperty)(e, t.showSellBuyButtons, bt)
                        }, {
                            id: "tradingSellBuyPanel",
                            title: vt
                        })
                    }(e, i),
                    h = (0, p.createCheckablePropertyDefinition)({
                        checked: (0, p.convertFromWVToDefinitionProperty)(e, i.noConfirmEnabled, wt)
                    }, {
                        id: "tradingConfirmEnabled",
                        title: At
                    }),
                    g = (0, p.createCheckablePropertyDefinition)({
                        checked: (0, p.convertFromWVToDefinitionProperty)(e, i.orderExecutedSoundParams.enabled, St)
                    }, {
                        id: "tradingSoundEnabled",
                        title: Wt
                    }),
                    y = (0, p.createCheckablePropertyDefinition)({
                        checked: (0, p.convertFromWVToDefinitionProperty)(e, i.showOnlyRejectionNotifications, Dt)
                    }, {
                        id: "tradingRejectionNotifications",
                        title: Rt
                    });
                null !== d && l.push(d), l.push(h, g, y);
                const u = (0, p.createPropertyDefinitionsGeneralGroup)(l, "generalVisibilityGroup", It),
                    b = [],
                    v = (0, p.createCheckableSetPropertyDefinition)({
                        checked: (0, p.convertToDefinitionProperty)(e, t.showPositions, Tt)
                    }, {
                        id: "tradingPositions",
                        title: xt
                    }, [a, s]);
                b.push(v);
                const f = (0, p.createCheckablePropertyDefinition)({
                    checked: (0, p.convertToDefinitionProperty)(e, t.showOrders, kt)
                }, {
                    id: "tradingOrders",
                    title: Mt
                });
                b.push(f);
                (0, p.createCheckablePropertyDefinition)({
                    checked: (0, p.convertToDefinitionProperty)(e, t.showExecutionsLabels, Ct)
                }, {
                    id: "tradingExecutionsLables",
                    title: Gt
                });
                const m = (0, p.createCheckableSetPropertyDefinition)({
                    checked: (0, p.convertToDefinitionProperty)(e, t.showExecutions, _t)
                }, {
                    id: "tradingExecutions",
                    title: Et
                }, []);
                b.push(m), b.push((0, p.createCheckablePropertyDefinition)({
                    checked: (0, p.convertToDefinitionProperty)(e, t.extendLeft, Lt)
                }, {
                    id: "extendLeftTradingLine",
                    title: zt
                }), (0, p.createOptionsPropertyDefinition)({
                    option: (0, p.convertToDefinitionProperty)(e, t.horizontalAlignment, Vt)
                }, {
                    id: "positionPLDisplay",
                    title: Bt,
                    options: new(c())(qt)
                }));
                return {
                    definitions: [u, (0, p.createPropertyDefinitionsGeneralGroup)(b, "appearanceVisibilityGroup", Ut)]
                }
            }
            var Kt = i(24818),
                Qt = i(3960);
            const Xt = {
                    symbol: i(90682),
                    legend: i(64864),
                    scales: i(89380),
                    appearance: i(4537),
                    events: i(8047),
                    trading: i(70609)
                },
                Yt = (0, r.t)("Symbol"),
                Zt = (0, r.t)("Status line"),
                $t = (0, r.t)("Scales"),
                ei = (0, r.t)("Appearance"),
                ti = ((0, r.t)("Events"), (0, r.t)("Trading")),
                ii = (0, r.t)("money"),
                ni = (0, r.t)("pips"),
                ri = (0, r.t)("ticks"),
                oi = o.enabled("chart_property_page_trading");
            let ai = null;

            function si() {
                const e = new Date(Date.UTC(1997, 8, 29));
                return gt.availableDateFormats.map(t => ({
                    value: t,
                    title: new ut.DateFormatter(t).format(e)
                }))
            }
            oi && (ai = (0, s.tradingService)());
            const li = [{
                id: "symbol-text-source-description",
                value: "description",
                title: (0, r.t)("Description")
            }, {
                id: "symbol-text-source-ticker",
                value: "ticker",
                title: (0, r.t)("Ticker")
            }, {
                id: "symbol-text-source-ticker-and-description",
                value: "ticker-and-description",
                title: (0, r.t)("Ticker and description")
            }];
            class ci {
                constructor(e, t, i) {
                    this._propertyPages = null, this._maxRightOffsetPropertyObject = null, this._profitLossOptions = null, this._pipValueTypeSpawn = null, this._isDestroyed = !1, this._undoModel = e, this._model = this._undoModel.model(), this._series = this._model.mainSeries(), this._chartWidgetProperties = t, this._options = i, this._seriesPropertyDefinitionViewModel = this._createSeriesViewModel(), this._legendPropertyPage = this._createLegendPropertyPage(), this._scalesPropertyPage = this._createScalesPropertyPage(), this._appearancePropertyPage = this._createAppearancePropertyPage(), this._tradingPropertyPage = this._createTradingPropertyPage(), this._eventsPropertyPage = this._createEventsPropertyPage(), this._series.onStyleChanged().subscribe(this, this._updateDefinitions), this._series.priceScaleChanged().subscribe(this, this._updateDefinitions)
                }
                destroy() {
                    var e;
                    null !== this._propertyPages && this._propertyPages.filter((e, t) => 0 !== t).forEach(e => {
                        (0, p.destroyDefinitions)(e.definitions.value())
                    }), this._seriesPropertyDefinitionViewModel.destroy(), null === (e = this._pipValueTypeSpawn) || void 0 === e || e.destroy(), this._series.onStyleChanged().unsubscribe(this, this._updateDefinitions), this._series.priceScaleChanged().unsubscribe(this, this._updateDefinitions);
                    (0, n.ensureNotNull)(this._model.timeScale()).maxRightOffsetChanged().unsubscribeAll(this), this._isDestroyed = !0
                }
                propertyPages() {
                    return null === this._propertyPages ? this._seriesPropertyDefinitionViewModel.propertyPages().then(e => {
                        if (this._isDestroyed) throw new Error("ChartPropertyDefinitionsViewModel already destroyed");
                        return null === this._propertyPages && (this._propertyPages = [...e], this._propertyPages.push(this._legendPropertyPage, this._scalesPropertyPage, this._appearancePropertyPage), null !== this._tradingPropertyPage && this._propertyPages.push(this._tradingPropertyPage), null !== this._eventsPropertyPage && this._propertyPages.push(this._eventsPropertyPage)), this._propertyPages
                    }) : Promise.resolve(this._propertyPages)
                }
                _updatePlDisplayOptions() {
                    const e = (0, n.ensureNotNull)(this._pipValueTypeSpawn).value();
                    (0, n.ensureNotNull)(this._profitLossOptions).setValue(function(e) {
                        return oi ? [{
                            value: a.PlDisplay.Money,
                            title: ii
                        }, {
                            value: a.PlDisplay.Pips,
                            title: e === Kt.PipValueType.Pips ? ni : ri
                        }, {
                            value: a.PlDisplay.Percentage,
                            title: "%"
                        }] : []
                    }(e))
                }
                _updateDefinitions() {
                    (0, p.destroyDefinitions)(this._scalesPropertyPage.definitions.value());
                    const e = this._createScalesDefinitions();
                    this._scalesPropertyPage.definitions.setValue(e.definitions)
                }
                _createSeriesViewModel() {
                    const e = {
                        property: this._model.properties().childs().timezone,
                        values: Qt.availableTimezones.map(e => ({
                            value: e.id,
                            title: e.title
                        }))
                    };
                    return new u.SeriesPropertyDefinitionsViewModel(this._series, this._undoModel, "symbol", Yt, Xt.symbol, e)
                }
                _createLegendPropertyPage() {
                    const e = this._chartWidgetProperties.childs().paneProperties.childs().legendProperties.childs(),
                        t = {
                            property: this._series.properties().childs().statusViewStyle.childs().symbolTextSource,
                            values: li
                        },
                        i = function(e, t, i, n, r) {
                            const o = [],
                                a = [],
                                s = (0, p.createOptionsPropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, t.showSeriesTitle, w),
                                    option: (0, p.convertToDefinitionProperty)(e, i.property, S)
                                }, {
                                    id: "symbolTextSource",
                                    title: M,
                                    options: new(c())(i.values)
                                });
                            if (a.push(s), null !== n) {
                                const t = (0, m.combineWithFilteredUpdate)(e => "market" === e, e => null !== e, e.mainSeries().marketStatusModel().status()),
                                    i = (0, p.createCheckablePropertyDefinition)({
                                        checked: (0, p.convertToDefinitionProperty)(e, n, D),
                                        visible: (0, p.convertFromReadonlyWVToDefinitionProperty)(t)
                                    }, {
                                        id: "showOpenMarketStatus",
                                        title: B
                                    });
                                a.push(i)
                            }
                            const l = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, t.showSeriesOHLC, T)
                            }, {
                                id: "ohlcTitle",
                                title: z
                            });
                            a.push(l);
                            const d = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, t.showBarChange, k)
                            }, {
                                id: "barChange",
                                title: E
                            });
                            a.push(d), a.push((0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, t.showVolume, O)
                            }, {
                                id: "barVolume",
                                title: G
                            })), o.push((0, p.createPropertyDefinitionsGeneralGroup)(a, "seriesLegendVisibilityGroup"));
                            const h = [],
                                g = (0, p.createCheckablePropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, t.showStudyArguments, _)
                                }, {
                                    id: "studyArguments",
                                    title: R
                                }),
                                y = (0, p.createCheckableSetPropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, t.showStudyTitles, C)
                                }, {
                                    id: "studyTitles",
                                    title: A
                                }, [g]),
                                u = (0, p.createCheckablePropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, t.showStudyValues, L)
                                }, {
                                    id: "studyValues",
                                    title: W
                                }),
                                b = (0, P.createWVFromGetterAndSubscription)(() => e.model().priceDataSources().some(e => !(0,
                                    f.isSymbolSource)(e) && e.showInObjectTree()), e.model().dataSourceCollectionChanged());
                            h.push(y, u), o.push((0, p.createPropertyDefinitionsGeneralGroup)(h, "studiesLegendVisibilityGroup", void 0, b));
                            const v = [],
                                F = (0, p.createTransparencyPropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, t.showBackground, V),
                                    transparency: (0, p.convertToDefinitionProperty)(e, t.backgroundTransparency, x)
                                }, {
                                    id: "legendBgTransparency",
                                    title: H
                                });
                            return v.push(F), o.push((0, p.createPropertyDefinitionsGeneralGroup)(v, "generalLegendGroup")), {
                                definitions: o
                            }
                        }(this._undoModel, e, t, this._options.marketStatusWidgetEnabled ? b.showMarketOpenStatusProperty : null);
                    return (0, d.createPropertyPage)(i, "legend", Zt, Xt.legend)
                }
                _createScalesPropertyPage() {
                    const e = this._createScalesDefinitions();
                    return (0, d.createPropertyPage)(e, "scales", $t, Xt.scales)
                }
                _createScalesDefinitions() {
                    const e = this._chartWidgetProperties.childs().scalesProperties.childs(),
                        t = {
                            property: this._model.properties().childs().priceScaleSelectionStrategyName,
                            values: (0, y.allPriceScaleSelectionStrategyInfo)().map(e => ({
                                value: e.name,
                                title: e.title
                            }))
                        },
                        i = {
                            property: yt.dateFormatProperty,
                            values: si()
                        },
                        n = this._model.mainSeriesScaleRatioProperty();
                    return function(e, t, i, n) {
                        const r = n.seriesPriceScale.properties().childs(),
                            a = [],
                            s = [];
                        if (n.seriesHasClosePrice) {
                            const t = (0, p.createCheckablePropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, i.showSymbolLabels, J)
                                }, {
                                    id: "symbolNameLabel",
                                    title: de
                                }),
                                n = (0, p.createOptionsPropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, i.showSeriesLastValue, K),
                                    option: (0, p.convertToDefinitionProperty)(e, i.seriesLastValueMode, Q)
                                }, {
                                    id: "symbolLastValueLabel",
                                    title: he,
                                    options: new(c())(Ce)
                                });
                            s.push(t, n); {
                                const t = (0, P.combineProperty)(e => !e, e.mainSeries().isDWMProperty()),
                                    n = (0, p.createCheckablePropertyDefinition)({
                                        checked: (0, p.convertToDefinitionProperty)(e, i.showSeriesPrevCloseValue, X),
                                        visible: (0, F.makeProxyDefinitionPropertyDestroyable)(t)
                                    }, {
                                        id: "symbolPrevCloseValue",
                                        title: ge
                                    });
                                s.push(n)
                            }
                        }
                        if (e.model().hasCustomSource("bidask")) {
                            const t = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, i.showBidAskLabels, Y)
                            }, {
                                id: "bidAskLabels",
                                title: be
                            });
                            s.push(t)
                        }
                        const l = t.highLowAvgPrice.childs(),
                            d = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, l.highLowPriceLabelsVisible, Z)
                            }, {
                                id: "highLowPriceLabels",
                                title: "High and low price labels"
                            });
                        if (s.push(d), q) {
                            const t = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, l.averageClosePriceLabelVisible, $)
                            }, {
                                id: "averageClosePriceLabel",
                                title: ve
                            });
                            s.push(t)
                        }
                        const h = (0, P.createWVFromGetterAndSubscription)(() => e.model().priceDataSources().some(e => !(0, f.isSymbolSource)(e) && e.showInObjectTree()), e.model().dataSourceCollectionChanged()); {
                            const t = (0, p.createCheckablePropertyDefinition)({
                                visible: (0, p.convertFromReadonlyWVToDefinitionProperty)(h),
                                checked: (0, p.convertToDefinitionProperty)(e, i.showStudyPlotLabels, ee)
                            }, {
                                id: "studyNameLabel",
                                title: ye
                            });
                            s.push(t)
                        }
                        const g = (0,
                            P.createWVFromGetterAndSubscription)(() => e.model().priceDataSources().some(e => !(0, f.isSymbolSource)(e) && e.showInObjectTree()), e.model().dataSourceCollectionChanged()); {
                            const t = (0, p.createCheckablePropertyDefinition)({
                                visible: (0, p.convertFromReadonlyWVToDefinitionProperty)(g),
                                checked: (0, p.convertToDefinitionProperty)(e, i.showStudyLastValue, te)
                            }, {
                                id: "studyLastValueLabel",
                                title: ue
                            });
                            s.push(t)
                        }
                        const y = (0, p.createCheckablePropertyDefinition)({
                            checked: (0, p.convertToDefinitionProperty)(e, r.alignLabels, ie)
                        }, {
                            id: "noOverlappingLabels",
                            title: _e
                        });
                        if (s.push(y), n.countdownEnabled) {
                            const i = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, t.showCountdown, ne)
                            }, {
                                id: "countdown",
                                title: Pe
                            });
                            s.push(i)
                        }
                        if (e.crossHairSource().isMenuEnabled()) {
                            const t = (0, p.createCheckablePropertyDefinition)({
                                checked: (0, p.convertToDefinitionProperty)(e, I.addPlusButtonProperty, se)
                            }, {
                                id: "addPlusButton",
                                title: Se
                            });
                            s.push(t)
                        }
                        if (n.currencyConversionEnabled || n.unitConversionEnabled) {
                            const t = n.currencyConversionEnabled && n.unitConversionEnabled ? we : n.currencyConversionEnabled ? fe : me,
                                i = n.currencyConversionEnabled && n.unitConversionEnabled ? ae : n.currencyConversionEnabled ? re : oe,
                                r = (0, p.createOptionsPropertyDefinition)({
                                    option: (0, p.convertToDefinitionProperty)(e, (0, U.currencyUnitVisibilityProperty)(), i)
                                }, {
                                    id: "scalesCurrencyUnit",
                                    title: t,
                                    options: new(c())((0, U.currencyUnitVisibilityOptions)())
                                });
                            s.push(r)
                        }
                        a.push((0, p.createPropertyDefinitionsGeneralGroup)(s, "generalScalesLabelsGroup"));
                        const u = (0, p.createNumberPropertyDefinition)({
                                checked: (0, p.getLockPriceScaleDefinitionProperty)(e, r.lockScale, n.seriesPriceScale, le),
                                value: (0, p.getScaleRatioDefinitionProperty)(e, n.mainSeriesScaleRatioProperty, ce, [(0, j.limitedPrecision)(7), e => e])
                            }, {
                                id: "lockScale",
                                title: ke,
                                min: new(c())(n.mainSeriesScaleRatioProperty.getMinValue()),
                                max: new(c())(n.mainSeriesScaleRatioProperty.getMaxValue()),
                                step: new(c())(n.mainSeriesScaleRatioProperty.getStepChangeValue())
                            }),
                            b = (0, p.createOptionsPropertyDefinition)({
                                option: (0, p.getPriceScaleSelectionStrategyDefinitionProperty)(e, n.scalesPlacementPropertyObj.property)
                            }, {
                                id: "scalesPlacement",
                                title: De,
                                options: new(c())(n.scalesPlacementPropertyObj.values)
                            });
                        if (a.push(u, b), o.enabled("scales_date_format")) {
                            const t = (0, p.createOptionsPropertyDefinition)({
                                option: (0, p.convertToDefinitionProperty)(e, n.dateFormatPropertyObj.property, pe)
                            }, {
                                id: "dateFormat",
                                title: Te,
                                options: new(c())(n.dateFormatPropertyObj.values)
                            });
                            a.push(t)
                        }
                        return {
                            definitions: a
                        }
                    }(this._undoModel, this._series.properties().childs(), e, {
                        disableSeriesPrevCloseValueProperty: this._series.isDWMProperty(),
                        seriesHasClosePrice: this._series.hasClosePrice(),
                        seriesPriceScale: this._series.priceScale(),
                        mainSeriesScaleRatioProperty: n,
                        scalesPlacementPropertyObj: t,
                        dateFormatPropertyObj: i,
                        currencyConversionEnabled: this._options.currencyConversionEnabled,
                        unitConversionEnabled: this._options.unitConversionEnabled,
                        countdownEnabled: this._options.countdownEnabled
                    })
                }
                _createMaxOffsetPropertyObject() {
                    const e = (0, n.ensureNotNull)(this._model.timeScale()),
                        t = new(c())(Math.floor(e.maxRightOffset()));
                    e.maxRightOffsetChanged().subscribe(this, e => {
                        t.setValue(Math.floor(e))
                    }), this._maxRightOffsetPropertyObject = {
                        value: e.defaultRightOffset(),
                        min: new(c())(0),
                        max: t
                    }
                }
                _createAppearancePropertyPage() {
                    const e = this._chartWidgetProperties.childs(),
                        t = e.paneProperties.childs(),
                        i = e.scalesProperties.childs(),
                        r = this._model.watermarkSource();
                    let a = null;
                    null !== r && (a = r.properties().childs());
                    const s = {
                            property: h.property(),
                            values: h.availableValues()
                        },
                        l = {
                            property: g.property(),
                            values: g.availableValues()
                        },
                        y = this._model.sessions().properties().childs().graphics.childs().vertlines.childs().sessBreaks.childs();
                    null === this._maxRightOffsetPropertyObject && this._createMaxOffsetPropertyObject();
                    const u = (0, n.ensureNotNull)(this._maxRightOffsetPropertyObject),
                        b = function(e, t, i, n, r, a, s, l, d) {
                            const h = [],
                                g = (0, p.createColorPropertyDefinition)({
                                    color: (0, p.getColorDefinitionProperty)(e, t.background, null, Le),
                                    gradientColor1: (0, p.getColorDefinitionProperty)(e, t.backgroundGradientStartColor, null, Le),
                                    gradientColor2: (0, p.getColorDefinitionProperty)(e, t.backgroundGradientEndColor, null, Le),
                                    type: (0, p.convertToDefinitionProperty)(e, t.backgroundType, Ve)
                                }, {
                                    id: "chartBackground",
                                    title: Ze,
                                    noAlpha: !0
                                }),
                                y = t.vertGridProperties.childs(),
                                u = (0, p.createLinePropertyDefinition)({
                                    color: (0, p.getColorDefinitionProperty)(e, y.color, null, xe),
                                    style: (0, p.convertToDefinitionProperty)(e, y.style, Oe)
                                }, {
                                    id: "vertGridLine",
                                    title: $e
                                }),
                                b = t.horzGridProperties.childs(),
                                v = (0, p.createLinePropertyDefinition)({
                                    color: (0, p.getColorDefinitionProperty)(e, b.color, null, Me),
                                    style: (0, p.convertToDefinitionProperty)(e, b.style, ze)
                                }, {
                                    id: "horizGridLine",
                                    title: et
                                }),
                                f = (0, P.combineProperty)(e => !e, e.mainSeries().isDWMProperty()),
                                m = (0, p.createLinePropertyDefinition)({
                                    visible: (0, F.makeProxyDefinitionPropertyDestroyable)(f),
                                    checked: (0, p.convertToDefinitionProperty)(e, r.visible, Ee),
                                    color: (0, p.getColorDefinitionProperty)(e, r.color, null, Ge),
                                    width: (0, p.convertToDefinitionProperty)(e, r.width, Ae),
                                    style: (0, p.convertToDefinitionProperty)(e, r.style, Re)
                                }, {
                                    id: "sessionBeaks",
                                    title: tt
                                }),
                                w = (0, p.createTextPropertyDefinition)({
                                    color: (0, p.getColorDefinitionProperty)(e, n.textColor, null, We),
                                    size: (0, p.convertToDefinitionProperty)(e, n.fontSize, He)
                                }, {
                                    id: "scalesText",
                                    title: it
                                }),
                                S = (0, p.createLinePropertyDefinition)({
                                    color: (0, p.getColorDefinitionProperty)(e, n.lineColor, null, Be)
                                }, {
                                    id: "scalesLine",
                                    title: nt
                                }),
                                D = (0, P.createWVFromGetterAndSubscription)(() => 1 !== e.model().panes().length, e.model().panesCollectionChanged()),
                                T = (0, p.createLinePropertyDefinition)({
                                    visible: (0, p.convertFromReadonlyWVToDefinitionProperty)(D),
                                    color: (0, p.getColorDefinitionProperty)(e, t.separatorColor, null, Fe)
                                }, {
                                    id: "paneSeparators",
                                    title: rt
                                }),
                                k = t.crossHairProperties.childs(),
                                _ = (0, p.createLinePropertyDefinition)({
                                    color: (0, p.getColorDefinitionProperty)(e, k.color, k.transparency, Ne),
                                    width: (0, p.convertToDefinitionProperty)(e, k.width, je),
                                    style: (0, p.convertToDefinitionProperty)(e, k.style, Ie)
                                }, {
                                    id: "crossHair",
                                    title: ot
                                });
                            if (h.push(g, u, v, m, w, S, T, _), null !== i) {
                                const t = (0, p.createColorPropertyDefinition)({
                                    checked: (0, p.convertToDefinitionProperty)(e, i.visibility, Ue),
                                    color: (0,
                                        p.getColorDefinitionProperty)(e, i.color, null, qe)
                                }, {
                                    id: "watermark",
                                    title: at
                                });
                                h.push(t)
                            }
                            const C = (0, p.createOptionsPropertyDefinition)({
                                option: (0, p.convertToDefinitionProperty)(e, l.property, Je)
                            }, {
                                id: "navButtons",
                                title: lt,
                                options: new(c())(l.values)
                            });
                            h.push(C);
                            const L = (0, p.createOptionsPropertyDefinition)({
                                option: (0, p.convertToDefinitionProperty)(e, d.property, Ke)
                            }, {
                                id: "paneButtons",
                                title: ct,
                                options: new(c())(d.values)
                            });
                            h.push(L);
                            const V = (0, p.createNumberPropertyDefinition)({
                                    value: (0, p.convertToDefinitionProperty)(e, t.topMargin, Qe, [j.floor])
                                }, {
                                    type: 0,
                                    id: "paneTopMargin",
                                    title: st,
                                    min: new(c())(0),
                                    max: new(c())(25),
                                    step: new(c())(1),
                                    unit: new(c())("%")
                                }),
                                x = (0, p.createNumberPropertyDefinition)({
                                    value: (0, p.convertToDefinitionProperty)(e, t.bottomMargin, Xe, [j.floor])
                                }, {
                                    type: 0,
                                    id: "paneBottomMargin",
                                    title: pt,
                                    min: new(c())(0),
                                    max: new(c())(25),
                                    step: new(c())(1),
                                    unit: new(c())("%")
                                }),
                                O = (0, p.createNumberPropertyDefinition)({
                                    value: (0, p.convertFromWVToDefinitionProperty)(e, s.value, Ye, [j.floor])
                                }, {
                                    type: 0,
                                    id: "paneRightMargin",
                                    title: dt,
                                    min: s.min,
                                    max: s.max,
                                    step: new(c())(1),
                                    unit: new(c())(ht)
                                }),
                                M = [(0, p.createPropertyDefinitionsGeneralGroup)(h, "generalAppearanceGroup"), V, x];
                            return o.enabled("chart_property_page_right_margin_editor") && M.push(O), {
                                definitions: M
                            }
                        }(this._undoModel, t, a, i, y, this._series.isDWMProperty(), u, s, l);
                    return (0, d.createPropertyPage)(b, "appearance", ei, Xt.appearance)
                }
                _createTradingPropertyPage() {
                    if (!oi) return null;
                    if (null === ai) return null;
                    this._profitLossOptions = new(c()), this._pipValueTypeSpawn = ai.pipValueType().spawn(), this._pipValueTypeSpawn.subscribe(this._updatePlDisplayOptions.bind(this), {
                        callWithLast: !0
                    });
                    const e = this._model.properties().childs().tradingProperties.childs(),
                        t = Jt(this._undoModel, e, ai, this._profitLossOptions);
                    return (0, d.createPropertyPage)(t, "trading", ti, Xt.trading)
                }
                _createEventsPropertyPage() {
                    return null
                }
            }
        },
        4537: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M7.5 16.5l-1 1v4h4l1-1m-4-4l2 2m-2-2l9-9m-5 13l-2-2m2 2l9-9m-11 7l9-9m0 0l-2-2m2 2l2 2m-4-4l.94-.94a1.5 1.5 0 0 1 2.12 0l1.88 1.88a1.5 1.5 0 0 1 0 2.12l-.94.94"/></svg>'
        },
        8047: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M10 4h1v2h6V4h1v2h2.5A2.5 2.5 0 0 1 23 8.5v11a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 5 19.5v-11A2.5 2.5 0 0 1 7.5 6H10V4zm8 3H7.5A1.5 1.5 0 0 0 6 8.5v11A1.5 1.5 0 0 0 7.5 21h13a1.5 1.5 0 0 0 1.5-1.5v-11A1.5 1.5 0 0 0 20.5 7H18zm-3 2h-2v2h2V9zm-7 4h2v2H8v-2zm12-4h-2v2h2V9zm-7 4h2v2h-2v-2zm-3 4H8v2h2v-2zm3 0h2v2h-2v-2zm7-4h-2v2h2v-2z"/></svg>'
        },
        89380: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M10.5 20.5a2 2 0 1 1-2-2m2 2a2 2 0 0 0-2-2m2 2h14m-16-2v-14m16 16L21 17m3.5 3.5L21 24M8.5 4.5L12 8M8.5 4.5L5 8"/></svg>'
        },
        64864: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" d="M6 13h12v1H6zM6 17h12v1H6zM6 21h12v1H6z"/><rect width="17" height="3" stroke="currentColor" rx="1.5" x="5.5" y="6.5"/></svg>'
        },
        90682: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9 7H7v14h2v3h1v-3h2V7h-2V4H9v3zM8 8v12h3V8H8zm9 1h-2v10h2v3h1v-3h2V9h-2V6h-1v3zm-1 1v8h3v-8h-3z"/></svg>'
        },
        70609: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M24.068 9a.569.569 0 0 1 .73.872L19 14.842l-5.798-4.97a.569.569 0 0 1 .73-.872l4.751 3.887.317.26.317-.26L24.068 9zm1.47-.67a1.569 1.569 0 0 0-2.103-.104L19 11.854l-4.435-3.628a1.569 1.569 0 0 0-2.014 2.405l6.124 5.249.325.279.325-.28 6.124-5.248a1.569 1.569 0 0 0 .088-2.3zm-11.484 9.728a.57.57 0 0 0 .688-.91L9 12.636l-5.742 4.512a.57.57 0 0 0 .688.91l4.76-3.462.294-.214.294.214 4.76 3.462zm1.446.649a1.57 1.57 0 0 1-2.034.16L9 15.618l-4.466 3.249a1.57 1.57 0 0 1-1.894-2.505l6.051-4.755.309-.243.309.243 6.051 4.755c.74.581.806 1.68.14 2.345z"/></svg>'
        }
    }
]);
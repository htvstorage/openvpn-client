(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [8179], {
        9873: e => {
            e.exports = {
                container: "container-FRMBXkkj",
                active: "active-FRMBXkkj",
                title: "title-FRMBXkkj",
                inactive: "inactive-FRMBXkkj",
                titleText: "titleText-FRMBXkkj",
                indicator: "indicator-FRMBXkkj",
                disconnected: "disconnected-FRMBXkkj",
                failed: "failed-FRMBXkkj",
                connecting: "connecting-FRMBXkkj",
                connected: "connected-FRMBXkkj",
                loginTooltip: "loginTooltip-FRMBXkkj"
            }
        },
        47465: (e, t, n) => {
            "use strict";
            n.d(t, {
                makeCancelable: () => r,
                isCancelled: () => a
            });
            class i {}

            function r(e) {
                let t = !1;
                return {
                    promise: new Promise((n, r) => {
                        e.then(e => t ? r(new i) : n(e)), e.catch(e => r(t ? new i : e))
                    }),
                    cancel() {
                        t = !0
                    }
                }
            }

            function a(e) {
                return e instanceof i
            }
        },
        66854: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                getTerminalConfigSet: () => f
            });
            var i = n(25177);
            const r = {
                paper_trading: {
                    name: "paper_trading",
                    title: (0, i.t)("Trading Panel"),
                    buttonOpenTooltip: (0, i.t)("Open Trading Panel"),
                    buttonCloseTooltip: (0, i.t)("Close Trading Panel"),
                    ctor: null,
                    _gaEvent: "Trading Panel"
                },
                scripteditor: {
                    name: "scripteditor",
                    title: (0, i.t)("Pine Editor"),
                    buttonOpenTooltip: (0, i.t)("Open Pine Editor"),
                    buttonCloseTooltip: (0, i.t)("Close Pine Editor"),
                    ctor: null,
                    _gaEvent: "Pine Editor"
                },
                backtesting: {
                    name: "backtesting",
                    title: (0, i.t)("Strategy Tester"),
                    buttonOpenTooltip: (0, i.t)("Open Strategy Tester"),
                    buttonCloseTooltip: (0, i.t)("Close Strategy Tester"),
                    ctor: null,
                    _gaEvent: "Strategy Tester"
                },
                screener: {
                    name: "screener",
                    title: (0, i.t)("Screener"),
                    buttonOpenTooltip: (0, i.t)("Open Screener"),
                    buttonCloseTooltip: (0, i.t)("Close Screener"),
                    ctor: null,
                    _gaEvent: "Screener"
                },
                text_notes: {
                    name: "text_notes",
                    title: (0, i.t)("Text Notes"),
                    buttonOpenTooltip: (0, i.t)("Open Text Notes Panel"),
                    buttonCloseTooltip: (0, i.t)("Close Text Notes Panel"),
                    ctor: null,
                    _gaEvent: "Text Notes"
                }
            };
            var a = n(88537),
                s = n(33080),
                o = (n(24818), n(94489)),
                c = n.n(o),
                l = n(71757);
            class d {
                constructor(e) {
                    this._contentRenderer = Promise.resolve(), this._spinnerContainer = document.createElement("div"), this._offlineScreenContainer = document.createElement("div"), this._renderer = Promise.resolve(), this._filter = new(c())(!0), this._bridge = e, (0, s.waitTradingService)().then(e => {
                        this._trading = e, this.onStatusChange(e.connectStatus()), this._trading.onConnectionStatusChange.subscribe(this, this.onStatusChange)
                    }), n.e(7102).then(n.bind(n, 74063)).then(e => {
                        e.render(this._spinnerContainer)
                    }), (0, l.renderOfflineScreen)((0, a.ensureDefined)(this._offlineScreenContainer))
                }
                activate() {
                    this._contentRenderer.then(() => {
                        this._content && this._content.drawAttention && this._content.drawAttention()
                    })
                }
                onStatusChange(e, t) {
                    this._connectStatus !== e && (this._connectStatus = this._trading.connectStatus(), window.navigator.onLine ? (this._contentRenderer = Promise.resolve(), this._content && this._content.remove(), 2 === e && this._renderSpinner(), 3 !== e && 4 !== e ? 1 === e && this._renderAccountManager(this._trading.activeBroker()) : this._renderSpinner()) : this._renderOfflineScreen())
                }
                _renderSpinner() {
                    this._bridge.container.innerText = "", this._content = this._bridge.container.appendChild(this._spinnerContainer)
                }
                _renderOfflineScreen() {
                    this._bridge.container.innerText = "",
                        this._content = this._bridge.container.appendChild(this._offlineScreenContainer)
                }
                async _createAccountManager(e) {
                    const {
                        AccountManager: t
                    } = await Promise.all([n.e(9685), n.e(5514), n.e(9129), n.e(2e3), n.e(6363), n.e(3466), n.e(7836), n.e(3921), n.e(7427), n.e(7552), n.e(7419), n.e(3727), n.e(2335), n.e(3975), n.e(3944), n.e(419), n.e(9255), n.e(2930), n.e(7664), n.e(9578), n.e(6872), n.e(8354)]).then(n.bind(n, 56718)), {
                        SummaryFieldsVisibilityManager: i
                    } = await Promise.all([n.e(9685), n.e(5514), n.e(9129), n.e(2e3), n.e(6363), n.e(3466), n.e(7836), n.e(3921), n.e(7427), n.e(7552), n.e(7419), n.e(3727), n.e(2335), n.e(3975), n.e(3944), n.e(419), n.e(9255), n.e(2930), n.e(7664), n.e(9578), n.e(6872), n.e(8354)]).then(n.bind(n, 56656));
                    if (this._contentRenderer !== this._renderer) return;
                    this._content && this._content.remove();
                    const r = new i((0, a.ensureNotNull)(e).accountManagerInfo().summary, this._trading.getBrokerTradingSettingsStorage);
                    this._content = await t.create({
                        broker: e,
                        bridge: this._bridge,
                        mode: 1,
                        summaryFieldsVisibilityManager: r
                    })
                }
                _renderAccountManager(e) {
                    this._renderer = this._contentRenderer = this._createAccountManager(e)
                }
                _renderBrokerSelectScreen() {
                    0
                }
            }
            var h = n(59496),
                g = n(97754),
                _ = n(82527),
                u = n(47465),
                p = n(50681),
                m = n(9873);
            const b = (0, i.t)("Trading Panel"),
                C = (0, i.t)("Account Manager"),
                v = {
                    4: "failed",
                    2: "connecting",
                    1: "connected",
                    3: "disconnected"
                },
                S = {
                    4: (0, i.t)("Failed"),
                    2: (0, i.t)("Connecting"),
                    1: (0, i.t)("Connected"),
                    3: (0, i.t)("Disconnected")
                };
            class k extends h.PureComponent {
                constructor(e) {
                    super(e), this._trading = null, this._tradingServiceCancelable = null, this._titleClick = () => {
                        const {
                            onClick: e
                        } = this.props;
                        e && e()
                    }, this.state = {
                        status: 3,
                        hasActiveBroker: !1,
                        title: _.enabled("trading_terminal") ? C : b
                    }
                }
                componentDidMount() {
                    if (_.enabled("trading_terminal")) return;
                    const e = (0, s.tradingService)();
                    null === e ? (this._tradingServiceCancelable = (0, u.makeCancelable)((0, s.waitTradingService)()), this._tradingServiceCancelable.promise.then(this._onTradingService.bind(this))) : this._onTradingService(e)
                }
                componentWillUnmount() {
                    _.enabled("trading_terminal") || (this._cancelWaitingTrading(), null !== this._trading && (this._trading.onBrokerChange.unsubscribe(this, this._update), this._trading.onConnectionStatusChange.unsubscribe(this, this._update)))
                }
                render() {
                    const {
                        status: e,
                        hasActiveBroker: t,
                        title: n
                    } = this.state;
                    return h.createElement("div", {
                        className: g(p.bottomTradingTabClassName, m.container, m[v[e]], {
                            [m.active]: this.props.isActive,
                            [m.inactive]: !t
                        }),
                        onClick: this._titleClick,
                        "data-name": this.props.dataName,
                        "data-active": this.props.isActive
                    }, h.createElement("span", {
                        className: m.title
                    }, h.createElement("span", {
                        className: m.titleText
                    }, n)), h.createElement("div", {
                        className: g(m.indicator, "apply-common-tooltip"),
                        title: S[e]
                    }))
                }
                _onTradingService(e) {
                    this._cancelWaitingTrading(), this._trading = e, e.onBrokerChange.subscribe(this, this._update), e.onConnectionStatusChange.subscribe(this, this._update), this._update()
                }
                _update() {
                    const e = this._trading,
                        t = e && e.activeBroker(),
                        n = e ? e.connectStatus() : 3;
                    window.is_authenticated && !_.enabled("trading_terminal") && e && t && 1 === n ? this.setState({
                        status: n,
                        hasActiveBroker: !0,
                        title: t.accountManagerInfo().accountTitle
                    }) : this.setState({
                        status: n,
                        hasActiveBroker: !1,
                        title: b
                    })
                }
                _cancelWaitingTrading() {
                    null !== this._tradingServiceCancelable && (this._tradingServiceCancelable.cancel(), this._tradingServiceCancelable = null)
                }
            }
            var T = n(2683);

            function f() {
                const e = {
                    paper_trading: {
                        ctor: d,
                        customTitleComponent: k
                    }
                };
                return (0, T.merge)((0, T.clone)(r), e)
            }
        }
    }
]);
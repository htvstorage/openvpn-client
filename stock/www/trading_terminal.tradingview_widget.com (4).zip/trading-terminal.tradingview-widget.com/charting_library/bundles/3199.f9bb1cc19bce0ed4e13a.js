"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [3199], {
        83199: (t, e, r) => {
            r.d(e, {
                FixedSizeList: () => x,
                VariableSizeList: () => z
            });
            var n = r(19624),
                o = r(11430);

            function i(t, e) {
                t.prototype = Object.create(e.prototype), t.prototype.constructor = t, (0, o.default)(t, e)
            }
            var a = r(75542),
                l = Number.isNaN || function(t) {
                    return "number" == typeof t && t != t
                };

            function s(t, e) {
                if (t.length !== e.length) return !1;
                for (var r = 0; r < t.length; r++)
                    if (n = t[r], o = e[r], !(n === o || l(n) && l(o))) return !1;
                var n, o;
                return !0
            }
            const c = function(t, e) {
                var r;
                void 0 === e && (e = s);
                var n, o = [],
                    i = !1;
                return function() {
                    for (var a = [], l = 0; l < arguments.length; l++) a[l] = arguments[l];
                    return i && r === this && e(a, o) || (n = t.apply(this, a), i = !0, r = this, o = a), n
                }
            };
            var u = r(59496),
                f = "object" == typeof performance && "function" == typeof performance.now ? function() {
                    return performance.now()
                } : function() {
                    return Date.now()
                };

            function d(t) {
                cancelAnimationFrame(t.id)
            }

            function h(t, e) {
                var r = f();
                var n = {
                    id: requestAnimationFrame((function o() {
                        f() - r >= e ? t.call(null) : n.id = requestAnimationFrame(o)
                    }))
                };
                return n
            }
            var m = null;

            function p(t) {
                if (void 0 === t && (t = !1), null === m || t) {
                    var e = document.createElement("div"),
                        r = e.style;
                    r.width = "50px", r.height = "50px", r.overflow = "scroll", r.direction = "rtl";
                    var n = document.createElement("div"),
                        o = n.style;
                    return o.width = "100px", o.height = "100px", e.appendChild(n), document.body.appendChild(e), e.scrollLeft > 0 ? m = "positive-descending" : (e.scrollLeft = 1, m = 0 === e.scrollLeft ? "negative" : "positive-ascending"), document.body.removeChild(e), m
                }
                return m
            }
            var v = function(t, e) {
                return t
            };

            function g(t) {
                var e, r, o = t.getItemOffset,
                    l = t.getEstimatedTotalSize,
                    s = t.getItemSize,
                    f = t.getOffsetForIndexAndAlignment,
                    m = t.getStartIndexForOffset,
                    g = t.getStopIndexForStartIndex,
                    I = t.initInstanceProps,
                    _ = t.shouldResetStyleCacheOnItemSizeChange,
                    M = t.validateProps;
                return r = e = function(t) {
                    function e(e) {
                        var r;
                        return (r = t.call(this, e) || this)._instanceProps = I(r.props, (0, a.default)((0, a.default)(r))), r._outerRef = void 0, r._resetIsScrollingTimeoutId = null, r.state = {
                            instance: (0, a.default)((0, a.default)(r)),
                            isScrolling: !1,
                            scrollDirection: "forward",
                            scrollOffset: "number" == typeof r.props.initialScrollOffset ? r.props.initialScrollOffset : 0,
                            scrollUpdateWasRequested: !1
                        }, r._callOnItemsRendered = void 0, r._callOnItemsRendered = c((function(t, e, n, o) {
                            return r.props.onItemsRendered({
                                overscanStartIndex: t,
                                overscanStopIndex: e,
                                visibleStartIndex: n,
                                visibleStopIndex: o
                            })
                        })), r._callOnScroll = void 0, r._callOnScroll = c((function(t, e, n) {
                            return r.props.onScroll({
                                scrollDirection: t,
                                scrollOffset: e,
                                scrollUpdateWasRequested: n
                            })
                        })), r._getItemStyle = void 0, r._getItemStyle = function(t) {
                            var e, n = r.props,
                                i = n.direction,
                                a = n.itemSize,
                                l = n.layout,
                                c = r._getItemStyleCache(_ && a, _ && l, _ && i);
                            if (c.hasOwnProperty(t)) e = c[t];
                            else {
                                var u = o(r.props, t, r._instanceProps),
                                    f = s(r.props, t, r._instanceProps),
                                    d = "horizontal" === i || "horizontal" === l,
                                    h = "rtl" === i,
                                    m = d ? u : 0;
                                c[t] = e = {
                                    position: "absolute",
                                    left: h ? void 0 : m,
                                    right: h ? m : void 0,
                                    top: d ? 0 : u,
                                    height: d ? "100%" : f,
                                    width: d ? f : "100%"
                                }
                            }
                            return e
                        }, r._getItemStyleCache = void 0, r._getItemStyleCache = c((function(t, e, r) {
                            return {}
                        })), r._onScrollHorizontal = function(t) {
                            var e = t.currentTarget,
                                n = e.clientWidth,
                                o = e.scrollLeft,
                                i = e.scrollWidth;
                            r.setState((function(t) {
                                if (t.scrollOffset === o) return null;
                                var e = r.props.direction,
                                    a = o;
                                if ("rtl" === e) switch (p()) {
                                    case "negative":
                                        a = -o;
                                        break;
                                    case "positive-descending":
                                        a = i - n - o
                                }
                                return a = Math.max(0, Math.min(a, i - n)), {
                                    isScrolling: !0,
                                    scrollDirection: t.scrollOffset < o ? "forward" : "backward",
                                    scrollOffset: a,
                                    scrollUpdateWasRequested: !1
                                }
                            }), r._resetIsScrollingDebounced)
                        }, r._onScrollVertical = function(t) {
                            var e = t.currentTarget,
                                n = e.clientHeight,
                                o = e.scrollHeight,
                                i = e.scrollTop;
                            r.setState((function(t) {
                                if (t.scrollOffset === i) return null;
                                var e = Math.max(0, Math.min(i, o - n));
                                return {
                                    isScrolling: !0,
                                    scrollDirection: t.scrollOffset < e ? "forward" : "backward",
                                    scrollOffset: e,
                                    scrollUpdateWasRequested: !1
                                }
                            }), r._resetIsScrollingDebounced)
                        }, r._outerRefSetter = function(t) {
                            var e = r.props.outerRef;
                            r._outerRef = t, "function" == typeof e ? e(t) : null != e && "object" == typeof e && e.hasOwnProperty("current") && (e.current = t)
                        }, r._resetIsScrollingDebounced = function() {
                            null !== r._resetIsScrollingTimeoutId && d(r._resetIsScrollingTimeoutId), r._resetIsScrollingTimeoutId = h(r._resetIsScrolling, 150)
                        }, r._resetIsScrolling = function() {
                            r._resetIsScrollingTimeoutId = null, r.setState({
                                isScrolling: !1
                            }, (function() {
                                r._getItemStyleCache(-1, null)
                            }))
                        }, r
                    }
                    i(e, t), e.getDerivedStateFromProps = function(t, e) {
                        return S(t, e), M(t), null
                    };
                    var r = e.prototype;
                    return r.scrollTo = function(t) {
                        t = Math.max(0, t), this.setState((function(e) {
                            return e.scrollOffset === t ? null : {
                                scrollDirection: e.scrollOffset < t ? "forward" : "backward",
                                scrollOffset: t,
                                scrollUpdateWasRequested: !0
                            }
                        }), this._resetIsScrollingDebounced)
                    }, r.scrollToItem = function(t, e) {
                        void 0 === e && (e = "auto");
                        var r = this.props.itemCount,
                            n = this.state.scrollOffset;
                        t = Math.max(0, Math.min(t, r - 1)), this.scrollTo(f(this.props, t, e, n, this._instanceProps))
                    }, r.componentDidMount = function() {
                        var t = this.props,
                            e = t.direction,
                            r = t.initialScrollOffset,
                            n = t.layout;
                        if ("number" == typeof r && null != this._outerRef) {
                            var o = this._outerRef;
                            "horizontal" === e || "horizontal" === n ? o.scrollLeft = r : o.scrollTop = r
                        }
                        this._callPropsCallbacks()
                    }, r.componentDidUpdate = function() {
                        var t = this.props,
                            e = t.direction,
                            r = t.layout,
                            n = this.state,
                            o = n.scrollOffset;
                        if (n.scrollUpdateWasRequested && null != this._outerRef) {
                            var i = this._outerRef;
                            if ("horizontal" === e || "horizontal" === r)
                                if ("rtl" === e) switch (p()) {
                                    case "negative":
                                        i.scrollLeft = -o;
                                        break;
                                    case "positive-ascending":
                                        i.scrollLeft = o;
                                        break;
                                    default:
                                        var a = i.clientWidth,
                                            l = i.scrollWidth;
                                        i.scrollLeft = l - a - o
                                } else i.scrollLeft = o;
                                else i.scrollTop = o
                        }
                        this._callPropsCallbacks()
                    }, r.componentWillUnmount = function() {
                        null !== this._resetIsScrollingTimeoutId && d(this._resetIsScrollingTimeoutId)
                    }, r.render = function() {
                        var t = this.props,
                            e = t.children,
                            r = t.className,
                            o = t.direction,
                            i = t.height,
                            a = t.innerRef,
                            s = t.innerElementType,
                            c = t.innerTagName,
                            f = t.itemCount,
                            d = t.itemData,
                            h = t.itemKey,
                            m = void 0 === h ? v : h,
                            p = t.layout,
                            g = t.outerElementType,
                            S = t.outerTagName,
                            I = t.style,
                            _ = t.useIsScrolling,
                            M = t.width,
                            y = this.state.isScrolling,
                            z = "horizontal" === o || "horizontal" === p,
                            x = z ? this._onScrollHorizontal : this._onScrollVertical,
                            O = this._getRangeToRender(),
                            w = O[0],
                            C = O[1],
                            R = [];
                        if (f > 0)
                            for (var b = w; b <= C; b++) R.push((0,
                                u.createElement)(e, {
                                data: d,
                                key: m(b, d),
                                index: b,
                                isScrolling: _ ? y : void 0,
                                style: this._getItemStyle(b)
                            }));
                        var T = l(this.props, this._instanceProps);
                        return (0, u.createElement)(g || S || "div", {
                            className: r,
                            onScroll: x,
                            ref: this._outerRefSetter,
                            style: (0, n.default)({
                                position: "relative",
                                height: i,
                                width: M,
                                overflow: "auto",
                                WebkitOverflowScrolling: "touch",
                                willChange: "transform",
                                direction: o
                            }, I)
                        }, (0, u.createElement)(s || c || "div", {
                            children: R,
                            ref: a,
                            style: {
                                height: z ? "100%" : T,
                                pointerEvents: y ? "none" : void 0,
                                width: z ? T : "100%"
                            }
                        }))
                    }, r._callPropsCallbacks = function() {
                        if ("function" == typeof this.props.onItemsRendered && this.props.itemCount > 0) {
                            var t = this._getRangeToRender(),
                                e = t[0],
                                r = t[1],
                                n = t[2],
                                o = t[3];
                            this._callOnItemsRendered(e, r, n, o)
                        }
                        if ("function" == typeof this.props.onScroll) {
                            var i = this.state,
                                a = i.scrollDirection,
                                l = i.scrollOffset,
                                s = i.scrollUpdateWasRequested;
                            this._callOnScroll(a, l, s)
                        }
                    }, r._getRangeToRender = function() {
                        var t = this.props,
                            e = t.itemCount,
                            r = t.overscanCount,
                            n = this.state,
                            o = n.isScrolling,
                            i = n.scrollDirection,
                            a = n.scrollOffset;
                        if (0 === e) return [0, 0, 0, 0];
                        var l = m(this.props, a, this._instanceProps),
                            s = g(this.props, l, a, this._instanceProps),
                            c = o && "backward" !== i ? 1 : Math.max(1, r),
                            u = o && "forward" !== i ? 1 : Math.max(1, r);
                        return [Math.max(0, l - c), Math.max(0, Math.min(e - 1, s + u)), l, s]
                    }, e
                }(u.PureComponent), e.defaultProps = {
                    direction: "ltr",
                    itemData: void 0,
                    layout: "vertical",
                    overscanCount: 2,
                    useIsScrolling: !1
                }, r
            }
            var S = function(t, e) {
                    t.children, t.direction, t.height, t.layout, t.innerTagName, t.outerTagName, t.width, e.instance
                },
                I = function(t, e, r) {
                    var n = t.itemSize,
                        o = r.itemMetadataMap,
                        i = r.lastMeasuredIndex;
                    if (e > i) {
                        var a = 0;
                        if (i >= 0) {
                            var l = o[i];
                            a = l.offset + l.size
                        }
                        for (var s = i + 1; s <= e; s++) {
                            var c = n(s);
                            o[s] = {
                                offset: a,
                                size: c
                            }, a += c
                        }
                        r.lastMeasuredIndex = e
                    }
                    return o[e]
                },
                _ = function(t, e, r, n, o) {
                    for (; n <= r;) {
                        var i = n + Math.floor((r - n) / 2),
                            a = I(t, i, e).offset;
                        if (a === o) return i;
                        a < o ? n = i + 1 : a > o && (r = i - 1)
                    }
                    return n > 0 ? n - 1 : 0
                },
                M = function(t, e, r, n) {
                    for (var o = t.itemCount, i = 1; r < o && I(t, r, e).offset < n;) r += i, i *= 2;
                    return _(t, e, Math.min(r, o - 1), Math.floor(r / 2), n)
                },
                y = function(t, e) {
                    var r = t.itemCount,
                        n = e.itemMetadataMap,
                        o = e.estimatedItemSize,
                        i = e.lastMeasuredIndex,
                        a = 0;
                    if (i >= r && (i = r - 1), i >= 0) {
                        var l = n[i];
                        a = l.offset + l.size
                    }
                    return a + (r - i - 1) * o
                },
                z = g({
                    getItemOffset: function(t, e, r) {
                        return I(t, e, r).offset
                    },
                    getItemSize: function(t, e, r) {
                        return r.itemMetadataMap[e].size
                    },
                    getEstimatedTotalSize: y,
                    getOffsetForIndexAndAlignment: function(t, e, r, n, o) {
                        var i = t.direction,
                            a = t.height,
                            l = t.layout,
                            s = t.width,
                            c = "horizontal" === i || "horizontal" === l ? s : a,
                            u = I(t, e, o),
                            f = y(t, o),
                            d = Math.max(0, Math.min(f - c, u.offset)),
                            h = Math.max(0, u.offset - c + u.size);
                        switch ("smart" === r && (r = n >= h - c && n <= d + c ? "auto" : "center"), r) {
                            case "start":
                                return d;
                            case "end":
                                return h;
                            case "center":
                                return Math.round(h + (d - h) / 2);
                            case "auto":
                            default:
                                return n >= h && n <= d ? n : n < h ? h : d
                        }
                    },
                    getStartIndexForOffset: function(t, e, r) {
                        return function(t, e, r) {
                            var n = e.itemMetadataMap,
                                o = e.lastMeasuredIndex;
                            return (o > 0 ? n[o].offset : 0) >= r ? _(t, e, o, 0, r) : M(t, e, Math.max(0, o), r)
                        }(t, r, e)
                    },
                    getStopIndexForStartIndex: function(t, e, r, n) {
                        for (var o = t.direction, i = t.height, a = t.itemCount, l = t.layout, s = t.width, c = "horizontal" === o || "horizontal" === l ? s : i, u = I(t, e, n), f = r + c, d = u.offset + u.size, h = e; h < a - 1 && d < f;) h++, d += I(t, h, n).size;
                        return h
                    },
                    initInstanceProps: function(t, e) {
                        var r = {
                            itemMetadataMap: {},
                            estimatedItemSize: t.estimatedItemSize || 50,
                            lastMeasuredIndex: -1
                        };
                        return e.resetAfterIndex = function(t, n) {
                            void 0 === n && (n = !0), r.lastMeasuredIndex = Math.min(r.lastMeasuredIndex, t - 1), e._getItemStyleCache(-1), n && e.forceUpdate()
                        }, r
                    },
                    shouldResetStyleCacheOnItemSizeChange: !1,
                    validateProps: function(t) {
                        t.itemSize
                    }
                }),
                x = g({
                    getItemOffset: function(t, e) {
                        return e * t.itemSize
                    },
                    getItemSize: function(t, e) {
                        return t.itemSize
                    },
                    getEstimatedTotalSize: function(t) {
                        var e = t.itemCount;
                        return t.itemSize * e
                    },
                    getOffsetForIndexAndAlignment: function(t, e, r, n) {
                        var o = t.direction,
                            i = t.height,
                            a = t.itemCount,
                            l = t.itemSize,
                            s = t.layout,
                            c = t.width,
                            u = "horizontal" === o || "horizontal" === s ? c : i,
                            f = Math.max(0, a * l - u),
                            d = Math.min(f, e * l),
                            h = Math.max(0, e * l - u + l);
                        switch ("smart" === r && (r = n >= h - u && n <= d + u ? "auto" : "center"), r) {
                            case "start":
                                return d;
                            case "end":
                                return h;
                            case "center":
                                var m = Math.round(h + (d - h) / 2);
                                return m < Math.ceil(u / 2) ? 0 : m > f + Math.floor(u / 2) ? f : m;
                            case "auto":
                            default:
                                return n >= h && n <= d ? n : n < h ? h : d
                        }
                    },
                    getStartIndexForOffset: function(t, e) {
                        var r = t.itemCount,
                            n = t.itemSize;
                        return Math.max(0, Math.min(r - 1, Math.floor(e / n)))
                    },
                    getStopIndexForStartIndex: function(t, e, r) {
                        var n = t.direction,
                            o = t.height,
                            i = t.itemCount,
                            a = t.itemSize,
                            l = t.layout,
                            s = t.width,
                            c = e * a,
                            u = "horizontal" === n || "horizontal" === l ? s : o,
                            f = Math.ceil((u + r - c) / a);
                        return Math.max(0, Math.min(i - 1, e + f - 1))
                    },
                    initInstanceProps: function(t) {},
                    shouldResetStyleCacheOnItemSizeChange: !0,
                    validateProps: function(t) {
                        t.itemSize
                    }
                })
        }
    }
]);
"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [970], {
        58261: (e, n, r) => {
            r.d(n, {
                combineLatest: () => b
            });
            var t = r(15544),
                i = Array.isArray,
                u = Object.getPrototypeOf,
                o = Object.prototype,
                c = Object.keys;

            function s(e) {
                if (1 === e.length) {
                    var n = e[0];
                    if (i(n)) return {
                        args: n,
                        keys: null
                    };
                    if ((t = n) && "object" == typeof t && u(t) === o) {
                        var r = c(n);
                        return {
                            args: r.map((function(e) {
                                return n[e]
                            })),
                            keys: r
                        }
                    }
                }
                var t;
                return {
                    args: e,
                    keys: null
                }
            }
            var a = r(39874),
                l = r(72484),
                f = r(91034),
                d = r(95940);

            function h(e, n) {
                return e.reduce((function(e, r, t) {
                    return e[r] = n[t], e
                }), {})
            }
            var v = r(38966),
                p = r(72117);

            function b() {
                for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                var r = (0, d.popScheduler)(e),
                    i = (0, d.popResultSelector)(e),
                    u = s(e),
                    o = u.args,
                    c = u.keys;
                if (0 === o.length) return (0, a.from)([], r);
                var v = new t.Observable(y(o, r, c ? function(e) {
                    return h(c, e)
                } : l.identity));
                return i ? v.pipe((0, f.mapOneOrManyArgs)(i)) : v
            }

            function y(e, n, r) {
                return void 0 === r && (r = l.identity),
                    function(t) {
                        g(n, (function() {
                            for (var i = e.length, u = new Array(i), o = i, c = i, s = function(i) {
                                    g(n, (function() {
                                        var s = (0, a.from)(e[i], n),
                                            l = !1;
                                        s.subscribe(new v.OperatorSubscriber(t, (function(e) {
                                            u[i] = e, l || (l = !0, c--), c || t.next(r(u.slice()))
                                        }), (function() {
                                            --o || t.complete()
                                        })))
                                    }), t)
                                }, l = 0; l < i; l++) s(l)
                        }), t)
                    }
            }

            function g(e, n, r) {
                e ? (0, p.executeSchedule)(r, e, n) : n()
            }
        },
        95205: (e, n, r) => {
            r.d(n, {
                connectable: () => c
            });
            var t = r(37538),
                i = r(15544),
                u = r(71035);
            var o = {
                connector: function() {
                    return new t.Subject
                },
                resetOnDisconnect: !0
            };

            function c(e, n) {
                void 0 === n && (n = o);
                var r = null,
                    t = n.connector,
                    c = n.resetOnDisconnect,
                    s = void 0 === c || c,
                    a = t(),
                    l = new i.Observable((function(e) {
                        return a.subscribe(e)
                    }));
                return l.connect = function() {
                    var n;
                    return r && !r.closed || (r = (n = function() {
                        return e
                    }, new i.Observable((function(e) {
                        (0, u.innerFrom)(n()).subscribe(e)
                    }))).subscribe(a), s && r.add((function() {
                        return a = t()
                    }))), r
                }, l
            }
        },
        75734: (e, n, r) => {
            r.d(n, {
                fromEventPattern: () => o
            });
            var t = r(15544),
                i = r(38323),
                u = r(91034);

            function o(e, n, r) {
                return r ? o(e, n).pipe((0, u.mapOneOrManyArgs)(r)) : new t.Observable((function(r) {
                    var t = function() {
                            for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                            return r.next(1 === e.length ? e[0] : e)
                        },
                        u = e(t);
                    return (0, i.isFunction)(n) ? function() {
                        return n(t, u)
                    } : void 0
                }))
            }
        },
        86639: (e, n, r) => {
            r.d(n, { of: () => u
            });
            var t = r(95940),
                i = r(39874);

            function u() {
                for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                var r = (0, t.popScheduler)(e);
                return (0, i.from)(e, r)
            }
        },
        23691: (e, n, r) => {
            r.d(n, {
                zip: () => f
            });
            var t = r(46685),
                i = r(15544),
                u = r(71035),
                o = Array.isArray;

            function c(e) {
                return 1 === e.length && o(e[0]) ? e[0] : e
            }
            var s = r(23869),
                a = r(38966),
                l = r(95940);

            function f() {
                for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                var r = (0, l.popResultSelector)(e),
                    o = c(e);
                return o.length ? new i.Observable((function(e) {
                    var n = o.map((function() {
                            return []
                        })),
                        i = o.map((function() {
                            return !1
                        }));
                    e.add((function() {
                        n = i = null
                    }));
                    for (var c = function(c) {
                            (0, u.innerFrom)(o[c]).subscribe(new a.OperatorSubscriber(e, (function(u) {
                                if (n[c].push(u), n.every((function(e) {
                                        return e.length
                                    }))) {
                                    var o = n.map((function(e) {
                                        return e.shift()
                                    }));
                                    e.next(r ? r.apply(void 0, (0, t.__spreadArray)([], (0, t.__read)(o), !1)) : o),
                                        n.some((function(e, n) {
                                            return !e.length && i[n]
                                        })) && e.complete()
                                }
                            }), (function() {
                                i[c] = !0, !n[c].length && e.complete()
                            })))
                        }, s = 0; !e.closed && s < o.length; s++) c(s);
                    return function() {
                        n = i = null
                    }
                })) : s.EMPTY
            }
        },
        21603: (e, n, r) => {
            r.d(n, {
                takeUntil: () => c
            });
            var t = r(16217),
                i = r(38966),
                u = r(71035),
                o = r(77441);

            function c(e) {
                return (0, t.operate)((function(n, r) {
                    (0, u.innerFrom)(e).subscribe(new i.OperatorSubscriber(r, (function() {
                        return r.complete()
                    }), o.noop)), !r.closed && n.subscribe(r)
                }))
            }
        },
        85941: (e, n, r) => {
            r.d(n, {
                throttleTime: () => w
            });
            var t = r(46685),
                i = function(e) {
                    function n(n, r) {
                        return e.call(this) || this
                    }
                    return (0, t.__extends)(n, e), n.prototype.schedule = function(e, n) {
                        return void 0 === n && (n = 0), this
                    }, n
                }(r(3448).Subscription),
                u = {
                    setInterval: function() {
                        for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                        var r = u.delegate;
                        return ((null == r ? void 0 : r.setInterval) || setInterval).apply(void 0, (0, t.__spreadArray)([], (0, t.__read)(e), !1))
                    },
                    clearInterval: function(e) {
                        var n = u.delegate;
                        return ((null == n ? void 0 : n.clearInterval) || clearInterval)(e)
                    },
                    delegate: void 0
                },
                o = r(3955),
                c = function(e) {
                    function n(n, r) {
                        var t = e.call(this, n, r) || this;
                        return t.scheduler = n, t.work = r, t.pending = !1, t
                    }
                    return (0, t.__extends)(n, e), n.prototype.schedule = function(e, n) {
                        if (void 0 === n && (n = 0), this.closed) return this;
                        this.state = e;
                        var r = this.id,
                            t = this.scheduler;
                        return null != r && (this.id = this.recycleAsyncId(t, r, n)), this.pending = !0, this.delay = n, this.id = this.id || this.requestAsyncId(t, this.id, n), this
                    }, n.prototype.requestAsyncId = function(e, n, r) {
                        return void 0 === r && (r = 0), u.setInterval(e.flush.bind(e, this), r)
                    }, n.prototype.recycleAsyncId = function(e, n, r) {
                        if (void 0 === r && (r = 0), null != r && this.delay === r && !1 === this.pending) return n;
                        u.clearInterval(n)
                    }, n.prototype.execute = function(e, n) {
                        if (this.closed) return new Error("executing a cancelled action");
                        this.pending = !1;
                        var r = this._execute(e, n);
                        if (r) return r;
                        !1 === this.pending && null != this.id && (this.id = this.recycleAsyncId(this.scheduler, this.id, null))
                    }, n.prototype._execute = function(e, n) {
                        var r, t = !1;
                        try {
                            this.work(e)
                        } catch (e) {
                            t = !0, r = e || new Error("Scheduled action threw falsy error")
                        }
                        if (t) return this.unsubscribe(), r
                    }, n.prototype.unsubscribe = function() {
                        if (!this.closed) {
                            var n = this.id,
                                r = this.scheduler,
                                t = r.actions;
                            this.work = this.state = this.scheduler = null, this.pending = !1, (0, o.arrRemove)(t, this), null != n && (this.id = this.recycleAsyncId(r, n, null)), this.delay = null, e.prototype.unsubscribe.call(this)
                        }
                    }, n
                }(i),
                s = r(12813),
                a = function() {
                    function e(n, r) {
                        void 0 === r && (r = e.now), this.schedulerActionCtor = n, this.now = r
                    }
                    return e.prototype.schedule = function(e, n, r) {
                        return void 0 === n && (n = 0), new this.schedulerActionCtor(this, e).schedule(r, n)
                    }, e.now = s.dateTimestampProvider.now, e
                }(),
                l = new(function(e) {
                    function n(n, r) {
                        void 0 === r && (r = a.now);
                        var t = e.call(this, n, r) || this;
                        return t.actions = [], t._active = !1, t._scheduled = void 0, t
                    }
                    return (0, t.__extends)(n, e), n.prototype.flush = function(e) {
                        var n = this.actions;
                        if (this._active) n.push(e);
                        else {
                            var r;
                            this._active = !0;
                            do {
                                if (r = e.execute(e.state, e.delay)) break
                            } while (e = n.shift());
                            if (this._active = !1, r) {
                                for (; e = n.shift();) e.unsubscribe();
                                throw r
                            }
                        }
                    }, n
                }(a))(c),
                f = l,
                d = r(16217),
                h = r(38966),
                v = r(71035),
                p = {
                    leading: !0,
                    trailing: !1
                };
            var b = r(15544),
                y = r(37160);

            function g(e, n, r) {
                void 0 === e && (e = 0), void 0 === r && (r = f);
                var t = -1;
                return null != n && ((0, y.isScheduler)(n) ? r = n : t = n), new b.Observable((function(n) {
                    var i, u = (i = e) instanceof Date && !isNaN(i) ? +e - r.now() : e;
                    u < 0 && (u = 0);
                    var o = 0;
                    return r.schedule((function() {
                        n.closed || (n.next(o++), 0 <= t ? this.schedule(void 0, t) : n.complete())
                    }), u)
                }))
            }

            function w(e, n, r) {
                void 0 === n && (n = l), void 0 === r && (r = p);
                var t, i, u, o, c, s = g(e, n);
                return t = function() {
                    return s
                }, o = (u = void 0 === (i = r) ? p : i).leading, c = u.trailing, (0, d.operate)((function(e, n) {
                    var r = !1,
                        i = null,
                        u = null,
                        s = !1,
                        a = function() {
                            null == u || u.unsubscribe(), u = null, c && (d(), s && n.complete())
                        },
                        l = function() {
                            u = null, s && n.complete()
                        },
                        f = function(e) {
                            return u = (0, v.innerFrom)(t(e)).subscribe(new h.OperatorSubscriber(n, a, l))
                        },
                        d = function() {
                            if (r) {
                                r = !1;
                                var e = i;
                                i = null, n.next(e), !s && f(e)
                            }
                        };
                    e.subscribe(new h.OperatorSubscriber(n, (function(e) {
                        r = !0, i = e, (!u || u.closed) && (o ? d() : f(e))
                    }), (function() {
                        s = !0, (!(c && r && u) || u.closed) && n.complete()
                    })))
                }))
            }
        },
        52260: (e, n, r) => {
            r.d(n, {
                withLatestFrom: () => l
            });
            var t = r(46685),
                i = r(16217),
                u = r(38966),
                o = r(71035),
                c = r(72484),
                s = r(77441),
                a = r(95940);

            function l() {
                for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                var r = (0, a.popResultSelector)(e);
                return (0, i.operate)((function(n, i) {
                    for (var a = e.length, l = new Array(a), f = e.map((function() {
                            return !1
                        })), d = !1, h = function(n) {
                            (0, o.innerFrom)(e[n]).subscribe(new u.OperatorSubscriber(i, (function(e) {
                                l[n] = e, d || f[n] || (f[n] = !0, (d = f.every(c.identity)) && (f = null))
                            }), s.noop))
                        }, v = 0; v < a; v++) h(v);
                    n.subscribe(new u.OperatorSubscriber(i, (function(e) {
                        if (d) {
                            var n = (0, t.__spreadArray)([e], (0, t.__read)(l), !1);
                            i.next(r ? r.apply(void 0, (0, t.__spreadArray)([], (0, t.__read)(n), !1)) : n)
                        }
                    })))
                }))
            }
        },
        91034: (e, n, r) => {
            r.d(n, {
                mapOneOrManyArgs: () => o
            });
            var t = r(46685),
                i = r(97345),
                u = Array.isArray;

            function o(e) {
                return (0, i.map)((function(n) {
                    return function(e, n) {
                        return u(n) ? e.apply(void 0, (0, t.__spreadArray)([], (0, t.__read)(n), !1)) : e(n)
                    }(e, n)
                }))
            }
        }
    }
]);
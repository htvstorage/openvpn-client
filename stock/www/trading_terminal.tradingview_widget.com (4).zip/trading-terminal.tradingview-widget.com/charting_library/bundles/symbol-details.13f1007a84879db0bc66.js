(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [6991], {
        46673: () => {},
        97623: e => {
            e.exports = {
                scrollWrap: "scrollWrap-9M00JHkT"
            }
        },
        21789: e => {
            e.exports = {
                container: "container-1ot4c7oO",
                overlayScrollWrap: "overlayScrollWrap-1ot4c7oO",
                wrapper: "wrapper-1ot4c7oO"
            }
        },
        62230: e => {
            e.exports = {
                wrap: "wrap-Shy8LdqT",
                "wrap--horizontal": "wrap--horizontal-Shy8LdqT",
                bar: "bar-Shy8LdqT",
                barInner: "barInner-Shy8LdqT",
                "barInner--horizontal": "barInner--horizontal-Shy8LdqT",
                "bar--horizontal": "bar--horizontal-Shy8LdqT"
            }
        },
        75305: e => {
            e.exports = {
                change: "change-xEmvGjko"
            }
        },
        6058: e => {
            e.exports = {
                main: "main-WLuu8Y22",
                additional: "additional-WLuu8Y22",
                invalid: "invalid-WLuu8Y22",
                dotWrap: "dotWrap-WLuu8Y22",
                smallMargin: "smallMargin-WLuu8Y22",
                dot: "dot-WLuu8Y22"
            }
        },
        18618: e => {
            e.exports = {
                container: "container-nyUk7y6M",
                bid: "bid-nyUk7y6M",
                ask: "ask-nyUk7y6M"
            }
        },
        25271: e => {
            e.exports = {
                container: "container-ccFPqsjV",
                title: "title-ccFPqsjV",
                daysCounter: "daysCounter-ccFPqsjV",
                daysCounterSoon: "daysCounterSoon-ccFPqsjV",
                groupWrap: "groupWrap-ccFPqsjV",
                hasDisabledSet: "hasDisabledSet-ccFPqsjV"
            }
        },
        29549: e => {
            e.exports = {
                highlight: "highlight-SpK5FWdt",
                growing: "growing-SpK5FWdt",
                falling: "falling-SpK5FWdt"
            }
        },
        22341: e => {
            e.exports = {
                status: "status-ko7LfJhF",
                open: "open-ko7LfJhF",
                dot: "dot-ko7LfJhF",
                text: "text-ko7LfJhF",
                close: "close-ko7LfJhF",
                textWithIcon: "textWithIcon-ko7LfJhF",
                lastPriceTimeWithIcon: "lastPriceTimeWithIcon-ko7LfJhF",
                lastPrice: "lastPrice-ko7LfJhF",
                plus: "plus-ko7LfJhF",
                change: "change-ko7LfJhF",
                changePercent: "changePercent-ko7LfJhF",
                minus: "minus-ko7LfJhF",
                price: "price-ko7LfJhF",
                changeWrap: "changeWrap-ko7LfJhF",
                extra: "extra-ko7LfJhF",
                pre: "pre-ko7LfJhF",
                label: "label-ko7LfJhF",
                separator: "separator-ko7LfJhF",
                post: "post-ko7LfJhF",
                icon: "icon-ko7LfJhF"
            }
        },
        72645: e => {
            e.exports = {
                container: "container-kNPSIFlx",
                header: "header-kNPSIFlx",
                title: "title-kNPSIFlx",
                price: "price-kNPSIFlx",
                range: "range-kNPSIFlx",
                bar: "bar-kNPSIFlx",
                low: "low-kNPSIFlx",
                roundedLeft: "roundedLeft-kNPSIFlx",
                roundedRight: "roundedRight-kNPSIFlx",
                arrowContainer: "arrowContainer-kNPSIFlx",
                arrow: "arrow-kNPSIFlx",
                extraMargin: "extraMargin-kNPSIFlx"
            }
        },
        63997: e => {
            e.exports = {
                container: "container-5J7H5XBV",
                price: "price-5J7H5XBV",
                info: "info-5J7H5XBV",
                mode: "mode-5J7H5XBV",
                currency: "currency-5J7H5XBV",
                priceWrapper: "priceWrapper-5J7H5XBV"
            }
        },
        31419: e => {
            e.exports = {
                hiddenWrapper: "hiddenWrapper-rKprzB9g",
                container: "container-rKprzB9g",
                opacity: "opacity-rKprzB9g",
                widgetWrapper: "widgetWrapper-rKprzB9g",
                large: "large-rKprzB9g",
                offsetDisabled: "offsetDisabled-rKprzB9g",
                separator: "separator-rKprzB9g",
                previewWidget: "previewWidget-rKprzB9g"
            }
        },
        9970: (e, t, r) => {
            "use strict";
            r.d(t, {
                AbstractIndicator: () => i
            });
            var a = r(51951),
                n = r(16345),
                s = r(21162);
            r(44471);
            const o = (0, a.getLogger)("GUI.Blocks.AbstractIndicator");
            class i {
                constructor(e) {
                    this._classSuffix = "", this._quoteSessionPrefix = "abstract-indicator", this._shortMode = !1, this._showTooltip = !0, this._subscribed = !1, this._tooltipType = "custom", this._lastTooltipText = "", this._quoteSession = e.quoteSession
                }
                getValue() {
                    return this._value
                }
                getTooltipText() {
                    return this._labelMap[this._value] || ""
                }
                getLabel() {
                    return this._labelMap[this._value] || ""
                }
                getElement() {
                    return this._el
                }
                update(e, t) {
                    this._updateValue(e, t), this._render()
                }
                setTooltipEnabled(e = !1) {
                    this._showTooltip !== e && (this._showTooltip = e, this._renderTooltip())
                }
                enableShortMode() {
                    !0 !== this._shortMode && (this._shortMode = !0, this._render())
                }
                disableShortMode() {
                    !1 !== this._shortMode && (this._shortMode = !1, this._render())
                }
                isShortModeEnabled() {
                    return this._shortMode
                }
                start() {
                    !this._subscribed && this._symbolName && (this._quoteSession || (this._quoteSession = (0, s.getQuoteSessionInstance)("simple")), this._quoteSession.subscribe(this._getQuoteSessionId(), this._symbolName, this.update.bind(this)), this._subscribed = !0)
                }
                stop() {
                    this._subscribed && this._quoteSession && this._symbolName && (this._quoteSession.unsubscribe(this._getQuoteSessionId(), this._symbolName), this._subscribed = !1)
                }
                _init(e) {
                    this._el = e.el ? e.el : document.createElement("span"), this._el.innerHTML = "", this._classMap = e.classMap, this._labelMap = e.labelMap, this._showTooltip = e.showTooltip, this._classSuffix = e.classSuffix, this._symbolName = e.symbol, e.tooltipType && (this._tooltipType = e.tooltipType), this._quoteSessionGUID = (0, n.guid)(), !0 === e.short && this.enableShortMode(), e.data && this._updateValue(e.data)
                }
                _clearClasses() {
                    Object.values(this._classMap).map(e => {
                        this._el.classList.remove("" + e), this._el.classList.remove(`${e}${this._classSuffix}`)
                    })
                }
                _render() {
                    this._renderClasses(), this._renderTooltip(), this._renderLabel()
                }
                _renderLabel() {
                    this._el.textContent = this.getLabel()
                }
                _updateValue(e, t) {
                    const r = this._getValueFromData(e);
                    (t || r !== this._value) && (this._value = r)
                }
                _renderClasses() {
                    const e = this._el.classList;
                    e.add(this._componentClass, this._componentClass + this._classSuffix);
                    const t = this._classMap[this._value];
                    for (const r in this._classMap) {
                        const a = this._classMap[r];
                        a && (a === t ? e.add(a, a + this._classSuffix) : e.remove(a, a + this._classSuffix))
                    }!t && this._value && o.logWarn("no className for status " + this._value)
                }
                _renderTooltip() {
                    const e = this._showTooltip ? this.getTooltipText() : "";
                    e !== this._lastTooltipText && (this._lastTooltipText = e, this._el.setAttribute("title", e), "custom" === this._tooltipType && this._el.classList.toggle("apply-common-tooltip", this._showTooltip))
                }
                _getQuoteSessionId() {
                    return `${this._quoteSessionPrefix}.${this._quoteSessionGUID}`
                }
            }
        },
        78100: (e, t, r) => {
            "use strict";
            r.d(t, {
                DataModeIndicator: () => c
            });
            var a = r(25177),
                n = (r(35897), r(46673), r(9970));
            const s = {
                    connecting: (0, a.t)("Connecting"),
                    delayed: (0, a.t)("Delayed"),
                    delayed_streaming: (0, a.t)("Delayed"),
                    endofday: (0, a.t)("End of Day"),
                    forbidden: (0, a.t)("Instrument is not allowed"),
                    realtime: (0, a.t)("Real-time"),
                    snapshot: (0, a.t)("Snapshot"),
                    loading: "",
                    replay: (0, a.t)("Replay Mode")
                },
                o = {
                    connecting: (0, a.t)("C", {
                        context: "data_mode_connecting_letter"
                    }),
                    delayed: (0, a.t)("D", {
                        context: "data_mode_delayed_letter"
                    }),
                    delayed_streaming: (0, a.t)("D", {
                        context: "data_mode_delayed_streaming_letter"
                    }),
                    endofday: (0, a.t)("E", {
                        context: "data_mode_end_of_day_letter"
                    }),
                    forbidden: (0, a.t)("F", {
                        context: "data_mode_forbidden_letter"
                    }),
                    realtime: (0, a.t)("R", {
                        context: "data_mode_realtime_letter"
                    }),
                    snapshot: (0, a.t)("S", {
                        context: "data_mode_snapshot_letter"
                    }),
                    loading: "",
                    replay: (0, a.t)("R", {
                        context: "data_mode_replay_letter"
                    })
                },
                i = {
                    streaming: "realtime"
                },
                l = {
                    classMap: {
                        connecting: "tv-data-mode--connecting",
                        delayed: "tv-data-mode--delayed",
                        delayed_streaming: "tv-data-mode--delayed",
                        endofday: "tv-data-mode--endofday",
                        forbidden: "tv-data-mode--forbidden",
                        realtime: "tv-data-mode--realtime",
                        snapshot: "tv-data-mode--snapshot",
                        loading: "tv-data-mode--loading",
                        replay: "tv-data-mode--replay"
                    },
                    classSuffix: "",
                    data: {
                        values: {
                            update_mode: "connecting"
                        }
                    },
                    labelMap: s,
                    modeInterval: 600,
                    short: !1,
                    shortLabelMap: o,
                    showTooltip: !0,
                    tooltipType: "custom"
                };
            class c extends n.AbstractIndicator {
                constructor(e) {
                    super(e), this._quoteSessionPrefix = "data-mode-indicator", this._componentClass = "tv-data-mode", this._init(e)
                }
                getLabel() {
                    return !0 === this._shortMode ? this._shortLabelMap[this._value] || "" : super.getLabel()
                }
                setMode(e, t) {
                    this.update({
                        values: {
                            update_mode: e,
                            update_mode_seconds: t
                        }
                    })
                }
                hide() {
                    this._el.classList.add("i-hidden")
                }
                show() {
                    this._el.classList.remove("i-hidden")
                }
                getTooltipText() {
                    let e = "";
                    const t = this.getValue();
                    if ("" === t) return e;
                    switch (t) {
                        case "delayed":
                            e = (0, a.t)("Quotes are delayed by {number} min and updated every 30 seconds");
                            break;
                        case "delayed_streaming":
                            e = (0, a.t)("Quotes are delayed by {number} min");
                            break;
                        default:
                            e = this._labelMap[t] || e
                    }
                    return ["delayed", "delayed_streaming"].includes(t) && (e = e.format({
                        number: String(Math.round(this._modeInterval / 60))
                    })), e
                }
                _init(e = {}) {
                    const t = Object.assign({}, l, e);
                    this._modeInterval = t.modeInterval || 600, this._shortLabelMap = t.shortLabelMap || o, super._init(t), this._render()
                }
                _getValueFromData(e) {
                    let t;
                    return t = void 0 !== e.values && void 0 !== e.values.update_mode ? e.values.update_mode : this.getValue(), i[t] || t
                }
                _updateValue(e, t) {
                    void 0 !== e.values && void 0 !== e.values.update_mode_seconds && (this._modeInterval = e.values.update_mode_seconds), super._updateValue(e, t)
                }
            }
        },
        73288: (e, t, r) => {
            "use strict";
            r.d(t, {
                OverlayScrollContainer: () => h
            });
            var a = r(59496),
                n = r(97754),
                s = r.n(n),
                o = r(88537),
                i = r(97280),
                l = r(34581);
            const c = r(62230);

            function u(e) {
                const {
                    size: t,
                    scrollSize: r,
                    clientSize: n,
                    scrollProgress: u,
                    onScrollProgressChange: d,
                    horizontal: m,
                    theme: h = c,
                    onDragStart: p,
                    onDragEnd: f,
                    minBarSize: g = 40
                } = e, v = (0, a.useRef)(null), _ = (0, a.useRef)(null), [b, y] = (0, a.useState)(!1), P = (0, a.useRef)(0);
                (0, a.useEffect)(() => {
                    const e = (0, o.ensureNotNull)(v.current).ownerDocument;
                    return b ? (p && p(), e && (e.addEventListener("mousemove", k), e.addEventListener("mouseup", M))) : f && f(), () => {
                        e && (e.removeEventListener("mousemove", k), e.removeEventListener("mouseup", M))
                    }
                }, [b]);
                const E = t / r || 0,
                    w = n * E || 0,
                    N = Math.max(w, g),
                    S = (t - N) / (t - w),
                    x = function(e) {
                        if ((0, l.isRtl)() && m) return e - r + n;
                        return e
                    }((0, i.clamp)(u, 0, r - t));
                return a.createElement("div", {
                    ref: v,
                    className: s()(h.wrap, m && h["wrap--horizontal"]),
                    style: {
                        [m ? "width" : "height"]: t
                    },
                    onMouseDown: function(e) {
                        if (e.isDefaultPrevented()) return;
                        e.preventDefault();
                        const a = (0, o.ensureNotNull)(_.current).getBoundingClientRect();
                        P.current = (m ? a.width : a.height) / 2;
                        const n = r - t;
                        let s = F(e.nativeEvent, (0, o.ensureNotNull)(v.current)) - P.current;
                        s < 0 ? (s = 0, P.current = F(e.nativeEvent, (0, o.ensureNotNull)(v.current))) : s > n * E * S && (s = n * E * S,
                            P.current = F(e.nativeEvent, (0, o.ensureNotNull)(v.current)) - s);
                        d(s / E / S), y(!0)
                    }
                }, a.createElement("div", {
                    ref: _,
                    className: s()(h.bar, m && h["bar--horizontal"]),
                    style: {
                        [m ? "minWidth" : "minHeight"]: g,
                        [m ? "width" : "height"]: N,
                        transform: `translate${m?"X":"Y"}(${x*E*S||0}px)`
                    },
                    onMouseDown: function(e) {
                        e.preventDefault(), P.current = F(e.nativeEvent, (0, o.ensureNotNull)(_.current)), y(!0)
                    }
                }, a.createElement("div", {
                    className: s()(h.barInner, m && h["barInner--horizontal"])
                })));

                function k(e) {
                    const t = F(e, (0, o.ensureNotNull)(v.current)) - P.current;
                    d(t / E / S)
                }

                function M(e) {
                    y(!1)
                }

                function F(e, t) {
                    const r = t.getBoundingClientRect();
                    return m ? e.clientX - r.left : e.clientY - r.top
                }
            }
            var d = r(21258),
                m = r(97623);

            function h(e) {
                const {
                    reference: t,
                    className: r,
                    containerHeight: s = 0,
                    containerWidth: o = 0,
                    contentHeight: i = 0,
                    contentWidth: l = 0,
                    scrollPosTop: c = 0,
                    scrollPosLeft: h = 0,
                    onVerticalChange: p,
                    onHorizontalChange: f,
                    visible: g
                } = e, [v, _] = (0, d.useHover)(), [b, y] = (0, a.useState)(!1), P = s < i, E = o < l, w = P && E ? 8 : 0;
                return a.createElement("div", { ..._,
                    ref: t,
                    className: n(r, m.scrollWrap),
                    style: {
                        visibility: g || v || b ? "visible" : "hidden"
                    }
                }, P && a.createElement(u, {
                    size: s - w,
                    scrollSize: i - w,
                    clientSize: s - w,
                    scrollProgress: c,
                    onScrollProgressChange: function(e) {
                        p && p(e)
                    },
                    onDragStart: N,
                    onDragEnd: S
                }), E && a.createElement(u, {
                    size: o - w,
                    scrollSize: l - w,
                    clientSize: o - w,
                    scrollProgress: h,
                    onScrollProgressChange: function(e) {
                        f && f(e)
                    },
                    onDragStart: N,
                    onDragEnd: S,
                    horizontal: !0
                }));

                function N() {
                    y(!0)
                }

                function S() {
                    y(!1)
                }
            }
        },
        20182: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                DetailsWrapper: () => xe
            });
            var a = r(59496),
                n = r(87995),
                s = r(97754),
                o = r.n(s),
                i = r(26800);

            function l(e) {
                const t = (0, a.useRef)(null);
                return (0, a.useEffect)(() => {
                    t.current = e
                }, [e]), t.current
            }

            function c(e, t) {
                const r = (0, a.useRef)(null),
                    [n, s] = (0, a.useState)(!1),
                    o = l(e);
                return (0, a.useEffect)(() => {
                    t && null !== r.current && (clearTimeout(r.current), r.current = null, s(!0))
                }, [t]), (0, a.useEffect)(() => (e !== o && (s(!1), r.current = setTimeout(() => s(!0), 500)), () => {
                    null !== r.current && (clearTimeout(r.current), r.current = null)
                }), [e]), t || n
            }
            var u = r(82527),
                d = r(40976),
                m = r(88537);
            const h = (0, a.createContext)(null);
            var p = r(25271);

            function f(e) {
                const {
                    complete: t,
                    logoId: r,
                    symbolName: s,
                    baseCurrencyLogoId: o,
                    currencyLogoId: l,
                    earningsReleaseNextDate: u,
                    earningsPerShareForecastNextFq: f,
                    earningsReleaseNextCalendarDate: g,
                    disabledSet: v,
                    onDisabledSetChange: _
                } = e, {
                    header: b
                } = (0, d.useEnsuredContext)(h);
                c(s, Boolean(t));
                return n.createPortal(a.createElement("div", {
                    className: p.container
                }, !1, a.createElement("span", {
                    className: p.title
                }, (0, i.safeShortName)(s)), !1), (0, m.ensureNotNull)(b))
            }
            var g = r(25177),
                v = r(12777);
            var _ = r(29549);

            function b(e) {
                const {
                    value: t,
                    formatter: r,
                    className: n
                } = e, s = (0, a.useRef)(null), i = l(t), c = function(e) {
                    const t = l(e),
                        r = (0, a.useRef)(null);
                    return (0, a.useEffect)(() => {
                        t !== e && (r.current = t)
                    }, [e]), r.current
                }(t), u = (0, a.useCallback)(() => {
                    null !== s.current && (clearTimeout(s.current), s.current = null)
                }, []), [d, m] = (0, a.useState)(n), [h, p] = (0, a.useMemo)(() => {
                    if (void 0 === t || !r) return ["", ""];
                    if (null == c) return [r.format(t), ""];
                    const e = r.format(c),
                        a = r.format(t),
                        n = Math.min(e.length, a.length);
                    let s = 0;
                    for (; s < n && e.charAt(s) === a.charAt(s);) s++;
                    return [a.slice(0, s), a.slice(s)]
                }, [t, c, r]);
                (0, a.useEffect)(() => u, []), (0, a.useEffect)(() => {
                    if (void 0 === t || null == i) return void m(n);
                    i !== t && (u(), s.current = setTimeout(() => m(n), 500), m(o()(n, t > i && _.growing, t < i && _.falling)))
                }, [t, i, n]);
                const f = c || i;
                return a.createElement("span", {
                    className: o()(_.highlight, d)
                }, h, !!p.length && a.createElement("span", {
                    className: o()(_.highlight, t && f && t > f && _.growing, t && f && t < f && _.falling)
                }, (null == r ? void 0 : r.hasForexAdditionalPrecision()) ? a.createElement(a.Fragment, null, p.slice(0, p.length - 1), a.createElement("sup", null, p.slice(p.length - 1))) : p))
            }

            function y(e) {
                return e ? o()(_.highlight, e > 0 ? _.growing : _.falling) : ""
            }
            var P = r(78100),
                E = r(42419),
                w = r(75305);
            const N = new E.PercentageFormatter;

            function S(e) {
                const {
                    change: t,
                    changePercent: r,
                    priceFormatter: n,
                    changeClassName: s
                } = e;
                return a.createElement("span", null, void 0 !== t && a.createElement("span", {
                    className: o()(w.change, s, y(t))
                }, null == n ? void 0 : n.format(t)), a.createElement("span", {
                    className: o()(w.change, s, y(r))
                }, void 0 !== r && `(${N.format(r)})`))
            }
            var x = r(63997);

            function k(e) {
                const {
                    className: t,
                    symbol: r,
                    updateMode: n,
                    updateModeSeconds: s,
                    currency: i,
                    lastPrice: l,
                    change: c,
                    changePercent: u,
                    priceFormatter: d
                } = e, m = (0, a.useRef)(null), h = (0, a.useRef)(null);
                return (0, a.useEffect)(() => (null !== m.current && (h.current = new P.DataModeIndicator({
                    classSuffix: "--for-details",
                    el: m.current,
                    short: !0,
                    symbol: r,
                    manualUpdate: !0
                })), () => {
                    h.current = null
                }), []), (0, a.useEffect)(() => {
                    const e = h.current;
                    null !== e && (void 0 === n ? e.hide() : (e.show(), e.update({
                        values: {
                            update_mode: n,
                            update_mode_seconds: s
                        }
                    })))
                }, [n, s]), a.createElement("div", {
                    className: o()(x.container, t)
                }, a.createElement("span", {
                    className: x.priceWrapper
                }, a.createElement(b, {
                    key: r,
                    className: x.price,
                    value: l,
                    formatter: d
                }), a.createElement("span", {
                    className: x.info
                }, a.createElement("span", {
                    className: x.mode,
                    ref: m
                }), a.createElement("span", {
                    className: x.currency
                }, i))), a.createElement(S, {
                    change: c,
                    changePercent: u,
                    priceFormatter: d
                }))
            }
            var M = r(72571),
                F = r(26434),
                L = r(67184),
                T = r(8574),
                W = r(22341);
            const C = new E.PercentageFormatter;

            function D(e) {
                const {
                    className: t,
                    currentSession: r,
                    lastPriceTime: n,
                    extraHoursPrice: s,
                    extraHoursChange: i,
                    extraHoursChangePercent: l,
                    priceFormatter: c,
                    dateFormatter: u
                } = e, d = "market" === r, m = "pre_market" === r, h = m || "post_market" === r;
                return a.createElement("div", {
                    className: t
                }, a.createElement("div", {
                    className: o()(W.status, d ? W.open : W.close)
                }, !h && a.createElement("span", {
                    className: W.dot
                }), a.createElement("span", {
                    className: o()(W.text, !h && W.textWithIcon)
                }, h ? (0, g.t)("At close") : I(r)), n && !d && a.createElement("span", {
                    className: o()(W.text, !h && W.lastPriceTimeWithIcon)
                }, "(", u.format(n), ")")), h && a.createElement(a.Fragment, null, null != i && a.createElement("div", {
                    className: o()(W.lastPrice, i < 0 && W.minus, i > 0 && W.plus)
                }, a.createElement("span", {
                    className: W.price
                }, s && (null == c ? void 0 : c.format(s))), a.createElement("span", {
                    className: W.changeWrap
                }, a.createElement("span", {
                    className: W.change
                }, null == c ? void 0 : c.format(i)), null != l && a.createElement("span", {
                    className: W.changePercent
                }, "(", C.format(l), ")"))), a.createElement("div", {
                    className: o()(W.extra, m ? W.pre : W.post)
                }, a.createElement(M.Icon, {
                    className: W.icon,
                    icon: z(r)
                }), a.createElement("span", {
                    className: W.label
                }, I(r)), null == s && a.createElement(a.Fragment, null, a.createElement("span", {
                    className: W.separator
                }), a.createElement("span", {
                    className: W.label
                }, (0, g.t)("No trades"))))))
            }

            function z(e) {
                switch (e) {
                    case "pre_market":
                        return F;
                    case "holiday":
                    case "out_of_session":
                        return L;
                    case "post_market":
                        return T;
                    default:
                        return
                }
            }

            function I(e) {
                switch (e) {
                    case "market":
                        return (0, g.t)("Market Open");
                    case "out_of_session":
                        return (0, g.t)("Market Closed");
                    case "pre_market":
                        return (0, g.t)("Pre Market");
                    case "post_market":
                        return (0, g.t)("Post Market");
                    case "holiday":
                        return (0, g.t)("Holiday");
                    default:
                        return
                }
            }
            r(32133);
            var H = r(6058);

            function R(e) {
                return a.createElement("div", {
                    className: o()(H.dotWrap, e.className)
                }, a.createElement("div", {
                    className: H.dot
                }))
            }

            function B(e) {
                const {
                    description: t,
                    exchange: r,
                    additionalMain: n,
                    additionalSecondary: s,
                    invalid: o,
                    symbolPagePath: i
                } = e;
                return o ? a.createElement("div", null, a.createElement("span", {
                    className: H.invalid
                }, t)) : a.createElement(a.Fragment, null, a.createElement("div", null, a.createElement("span", {
                    className: H.main
                }, t, r && a.createElement(R, {
                    className: H.smallMargin
                }), a.createElement("span", {
                    "data-name": "details-exchange"
                }, r))), (n || s) && a.createElement("div", null, a.createElement("span", {
                    className: H.additional
                }, n && a.createElement("span", {
                    className: H.additionalText,
                    "data-name": "details-additional-main"
                }, n), s && a.createElement(a.Fragment, null, a.createElement(R, null), a.createElement("span", {
                    className: H.additionalText,
                    "data-name": "details-additional-secondary"
                }, s)))))
            }
            const V = new Set(["stock", "fund", "dr", "right", "warrant"]);

            function q(e) {
                const {
                    price: t,
                    priceFormatter: r,
                    size: n,
                    className: s
                } = e;
                if (r && t) {
                    const e = r.hasForexAdditionalPrecision(),
                        o = r.format(t);
                    if (e) {
                        const e = o.toString();
                        return a.createElement("span", {
                            className: s
                        }, e.slice(0, e.length - 1), a.createElement("sup", null, e.slice(e.length - 1)), !!n && a.createElement("span", null, "×" + n))
                    }
                    return a.createElement("span", {
                        className: s
                    }, o, !!n && a.createElement("span", null, "×" + n))
                }
                return a.createElement("span", {
                    className: s
                }, t)
            }
            var J = r(18618);

            function A(e) {
                const {
                    className: t,
                    priceFormatter: r,
                    bid: n,
                    ask: s,
                    bidSize: i,
                    askSize: l
                } = e;
                return a.createElement("div", {
                    className: o()(J.container, t)
                }, a.createElement(q, {
                    price: n,
                    priceFormatter: r,
                    size: i,
                    className: J.bid
                }), a.createElement(q, {
                    price: s,
                    priceFormatter: r,
                    size: l,
                    className: J.ask
                }))
            }
            var O = r(34581),
                K = r(1855),
                j = r(72645);

            function $(e) {
                const {
                    lowPrice: t,
                    highPrice: r,
                    priceFormatter: n,
                    title: s,
                    open: i,
                    close: l,
                    lastPrice: c,
                    dataName: u
                } = e, d = r - t, m = (Math.min(l, i) - t) / d * 100, h = (Math.max(l, i) - t) / d * 100, p = l < i, f = m <= 1, g = h >= 99, v = 100 * (c - t) / d, _ = {
                    width: h - m + "%"
                }, b = {};
                (0, O.isRtl)() ? (_.right = m + "%", b.right = v + "%") : (_.left = m + "%", b.left = v + "%");
                const y = o()(j.bar, p && j.low, f && j.roundedLeft, g && j.roundedRight),
                    P = o()(j.arrow, f && j.extraMargin);
                return a.createElement("div", {
                    className: j.container,
                    "data-name": u
                }, a.createElement("div", {
                    className: j.header
                }, t && a.createElement(q, {
                    price: t,
                    priceFormatter: n,
                    className: j.price
                }), a.createElement("span", {
                    className: j.title
                }, s), r && a.createElement(q, {
                    price: r,
                    priceFormatter: n,
                    className: j.price
                })), a.createElement("div", {
                    className: j.range
                }, a.createElement("div", {
                    className: y,
                    style: _
                })), a.createElement("div", {
                    className: j.arrowContainer
                }, a.createElement("div", {
                    className: P,
                    style: b,
                    dangerouslySetInnerHTML: {
                        __html: K
                    }
                })))
            }

            function U(e) {
                const {
                    openPrice: t,
                    lastPrice: r,
                    lowPrice: n,
                    highPrice: s,
                    price52WeekHigh: o,
                    price52WeekLow: i,
                    priceFormatter: l
                } = e, c = !(!t || !r) && t > r, u = c ? s : n, d = c ? n : s, m = s && o ? Math.max(s, o) : o, h = n && i ? Math.min(n, i) : i;
                return a.createElement($, {
                    dataName: "details-52wk-range",
                    lowPrice: h,
                    highPrice: m,
                    priceFormatter: l,
                    title: (0, g.t)("52wk Range"),
                    open: u,
                    close: d,
                    lastPrice: r
                })
            }

            function Y(e) {
                const {
                    className: t,
                    priceFormatter: r
                } = e;
                return a.createElement("div", {
                    className: t
                }, Q(e) && a.createElement($, {
                    dataName: "details-days-range",
                    title: (0, g.t)("Day's Range"),
                    lowPrice: e.lowPrice,
                    highPrice: e.highPrice,
                    priceFormatter: r,
                    open: e.openPrice,
                    close: e.lastPrice,
                    lastPrice: e.lastPrice
                }), X(e) && a.createElement(U, {
                    openPrice: e.openPrice,
                    lastPrice: e.lastPrice,
                    lowPrice: e.lowPrice,
                    highPrice: e.highPrice,
                    price52WeekHigh: e.price52WeekHigh,
                    price52WeekLow: e.price52WeekLow,
                    priceFormatter: r
                }))
            }

            function X(e) {
                const {
                    openPrice: t,
                    lastPrice: r,
                    lowPrice: a,
                    highPrice: n,
                    price52WeekHigh: s,
                    price52WeekLow: o
                } = e;
                return void 0 !== t && void 0 !== r && void 0 !== a && void 0 !== n && void 0 !== o && void 0 !== s
            }

            function Q(e) {
                const {
                    openPrice: t,
                    lastPrice: r,
                    lowPrice: a,
                    highPrice: n
                } = e;
                return void 0 !== t && void 0 !== r && void 0 !== a && void 0 !== n
            }
            var G = r(1397),
                Z = r(76099),
                ee = r(52647),
                te = r(89963);
            const re = {
                dateFormat: "MMM dd",
                timeFormat: "%h:%m"
            };
            class ae {
                constructor(e = {}) {
                    this._dateFormatter = null, this._timeFormatter = null, this._options = Object.assign({}, re, e), "" !== this._options.dateFormat && (this._dateFormatter = new ee.DateFormatter(this._options.dateFormat)), this._options.timeFormat.length > 0 && (this._timeFormatter = new te.TimeFormatter(this._options.timeFormat)), this._timezone = this._options.timezone
                }
                format(e) {
                    void 0 === this._tzOffset && void 0 !== this._timezone && (this._tzOffset = (0, Z.parseTzOffset)(this._timezone, 1e3 * e));
                    const t = this._tzOffset ? this._tzOffset : {
                            offset: 0,
                            string: "UTC"
                        },
                        r = 1e3 * e + t.offset,
                        a = new Date(r),
                        n = [];
                    if (null !== this._dateFormatter && n.push(this._dateFormatter.format(a)), null !== this._timeFormatter) {
                        const e = this._timeFormatter.format(a);
                        n.push(e)
                    }
                    return n.push(t.string), n.join(" ")
                }
                setTimezone(e) {
                    this._timezone = e, this._tzOffset = void 0
                }
            }
            var ne = r(70981),
                se = r(73288),
                oe = r(39043),
                ie = r(21789);

            function le(e) {
                const {
                    children: t,
                    className: r,
                    reference: n,
                    hasCustomTouchScrollAnimation: s,
                    scrollContainerRef: i,
                    ...l
                } = e, [c, u, d, m] = (0, oe.useOverlayScroll)(i, s);
                return (0, a.useImperativeHandle)(n, () => ({
                    updateScrollState: m
                })), a.createElement("div", { ...l,
                    ...u,
                    className: o()(ie.container, r)
                }, a.createElement(se.OverlayScrollContainer, { ...c,
                    className: ie.overlayScrollWrap
                }), a.createElement("div", {
                    className: ie.wrapper,
                    ref: function(e) {
                        d.current = e
                    },
                    onScroll: m
                }, t))
            }
            var ce = r(51951),
                ue = r(31419);
            const de = (0,
                    ce.getLogger)("Details"),
                me = ["Description", "Price", "MarketStatus", "BidAndAsk", "Ranges", "FuturesChart", "KeyStats", "Earnings", "Financials", "Dividends", "MoreFinancials", "Performance", "Technicals", "AnalystRecommendations", "Profile"],
                he = new Set(["BidAndAsk", "FuturesChart"]),
                pe = new Map;
            for (let e = 0; e < me.length; e++) pe.set(me[e], e);

            function fe(e) {
                const [t, r] = (0, a.useState)(!0), n = c(e.symbol, Boolean(e.complete)), s = function(e, t) {
                    const r = l(e),
                        n = (0, a.useRef)(null);
                    return (t = null != t ? t : (e, t, r) => e !== t && t !== r)(n.current, r, e) && (n.current = r), n.current
                }(e, (function(e, t, r) {
                    if (null === e && !Ye(r) && Ye(t)) return !0;
                    if (!Ye(r) || !Ye(t)) return !1;
                    return (null == e ? void 0 : e.symbol) !== (null == t ? void 0 : t.symbol) && (null == t ? void 0 : t.symbol) !== r.symbol
                })), i = Ue() ? e : (0, m.ensureNotNull)(s), {
                    className: u,
                    isDialog: d,
                    complete: h,
                    descriptionClassName: p,
                    volume: f,
                    averageVolume: _,
                    averageVolume10dCalc: b,
                    currentSession: y,
                    updateMode: P,
                    updateModeSeconds: E,
                    lastPrice: w,
                    contracts: N,
                    change: S,
                    changePercent: x,
                    currency: M,
                    fundamentalCurrencyCode: F,
                    lastPriceTime: L,
                    extraHoursPrice: T,
                    extraHoursChange: W,
                    extraHoursChangePercent: C,
                    timezone: z,
                    proName: I,
                    shortName: H,
                    type: R,
                    typespecs: V,
                    symbolDescription: q,
                    exchange: J,
                    listedExchange: O,
                    invalid: K,
                    marketCap: j,
                    basicEarningsTTM: $,
                    dividendsYield: U,
                    priceToEarningsRatioTTM: X,
                    employees: Q,
                    floatShares: Z,
                    showTechnicalsDialog: ee,
                    performance: te,
                    widgetWidth: re,
                    symbol: se,
                    pricescale: oe,
                    minMovePrimary: ie,
                    minMoveSecondary: ce,
                    fractional: fe,
                    summaryCoefficient: _e,
                    openPrice: be,
                    lowPrice: ye,
                    highPrice: Pe,
                    price52WeekHigh: Ee,
                    price52WeekLow: we,
                    bid: Ne,
                    ask: Se,
                    bidSize: xe,
                    askSize: ke,
                    financialsData: Me,
                    incomeData: Fe,
                    websiteUrl: Le,
                    businessDescription: Te,
                    newsPreview: We,
                    primaryName: Ce,
                    notesStatus: De,
                    symbolNotes: ze,
                    priceTargetAverage: Ie,
                    recommendationMark: He,
                    ratesPtToSymbol: Re,
                    disabledSet: Be,
                    dividendsData: Ve
                } = i, qe = (0, a.useRef)(new Map), Je = (0, a.useRef)(new Map), {
                    additionalMain: Ae,
                    additionalSecondary: Oe
                } = ve(i), Ke = J, je = (0, a.useMemo)(() => new G.PriceFormatter(oe, ie, fe, ce), [oe, ie, fe, ce]), $e = (0, a.useMemo)(() => {
                    const e = new ae;
                    return z && e.setTimezone(z), e
                }, [z]);
                return (0, a.useEffect)(() => {
                    n && (qe.current.forEach((e, t) => {
                        de.logDebug(`${t} render reason: ${e}`)
                    }), Je.current.forEach((e, t) => {
                        de.logDebug(`${t} were blocked by ${JSON.stringify(Array.from(e))}`)
                    }))
                }, [n]), (0, a.useEffect)(() => {
                    qe.current = new Map, Je.current = new Map
                }, [e.symbol]), a.createElement(le, {
                    className: o()(u, !t && ue.hiddenWrapper, !Ue() && ue.opacity),
                    onContextMenu: v.preventDefaultForContextMenu,
                    onScrollCapture: function() {
                        ne.globalCloseDelegate.fire()
                    }
                }, (!Ue() || (ge("Description", i) || n)) && a.createElement("div", {
                    className: o()(ue.widgetWrapper, p)
                }, K ? a.createElement(B, {
                    description: (0, g.t)("Invalid symbol"),
                    invalid: K
                }) : a.createElement(B, {
                    description: q,
                    exchange: Ke,
                    symbolPagePath: void 0,
                    additionalMain: Ae,
                    additionalSecondary: Oe
                })), !1, !1, Xe("Price") && a.createElement(k, {
                    className: o()(ue.widgetWrapper, y && ue.offsetDisabled),
                    updateMode: P,
                    updateModeSeconds: E,
                    symbol: se,
                    priceFormatter: je,
                    lastPrice: w,
                    change: S,
                    changePercent: x,
                    currency: M
                }), Xe("MarketStatus") && y && a.createElement(D, {
                    className: ue.widgetWrapper,
                    currentSession: y,
                    priceFormatter: je,
                    dateFormatter: $e,
                    lastPriceTime: L,
                    extraHoursPrice: T,
                    extraHoursChange: W,
                    extraHoursChangePercent: C
                }), Xe("BidAndAsk") && a.createElement(A, {
                    className: ue.widgetWrapper,
                    bid: Ne,
                    bidSize: xe,
                    ask: Se,
                    askSize: ke,
                    priceFormatter: je
                }), Xe("Ranges") && a.createElement(Y, {
                    className: ue.widgetWrapper,
                    openPrice: be,
                    lastPrice: w,
                    lowPrice: ye,
                    highPrice: Pe,
                    price52WeekHigh: Ee,
                    price52WeekLow: we,
                    priceFormatter: je
                }), !1);

                function Ue() {
                    return Ye(e) || null === s
                }

                function Ye(e) {
                    return null !== e && (ge("Description", e) || n)
                }

                function Xe(e) {
                    if (n && ge(e, i)) return qe.current.has(e) || qe.current.set(e, h ? "complete" : "timeout"), !0;
                    const t = me.slice(0, (0, m.ensureDefined)(pe.get(e))).filter(e => !he.has(e)),
                        r = !Ue() || t.every(e => ge(e, i)),
                        a = r && ge(e, i);
                    if (!r && ge(e, i)) {
                        const r = t.find(e => !ge(e, i));
                        if (void 0 !== r) {
                            const t = Je.current.get(e);
                            t ? t.add(r) : Je.current.set(e, new Set([r]))
                        }
                    }
                    return a && !qe.current.has(e) && qe.current.set(e, "data exist"), a
                }
            }

            function ge(e, t) {
                switch (t.disabledSet, e) {
                    case "Description":
                        return t.invalid || Boolean(ve(t).additionalMain);
                    case "Price":
                        return void 0 !== t.lastPrice;
                    case "MarketStatus":
                        return u.enabled("display_market_status") && Boolean(t.currentSession);
                    case "BidAndAsk":
                        return Boolean(t.bid) && Boolean(t.ask);
                    case "Ranges":
                        return Q(t) || X(t);
                    case "FuturesChart":
                        return Boolean(t.contracts && t.contracts.length > 0);
                    case "KeyStats":
                        return hasKeyStats(t.type, t.typespecs);
                    case "Earnings":
                        return Boolean(t.incomeData);
                    case "Dividends":
                        return Boolean(t.dividendsData);
                    case "Financials":
                        return Boolean(t.financialsData && t.financialsData[PeriodId.Year]);
                    case "MoreFinancials":
                        return !1;
                    case "Performance":
                        return checkPerformanceVisible(t.performance);
                    case "Technicals":
                        return void 0 !== t.summaryCoefficient;
                    case "AnalystRecommendations":
                        return !1;
                    case "Profile":
                        return Boolean(t.websiteUrl || t.businessDescription || t.employees);
                    default:
                        return !1
                }
            }

            function ve(e) {
                const {
                    type: t,
                    proName: r,
                    sector: a,
                    industry: n
                } = e, s = t && V.has(t), o = r && a || "";
                return {
                    additionalMain: s ? (0, g.t)(o) : function(e) {
                        const {
                            proName: t,
                            type: r,
                            typespecs: a,
                            country: n,
                            sector: s
                        } = e, o = t && n || "", i = t && s || "";
                        let l;
                        0;
                        switch (r) {
                            case "equity":
                                l = (0, g.t)("Equity");
                                break;
                            case "futures":
                                l = (0, g.t)("Futures");
                                break;
                            case "index":
                                l = (0, g.t)("Index");
                                break;
                            case "spread":
                                l = (0, g.t)("Composite Symbols");
                                break;
                            case "economic":
                                l = (0, g.t)("Economy");
                                break;
                            case "cfd":
                                l = "CFD";
                                break;
                            case "bond":
                                l = "Bond";
                                break;
                            case "forex":
                                let e;
                                switch (i) {
                                    case "Minor":
                                        e = (0, g.t)("Minor", {
                                            context: "currency"
                                        });
                                        break;
                                    case "Major":
                                        e = (0, g.t)("Major", {
                                            context: "currency"
                                        });
                                        break;
                                    case "Exotic":
                                        e = (0, g.t)("Exotic");
                                        break;
                                    default:
                                        e = i
                                }
                                e && (l = (0, g.t)("Forex {sector}: {country}").replace("{sector}", e).replace("{country}", (0, g.t)(o)))
                        }
                        return l
                    }(e),
                    additionalSecondary: s ? (0, g.t)(n || "") : void 0
                }
            }
            var _e = r(97265);

            function be(e) {
                const {
                    bridge: t
                } = (0, d.useEnsuredContext)(h), {
                    detailsHeaderProps: r,
                    detailsInfoProps: n,
                    newsPreview: s
                } = e, o = (0, _e.useWatchedValueReadonly)({
                    watchedValue: (0, m.ensureDefined)(t).width
                }), [i, l] = [];
                return a.createElement(a.Fragment, null, r && a.createElement(f, {
                    disabledSet: i,
                    onDisabledSetChange: l,
                    ...r
                }), n && a.createElement(fe, { ...n,
                    newsPreview: s,
                    widgetWidth: o,
                    symbolNotes: void 0,
                    notesStatus: void 0,
                    disabledSet: i
                }))
            }
            var ye = r(16345),
                Pe = r(21162),
                Ee = r(64858);

            function we(e) {
                return {
                    symbolName: e
                }
            }

            function Ne(e) {
                return {
                    source: "RightToolbar",
                    symbol: e
                }
            }

            function Se(e) {
                const {
                    bridge: t
                } = (0, d.useEnsuredContext)(h), r = (0, _e.useWatchedValueReadonly)({
                    watchedValue: (0, m.ensureDefined)(t).symbol
                }, !0), [n, s] = function(e) {
                    const [t, r] = (0, a.useState)(() => we(e)), [n, s] = (0, a.useState)(() => Ne(e));
                    return (0, a.useEffect)(() => {
                        if (r(() => we(e)), s(() => Ne(e)), !e) return;
                        const t = (0, ye.guid)(),
                            a = (0, Pe.getQuoteSessionInstance)("full");
                        return a.subscribe(t, e, (function(e) {
                            const {
                                average_volume: t,
                                last_price: r,
                                open_price: a,
                                low_price: n,
                                high_price: o,
                                ask: i,
                                bid: l,
                                pricescale: c,
                                volume: u,
                                short_name: d,
                                minmov: m,
                                minmove2: h,
                                fractional: p,
                                change: f,
                                change_percent: g,
                                current_session: v,
                                exchange: _,
                                pro_name: b,
                                type: y,
                                sector: P,
                                industry: E
                            } = e.values;
                            s(s => ({ ...s,
                                averageVolume: t,
                                lastPrice: r,
                                openPrice: a,
                                lowPrice: n,
                                highPrice: o,
                                ask: i,
                                bid: l,
                                pricescale: c,
                                volume: u,
                                shortName: d,
                                minMovePrimary: m,
                                minMoveSecondary: h,
                                fractional: p,
                                change: f,
                                changePercent: g,
                                currentSession: v,
                                exchange: _,
                                proName: b,
                                type: y,
                                sector: P,
                                industry: E,
                                invalid: "ok" !== e.status,
                                symbolDescription: (0, Ee.getTranslatedSymbolDescription)(e.values)
                            }))
                        })), () => {
                            a.unsubscribe(t, e)
                        }
                    }, [e]), (0, a.useMemo)(() => [t, n], [t, n])
                }(r);
                return a.createElement(be, {
                    detailsHeaderProps: n,
                    detailsInfoProps: s,
                    newsPreview: null
                })
            }

            function xe(e) {
                const {
                    widgetHeaderElement: t,
                    bridge: r,
                    history: n
                } = e, s = (0, a.useMemo)(() => ({
                    header: t,
                    bridge: r
                }), [r, t]);
                return a.createElement(h.Provider, {
                    value: s
                }, a.createElement(Se, null))
            }
        },
        40976: (e, t, r) => {
            "use strict";
            r.d(t, {
                useEnsuredContext: () => s
            });
            var a = r(59496),
                n = r(88537);

            function s(e) {
                return (0, n.ensureNotNull)((0, a.useContext)(e))
            }
        },
        39043: (e, t, r) => {
            "use strict";
            r.d(t, {
                useOverlayScroll: () => l
            });
            var a = r(59496),
                n = r(88537),
                s = r(21258),
                o = r(1227);
            const i = {
                onMouseOver: () => {},
                onMouseOut: () => {}
            };

            function l(e, t = o.CheckMobile.any()) {
                const r = (0, a.useRef)(null),
                    l = e || (0, a.useRef)(null),
                    [c, u] = (0, s.useHover)(),
                    [d, m] = (0, a.useState)({
                        reference: r,
                        containerHeight: 0,
                        containerWidth: 0,
                        contentHeight: 0,
                        contentWidth: 0,
                        scrollPosTop: 0,
                        scrollPosLeft: 0,
                        onVerticalChange: function(e) {
                            m(t => ({ ...t,
                                scrollPosTop: e
                            })), (0, n.ensureNotNull)(l.current).scrollTop = e
                        },
                        onHorizontalChange: function(e) {
                            m(t => ({ ...t,
                                scrollPosLeft: e
                            })), (0, n.ensureNotNull)(l.current).scrollLeft = e
                        },
                        visible: c
                    }),
                    h = (0, a.useCallback)(() => {
                        if (!l.current) return;
                        const {
                            clientHeight: e,
                            scrollHeight: t,
                            scrollTop: a,
                            clientWidth: n,
                            scrollWidth: s,
                            scrollLeft: o
                        } = l.current, i = r.current ? r.current.offsetTop : 0;
                        m(r => ({ ...r,
                            containerHeight: e - i,
                            contentHeight: t - i,
                            scrollPosTop: a,
                            containerWidth: n,
                            contentWidth: s,
                            scrollPosLeft: o
                        }))
                    }, []);

                function p() {
                    m(e => ({ ...e,
                        scrollPosTop: (0, n.ensureNotNull)(l.current).scrollTop,
                        scrollPosLeft: (0, n.ensureNotNull)(l.current).scrollLeft
                    }))
                }
                return (0, a.useEffect)(() => {
                    c && h(), m(e => ({ ...e,
                        visible: c
                    }))
                }, [c]), (0, a.useEffect)(() => {
                    const e = l.current;
                    return e && e.addEventListener("scroll", p), () => {
                        e && e.removeEventListener("scroll", p)
                    }
                }, [l]), [d, t ? i : u, l, h]
            }
        },
        97265: (e, t, r) => {
            "use strict";
            r.d(t, {
                useWatchedValueReadonly: () => n
            });
            var a = r(59496);
            const n = (e, t = !1) => {
                const r = "watchedValue" in e ? e.watchedValue : void 0,
                    n = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                    [s, o] = (0, a.useState)(r ? r.value() : n);
                return (t ? a.useLayoutEffect : a.useEffect)(() => {
                    if (r) {
                        o(r.value());
                        const e = e => o(e);
                        return r.subscribe(e), () => r.unsubscribe(e)
                    }
                    return () => {}
                }, [r]), s
            }
        },
        67184: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><circle fill="#9598A1" cx="9" cy="9" r="4"/></svg>'
        },
        8574: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="#2962FF" fill-rule="evenodd" clip-rule="evenodd" d="M12.57 5.5h-.07a3.5 3.5 0 1 0 .07 7A4.98 4.98 0 0 1 4 9a5 5 0 0 1 8.57-3.5z"/></svg>'
        },
        26434: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 17" width="14" height="17" fill="none"><g fill="#FB8C00" fill-rule="evenodd" clip-path="url(#ai0qyr3iu)" clip-rule="evenodd"><path d="M9.93 11.64A3.01 3.01 0 0 0 7 8a3 3 0 0 0-2.93 3.64 6.97 6.97 0 0 1 5.86 0zM3.12 10.44l-2.07-.56.31-1.15 2.07.55-.3 1.16zM4.92 7.68l-.96-1.91 1.08-.54L6 7.14l-1.08.54zM8 7.14l.96-1.9 1.08.53-.96 1.91L8 7.14zM10.57 9.56l2.07-.55.31 1.16-2.06.55-.32-1.16z"/></g><defs><clipPath id="ai0qyr3iu"><path fill="#fff" d="M0 0h14v17H0z"/></clipPath></defs></svg>'
        },
        1855: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 8" width="12" height="8" fill="none"><path fill="currentColor" d="M10 8H2a1 1 0 0 1-.8-1.6l4-5.33a1 1 0 0 1 1.6 0l4 5.33A1 1 0 0 1 10 8z"/></svg>'
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [660], {
        82515: e => {
            e.exports = {
                mobile: "screen and (max-width: 567px)"
            }
        },
        59636: (e, t, i) => {
            "use strict";
            i.d(t, {
                parsePrice: () => r,
                generateSingleDirectionItems: () => o,
                generatePriceRangeFrom: () => n,
                getDropdownItemsForDevice: () => a
            });
            var s = i(58198);

            function r(e, t, i) {
                if (t.parse) {
                    const i = t.parse(e);
                    if (i.res) return i.value
                }
                return void 0 !== i ? i : parseFloat(e)
            }

            function o(e, t, i, s, r) {
                const o = Array.from({
                    length: e
                }, function(e, t, i, s) {
                    return (r, o) => s.format(e + i * t * (o + 1))
                }(t, i, s, r));
                return 1 === s ? o.reverse() : o
            }

            function n(e, t, i, s) {
                return [...o(s, e, t, 1, i), i.format(e), ...o(s, e, t, -1, i)]
            }

            function a() {
                return "phone" !== s.mediaState.device && "phone-vertical" !== s.mediaState.device ? 6 : 4
            }
        },
        63111: (e, t, i) => {
            "use strict";
            i.d(t, {
                OrderPanelStatus: () => s,
                OrderPlacingStatus: () => r,
                OrderEditorDisplayMode: () => o,
                PriceType: () => n,
                BracketDefaultPips: () => a,
                BracketSubControlType: () => l,
                QuantitySubControlType: () => u,
                PriceSubControlType: () => h,
                CalculatorDecKeyCodes: () => c,
                CalculatorIncKeyCodes: () => d,
                Context: () => b,
                orderTypes: () => y
            });
            var s, r, o, n, a, l, u, h, c, d, p = i(59496),
                _ = i(25177);
            ! function(e) {
                e[e.Wait = 0] = "Wait", e[e.Active = 1] = "Active", e[e.Editing = 2] = "Editing", e[e.Preview = 3] = "Preview"
            }(s || (s = {})),
            function(e) {
                e[e.Creating = 0] = "Creating", e[e.Placed = 1] = "Placed"
            }(r || (r = {})),
            function(e) {
                e.Popup = "popup", e.Panel = "panel"
            }(o || (o = {})),
            function(e) {
                e[e.Stop = 0] = "Stop", e[e.Limit = 1] = "Limit"
            }(n || (n = {})),
            function(e) {
                e[e.TakeProfit = 75] = "TakeProfit", e[e.StopLoss = 25] = "StopLoss"
            }(a || (a = {})),
            function(e) {
                e.Price = "Price", e.Pips = "Pips", e.Money = "Money", e.Percent = "Percent"
            }(l || (l = {})),
            function(e) {
                e.Units = "Units", e.RiskInCurrency = "RiskInCurrency", e.RiskInPercent = "RiskInPercent", e.BaseCurrency = "BaseCurrency", e.QuoteCurrency = "QuoteCurrency"
            }(u || (u = {})),
            function(e) {
                e.Absolute = "Absolute", e.Relative = "Relative"
            }(h || (h = {})),
            function(e) {
                e[e.Minus = 189] = "Minus", e[e.NumMinus = 109] = "NumMinus", e[e.FirefoxMinus = 173] = "FirefoxMinus"
            }(c || (c = {})),
            function(e) {
                e[e.Plus = 187] = "Plus", e[e.NumPlus = 107] = "NumPlus", e[e.FirefoxPlus = 61] = "FirefoxPlus"
            }(d || (d = {}));
            const b = p.createContext({
                    resizerWidth: null,
                    mode: o.Panel,
                    supportTrailingStop: !1
                }),
                y = {
                    1: (0, _.t)("Limit"),
                    2: (0, _.t)("Market"),
                    3: (0, _.t)("Stop"),
                    4: (0, _.t)("Stop Limit")
                }
        },
        95318: (e, t, i) => {
            "use strict";
            i.d(t, {
                defaultSettings: () => r,
                defaultCryptoBracketsSettings: () => o,
                SettingsContext: () => n
            });
            var s = i(59496);
            const r = {
                    showRelativePriceControl: !0,
                    showCurrencyRiskInQty: !0,
                    showPercentRiskInQty: !0,
                    showBracketsInCurrency: !0,
                    showBracketsInPercent: !0,
                    showOrderPreview: !0,
                    showCryptoBracketsInCurrency: !1,
                    showCryptoBracketsInPercent: !1
                },
                o = {
                    showCryptoBracketsInCurrency: !1,
                    showCryptoBracketsInPercent: !1
                },
                n = s.createContext({
                    value: r,
                    setValue: e => {
                        console.warn("unable to modify order ticket settings because context.setValue is not defined")
                    }
                })
        },
        9016: (e, t, i) => {
            "use strict";
            i.d(t, {
                priceToPips: () => r,
                riskInCurrencyToPips: () => o,
                riskInPercentToPips: () => n,
                pipsToPrice: () => a,
                pipsToRiskInCurrency: () => l,
                pipsToRiskInPercent: () => u
            });
            var s = i(60521);

            function r(e, t, i, r) {
                return (0, s.Big)(e).minus(t).div(r).div(i).toNumber()
            }

            function o(e, t, i, r, o) {
                const n = (0,
                    s.Big)(i).mul(t).mul(o || 1);
                if (n.eq(0)) return 0;
                const a = (0, s.Big)(e).div(n).mul(r).toNumber();
                return Math.floor(a)
            }

            function n(e, t, i, r, o, n) {
                const a = (0, s.Big)(r).mul(t).mul(n || 1).mul(100);
                if (a.eq(0)) return 0;
                const l = (0, s.Big)(e).mul(i).div(a).mul(o).toNumber();
                return Math.floor(l)
            }

            function a(e, t, i, r) {
                return (0, s.Big)(i).mul(e).mul(r).plus(t).toNumber()
            }

            function l(e, t, i, r, o) {
                return (0, s.Big)(e).mul(i).mul(t).mul(o || 1).div(r).toNumber()
            }

            function u(e, t, i, r, o, n) {
                return i ? (0, s.Big)(e).mul(r).mul(t).mul(n || 1).mul(100).div(i).div(o).toNumber() : 0
            }
        },
        44785: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                OrderViewController: () => tt
            });
            var s = i(70122),
                r = i(88401),
                o = i(88537),
                n = i(51951),
                a = i(63329),
                l = i(82527),
                u = i(94489),
                h = i.n(u),
                c = i(50317),
                d = i(25177),
                p = i(99796),
                _ = i(58121),
                b = i(12694),
                y = i(57604),
                g = i(97345),
                P = i(18286),
                m = i(47488),
                v = i(75734),
                k = i(65728),
                f = i(95205),
                S = i(58261),
                C = i(86639),
                M = i(24818),
                T = i(63111),
                w = i(16345),
                V = i(97496),
                I = i.n(V),
                B = i(36376),
                O = i(50681),
                $ = i(1397),
                L = i(47898);
            const q = ["tpPercent"],
                R = ["slPercent"],
                F = ["stopPercent"],
                D = ["limitPercent"];

            function E(e) {
                return N(e) || x(e)
            }

            function N(e) {
                return D.includes(e.id)
            }

            function x(e) {
                return F.includes(e.id)
            }

            function j(e, t, i) {
                var s;
                return null === (s = e.getValidationRules(t)) || void 0 === s ? void 0 : s.filter(e => i.includes(e.id))
            }

            function Q(e, t) {
                return j(e, t, q)
            }

            function W(e, t) {
                return j(e, t, R)
            }
            const A = (0, d.t)("Long"),
                z = (0, d.t)("Short");
            class U {
                constructor(e, t, i, s, r, o, n, a, u, c, d, p, _ = !1) {
                    this.description = "", this.isTradable = !0, this._pinButtonClicked = new(I()), this._backButtonClicked = new(I()), this._cancelButtonClicked = new(I()), this._closeButtonClicked = new(I()), this._onStatusChanged = () => {
                        this.hasBackButton.setValue(this._hasBackButton()), this.hasCloseButton.setValue(l.enabled("order_panel_close_button")), this.hasCancelButton.setValue(this._hasCancelButton()), this.description = this._text(), this.title = this._title()
                    }, this._onQuotes = e => {
                        this.hasDelayedWarning.setValue(Boolean(e.isDelayed))
                    }, this._data = d, this._displaySymbolName = e, this._formatter = p, this._brokerName = i, this.status = r, this._mode = s, this.type = o, this._existingOrder = n, this.isTradable = a, this.isTradingPanelVisible = c, this.symbol = t, this.hasBackButton = new(h())(this._hasBackButton()), this.hasCloseButton = new(h())(l.enabled("order_panel_close_button")), this.hasCancelButton = new(h())(!1), this.hasDelayedWarning = new(h())(!1), this.hasBatsQuotes = _, this.title = this._title(), this.description = this._text(), this.status.subscribe(this._onStatusChanged), this._mode.subscribe(this._onStatusChanged), u && (this._quotesSubscription = u.subscribe(this._onQuotes))
                }
                unsubscribe() {
                    this._mode.unsubscribe(this._onStatusChanged), this.status.unsubscribe(this._onStatusChanged), this._quotesSubscription && this._quotesSubscription.unsubscribe()
                }
                showCancelButton() {
                    this.hasCancelButton.setValue(!0)
                }
                hideCancelButton() {
                    this.hasCancelButton.setValue(!1)
                }
                back() {
                    this._backButtonClicked.fire()
                }
                pin() {
                    this._pinButtonClicked.fire()
                }
                cancel() {
                    this._cancelButtonClicked.fire()
                }
                close() {
                    this._closeButtonClicked.fire()
                }
                pinButtonClicked() {
                    return this._pinButtonClicked
                }
                backButtonClicked() {
                    return this._backButtonClicked
                }
                cancelButtonClicked() {
                    return this._cancelButtonClicked
                }
                closeButtonClicked() {
                    return this._closeButtonClicked
                }
                _hasBackButton() {
                    return !(this._mode.value() !== T.OrderEditorDisplayMode.Panel || !this._existingOrder && 2 !== this.type && this.status.value() !== T.OrderPanelStatus.Preview)
                }
                _hasCancelButton() {
                    return this._mode.value() === T.OrderEditorDisplayMode.Panel && this.status.value() === T.OrderPanelStatus.Active && !this._existingOrder && 2 !== this.type
                }
                _title() {
                    return this.status.value() === T.OrderPanelStatus.Preview ? (0, d.t)("Order confirmation") : this._displaySymbolName
                }
                _text() {
                    if (this.status.value() === T.OrderPanelStatus.Preview) return "";
                    if (this._existingOrder && this._data && this._formatter) {
                        if (2 === this.type) {
                            const e = this._data.side,
                                t = this._data.qty,
                                i = this._formatter.format(this._data.price || this._data.avgPrice || this._data.limitPrice);
                            return ", " + (1 === e ? A : z) + " " + t + " @ " + i
                        }
                        return ", " + (0, d.t)("order") + " " + this._data.id
                    }
                    return this._brokerName ? ", " + this._brokerName : ""
                }
            }
            var H = i(85941),
                G = i(2683);
            class K {
                constructor({
                    initialSide: e,
                    quotes$: t,
                    priceFormatter: i,
                    spreadFormatter: s,
                    status: r,
                    baseCurrency: o
                }) {
                    this.baseCurrency = null, this.onControlFocused = new(I()), this._formattedQuotes$ = new m.BehaviorSubject({
                        ask: " ",
                        bid: " "
                    }), this._restrictionTypes$ = new m.BehaviorSubject([]), this._quotes = {
                        ask: 0,
                        bid: 0
                    }, this._waitQuotesTimeout = void 0, this._subscriptions = [], this.getValue = () => this._value$.getValue(), this.setValue = e => {
                        this._value$.next(e)
                    }, this.getFormattedQuotes = () => this._formattedQuotes$.getValue(), this.currentQuotes = () => this._quotes, this.getRestrictionTypes = () => this._restrictionTypes$.getValue(), this._value$ = new m.BehaviorSubject(e), this.value$ = this._value$.asObservable(), this.formattedQuotes$ = this._formattedQuotes$.asObservable(), this.restrictionTypes$ = this._restrictionTypes$.asObservable(), this.baseCurrency = o, this.status = r, this._quotes$ = t, this._priceFormatter = i, this._spreadFormatter = s
                }
                subscribe() {
                    this._waitQuotesTimeout = setTimeout(() => {
                        this._formattedQuotes$.next({}), this._quotes = {}
                    }, 5e3);
                    const e = this._quotes$.subscribe(e => {
                            this._formattedQuotes$.next(this._generateText(e)), this._quotes = e, clearTimeout(this._waitQuotesTimeout)
                        }),
                        t = this._quotes$.pipe((0, H.throttleTime)(2e3)).subscribe(e => {
                            this._restrictionTypes$.next(this._generateRestrictionTypes(e))
                        });
                    return this._subscriptions = [e, t], this._subscriptions
                }
                unsubscribe() {
                    this._subscriptions.forEach(e => e.unsubscribe()), clearTimeout(this._waitQuotesTimeout)
                }
                _generateText(e) {
                    const t = {},
                        i = (0, L.getAsk)(e),
                        s = (0, L.getBid)(e);
                    return t.ask = this._priceFormatter.format(i), t.bid = this._priceFormatter.format(s), t.spread = (0, G.isNumber)(e.spread) ? this._spreadFormatter.format(e.spread) : this._priceFormatter.format(i - s), t
                }
                _generateRestrictionTypes(e) {
                    const t = [];
                    return e.isHalted && t.push(M.RestrictionType.Halted), e.isHardToBorrow && t.push(M.RestrictionType.HardToBorrow), e.isNotShortable && t.push(M.RestrictionType.NotShortable), t
                }
            }
            var J = i(60521),
                Y = i(83450),
                X = i(59636);
            const Z = (0, d.t)("Order price is not appropriate for this order type/direction."),
                ee = (0,
                    d.t)("Order price is too close to the market price. It can lead to placing wrong order type due to specifics of the order placement in {brokerTitle}");

            function te(e, t, i, s) {
                const r = new J.Big(t),
                    o = r.mul(e).div(100);
                return r.minus(o.mul(i).mul(s)).toNumber()
            }

            function ie(e, t) {
                return (0, J.Big)(e).minus(t).abs().gt((0, J.Big)(e).div(2))
            }

            function se(e) {
                const {
                    price: t,
                    askOrBid: i,
                    orderType: s,
                    side: r,
                    isStopPrice: o,
                    isForex: n,
                    formatter: a,
                    supportStopOrdersInBothDirections: l,
                    supportStopLimitOrdersInBothDirections: u,
                    step: h,
                    roundedToStep: c
                } = e, p = t < 0 || (0, J.Big)(i).mul(100).lt(t) || function(e) {
                    const {
                        price: t,
                        askOrBid: i,
                        orderType: s,
                        side: r,
                        isStopPrice: o,
                        supportStopOrdersInBothDirections: n,
                        supportStopLimitOrdersInBothDirections: a
                    } = e;
                    return 1 === s ? 1 === r ? t > i && ie(i, t) : t < i && ie(i, t) : !!(3 === s && !n || 4 === s && o && !a) && (1 === r ? t < i : t > i)
                }({
                    price: t,
                    askOrBid: i,
                    orderType: s,
                    side: r,
                    isStopPrice: o,
                    supportStopOrdersInBothDirections: l,
                    supportStopLimitOrdersInBothDirections: u
                });
                return n && !c || !1 !== (0, L.isMintickMultiple)(t, h) ? {
                    res: p,
                    severity: "error",
                    msg: p ? Z : void 0
                } : {
                    res: !0,
                    msg: (0, d.t)("Order price should be a multiple of {minTick}").format({
                        minTick: a.format(h)
                    })
                }
            }
            class re {
                constructor({
                    quotes$: e,
                    side$: t,
                    initialSide: i,
                    info: s,
                    status: r,
                    price: o,
                    formatter: n,
                    orderType: a,
                    isLimitPrice: l,
                    settings: u,
                    brokerTitle: p,
                    orderWidgetStat: _,
                    orderRules: b,
                    forceAbsolutePriceUpdate: y,
                    supportStopOrdersInBothDirections: g,
                    supportStopLimitOrdersInBothDirections: P
                }) {
                    var v, k;
                    this.id = (0, w.randomHashN)(6), this.price = new(h())(null), this.displayPrice = new(h())(""), this.relativePrice = new Y.WatchedObject(null, L.comparator), this.priceError = new(h()), this.quotes = new Y.WatchedObject({
                        ask: 0,
                        bid: 0,
                        last: 0
                    }, L.comparator), this.side = new(h()), this.step = new(h()), this.error = new Y.WatchedObject({
                        res: !1
                    }, L.comparator), this.onControlFocused = new(I()), this.$value = new m.BehaviorSubject(null), this._controlError = new m.BehaviorSubject(!1), this._syncPrice = null, this._symbolType = "", this._priceRules = [], this._stopLimitPercentPriceRuleCheckers = [], this.setControlError = e => {
                        this._controlError.next(e)
                    }, this._isPriceRules = e => "limitPriceDistance" === e.id || "stopPriceDistance" === e.id, this._updateFocusIfNeeded = () => {
                        1 !== this.focusedControl.value() || !this.isRelativePriceControlHidden && this._settings.value().showRelativePriceControl || this.focusedControl.setValue(0)
                    }, this.side.setValue(i), this._instrumentInfo = s, this.status = r, this.orderType = a, this._isLimitPrice = l, this._settings = u, this._settings.subscribe(this._updateFocusIfNeeded), this.isRelativePriceControlHidden = this._roundToStepRequired(), this._setStep(), this.formatter = n, this.orderWidgetStat = _, this.supportStopOrdersInBothDirections = Boolean(g), this.supportStopLimitOrdersInBothDirections = Boolean(P);
                    const f = y || this.isRelativePriceControlHidden || !this._settings.value().showRelativePriceControl;
                    this.focusedControl = new(h())(f ? 0 : 1), this.modifiedAbsolutePriceControlStat = null !== _ ? () => _.setPriceControlModifiedProperty(T.PriceSubControlType.Absolute) : () => {}, this.modifiedRelativePriceControlStat = null !== _ ? () => _.setPriceControlModifiedProperty(T.PriceSubControlType.Relative) : () => {},
                        this.displayPrice.setValue(this.formatter.format(0)), void 0 !== o && (this.forceAbsolutePriceUpdate(o, !0), this.$value.next(this.price.value())), this._symbolType = s.type || "", this._quotes = e, this._side$ = t, this._priceSubscription = (0, L.makeSubjectFromWatchedValue)(this.price), this._orderTypeSubscription = (0, L.makeSubjectFromWatchedValue)(this.orderType), this._orderTypeSubj = this._orderTypeSubscription.subject, this._resultSubscription = (0, S.combineLatest)([this._priceSubscription.subject, this._quotes, this._side$, this._orderTypeSubscription.subject, this._controlError]).subscribe(([e, t, i, s, r]) => {
                            const o = (0, L.getQuotePrice)(i, t),
                                n = "forex" === this._symbolType,
                                a = this.status.value(),
                                l = a !== T.OrderPanelStatus.Wait,
                                u = a === T.OrderPanelStatus.Editing;
                            let h = {
                                res: !1
                            };
                            if (null !== e && null !== s && 2 !== s) {
                                h = se({
                                    price: e,
                                    askOrBid: o,
                                    orderType: s,
                                    side: i,
                                    isStopPrice: !this._isLimitPrice,
                                    isForex: n,
                                    formatter: this.formatter,
                                    supportStopOrdersInBothDirections: this.supportStopOrdersInBothDirections,
                                    supportStopLimitOrdersInBothDirections: this.supportStopLimitOrdersInBothDirections,
                                    step: this.step.value(),
                                    roundedToStep: this._roundToStepRequired()
                                });
                                for (const t of this._stopLimitPercentPriceRuleCheckers)
                                    if (h = t(e, o, i, s, this.step.value(), u), h.res) break
                            }
                            const c = null !== e ? this._checkPriceWarning(e, t, i) : {
                                    res: !1
                                },
                                d = h.res || r || c.res,
                                p = h.res || r ? "error" : "warning",
                                _ = r ? void 0 : h.res ? h.msg : c.msg;
                            this.error.setValue({
                                res: !!l && d,
                                severity: p,
                                msg: l ? _ : void 0
                            }), this.$value.next(h.res || r ? null : e)
                        }), this._pipSize = s.pipSize;
                    const C = null != b ? b : [];
                    this._priceRules = null !== (v = C.filter(this._isPriceRules)) && void 0 !== v ? v : [];
                    const M = null !== (k = C.filter(E)) && void 0 !== k ? k : [],
                        V = this._isLimitPrice ? N : x;
                    M.filter(V).forEach(e => {
                        this._stopLimitPercentPriceRuleCheckers.push(function(e, t) {
                            let i;
                            return (s, r, o, n, a, l) => {
                                const u = -1 === o ? 1 : -1,
                                    h = 3 === n ? 1 : -1,
                                    p = te(e, r, u, h),
                                    _ = te(t, r, u, h),
                                    b = 1 === n ? 1 : 2,
                                    y = (0, c.roundToStepByPriceTypeAndSide)(p, a, b, o),
                                    g = (0, c.roundToStepByPriceTypeAndSide)(_, a, b, o);
                                let P = Math.min(y, g),
                                    m = Math.max(y, g);
                                l && (void 0 === i && (i = s), P = Math.min(P, i), m = Math.max(m, i));
                                return s >= P && s <= m ? {
                                    res: !1
                                } : {
                                    res: !0,
                                    msg: (0, d.t)("Order price should be in the range of {min} and {max}").replace("{min}", P.toString()).replace("{max}", m.toString())
                                }
                            }
                        }(e.options.min, e.options.max))
                    }), this._brokerTitle = p
                }
                onAbsolutePriceSelected(e) {
                    let t, i;
                    t = this.formatter.parse ? this.formatter.parse(e) : {
                        res: !1,
                        error: "Formatter does not support parse"
                    }, t.res ? (this.price.setValue(t.value), this.displayPrice.setValue(e)) : this.displayPrice.setValue(e), i = this._isLimitPrice && 4 === this.orderType.value() && null !== this._syncPrice ? this._syncPrice : this._getQuotesBySide(this.side.value());
                    const s = {
                        base: this._getBase(this.side.value(), this.orderType.value()),
                        offset: this.calcOffset(t.res ? t.value : 0, i, this.step.value())
                    };
                    this.relativePrice.setValue(s)
                }
                onRelativePriceSelected(e) {
                    if (this.isRelativePriceControlHidden || !this._settings.value().showRelativePriceControl) return;
                    let t;
                    if (this.relativePrice.setValue(e), null === e) t = 0;
                    else if ("ask" === e.base) t = (0, J.Big)(this.step.value()).mul(e.offset).plus(this.quotes.value().ask).toNumber();
                    else if ("bid" === e.base) t = (0,
                        J.Big)(this.step.value()).mul(e.offset).plus(this.quotes.value().bid).toNumber();
                    else {
                        let i;
                        i = this._isLimitPrice && 4 === this.orderType.value() && null !== this._syncPrice ? this._syncPrice : this._getQuotesBySide(this.side.value()), t = (0, J.Big)(this.step.value()).mul(e.offset).plus(i).toNumber()
                    }
                    this._checkOutOfRange(this.quotes.value(), t) && (t = this._getQuotesBySide(this.side.value()), this.relativePrice.setValue({
                        base: this._getBase(this.side.value(), this.orderType.value()),
                        offset: 0
                    }));
                    const i = this.formatter.format(t);
                    this.price.setValue((0, X.parsePrice)(i, this.formatter, t)), this.displayPrice.setValue(i)
                }
                subscribe() {
                    return (0, S.combineLatest)([this._side$, this._quotes, this._orderTypeSubj]).subscribe(([e, t, i]) => {
                        this.orderType.setValue(i), this.isRelativePriceControlHidden = this._roundToStepRequired(), this._setStep(), (this._isLimitPrice && 4 !== i || !1 === this._isLimitPrice || this.isRelativePriceControlHidden) && (this._updateAbsolutePriceOnQuotes(e, t), this._updateRelativePriceOnQuotes(e, t, i)), this.quotes.setValue({
                            ask: (0, L.getAsk)(t),
                            bid: (0, L.getBid)(t),
                            last: (0, L.getLast)(t)
                        }), this.side.setValue(e), this.orderType.setValue(i)
                    })
                }
                unsubscribe() {
                    this._priceSubscription.unsubscribe(), this._orderTypeSubscription.unsubscribe(), this._resultSubscription.unsubscribe(), this._settings.unsubscribe(this._updateFocusIfNeeded)
                }
                forcePricesUpdate(e) {
                    this.focusedControl.setValue(this._settings.value().showRelativePriceControl && !this.isRelativePriceControlHidden ? 1 : 0), this.forceAbsolutePriceUpdate(e), this.forceRelativePriceUpdate()
                }
                forceAbsolutePriceUpdate(e, t = !1) {
                    if (null === e) return;
                    const i = this._roundToStepRequired() || t,
                        s = this._getPriceType();
                    e = i ? (0, c.roundToStepByPriceTypeAndSide)(e, this.step.value(), s, this.side.value()) : e, this.price.setValue(e), this.displayPrice.setValue(this.formatter.format(e))
                }
                forceRelativePriceUpdate() {
                    const e = this._getOffsetFromAbsolutePrice(this.price.value(), this.side.value(), this.quotes.value()),
                        t = {
                            base: this._getBase(this.side.value(), this.orderType.value()),
                            offset: e
                        };
                    this.onRelativePriceSelected(t)
                }
                forceStopLimitRelativePriceUpdate() {
                    const e = {
                        base: "stop",
                        offset: this.side.value()
                    };
                    this.onRelativePriceSelected(e)
                }
                syncWithPrice(e) {
                    const t = null !== e ? e : 0;
                    this._syncPrice = t;
                    const i = this.price.value(),
                        s = null !== i ? i : 0,
                        r = this.calcOffset(s, t, this.step.value());
                    if (0 === this.focusedControl.value()) {
                        const e = {
                            base: "stop",
                            offset: r
                        };
                        this.relativePrice.setValue(e)
                    } else {
                        const e = this.relativePrice.value(),
                            i = t + (null !== e ? e.offset : 0) * this.step.value();
                        this.forceAbsolutePriceUpdate(i)
                    }
                }
                calcOffset(e, t, i) {
                    return Math.round((e - t) / i)
                }
                _checkOutOfRange(e, t) {
                    const i = null !== t && t >= 0,
                        s = null !== t && t <= 100 * (0, L.getQuotePrice)(this.side.value(), e);
                    return !i || !s
                }
                _checkPriceWarning(e, t, i) {
                    const s = this._priceRules.find(s => this._isDistanceRuleViolated(e, t, s, i));
                    return s ? {
                        res: !0,
                        severity: s.severity,
                        msg: ee.format({
                            brokerTitle: this._brokerTitle
                        })
                    } : {
                        res: !1,
                        msg: void 0
                    }
                }
                _isDistanceRuleViolated(e, t, i, s) {
                    if ("limitPriceDistance" === i.id && !this._isLimitPrice || "stopPriceDistance" === i.id && this._isLimitPrice) return !1;
                    const r = 1 === s,
                        o = (0, L.getQuotePrice)(s, t);
                    let n = null;
                    if (r && "buyDirectionPips" in i.options && (n = i.options.buyDirectionPips), !r && "sellDirectionPips" in i.options && (n = i.options.sellDirectionPips), null === n) return !1;
                    return Math.abs(o - e) < n * this._pipSize
                }
                _getBase(e, t) {
                    return 4 === t && !0 === this._isLimitPrice ? "stop" : 1 === e ? "ask" : "bid"
                }
                _getQuotesBySide(e) {
                    return 1 === e ? this.quotes.value().ask : this.quotes.value().bid
                }
                _getOffsetFromAbsolutePrice(e, t, i) {
                    const s = 1 === t ? (0, L.getAsk)(i) : (0, L.getBid)(i);
                    return this.calcOffset(null !== e ? e : s, s, this.step.value())
                }
                _getOffsetFromRelativePrice() {
                    const e = this.relativePrice.value();
                    return null !== e ? e.offset : 0
                }
                _updateAbsolutePriceOnQuotes(e, t) {
                    const i = (0, L.getQuotePrice)(e, t);
                    if (null === this.price.value()) this.forceAbsolutePriceUpdate(i);
                    else if (1 === this.focusedControl.value()) {
                        const e = this._getOffsetFromRelativePrice(),
                            t = (0, J.Big)(e).mul(this.step.value()).plus(i).toNumber();
                        this.forceAbsolutePriceUpdate(t)
                    }
                }
                _updateRelativePriceOnQuotes(e, t, i) {
                    if (!this.isRelativePriceControlHidden && this._settings.value().showRelativePriceControl && (null === this.relativePrice.value() || 0 === this.focusedControl.value() || this.side.value() !== e || this.orderType.value() !== i)) {
                        let s;
                        s = this.side.value() === e ? 4 === i && null === this.relativePrice.value() ? e : this._getOffsetFromAbsolutePrice(this.price.value(), e, t) : 1 === this.focusedControl.value() ? 0 : 4 === i ? e : -this._getOffsetFromRelativePrice();
                        const r = {
                            base: this._getBase(e, i),
                            offset: s
                        };
                        this.relativePrice.setValue(r)
                    }
                }
                _getPriceType() {
                    const e = this.orderType.value();
                    return 1 === e || 4 === e && this._isLimitPrice ? 1 : 2
                }
                _setStep() {
                    const e = this._getPriceType();
                    1 === e && void 0 !== this._instrumentInfo.limitPriceStep ? this.step.setValue(this._instrumentInfo.limitPriceStep) : 2 === e && void 0 !== this._instrumentInfo.stopPriceStep ? this.step.setValue(this._instrumentInfo.stopPriceStep) : this.step.setValue(this._instrumentInfo.minTick || this._instrumentInfo.pipSize)
                }
                _roundToStepRequired() {
                    const e = this._getPriceType(),
                        t = this._instrumentInfo.minTick || this._instrumentInfo.pipSize;
                    return 2 === e && void 0 !== this._instrumentInfo.stopPriceStep ? this._instrumentInfo.stopPriceStep !== t : 1 === e && void 0 !== this._instrumentInfo.limitPriceStep && this._instrumentInfo.limitPriceStep !== t
                }
            }
            var oe = i(16230),
                ne = i(32207),
                ae = i(84039);

            function le(e, t, i, s, r) {
                if (!t) return 0;
                return de((0, J.Big)(e).div(t).div(i).div(r || 1), s).toNumber()
            }

            function ue(e, t, i, s, r, o) {
                if (!i) return 0;
                return de((0, J.Big)(e).mul(t).div(i).div(s).div(o || 1).div(100), r).toNumber()
            }

            function he(e, t, i, s) {
                return (0, J.Big)(t).mul(i).mul(e).mul(s || 1).toNumber()
            }

            function ce(e, t, i, s, r) {
                return s && e ? (0, J.Big)(t).mul(i).mul(e).mul(r || 1).mul(100).div(s).toNumber() : 0
            }

            function de(e, t) {
                return e.div(t).round(0, 0).mul(t)
            }
            class pe {
                constructor(e, t, i, s, r, o, n, a, l, u, c) {
                    this.formatter = new ne.SplitThousandsFormatter, this.riskInCurrencyFormatter = new $.PriceFormatter(100), this.riskInPercentFormatter = new $.PriceFormatter(100), this.isRiskAvailable = new(h())(!1), this.focusedControl = new(h())(null), this.riskStep = .01, this.error = new Y.WatchedObject({
                        res: !1
                    }, L.comparator), this.onControlFocused = new(I()), this.$value = new m.BehaviorSubject(null), this._focusSubscription = (0,
                        L.makeSubjectFromWatchedValue)(this.focusedControl), this._focusSubj = this._focusSubscription.subject, this._controlError = new m.BehaviorSubject({
                        res: !1
                    }), this.setControlError = e => {
                        this._controlError.next({
                            res: e
                        })
                    }, this._updateFocusIfNeeded = e => {
                        const t = this.focusedControl.value(),
                            i = 1 === t && !e.showCurrencyRiskInQty,
                            s = 2 === t && !e.showPercentRiskInQty;
                        (i || s) && this.focusedControl.setValue(0)
                    }, this.qty = r.qty, this.units = r.units, this._lotSize = r.lotSize, this.quantity = {
                        value: new(h())(null !== n ? n : this.qty.default),
                        onModifiedCallback: () => null !== u ? u.setQtyControlModifiedProperty(T.QuantitySubControlType.Units) : () => {},
                        calculatorUsedStat: () => null !== u ? u.setCalculatorUsedProperty() : () => {}
                    }, this._quantitySubscription = (0, L.makeSubjectFromWatchedValue)(this.quantity.value), this._quantitySubj = this._quantitySubscription.subject, this.currency = o || "", this.riskInCurrency = {
                        value: new(h())(null),
                        onModifiedCallback: () => null !== u ? u.setQtyControlModifiedProperty(T.QuantitySubControlType.RiskInCurrency) : () => {},
                        calculatorUsedStat: () => null !== u ? u.setCalculatorUsedProperty() : () => {}
                    }, this.riskInPercent = {
                        value: new(h())(null),
                        onModifiedCallback: () => null !== u ? u.setQtyControlModifiedProperty(T.QuantitySubControlType.RiskInPercent) : () => {},
                        calculatorUsedStat: () => null !== u ? u.setCalculatorUsedProperty() : () => {}
                    }, this.showRiskControls = c, this._riskInCurrencySubscription = (0, L.makeSubjectFromWatchedValue)(this.riskInCurrency.value), this._riskInPercentSubscription = (0, L.makeSubjectFromWatchedValue)(this.riskInPercent.value), this._riskInCurrencySubj = this._riskInCurrencySubscription.subject, this._riskInPercentSubj = this._riskInPercentSubscription.subject, this.status = a, this._equity = i, this._pipValue = s, this._stopLossAvailable = e, this._stopLossPips = t, this._stopLossSubscription = this._stopLossAvailable.subscribe(e => {
                        this.isRiskAvailable.setValue(e), e || this.focusedControl.setValue(0)
                    }), this._valuesSubscription = (0, S.combineLatest)([this._createQuantityObservable(), this._createRiskInCurrencyObservable(), this._createRiskInPercentObservable(), this._focusSubj]).subscribe(([e, t, i, s]) => {
                        this.quantity.value.value() === e && this.riskInCurrency.value.value() === t && this.riskInPercent.value.value() === i && this.focusedControl.value() === s || this._setValuesForUnfocusedControls(s, e, t, i)
                    }), this._resultSubscription = (0, S.combineLatest)({
                        qty: this._quantitySubj,
                        controlError: this._controlError,
                        focus: this._focusSubj
                    }).pipe((0, P.distinctUntilChanged)(oe.default)).subscribe(e => {
                        const {
                            qty: t,
                            controlError: i,
                            focus: s
                        } = e, r = (0, ae.checkQtyError)(this.qty, t, !0), o = i.res ? i.msg : r.msg;
                        this.error.setValue({
                            res: r.res || i.res,
                            msg: o
                        }), this.$value.next(r.res || i.res || null === s ? null : t)
                    }), this.focusedControl.setValue(0), this._settings = l, this._settings.subscribe(this._updateFocusIfNeeded)
                }
                unsubscribe() {
                    this._stopLossSubscription.unsubscribe(), this._valuesSubscription.unsubscribe(), this._resultSubscription.unsubscribe(), this._focusSubscription.unsubscribe(), this._quantitySubscription.unsubscribe(), this._riskInCurrencySubscription.unsubscribe(), this._riskInPercentSubscription.unsubscribe(), this._settings.unsubscribe(this._updateFocusIfNeeded)
                }
                _setValuesForUnfocusedControls(e, t, i, s) {
                    0 !== e && this.quantity.value.setValue(t), 1 !== e && this.riskInCurrency.value.setValue(i), 2 !== e && this.riskInPercent.value.setValue(s)
                }
                _createQuantityObservable() {
                    return (0, S.combineLatest)({
                        focus: this._focusSubj,
                        pipValue: this._pipValue,
                        quantity: this._quantitySubj,
                        riskInCurrency: this._riskInCurrencySubj,
                        riskInPercent: this._riskInPercentSubj,
                        stopLossPips: this._stopLossPips,
                        equity: this._equity
                    }).pipe((0, g.map)(e => {
                        const {
                            focus: t,
                            pipValue: i,
                            quantity: s,
                            riskInCurrency: r,
                            riskInPercent: o,
                            stopLossPips: n,
                            equity: a
                        } = e;
                        switch (t) {
                            case 0:
                                return s;
                            case 1:
                                return null === r || null === n ? null : le(r, n, i, this.qty.step, this._lotSize);
                            case 2:
                                return null === o || null === n ? null : ue(o, a, n, i, this.qty.step, this._lotSize);
                            default:
                                return s
                        }
                    }))
                }
                _createRiskInCurrencyObservable() {
                    return (0, S.combineLatest)({
                        focus: this._focusSubj,
                        pipValue: this._pipValue,
                        quantity: this._quantitySubj,
                        riskInCurrency: this._riskInCurrencySubj,
                        riskInPercent: this._riskInPercentSubj,
                        stopLossPips: this._stopLossPips,
                        equity: this._equity
                    }).pipe((0, g.map)(e => {
                        const {
                            focus: t,
                            pipValue: i,
                            quantity: s,
                            riskInCurrency: r,
                            riskInPercent: o,
                            stopLossPips: n,
                            equity: a
                        } = e;
                        switch (t) {
                            case 0:
                                return null === s || null === n ? null : he(s, n, i, this._lotSize);
                            case 1:
                                return r;
                            case 2:
                                if (null === o || null === n) return null;
                                return he(ue(o, a, n, i, this.qty.step, this._lotSize), n, i, this._lotSize);
                            default:
                                return null === s || null === n ? null : he(s, n, i)
                        }
                    }))
                }
                _createRiskInPercentObservable() {
                    return (0, S.combineLatest)({
                        focus: this._focusSubj,
                        pipValue: this._pipValue,
                        quantity: this._quantitySubj,
                        riskInCurrency: this._riskInCurrencySubj,
                        riskInPercent: this._riskInPercentSubj,
                        stopLossPips: this._stopLossPips,
                        equity: this._equity
                    }).pipe((0, g.map)(e => {
                        const {
                            focus: t,
                            pipValue: i,
                            quantity: s,
                            riskInCurrency: r,
                            riskInPercent: o,
                            stopLossPips: n,
                            equity: a
                        } = e, l = null === n;
                        switch (t) {
                            case 0:
                                return null === s || l ? null : ce(s, n, i, a, this._lotSize);
                            case 1:
                                if (null === r || l) return null;
                                return ce(le(r, n, i, this.qty.step, this._lotSize), n, i, a, this._lotSize);
                            case 2:
                                return o;
                            default:
                                return null === s || l ? null : ce(s, n, i, a, this._lotSize)
                        }
                    }))
                }
            }
            var _e = i(54620);
            class be {
                constructor({
                    info: e,
                    price$: t,
                    baseCurrencyCryptoBalance$: i,
                    quoteCurrencyCryptoBalance$: s,
                    initialQty: r,
                    status: o,
                    side$: n,
                    sideGetter: a,
                    orderWidgetStat: l,
                    isExistingOrder: u,
                    orderQty: d,
                    orderPrice: p
                }) {
                    this.focusedControl = new(h())(3), this.error = new Y.WatchedObject({
                        res: !1
                    }, L.comparator), this.onControlFocused = new(I()), this.$value = new m.BehaviorSubject(null), this._focusSubscription = (0, L.makeSubjectFromWatchedValue)(this.focusedControl), this._controlError = new m.BehaviorSubject({
                        res: !1
                    }), this._focusSubj = this._focusSubscription.subject, this._baseCurrencyCryptoBalanceValue$ = new m.BehaviorSubject(null), this._quoteCurrencyCryptoBalanceValue$ = new m.BehaviorSubject(null), this._subscriptions = [], this.setControlError = e => {
                        this._controlError.next({
                            res: e
                        })
                    }, this.info = e, this.status = o, this._orderQty = d, this._orderPrice = p, this._isExistingOrder = u, this.formatter = new _e.QuantityFormatter, this.quoteCurrencyUiParams$ = t.pipe((0, g.map)(t => {
                        const i = (0, J.Big)(t).mul(e.qty.step),
                            s = (0, c.roundDownToPowerOf10)(i.toNumber()),
                            r = (0,
                                J.Big)(Math.ceil(i.div(s).toNumber())).mul(s),
                            o = (0, J.Big)(e.qty.min).div(e.qty.step);
                        return {
                            min: r.mul(o).toNumber(),
                            step: s
                        }
                    })), this.quantity = {
                        value: new(h())(null !== r ? r : e.qty.default || e.qty.step),
                        onModifiedCallback: null !== l ? () => l.setQtyControlModifiedProperty(T.QuantitySubControlType.BaseCurrency) : () => {}
                    }, this.quoteCurrencyQuantity = {
                        value: new(h())(null !== r ? r : e.qty.default || e.qty.step),
                        onModifiedCallback: null !== l ? () => l.setQtyControlModifiedProperty(T.QuantitySubControlType.QuoteCurrency) : () => {}
                    }, this.side$ = n, this.getSide = a, this.baseCurrencyCryptoBalanceValue$ = this._baseCurrencyCryptoBalanceValue$.asObservable(), this.quoteCurrencyCryptoBalanceValue$ = this._quoteCurrencyCryptoBalanceValue$.asObservable(), this._quoteCurrencyQuantitySubscription = (0, L.makeSubjectFromWatchedValue)(this.quoteCurrencyQuantity.value), this._baseCurrencyQuantitySubscription = (0, L.makeSubjectFromWatchedValue)(this.quantity.value), this._baseCurrencyQuantitySubj = this._baseCurrencyQuantitySubscription.subject, this._quoteCurrencyQuantitySubj = this._quoteCurrencyQuantitySubscription.subject, null !== i && this._subscriptions.push((0, S.combineLatest)([n, i]).subscribe(e => {
                        const [t, i] = e;
                        this._baseCurrencyCryptoBalanceValue$.next(this._getBalance(t, i))
                    })), null !== s && this._subscriptions.push((0, S.combineLatest)([n, s]).subscribe(e => {
                        const [t, i] = e;
                        this._quoteCurrencyCryptoBalanceValue$.next(this._getBalance(t, i))
                    })), this._subscriptions = [(0, S.combineLatest)({
                        focus: this._focusSubj,
                        price: t,
                        baseCurrencyQuantity: this._baseCurrencyQuantitySubj,
                        quoteCurrencyQuantity: this._quoteCurrencyQuantitySubj
                    }).subscribe(t => {
                        const {
                            focus: i,
                            price: s,
                            baseCurrencyQuantity: r,
                            quoteCurrencyQuantity: o
                        } = t;
                        if (4 === i) {
                            if (null !== o) {
                                const t = (0, J.Big)(o).div(s).div(e.qty.step).round(0, 0).mul(e.qty.step).toNumber();
                                this.quantity.value.setValue(t)
                            }
                        } else null !== r && this.quoteCurrencyQuantity.value.setValue((0, J.Big)(r).mul(s).toNumber())
                    }), (0, S.combineLatest)({
                        baseValue: this._baseCurrencyQuantitySubj,
                        quoteValue: this._quoteCurrencyQuantitySubj,
                        controlError: this._controlError,
                        focus: this._focusSubj,
                        side: this.side$,
                        baseBalanceValue: this._baseCurrencyCryptoBalanceValue$,
                        quoteBalanceValue: this._quoteCurrencyCryptoBalanceValue$
                    }).subscribe(t => {
                        const {
                            baseValue: i,
                            quoteValue: s,
                            controlError: r,
                            focus: o,
                            side: n,
                            baseBalanceValue: a,
                            quoteBalanceValue: l
                        } = t, u = (0, ae.checkQtyError)(e.qty, i), h = this._isSellSide(n) ? this._checkBalanceError(i, a) : this._checkBalanceError(s, l);
                        this.error.setValue({
                            res: u.res || h.res || r.res,
                            msg: u.msg || h.msg || r.msg
                        }), this.$value.next(u.res || h.res || r.res || null === o ? null : i)
                    })]
                }
                unsubscribe() {
                    this._subscriptions.forEach(e => e && e.unsubscribe())
                }
                _checkBalanceError(e, t) {
                    return null !== e && null !== t && e > t ? {
                        res: !0,
                        msg: ae.qtyErrors.balance
                    } : {
                        res: !1
                    }
                }
                _getBalance(e, t) {
                    return null === t ? null : this._makeOrderBalanceValue(e).plus(t.available).toNumber()
                }
                _makeOrderBalanceValue(e) {
                    return this._isExistingOrder && this._orderQty && this._orderPrice ? this._isSellSide(e) ? new J.Big(this._orderQty) : new J.Big(this._orderQty).mul(this._orderPrice) : new J.Big(0)
                }
                _isSellSide(e) {
                    return -1 === e
                }
            }
            var ye = i(33064),
                ge = i(46502),
                Pe = i(23691),
                me = i(9016);
            const ve = {
                orderStopLoss: {
                    long: (0, d.t)("Stop loss order must be below entry price."),
                    short: (0, d.t)("Stop loss order must be higher entry price.")
                },
                orderTakeProfit: {
                    long: (0, d.t)("Take profit order must be above entry price."),
                    short: (0, d.t)("Take profit order must be lower entry price.")
                },
                positionStopLoss: {
                    long: e => (0, d.t)("Stop loss must be below current {value}.", {
                        replace: {
                            value: e
                        }
                    }),
                    short: e => (0, d.t)("Stop loss must be above current {value}.", {
                        replace: {
                            value: e
                        }
                    })
                },
                positionTakeProfit: {
                    long: e => (0, d.t)("Take profit must be above current {value}.", {
                        replace: {
                            value: e
                        }
                    }),
                    short: e => (0, d.t)("Take profit must be below current {value}.", {
                        replace: {
                            value: e
                        }
                    })
                }
            };

            function ke(e, t) {
                let i, s, r;
                const o = (e, t, i, s) => {
                    const r = new J.Big(t),
                        o = r.mul(e).div(100);
                    return r.minus(o.mul(i).mul(s)).toNumber()
                };
                return (n, a, l, u, h, p, _, b) => {
                    const y = -1 === l ? -1 : 1,
                        g = u === M.BracketType.TakeProfit ? -1 : 1,
                        P = o(e, a, y, g),
                        m = o(t, a, y, g),
                        v = (0, c.roundToStepByPriceTypeAndSide)(P, p, h, l),
                        k = (0, c.roundToStepByPriceTypeAndSide)(m, p, h, l);
                    let f = Math.min(v, k),
                        S = Math.max(v, k);
                    _ && (void 0 !== i && void 0 !== s && r ? (f = i, S = s) : void 0 === i && void 0 === s && (f = Math.min(f, n), S = Math.max(S, n), i = f, s = S, r = b));
                    if (!(n >= f && n <= S)) return {
                        res: !0,
                        msg: (0, d.t)("Bracket price should be in the range of {min} and {max}").replace("{min}", f.toString()).replace("{max}", S.toString())
                    };
                    return (y * g == -1 ? v >= a && k >= a : v <= a && k <= a) ? {
                        res: !1
                    } : {
                        res: !0,
                        msg: (0, d.t)("Calculated boundaries do not match parent order side")
                    }
                }
            }

            function fe(e, t) {
                if (null === e) return null;
                const i = t.format(e);
                if (t.parse) {
                    const e = t.parse(i);
                    if (e.res) return e.value
                }
                return parseFloat(i)
            }
            class Se {
                constructor({
                    initialPrice: e,
                    initialEnabled: t,
                    initialBracketType: i,
                    formatter: s,
                    equity$: r,
                    quotes$: o,
                    info: n,
                    pipValue$: a,
                    side$: l,
                    amount$: u,
                    parentPrice$: h,
                    orderType$: c,
                    currency: p,
                    parentType: _,
                    savedPips: b,
                    settings: y,
                    orderWidgetStat: P,
                    showRiskControls: v,
                    status: k,
                    validationRules: f,
                    supportModifyBrackets: C,
                    supportModifyTrailingStop: w,
                    supportCryptoBrackets: V,
                    supportAddBracketsToExistingOrder: B,
                    hasTrailingStopBracket: O
                }) {
                    if (this.isValuesInitialized = !1, this.onControlFocused = new(I()), this.stopLossTypes = [M.BracketType.StopLoss, M.BracketType.TrailingStop], this.roundToStopLimitPriceStepRequired = !1, this._value$ = new m.BehaviorSubject(null), this._pips$ = new m.BehaviorSubject(null), this._price$ = new m.BehaviorSubject(null), this._riskInCurrency$ = new m.BehaviorSubject(null), this._riskInPercent$ = new m.BehaviorSubject(null), this._focusedControl$ = new m.BehaviorSubject(1), this._error$ = new m.BehaviorSubject({
                            res: !1
                        }), this._controlError$ = new m.BehaviorSubject({
                            res: !1
                        }), this._subscriptions = [], this._bracketPercentPriceRuleCheckers = [], this.getValue = () => this._value$.getValue(), this.getFocusedControl = () => this._focusedControl$.getValue(), this.getEnabled = () => this._enabled$.getValue(), this.getBracketType = () => this._bracketType$.getValue(), this.getError = () => this._error$.getValue(), this.setFocusedControl = e => {
                            this._focusedControl$.next(e)
                        }, this.setEnabled = e => {
                            this._enabled$.next(e)
                        }, this.setBracketType = e => {
                            this._bracketType$.next(e)
                        }, this.setControlError = e => {
                            this._controlError$.next({
                                res: e,
                                msg: void 0
                            })
                        },
                        this._bracketValuesWithFocusedControlObservable = () => this._focusedControl$.pipe((0, ye.switchMap)(e => 1 === e ? this._priceObservable(e) : 2 === e ? this._riskInCurrencyObservable(e) : 3 === e ? this._riskInPercentObservable(e) : this._pipsObservable(e))), this._updateFocusIfNeeded = e => {
                            const t = this.getFocusedControl(),
                                i = this._supportCryptoBrackets ? "showCryptoBracketsInPercent" : "showBracketsInPercent",
                                s = this._supportCryptoBrackets ? "showCryptoBracketsInCurrency" : "showBracketsInCurrency";
                            (3 === t && !e[i] || 2 === t && !e[s]) && this.setFocusedControl(0)
                        }, this._getPips = () => this._pips$.getValue(), this._getPrice = () => this._price$.getValue(), this._getRiskInCurrency = () => this._riskInCurrency$.getValue(), this._getRiskInPercent = () => this._riskInPercent$.getValue(), this._setPips = e => {
                            this._pips$.next(fe(e, this._pipsFormatter))
                        }, this._setPrice = e => {
                            this._price$.next(fe(e, this._priceFormatter))
                        }, this._setRiskInCurrency = e => {
                            this._riskInCurrency$.next(fe(e, this._riskInCurrencyFormatter))
                        }, this._setRiskInPercent = e => {
                            this._riskInPercent$.next(fe(e, this._riskInPercentFormatter))
                        }, this._enabled$ = new m.BehaviorSubject(t), this._bracketType$ = new m.BehaviorSubject(i), this._equity$ = r, this._pipValue$ = a, this._side$ = l, this._sideSign$ = l.pipe((0, g.map)(e => (i !== M.BracketType.TakeProfit ? -1 : 1) * e)), this._quotes$ = o, this._amount$ = u, this._pipSize = n.pipSize, this._lotSize = n.lotSize, this._settings = y, this._parentType = _, this._priceType = i === M.BracketType.TakeProfit ? 1 : 2, this._supportCryptoBrackets = Boolean(V), this._isStatusEditing = 1 !== _ || k === T.OrderPanelStatus.Editing, this._pipsFormatter = new $.PriceFormatter(n.pipSize !== n.minTick ? 10 : 1), this._priceFormatter = s, this._riskInCurrencyFormatter = new $.PriceFormatter(100), this._riskInPercentFormatter = new $.PriceFormatter(100), this._priceMagnifier = n.priceMagnifier || 1, this._hasTrailingStopBracket = O, this._parentPrice$ = (0, S.combineLatest)({
                            parentPrice: h,
                            orderType: c,
                            bracketType: this._bracketType$,
                            quotes: this._quotes$,
                            parentSide: this._side$
                        }).pipe((0, g.map)(e => {
                            const {
                                parentPrice: t,
                                orderType: i,
                                bracketType: s,
                                quotes: r,
                                parentSide: o
                            } = e;
                            if (s === M.BracketType.TrailingStop) {
                                if (2 === i) return 1 === o ? (0, L.getAsk)(r) : (0, L.getBid)(r);
                                if (1 !== this._parentType) return 1 === o ? (0, L.getBid)(r) : (0, L.getAsk)(r)
                            }
                            return t
                        })), void 0 !== f)
                        for (const e of f) this._bracketPercentPriceRuleCheckers.push(ke(e.options.min, e.options.max));
                    this._priceStep = n.minTick || n.pipSize, i === M.BracketType.StopLoss && void 0 !== n.stopPriceStep && n.stopPriceStep !== this._priceStep && (this._priceStep = n.stopPriceStep, this.roundToStopLimitPriceStepRequired = !0), i === M.BracketType.TakeProfit && void 0 !== n.limitPriceStep && n.limitPriceStep !== this._priceStep && (this._priceStep = n.limitPriceStep, this.roundToStopLimitPriceStepRequired = !0), (0, S.combineLatest)({
                        parentPrice: this._parentPrice$,
                        sideSign: this._sideSign$,
                        pipValue: this._pipValue$,
                        equity: this._equity$,
                        amount: this._amount$
                    }).pipe((0, ge.take)(1)).subscribe(t => {
                        const {
                            parentPrice: s,
                            sideSign: r,
                            pipValue: o,
                            equity: n,
                            amount: a
                        } = t;
                        let l, u, h = 0;
                        null !== e ? (h = 1, l = null, u = e) : (l = null !== b ? b : this._getDefaultPips(i), u = null);
                        const {
                            pips: c,
                            price: d,
                            riskInCurrency: p,
                            riskInPercent: _
                        } = this._calculateBracketValues({
                            sideSign: r,
                            pipValue: o,
                            equity: n,
                            parentPrice: s,
                            amount: a,
                            focusedControl: h,
                            pips: l,
                            price: u,
                            riskInCurrency: null,
                            riskInPercent: null
                        });
                        this.setFocusedControl(h), this._setPips(c), this._setPrice(d), this._setRiskInCurrency(p), this._setRiskInPercent(_), this.isValuesInitialized = !0
                    }), this._bracketValuesWithFocusedControl$ = this._bracketValuesWithFocusedControlObservable(), this.pips = {
                        value$: this._pips$.asObservable(),
                        step: 1,
                        formatter: this._pipsFormatter,
                        getValue: this._getPips,
                        setValue: this._setPips,
                        onModifiedCallback: null !== P ? () => P.setBracketControlModifiedProperty(i, T.BracketSubControlType.Pips) : () => {}
                    }, this.price = {
                        value$: this._price$.asObservable(),
                        step: this._priceStep,
                        formatter: this._priceFormatter,
                        getValue: this._getPrice,
                        setValue: this._setPrice,
                        onModifiedCallback: null !== P ? () => P.setBracketControlModifiedProperty(i, T.BracketSubControlType.Price) : () => {}
                    }, this.riskInCurrency = {
                        value$: this._riskInCurrency$.asObservable(),
                        step: .01,
                        formatter: this._riskInCurrencyFormatter,
                        getValue: this._getRiskInCurrency,
                        setValue: this._setRiskInCurrency,
                        onModifiedCallback: null !== P ? () => P.setBracketControlModifiedProperty(i, T.BracketSubControlType.Money) : () => {}
                    }, this.riskInPercent = {
                        value$: this._riskInPercent$.asObservable(),
                        step: .01,
                        formatter: this._riskInPercentFormatter,
                        getValue: this._getRiskInPercent,
                        setValue: this._setRiskInPercent,
                        onModifiedCallback: null !== P ? () => P.setBracketControlModifiedProperty(i, T.BracketSubControlType.Percent) : () => {}
                    }, this.value$ = this._value$.asObservable(), this.enabled$ = this._enabled$.asObservable(), this.bracketType$ = this._bracketType$.asObservable(), this.focusedControl$ = this._focusedControl$.asObservable(), this.error$ = this._error$.asObservable(), this.controlState = this._computeControlState(_, i, C, w, B), this.currency = p.length > 0 ? p : (0, d.t)("Money"), this.showRiskControls = v
                }
                subscribe() {
                    this._settings.subscribe(this._updateFocusIfNeeded);
                    const e = (0, S.combineLatest)({
                            enabled: this._enabled$,
                            parentPrice: this._parentPrice$,
                            sideSign: this._sideSign$,
                            pipValue: this._pipValue$,
                            equity: this._equity$,
                            amount: this._amount$,
                            bracketValuesWithFocusedControl: this._bracketValuesWithFocusedControl$
                        }).subscribe(e => {
                            const {
                                enabled: t,
                                parentPrice: i,
                                sideSign: s,
                                pipValue: r,
                                equity: o,
                                amount: n,
                                bracketValuesWithFocusedControl: a
                            } = e, {
                                focusedControl: l,
                                pips: u,
                                price: h,
                                riskInCurrency: c,
                                riskInPercent: d
                            } = a, {
                                pips: p,
                                price: _,
                                riskInCurrency: b,
                                riskInPercent: y
                            } = this._calculateBracketValues({
                                sideSign: s,
                                pipValue: r,
                                equity: o,
                                parentPrice: i,
                                amount: n,
                                focusedControl: l,
                                pips: u,
                                price: h,
                                riskInCurrency: c,
                                riskInPercent: d
                            });
                            !t && null !== c || u === p && h === _ && c === b && d === y || this._setValuesForUnfocusedControls(l, p, _, b, y)
                        }),
                        t = (0, S.combineLatest)({
                            side: this._side$,
                            enabled: this._enabled$,
                            controlError: this._controlError$,
                            bracketValuesWithFocusedControl: this._bracketValuesWithFocusedControl$,
                            parentPrice: this._parentPrice$,
                            quotes: this._quotes$,
                            bracketType: this._bracketType$
                        }).subscribe(e => {
                            const {
                                side: t,
                                enabled: i,
                                controlError: s,
                                bracketValuesWithFocusedControl: r,
                                parentPrice: o,
                                quotes: n,
                                bracketType: a
                            } = e, {
                                focusedControl: l,
                                pips: u,
                                price: h
                            } = r;
                            i && this._setError({
                                side: t,
                                parentPrice: o,
                                quotes: n,
                                bracketType: a,
                                controlError: s,
                                focusedControl: l,
                                pips: u,
                                price: h
                            })
                        }),
                        i = (0, S.combineLatest)({
                            pips: this._pips$,
                            error: this._error$,
                            enabled: this._enabled$
                        }).subscribe(e => {
                            const {
                                pips: t,
                                error: i,
                                enabled: s
                            } = e;
                            this._value$.next(i.res || !s || null === t ? null : (0, J.Big)(t).div(this._priceMagnifier).toNumber())
                        });
                    return this._subscriptions = [e, t, i], this._subscriptions
                }
                unsubscribe() {
                    this._subscriptions.forEach(e => e.unsubscribe()), this._settings.unsubscribe(this._updateFocusIfNeeded)
                }
                isValueIncorrect() {
                    const e = this.getEnabled(),
                        t = this.getValue();
                    return e && null === t
                }
                _getDefaultPips(e) {
                    return e === M.BracketType.TakeProfit ? T.BracketDefaultPips.TakeProfit : T.BracketDefaultPips.StopLoss
                }
                _setValuesForUnfocusedControls(e, t, i, s, r) {
                    0 !== e && this._setPips(t), 1 !== e && this._setPrice(i), 2 !== e && this._setRiskInCurrency(s), 3 !== e && this._setRiskInPercent(r)
                }
                _setError(e) {
                    const {
                        side: t,
                        parentPrice: i,
                        quotes: s,
                        bracketType: r,
                        controlError: o,
                        focusedControl: n,
                        pips: a,
                        price: l
                    } = e;
                    if (o.res) return void this._error$.next(o);
                    let u = {
                        res: !1
                    };
                    null === l || null === a ? u = {
                        res: !0,
                        msg: "Order don't have price or pips."
                    } : (u = 2 === this._parentType ? this._checkPositionError(t, l, i, r, s) : this._checkOrderError(t, a, l, i, r), this.roundToStopLimitPriceStepRequired && !u.res && 1 === n && (u = function(e, t, i) {
                        return (0, L.isMintickMultiple)(e, t) ? {
                            res: !1
                        } : {
                            res: !0,
                            msg: (0, d.t)("Bracket price should be a multiple of {minTick}").format({
                                minTick: i.format(t)
                            })
                        }
                    }(l, this._priceStep, this._priceFormatter))), this._error$.next(u)
                }
                _checkBracketPercentValidationRules(e, t, i, s) {
                    for (const r of this._bracketPercentPriceRuleCheckers) {
                        const o = r(t, i, e, s, this._priceType, this._priceStep, this._isStatusEditing, this.getEnabled());
                        if (o.res) return o
                    }
                    return {
                        res: !1
                    }
                }
                _checkOrderError(e, t, i, s, r) {
                    let o = this._bracketPercentPriceRuleCheckers.length > 0 ? this._checkBracketPercentValidationRules(e, i, s, r) : {
                        res: !1
                    };
                    if (t <= 0 || i <= 0) {
                        const t = r === M.BracketType.TakeProfit ? ve.orderTakeProfit : ve.orderStopLoss;
                        o = {
                            res: !0,
                            msg: 1 === e ? t.long : t.short
                        }
                    }
                    return o
                }
                _checkPositionError(e, t, i, s, r) {
                    const o = (s === M.BracketType.TakeProfit ? -1 : 1) * e,
                        n = -1 === e ? (0, L.getAsk)(r) : (0, L.getBid)(r),
                        a = -1 === e ? (0, d.t)("ask") : (0, d.t)("bid"),
                        l = s === M.BracketType.TakeProfit ? ve.positionTakeProfit : ve.positionStopLoss;
                    let u = this._bracketPercentPriceRuleCheckers.length > 0 ? this._checkBracketPercentValidationRules(e, t, i, s) : {
                        res: !1
                    };
                    return n && Math.sign(t - n) === o && (u = {
                        res: !0,
                        msg: -1 === e ? l.short(a) : l.long(a)
                    }), u
                }
                _pipsObservable(e) {
                    return this._pips$.pipe((0, ye.switchMap)(t => (0, Pe.zip)([this._price$, this._riskInCurrency$, this._riskInPercent$]).pipe((0, g.map)(i => {
                        const [s, r, o] = i;
                        return {
                            focusedControl: e,
                            pips: t,
                            price: s,
                            riskInCurrency: r,
                            riskInPercent: o
                        }
                    }))))
                }
                _priceObservable(e) {
                    return this._price$.pipe((0, ye.switchMap)(t => (0, Pe.zip)([this._pips$, this._riskInCurrency$, this._riskInPercent$]).pipe((0, g.map)(i => {
                        const [s, r, o] = i;
                        return {
                            focusedControl: e,
                            pips: s,
                            price: t,
                            riskInCurrency: r,
                            riskInPercent: o
                        }
                    }))))
                }
                _riskInCurrencyObservable(e) {
                    return this._riskInCurrency$.pipe((0, ye.switchMap)(t => (0, Pe.zip)([this._pips$, this._price$, this._riskInPercent$]).pipe((0, g.map)(i => {
                        const [s, r, o] = i;
                        return {
                            focusedControl: e,
                            pips: s,
                            price: r,
                            riskInCurrency: t,
                            riskInPercent: o
                        }
                    }))))
                }
                _riskInPercentObservable(e) {
                    return this._riskInPercent$.pipe((0, ye.switchMap)(t => (0, Pe.zip)([this._pips$, this._price$, this._riskInCurrency$]).pipe((0, g.map)(i => {
                        const [s, r, o] = i;
                        return {
                            focusedControl: e,
                            pips: s,
                            price: r,
                            riskInCurrency: o,
                            riskInPercent: t
                        }
                    }))))
                }
                _calculateBracketValues(e) {
                    return {
                        pips: fe(this._calculatePips(e), this._pipsFormatter),
                        price: fe(this._calculatePrice(e), this._priceFormatter),
                        riskInCurrency: fe(this._calculateRiskInCurrency(e), this._riskInCurrencyFormatter),
                        riskInPercent: fe(this._calculateRiskInPercent(e), this._riskInPercentFormatter)
                    }
                }
                _calculatePips(e) {
                    const {
                        sideSign: t,
                        pipValue: i,
                        equity: s,
                        parentPrice: r,
                        amount: o,
                        focusedControl: n,
                        pips: a,
                        price: l,
                        riskInCurrency: u,
                        riskInPercent: h
                    } = e;
                    switch (n) {
                        case 0:
                            return a;
                        case 1:
                            return null === l ? null : (0, me.priceToPips)(l, r, t, this._pipSize);
                        case 2:
                            return null === u || null === o ? null : (0, me.riskInCurrencyToPips)(u, o, i, this._priceMagnifier, this._lotSize);
                        case 3:
                            return null === h || null === o ? null : (0, me.riskInPercentToPips)(h, o, s, i, this._priceMagnifier, this._lotSize);
                        default:
                            return a
                    }
                }
                _calculatePrice(e) {
                    const {
                        sideSign: t,
                        pipValue: i,
                        equity: s,
                        parentPrice: r,
                        amount: o,
                        focusedControl: n,
                        pips: a,
                        price: l,
                        riskInCurrency: u,
                        riskInPercent: h
                    } = e;
                    let d, p;
                    switch (n) {
                        case 0:
                            if (null === a) return null;
                            p = (0, me.pipsToPrice)(a, r, t, this._pipSize);
                            break;
                        case 1:
                            return l;
                        case 2:
                            if (null === u || null === o) return null;
                            d = (0, me.riskInCurrencyToPips)(u, o, i, this._priceMagnifier, this._lotSize), p = (0, me.pipsToPrice)(d, r, t, this._pipSize);
                            break;
                        case 3:
                            if (null === h || null === o) return null;
                            d = (0, me.riskInPercentToPips)(h, o, s, i, this._priceMagnifier, this._lotSize), p = (0, me.pipsToPrice)(d, r, t, this._pipSize);
                            break;
                        default:
                            if (null === a) return null;
                            p = (0, me.pipsToPrice)(a, r, t, this._pipSize)
                    }
                    return this.roundToStopLimitPriceStepRequired ? (0, c.roundToStepByPriceTypeAndSide)(p, this._priceStep, this._priceType, t) : p
                }
                _calculateRiskInCurrency(e) {
                    const {
                        sideSign: t,
                        pipValue: i,
                        equity: s,
                        parentPrice: r,
                        amount: o,
                        focusedControl: n,
                        pips: a,
                        price: l,
                        riskInCurrency: u,
                        riskInPercent: h
                    } = e;
                    let c;
                    const d = null === a || null === o;
                    switch (n) {
                        case 0:
                            return d ? null : (0, me.pipsToRiskInCurrency)(a, o, i, this._priceMagnifier, this._lotSize);
                        case 1:
                            return null === l || d ? null : (c = (0, me.priceToPips)(l, r, t, this._pipSize), (0, me.pipsToRiskInCurrency)(c, o, i, this._priceMagnifier, this._lotSize));
                        case 2:
                            return u;
                        case 3:
                            return null === h || d ? null : (c = (0, me.riskInPercentToPips)(h, o, s, i, this._priceMagnifier, this._lotSize), (0, me.pipsToRiskInCurrency)(c, o, i, this._priceMagnifier, this._lotSize));
                        default:
                            return d ? null : (0, me.pipsToRiskInCurrency)(a, o, i, this._priceMagnifier, this._lotSize)
                    }
                }
                _calculateRiskInPercent(e) {
                    const {
                        sideSign: t,
                        pipValue: i,
                        equity: s,
                        parentPrice: r,
                        amount: o,
                        focusedControl: n,
                        pips: a,
                        price: l,
                        riskInCurrency: u,
                        riskInPercent: h
                    } = e;
                    let c;
                    const d = null === a || null === o;
                    switch (n) {
                        case 0:
                            return d ? null : (0, me.pipsToRiskInPercent)(a, o, s, i, this._priceMagnifier, this._lotSize);
                        case 1:
                            return null === l || d ? null : (c = (0, me.priceToPips)(l, r, t, this._pipSize), (0, me.pipsToRiskInPercent)(c, o, s, i, this._priceMagnifier, this._lotSize));
                        case 2:
                            return null === u || null === o ? null : (c = (0, me.riskInCurrencyToPips)(u, o, i, this._priceMagnifier, this._lotSize), (0, me.pipsToRiskInPercent)(c, o, s, i, this._priceMagnifier, this._lotSize));
                        case 3:
                            return h;
                        default:
                            return d ? null : (0, me.pipsToRiskInPercent)(a, o, s, i, this._priceMagnifier, this._lotSize)
                    }
                }
                _computeControlState(e, t, i, s, r) {
                    const o = this._isStatusEditing && t === M.BracketType.TrailingStop && !s && this._hasTrailingStopBracket,
                        n = this._isStatusEditing && t !== M.BracketType.TakeProfit && this.getEnabled() && !s && this._hasTrailingStopBracket,
                        a = this._isStatusEditing && !i,
                        l = Boolean(1 === e && this._isStatusEditing && !this.getEnabled() && !r);
                    return {
                        inputDisabled: o || a || l,
                        labelDisabled: n || a || l,
                        checkboxDisabled: a || l
                    }
                }
            }
            var Ce = i(37538),
                Me = i(21603);
            class Te {
                constructor(e, t, i, s) {
                    this.onControlFocused = new(I()), this._stop$ = new Ce.Subject, this.durationMetaInfoList = t, this.orderType = i;
                    const r = this._getDurationByOrderType(e, i.value());
                    this.$value = new m.BehaviorSubject(r), this.currentDuration = new Y.WatchedObject(r, L.comparator), this._currentDurationSubscription = (0, L.makeSubjectFromWatchedValue)(this.currentDuration), this._orderTypeSubscription = (0, L.makeSubjectFromWatchedValue)(this.orderType), this._currentDurationSubscription.subject.pipe((0, Me.takeUntil)(this._stop$)).subscribe(e => {
                        this.$value.next(e)
                    }), this._orderTypeSubscription.subject.pipe((0, Me.takeUntil)(this._stop$)).subscribe(e => {
                        const t = this._getDurationByOrderType(this.getValue(), e);
                        this.currentDuration.setValue(t)
                    }), this.onModifiedCallback = null !== s ? () => s.setDurationControlModifiedProperty() : () => {}
                }
                isDurationsAvailable() {
                    return null !== this._getDurationByOrderType(this.currentDuration.value(), this.orderType.value())
                }
                unsubscribe() {
                    this._stop$.next(), this._stop$.complete(), this._currentDurationSubscription.unsubscribe(), this._orderTypeSubscription.unsubscribe()
                }
                getValue() {
                    const e = this.$value.getValue();
                    if (null === e) return null;
                    const t = this.durationMetaInfoList.find(t => e.type === t.value);
                    if (void 0 === t) return null;
                    const i = {
                        type: e.type
                    };
                    return (t.hasDatePicker || t.hasTimePicker) && (i.datetime = e.datetime), i
                }
                _getDurationByOrderType(e, t) {
                    const i = (0, B.filterDurationsByOrderType)(t, this.durationMetaInfoList);
                    if (0 === i.length) return null;
                    return null !== e && i.some(t => e.type === t.value) ? e : (0, B.makeInitialOrderDuration)(t, i)
                }
            }
            var we = i(73587);

            function Ve(e, t = 100, i) {
                const s = new Map,
                    r = new Map;
                return function(...o) {
                    var n;
                    const a = String(i ? i.apply(null, o) : o),
                        l = Date.now();
                    if (s.has(a) && (null !== (n = r.get(a)) && void 0 !== n ? n : -1 / 0) > l) return s.get(a);
                    const u = e.apply(this, o);
                    return s.set(a, u), r.set(a, l + t), u
                }
            }
            const Ie = (0, n.getLogger)("Trading.LeverageViewModel");
            class Be {
                constructor({
                    adapterLeverageInfo: e,
                    adapterSetLeverage: t,
                    adapterPreviewLeverage: i,
                    brokerName: s,
                    symbol: r,
                    displaySymbol: n,
                    orderType$: a,
                    side$: l,
                    initialSide: u,
                    customFieldModels: h,
                    customFieldsGetter: p,
                    blocked$: _,
                    onBlockedClick: b
                }) {
                    this.onControlFocused = new(I()), this._leverageInfo$ = new m.BehaviorSubject(null),
                        this._leveragePreviewResult$ = new m.BehaviorSubject(null), this._subscriptions = [], this.leverageInfo = () => this._leverageInfo$.getValue(), this.leveragePreviewResult = () => this._leveragePreviewResult$.getValue(), this.setLeverage = async e => {
                            try {
                                const t = await this._adapterSetLeverage(e),
                                    i = this.leverageInfo();
                                null !== i && this._leverageInfo$.next({ ...i,
                                    leverage: t.leverage
                                })
                            } catch (e) {
                                throw Ie.logError("Failed to set leverage: " + (0, c.getLoggerMessage)(e)), new Error((0, d.t)("Failed to set leverage"))
                            }
                        }, this.previewLeverage = async e => {
                            try {
                                const t = await this._adapterPreviewLeverage(e);
                                return this._leveragePreviewResult$.next(t), t
                            } catch (e) {
                                throw this._leveragePreviewResult$.next(null), Ie.logError("Failed to preview leverage: " + (0, c.getLoggerMessage)(e)), new Error((0, d.t)("Failed to preview leverage"))
                            }
                        }, this._updateLeverageInfo = async () => {
                            if (this.getBlocked()) return;
                            const e = await this.getLeverageInfo({
                                symbol: this.symbol,
                                orderType: this.orderType,
                                side: this.side,
                                customFields: this.customFields
                            });
                            this._leverageInfo$.next(e)
                        }, this._adapterLeverageInfo = e, this._adapterSetLeverage = t, this._adapterPreviewLeverage = i, this.symbol = r, this.displaySymbol = n, this._orderType$ = a, this._side$ = l, this._customFieldModels = h, this.brokerName = s, this.leverageInfo$ = this._leverageInfo$.asObservable(), this.orderType = (0, o.ensureNotNull)(a.value), this.side = u, this.customFields = p(this._customFieldModels.value()), this._customFieldsGetter = p, this._blocked$ = _, this.blocked$ = this._blocked$.asObservable(), this.onBlockedClick = b, this._selectedItems$ = this._customFieldModels.value().filter(e => "ComboBox" === e.type && "selectedItem" in e).map(e => {
                            const t = (0, L.makeSubjectFromWatchedValue)(e.selectedItem);
                            return e.subscription = t, t.subject
                        }), this._subscribe(), this.getLeverageInfo = Ve(this.getLeverageInfo)
                }
                unsubscribe() {
                    this._subscriptions.forEach(e => {
                        e.unsubscribe()
                    })
                }
                async getLeverageInfo(e) {
                    try {
                        return await this._adapterLeverageInfo(e)
                    } catch (e) {
                        return Ie.logError("Failed to get leverage info: " + (0, c.getLoggerMessage)(e)), null
                    }
                }
                getBlocked() {
                    return this._blocked$.getValue()
                }
                _subscribe() {
                    const e = (0, S.combineLatest)([this._orderType$, this._side$]).pipe((0, we.skip)(1)).subscribe(async ([e, t]) => {
                            this.orderType = (0, o.ensureNotNull)(e), this.side = t, this._updateLeverageInfo()
                        }),
                        t = (0, S.combineLatest)(this._selectedItems$).pipe((0, we.skip)(1)).subscribe(() => {
                            this.customFields = this._customFieldsGetter(this._customFieldModels.value()), this._updateLeverageInfo()
                        }),
                        i = this.blocked$.pipe((0, we.skip)(1)).subscribe(this._updateLeverageInfo);
                    this._subscriptions = [e, t, i]
                }
            }
            i(35897);
            class Oe {
                constructor(e, t) {
                    this.getValue = () => this._value.getValue(), this.subscribe = () => {
                        const e = (0, o.ensureDefined)(this._props);
                        if (e.existingOrder || this._tradingEntityType === M.TradingEntityType.Position) return;
                        const t = {
                            status: e.status,
                            orderType: e.orderType,
                            orderPlacingStatus: e.orderPlacingStatus,
                            side: e.side,
                            quantity: e.quantity,
                            stopPrice: e.stopPrice,
                            limitPrice: e.limitPrice
                        };
                        this._orderSubscription = (0, S.combineLatest)(t).subscribe(this._orderSubscriptionValues)
                    }, this.unsubscribe = () => {
                        this._orderSubscription && this._orderSubscription.unsubscribe()
                    }, this._orderSubscriptionValues = e => {
                        const t = (0, o.ensureDefined)(this._props),
                            {
                                status: i,
                                orderType: s,
                                orderPlacingStatus: r,
                                side: n,
                                quantity: a,
                                stopPrice: l,
                                limitPrice: u
                            } = e;
                        if (i === T.OrderPanelStatus.Preview) return this._value.next((0, d.t)("Send"));
                        if (i === T.OrderPanelStatus.Wait) return r === T.OrderPlacingStatus.Placed ? this._value.next((0, d.t)("Order sent")) : this._value.next((0, d.t)("Click any field to activate order placement"));
                        const h = null !== l ? t.formatter.format(l) : "",
                            c = null !== u ? t.formatter.format(u) : "",
                            p = null !== a ? t.quantityFormatter.format(a) : "",
                            _ = 1 === n ? L.i18nOrderResultText.buy : L.i18nOrderResultText.sell;
                        switch (s) {
                            case 2:
                                return this._value.next(_.market(p, t.symbol));
                            case 3:
                                return this._value.next(_.stop(p, t.symbol, h));
                            case 1:
                                return this._value.next(_.limit(p, t.symbol, c));
                            case 4:
                                return this._value.next(_.stopLimit(p, t.symbol, h, c))
                        }
                    }, this._tradingEntityType = e, this._value = new m.BehaviorSubject(""), this.value$ = this._value.asObservable(), this._props = t, this._setInitialValue()
                }
                _setInitialValue() {
                    var e;
                    switch (this._tradingEntityType) {
                        case M.TradingEntityType.Order:
                            const t = !0 === (null === (e = this._props) || void 0 === e ? void 0 : e.existingOrder) ? (0, d.t)("Modify order") : "";
                            this._value.next(t);
                            break;
                        case M.TradingEntityType.Position:
                            this._value.next((0, d.t)("Modify"))
                    }
                }
            }
            class $e {
                constructor({
                    marginAvailable$: e,
                    qty$: t,
                    currency: i,
                    pipValue$: s,
                    price$: r,
                    side$: o,
                    showTotalInsteadOfTradeValue: n,
                    showRiskControls: a,
                    info: l,
                    tpInfo: u,
                    slInfo: c,
                    supportMargin: d,
                    pipValueType: p
                }) {
                    this._availableMargin = new(h())(0), this._usedMargin = new(h())(0), this._infoTableData = new Y.WatchedObject({
                        rows: []
                    }, L.comparator), this._tpEnabled$ = null, this._tpRiskInCurrency$ = null, this._tpRiskInPercent$ = null, this._slEnabled$ = null, this._slRiskInCurrency$ = null, this._slRiskInPercent$ = null, this._riskFormatter = new $.PriceFormatter(100), this._marginAvailable$ = e, this._qty$ = t, this._pipValue$ = s, this._side$ = o, this._type = l.type, this._pipValueType = p, this._currency = i, this._marginRate = l.marginRate, this._hasMarginMeter = d && void 0 !== this._marginRate, this._price$ = r, this._showTotalInsteadOfTradeValue = n, this._showRiskControls = a, this._bigPointValue = l.bigPointValue || 1, this._instrumentCurrency = l.currency, this._leverage = l.leverage, this._lotSize = l.lotSize, this._symbolPipSize = l.pipSize, this._pipValueForCurrentQuantity = 0, this._tradeValueInSymbolCurrency = 0, this._tradeValue = 0, this._priceMagnifier = l.priceMagnifier, u && c && (this._tpEnabled$ = u.enabled, this._tpRiskInCurrency$ = u.riskInCurrency, this._tpRiskInPercent$ = u.riskInPercent, this._slEnabled$ = c.enabled, this._slRiskInCurrency$ = c.riskInCurrency, this._slRiskInPercent$ = c.riskInPercent)
                }
                subscribe() {
                    const e = [this._price$, this._pipValue$, this._side$, this._qty$, null !== this._tpEnabled$ ? this._tpEnabled$ : (0, C.of)(null), null !== this._tpRiskInCurrency$ ? this._tpRiskInCurrency$ : (0, C.of)(null), null !== this._tpRiskInPercent$ ? this._tpRiskInPercent$ : (0, C.of)(null), null !== this._slEnabled$ ? this._slEnabled$ : (0, C.of)(null), null !== this._slRiskInCurrency$ ? this._slRiskInCurrency$ : (0, C.of)(null), null !== this._slRiskInPercent$ ? this._slRiskInPercent$ : (0, C.of)(null)],
                        t = [(0,
                            S.combineLatest)(e).subscribe(e => {
                            const [t, i, , s, r, o, n, a, l, u] = e;
                            if (this._pipValueForCurrentQuantity = (0, L.convertToBaseMonetaryUnit)((0, L.calculatePipValue)(s, i, this._lotSize), this._priceMagnifier), null === s) this._tradeValue = 0, this._tradeValueInSymbolCurrency = 0;
                            else {
                                const e = "crypto" === this._type ? (0, J.Big)(s).mul(t).toNumber() : (0, L.calculateTradeValue)(s, t, i, this._symbolPipSize, this._lotSize);
                                this._tradeValue = (0, L.convertToBaseMonetaryUnit)(e, this._priceMagnifier);
                                const r = (0, L.calculateTradeValueByBigPointValue)(s, t, this._bigPointValue, this._lotSize);
                                this._tradeValueInSymbolCurrency = (0, L.convertToBaseMonetaryUnit)(r, this._priceMagnifier)
                            }
                            this._usedMargin.setValue((0, L.calculateUsedMargin)(this._tradeValue, this._marginRate));
                            const h = [];
                            h.push(...this._makeLeverageInfo(), ...this._makeLotSizeInfo(), ...this._makePipValueInfo(), ...this._makeTradeValueInfo(), ...this._makeRewardInfo(r, o, n), ...this._makeRiskInfo(a, l, u)), this._infoTableData.setValue({
                                rows: h
                            })
                        })];
                    return this._hasMarginMeter && t.push((0, o.ensureNotNull)(this._marginAvailable$).subscribe(e => this._updateAvailableMargin(e))), t
                }
                title() {
                    return (0, d.t)("Order info")
                }
                infoTableData() {
                    return this._infoTableData
                }
                hasMarginMeter() {
                    return this._hasMarginMeter
                }
                availableMargin() {
                    return this._availableMargin
                }
                usedMargin() {
                    return this._usedMargin
                }
                pipValue() {
                    throw new Error("not supported")
                }
                tradeValue() {
                    throw new Error("not supported")
                }
                _updateAvailableMargin(e) {
                    this._availableMargin.setValue(e)
                }
                _makeLeverageInfo() {
                    const e = (0, L.displayedLeverage)(this._leverage, this._marginRate);
                    return null === e ? [] : [{
                        title: (0, d.t)("Leverage"),
                        value: e
                    }]
                }
                _makeLotSizeInfo() {
                    return "number" == typeof this._lotSize && Number.isFinite(this._lotSize) ? [{
                        title: (0, d.t)("Lot size"),
                        value: String(this._lotSize)
                    }] : []
                }
                _makePipValueInfo() {
                    return this._showRiskControls && this._pipValueType.value() !== M.PipValueType.None && Number.isFinite(this._pipValueForCurrentQuantity) ? [{
                        title: this._pipValueType.value() === M.PipValueType.Pips ? (0, d.t)("Pip value") : (0, d.t)("Tick value"),
                        value: `${this._currency} ${(0,L.formatInfoValue)(this._pipValueForCurrentQuantity)}`
                    }] : []
                }
                _makeTradeValueInfo() {
                    const e = this._getTradeValue();
                    if (void 0 === e) return [];
                    const t = this._showTotalInsteadOfTradeValue ? (0, d.t)("Total") : (0, d.t)("Trade value"),
                        i = this._getTradeValueInSymbolCurrency();
                    return void 0 === i ? [{
                        title: t,
                        value: `${this._currency} ${e}`
                    }] : [{
                        title: t
                    }, {
                        title: (0, d.t)("in account currency"),
                        value: `${this._currency} ${e}`,
                        listMarker: !0
                    }, {
                        title: (0, d.t)("in symbol currency"),
                        value: `${this._instrumentCurrency} ${i}`,
                        listMarker: !0
                    }]
                }
                _getTradeValue() {
                    const e = this._getMarginRate();
                    if (this._showRiskControls && Number.isFinite(this._tradeValue) && (this._isSymbolTypeSupportTradeValue() || void 0 !== e)) return (0, L.formatInfoValue)(this._tradeValue * (null != e ? e : 1))
                }
                _getTradeValueInSymbolCurrency() {
                    var e;
                    const t = null !== (e = this._getMarginRate()) && void 0 !== e ? e : 1;
                    if (void 0 !== this._instrumentCurrency && this._instrumentCurrency !== this._currency && Number.isFinite(this._tradeValueInSymbolCurrency)) return (0, L.formatInfoValue)(this._tradeValueInSymbolCurrency * t)
                }
                _getMarginRate() {
                    return void 0 !== this._marginRate && this._marginRate > 0 ? this._marginRate : void 0
                }
                _isSymbolTypeSupportTradeValue() {
                    return void 0 !== this._type && ["stock", "dr", "right", "bond", "warrant", "structured"].includes(this._type)
                }
                _makeRewardInfo(e, t, i) {
                    return this._showRiskControls && e && null !== t && null !== i ? [{
                        title: (0, d.t)("Reward"),
                        value: this._riskFormatter.format(i) + "% (" + this._currency + " " + this._riskFormatter.format(t) + ")"
                    }] : []
                }
                _makeRiskInfo(e, t, i) {
                    return this._showRiskControls && e && null !== t && null !== i ? [{
                        title: (0, d.t)("Risk"),
                        value: this._riskFormatter.format(i) + "% (" + this._currency + " " + this._riskFormatter.format(t) + ")"
                    }] : []
                }
            }
            const Le = (0, n.getLogger)("PromiseWithDefault");

            function qe(e, t, i) {
                return e.catch(e => (Le.logError(e), i && i(), t))
            }
            const Re = {
                symbol: (0, d.t)("Symbol"),
                ask: (0, d.t)("Ask"),
                bid: (0, d.t)("Bid"),
                orderType: (0, d.t)("Type"),
                side: (0, d.t)("Side"),
                quantity: (0, d.t)("Quantity"),
                price: (0, d.t)("Price"),
                stopPrice: (0, d.t)("Stop price"),
                limitPrice: (0, d.t)("Limit price"),
                currency: (0, d.t)("Currency"),
                stopLoss: (0, d.t)("Stop Loss"),
                takeProfit: (0, d.t)("Take Profit"),
                buy: (0, d.t)("Buy"),
                sell: (0, d.t)("Sell"),
                warning: (0, d.t)("Estimated money impact is for main order only.")
            };
            class Fe {
                constructor(e, t, i, s, r, o, n, a) {
                    this.warnings = [], this.errors = [], this._infoTableQuotesData = new Y.WatchedObject({
                        rows: []
                    }, L.comparator), this._infoTableOrderData = {
                        rows: []
                    }, this._infoTableCustomData = [], this.order = e, this.confirmId = t.confirmId, this.onCancelClick = s, this.onPlaceClick = r, this._quotes$ = i, this._currency = a, this._formatter = o, this._quantityFormatter = n, this._infoTableCustomData = t.sections, this._fillQuotesInfo(), this._fillOrderInfo(), (e.takeProfit || e.stopLoss) && this.warnings.push(Re.warning), t.warnings && this.warnings.push(...t.warnings), t.errors && this.errors.push(...t.errors)
                }
                subscribe() {
                    return this._quotes$.subscribe(e => this._fillQuotesInfo(e))
                }
                infoTableQuotesData() {
                    return this._infoTableQuotesData
                }
                infoTableOrderData() {
                    return this._infoTableOrderData
                }
                infoTableCustomData() {
                    return this._infoTableCustomData
                }
                _fillQuotesInfo(e) {
                    const t = [{
                        title: Re.symbol,
                        value: this.order.symbol
                    }, {
                        title: Re.ask,
                        value: e ? this._formatter.format(e.ask) : ""
                    }, {
                        title: Re.bid,
                        value: e ? this._formatter.format(e.bid) : ""
                    }];
                    this._infoTableQuotesData.setValue({
                        rows: t
                    })
                }
                _fillOrderInfo() {
                    this._infoTableOrderData.rows.push({
                        title: Re.orderType,
                        value: this.order.type ? T.orderTypes[this.order.type] : ""
                    }, {
                        title: Re.side,
                        value: 1 === this.order.side ? Re.buy : Re.sell,
                        type: 1 === this.order.side ? 0 : 1
                    }, {
                        title: Re.quantity,
                        value: this._quantityFormatter.format(this.order.qty)
                    }), 3 !== this.order.type && 1 !== this.order.type || this._infoTableOrderData.rows.push({
                        title: Re.price,
                        value: this._formatter.format(3 === this.order.type ? this.order.stopPrice : this.order.limitPrice)
                    }), 4 === this.order.type && this._infoTableOrderData.rows.push({
                        title: Re.stopPrice,
                        value: this._formatter.format(this.order.stopPrice)
                    }, {
                        title: Re.limitPrice,
                        value: this._formatter.format(this.order.limitPrice)
                    }), this.order.stopLoss && this._infoTableOrderData.rows.push({
                        title: Re.stopLoss,
                        value: String(this.order.stopLoss)
                    }), this.order.takeProfit && this._infoTableOrderData.rows.push({
                        title: Re.takeProfit,
                        value: String(this.order.takeProfit)
                    }), this._currency.length > 0 && this._infoTableOrderData.rows.push({
                        title: Re.currency,
                        value: this._currency
                    })
                }
            }
            const De = (0, n.getLogger)("Trading.OrderViewModel");

            function Ee(e) {
                return "ComboBox" === e.type
            }
            class Ne {
                constructor({
                    adapter: e,
                    order: t,
                    mode: i,
                    settings: s,
                    isTradable: r,
                    isTradingPanelVisible: n,
                    isTradingPanelOpened: a,
                    orderWidgetStat: l = null,
                    pipValueType: u,
                    onNeedSelectBroker: c,
                    trackEvent: g,
                    toggleTradingWidget: P,
                    showErrorNotification: S,
                    handler: C,
                    savedInputState: V,
                    forceAbsolutePriceUpdate: B,
                    qtySuggester: q
                }) {
                    if (this.orderType = new(h())(null), this.orderInfoModel = null, this.orderPreviewModel = null, this.customFieldModels = new(h())([]), this.onDoneButtonClicked = (0, p.createDeferredPromise)(), this.status = new(h())(T.OrderPanelStatus.Active), this.rewardRisk = new(h())(""), this.disabled = new(h())(!0), this.loading = new(h())(!1), this.needSignIn = !1, this.noBroker = !1, this.isNoQuotes = new(h())(!1), this.symbolHasLotSize = !1, this.id = (0, w.randomHashN)(6), this.existingOrder = !1, this._isEmptyRequiredCustomFieldsHighlighted = new(h())(!1), this._prevOrderType = new(h())(null), this._onModeChanged = new(I()), this._onInputStateChanged = new(I()), this._onCloseButtonClicked = new(I()), this._onBackButtonClicked = new(I()), this._subscriptions = [], this._stopLossPips = new m.BehaviorSubject(null), this._orderWidgetStat = null, this._existingPlacedOrder = null, this._marginAvailable$ = null, this._baseCurrencyCryptoBalance$ = null, this._quoteCurrencyCryptoBalance$ = null, this._orderPlacingStatus = new m.BehaviorSubject(T.OrderPlacingStatus.Creating), this._destroyed = !1, this._setSolutionAccount = null, this._isBats = !1, this._isCustomFieldsNotSelected$ = new m.BehaviorSubject(!1), this.doneButtonClick = () => {
                            var e;
                            if (this.loading.value()) return;
                            this.loading.setValue(!0);
                            const t = this.sideModel.currentQuotes(),
                                i = this.sideModel.getValue(),
                                s = null !== (e = 1 === i ? t.ask : t.bid) && void 0 !== e ? e : 0;
                            let r = {
                                symbol: this.symbol,
                                type: (0, o.ensureNotNull)(this.orderType.value()),
                                side: i,
                                qty: 0,
                                seenPrice: s
                            };
                            r.qty = (0, o.ensureNotNull)(this.quantityModel.$value.getValue()), 4 === this.orderType.value() ? (r.stopPrice = (0, o.ensureNotNull)(this.stopPriceModel.$value.getValue()), r.limitPrice = (0, o.ensureNotNull)(this.limitPriceModel.$value.getValue())) : 3 === this.orderType.value() ? r.stopPrice = (0, o.ensureNotNull)(this.stopPriceModel.$value.getValue()) : 1 === this.orderType.value() && (r.limitPrice = (0, o.ensureNotNull)(this.limitPriceModel.$value.getValue()));
                            const n = this.durationModel.getValue();
                            null !== n && (r.duration = n), this.stopLossModel && (delete r.stopLoss, delete r.trailingStopPips, this.stopLossModel.getBracketType() === M.BracketType.StopLoss && (r.stopLoss = this.stopLossModel.getEnabled() ? (0, o.ensureNotNull)(this.stopLossModel.getValue() && this.stopLossModel.price.getValue()) : void 0, r.trailingStopPips = void 0), this.stopLossModel.getBracketType() === M.BracketType.TrailingStop && (r.trailingStopPips = this.stopLossModel.getEnabled() ? (0, o.ensureNotNull)(this.stopLossModel.getValue()) : void 0, r.stopLoss = void 0 !== r.trailingStopPips ? void 0 : r.stopLoss)),
                                this.takeProfitModel && (r.takeProfit = this.takeProfitModel.getEnabled() ? (0, o.ensureNotNull)(this.takeProfitModel.getValue() && this.takeProfitModel.price.getValue()) : void 0), Array.isArray(this.customFieldModels.value()) && (r.customFields = this._getCustomFields());
                            if ((this.existingOrder ? this.supportModifyOrderPreview : this.supportPlaceOrderPreview) && this._settings.value().showOrderPreview) {
                                if (null === this.orderPreviewModel) {
                                    const e = this.supportModifyOrderPreview && null !== this._existingPlacedOrder ? { ...r,
                                        id: this._existingPlacedOrder.id
                                    } : r;
                                    return void this._adapter.previewOrder(e).then(t => {
                                        const i = this.supportCurrencyInOrderPreview && void 0 !== this._symbolInfo.currency ? this._symbolInfo.currency : "";
                                        this.orderPreviewModel = new Fe(e, t, this._quotes$, this._back, this.doneButtonClick, this.formatter, this.quantityModel.formatter, i), this._subscriptions.push(this.orderPreviewModel.subscribe()), this.loading.setValue(!1), this.status.setValue(T.OrderPanelStatus.Preview)
                                    }).catch(e => {
                                        this.loading.setValue(!1), this._showErrorNotification((0, d.t)("Order preview"), "object" == typeof e ? e.message : e)
                                    })
                                }
                                r = this.orderPreviewModel.order
                            }
                            this._doneHandler(r, null !== this.orderPreviewModel ? this.orderPreviewModel.confirmId : void 0).then(e => {
                                this.loading.setValue(!1), e && (this.onDoneButtonClicked.resolve(!0), this.mode.value() === T.OrderEditorDisplayMode.Popup ? this.headerModel.close() : this._backToDefaultOrderPanel(), this.existingOrder || this._orderPlacingStatus.next(T.OrderPlacingStatus.Placed)), e || null === this.orderPreviewModel || this._back(), this.orderPreviewModel = null
                            })
                        }, this.activateOrderPanel = () => {
                            this.status.setValue(this.existingOrder ? T.OrderPanelStatus.Editing : T.OrderPanelStatus.Active), this.orderType.unsubscribe(this.activateOrderPanel), this.sideModel && this.sideModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.limitPriceModel && this.limitPriceModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.stopPriceModel && this.stopPriceModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.quantityModel && this.quantityModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.takeProfitModel && this.takeProfitModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.stopLossModel && this.stopLossModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.durationModel && this.durationModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), Array.isArray(this.customFieldModels.value()) && this.customFieldModels.value().length > 0 && this.customFieldModels.value().forEach(e => {
                                e.onControlFocused.unsubscribe(this, this.activateOrderPanel)
                            }), this._orderPlacingStatus.next(T.OrderPlacingStatus.Creating)
                        }, this._noQuotesCallback = () => {
                            this._trackEvent("Order Ticket", "No Quotes")
                        }, this._updateMode = () => {
                            this.mode.value() === T.OrderEditorDisplayMode.Popup && this.status.value() !== T.OrderPanelStatus.Preview && this.activateOrderPanel(), this.toggleCancelButton()
                        }, this._mergeInputStateDiff = e => {
                            void 0 !== e.duration && (this._currentInputState.duration = null), (0, _.default)(this._currentInputState, e)
                        },
                        this._syncOrderPricesAndFocuses = () => {
                            1 === this.orderType.value() && 4 === this._prevOrderType.value() && (this.limitPriceModel.forceAbsolutePriceUpdate(this.stopPriceModel.price.value()), this.limitPriceModel.forceRelativePriceUpdate()), 1 === this.orderType.value() && 3 === this._prevOrderType.value() && (this.limitPriceModel.forceAbsolutePriceUpdate(this.stopPriceModel.price.value()), this.limitPriceModel.focusedControl.setValue(this.stopPriceModel.focusedControl.value()), this.limitPriceModel.forceRelativePriceUpdate()), 3 === this.orderType.value() && 1 === this._prevOrderType.value() && (this.stopPriceModel.forceAbsolutePriceUpdate(this.limitPriceModel.price.value()), this.stopPriceModel.focusedControl.setValue(this.limitPriceModel.focusedControl.value()), this.stopPriceModel.forceRelativePriceUpdate()), 4 === this.orderType.value() && (1 === this._prevOrderType.value() && (this.stopPriceModel.forceAbsolutePriceUpdate(this.limitPriceModel.price.value()), this.stopPriceModel.forceRelativePriceUpdate()), 3 === this._prevOrderType.value() && this.limitPriceModel.forceAbsolutePriceUpdate(this.stopPriceModel.price.value()), this._syncStopLimitPrices(), this.limitPriceModel.forceStopLimitRelativePriceUpdate()), this._prevOrderType.setValue(this.orderType.value())
                        }, this._syncStopLimitPrices = () => {
                            4 === this.orderType.value() && this.limitPriceModel.syncWithPrice(this.stopPriceModel.price.value())
                        }, this._back = () => {
                            this._cleanUp(), this._onBackButtonClicked.fire()
                        }, this._highlightEmptyRequiredCustomFields = () => {
                            this._isEmptyRequiredCustomFieldsHighlighted.setValue(!0)
                        }, this._checkIsCustomFieldNotSelected = () => {
                            const e = [];
                            for (const t of this.customFieldModels.value()) Ee(t) && e.push(t);
                            const t = e.some(e => void 0 === e.selectedItem.value());
                            this._isCustomFieldsNotSelected$.next(t)
                        }, this._onSuggestedQtyChange = e => {
                            this._suggestedQty = e, this.quantityModel && this.quantityModel.quantity.value.value() !== e && (this.quantityModel.focusedControl.setValue(this.supportCryptoExchangeOrderTicket() ? 3 : 0), this.quantityModel.quantity.value.setValue(e))
                        }, this._onQtyChange = e => {
                            null !== e && this._qtySuggester.setQty(this.symbol, e)
                        }, this._toggleTradingWidget = P, this._onNeedSelectBroker = c, this._showErrorNotification = S, this._trackEvent = g, this._orderWidgetStat = l, this._pipValueType = u, this._qtySuggester = q, this.mode = i, this._settings = s,
                        function(e) {
                            return e.hasOwnProperty("id")
                        }(t) && (this.existingOrder = !0, this._existingPlacedOrder = t), this.status = new(h())(this.existingOrder ? T.OrderPanelStatus.Editing : T.OrderPanelStatus.Active), this.isEmptyRequiredCustomFieldsHighlighted = this._isEmptyRequiredCustomFieldsHighlighted.readonly(), this.symbol = t.symbol, this._orderStatusSubscription = (0, L.makeSubjectFromWatchedValue)(this.status), this._loadingSubscription = (0, L.makeSubjectFromWatchedValue)(this.loading), this._status = this._orderStatusSubscription.subject, this._loading = this._loadingSubscription.subject, this._isTradingPanelVisible = n, this._isTradingPanelOpened = a, this._stopLossAvailable = new m.BehaviorSubject(Boolean(t.trailingStopPips ? t.trailingStopPips : t.stopLoss)), null === e) return void(this.onReady = Promise.resolve());
                    if (this._adapter = e, this.brokerName = e.metainfo().title, !r.tradable) return void(this.onReady = this._prepareTradableSolution(r));
                    this._handler = C, this._orderTemplate = Object.assign({}, t), this.existingOrder = t.hasOwnProperty("id"), this.status.setValue(this.existingOrder ? T.OrderPanelStatus.Editing : T.OrderPanelStatus.Active);
                    const R = e.metainfo().configFlags;
                    this.supportModifyOrderPrice = R.supportModifyOrderPrice, this.supportModifyQuantity = !this.existingOrder || Boolean(this.existingOrder && R.supportEditAmount), this.showQuantityInsteadOfAmount = R.showQuantityInsteadOfAmount, this.supportMarketOrders = R.supportMarketOrders, this.supportLimitOrders = R.supportLimitOrders, this.supportStopOrders = R.supportStopOrders, this.supportStopLimitOrders = R.supportStopLimitOrders, this.supportBrackets = R.supportOrderBrackets && !(t.hasOwnProperty("parentId") && t.parentId), this.supportModifyBrackets = this.supportBrackets && R.supportModifyBrackets, this.supportAddBracketsToExistingOrder = this.supportModifyBrackets && R.supportAddBracketsToExistingOrder, this.supportTrailingStop = this.supportBrackets && R.supportTrailingStop, this.supportModifyTrailingStop = this.supportTrailingStop && R.supportModifyTrailingStop, this.supportMarketBrackets = this.supportBrackets && R.supportMarketBrackets, this.supportModifyDuration = R.supportModifyDuration, this.supportLeverage = R.supportLeverage, this.supportPlaceOrderPreview = R.supportPlaceOrderPreview, this.supportModifyOrderPreview = R.supportModifyOrderPreview, this.supportBalances = R.supportBalances, this.supportCryptoBrackets = R.supportCryptoBrackets, this.supportStopOrdersInBothDirections = R.supportStopOrdersInBothDirections, this.supportStopLimitOrdersInBothDirections = R.supportStopLimitOrdersInBothDirections, this.supportCurrencyInOrderPreview = R.supportCurrencyInOrderPreview, this.orderType.setValue("type" in t && t.type || this.supportLimitOrders && 1 || this.supportMarketOrders && 2 || this.supportStopLimitOrders && 4 || this.supportStopOrders && 3 || null), this._prevOrderType.setValue(this.orderType.value()), this._orderTypeSubscription = (0, L.makeSubjectFromWatchedValue)(this.orderType), this._orderType = this._orderTypeSubscription.subject, this.onReady = Promise.all([e.symbolInfo(t.symbol), e.getOrderDialogOptions(t.symbol), qe(e.accountMetainfo(), {
                        id: e.currentAccount(),
                        name: e.metainfo().title
                    }), qe(e.quotesSnapshot(t.symbol), {}, this._noQuotesCallback), qe(e.formatter(t.symbol, !1), new $.PriceFormatter), qe(e.spreadFormatter(t.symbol), new $.PriceFormatter)]).then(async ([i, s, o, n, a, l]) => {
                        this._isBats = (0, O.isBatsQuotes)(n), this._supportCryptoExchangeOrderTicket = R.supportCryptoExchangeOrderTicket || R.supportSymbolSpecificCryptoOrderTicket && "crypto" === i.type, this._symbolInfo = i, this._destroyed || (this.displaySymbolName = i.brokerSymbol || "brokerSymbol" in t && t.brokerSymbol || this.symbol, this.symbolType = i.type, this.currency = (0, O.getCurrency)(o), this._currencyName = (0, O.getCurrency)(o, !0), this.formatter = a, this.symbolHasLotSize = i.hasOwnProperty("lotSize"), this.showRiskControls = R.supportRiskControls && 0 !== i.pipValue, this._suggestedQty = await this._qtySuggester.getQty(this.symbol),
                            this._initialInputState = this._getInitialInputState(t, i, V), this._currentInputState = Object.assign({}, this._initialInputState), this.customFieldModels.setValue((0, L.createCustomFieldModels)(this.existingOrder, this.status, this._isEmptyRequiredCustomFieldsHighlighted, s, Object.assign(this._currentInputState.customFields || {}, t.customFields))), this._checkIsCustomFieldNotSelected(), this._quotes$ = (0, v.fromEventPattern)(i => e.subscribeRealtime(t.symbol, i), i => e.unsubscribeRealtime(t.symbol, i), (e, t) => (0, L.alignQuotesToMinTick)(t, i.minTick)).pipe((0, b.share)({
                                connector: () => new k.ReplaySubject(1)
                            })), this._equity$ = (0, v.fromEventPattern)(t => e.subscribeEquity(t), t => e.unsubscribeEquity(t), (e, t) => t).pipe((0, y.startWith)(NaN), (0, b.share)({
                                connector: () => new k.ReplaySubject(1)
                            })), this._marginAvailable$ = R.supportMargin ? (0, f.connectable)((0, v.fromEventPattern)(t => e.subscribeMarginAvailable(t), t => e.unsubscribeMarginAvailable(t), (e, t) => t)) : null, this._baseCurrencyCryptoBalance$ = R.supportBalances ? (0, f.connectable)((0, v.fromEventPattern)(t => e.subscribeCryptoBalance(i.baseCurrency || "", t), t => e.unsubscribeCryptoBalance(i.baseCurrency || "", t), (e, t) => t).pipe((0, y.startWith)({
                                symbol: i.baseCurrency || "",
                                total: 0,
                                available: 0
                            }))) : null, this._quoteCurrencyCryptoBalance$ = R.supportBalances ? (0, f.connectable)((0, v.fromEventPattern)(t => e.subscribeCryptoBalance(i.quoteCurrency || "", t), t => e.unsubscribeCryptoBalance(i.quoteCurrency || "", t), (e, t) => t).pipe((0, y.startWith)({
                                symbol: i.quoteCurrency || "",
                                total: 0,
                                available: 0
                            }))) : null, this._pipValues$ = (0, f.connectable)((0, v.fromEventPattern)(i => e.subscribePipValue(t.symbol, i), i => e.unsubscribePipValue(t.symbol, i), (e, t) => t).pipe((0, y.startWith)({
                                buyPipValue: i.pipValue,
                                sellPipValue: i.pipValue
                            }))), 0 === this._orderTemplate.limitPrice && !1 === this.existingOrder && (this._orderTemplate.limitPrice = 1 === this._initialInputState.side ? (0, L.getAsk)(n) : (0, L.getBid)(n)), 0 === this._orderTemplate.stopPrice && !1 === this.existingOrder && (this._orderTemplate.stopPrice = 1 === this._initialInputState.side ? (0, L.getBid)(n) : (0, L.getAsk)(n)), this._createModels(t, i, l, r.tradable, B, s), this._subscribe(), this._onInputStateChanged.fire(this._getCurrentInputState()))
                    }).catch(e => {
                        throw De.logError("Failed to create order model: " + e), e
                    })
                }
                destroy() {
                    this._destroyed = !0, this.onInputStateChanged().unsubscribe(this, this._mergeInputStateDiff), this._subscriptions.forEach(e => e && e.unsubscribe()), this._orderStatusSubscription.unsubscribe(), this._loadingSubscription.unsubscribe(), this._orderTypeSubscription && this._orderTypeSubscription.unsubscribe(), this.headerModel && (this.headerModel.unsubscribe(), this.headerModel.pinButtonClicked().unsubscribe(this, this._toggleMode), this.headerModel.cancelButtonClicked().unsubscribe(this, this._cancel), this.headerModel.closeButtonClicked().unsubscribe(this, this._closeWidget), this.headerModel.backButtonClicked().unsubscribe(this, this._back)), this.sideModel && (this.sideModel.unsubscribe(), this.sideModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), this.limitPriceModel && (this.limitPriceModel.unsubscribe(),
                        this.limitPriceModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), this.stopPriceModel && (this.stopPriceModel.price.unsubscribe(this._syncStopLimitPrices), this.stopPriceModel.unsubscribe(), this.stopPriceModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), this.quantityModel && (this.quantityModel.unsubscribe(), this.quantityModel.onControlFocused.unsubscribe(this, this.activateOrderPanel), this.quantityModel.quantity.value.unsubscribe(this._onQtyChange)), this.takeProfitModel && (this.takeProfitModel.unsubscribe(), this.takeProfitModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), this.stopLossModel && (this.stopLossModel.unsubscribe(), this.stopLossModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), this.durationModel && (this.durationModel.unsubscribe(), this.durationModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), void 0 !== this.leverageModel && (this.leverageModel.unsubscribe(), this.leverageModel.onControlFocused.unsubscribe(this, this.activateOrderPanel)), Array.isArray(this.customFieldModels.value()) && this.customFieldModels.value().length > 0 && this.customFieldModels.value().forEach(e => {
                        e.onControlFocused.unsubscribe(this, this.activateOrderPanel), e.subscription && e.subscription.unsubscribe()
                    }), void 0 !== this.buttonModel && this.buttonModel.unsubscribe(), this._customFieldsSubscription && this._customFieldsSubscription.unsubscribe(), this._adapter && this._adapter.orderUpdate.unsubscribe(this, this._orderUpdate), this.orderType.unsubscribe(this._syncOrderPricesAndFocuses), this.orderType.unsubscribe(this.activateOrderPanel), this.mode.unsubscribe(this._updateMode)
                }
                supportCryptoExchangeOrderTicket() {
                    return Boolean(this._supportCryptoExchangeOrderTicket)
                }
                onModeChanged() {
                    return this._onModeChanged
                }
                onInputStateChanged() {
                    return this._onInputStateChanged
                }
                onCloseButtonClicked() {
                    return this._onCloseButtonClicked
                }
                onBackButtonClicked() {
                    return this._onBackButtonClicked
                }
                side() {
                    var e;
                    return null === (e = this.sideModel) || void 0 === e ? void 0 : e.getValue()
                }
                setSolutionAccount() {
                    null !== this._setSolutionAccount && this._setSolutionAccount()
                }
                selectBroker() {
                    this._toggleTradingWidget().then(() => this._onNeedSelectBroker.fire())
                }
                orderWidgetStat() {
                    return this._orderWidgetStat
                }
                resetOrderPanel() {
                    this._cancel()
                }
                deactivateOrderPanel() {
                    this.status.value() !== T.OrderPanelStatus.Wait && (this.status.setValue(T.OrderPanelStatus.Wait), this.orderType.subscribe(this.activateOrderPanel), this.sideModel && this.sideModel.onControlFocused.subscribe(this, this.activateOrderPanel), this.limitPriceModel && this.limitPriceModel.onControlFocused.subscribe(this, this.activateOrderPanel), this.stopPriceModel && this.stopPriceModel.onControlFocused.subscribe(this, this.activateOrderPanel), this.quantityModel && this.quantityModel.onControlFocused.subscribe(this, this.activateOrderPanel), void 0 !== this.leverageModel && this.leverageModel.onControlFocused.subscribe(this, this.activateOrderPanel), this.takeProfitModel && (this.takeProfitModel.setEnabled(!1), this.takeProfitModel.onControlFocused.subscribe(this, this.activateOrderPanel)),
                        this.stopLossModel && (this.stopLossModel.setEnabled(!1), this.stopLossModel.onControlFocused.subscribe(this, this.activateOrderPanel)), this.durationModel && this.durationModel.onControlFocused.subscribe(this, this.activateOrderPanel), Array.isArray(this.customFieldModels.value()) && this.customFieldModels.value().length > 0 && this.customFieldModels.value().forEach(e => {
                            e.onControlFocused.subscribe(this, this.activateOrderPanel)
                        }), this._setDisabledIfNeeded({
                            status: this._status.getValue(),
                            loading: this._loading.getValue(),
                            quotes: null,
                            side: this.sideModel ? this.sideModel.getValue() : null,
                            limitPrice: this.limitPriceModel ? this.limitPriceModel.$value.getValue() : null,
                            stopPrice: this.stopPriceModel ? this.stopPriceModel.$value.getValue() : null,
                            quantity: this.quantityModel ? this.quantityModel.$value.getValue() : null,
                            isTakeProfitIncorrect: !!this.takeProfitModel && this.takeProfitModel.isValueIncorrect(),
                            isStopLossIncorrect: !!this.stopLossModel && this.stopLossModel.isValueIncorrect(),
                            customFields: this._getCustomFields(this.customFieldModels.value())
                        }))
                }
                toggleCancelButton() {
                    this.mode.value() === T.OrderEditorDisplayMode.Panel && this.status.value() === T.OrderPanelStatus.Active ? this.headerModel.showCancelButton() : this.headerModel.hideCancelButton()
                }
                _createSimpleDialog(e) {
                    this.orderType.setValue(null), this.status.setValue(T.OrderPanelStatus.Wait), this.headerModel = new U(this.symbol, this.symbol, e ? e.metainfo().title : "", this.mode, this.status, 1, !1, !1, this._quotes$, this._isTradingPanelVisible, void 0, void 0, this._isBats), this.headerModel.closeButtonClicked().subscribe(this, this._closeWidget)
                }
                _createModels(e, t, i, s, r, n) {
                    var a, l;
                    const u = this.supportCryptoExchangeOrderTicket();
                    this.sideModel = new K({
                        initialSide: this._initialInputState.side,
                        quotes$: this._quotes$,
                        priceFormatter: this.formatter,
                        spreadFormatter: i,
                        status: this.status,
                        baseCurrency: u && "crypto" === t.type && t.baseCurrency || null
                    }), this._pipValue$ = (0, S.combineLatest)([this._pipValues$, this.sideModel.value$]).pipe((0, g.map)(([e, t]) => 1 === t ? e.buyPipValue : e.sellPipValue));
                    const {
                        orderRules: h = [],
                        title: c
                    } = this._adapter.metainfo();
                    let d = [],
                        p = [];
                    var _, b;
                    this.supportStopOrdersInBothDirections && this.supportStopLimitOrdersInBothDirections || (d = null !== (_ = this._adapter, b = this.symbol, a = j(_, b, D)) && void 0 !== a ? a : [], p = null !== (l = function(e, t) {
                        return j(e, t, F)
                    }(this._adapter, this.symbol)) && void 0 !== l ? l : []), this.limitPriceModel = new re({
                        quotes$: this._quotes$,
                        side$: this.sideModel.value$,
                        initialSide: this.sideModel.getValue(),
                        info: t,
                        status: this.status,
                        price: this._orderTemplate.limitPrice,
                        formatter: this.formatter,
                        orderType: this.orderType,
                        isLimitPrice: !0,
                        settings: this._settings,
                        brokerTitle: c,
                        orderWidgetStat: this._orderWidgetStat,
                        orderRules: [...h, ...d],
                        forceAbsolutePriceUpdate: r
                    }), this.stopPriceModel = new re({
                        quotes$: this._quotes$,
                        side$: this.sideModel.value$,
                        initialSide: this.sideModel.getValue(),
                        info: t,
                        status: this.status,
                        price: this._orderTemplate.stopPrice,
                        formatter: this.formatter,
                        orderType: this.orderType,
                        isLimitPrice: !1,
                        settings: this._settings,
                        brokerTitle: c,
                        orderWidgetStat: this._orderWidgetStat,
                        orderRules: [...h, ...p],
                        forceAbsolutePriceUpdate: r,
                        supportStopOrdersInBothDirections: this.supportStopOrdersInBothDirections,
                        supportStopLimitOrdersInBothDirections: this.supportStopLimitOrdersInBothDirections
                    }), this._syncStopLimitPrices(), this._price$ = (0, S.combineLatest)([this._orderType, this.sideModel.value$, this._quotes$, this.stopPriceModel.$value, this.limitPriceModel.$value]).pipe((0, g.map)(([e, t, i, s, r]) => {
                        const o = 1 === t ? (0, L.getAsk)(i) : (0, L.getBid)(i),
                            n = (i.trade ? i.trade : o) || 0;
                        switch (this._initialInputState.limitPrice = o, this._initialInputState.stopPrice = o, e) {
                            case 1:
                            case 4:
                                return (null === r ? this.limitPriceModel.price.value() : r) || n;
                            case 3:
                                return (null === s ? this.stopPriceModel.price.value() : s) || n;
                            default:
                                return o
                        }
                    }), (0, P.distinctUntilChanged)()), this.quantityModel = u ? new be({
                        info: t,
                        price$: this._price$,
                        baseCurrencyCryptoBalance$: this._baseCurrencyCryptoBalance$,
                        quoteCurrencyCryptoBalance$: this._quoteCurrencyCryptoBalance$,
                        initialQty: this._initialInputState.quantity,
                        status: this.status,
                        side$: this.sideModel.value$,
                        sideGetter: this.sideModel.getValue,
                        orderWidgetStat: this._orderWidgetStat,
                        isExistingOrder: this.existingOrder,
                        orderQty: e.qty,
                        orderPrice: 1 === e.type ? e.limitPrice : e.stopPrice
                    }) : new pe(this._stopLossAvailable, this._stopLossPips, this._equity$, this._pipValue$, t, (0, o.ensureDefined)(this.currency), this._initialInputState.quantity, this.status, this._settings, this._orderWidgetStat, this.showRiskControls), this.quantityModel.quantity.value.subscribe(this._onQtyChange), (this.supportBrackets || this.supportCryptoBrackets) && this._createBracketsModels(e, t, (0, o.ensureDefined)(this.currency)), this.headerModel = new U(this.displaySymbolName, this.symbol, this._adapter.metainfo().title, this.mode, this.status, 1, this.existingOrder, s, this._quotes$, this._isTradingPanelVisible, e, this.formatter, this._isBats);
                    const y = (0, L.shouldShowTotal)(n);
                    u || (this.orderInfoModel = new $e({
                        marginAvailable$: this._marginAvailable$,
                        qty$: this.quantityModel.$value,
                        currency: (0, o.ensureDefined)(this._currencyName),
                        pipValue$: this._pipValue$,
                        price$: this._price$,
                        side$: this.sideModel.value$,
                        showTotalInsteadOfTradeValue: y,
                        showRiskControls: this.showRiskControls,
                        info: t,
                        tpInfo: this.supportBrackets && this.takeProfitModel ? {
                            enabled: this.takeProfitModel.enabled$,
                            riskInCurrency: this.takeProfitModel.riskInCurrency.value$,
                            riskInPercent: this.takeProfitModel.riskInPercent.value$
                        } : null,
                        slInfo: this.supportBrackets && this.stopLossModel ? {
                            enabled: this.stopLossModel.enabled$,
                            riskInCurrency: this.stopLossModel.riskInCurrency.value$,
                            riskInPercent: this.stopLossModel.riskInPercent.value$
                        } : null,
                        supportMargin: this._adapter.metainfo().configFlags.supportMargin || !1,
                        pipValueType: this._pipValueType
                    })), this.durationModel = new Te(this._initialInputState.duration, this._getDurationMetaInfoList(), this.orderType, this._orderWidgetStat), this.supportLeverage && (this.leverageModel = new Be({
                        adapterLeverageInfo: this._adapter.leverageInfo,
                        adapterSetLeverage: this._adapter.setLeverage,
                        adapterPreviewLeverage: this._adapter.previewLeverage,
                        brokerName: this._adapter.metainfo().title,
                        symbol: this.symbol,
                        displaySymbol: this.displaySymbolName,
                        orderType$: this._orderType,
                        side$: this.sideModel.value$,
                        initialSide: this.sideModel.getValue(),
                        customFieldModels: this.customFieldModels,
                        customFieldsGetter: this._getCustomFields,
                        blocked$: this._isCustomFieldsNotSelected$,
                        onBlockedClick: this._highlightEmptyRequiredCustomFields
                    }));
                    const m = {
                        orderType: (0, L.makeSubjectFromWatchedValue)(this.orderType).subject.asObservable(),
                        side: this.sideModel.value$,
                        quantity: this.quantityModel.$value.asObservable(),
                        symbol: this.displaySymbolName,
                        stopPrice: this.stopPriceModel.$value.asObservable(),
                        limitPrice: this.limitPriceModel.$value.asObservable(),
                        formatter: this.formatter,
                        quantityFormatter: this.quantityModel.formatter,
                        orderPlacingStatus: this._orderPlacingStatus.asObservable(),
                        status: (0, L.makeSubjectFromWatchedValue)(this.status).subject.asObservable(),
                        existingOrder: this.existingOrder
                    };
                    this.buttonModel = new Oe(M.TradingEntityType.Order, m)
                }
                _createBracketsModels(e, t, i) {
                    const s = Q(this._adapter, this.symbol),
                        r = W(this._adapter, this.symbol);
                    this.takeProfitModel = new Se({
                        initialPrice: e.takeProfit || null,
                        initialEnabled: Boolean(e.takeProfit),
                        initialBracketType: M.BracketType.TakeProfit,
                        formatter: this.formatter,
                        equity$: this._equity$,
                        quotes$: this._quotes$,
                        info: t,
                        pipValue$: this._pipValue$,
                        side$: this.sideModel.value$,
                        amount$: this.quantityModel.$value,
                        parentPrice$: this._price$,
                        orderType$: this._orderType,
                        currency: i,
                        parentType: 1,
                        savedPips: this._currentInputState.takeProfitPips,
                        settings: this._settings,
                        orderWidgetStat: this._orderWidgetStat,
                        showRiskControls: this.showRiskControls,
                        status: this.status.value(),
                        validationRules: s,
                        supportModifyBrackets: this.supportModifyBrackets,
                        supportModifyTrailingStop: this.supportModifyTrailingStop,
                        supportCryptoBrackets: this.supportCryptoBrackets,
                        supportAddBracketsToExistingOrder: this.supportAddBracketsToExistingOrder
                    });
                    const o = Boolean(e.trailingStopPips);
                    this.stopLossModel = new Se({
                        initialPrice: o ? null : e.stopLoss || null,
                        initialEnabled: Boolean(o ? e.trailingStopPips : e.stopLoss),
                        initialBracketType: o ? M.BracketType.TrailingStop : M.BracketType.StopLoss,
                        formatter: this.formatter,
                        equity$: this._equity$,
                        quotes$: this._quotes$,
                        info: t,
                        pipValue$: this._pipValue$,
                        side$: this.sideModel.value$,
                        amount$: this.quantityModel.$value,
                        parentPrice$: this._price$,
                        orderType$: this._orderType,
                        currency: i,
                        parentType: 1,
                        savedPips: (o ? e.trailingStopPips : this._currentInputState.stopLossPips) || null,
                        settings: this._settings,
                        orderWidgetStat: this._orderWidgetStat,
                        showRiskControls: this.showRiskControls,
                        status: this.status.value(),
                        validationRules: r,
                        supportModifyBrackets: this.supportModifyBrackets,
                        supportModifyTrailingStop: this.supportModifyTrailingStop,
                        supportCryptoBrackets: this.supportCryptoBrackets,
                        supportAddBracketsToExistingOrder: this.supportAddBracketsToExistingOrder,
                        hasTrailingStopBracket: e.hasTrailingStopBracket
                    }), this.supportCryptoExchangeOrderTicket() || (this.stopLossModel.focusedControl$.subscribe(e => {
                        2 !== e && 3 !== e || this.quantityModel.focusedControl.setValue(0)
                    }), this.quantityModel.focusedControl.subscribe(e => {
                        !this.stopLossModel || 1 === this.stopLossModel.getFocusedControl() || 1 !== e && 2 !== e || this.stopLossModel.setFocusedControl(0)
                    }))
                }
                _subscribe() {
                    var e, t, i, s, r, o, n, a;
                    if (this.mode.subscribe(this._updateMode), this.onInputStateChanged().subscribe(this, this._mergeInputStateDiff), this.headerModel.pinButtonClicked().subscribe(this, this._toggleMode), this.headerModel.cancelButtonClicked().subscribe(this, this._cancel), this.headerModel.closeButtonClicked().subscribe(this, this._closeWidget), this.headerModel.backButtonClicked().subscribe(this, this._back), this._buttonDataSubscription = (0, S.combineLatest)({
                            status: this._status,
                            side: this.sideModel.value$,
                            loading: this._loading,
                            quotes: this._quotes$,
                            limitPrice: this.limitPriceModel.$value,
                            stopPrice: this.stopPriceModel.$value,
                            quantity: this.quantityModel.$value,
                            takeProfitPips: null !== (t = null === (e = this.takeProfitModel) || void 0 === e ? void 0 : e.value$) && void 0 !== t ? t : (0, C.of)(null),
                            stopLossPips: null !== (s = null === (i = this.stopLossModel) || void 0 === i ? void 0 : i.value$) && void 0 !== s ? s : (0, C.of)(null),
                            takeProfitEnabled: null !== (o = null === (r = this.takeProfitModel) || void 0 === r ? void 0 : r.enabled$) && void 0 !== o ? o : (0, C.of)(!1),
                            stopLossEnabled: null !== (a = null === (n = this.stopLossModel) || void 0 === n ? void 0 : n.enabled$) && void 0 !== a ? a : (0, C.of)(!1),
                            duration: this.durationModel.$value
                        }).subscribe(e => {
                            const {
                                status: t,
                                side: i,
                                loading: s,
                                quotes: r,
                                limitPrice: o,
                                stopPrice: n,
                                quantity: a,
                                takeProfitPips: l,
                                stopLossPips: u,
                                takeProfitEnabled: h,
                                stopLossEnabled: c,
                                duration: d
                            } = e;
                            this._setDisabledIfNeeded({
                                status: t,
                                loading: s,
                                quotes: r,
                                side: i,
                                limitPrice: o,
                                stopPrice: n,
                                quantity: a,
                                isTakeProfitIncorrect: h && null === l,
                                isStopLossIncorrect: c && null === u,
                                customFields: this._getCustomFields(this.customFieldModels.value())
                            }), this._compareInputStates({
                                side: i,
                                limitPrice: o,
                                stopPrice: n,
                                quantity: a,
                                takeProfitPips: l,
                                stopLossPips: u,
                                duration: d
                            })
                        }), this._waitQuotesTimeout = setTimeout(() => this.isNoQuotes.setValue(!0), 5e3), this._noQuotesSubscription = this._quotes$.subscribe(e => {
                            this.isNoQuotes.setValue((0, L.isNoQuotes)(e)), clearTimeout(this._waitQuotesTimeout)
                        }), this.customFieldModels) {
                        const e = [];
                        for (const t of this._getSavableCustomFieldsModels()) {
                            const i = "Checkbox" === t.type ? t.checked : t.selectedItem,
                                s = (0, L.makeSubjectFromWatchedValue)(i);
                            e.push(s.subject), t.subscription = s
                        }
                        this._customFieldsSubscription = (0, S.combineLatest)(e).subscribe(() => {
                            this._setDisabledIfNeeded({
                                status: this._status.getValue(),
                                loading: this._loading.getValue(),
                                quotes: this.sideModel.currentQuotes(),
                                side: this.sideModel ? this.sideModel.getValue() : null,
                                limitPrice: this.limitPriceModel ? this.limitPriceModel.$value.getValue() : null,
                                stopPrice: this.stopPriceModel ? this.stopPriceModel.$value.getValue() : null,
                                quantity: this.quantityModel ? this.quantityModel.$value.getValue() : null,
                                isTakeProfitIncorrect: !!this.takeProfitModel && this.takeProfitModel.isValueIncorrect(),
                                isStopLossIncorrect: !!this.stopLossModel && this.stopLossModel.isValueIncorrect(),
                                customFields: this._getCustomFields(this.customFieldModels.value())
                            }), this._onInputStateChanged.fire({
                                customFields: this._getCustomFields(this._getSavableCustomFieldsModels())
                            }), this._checkIsCustomFieldNotSelected()
                        })
                    }
                    if (this._subscriptions = [...this.sideModel.subscribe(), this.limitPriceModel.subscribe(), this.stopPriceModel.subscribe(), this._price$.subscribe(), this._qtySuggester.suggestedQtyChanged(this.symbol).subscribe(this._onSuggestedQtyChange)], this.buttonModel && this.buttonModel.subscribe(), void 0 !== this.takeProfitModel && this._subscriptions.push(...this.takeProfitModel.subscribe()), void 0 !== this.stopLossModel) {
                        const e = (0, S.combineLatest)([this.stopLossModel.value$, this.stopLossModel.enabled$]).subscribe(([e, t]) => {
                            this._stopLossAvailable.next(t), t && this._stopLossPips.next(e)
                        });
                        this._subscriptions.push(e, ...this.stopLossModel.subscribe())
                    }
                    if (void 0 !== this.takeProfitModel && void 0 !== this.stopLossModel) {
                        const e = (0, S.combineLatest)([this.takeProfitModel.value$, this.stopLossModel.value$]).subscribe(([e, t]) => {
                            this.rewardRisk.setValue((0, L.formatRiskReward)(e, t))
                        });
                        this._subscriptions.push(e)
                    }
                    null !== this.orderInfoModel && this._subscriptions.push(...this.orderInfoModel.subscribe()), this._subscriptions.push(this._buttonDataSubscription, this._noQuotesSubscription, this._pipValues$.connect()), null !== this._marginAvailable$ && this._subscriptions.push(this._marginAvailable$.connect()), null !== this._baseCurrencyCryptoBalance$ && this._subscriptions.push(this._baseCurrencyCryptoBalance$.connect()), null !== this._quoteCurrencyCryptoBalance$ && this._subscriptions.push(this._quoteCurrencyCryptoBalance$.connect()), this.orderType.subscribe(this._syncOrderPricesAndFocuses), this._adapter.orderUpdate.subscribe(this, this._orderUpdate), this.stopPriceModel.price.subscribe(this._syncStopLimitPrices)
                }
                _backToDefaultOrderPanel() {
                    this.mode.value() === T.OrderEditorDisplayMode.Panel && this._cancel()
                }
                _orderUpdate(e) {
                    (this._isTradingPanelOpened.value() || this.mode.value() === T.OrderEditorDisplayMode.Popup) && this.existingOrder && e.id === this._orderTemplate.id && 6 !== e.status && this._back()
                }
                async _doneHandler(e, t) {
                    await this._getAndSendStatistics(e), null !== this._orderWidgetStat && this._orderWidgetStat.clear();
                    const i = this._handler;
                    return this._isHandlerPlacedOrder(i) ? i(Object.assign({}, this._existingPlacedOrder, e), t) : i(e, t)
                }
                _isHandlerPlacedOrder(e) {
                    return this.existingOrder
                }
                async _getAndSendStatistics(e) {
                    var t;
                    const i = this.stopLossModel && this.stopLossModel.getEnabled(),
                        s = this.takeProfitModel && this.takeProfitModel.getEnabled(),
                        r = i && this.supportTrailingStop,
                        n = 1 === e.side ? "Buy" : "Sell",
                        a = ["Price", "Pips"],
                        l = ["Units", "RiskInCurrency", "RiskInPercent", "BaseCurrencyQuantity", "QuoteCurrencyQuantity"],
                        u = this.quantityModel.focusedControl.value(),
                        h = ["Pips", "Price", "RiskInCurrency", "RiskInPercent"],
                        c = ["Limit", "Market", "Stop", "StopLimit"][e.type - 1],
                        d = this.durationModel.getValue(),
                        p = this.leverageModel ? this.leverageModel.leverageInfo() : null,
                        _ = 4 === e.type,
                        b = 3 === e.type || _,
                        y = 1 === e.type || _,
                        g = Object.assign({}, this._settings.value()),
                        P = this.limitPriceModel && !this.limitPriceModel.isRelativePriceControlHidden || this.stopPriceModel && !this.stopPriceModel.isRelativePriceControlHidden,
                        m = Boolean(this.supportBrackets);

                    function v(e, t) {
                        return t[null !== e ? e : 0]
                    }
                    g.showRelativePriceControl = g.showRelativePriceControl && P,
                        g.showCurrencyRiskInQty = g.showCurrencyRiskInQty && m, g.showPercentRiskInQty = g.showPercentRiskInQty && m, g.showBracketsInCurrency = g.showBracketsInCurrency && m, g.showBracketsInPercent = g.showBracketsInPercent && m, g.showOrderPreview = g.showOrderPreview && Boolean(this.supportPlaceOrderPreview || this.supportModifyOrderPreview), null !== this._orderWidgetStat && (this._orderWidgetStat.setStaticSnowplowEventDataProperty({
                            accountType: this._adapter.currentAccountType(),
                            brokerId: this._adapter.metainfo().id,
                            orderTicketMode: this.mode.value(),
                            side: n,
                            orderType: c,
                            leverageInfo: p,
                            symbolType: void 0 !== this._symbolInfo.type ? this._symbolInfo.type : null,
                            operation: this.existingOrder ? "Modify" : "Place",
                            stopLoss: i ? (0, o.ensureDefined)(this.stopLossModel).getValue() : null,
                            takeProfit: s ? (0, o.ensureDefined)(this.takeProfitModel).getValue() : null,
                            trailingStop: r ? (0, o.ensureDefined)(this.stopLossModel).getValue() : null,
                            guaranteedStop: null,
                            focusedTPField: s ? v((0, o.ensureDefined)(this.takeProfitModel).getFocusedControl(), h) : null,
                            focusedSLField: i ? v((0, o.ensureDefined)(this.stopLossModel).getFocusedControl(), h) : null,
                            focusedQtyField: null !== (t = l[null !== u ? u : 0]) && void 0 !== t ? t : null,
                            focusedLimitPriceField: y || _ && this.limitPriceModel ? v(this.limitPriceModel.focusedControl.value(), a) : null,
                            focusedStopPriceField: b && this.stopPriceModel ? a[this.stopPriceModel.focusedControl.value()] : null,
                            duration: null !== d ? d.type : null,
                            isDefaultDuration: null !== d ? d.type === this._getDefaultDuration().value : null,
                            showBracketsInCurrency: g.showBracketsInCurrency,
                            showBracketsInPercent: g.showBracketsInPercent,
                            showCurrencyRiskInQty: g.showCurrencyRiskInQty,
                            showOrderPreview: g.showOrderPreview,
                            showPercentRiskInQty: g.showPercentRiskInQty,
                            showRelativePriceControl: g.showRelativePriceControl
                        }), await this._orderWidgetStat.trackStat())
                }
                _getDurationMetaInfoList() {
                    var e;
                    const t = this._symbolInfo.allowedDurations,
                        i = null !== (e = this._adapter.metainfo().durations) && void 0 !== e ? e : [];
                    return 0 === i.length || void 0 === t ? i : i.filter(({
                        value: e
                    }) => t.includes(e))
                }
                _getDurationInitialState(e, t) {
                    return void 0 !== e.duration ? { ...e.duration
                    } : void 0 !== t && null !== t.duration ? { ...t.duration
                    } : (0, B.makeInitialOrderDuration)(this.orderType.value(), this._getDurationMetaInfoList())
                }
                _getInitialInputState(e, t, i) {
                    var s, r, o, n, a, l;
                    return {
                        symbol: this.symbol,
                        side: null !== (r = null !== (s = e.side) && void 0 !== s ? s : null == i ? void 0 : i.side) && void 0 !== r ? r : 1,
                        limitPrice: e.limitPrice || e.price || e.stopPrice || 0,
                        stopPrice: e.stopPrice || e.price || e.limitPrice || 0,
                        quantity: e.qty || (null == i ? void 0 : i.quantity) || this._suggestedQty || t.qty.min,
                        takeProfitPips: null !== (o = null == i ? void 0 : i.takeProfitPips) && void 0 !== o ? o : T.BracketDefaultPips.TakeProfit,
                        stopLossPips: null !== (n = null == i ? void 0 : i.stopLossPips) && void 0 !== n ? n : T.BracketDefaultPips.StopLoss,
                        customFields: null !== (l = null !== (a = e.customFields) && void 0 !== a ? a : null == i ? void 0 : i.customFields) && void 0 !== l ? l : {},
                        duration: this._getDurationInitialState(e, i)
                    }
                }
                _compareInputStates({
                    side: e,
                    limitPrice: t,
                    stopPrice: i,
                    quantity: s,
                    takeProfitPips: r,
                    stopLossPips: o,
                    duration: n
                }) {
                    0 === this._initialInputState.limitPrice && null !== t && (this._initialInputState.limitPrice = t),
                        0 === this._initialInputState.stopPrice && null !== i && (this._initialInputState.stopPrice = i);
                    const a = this.orderType.value(),
                        l = {};
                    let u = null === t;
                    if (null !== t) {
                        const e = this.formatter.format(t),
                            i = null !== this._currentInputState.limitPrice ? this.formatter.format(this._currentInputState.limitPrice) : null;
                        u = 3 !== a && e !== i
                    }
                    u && (l.limitPrice = t);
                    let h = null !== i;
                    if (null !== i) {
                        const e = this.formatter.format(i),
                            t = null !== this._currentInputState.stopPrice ? this.formatter.format(this._currentInputState.stopPrice) : null;
                        h = (3 === a || 4 === a) && e !== t
                    }
                    h && (l.stopPrice = i), null !== s && this._currentInputState.quantity !== s && (l.quantity = s), null !== r && this._currentInputState.takeProfitPips !== r && (l.takeProfitPips = r), null !== o && this._currentInputState.stopLossPips !== o && (l.stopLossPips = o), null === n || null === this._currentInputState.duration || this._currentInputState.duration.type === n.type && this._currentInputState.duration.datetime === n.datetime || (l.duration = n), null !== e && this._currentInputState.side !== e && (l.side = e), this._currentInputState.symbol !== this.symbol && (l.symbol = this.symbol), 0 !== Object.keys(l).length && this._onInputStateChanged.fire(l)
                }
                _getSavableComboBoxModels() {
                    return this.customFieldModels.value().filter(e => e.saveToSettings && "ComboBox" === e.type)
                }
                _getSavableCheckboxModels() {
                    return this.customFieldModels.value().filter(e => e.saveToSettings && "Checkbox" === e.type)
                }
                _getSavableCustomFieldsModels() {
                    return [...this._getSavableComboBoxModels(), ...this._getSavableCheckboxModels()]
                }
                _getCustomFields(e) {
                    e || (e = this.customFieldModels.value());
                    const t = {};
                    return e.forEach(e => {
                        "TextWithCheckBox" === e.type && (t[e.id] = {
                            text: e.text.value().replace(/&quote;/g, '"'),
                            checked: e.checked.value()
                        }), "Checkbox" === e.type && (t[e.id] = e.checked.value()), "ComboBox" === e.type && (t[e.id] = e.selectedItem.value())
                    }), t
                }
                _getCurrentInputState() {
                    return {
                        symbol: this.symbol,
                        side: this.sideModel.getValue(),
                        limitPrice: this.limitPriceModel.$value.getValue(),
                        stopPrice: this.stopPriceModel.$value.getValue(),
                        quantity: this.quantityModel.$value.getValue(),
                        takeProfitPips: this.takeProfitModel ? this.takeProfitModel.pips.getValue() : null,
                        stopLossPips: this.stopLossModel ? this.stopLossModel.pips.getValue() : null,
                        duration: this.durationModel.getValue(),
                        customFields: this._getCustomFields(this._getSavableCustomFieldsModels())
                    }
                }
                _setDisabledIfNeeded({
                    status: e,
                    loading: t,
                    quotes: i,
                    side: s,
                    limitPrice: r,
                    stopPrice: o,
                    quantity: n,
                    isTakeProfitIncorrect: a,
                    isStopLossIncorrect: l,
                    customFields: u
                }) {
                    this.disabled.setValue(this.mode.value() === T.OrderEditorDisplayMode.Panel && e === T.OrderPanelStatus.Wait || t || (0, L.isNoQuotes)(i) || null === s || (0, L.checkPriceByOrderType)(this.orderType.value(), r, o) || null === n || a || l || Object.values(u).some(e => void 0 === e))
                }
                _toggleMode() {
                    this.mode.setValue(this.mode.value() === T.OrderEditorDisplayMode.Panel ? T.OrderEditorDisplayMode.Popup : T.OrderEditorDisplayMode.Panel), this._updateMode(), this._onModeChanged.fire(this.mode.value())
                }
                _closeWidget() {
                    this._cleanUp(), this._onCloseButtonClicked.fire()
                }
                _cancel() {
                    this._cleanUp(), this.deactivateOrderPanel(), this._currentInputState = Object.assign({}, this._initialInputState),
                        this.limitPriceModel && this.limitPriceModel.forcePricesUpdate(this._initialInputState.limitPrice), this.stopPriceModel && this.stopPriceModel.forcePricesUpdate(this._initialInputState.stopPrice), this.takeProfitModel && this.takeProfitModel.setEnabled(!1), this.stopLossModel && this.stopLossModel.setEnabled(!1), this._orderPlacingStatus.next(T.OrderPlacingStatus.Creating), this.existingOrder && this._back()
                }
                _cleanUp() {
                    this.orderPreviewModel = null, this.onDoneButtonClicked.resolve(!1), this.quantityModel && void 0 !== this._suggestedQty && this.quantityModel.quantity.value.setValue(this._suggestedQty)
                }
                _getDefaultDuration() {
                    const e = (0, o.ensureDefined)(this._adapter.metainfo().durations);
                    return e.find(e => Boolean(e.default)) || e[0]
                }
                async _prepareTradableSolution(e) {
                    this.tradableSolution = await (0, L.prepareTradableSolution)(e, this._adapter), this._createSimpleDialog(this._adapter), this.notTradableText = e.reason
                }
            }
            var xe = i(52260);
            const je = {
                title: (0, d.t)("Position info"),
                pipValue: (0, d.t)("Pip value"),
                tradeValue: (0, d.t)("Trade value"),
                total: (0, d.t)("Total"),
                leverage: (0, d.t)("Leverage"),
                lotSize: (0, d.t)("Lot size")
            };
            class Qe {
                constructor({
                    qty: e,
                    currency: t,
                    positionPrice: i,
                    showTotalInsteadOfTradeValue: s,
                    info: r,
                    pipValueType: o,
                    tpInfo: n,
                    slInfo: a,
                    showRiskControls: l
                }) {
                    this._infoTableData = new Y.WatchedObject({
                        rows: []
                    }, L.comparator), this._riskFormatter = new $.PriceFormatter(100), this._tpEnabled$ = null, this._tpRiskInCurrency$ = null, this._tpRiskInPercent$ = null, this._slEnabled$ = null, this._slRiskInCurrency$ = null, this._slRiskInPercent$ = null, this._currency = t, this._showTotalInsteadOfTradeValue = s, this._showRiskControls = l, this._type = r.type, this._leverage = r.leverage, this._marginRate = r.marginRate, this._lotSize = r.lotSize, this._pipValue = (0, L.calculatePipValue)(e, r.pipValue, this._lotSize), this._pipValueType = o, null === e ? this._tradeValue = 0 : "crypto" === this._type ? this._tradeValue = e * i : this._tradeValue = (0, L.calculateTradeValue)(e, i, r.pipValue, r.pipSize, this._lotSize), n && a && (this._tpEnabled$ = n.enabled, this._tpRiskInCurrency$ = n.riskInCurrency, this._tpRiskInPercent$ = n.riskInPercent, this._slEnabled$ = a.enabled, this._slRiskInCurrency$ = a.riskInCurrency, this._slRiskInPercent$ = a.riskInPercent)
                }
                subscribe() {
                    return this._subscription = (0, S.combineLatest)({
                        tpEnabled: null !== this._tpEnabled$ ? this._tpEnabled$ : (0, C.of)(null),
                        tpRiskInCurrency: null !== this._tpRiskInCurrency$ ? this._tpRiskInCurrency$ : (0, C.of)(null),
                        tpRiskInPercent: null !== this._tpRiskInPercent$ ? this._tpRiskInPercent$ : (0, C.of)(null),
                        slEnabled: null !== this._slEnabled$ ? this._slEnabled$ : (0, C.of)(null),
                        slRiskInCurrency: null !== this._slRiskInCurrency$ ? this._slRiskInCurrency$ : (0, C.of)(null),
                        slRiskInPercent: null !== this._slRiskInPercent$ ? this._slRiskInPercent$ : (0, C.of)(null)
                    }).subscribe(e => {
                        const {
                            tpEnabled: t,
                            tpRiskInCurrency: i,
                            tpRiskInPercent: s,
                            slEnabled: r,
                            slRiskInCurrency: o,
                            slRiskInPercent: n
                        } = e, a = [];
                        a.push(...this._makeLeverageInfo(), ...this._makeLotSizeInfo(), ...this._makePipValueInfo(), ...this._makeTradeValueInfo(), ...this._makeRewardInfo(t, i, s), ...this._makeRiskInfo(r, o, n)), this._infoTableData.setValue({
                            rows: a
                        })
                    }), this._subscription
                }
                unsubscribe() {
                    var e;
                    null === (e = this._subscription) || void 0 === e || e.unsubscribe()
                }
                title() {
                    return je.title
                }
                infoTableData() {
                    return this._infoTableData
                }
                pipValue() {
                    throw new Error("not supported")
                }
                tradeValue() {
                    throw new Error("not supported")
                }
                _makeLeverageInfo() {
                    const e = (0, L.displayedLeverage)(this._leverage, this._marginRate);
                    return null === e ? [] : [{
                        title: (0, d.t)("Leverage"),
                        value: e
                    }]
                }
                _makeLotSizeInfo() {
                    return "number" == typeof this._lotSize && Number.isFinite(this._lotSize) ? [{
                        title: (0, d.t)("Lot size"),
                        value: String(this._lotSize)
                    }] : []
                }
                _makePipValueInfo() {
                    return this._showRiskControls && this._pipValueType.value() !== M.PipValueType.None && Number.isFinite(this._pipValue) ? [{
                        title: this._pipValueType.value() === M.PipValueType.Pips ? (0, d.t)("Pip value") : (0, d.t)("Tick value"),
                        value: `${this._currency} ${(0,L.formatInfoValue)(this._pipValue)}`
                    }] : []
                }
                _makeTradeValueInfo() {
                    const e = this._getTradeValue();
                    if (void 0 === e) return [];
                    return [{
                        title: this._showTotalInsteadOfTradeValue ? (0, d.t)("Total") : (0, d.t)("Trade value"),
                        value: `${this._currency} ${e}`
                    }]
                }
                _getTradeValue() {
                    const e = this._getMarginRate();
                    if (this._showRiskControls && Number.isFinite(this._tradeValue) && (this._isSymbolTypeSupportTradeValue() || void 0 !== e)) return (0, L.formatInfoValue)(this._tradeValue * (null != e ? e : 1))
                }
                _getMarginRate() {
                    return void 0 !== this._marginRate && this._marginRate > 0 ? this._marginRate : void 0
                }
                _isSymbolTypeSupportTradeValue() {
                    return void 0 !== this._type && ["stock", "dr", "right", "bond", "warrant", "structured"].includes(this._type)
                }
                _makeRewardInfo(e, t, i) {
                    return this._showRiskControls && e && null !== t && null !== i ? [{
                        title: (0, d.t)("Reward"),
                        value: this._riskFormatter.format(i) + "% (" + this._currency + " " + this._riskFormatter.format(t) + ")"
                    }] : []
                }
                _makeRiskInfo(e, t, i) {
                    return this._showRiskControls && e && null !== t && null !== i ? [{
                        title: (0, d.t)("Risk"),
                        value: this._riskFormatter.format(i) + "% (" + this._currency + " " + this._riskFormatter.format(t) + ")"
                    }] : []
                }
            }
            var We;
            ! function(e) {
                e[e.Position = 0] = "Position", e[e.Trade = 1] = "Trade"
            }(We || (We = {}));
            class Ae {
                constructor({
                    adapter: e,
                    position: t,
                    brackets: i,
                    mode: s,
                    settings: r,
                    realtimeProvider: o,
                    isTradingPanelVisible: n,
                    isTradingPanelOpened: a,
                    viewType: l,
                    pipValueType: u,
                    handler: c,
                    trackEvent: d
                }) {
                    this.positionInfoModel = null, this.customFieldModels = new(h())([]), this.onDoneButtonClicked = (0, p.createDeferredPromise)(), this.rewardRisk = new(h())(""), this.disabled = new(h())(!1), this.loading = new(h())(!1), this.status = new(h())(T.OrderPanelStatus.Active), this.id = (0, w.randomHashN)(6), this.warning = new(h())(void 0), this.isEmptyRequiredCustomFieldsHighlighted = new(h())(!1), this._onModeChanged = new(I()), this._onBackButtonClicked = new(I()), this._onCloseButtonClicked = new(I()), this._loadingSubscription = (0, L.makeSubjectFromWatchedValue)(this.loading), this._loading = this._loadingSubscription.subject, this.mode = s, this._position = t, this._settings = r, this._adapter = e, this._pipValueType = u, this.position = t, this.symbol = t.symbol, this.brackets = i, this._handler = c, this._isTradingPanelVisible = n, this._isTradingPanelOpened = a;
                    const _ = this._adapter.metainfo().configFlags;
                    this.supportBrackets = l === We.Trade ? _.supportTradeBrackets : _.supportPositionBrackets,
                        this.supportTrailingStop = this.supportBrackets && _.supportTrailingStop, this.supportModifyTrailingStop = this.supportTrailingStop && _.supportModifyTrailingStop, this.supportPositions = l === We.Position && _.supportPositions, this.supportTrades = l === We.Trade && _.supportTrades, this.supportOnlyPairPositionBrackets = _.supportOnlyPairPositionBrackets, this.supportCryptoExchangeOrderTicket = _.supportCryptoExchangeOrderTicket, this._adapter.orders().then(e => {
                            const i = e.filter(e => 2 === e.parentType && e.parentId === t.id),
                                s = i.length ? i[0].customFields : void 0,
                                r = this._adapter.getPositionDialogOptions();
                            this.customFieldModels.setValue((0, L.createCustomFieldModels)(Boolean(i.length), this.status, new(h())(!1), r, s)), this.supportOnlyPairPositionBrackets && this._updateWarning()
                        }), this._trackEvent = d, this.onReady = Promise.all([e.symbolInfo(t.symbol), e.getOrderDialogOptions(t.symbol), qe(e.accountMetainfo(), {
                            id: e.metainfo().id,
                            name: e.metainfo().title
                        }), qe(e.formatter(t.symbol, !1), new $.PriceFormatter)]).then(([s, r, n, a]) => {
                            this.showRiskControls = _.supportRiskControls && 0 !== s.pipValue, this.currency = (0, O.getCurrency)(n), this.symbolType = s.type, this.brokerSymbol = s.brokerSymbol || t.brokerSymbol || this.symbol, this._quotes$ = (0, f.connectable)((0, v.fromEventPattern)(e => o.subscribeRealtime(t.symbol, e), e => o.unsubscribeRealtime(t.symbol, e), (e, t) => t)), this._equity$ = (0, f.connectable)((0, v.fromEventPattern)(t => e.subscribeEquity(t), t => e.unsubscribeEquity(t), (e, t) => t)), this._pipValues$ = (0, f.connectable)((0, v.fromEventPattern)(i => e.subscribePipValue(t.symbol, i), i => e.unsubscribePipValue(t.symbol, i), (e, t) => t).pipe((0, y.startWith)({
                                buyPipValue: s.pipValue,
                                sellPipValue: s.pipValue
                            }))), this._pipValue$ = this._pipValues$.pipe((0, g.map)(e => 1 === t.side ? e.buyPipValue : e.sellPipValue)), this._createModels(i, s, n, this.mode, a, r), this._subscribe()
                        })
                }
                destroy() {
                    this._subscriptions && this._subscriptions.forEach(e => e.unsubscribe()), this.headerModel && (this.headerModel.unsubscribe(), this.headerModel.pinButtonClicked().unsubscribe(this, this._toggleMode), this.headerModel.backButtonClicked().unsubscribe(this, this._back), this.headerModel.closeButtonClicked().unsubscribe(this, this._closeWidget)), null !== this.positionInfoModel && this.positionInfoModel.unsubscribe(), this.supportPositions && this._adapter.positionUpdate.unsubscribe(this, this._positionOrTradeUpdate), this.supportTrades && this._adapter.tradeUpdate.unsubscribe(this, this._positionOrTradeUpdate), this.supportOnlyPairPositionBrackets && this._adapter.orderUpdate.unsubscribe(this, this._updateWarning)
                }
                side() {
                    return this._position.side
                }
                doneButtonClick() {
                    this.loading.setValue(!0), this._doneHandler().then(e => {
                        e && (this.onDoneButtonClicked.resolve(!0), this.mode.value() === T.OrderEditorDisplayMode.Popup ? this.headerModel.close() : this._back(), this._trackEvent("Position Ticket", "Modify Position", this.mode.value() === T.OrderEditorDisplayMode.Panel ? "Panel" : "Popup")), this.loading.setValue(!1)
                    })
                }
                onModeChanged() {
                    return this._onModeChanged
                }
                onBackButtonClicked() {
                    return this._onBackButtonClicked
                }
                onCloseButtonClicked() {
                    return this._onCloseButtonClicked
                }
                _createModels(e, t, i, s, r, o) {
                    const n = Q(this._adapter, this.symbol),
                        a = W(this._adapter, this.symbol),
                        l = (0, O.getCurrency)(i) || "$",
                        u = new m.BehaviorSubject(this._position.side || -1);
                    this.headerModel = new U(this.brokerSymbol, this.symbol, " ", s, this.status, 2, !0, !0, this._quotes$, this._isTradingPanelVisible, this._position, this._position.priceFormatter ? this._position.priceFormatter : r), this.takeProfitModel = new Se({
                        initialPrice: e.takeProfit || this._position.takeProfit || null,
                        initialEnabled: Boolean(e.takeProfit || this._position.takeProfit),
                        initialBracketType: M.BracketType.TakeProfit,
                        formatter: r,
                        equity$: this._equity$,
                        quotes$: this._quotes$,
                        info: t,
                        pipValue$: this._pipValue$,
                        side$: u,
                        amount$: new m.BehaviorSubject(this._position.qty),
                        parentPrice$: new m.BehaviorSubject(this._position.avgPrice),
                        orderType$: new m.BehaviorSubject(null),
                        currency: l,
                        parentType: 2,
                        savedPips: null,
                        settings: this._settings,
                        orderWidgetStat: null,
                        showRiskControls: this.showRiskControls,
                        status: this.status.value(),
                        validationRules: n,
                        supportModifyBrackets: this.supportBrackets,
                        supportModifyTrailingStop: this.supportModifyTrailingStop
                    });
                    const h = null !== this._position.trailingStopPips,
                        c = e.trailingStopPips || this._position.trailingStopPips,
                        d = e.stopLoss || this._position.stopLoss,
                        p = Boolean(c);
                    this.stopLossModel = new Se({
                        initialPrice: p ? null : d || null,
                        initialEnabled: Boolean(p ? c : d),
                        initialBracketType: p ? M.BracketType.TrailingStop : M.BracketType.StopLoss,
                        formatter: r,
                        equity$: this._equity$,
                        quotes$: this._quotes$,
                        info: t,
                        pipValue$: this._pipValue$,
                        side$: u,
                        amount$: new m.BehaviorSubject(this._position.qty),
                        parentPrice$: new m.BehaviorSubject(this._position.avgPrice),
                        orderType$: new m.BehaviorSubject(null),
                        currency: l,
                        parentType: 2,
                        savedPips: c || null,
                        settings: this._settings,
                        orderWidgetStat: null,
                        showRiskControls: this.showRiskControls,
                        status: this.status.value(),
                        validationRules: a,
                        supportModifyBrackets: this.supportBrackets,
                        supportModifyTrailingStop: this.supportModifyTrailingStop,
                        hasTrailingStopBracket: h
                    });
                    const _ = (0, L.shouldShowTotal)(o);
                    this.supportCryptoExchangeOrderTicket || (this.positionInfoModel = new Qe({
                        qty: this._position.qty,
                        currency: (0, O.getCurrency)(i),
                        positionPrice: this._position.avgPrice,
                        showTotalInsteadOfTradeValue: _,
                        info: t,
                        pipValueType: this._pipValueType,
                        tpInfo: this.supportBrackets && this.takeProfitModel ? {
                            enabled: this.takeProfitModel.enabled$,
                            riskInCurrency: this.takeProfitModel.riskInCurrency.value$,
                            riskInPercent: this.takeProfitModel.riskInPercent.value$
                        } : null,
                        slInfo: this.supportBrackets && this.stopLossModel ? {
                            enabled: this.stopLossModel.enabled$,
                            riskInCurrency: this.stopLossModel.riskInCurrency.value$,
                            riskInPercent: this.stopLossModel.riskInPercent.value$
                        } : null,
                        showRiskControls: this.showRiskControls
                    })), this.buttonModel = new Oe(M.TradingEntityType.Position)
                }
                _updateWarning() {
                    this._adapter.orders().then(e => {
                        const t = e.find(e => e.symbol === this._position.symbol && e.side !== this._position.side && (6 === e.status && void 0 === e.parentId || 3 === e.status));
                        this.warning.setValue(t ? (0, d.t)("You already have at least one working order that can affect this position") : void 0)
                    })
                }
                _subscribe() {
                    if (this.headerModel.pinButtonClicked().subscribe(this, this._toggleMode),
                        this.headerModel.backButtonClicked().subscribe(this, this._back), this.headerModel.closeButtonClicked().subscribe(this, this._closeWidget), this._buttonDataSubscription = (0, S.combineLatest)({
                            loading: this._loading,
                            quotes: this._quotes$,
                            takeProfit: this.takeProfitModel.value$,
                            stopLoss: this.stopLossModel.value$,
                            takeProfitEnabled: this.takeProfitModel.enabled$,
                            stopLossEnabled: this.stopLossModel.enabled$
                        }).subscribe(e => {
                            const {
                                loading: t,
                                quotes: i,
                                takeProfit: s,
                                stopLoss: r,
                                takeProfitEnabled: o,
                                stopLossEnabled: n
                            } = e;
                            this.disabled.setValue(t || (0, L.isNoQuotes)(i) || o && null === s || n && null === r)
                        }), this._rewardRiskSubscription = (0, S.combineLatest)([this.takeProfitModel.value$, this.stopLossModel.value$]).subscribe(([e, t]) => {
                            this.rewardRisk.setValue((0, L.formatRiskReward)(e, t))
                        }), this._subscriptions = [...this.takeProfitModel.subscribe(), ...this.stopLossModel.subscribe(), this._rewardRiskSubscription, this._buttonDataSubscription, this._equity$.connect(), this._quotes$.connect(), this._pipValues$.connect()], null !== this.positionInfoModel && this._subscriptions.push(this.positionInfoModel.subscribe()), this.supportPositions && this._adapter.positionUpdate.subscribe(this, this._positionOrTradeUpdate), this.supportTrades && this._adapter.tradeUpdate.subscribe(this, this._positionOrTradeUpdate), this.supportOnlyPairPositionBrackets) {
                        this._adapter.orderUpdate.subscribe(this, this._updateWarning);
                        const e = this.stopLossModel.enabled$.pipe((0, xe.withLatestFrom)(this.takeProfitModel.enabled$)).subscribe(e => {
                                const [t, i] = e;
                                i !== t && this.takeProfitModel.setEnabled(t)
                            }),
                            t = this.takeProfitModel.enabled$.pipe((0, xe.withLatestFrom)(this.stopLossModel.enabled$)).subscribe(e => {
                                const [t, i] = e;
                                i !== t && this.stopLossModel.setEnabled(t)
                            });
                        this._subscriptions.push(t, e)
                    }
                }
                _doneHandler() {
                    const e = null !== this.stopLossModel.getValue() ? this.stopLossModel.price.getValue() : null,
                        t = this.stopLossModel.getValue(),
                        i = null !== this.takeProfitModel.getValue() ? this.takeProfitModel.price.getValue() : null,
                        s = {};
                    if (null !== t && null !== e && (this.stopLossModel.getBracketType() === M.BracketType.StopLoss && (s.stopLoss = e), this.stopLossModel.getBracketType() === M.BracketType.TrailingStop && (s.trailingStopPips = t)), null !== i && (s.takeProfit = i), Array.isArray(this.customFieldModels.value())) {
                        const e = {};
                        return this.customFieldModels.value().forEach(t => {
                            "TextWithCheckBox" === t.type && (e[t.id] = {
                                text: t.text.value().replace(/&quote;/g, '"'),
                                checked: t.checked.value()
                            }), "Checkbox" === t.type && (e[t.id] = {
                                checked: t.checked.value()
                            }), "ComboBox" === t.type && (e[t.id] = t.selectedItem.value())
                        }), this._getAndSendStatistics(), this._handler(this.position.id, s, e)
                    }
                    return this._getAndSendStatistics(), this._handler(this.position.id, s)
                }
                _getAndSendStatistics() {
                    const e = this.stopLossModel.getEnabled(),
                        t = this.stopLossModel.getFocusedControl(),
                        i = this.takeProfitModel.getEnabled(),
                        s = this.takeProfitModel.getFocusedControl(),
                        r = this.stopLossModel && this.stopLossModel.getBracketType(),
                        o = ["Pips", "Price", "RiskInCurrency", "RiskInPercent"],
                        n = [" Disabled", " Active"],
                        a = ["StopLoss", "TakeProfit", "TrailingStop"],
                        l = {
                            SL: {
                                active: n[+e],
                                mode: o[t]
                            },
                            TP: {
                                active: n[+i],
                                mode: o[s]
                            }
                        };
                    this.supportTrailingStop && (l.SLType = {
                        active: n[+e],
                        mode: a[r]
                    });
                    const u = this._settings.value();
                    Object.keys(u).filter(e => ["showBracketsInCurrency", "showBracketsInPercent"].includes(e)).forEach(e => {
                        this._trackEvent("Order Ticket", e, u[e] ? "on" : "off")
                    }), Object.keys(l).forEach(e => {
                        l[e].active && this._trackEvent("Position Ticket", e, l[e].mode)
                    })
                }
                _positionOrTradeUpdate(e) {
                    !this._isTradingPanelOpened.value() && this.mode.value() !== T.OrderEditorDisplayMode.Popup || e.id !== this.position.id || 0 !== e.qty && this.position.side === e.side || this._back()
                }
                _toggleMode() {
                    this.mode.setValue(this.mode.value() === T.OrderEditorDisplayMode.Panel ? T.OrderEditorDisplayMode.Popup : T.OrderEditorDisplayMode.Panel), this._onModeChanged.fire(this.mode.value())
                }
                _closeWidget() {
                    this.onDoneButtonClicked.resolve(!1), this._onCloseButtonClicked.fire()
                }
                _back() {
                    this.onDoneButtonClicked.resolve(!1), this._onBackButtonClicked.fire()
                }
            }
            var ze = i(74617);
            class Ue {
                constructor(e) {
                    this._brokerId = "", this._settingsAdapter = e
                }
                setBrokerId(e) {
                    this._brokerId = e
                }
                saveSettings(e) {
                    this._settingsAdapter.setValue(this._makeKey(ze.settingsKeys.ORDER_PANEL_SETTINGS, this._brokerId), JSON.stringify(e))
                }
                getSettings() {
                    const e = this._settingsAdapter.getValue(this._makeKey(ze.settingsKeys.ORDER_PANEL_SETTINGS, this._brokerId));
                    try {
                        return JSON.parse(e)
                    } catch (e) {
                        return null
                    }
                }
                setWidgetMode(e) {
                    this._settingsAdapter.setValue(ze.settingsKeys.ORDER_WIDGET_MODE, e)
                }
                widgetMode() {
                    const e = this._settingsAdapter.getValue(ze.settingsKeys.ORDER_WIDGET_MODE);
                    return e || null
                }
                _makeKey(e, t, i) {
                    return e + t + ("string" == typeof i ? "." + i : "")
                }
            }
            var He, Ge = i(37076),
                Ke = i(95318),
                Je = i(12334),
                Ye = i(15180);
            ! function(e) {
                let t = 0;
                const i = new(h())(!1);
                e.value = i.readonly(), e.wrap = function(e) {
                    return async () => {
                        i.setValue(!0), t++;
                        try {
                            const s = await e();
                            return t--, i.setValue(0 !== t), s
                        } catch (e) {
                            throw t--, i.setValue(0 !== t), e
                        }
                    }
                }
            }(He || (He = {}));
            const Xe = (0, n.getLogger)("Trading.OrderViewController");

            function Ze() {
                return Promise.all([i.e(5514), i.e(2e3), i.e(6363), i.e(9289), i.e(3466), i.e(7836), i.e(3921), i.e(7427), i.e(8463), i.e(7552), i.e(7419), i.e(5998), i.e(3713), i.e(4763), i.e(2096), i.e(2385), i.e(9042), i.e(1333), i.e(6058), i.e(9055), i.e(3727), i.e(8068), i.e(9044), i.e(5399), i.e(4719), i.e(9283), i.e(7544), i.e(1902), i.e(9079), i.e(7125), i.e(9260), i.e(2100), i.e(8242), i.e(7502)]).then(i.bind(i, 56267))
            }

            function et() {
                return Promise.all([i.e(5514), i.e(2e3), i.e(6363), i.e(9289), i.e(3466), i.e(7836), i.e(3921), i.e(7427), i.e(7552), i.e(7419), i.e(5998), i.e(3713), i.e(4763), i.e(2096), i.e(2385), i.e(9042), i.e(3727), i.e(9044), i.e(5399), i.e(8844), i.e(4719), i.e(6767), i.e(4441), i.e(9079), i.e(7125), i.e(2100), i.e(8242), i.e(8751)]).then(i.bind(i, 10548))
            }
            class tt {
                constructor(e, t, i) {
                    if (this._orderViewModel = null, this._positionViewModel = null, this._visibility = new Ye.DialogVisibility, this._orderWidgetStat = null, this._settings = new(h())(Ke.defaultSettings), this._mode = new(h())(T.OrderEditorDisplayMode.Panel), this.openPanel = async () => {
                            try {
                                this._closeOrderDialog(), this._closePositionDialog(), this._setDisplayMode(T.OrderEditorDisplayMode.Panel), this._openTradingPanelPage(Ge.TradingPage.OrderPanel),
                                    await this._recreateOrderViewModel(), this._resetOrderPanel(), await this._openOrderPanel()
                            } catch (e) {
                                Xe.logError("Failed to open panel: " + (0, c.getLoggerMessage)(e))
                            }
                        }, this._onActiveTradingPanelChanged = e => {
                            e !== Ge.TradingPage.OrderPanel && (null !== this._positionViewModel && (this._unmountPositionPanel(), this._unsubscribePositionViewModel()), null !== this._orderViewModel && this._mode.value() === T.OrderEditorDisplayMode.Panel && (this._orderViewModel.existingOrder && this._orderViewModel.onDoneButtonClicked.reject(), this._unsubscribeOrderViewModel(), this._unmountOrderPanel()))
                        }, this._onStatusChanged = async () => {
                            try {
                                const e = this._state,
                                    t = this._makeState();
                                t.symbol === e.symbol && t.broker === e.broker && t.accountId === e.accountId && t.isAuthenticated === e.isAuthenticated || (this._state = t, this._setSettings(), await this._closeOrderDialog(), await this._closePositionDialog(), this._isTradingPanelOpened.value() && this._mode.value() === T.OrderEditorDisplayMode.Panel && this._tradingPanelActivePage.value() === Ge.TradingPage.OrderPanel && (await this._recreateOrderViewModel(), this._deactivateOrderPanel(), this._openOrderPanel()))
                            } catch (e) {
                                Xe.logError("Failed to change status: " + (0, c.getLoggerMessage)(e))
                            }
                        }, this._saveSettings = e => {
                            this._orderViewDataStorage.saveSettings(e)
                        }, this._recreateOrderViewModel = async e => {
                            null !== this._orderViewModel && (this._orderViewModel.existingOrder && this._orderViewModel.onDoneButtonClicked.reject(), this._unsubscribeOrderViewModel()), null !== this._positionViewModel && (this._positionViewModel.onDoneButtonClicked.reject(), this._unsubscribePositionViewModel()), this._orderStub = null != e ? e : this._createOrderStub();
                            const {
                                broker: t,
                                symbol: i
                            } = this._state;
                            let s = null;
                            if (null === t) s = new Ne({ ...this._commonOrderViewModelProps(),
                                adapter: t,
                                isTradable: {
                                    tradable: !1
                                },
                                isTradingPanelVisible: this._isTradingPanelVisible.value(),
                                handler: () => Promise.resolve(!0)
                            });
                            else {
                                const r = await t.isTradable(i),
                                    o = (null == e ? void 0 : e.hasOwnProperty("id")) ? t.modifyOrder.bind(t) : t.placeOrder.bind(t),
                                    n = r.tradable ? await this._getInputStateFromStorage() : void 0;
                                s = new Ne({ ...this._commonOrderViewModelProps(),
                                    adapter: t,
                                    isTradable: r,
                                    isTradingPanelVisible: this._isTradingPanelVisible.value(),
                                    handler: o,
                                    savedInputState: n,
                                    forceAbsolutePriceUpdate: !0
                                })
                            }
                            if (this._orderViewModel = s, await s.onReady, this._orderViewModel !== s) return Promise.reject("OrderViewModel was recreated during the initialization");
                            this._subscribeOrderViewModel()
                        }, this._onOrderWidgetModeChanged = async e => {
                            e === T.OrderEditorDisplayMode.Panel ? (await this._closeOrderDialog(), await this._openOrderPanel()) : (await this._closeOrderPanel(), await this._showOrderDialog())
                        }, this._onOrderWidgetInputStateChanged = e => {
                            var t, i, s, r, o;
                            if ((0, O.isDefined)(e.quantity) && (null === (t = this._getTradingSettingsStorage()) || void 0 === t || t.setSymbolQty(this._state.symbol, e.quantity)), (0, O.isDefined)(e.takeProfitPips) && (null === (i = this._getTradingSettingsStorage()) || void 0 === i || i.setTakeProfitPips(this._state.symbol, e.takeProfitPips, T.BracketDefaultPips.TakeProfit)), (0,
                                    O.isDefined)(e.stopLossPips) && (null === (s = this._getTradingSettingsStorage()) || void 0 === s || s.setStopLossPips(this._state.symbol, e.stopLossPips, T.BracketDefaultPips.StopLoss)), (0, O.isDefined)(e.duration)) {
                                const t = this._state.broker && this._state.broker.metainfo().durations,
                                    i = t && (t.find(e => e.default) || t[0]),
                                    s = i && i.name === e.duration.type ? null : e.duration;
                                null === (r = this._getTradingSettingsStorage()) || void 0 === r || r.setDuration(this._state.symbol, s)
                            }(0, O.isDefined)(e.customFields) && (null === (o = this._getTradingSettingsStorage()) || void 0 === o || o.setCustomFields(this._state.symbol, e.customFields)), (0, O.isDefined)(e.side) && this._setState({
                                side: e.side
                            })
                        }, this._onOrderWidgetCloseButtonClicked = () => {
                            this._mode.value() === T.OrderEditorDisplayMode.Panel ? this.closePanel() : this._closeOrderDialog()
                        }, this._onOrderWidgetBackButtonClicked = () => {
                            this._orderViewModel && this._orderViewModel.status.value() === T.OrderPanelStatus.Preview ? this._mode.value() === T.OrderEditorDisplayMode.Panel && (this._activateOrderPanel(), this._openOrderPanel()) : this.showOrderView({
                                order: this._createOrderStub()
                            })
                        }, this._onPositionWidgetModeChanged = async e => {
                            e === T.OrderEditorDisplayMode.Panel ? (await this._closePositionDialog(), await this._openPositionPanel()) : (await this._closePositionPanel(), await this._showPositionDialog())
                        }, this._onPositionWidgetBackButtonClicked = () => {
                            this._unmountPositionPanel(), this._unsubscribePositionViewModel(), this.showOrderView({
                                order: this._createOrderStub()
                            })
                        }, this._onPositionWidgetCloseButtonClicked = () => {
                            this._mode.value() === T.OrderEditorDisplayMode.Panel ? this.closePanel() : this._closePositionDialog()
                        }, this._tradingCommands = e, this._trackEvent = e.trackEvent, this._realtimeProvider = e.realtimeProvider, this._resizerBridge = e.resizerBridge, this._orderViewDataStorage = new Ue(s), this._tradingPanelContainer = t.container, this._isTradingPanelVisible = t.isVisible, this._isTradingPanelOpened = t.isOpened, this._qtySuggester = i, this._tradingPanelActivePage = t.activePage, this._closeTradingPanel = t.close, this._openTradingPanelPage = t.openPage, this._getTradingSettingsStorage = e.getTradingSettingsStorage, this.dialogVisibility = this._visibility.value$, window.matchMedia(Je.TradingLayoutBreakpoint.Mobile).matches) this._setDisplayMode(T.OrderEditorDisplayMode.Popup);
                    else if (l.enabled("order_panel")) {
                        const e = this._orderViewDataStorage.widgetMode();
                        this._setDisplayMode(null != e ? e : T.OrderEditorDisplayMode.Panel)
                    } else this._setDisplayMode(T.OrderEditorDisplayMode.Popup);
                    t.isVisible.subscribe(e => {
                            "visible" !== document.visibilityState || e || this._mode.value() !== T.OrderEditorDisplayMode.Panel || (t.close(), this._setDisplayMode(T.OrderEditorDisplayMode.Popup))
                        }), this._state = this._makeState(), this.stateChanging = He.value, this._onStatusChanged = (0, a.sequentialize)(this._onStatusChanged), this._onStatusChanged = He.wrap(this._onStatusChanged), this.openPanel = He.wrap(this.openPanel), this._realtimeProvider.onStatusChanged.subscribe(null, () => this._onStatusChanged()), r.linking.proSymbol.subscribe(this._onStatusChanged), window.loginStateChange && window.loginStateChange.subscribe(this, this._onStatusChanged),
                        t.activePage.subscribe(this._onActiveTradingPanelChanged)
                }
                closePanel() {
                    if (null !== this._positionViewModel) return this._positionViewModel.onDoneButtonClicked.reject(), this._closePositionPanel(), void this._unsubscribePositionViewModel();
                    null !== this._orderViewModel && (this._orderViewModel.existingOrder && this._orderViewModel.onDoneButtonClicked.reject(), this._closeOrderPanel(), this._unsubscribeOrderViewModel())
                }
                async showOrderView(e) {
                    try {
                        const {
                            order: t,
                            focus: i,
                            forceOrderDialog: s
                        } = e;
                        s && this._setDisplayMode(T.OrderEditorDisplayMode.Popup);
                        const r = Object.assign(this._createOrderStub(), t);
                        return t.symbol !== this._state.symbol && this._setState({
                            symbol: t.symbol
                        }), await this._recreateOrderViewModel(r), this._mode.value() === T.OrderEditorDisplayMode.Panel ? this._openOrderPanel(i) : this._showOrderDialog(i), (0, o.ensureNotNull)(this._orderViewModel).onDoneButtonClicked.promise
                    } catch (e) {
                        return Xe.logError("Failed to show order view: " + (0, c.getLoggerMessage)(e)), !1
                    }
                }
                async showPositionView(e, t, i) {
                    try {
                        return this._createAndShowPositionViewModel({
                            position: e,
                            viewType: We.Position,
                            brackets: t,
                            focus: i
                        })
                    } catch (e) {
                        return Xe.logError("Failed to show position view: " + (0, c.getLoggerMessage)(e)), !1
                    }
                }
                async showTradeView(e, t, i) {
                    try {
                        return this._createAndShowPositionViewModel({
                            position: e,
                            viewType: We.Trade,
                            brackets: t,
                            focus: i
                        })
                    } catch (e) {
                        return Xe.logError("Failed to show trade view: " + (0, c.getLoggerMessage)(e)), !1
                    }
                }
                mode() {
                    return this._mode
                }
                _setState(e) {
                    this._state = { ...this._state,
                        ...e
                    }
                }
                _setDisplayMode(e) {
                    this._mode.setValue(e), this._orderViewDataStorage.setWidgetMode(e)
                }
                _makeState() {
                    var e;
                    const t = window.is_authenticated,
                        i = r.linking.proSymbol.value() || r.linking.symbol.value() || "",
                        s = this._realtimeProvider.activeBroker(),
                        o = null !== (e = null == s ? void 0 : s.currentAccount()) && void 0 !== e ? e : null,
                        n = s ? s.metainfo().id : "";
                    return this._orderViewDataStorage.setBrokerId(n), {
                        isAuthenticated: t,
                        broker: s,
                        symbol: i,
                        accountId: o,
                        side: 1
                    }
                }
                async _createAndShowPositionViewModel({
                    position: e,
                    viewType: t,
                    brackets: i,
                    focus: s
                }) {
                    e.symbol !== this._state.symbol && this._setState({
                        symbol: e.symbol
                    }), null !== this._positionViewModel && (this._positionViewModel.onDoneButtonClicked.reject(), this._unsubscribePositionViewModel()), null !== this._orderViewModel && (this._orderViewModel.existingOrder && this._orderViewModel.onDoneButtonClicked.reject(), this._unsubscribeOrderViewModel(), this._mode.value() === T.OrderEditorDisplayMode.Popup && await this._closeOrderDialog());
                    const {
                        broker: r,
                        symbol: o
                    } = this._state, n = r ? await r.isTradable(o) : null;
                    if (null === r || null === n || !n.tradable) return this._mode.value() === T.OrderEditorDisplayMode.Popup && await this._closePositionDialog(), await this.showOrderView({
                        order: this._createOrderStub()
                    }), !1;
                    const a = t === We.Position ? r.editPositionBrackets.bind(r) : r.editTradeBrackets.bind(r),
                        l = new Ae({
                            adapter: r,
                            position: e,
                            brackets: i,
                            mode: this._mode,
                            settings: this._settings,
                            realtimeProvider: this._tradingCommands.realtimeProvider,
                            isTradingPanelVisible: this._isTradingPanelVisible.value(),
                            isTradingPanelOpened: this._isTradingPanelOpened,
                            viewType: t,
                            pipValueType: this._tradingCommands.pipValueType,
                            handler: a,
                            trackEvent: this._tradingCommands.trackEvent
                        });
                    return this._positionViewModel = l, await this._positionViewModel.onReady, this._positionViewModel !== l ? Promise.reject("PositionViewModel was recreated during the initialization") : (this._subscribePositionViewModel(), this._mode.value() === T.OrderEditorDisplayMode.Panel ? this._openPositionPanel(s) : this._showPositionDialog(s), this._positionViewModel.onDoneButtonClicked.promise)
                }
                _defaultBrokerOrderType() {
                    const e = this._state.broker,
                        t = null !== e ? e.metainfo().configFlags : null;
                    if (null !== t) return (t.supportLimitOrders ? 1 : t.supportMarketOrders && 2) || t.supportStopLimitOrders && 4 || t.supportStopOrders && 3 || void 0
                }
                _setSettings() {
                    if (null === this._state.broker) return;
                    this._settings.unsubscribe(this._saveSettings);
                    const e = this._state.broker.metainfo().configFlags.supportCryptoBrackets;
                    let t = this._orderViewDataStorage.getSettings() || Ke.defaultSettings;
                    e && (t = Object.assign({}, Ke.defaultCryptoBracketsSettings, t)), this._settings.setValue(t), this._settings.subscribe(this._saveSettings)
                }
                _createOrderStub() {
                    return {
                        limitPrice: 0,
                        stopPrice: 0,
                        qty: 0,
                        side: void 0,
                        symbol: this._state.symbol,
                        type: this._defaultBrokerOrderType(),
                        takeProfit: void 0,
                        stopLoss: void 0
                    }
                }
                _activateOrderPanel() {
                    null !== this._orderViewModel && this._orderViewModel.activateOrderPanel()
                }
                _deactivateOrderPanel() {
                    null !== this._orderViewModel && this._orderViewModel.deactivateOrderPanel()
                }
                _resetOrderPanel() {
                    null !== this._orderViewModel && this._orderViewModel.resetOrderPanel()
                }
                async _openOrderPanel(e) {
                    await this._mountOrderPanel(e), this._openTradingPanelPage(Ge.TradingPage.OrderPanel)
                }
                async _mountOrderPanel(e) {
                    const {
                        mountOrderPanel: t
                    } = await Ze();
                    null !== this._orderViewModel && t(this._orderViewModel, this._settings, this._tradingPanelContainer, (0, o.ensureNotNull)(this._resizerBridge).width, e, this._trackEvent)
                }
                async _closeOrderPanel() {
                    await this._unmountOrderPanel(), this._closeTradingPanel()
                }
                async _unmountOrderPanel() {
                    const {
                        unmountOrderPanel: e
                    } = await Ze();
                    e((0, o.ensureNotNull)(this._tradingPanelContainer))
                }
                async _showOrderDialog(e) {
                    const {
                        showOrderDialog: t
                    } = await Ze();
                    null !== this._orderViewModel && t({
                        viewModel: this._orderViewModel,
                        settings: this._settings,
                        focus: e,
                        trackEvent: this._trackEvent,
                        onOpen: e => {
                            this._visibility.setValue({
                                isVisible: !0,
                                isFullScreen: e
                            })
                        },
                        onClose: () => {
                            this._visibility.setValue({
                                isVisible: !1
                            })
                        }
                    })
                }
                async _closeOrderDialog() {
                    const {
                        closeOrderDialog: e
                    } = await Ze();
                    e(() => this._visibility.setValue({
                        isVisible: !1
                    }))
                }
                _subscribeOrderViewModel() {
                    (0, o.ensureNotNull)(this._orderViewModel).onModeChanged().subscribe(this, this._onOrderWidgetModeChanged), (0, o.ensureNotNull)(this._orderViewModel).onInputStateChanged().subscribe(this, this._onOrderWidgetInputStateChanged), (0, o.ensureNotNull)(this._orderViewModel).onCloseButtonClicked().subscribe(this, this._onOrderWidgetCloseButtonClicked), (0, o.ensureNotNull)(this._orderViewModel).onBackButtonClicked().subscribe(this, this._onOrderWidgetBackButtonClicked)
                }
                _unsubscribeOrderViewModel() {
                    (0, o.ensureNotNull)(this._orderViewModel).onModeChanged().unsubscribe(this, this._onOrderWidgetModeChanged), (0,
                        o.ensureNotNull)(this._orderViewModel).onInputStateChanged().unsubscribe(this, this._onOrderWidgetInputStateChanged), (0, o.ensureNotNull)(this._orderViewModel).onCloseButtonClicked().unsubscribe(this, this._onOrderWidgetCloseButtonClicked), (0, o.ensureNotNull)(this._orderViewModel).onBackButtonClicked().unsubscribe(this, this._onOrderWidgetBackButtonClicked), (0, o.ensureNotNull)(this._orderViewModel).destroy(), this._orderViewModel = null
                }
                async _openPositionPanel(e) {
                    await this._mountPositionPanel(e), this._openTradingPanelPage(Ge.TradingPage.OrderPanel)
                }
                async _mountPositionPanel(e) {
                    const {
                        mountPositionPanel: t
                    } = await et();
                    if (null !== this._positionViewModel) return t(this._positionViewModel, this._settings, this._tradingPanelContainer, e)
                }
                async _closePositionPanel() {
                    await this._unmountPositionPanel(), this._closeTradingPanel()
                }
                async _unmountPositionPanel() {
                    const {
                        unmountPositionPanel: e
                    } = await et();
                    e(this._tradingPanelContainer)
                }
                async _showPositionDialog(e) {
                    const {
                        showPositionDialog: t
                    } = await et();
                    null !== this._positionViewModel && t({
                        viewModel: this._positionViewModel,
                        settings: this._settings,
                        focus: e,
                        onOpen: e => {
                            this._visibility.setValue({
                                isVisible: !0,
                                isFullScreen: e
                            })
                        },
                        onClose: () => {
                            this._visibility.setValue({
                                isVisible: !1
                            })
                        }
                    })
                }
                async _closePositionDialog() {
                    const {
                        closePositionDialog: e
                    } = await et();
                    e(() => this._visibility.setValue({
                        isVisible: !1
                    }))
                }
                _subscribePositionViewModel() {
                    (0, o.ensureNotNull)(this._positionViewModel).onModeChanged().subscribe(this, this._onPositionWidgetModeChanged), (0, o.ensureNotNull)(this._positionViewModel).onBackButtonClicked().subscribe(this, this._onPositionWidgetBackButtonClicked), (0, o.ensureNotNull)(this._positionViewModel).onCloseButtonClicked().subscribe(this, this._onPositionWidgetCloseButtonClicked)
                }
                _unsubscribePositionViewModel() {
                    (0, o.ensureNotNull)(this._positionViewModel).onModeChanged().unsubscribe(this, this._onPositionWidgetModeChanged), (0, o.ensureNotNull)(this._positionViewModel).onBackButtonClicked().unsubscribe(this, this._onPositionWidgetBackButtonClicked), (0, o.ensureNotNull)(this._positionViewModel).onCloseButtonClicked().unsubscribe(this, this._onPositionWidgetCloseButtonClicked), (0, o.ensureNotNull)(this._positionViewModel).onDoneButtonClicked.resolve(!1), (0, o.ensureNotNull)(this._positionViewModel).destroy(), this._positionViewModel = null
                }
                async _getInputStateFromStorage() {
                    var e, t, i, s, r, o, n;
                    let a;
                    const l = await (null === (e = this._state.broker) || void 0 === e ? void 0 : e.getOrderDialogOptions(this._state.symbol));
                    l && l.customFields && (a = null === (t = this._getTradingSettingsStorage()) || void 0 === t ? void 0 : t.customFields(this._state.symbol, l.customFields.map(e => e.id)));
                    const u = (null === (i = this._getTradingSettingsStorage()) || void 0 === i ? void 0 : i.duration(this._state.symbol)) || null,
                        h = null === (s = this._state.broker) || void 0 === s ? void 0 : s.metainfo().durations,
                        c = void 0 !== h && null !== u ? (0, O.findDurationMetaInfo)(h, u.type) : void 0;
                    if (null !== u && void 0 !== c && (c.hasDatePicker || c.hasTimePicker) && void 0 !== u.datetime) {
                        const e = c.hasTimePicker ? u.datetime < Date.now() : Math.floor((u.datetime - Date.now()) / 864e5) < 0;
                        u.datetime = e ? (0,
                            O.makeDatePlus24UTCHours)().getTime() : u.datetime
                    }
                    return {
                        symbol: this._state.symbol,
                        side: this._state.side,
                        limitPrice: null,
                        stopPrice: null,
                        quantity: (null === (r = this._getTradingSettingsStorage()) || void 0 === r ? void 0 : r.symbolQty(this._state.symbol)) || null,
                        takeProfitPips: (null === (o = this._getTradingSettingsStorage()) || void 0 === o ? void 0 : o.takeProfitPips(this._state.symbol)) || null,
                        stopLossPips: (null === (n = this._getTradingSettingsStorage()) || void 0 === n ? void 0 : n.stopLossPips(this._state.symbol)) || null,
                        duration: u,
                        customFields: a || null
                    }
                }
                _commonOrderViewModelProps() {
                    return {
                        order: this._orderStub,
                        mode: this._mode,
                        settings: this._settings,
                        orderWidgetStat: this._orderWidgetStat,
                        isTradingPanelOpened: this._isTradingPanelOpened,
                        pipValueType: this._tradingCommands.pipValueType,
                        onNeedSelectBroker: this._tradingCommands.onNeedSelectBroker,
                        trackEvent: this._tradingCommands.trackEvent,
                        toggleTradingWidget: this._tradingCommands.toggleTradingWidget,
                        showErrorNotification: this._tradingCommands.showErrorNotification,
                        qtySuggester: this._qtySuggester
                    }
                }
            }
        },
        12334: (e, t, i) => {
            "use strict";
            i.d(t, {
                TradingLayoutBreakpoint: () => r
            });
            var s = i(82515);
            const r = {
                Mobile: s.mobile
            }
        },
        32207: (e, t, i) => {
            "use strict";
            i.d(t, {
                SplitThousandsFormatter: () => o
            });
            var s = i(72249),
                r = i(34581);
            class o {
                constructor(e = " ") {
                    this._divider = e
                }
                format(e) {
                    const t = (0, s.splitThousands)(e, this._divider);
                    return (0, r.isRtl)() ? (0, r.startWithLTR)(t) : t
                }
                parse(e) {
                    const t = (0, r.stripLTRMarks)(e).split(this._divider).join(""),
                        i = Number(t);
                    return isNaN(i) || /e/i.test(t) ? {
                        res: !1
                    } : {
                        res: !0,
                        value: i,
                        suggest: this.format(i)
                    }
                }
            }
        }
    }
]);
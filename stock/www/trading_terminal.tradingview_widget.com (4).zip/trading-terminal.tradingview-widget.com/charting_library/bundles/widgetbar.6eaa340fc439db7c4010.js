(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [4876], {
        1425: () => {},
        26473: t => {
            t.exports = {
                "css-value-widgetbar-tabs-width": "45px",
                "css-value-widgetbar-border-width": "1px"
            }
        },
        13646: t => {
            t.exports = {
                "css-value-widgets-margin": "4px",
                widget: "widget-FmHEpRDS",
                widgetHeader: "widgetHeader-FmHEpRDS",
                widgetTitle: "widgetTitle-FmHEpRDS",
                headerSpace: "headerSpace-FmHEpRDS"
            }
        },
        45285: () => {},
        69445: () => {},
        61226: t => {
            t.exports = {
                container: "container-68Nk42BD",
                mirror: "mirror-68Nk42BD",
                background: "background-68Nk42BD",
                arrow: "arrow-68Nk42BD"
            }
        },
        60306: t => {
            t.exports = {
                wrap: "wrap-GVak88eE",
                scrollWrap: "scrollWrap-GVak88eE",
                noScrollBar: "noScrollBar-GVak88eE",
                content: "content-GVak88eE",
                icon: "icon-GVak88eE",
                scrollBot: "scrollBot-GVak88eE",
                scrollTop: "scrollTop-GVak88eE",
                isVisible: "isVisible-GVak88eE",
                iconWrap: "iconWrap-GVak88eE",
                fadeBot: "fadeBot-GVak88eE",
                fadeTop: "fadeTop-GVak88eE"
            }
        },
        58191: t => {
            t.exports = {
                button: "button-26sjqpTM",
                icon: "icon-26sjqpTM"
            }
        },
        29954: t => {
            t.exports = {
                filler: "filler-outFBGGP"
            }
        },
        59542: t => {
            t.exports = {
                toolbar: "toolbar-jAj3CM2X",
                isGrayed: "isGrayed-jAj3CM2X"
            }
        },
        73878: t => {
            t.exports = {
                separator: "separator-nAcgOE1b"
            }
        },
        17982: t => {
            t.exports = {
                button: "button-L19piAIa",
                hover: "hover-L19piAIa",
                hoverMask: "hoverMask-L19piAIa",
                icon: "icon-L19piAIa",
                counterRow: "counterRow-L19piAIa",
                counter: "counter-L19piAIa",
                isGrayed: "isGrayed-L19piAIa",
                isActive: "isActive-L19piAIa",
                isTab: "isTab-L19piAIa"
            }
        },
        25669: () => {},
        99158: t => {
            t.exports = {
                wrapper: "wrapper-BaEDTGCd",
                touch: "touch-BaEDTGCd"
            }
        },
        72571: (t, e, i) => {
            "use strict";
            i.d(e, {
                Icon: () => n
            });
            var s = i(59496);
            const n = s.forwardRef((t, e) => {
                const {
                    icon: i = "",
                    ...n
                } = t;
                return s.createElement("span", { ...n,
                    ref: e,
                    dangerouslySetInnerHTML: {
                        __html: i
                    }
                })
            })
        },
        47465: (t, e, i) => {
            "use strict";
            i.d(e, {
                makeCancelable: () => n,
                isCancelled: () => a
            });
            class s {}

            function n(t) {
                let e = !1;
                return {
                    promise: new Promise((i, n) => {
                        t.then(t => e ? n(new s) : i(t)), t.catch(t => n(e ? new s : t))
                    }),
                    cancel() {
                        e = !0
                    }
                }
            }

            function a(t) {
                return t instanceof s
            }
        },
        92978: (t, e, i) => {
            "use strict";
            i.r(e), i.d(e, {
                WidgetBar: () => Ot
            });
            var s = i(58121),
                n = i(88537),
                a = (i(1425), i(26473), i(25177)),
                r = i(55563),
                o = i(59496),
                l = i(87995),
                h = i(94489),
                d = i.n(h);
            const c = {
                isActive: !1,
                notificationCount: 0
            };
            class u {
                constructor(t) {
                    const e = { ...c,
                        ...t
                    };
                    this.isActive = new(d())(e.isActive), this.notificationsCount = new(d())(e.notificationCount), this.icon = new(d())(e.icon), this.hint = new(d())(e.hint), this.onClick = new(d())(e.onClick), this.TabButtonComponent = t.TabButtonComponent
                }
                onActiveStateChange(t) {
                    this.isActive.setValue(t)
                }
                updateNotifications(t) {
                    this.notificationsCount.setValue(t)
                }
            }
            var g = i(62759),
                p = i(35982),
                m = i(48200),
                _ = i(13646);
            const v = parseInt(_["css-value-widgets-margin"]),
                f = {
                    reuters_calendar: {
                        title: (0, a.t)("Economic Calendar"),
                        ctor: null,
                        lazyLoad: !0,
                        icon: "economic-calendar",
                        options: {
                            widgetType: "widgetbar"
                        }
                    },
                    earnings_calendar: {
                        title: (0, a.t)("Earnings Calendar"),
                        ctor: null,
                        lazyLoad: !0,
                        icon: "earnings-calendar"
                    },
                    watchlist: {
                        title: (0, a.t)("Watchlist"),
                        ctor: null,
                        lazyLoad: !0,
                        chartWidgetAllowed: !0,
                        emptyHeader: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        margin: v,
                        preloadDelay: 6e4
                    },
                    hotlist: {
                        title: (0, a.t)("Hotlist"),
                        ctor: null,
                        lazyLoad: !0,
                        chartWidgetAllowed: !0,
                        emptyHeader: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        margin: v
                    },
                    detail: {
                        title: (0, a.t)("Details"),
                        ctor: null,
                        lazyLoad: !0,
                        chartWidgetAllowed: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        margin: v,
                        emptyHeader: !0
                    },
                    news: {
                        title: (0, a.t)("Headlines"),
                        ctor: null,
                        noHeaderSpace: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        titleClass: _.widgetTitle,
                        margin: v
                    },
                    chat: {
                        title: (0, a.t)("Talks"),
                        ctor: null,
                        chartWidgetAllowed: !0,
                        doNotClearNotifications: !0
                    },
                    messages: {
                        title: (0, a.t)("Recent Chats"),
                        ctor: null,
                        chartWidgetAllowed: !0,
                        doNotClearNotifications: !0
                    },
                    messages_with_select: {
                        title: (0, a.t)("Recent Chats"),
                        ctor: null,
                        chartWidgetAllowed: !0,
                        doNotClearNotifications: !0,
                        options: {
                            layoutWithSelect: !0
                        },
                        emptyHeader: !0
                    },
                    notifications_user: {
                        title: (0, a.t)("Notifications"),
                        ctor: null,
                        options: {
                            type: "user"
                        },
                        chartWidgetAllowed: !0
                    },
                    notifications_following: {
                        title: (0, a.t)("Ideas Stream"),
                        ctor: null,
                        options: {
                            type: "following"
                        },
                        chartWidgetAllowed: !0
                    },
                    datawindow: {
                        title: (0, a.t)("Data Window"),
                        ctor: null,
                        chartWidgetAllowed: !0,
                        chartWidgetRequired: !0
                    },
                    publicchats: {
                        title: (0, a.t)("All Talks"),
                        ctor: null,
                        doNotClearNotifications: !0
                    },
                    publicchats_with_select: {
                        title: (0, a.t)("All Talks"),
                        ctor: null,
                        doNotClearNotifications: !0,
                        options: {
                            layoutWithSelect: !0
                        },
                        emptyHeader: !0
                    },
                    notes: {
                        title: (0, a.t)("My Ideas"),
                        ctor: null,
                        lazyLoad: !0,
                        chartWidgetAllowed: !0
                    },
                    alerts_manage: {
                        ctor: null,
                        lazyLoad: !0,
                        chartWidgetAllowed: !0,
                        emptyHeader: !0,
                        noHeaderSpace: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        margin: v
                    },
                    alerts_log: {
                        ctor: null,
                        chartWidgetAllowed: !0,
                        emptyHeader: !0,
                        noHeaderSpace: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        margin: v
                    },
                    market_summary: {
                        title: (0, a.t)("Market Summary"),
                        ctor: null
                    },
                    object_tree: {
                        title: (0, a.t)("Object tree. Multi-select drawings tools"),
                        ctor: null,
                        noHeader: !0,
                        chartWidgetAllowed: !0,
                        chartWidgetRequired: !0
                    },
                    streams: {
                        title: (0, a.t)("Streams"),
                        ctor: null,
                        emptyHeader: !0,
                        widgetClass: _.widget,
                        headerClass: _.widgetHeader,
                        margin: v,
                        doNotClearNotifications: !0,
                        doNotClearNotificationsOnVisibilityChange: !0
                    }
                },
                w = {
                    base: g
                };
            w["object-tree"] = p, w.datawindow = m;
            var b = i(97754),
                y = i.n(b),
                C = i(52752),
                S = i(97496),
                T = i.n(S),
                B = i(88401),
                x = i(93605),
                E = i(32133),
                P = i(70122);
            class W {
                constructor(t) {
                    this._settingsKey = null, this._value = null, t && t.settingsKey && (this._settingsKey = t.settingsKey, this._value = P.getJSON(this._settingsKey, null)), t && t.widgetBarWidget && Object.defineProperty(this, "widgetBarWidget", {
                        value: t.widgetBarWidget,
                        configurable: !0
                    })
                }
                value() {
                    return this._value
                }
                setValue(t, e) {
                    return this._value = t, this._settingsKey && (null == t ? ((0, E.trackEvent)("Settings debug", "WigdetProperties.setValue: " + this._settingsKey, window.user.username), P.remove(this._settingsKey)) : P.setJSON(this._settingsKey, t, e)), this._value
                }
            }
            var M, L = i(2369);
            const H = new((M = class t {
                postMessage(e, i) {
                    t._handlers.forEach(t => {
                        t.handler(e, i)
                    })
                }
                onMessage(e) {
                    "function" == typeof e && t._handlers.push({
                        handler: e,
                        widget: this
                    })
                }
                offMessage(e) {
                    if ("function" == typeof e) {
                        const i = t._handlers.findIndex(t => t.handler === e); - 1 !== i && t._handlers.splice(i, 1)
                    }
                }
                offWidget(e) {
                    t._handlers = t._handlers.filter(t => t.widget !== e)
                }
            })._handlers = [], M);
            var O = i(16345),
                I = i(96818);
            class z {
                constructor(t) {
                    this.heightRatio = z.heightRatio, this.minHeight = 0, this.widgetConfig = null, this.widgetActive = new(d()), this.widgetMaximized = new(d()), this.widgetVisible = null, this.symbolLinking = null, this.intervalLinking = null, this._header = null, this._widget = null, this._headerIcon = null, this._headerspace = null, this._title = null, this._resizehandle = null, this._widgetStarted = new(T()), this._resizer = null, this._internalState = {
                        alive: new(d())(!0),
                        container: new(d()),
                        width: new(d()),
                        height: new(d()),
                        detachable: new(d())(!1)
                    }, t && t.widgetBarPage && (this.widgetBarPage = t.widgetBarPage), this._rdState = new C.ResizerDetacherState(this._internalState), this._rdState.owner.subscribe(t => {
                        t !== this._internalState && (this._internalState.container.value().innerHTML = "")
                    })
                }
                element(t) {
                    switch (t) {
                        case "widget":
                            return this._widget;
                        case "header":
                            return this._header;
                        case "resize-handle":
                            return this._resizehandle;
                        default:
                            return null
                    }
                }
                setHeight(t) {
                    this._internalState.container.value() && (this._internalState.container.value().style.height = t + "px"), this._internalState.height.setValue(t)
                }
                onWidthChange(t) {
                    this._internalState.width.setValue(t)
                }
                remove() {
                    this.widgetBarPage && this.widgetBarPage.removeWidget(this)
                }
                destroy() {
                    var t, e, i, s, n, a;
                    this.widgetObject && "destroy" in this.widgetObject && this.widgetObject.destroy(), this.remove(), this.symbolLinking && (this.symbolLinking.destroy(), this.symbolLinking = null), this.intervalLinking && (this.intervalLinking.destroy(), this.intervalLinking = null), this.widgetVisible && (this.widgetVisible.unsubscribe(), this.widgetVisible = null), this.widgetActive && (this.widgetActive.unsubscribe(), this.widgetActive = null), this.widgetMaximized && (this.widgetMaximized.unsubscribe(), this.widgetMaximized = null), null === (t = this._header) || void 0 === t || t.remove(), null === (e = this._widget) || void 0 === e || e.remove(), null === (i = this._headerIcon) || void 0 === i || i.remove(), null === (s = this._headerspace) || void 0 === s || s.remove(), null === (n = this._title) || void 0 === n || n.remove(), null === (a = this._resizehandle) || void 0 === a || a.remove(), this._header = null, this._widget = null, this._headerIcon = null, this._headerspace = null, this._title = null, this._resizehandle = null, H.offWidget(this), this._preloadTimeout && clearTimeout(this._preloadTimeout)
                }
                rdState() {
                    return this._rdState
                }
                onActiveStateChange(t) {
                    var e;
                    const i = (this.getWidgetBarOption("widgetConfig") || f)[this.type];
                    t && !i.doNotClearNotifications && this.clearNotifications(), this.updateVisibleWatchedValue(), null === (e = this.widgetActive) || void 0 === e || e.setValue(!!t)
                }
                toggleMaximize(t) {
                    var e, i, s;
                    const n = "boolean" != typeof t ? !(null === (e = this.widgetMaximized) || void 0 === e ? void 0 : e.value()) : t;
                    n !== (null === (i = this.widgetMaximized) || void 0 === i ? void 0 : i.value()) && (null === (s = this.widgetMaximized) || void 0 === s || s.setValue(n), this.widgetBarPage && this.widgetBarPage.widgetBarLayout && this.widgetBarPage.widgetBarLayout.widgetBar && this.widgetBarPage.widgetBarLayout.widgetBar.saveToTVSettings(), this.widgetBarPage && this.widgetBarPage.updateWidgetsHeight())
                }
                startWidget() {
                    var t;
                    if (this.widgetObject || this.widgetStartDelayed) return;
                    if (!this.id) return;
                    const e = this.getWidgetBarOption("widgetConfig") || f;
                    if (!this.type) return;
                    const i = e[this.type];
                    if (!i) return;
                    const s = i.ctor;
                    if (!s) return;
                    if (this.widgetVisible = this.widgetVisible || new(d()), this.updateVisibleWatchedValue(), i.lazyLoad && !this.widgetVisible.value()) return this.widgetStartDelayed = !0, this.widgetVisible.when(() => {
                        delete this.widgetStartDelayed, this.startWidget(), clearTimeout(this._preloadTimeout)
                    }), void(i.preloadDelay && (this._preloadTimeout = setTimeout(() => {
                        s.preload && s.preload()
                    }, i.preloadDelay)));
                    this.symbolLinking = B.linking.symbol.spawn(), this.intervalLinking = B.linking.interval.spawn();
                    const a = this._rdState.bridge(),
                        r = { ...{},
                            header: (0, n.ensureNotNull)(this._header),
                            headerspace: this._headerspace,
                            widget: (0, n.ensureNotNull)(this._widget),
                            container: a.container.value(),
                            properties: this.properties,
                            notify: this.notify.bind(this),
                            clearNotifications: this.clearNotifications.bind(this),
                            visible: this.widgetVisible.readonly(),
                            active: (0, n.ensureNotNull)(this.widgetActive).readonly(),
                            symbol: this.symbolLinking,
                            interval: this.intervalLinking,
                            height: a.height,
                            setMinHeight: this.setMinHeight.bind(this),
                            width: a.width,
                            setTitle: this.setTitle.bind(this),
                            setTitleHtml: this.setTitleHtml.bind(this),
                            id: this.id,
                            toggleMaximize: this.toggleMaximize.bind(this),
                            maximized: (0, n.ensureNotNull)(this.widgetMaximized).readonly(),
                            postMessage: H.postMessage.bind(this),
                            onMessage: H.onMessage.bind(this),
                            offMessage: H.offMessage.bind(this),
                            hideDetach: !1,
                            unAuthEditable: this.unAuthEditable
                        };
                    if (i.chartWidgetAllowed) {
                        const t = () => this.widgetBarPage && this.widgetBarPage.widgetBarLayout && this.widgetBarPage.widgetBarLayout.widgetBar && this.widgetBarPage.widgetBarLayout.widgetBar.chartWidgetCollection;
                        r.getChartWidget = () => {
                            const e = t();
                            return e ? e.activeChartWidget.value() : null
                        }, r.getChartWidgetCollection = () => t() || null
                    }
                    void 0 !== this.readonly ? this.readonly && (r.readonly = !0) : this.getWidgetBarOption("readonly") && (r.readonly = !0), void 0 !== i.options && (r.options = i.options), null != this.stateData ? r.data = this.stateData : null != i.data && (r.data = i.data);
                    const o = this.widgetObject = new s(r);
                    "hasLifecycle" in o && (null === (t = this.widgetActive) || void 0 === t || t.readonly().subscribe(t => {
                        t ? o.mount() : o.unmount()
                    }, {
                        callWithLast: !i.lazyLoad
                    })), this._widgetStarted.fire(this)
                }
                widgetStarted() {
                    return this._widgetStarted
                }
                notify(t, e = {}) {
                    if (this.widgetBarPage && (!this.widgetBarPage.isActiveAndVisible() || e.force)) return this.widgetBarPage.notify(t, e)
                }
                clearNotifications() {
                    if (this.widgetBarPage) return this.widgetBarPage.clearNotifications()
                }
                onVisibilityChange() {
                    this.updateVisibleWatchedValue()
                }
                updateVisibleWatchedValue() {
                    this.widgetVisible && this.widgetVisible.setValue(!!this.widgetBarPage && this.widgetBarPage.isActiveAndVisible())
                }
                setTitle(t) {
                    this.customTitle = String(t), this._title && (this._title.textContent = this.getTitle())
                }
                setTitleHtml(t) {
                    this._title && (0, L.html)(this._title, t)
                }
                setMinHeight(t) {
                    const e = this.widgetBarPage;
                    e && (this.minHeight = 0, this.minHeight = Math.min(t, e.getAvailableHeight()), e.updateWidgetsHeight())
                }
                getWidgetBarOption(t) {
                    if (this.widgetBarPage && this.widgetBarPage.widgetBarLayout && this.widgetBarPage.widgetBarLayout.widgetBar && t in this.widgetBarPage.widgetBarLayout.widgetBar) return this.widgetBarPage.widgetBarLayout.widgetBar[t]
                }
                getTitle(t) {
                    const e = function(t, e) {
                        var i, s;
                        try {
                            let n = null === (i = (e = e || f)[t]) || void 0 === i ? void 0 : i.title;
                            return !n && t && (n = null === (s = String(t).match(/[A-Z]{2,}|\d+(?:\.\d+)?|[A-Z]?[a-z]+/g)) || void 0 === s ? void 0 : s.join(" ").replace(/^.|\s./g, t => t.toUpperCase())), n || void 0
                        } catch (t) {
                            return
                        }
                    }(this.type, this.getWidgetBarOption("widgetConfig"));
                    return t && this.customTitle && e ? this.customTitle.substring(0, e.length) === e ? this.customTitle : e + ": " + this.customTitle : this.customTitle || e || (0, a.t)("Widget")
                }
                createHTML() {
                    const t = !!this.widgetConfig && (!!this.widgetConfig.icon && this.widgetConfig.icon),
                        e = this.widgetConfig && this.widgetConfig.emptyHeader,
                        i = this.widgetConfig && this.widgetConfig.noHeader,
                        s = this.widgetConfig && this.widgetConfig.noHeaderSpace,
                        n = this.widgetConfig && this.widgetConfig.widgetClass || "",
                        a = this.widgetConfig && this.widgetConfig.headerClass || "",
                        r = this.widgetConfig && this.widgetConfig.titleClass || "",
                        o = this._widget = document.createElement("div");
                    o.classList.value = y()(n, "widgetbar-widget", "widgetbar-widget-" + this.type);
                    const l = this._header = document.createElement("div");
                    if (l.classList.value = a || "widgetbar-widgetheader", l.addEventListener("contextmenu", t => {
                            "input" !== t.target.tagName.toLowerCase() && t.preventDefault()
                        }), i || o.appendChild(l), t) {
                        const e = this._headerIcon = document.createElement("div");
                        e.classList.value = "widgetbar-widgetheader-icon widgetbar-widgetheader-icon-" + t, e.appendChild((0, x.parseHtml)(w[t])), l.appendChild(e)
                    }
                    if (!s) {
                        const t = this._headerspace = document.createElement("div");
                        t.classList.value = "widgetbar-headerspace", t.addEventListener("click", t => t.preventDefault()), l.appendChild(t)
                    }
                    if (!e) {
                        const t = this._title = document.createElement("div");
                        t.classList.value = y()("widgetbar-widgettitle", r), t.dataset.name = this.type + "_header", t.textContent = this.getTitle(), l.appendChild(t)
                    }
                    const h = document.createElement("div");
                    h.classList.value = "widgetbar-widgetbody", h.addEventListener("contextmenu", t => {
                        t.target === h && t.preventDefault()
                    }), o.appendChild(h), this._internalState.container.setValue(h);
                    const d = this._resizehandle = document.createElement("div");
                    d.classList.value = "widgetbar-widgethandle", d.addEventListener("contextmenu", t => {
                        t.target === d && t.preventDefault()
                    }), null !== this._resizer && this._resizer.destroy(), this._resizer = new I.PointerBackend({
                        handle: d,
                        onDragStart: t => {
                            var e;
                            null === (e = this.widgetBarPage) || void 0 === e || e.handleWidgetResizeStart(this, t)
                        },
                        onDragMove: t => {
                            var e;
                            null === (e = this.widgetBarPage) || void 0 === e || e.handleWidgetResizeChange(this, t)
                        },
                        onDragStop: t => {
                            var e;
                            null === (e = this.widgetBarPage) || void 0 === e || e.handleWidgetResizeStop(this, t)
                        }
                    }), o.appendChild(d), !0 === this.maximized && (this.toggleMaximize(!0), delete this.maximized)
                }
                demarshal(t) {
                    if ("string" == typeof t) try {
                        t = JSON.parse(t)
                    } catch (t) {}
                    if (!t || "object" != typeof t) return null;
                    let e;
                    if ("id" in t ? (this.id = String(t.id),
                            this.type = this.id.replace(/\..*/, "")) : "type" in t ? (this.type = String(t.type), this.id = this.type + "." + (0, O.randomHash)()) : (delete this.type, delete this.id), null != t.readonly ? this.readonly = !!t.readonly : delete this.readonly, this.stateData = t.data, isFinite(Number(t.heightRatio)) && Number(t.heightRatio) >= 0 ? this.heightRatio = Number(t.heightRatio) : this.heightRatio = z.heightRatio, !0 === t.maximized && (this.maximized = !0), !0 === t.unAuthEditable && (this.unAuthEditable = !0), t.settingsKey) e = String(t.settingsKey);
                    else if (this.id) {
                        const t = this.getWidgetBarOption("_settingsPrefix");
                        t && (e = t + ".widget." + this.id)
                    }
                    if (this.properties = new W({
                            widgetBarWidget: this,
                            settingsKey: e
                        }), null == t.properties || e && null !== this.properties.value() || this.properties.setValue(t.properties), "news" !== this.type && "hotlist" !== this.type || !e || this.properties.setValue((0, s.default)({}, t.properties, this.properties.value())), "hotlist" === this.type)
                        if (!e && t.properties) this.properties.setValue(t.properties);
                        else {
                            const t = this.properties.value();
                            ("exchangeByLocale" in t || "groupByLocale" in t) && (delete t.exchangeByLocale, delete t.groupByLocale, this.properties.setValue(t))
                        }
                    this.widgetConfig = null;
                    const i = this.getWidgetBarOption("widgetConfig");
                    return this.type && i && i[this.type] && (this.widgetConfig = i[this.type]), this
                }
                marshal() {
                    var t;
                    const e = {};
                    return this.id && (e.id = this.id), this.type && (e.type = this.type), this.heightRatio !== z.heightRatio && (e.heightRatio = this.heightRatio), (null === (t = this.widgetMaximized) || void 0 === t ? void 0 : t.value()) && (e.maximized = !0), e
                }
            }
            z.heightRatio = 1;
            class N {
                constructor(t) {
                    this.widgets = [], this.notificationCounter = 0, this._page = null, this._invalidated = !1, this._resizeOperations = new WeakMap, this.widgets = [], t && t.widgetBarLayout && (this.widgetBarLayout = t.widgetBarLayout)
                }
                widget(t) {
                    for (const e of this.widgets)
                        if (e.type === t) return e;
                    return null
                }
                element() {
                    return this._page
                }
                gaEvent() {
                    return this._gaEvent
                }
                onActiveStateChange(t) {
                    var e;
                    t = !!t, null === (e = this._page) || void 0 === e || e.classList.toggle("active", !!t), (0, n.ensure)(this.tab).onActiveStateChange(t), t && this.updateWidgetsHeight({
                        skipIfHeightUnchanged: !0
                    }), this.widgets.forEach(e => {
                        e.onActiveStateChange(t)
                    })
                }
                getAvailableHeight() {
                    var t, e;
                    let i = (null === (e = null === (t = this.widgetBarLayout) || void 0 === t ? void 0 : t.widgetBar) || void 0 === e ? void 0 : e.resizerBridge.height.value()) || 0;
                    if (!i) return 0;
                    let s = 0;
                    return this.widgets.forEach((t, e) => {
                        if (i -= t.minHeight, e > 0) {
                            const e = t.widgetConfig && t.widgetConfig.margin || 1;
                            i -= e
                        }
                        const n = t.element("header");
                        n && (s || (s = (0, L.outerHeight)(n, !0)), i -= s)
                    }), Math.max(i, 0)
                }
                updateWidgetsHeight(t = {}) {
                    if (!this._page) return;
                    if (!this.widgetBarLayout || !this.widgetBarLayout.widgetBar) return;
                    if (this.widgetBarLayout.getActivePage() !== this) return void(this._invalidated = !0);
                    const e = this.widgetBarLayout.widgetBar.resizerBridge.height.value();
                    if (this._pageHeight === e && t.skipIfHeightUnchanged || (this._invalidated = !0, this._pageHeight = e), !this._invalidated) return;
                    let i, s = e,
                        a = 0,
                        r = this.widgets,
                        o = null;
                    const l = r.every(t => 0 === t.heightRatio);
                    for (let t = this.widgets.length; t--;)
                        if ((0, n.ensureNotNull)(this.widgets[t].widgetMaximized).value()) {
                            o = this.widgets[t];
                            break
                        }
                    if (r.length > 0 && null === o && l) {
                        const t = r[r.length - 1];
                        t.heightRatio = 1, o = t
                    }
                    if (o) {
                        for (let t = this.widgets.length; t--;) {
                            const e = r[t];
                            e !== o && e.setHeight(0)
                        }
                        r = [o]
                    }
                    for (let t = r.length - 1; t > 0; t--) {
                        const e = r[t];
                        s -= e.widgetConfig && e.widgetConfig.margin || 1
                    }
                    for (let t = r.length; t--;) {
                        const e = r[t],
                            n = e.element("header");
                        n && (void 0 === i && (i = (0, L.outerHeight)(n, !0)), s -= i, a += e.heightRatio)
                    }
                    const h = s / a;
                    this._recalculateWidgetsHeightRatio(h);
                    const d = r.length - 1;
                    for (let t = 0; t <= d; t++) {
                        const e = r[t];
                        let i;
                        i = t === d ? s : Math.round(h * e.heightRatio), i = Math.max(i, e.minHeight), e.setHeight(i), s -= i
                    }
                }
                handleWidgetResizeStart(t, e) {
                    let i, s;
                    for (let e = this.widgets.length - 1; e > 0; e--) this.widgets[e] === t && (i = this.widgets[e], s = this.widgets[e - 1]);
                    (0, n.assert)(void 0 !== i), (0, n.assert)(void 0 !== s);
                    const a = s.rdState().bridge().height.value(),
                        r = s.heightRatio + i.heightRatio,
                        o = a + i.rdState().bridge().height.value();
                    0 === o && e.preventDefault(), this._resizeOperations.set(t, {
                        bottomWidget: i,
                        topWidget: s,
                        summaryHeight: o,
                        summaryRatio: r,
                        startTopWidgetHeight: a,
                        prevTopWidgetHeight: void 0
                    })
                }
                handleWidgetResizeChange(t, e) {
                    var i;
                    const s = this._resizeOperations.get(t);
                    if (void 0 === s) return;
                    null === (i = this._page) || void 0 === i || i.classList.add("widget-resize-mode");
                    const {
                        current: n,
                        initial: a
                    } = e.detail, r = n.pageY - a.pageY, o = Math.max(s.topWidget.minHeight, Math.min(s.startTopWidgetHeight + r, s.summaryHeight - s.bottomWidget.minHeight));
                    s.prevTopWidgetHeight !== o && (s.prevTopWidgetHeight = o, s.topWidget.heightRatio = o / s.summaryHeight * s.summaryRatio, s.bottomWidget.heightRatio = s.summaryRatio - s.topWidget.heightRatio, s.topWidget.setHeight(o), s.bottomWidget.setHeight(s.summaryHeight - o))
                }
                handleWidgetResizeStop(t, e) {
                    var i;
                    const s = this._resizeOperations.get(t);
                    void 0 !== s && (this._resizeOperations.delete(t), null === (i = this._page) || void 0 === i || i.classList.remove("widget-resize-mode"), s.prevTopWidgetHeight !== s.startTopWidgetHeight && (this.normalizeRatios(), this.widgetBarLayout && this.widgetBarLayout.widgetBar && this.widgetBarLayout.widgetBar.saveToTVSettings()))
                }
                normalizeRatios() {
                    let t = 1 / 0;
                    for (let e = this.widgets.length; e--;) {
                        const i = this.widgets[e].heightRatio;
                        i <= 0 || !isFinite(i) || i < t && (t = i)
                    }
                    if (!isFinite(t)) return;
                    let e = 1;
                    for (; t < 1;) t *= 2, e *= 2;
                    for (; t >= 2;) t /= 2, e /= 2;
                    for (let t = this.widgets.length; t--;) this.widgets[t].heightRatio *= e
                }
                attachWidget(t, e) {
                    var i;
                    e = Number(e);
                    const s = this.widgets.indexOf(t); - 1 !== s ? this.widgets.splice(s, 1) : t.widgetBarPage && t.widgetBarPage !== this && t.widgetBarPage.removeWidget(t), e < this.widgets.length ? e < 0 && (e = 0) : e = this.widgets.length, delete t.widgetBarPage, Object.defineProperty(t, "widgetBarPage", {
                        value: this,
                        configurable: !0
                    }), this.widgets.splice(e, 0, t);
                    const n = this.widgets[e + 1],
                        a = t.element("widget");
                    n ? a && a.insertAdjacentElement("beforebegin", n.element("widget")) : a && (null === (i = this._page) || void 0 === i || i.appendChild(a)), this.updateWidgetsHeight(), t.updateVisibleWatchedValue()
                }
                removeWidget(t) {
                    var e;
                    const i = this.widgets.indexOf(t); - 1 !== i && (delete t.widgetBarPage, this.widgets.splice(i, 1), null === (e = t.element("widget")) || void 0 === e || e.remove(), this.updateWidgetsHeight())
                }
                remove() {
                    this.widgetBarLayout && this.widgetBarLayout.removePage(this)
                }
                destroy() {
                    var t;
                    this.remove(), null === (t = this._page) || void 0 === t || t.remove()
                }
                onVisibilityChange(t) {
                    const e = t && this.widgetBarLayout && this.widgetBarLayout.getActivePage() === this;
                    this.widgets.forEach(t => {
                        const i = t.getWidgetBarOption("widgetConfig")[t.type];
                        e && !i.doNotClearNotificationsOnVisibilityChange && t.clearNotifications(), t.onVisibilityChange()
                    })
                }
                notify(t, e = {}) {
                    !0 !== e.clear ? e.stopHighlightTab || (this.notificationCounter = this.notificationCounter + (~~t || 1), this.updateNotifications(e.notificationValue)) : this.clearNotifications()
                }
                clearNotifications() {
                    this.notificationCounter = 0, (0, n.ensure)(this.tab).updateNotifications(this.notificationCounter)
                }
                updateNotifications(t) {
                    const e = "number" == typeof t ? t : this.notificationCounter;
                    (0, n.ensure)(this.tab).updateNotifications(e)
                }
                getWidgets(t) {
                    const e = [];
                    for (let i = 0; i < this.widgets.length; ++i) {
                        const s = this.widgets[i];
                        s.type === t && e.push(s)
                    }
                    return e
                }
                isActiveAndVisible() {
                    const t = this.widgetBarLayout;
                    return !(!t || !t.visible) && t.getActivePage() === this
                }
                createHTML() {
                    const t = this._page = document.createElement("div");
                    t.classList.value = "widgetbar-page", this.widgets.forEach(e => {
                        e.createHTML();
                        const i = e.element("widget");
                        i && t.appendChild(i)
                    })
                }
                createTabButtonViewModel() {
                    this.tab = new u({
                        icon: w[this.icon],
                        hint: this.title,
                        onClick: t => {
                            this.widgetBarLayout && this.widgetBarLayout.onTabClick(t, this)
                        },
                        TabButtonComponent: this.TabButtonComponent
                    })
                }
                demarshal(t) {
                    if ("string" == typeof t) try {
                        t = JSON.parse(t)
                    } catch (t) {}
                    if ("object" != typeof t || !t.widgets || !Array.isArray(t.widgets)) return null;
                    const e = this.widgets;
                    return e.splice(0, e.length), this._gaEvent = t._gaEvent, this.title = t.title, this.name = t.name, this.icon = t.icon, this.spaceBottom = t.spaceBottom, this.spaceBottomText = t.spaceBottomText, this.onBottom = t.onBottom, this.TabButtonComponent = t.TabButtonComponent, this.createTabButtonViewModel(), t.widgets.forEach(t => {
                        const i = new z({
                            widgetBarPage: this
                        }).demarshal(t);
                        i && e.push(i)
                    }), 0 === e.length ? null : this
                }
                marshal() {
                    const t = [];
                    return this.widgets.forEach(e => {
                        const i = e.marshal();
                        i && t.push(i)
                    }), 0 === t.length ? null : t
                }
                _recalculateWidgetsHeightRatio(t) {
                    const e = this.widgets;
                    e.length <= 1 || e.forEach((i, s) => {
                        if (t * i.heightRatio >= i.minHeight) return;
                        let n = i.minHeight / t - i.heightRatio;
                        for (let i = 0; i < e.length; i++) {
                            if (i === s) continue;
                            const a = e[i],
                                r = a.heightRatio - a.minHeight / t;
                            if (!(r <= 0) && (a.heightRatio -= Math.min(n, r), e[s].heightRatio += Math.min(n, r), n -= r, n <= 0)) break
                        }
                    })
                }
            }
            var A = i(19036),
                V = i(72535),
                k = i(72571),
                D = i(58191),
                R = i(91046);

            function j(t) {
                const e = b(t.className, D.button, t.isGrayed && D.isGrayed);
                return o.createElement("div", {
                    className: e,
                    onClick: t.onClick,
                    "data-role": "button",
                    "data-name": t.name
                }, o.createElement(k.Icon, {
                    className: D.icon,
                    icon: R
                }))
            }
            var F = i(81814),
                q = i(17982);

            function G(t) {
                t = {
                    isTab: !0,
                    theme: q,
                    ...t
                };
                const {
                    NotificationComponent: e = U
                } = t, i = b(t.className, t.theme.button, t.isTab && t.theme.isTab, t.isActive && t.theme.isActive, t.isGrayed && t.theme.isGrayed, t.hint && "apply-common-tooltip common-tooltip-vertical");
                return o.createElement("div", {
                    className: i,
                    title: t.hint,
                    onClick: t.onClick,
                    ref: t.reference,
                    "data-role": "button",
                    "data-name": t.name
                }, o.createElement("div", {
                    className: t.theme.hoverMask
                }), o.createElement(k.Icon, {
                    icon: t.icon
                }), o.createElement("div", {
                    className: t.theme.counterRow
                }, o.createElement(e, {
                    className: t.theme.counter,
                    count: t.count,
                    "data-name": "counter"
                })))
            }

            function U(t) {
                return o.createElement("span", {
                    className: t.className,
                    "data-name": "counter"
                }, t.count && 0 !== t.count ? t.count.toString() : void 0)
            }
            var Y = i(37076),
                K = i(23404),
                J = i(95387);
            const X = (0, a.t)("DOM"),
                Z = (0, K.registryContextType)();
            class $ extends o.PureComponent {
                constructor(t, e) {
                    super(t, e), this._handleClick = () => {
                        const {
                            setDomPanelVisibility: t
                        } = (0, n.ensure)(this.context.widgetBar.tradingPanelAccessor);
                        t(!this.state.isActive)
                    }, this._handleIsOpenedChange = () => {
                        this.setState({
                            isActive: this._tradingPanel.isPageOpened(Y.TradingPage.DomPanel)
                        })
                    }, this._handleActivePageChange = t => {
                        this._tradingPanel.isOpened.value() && this.setState({
                            isActive: t === Y.TradingPage.DomPanel
                        })
                    }, (0, K.validateRegistry)(e, {
                        widgetBar: A.any.isRequired
                    }), this._tradingPanel = (0, n.ensure)(this.context.widgetBar.tradingPanelAccessor).tradingPanel, this.state = {
                        isActive: this._tradingPanel.isPageOpened(Y.TradingPage.DomPanel)
                    }
                }
                componentDidMount() {
                    this._tradingPanel.isOpened.subscribe(this._handleIsOpenedChange), this._tradingPanel.activePage.subscribe(this._handleActivePageChange)
                }
                componentWillUnmount() {
                    this._tradingPanel.isOpened.unsubscribe(this._handleIsOpenedChange), this._tradingPanel.activePage.unsubscribe(this._handleActivePageChange)
                }
                render() {
                    return o.createElement(G, { ...this.props,
                        icon: J,
                        hint: X,
                        isActive: this.state.isActive,
                        onClick: this._handleClick
                    })
                }
            }
            $.contextType = Z;
            var Q = i(42353);
            const tt = (0, a.t)("Order Panel"),
                et = (0, K.registryContextType)();
            class it extends o.PureComponent {
                constructor(t, e) {
                    super(t, e), this._handleClick = () => {
                        const {
                            setOrderPanelVisibility: t
                        } = (0, n.ensure)(this.context.widgetBar.tradingPanelAccessor), e = !this.state.isActive;
                        t(e), e && (0, E.trackEvent)("GUI", "Open Order Panel")
                    }, this._handleIsOpenedChange = () => {
                        this.setState({
                            isActive: this._tradingPanel.isPageOpened(Y.TradingPage.OrderPanel)
                        })
                    }, this._handleActivePageChange = t => {
                        this._tradingPanel.isOpened.value() && this.setState({
                            isActive: t === Y.TradingPage.OrderPanel
                        })
                    }, (0, K.validateRegistry)(e, {
                        widgetBar: A.any.isRequired
                    }), this._tradingPanel = (0, n.ensure)(this.context.widgetBar.tradingPanelAccessor).tradingPanel, this.state = {
                        isActive: this._tradingPanel.isPageOpened(Y.TradingPage.OrderPanel)
                    }
                }
                componentDidMount() {
                    this._tradingPanel.isOpened.subscribe(this._handleIsOpenedChange), this._tradingPanel.activePage.subscribe(this._handleActivePageChange)
                }
                componentWillUnmount() {
                    this._tradingPanel.isOpened.unsubscribe(this._handleIsOpenedChange), this._tradingPanel.activePage.unsubscribe(this._handleActivePageChange)
                }
                render() {
                    return o.createElement(G, { ...this.props,
                        icon: Q,
                        hint: tt,
                        isActive: this.state.isActive,
                        onClick: this._handleClick
                    })
                }
            }
            it.contextType = et;
            var st = i(73878);

            function nt(t) {
                return o.createElement("div", {
                    className: b(t.className, st.separator)
                })
            }
            var at = i(29954);

            function rt(t) {
                return o.createElement("div", {
                    className: b(at.filler, t.className)
                })
            }

            function ot(t, e) {
                return class extends o.PureComponent {
                    constructor(t) {
                        super(t), this._bindedForceUpdate = () => this.forceUpdate(), this.state = {
                            viewModel: e
                        }
                    }
                    componentDidMount() {
                        const {
                            viewModel: t
                        } = this.state;
                        t.notificationsCount.subscribe(this._bindedForceUpdate), t.isActive.subscribe(this._bindedForceUpdate)
                    }
                    componentWillUnmount() {
                        const {
                            viewModel: t
                        } = this.state;
                        t.notificationsCount.unsubscribe(this._bindedForceUpdate), t.isActive.unsubscribe(this._bindedForceUpdate)
                    }
                    render() {
                        const {
                            viewModel: e
                        } = this.state, i = e.notificationsCount.value();
                        return o.createElement(t, { ...this.props,
                            icon: e.icon.value(),
                            isActive: e.isActive.value(),
                            onClick: e.onClick.value(),
                            hint: e.hint.value(),
                            count: i
                        })
                    }
                }
            }
            var lt = i(12777),
                ht = i(51951),
                dt = i(21258),
                ct = i(59542);
            const ut = (0, ht.getLogger)("Platform.GUI.RightToolbar"),
                gt = (0, K.registryContextType)();
            class pt extends o.PureComponent {
                constructor(t, e) {
                    super(t, e), this._pages = {}, this._isTradingPanelVisible = null, this._tradingActivePage = null, this._isTradingPanelOpened = null, this._handleMouseOver = t => {
                        (0, dt.hoverMouseEventFilter)(t) && this.setState({
                            isHovered: !0
                        })
                    }, this._handleMouseOut = t => {
                        (0, dt.hoverMouseEventFilter)(t) && this.setState({
                            isHovered: !1
                        })
                    }, this._handleFullscreenChange = t => {
                        this.setState({
                            isFullscreen: t
                        })
                    }, this._handleCloseClick = () => {
                        const {
                            widgetBar: t
                        } = this.context;
                        (0, n.ensureDefined)(t.layout).setMinimizedState(!0)
                    }, this._handleGrayedChange = () => {
                        this.setState({
                            isGrayed: this._isGrayed()
                        })
                    }, this._handleDomButtonVisibilityChange = t => {
                        this.setState({
                            isTradingButtonsVisible: t
                        })
                    }, this._isGrayed = () => {
                        let t = this._isMinimized.value();
                        return null !== this._isTradingPanelOpened && (t = t && !this._isTradingPanelOpened.value()), !t
                    }, (0, K.validateRegistry)(e, {
                        widgetBar: A.any.isRequired
                    });
                    const {
                        widgetBar: i
                    } = this.context;
                    if (this._isMinimized = (0, n.ensureDefined)(i.layout).isMinimized.spawn(), this._isFullscreen = i.resizerBridge.fullscreen.spawn(), i.tradingPanelAccessor) {
                        const t = i.tradingPanelAccessor.tradingPanel;
                        this._isTradingPanelVisible = t.isVisible.spawn(), this._tradingActivePage = t.activePage.spawn(), this._isTradingPanelOpened = t.isOpened.spawn()
                    }
                    this.state = {
                        isHovered: !1,
                        isGrayed: this._isGrayed(),
                        isFullscreen: this._isFullscreen.value(),
                        isTradingButtonsVisible: !1
                    }, null !== this._isTradingPanelVisible && (this.state = { ...this.state,
                        isTradingButtonsVisible: this._isTradingPanelVisible.value()
                    }), (0, n.ensureDefined)(i.layout).pages.forEach(t => {
                        var e;
                        void 0 === t.name && ut.logWarn('Page does not provide required field "name"');
                        const i = t.tab;
                        this._pages[t.name] = ot(null !== (e = i.TabButtonComponent) && void 0 !== e ? e : G, i)
                    }), this._toolset = this._createToolset()
                }
                componentDidMount() {
                    this._isFullscreen.subscribe(this._handleFullscreenChange), this._isMinimized.subscribe(this._handleGrayedChange), null !== this._isTradingPanelVisible && this._isTradingPanelVisible.subscribe(this._handleDomButtonVisibilityChange), null !== this._isTradingPanelOpened && this._isTradingPanelOpened.subscribe(this._handleGrayedChange)
                }
                componentWillUnmount() {
                    this._isFullscreen.destroy(), this._isMinimized.destroy(), null !== this._isTradingPanelVisible && this._isTradingPanelVisible.destroy(),
                        null !== this._tradingActivePage && this._tradingActivePage.destroy(), null !== this._isTradingPanelOpened && this._isTradingPanelOpened.destroy()
                }
                render() {
                    const {
                        className: t,
                        isDomButtonAvailable: e,
                        isOrderPanelButtonAvailable: i
                    } = this.props, {
                        isHovered: s,
                        isGrayed: n,
                        isFullscreen: a,
                        isTradingButtonsVisible: r
                    } = this.state, {
                        widgetBar: l
                    } = this.context, h = this._toolset, d = i && r, c = e && r;
                    return o.createElement(F.VerticalScroll, {
                        isVisibleFade: V.mobiletouch,
                        isVisibleButtons: !V.mobiletouch && s,
                        isVisibleScrollbar: !1,
                        onMouseOver: this._handleMouseOver,
                        onMouseOut: this._handleMouseOut
                    }, o.createElement("div", {
                        className: b(t, ct.toolbar, n && ct.isGrayed),
                        "data-name": "right-toolbar",
                        onContextMenu: lt.preventDefault
                    }, l.adaptive && a && o.createElement(j, {
                        name: "close-button",
                        onClick: this._handleCloseClick
                    }), this._renderPages(), (d || c) && o.createElement(nt, null), d && o.createElement(it, {
                        name: "order-panel-button",
                        isGrayed: n
                    }), c && o.createElement($, {
                        name: "dom-button",
                        isGrayed: n
                    }), o.createElement(rt, null), this._renderPages(!0), h.SupportTicketButton && o.createElement(h.SupportTicketButton, {
                        name: "bug-report-button",
                        isGrayed: n,
                        isTab: !1
                    }), h.HelpButton && o.createElement(h.HelpButton, {
                        name: "help-button",
                        isGrayed: n,
                        isTab: !1
                    })))
                }
                _renderPages(t) {
                    const e = [],
                        {
                            isGrayed: i
                        } = this.state,
                        {
                            widgetBar: s
                        } = this.context,
                        {
                            pages: a
                        } = (0, n.ensureDefined)(s.layout);
                    return a.forEach(s => {
                        const n = s.name;
                        if (n in this._pages && Boolean(s.onBottom) === Boolean(t)) {
                            const t = this._pages[n];
                            e.push(o.createElement(t, {
                                name: n,
                                isGrayed: i,
                                key: n
                            })), s.spaceBottom && e.push(o.createElement(nt, {
                                key: s.spaceBottomText
                            }))
                        }
                    }), e
                }
                _createToolset() {
                    const {
                        widgetBar: t
                    } = this.context;
                    return {
                        SupportTicketButton: this.props.isSupportTicketButtonAvailable ? ot(G, t.ensureSupportTicketButtonViewModel()) : void 0,
                        HelpButton: this.props.isHelpButtonAvailable ? ot(G, t.ensureHelpButtonViewModel()) : void 0
                    }
                }
            }
            pt.contextType = gt;
            const mt = {
                widgetBar: A.any
            };
            class _t extends o.PureComponent {
                constructor(t) {
                    super(t), this._registry = {
                        widgetBar: this.props.widgetBar
                    }
                }
                render() {
                    return o.createElement(K.RegistryProvider, {
                        validation: mt,
                        value: this._registry
                    }, this.props.children)
                }
            }
            class vt {
                constructor(t, e, i) {
                    this._widgetBar = t, this._container = e, this._options = i, this._render()
                }
                updateOptions(t) {
                    this._options = t, this._render()
                }
                destroy() {
                    l.unmountComponentAtNode(this._container)
                }
                _render() {
                    l.render(o.createElement(_t, {
                        widgetBar: this._widgetBar
                    }, o.createElement(pt, {
                        isDomButtonAvailable: this._options.isDomButtonAvailable,
                        isOrderPanelButtonAvailable: this._options.isOrderPanelButtonAvailable,
                        isHelpButtonAvailable: this._options.isHelpButtonAvailable,
                        isSupportTicketButtonAvailable: this._options.isSupportTicketButtonAvailable
                    })), this._container)
                }
            }
            var ft = i(93599);
            const wt = (0, a.t)("Hide Tab"),
                bt = (0, a.t)("Open Tab");

            function yt(t) {
                const e = b(t.className, "apply-common-tooltip", "common-tooltip-vertical", "common-tooltip-otl");
                return o.createElement("div", {
                    className: e,
                    onClick: t.onClick,
                    title: t.isMinimized ? bt : wt
                }, o.createElement(ft.VerticalToolbarHider, {
                    direction: t.isMinimized ? "left" : "right"
                }))
            }
            var Ct = i(82527);
            class St {
                constructor(t = {}) {
                    this.MIN_WIDTH = 200, this.MINIMIZE_THRESHOLD = 50,
                        this.activeIndex = St.activeIndex, this.activeName = St.activeName, this.minimized = St.minimized, this.visible = St.visible, this.width = St.width, this.version = St.version, this.pages = [], this.isMinimized = new(d()), this.activePageIndex = new(d())(this.activeIndex), this.tabRenderer = null, this._tabs = null, this._pages = null, this._pagescontent = null, this._handle = null, this._deviceButton = null, this._hider = null, this._draggable = null, this._rightToolbarOptions = {
                            isDomButtonAvailable: Ct.enabled("dome_widget") || Ct.enabled("dom_widget"),
                            isOrderPanelButtonAvailable: Ct.enabled("order_panel"),
                            isSupportTicketButtonAvailable: Ct.enabled("bugreport_button"),
                            isHelpButtonAvailable: !Ct.enabled("widget") && !Ct.enabled("charting_library_base")
                        }, this.widgetBar = t.widgetBar, this._rightToolbar = Boolean(t.rightToolbar)
                }
                element(t) {
                    switch (t) {
                        case "tabs":
                            return this._tabs;
                        case "pages":
                            return this._pages;
                        case "pages-content":
                            return this._pagescontent;
                        case "handle":
                            return this._handle;
                        case "device-button":
                            return this._deviceButton;
                        case "hider":
                            return this._hider;
                        default:
                            return null
                    }
                }
                widget(t) {
                    for (const e of this.pages) {
                        const i = e.widget(t);
                        if (i) return i
                    }
                    return null
                }
                startWidgets() {
                    this.pages.forEach(t => {
                        t.widgets.forEach(t => {
                            t.widgetObject || t.widgetStartDelayed || setTimeout(() => {
                                t.startWidget()
                            }, 0)
                        })
                    });
                    const t = this.getActivePage();
                    t && t.onActiveStateChange(!0)
                }
                syncHeight() {
                    const t = (0, n.ensureDefined)(this.widgetBar).resizerBridge.height.value();
                    if (null !== this._pages && (this._pages.style.height = t + "px"), !this.minimized) {
                        const t = this.getActivePage();
                        t && t.updateWidgetsHeight()
                    }
                }
                tabsWidth() {
                    return this._rightToolbar ? 46 : this.minimized ? 5 : 0
                }
                borderWidth() {
                    return 1
                }
                canOpen() {
                    return this.MIN_WIDTH + this.tabsWidth() + this.borderWidth() <= (0, n.ensureDefined)(this.widgetBar).resizerBridge.availWidth.value()
                }
                requestWidth(t) {
                    const e = (0, n.ensureDefined)(this.widgetBar).resizerBridge;
                    t > 0 && (t += this.borderWidth());
                    const i = this.tabsWidth(),
                        s = t + i;
                    this.canOpen() ? e.width.value() !== s && e.negotiateWidth([{
                        min: i,
                        max: i
                    }, {
                        min: this.MIN_WIDTH + i,
                        max: s
                    }]) : e.negotiateWidth(0)
                }
                requestOptimalWidth() {
                    this.minimized ? this.requestWidth(0) : this.requestWidth(this.width)
                }
                updateResponsiveness() {
                    var t, e;
                    const i = !this.canOpen();
                    null === (t = this._tabs) || void 0 === t || t.classList.toggle("js-hidden", i), null === (e = this._pages) || void 0 === e || e.classList.toggle("js-hidden", i)
                }
                syncWidth() {
                    const t = (0, n.ensureDefined)(this.widgetBar).resizerBridge,
                        e = this.tabsWidth(),
                        i = this.borderWidth(),
                        s = t.width.value(),
                        a = Math.max(s - e - i, 0) || 0;
                    a < this.MINIMIZE_THRESHOLD ? this.setMinimizedState(!0) : this.setMinimizedState(!1);
                    const r = this._pages;
                    if (r && (r.style.width = a + "px", r.classList.toggle("hidden", !!this.minimized)), !this.minimized) {
                        const t = this.getActivePage();
                        t && t.widgets.forEach(t => {
                            t.onWidthChange(a)
                        }), this.widgetBar && this.widgetBar.loadWidgets()
                    }
                    const o = !this.canOpen();
                    this._deviceButton && this._deviceButton.classList.toggle("js-hidden", !o || !this.minimized)
                }
                setMinimizedState(t) {
                    const e = Boolean(t);
                    !!this.minimized !== e && (this.minimized = e, this.isMinimized.setValue(this.minimized), e && (0, n.ensureDefined)(this.widgetBar).resizerBridge.exitFullscreen(),
                        this.requestOptimalWidth(), this.activeIndex >= 0 && this.pages[this.activeIndex].onActiveStateChange(!this.minimized))
                }
                switchPage(t) {
                    if (-1 === t || 0 === this.pages.length) return this.activeIndex = -1, void this.activePageIndex.setValue(this.activeIndex);
                    let e;
                    if (t instanceof N) {
                        if (e = this.pages.indexOf(t), -1 === e) return
                    } else e = +t;
                    const i = this.pages[this.activeIndex];
                    this.activeIndex = Math.min(this.pages.length - 1, Math.max(0, e)), this.activePageIndex.setValue(this.activeIndex);
                    const s = this.pages[this.activeIndex];
                    this.activeName = s.name || "", this.minimized || i && i === s || (i && i.onActiveStateChange(!1), s && s.onActiveStateChange(!0))
                }
                getActivePage() {
                    return this.minimized ? null : this.pages[this.activeIndex] || null
                }
                getWidgetByType(t) {
                    var e;
                    const i = null === (e = this.getActivePage()) || void 0 === e ? void 0 : e.widgets;
                    if (i) return i.find(e => e.type === t)
                }
                onTabClick(t, e) {
                    if (t.isDefaultPrevented()) return;
                    const i = this.pages.indexOf(e);
                    if (-1 !== i) {
                        if (t.preventDefault(), this._trackClick(e.name), i !== this.activeIndex || this.minimized) {
                            const t = e.gaEvent();
                            t && (0, E.trackEvent)("Platform Widgets", t), this.switchPage(i), this.minimized && this.setMinimizedState(!1)
                        } else this.setMinimizedState(!0);
                        this.widgetBar && this.widgetBar.saveToTVSettings()
                    }
                }
                removePage(t) {
                    const e = this.pages.indexOf(t);
                    if (-1 === e) return;
                    delete t.widgetBarLayout, this.pages.splice(e, 1);
                    const i = t.element();
                    null == i || i.remove(), this.activeIndex === e && this.switchPage(e - 1)
                }
                createPage() {
                    var t;
                    const e = new N({
                        widgetBarLayout: this
                    });
                    this.pages.push(e), e.createHTML();
                    const i = (0, n.ensureNotNull)(e.element());
                    return null === (t = this._pagescontent) || void 0 === t || t.append(i), e
                }
                createWidget(t, e) {
                    if (e) {
                        if (-1 === this.pages.indexOf(e)) return null
                    } else e = this.createPage();
                    const i = new z({
                        widgetBarPage: e
                    });
                    return i.demarshal({
                        type: t
                    }), i.createHTML(), e.attachWidget(i), i
                }
                onVisibilityChange() {
                    const t = !(!this.widgetBar || !this.widgetBar.resizerBridge.visible.value());
                    this.visible = t, this.pages.forEach(e => {
                        e.onVisibilityChange(t)
                    })
                }
                destroy() {
                    var t, e, i, s, n, a;
                    this.widgetBar && this.widgetBar.layout === this && delete this.widgetBar.layout, this.tabRenderer && (this.tabRenderer.destroy(), this.tabRenderer = null), this._hider && l.unmountComponentAtNode(this._hider);
                    for (let t = this.pages.length; t--;) {
                        const e = this.pages[t];
                        for (let t = e.widgets.length; t--;) e.widgets[t].destroy()
                    }
                    null === (t = this._tabs) || void 0 === t || t.remove(), null === (e = this._pages) || void 0 === e || e.remove(), null === (i = this._pagescontent) || void 0 === i || i.remove(), null === (s = this._handle) || void 0 === s || s.remove(), null === (n = this._deviceButton) || void 0 === n || n.remove(), null === (a = this._hider) || void 0 === a || a.remove()
                }
                updateRightToolbar() {
                    var t;
                    null === (t = this.tabRenderer) || void 0 === t || t.updateOptions(this._rightToolbarOptions)
                }
                createHTML() {
                    const t = (0, n.ensureDefined)(this.widgetBar);
                    if (this._rightToolbar) {
                        const e = this._tabs = document.createElement("div");
                        e.classList.value = "widgetbar-tabs", this.tabRenderer && (this.tabRenderer.destroy(), this.tabRenderer = null), this.tabRenderer = new vt(t, e, this._rightToolbarOptions)
                    }
                    const e = this._pages = document.createElement("div");
                    e.classList.value = "widgetbar-pages";
                    const i = this._pagescontent = document.createElement("div");
                    i.classList.value = "widgetbar-pagescontent", e.appendChild(i), this._rightToolbar || (this._pages.style.right = "-1px");
                    const s = this._handle = document.createElement("div");
                    if (s.classList.value = "widgetbar-handle", e.appendChild(s), s.addEventListener("contextmenu", t => {
                            t.target === s && t.preventDefault()
                        }), this._createDraggable(s), t.showCloseButton) {
                        const t = this._hider = document.createElement("div");
                        t.classList.value = "widgetbar-hider";
                        const e = () => {
                            t.classList.toggle("widgetbar-hider--closed", this.isMinimized.value()), t.classList.toggle("js-hidden", this._rightToolbar && this.isMinimized.value()), l.render(o.createElement(yt, {
                                isMinimized: this.isMinimized.value(),
                                onClick: () => {
                                    this.setMinimizedState(!this.minimized)
                                }
                            }), t)
                        };
                        this.isMinimized.subscribe(e), e()
                    }
                    this.pages.forEach(t => {
                        t.createHTML();
                        const e = t.element();
                        e && i.appendChild(e)
                    })
                }
                demarshal(t) {
                    if ("string" == typeof t) try {
                        t = JSON.parse(t)
                    } catch (t) {}
                    if ("object" != typeof t) return null;
                    this.width = Number(t.width), !isFinite(this.width) || this.width <= 0 ? this.width = St.width : this.width < this.MIN_WIDTH && (this.width = this.MIN_WIDTH), "minimized" in t ? (this.minimized = Boolean(t.minimized), this.isMinimized.setValue(this.minimized)) : (this.minimized = St.minimized, this.isMinimized.setValue(this.minimized)), "version" in t && (this.version = t.version);
                    let e = Number(t.activeIndex);
                    const i = t.activeName;
                    let s = !1;
                    const n = this.pages;
                    return n.splice(0, this.pages.length), Array.isArray(t.pages) && t.pages.forEach((t, a) => {
                        const r = new N({
                            widgetBarLayout: this
                        }).demarshal(t);
                        i ? t.name === i && r && (e = a, s = !0) : r || a !== e || e--, r && n.push(r)
                    }), i && !s && (e = 0), 0 === n.length ? (this.activeIndex = -1, this.activePageIndex.setValue(this.activeIndex)) : e >= 0 && e < n.length && (this.activeIndex = e, this.activePageIndex.setValue(this.activeIndex)), this
                }
                marshal() {
                    let t = [];
                    this.pages.forEach(e => {
                        const i = e.marshal();
                        i && (t = t.concat(i))
                    });
                    const e = {};
                    for (let i = 0; i < t.length; i++) {
                        const s = t[i].type;
                        s && (t[i].id && delete t[i].type, e[s] ? e[s].push(t[i]) : e[s] = [t[i]])
                    }
                    const i = {
                        widgets: e,
                        settings: {}
                    };
                    return this.minimized !== St.minimized && (i.settings.minimized = this.minimized), this.width !== St.width && (i.settings.width = this.width), this.activeIndex !== St.activeIndex && (i.settings.activeIndex = this.activeIndex), this.activeName !== St.activeName && (i.settings.activeName = this.activeName), this.version !== St.version && (i.settings.version = this.version), i
                }
                _createDraggable(t) {
                    null !== this._draggable && this._draggable.destroy();
                    const e = {
                        initialWidth: 0
                    };
                    this._draggable = new I.PointerBackend({
                        handle: t,
                        onDragStart: t => {
                            this.widgetBar ? e.initialWidth = Math.max(this.widgetBar.resizerBridge.width.value() - this.tabsWidth() - this.borderWidth(), 0) : t.preventDefault()
                        },
                        onDragMove: t => {
                            const {
                                current: i,
                                initial: s
                            } = t.detail, n = i.pageX - s.pageX;
                            let a = e.initialWidth - n;
                            a < this.MINIMIZE_THRESHOLD ? a = 0 : a < this.MIN_WIDTH && (a = this.MIN_WIDTH), a > 0 && (this.width = a), this.requestWidth(a)
                        },
                        onDragStop: t => {
                            this.widgetBar && this.widgetBar.saveToTVSettings()
                        }
                    })
                }
                _trackClick(t) {
                    0
                }
            }
            St.width = 290, St.minimized = !Ct.enabled("show_right_widgets_panel_by_default"), St.activeIndex = 0, St.activeName = "",
                St.visible = !0, St.version = void 0;
            var Tt = i(47465),
                Bt = i(33080),
                xt = i(35354),
                Et = i(47152),
                Pt = i(5775),
                Wt = i(86126);
            const Mt = Ct.enabled("right_toolbar"),
                Lt = Ct.enabled("keep_object_tree_widget_in_right_toolbar"),
                Ht = Ct.enabled("show_object_tree");
            class Ot {
                constructor(t) {
                    this._wrap = null, this._tradingServiceCancelable = null, this.options = t, this._load = () => {};
                    const e = new Promise(t => {
                            this._load = t
                        }),
                        i = this.options.configuration;
                    this._configuration = Promise.race([(0, Et.delay)(null, 5e3), e]).then(() => i()).then(t => {
                        const e = this.widgetConfig;
                        return e.reuters_calendar.ctor = t.ReutersCalendarWidget, e.earnings_calendar.ctor = t.CalendarWidget && t.CalendarWidget.Earnings, e.watchlist.ctor = t.Watchlist, e.hotlist.ctor = t.HotlistWidget, e.detail.ctor = t.Detail && t.Detail.Widget, e.news.ctor = t.NewsWidget, e.chat.ctor = t.ChatWidget, e.messages.ctor = t.Messages && t.Messages.Widget, e.messages_with_select.ctor = t.Messages && t.Messages.Widget, e.notifications_following.ctor = t.NotificationsWidgets, e.notifications_user.ctor = t.NotificationsWidgets, e.publicchats.ctor = t.PublicChatsWidget, e.publicchats_with_select.ctor = t.PublicChatsWidget, e.notes.ctor = t.NotesWidget, e.alerts_manage.ctor = t.AlertsManageWidget, e.alerts_log.ctor = t.AlertsLogWidget, e.streams.ctor = t.StreamsWidget, e.datawindow.ctor = t.DataWindowWidget, (0, n.ensure)(e.object_tree).ctor = t.ObjectTreeWidget, t
                    });
                    const a = this.resizerBridge = t.resizerBridge;
                    this.adaptive = Boolean(t.adaptive), this.tradingPanelAccessor = t.tradingPanelAccessor || null, this._visible = (0, r.combine)((t, e, i) => Boolean(t && e && i), a.width, a.height, a.visible), this.widgetConfig = (0, s.default)({}, f), t.widgetConfig && (this.widgetConfig = (0, s.default)(this.widgetConfig, t.widgetConfig)), this.layout = new St({
                        widgetBar: this,
                        rightToolbar: Mt
                    }), this._customization = t.customization || {}, t.chartWidgetCollection && (this.chartWidgetCollection = t.chartWidgetCollection), t.state ? this.layout.demarshal(t.state) : t.settingsPrefix && (this._settingsPrefix = String(t.settingsPrefix), this.loadFromTVSettings()), t.readonly && (this.readonly = !0), t.fixedMode && (this.fixedMode = !0), t.showCloseButton && (this.showCloseButton = !0), this._container = this.resizerBridge.container.value(), this.createHTML(), this.initLayout(), window.loginStateChange.subscribe(this, this.onLoginStateChange), this.resizerBridge.width.subscribe(() => {
                        var t;
                        null === (t = this.layout) || void 0 === t || t.syncWidth()
                    }), this.resizerBridge.height.subscribe(() => {
                        var t;
                        null === (t = this.layout) || void 0 === t || t.syncHeight()
                    }), this.resizerBridge.visible.subscribe(() => {
                        var t;
                        null === (t = this.layout) || void 0 === t || t.onVisibilityChange()
                    }), this.resizerBridge.availWidth.subscribe(() => {
                        var t, e;
                        null === (t = this.layout) || void 0 === t || t.requestOptimalWidth(), null === (e = this.layout) || void 0 === e || e.updateResponsiveness()
                    }), this._tradingServiceCancelable = (0, Tt.makeCancelable)((0, Bt.waitTradingService)()), this._tradingServiceCancelable.promise.then(t => {
                        this._tradingServiceCancelable = null, t.onConnectionStatusChange.subscribe(this, this._onBrokerConnectionStatusChanged)
                    })
                }
                destroy() {
                    if (null !== this._tradingServiceCancelable) this._tradingServiceCancelable.cancel(),
                        this._tradingServiceCancelable = null;
                    else {
                        (0, n.ensureNotNull)((0, Bt.tradingService)()).onConnectionStatusChange.unsubscribe(this, this._onBrokerConnectionStatusChanged)
                    }
                }
                widget(t) {
                    return this.layout ? this.layout.widget(t) : null
                }
                isVisible() {
                    const t = this.resizerBridge;
                    return Boolean(t.visible.value() && t.height.value() && t.width.value())
                }
                visible() {
                    return this._visible
                }
                initLayout() {
                    var t;
                    this.options.instantLoad && this._load(), this.layout && (this._configuration.then(() => {
                        var t;
                        null === (t = this.layout) || void 0 === t || t.startWidgets()
                    }), 0 === this.layout.pages.length && (this.layout.setMinimizedState(!0), null === (t = this.layout.element("handle")) || void 0 === t || t.classList.add("js-hidden")), this.layout.requestOptimalWidth(), this.layout.syncWidth(), this.layout.syncHeight(), this.layout.onVisibilityChange(), this.layout.updateResponsiveness())
                }
                loadWidgets() {
                    this._widgetsLoadRequested || (this._widgetsLoadRequested = !0, this._load())
                }
                onLoginStateChange(t) {
                    t || window.is_authenticated && (this.dropWidgetData(), this.refreshFromTVSettings())
                }
                dropWidgetData() {
                    for (const t in this.widgetConfig) delete(0, n.ensure)(this.widgetConfig[t]).data
                }
                refreshFromTVSettings() {
                    var t, e, i;
                    if (!this._settingsPrefix) return;
                    this.layout && this.layout.destroy(), this.layout = new St({
                        widgetBar: this,
                        rightToolbar: Mt
                    }), this.loadFromTVSettings(), this.layout.createHTML();
                    const s = this.layout.element("pages");
                    s && (null === (t = this._wrap) || void 0 === t || t.appendChild(s));
                    const n = this.layout.element("tabs");
                    n && (null === (e = this._wrap) || void 0 === e || e.appendChild(n));
                    const a = this.layout.element("hider");
                    a && (null === (i = this._wrap) || void 0 === i || i.appendChild(a)), this.initLayout()
                }
                getWidgets(t) {
                    let e = [];
                    if (!this.layout) return e;
                    for (let i = 0; i < this.layout.pages.length; ++i) e = e.concat(this.layout.pages[i].getWidgets(t));
                    return e
                }
                loadFromTVSettings() {
                    if (!this._settingsPrefix) return;
                    if (!this.layout) return;
                    let t = this.getLayoutState();
                    t = this.mergeProperties(t), this.layout.demarshal(t), this.saveToTVSettings();
                    const e = this._getSerializedStateFromSetting();
                    if (e) {
                        let t = [];
                        for (const i in e.widgets) {
                            const s = e.widgets[i];
                            t = t.concat(s.map(t => t.id))
                        }
                        const i = P.keysMask(this._settingsPrefix + ".widget.*.*");
                        i && i.forEach(e => {
                            const i = e.replace(this._settingsPrefix + ".widget.", ""); - 1 === t.indexOf(i) && 0 === e.indexOf(this._settingsPrefix + ".widget.") && ((0, E.trackEvent)("Settings debug", "loadFromTVSettings: " + e, window.user.username), P.remove(e))
                        })
                    }
                }
                mergeProperties(t) {
                    const e = this._getSerializedStateFromSetting();
                    if (!e) return t;
                    e.settings && Object.assign(t, e.settings);
                    const i = {};
                    for (let s = 0; s < t.pages.length; s++)
                        for (let n = 0; n < t.pages[s].widgets.length; n++) {
                            const a = t.pages[s].widgets[n],
                                r = i[a.type] || 0;
                            e.widgets[a.type] && e.widgets[a.type][r] && Object.assign(a, e.widgets[a.type][r]), i[a.type] = r + 1
                        }
                    return t
                }
                saveToTVSettings() {
                    if (!this._settingsPrefix) return;
                    if (!this.layout) return;
                    const t = this.layout.marshal();
                    this._setSerializedStateToSettings(t)
                }
                getWidgetProperties(t, e = 0) {
                    const i = (0, n.ensure)(this._settingsPrefix).replace(/\W/g, "\\$&") + ".widget.";
                    let s = P.keysMask(i + t + ".*");
                    return s && s.length && (s = s.sort(), s[e]) ? {
                        id: s[e].replace(i, "")
                    } : null
                }
                getGenericLayoutState(t) {
                    const e = (0, xt.getDefaultState)(),
                        i = {
                            type: "news"
                        },
                        s = [{
                            _gaEvent: "General Widget",
                            title: (0, a.t)("Watchlist, details and news"),
                            name: "base",
                            icon: "base",
                            widgets: [{
                                type: "watchlist",
                                properties: t && t.length ? {
                                    list: t
                                } : void 0
                            }, {
                                type: "detail"
                            }, { ...i,
                                isEnabled: !0
                            }]
                        }, Ct.enabled("alerts") ? {
                            _gaEvent: "Alerts",
                            title: (0, a.t)("Alerts"),
                            name: "alerts",
                            icon: "alarm-clock",
                            widgets: [{
                                type: "alerts_manage",
                                properties: {}
                            }, {
                                type: "alerts_log",
                                properties: {}
                            }]
                        } : null, null, null, {
                            _gaEvent: "Data Window",
                            title: (0, a.t)("Data Window"),
                            name: "data-window",
                            icon: "datawindow",
                            widgets: [{
                                type: "datawindow"
                            }]
                        }, {
                            _gaEvent: "Hotlists",
                            title: (0, a.t)("Hotlists"),
                            name: "hotlist",
                            icon: "hotlists",
                            widgets: [{
                                type: "hotlist",
                                properties: {
                                    group: "volume_gainers"
                                }
                            }, {
                                type: "hotlist",
                                properties: {
                                    group: "percent_change_gainers"
                                }
                            }, {
                                type: "hotlist",
                                properties: {
                                    group: "percent_change_loosers"
                                }
                            }]
                        }, {
                            _gaEvent: "Calendar",
                            title: (0, a.t)("Calendar"),
                            name: "calendar",
                            icon: "calendar",
                            widgets: [{
                                type: "reuters_calendar",
                                properties: {}
                            }, {
                                type: "earnings_calendar",
                                properties: {}
                            }]
                        }, {
                            _gaEvent: "My Ideas",
                            title: (0, a.t)("My Ideas"),
                            name: "notes",
                            icon: "notes",
                            spaceBottom: !0,
                            spaceBottomText: (0, a.t)("Social"),
                            widgets: [{
                                type: "notes"
                            }]
                        }, {
                            _gaEvent: "Public Chats",
                            title: (0, a.t)("Public Chats"),
                            name: "chats",
                            icon: "chat",
                            widgets: [{
                                type: "chat"
                            }, {
                                type: "publicchats"
                            }]
                        }, {
                            _gaEvent: "Private Chats",
                            title: (0, a.t)("Private Chats"),
                            name: "pm_chats",
                            icon: "messages",
                            widgets: [{
                                type: "messages"
                            }]
                        }, {
                            _gaEvent: "Ideas Stream",
                            title: (0, a.t)("Ideas Stream"),
                            name: "ideas_stream",
                            icon: "ideas-stream",
                            widgets: [{
                                type: "notifications_following"
                            }]
                        }, null, {
                            _gaEvent: "Notifications",
                            title: (0, a.t)("Notifications"),
                            name: "notifications",
                            icon: "notifications",
                            widgets: [{
                                type: "notifications_user"
                            }]
                        }];
                    for (let t = 0; t < s.length; t++) {
                        const i = s[t];
                        i && e.pages.push(i)
                    }
                    return e
                }
                getChartingPlatformLayoutState(t, e) {
                    const i = (0, xt.getDefaultState)();
                    if (this._customization.watchlist || this._customization.details || this._customization.news) {
                        let s = "";
                        const n = [];
                        this._customization.watchlist && (s = (0, a.t)("Watchlist"), n.push({
                            type: "watchlist",
                            id: "watchlist." + e,
                            properties: t && t.length ? {
                                list: t
                            } : void 0
                        })), this._customization.details && (s = this._customization.watchlist ? (0, a.t)("Watchlist and details") : (0, a.t)("Details"), n.push({
                            type: "detail"
                        })), this._customization.news && (s = this._customization.watchlist && this._customization.details ? (0, a.t)("Watchlist and details and news") : this._customization.watchlist ? (0, a.t)("Watchlist and news") : (0, a.t)("News"), n.push({
                            type: "news",
                            id: "news." + e
                        })), i.pages.push({
                            name: "base",
                            title: s,
                            icon: "base",
                            widgets: n
                        })
                    }
                    return this._customization.datawindow && i.pages.push({
                        title: (0, a.t)("Data Window"),
                        name: "data-window",
                        icon: "datawindow",
                        widgets: [{
                            type: "datawindow"
                        }]
                    }), (Mt || Lt && !Mt) && Ht && this.chartWidgetCollection && !this.chartWidgetCollection.readOnly() && i.pages.push({
                        title: (0, a.t)("Show Object tree"),
                        name: "object_tree",
                        icon: "object-tree",
                        onBottom: !1,
                        widgets: [{
                            type: "object_tree"
                        }]
                    }), i
                }
                getLayoutState() {
                    const t = P.getJSON("watchlist.list", []);
                    let e;
                    e = Ct.enabled("trading_terminal") ? this.getChartingPlatformLayoutState(t, "terminal") : this.getGenericLayoutState(t);
                    const i = t => !(void 0 !== t.isEnabled && !t.isEnabled) && (this.chartWidgetCollection || !(0, n.ensure)(f[t.type]).chartWidgetRequired);
                    for (let t = e.pages.length - 1; t >= 0; t--) {
                        const s = e.pages[t];
                        s.widgets = s.widgets.filter(i)
                    }
                    return e.pages = e.pages.filter(t => t.widgets && t.widgets.length), e
                }
                createWidgetId(t) {
                    return t + "." + (0, O.randomHash)()
                }
                setPage(t) {
                    if (!this.layout) return null;
                    this.layout.setMinimizedState(!1);
                    let e = this.layout.activeIndex;
                    return this.layout.pages.forEach((i, s) => {
                        i.name === t && (e = s)
                    }), this.layout.switchPage(e), this.layout.getActivePage()
                }
                ensureSupportTicketButtonViewModel() {
                    return this._supportTicketButtonViewModel || (this._supportTicketButtonViewModel = new u({
                        icon: Pt,
                        hint: (0, a.t)("Help Center"),
                        onClick: () => {
                            this._configuration.then(t => {
                                const e = t.showSupportDialog;
                                e && e()
                            }), this._load()
                        }
                    })), this._supportTicketButtonViewModel
                }
                ensureHelpButtonViewModel() {
                    if (this._helpButtonViewModel) return this._helpButtonViewModel;
                    const t = this.ensureSupportTicketButtonViewModel();
                    return this._helpButtonViewModel = new u({
                        icon: Wt,
                        hint: (0, a.t)("Help Center"),
                        onClick: t.onClick.value()
                    }), this._helpButtonViewModel
                }
                createHTML() {
                    const t = this._container;
                    if (!t) return;
                    if (!this.layout) return;
                    t.innerHTML = "", this.layout.createHTML();
                    const e = this._wrap = document.createElement("div");
                    e.classList.value = "widgetbar-wrap unselectable js-right-boundary", t.appendChild(e);
                    const i = this.layout.element("pages");
                    i && this._wrap.appendChild(i);
                    const s = this.layout.element("tabs");
                    Mt && s && this._wrap.appendChild(s);
                    const n = this.layout.element("device-button");
                    n && this._wrap.appendChild(n);
                    const a = this.layout.element("hider");
                    a && this._wrap.appendChild(a)
                }
                _getSerializedStateFromSetting() {
                    return this._settingsPrefix ? P.getJSON(this._settingsPrefix + ".layout-settings", null) : null
                }
                _setSerializedStateToSettings(t) {
                    this._settingsPrefix && P.setJSON(this._settingsPrefix + ".layout-settings", t)
                }
                _onBrokerConnectionStatusChanged() {}
            }
        },
        93599: (t, e, i) => {
            "use strict";
            i.d(e, {
                DEFAULT_VERTICAL_TOOLBAR_HIDER_THEME: () => o,
                VerticalToolbarHider: () => h
            });
            var s = i(59496),
                n = i(97754),
                a = i(12777),
                r = i(61226);
            const o = r,
                l = "http://www.w3.org/2000/svg";

            function h(t) {
                const {
                    direction: e,
                    theme: i = r
                } = t;
                return s.createElement("svg", {
                    xmlns: l,
                    width: "9",
                    height: "27",
                    viewBox: "0 0 9 27",
                    className: n(i.container, "right" === e ? i.mirror : null),
                    onContextMenu: a.preventDefault
                }, s.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, s.createElement("path", {
                    className: i.background,
                    d: "M4.5.5a4 4 0 0 1 4 4v18a4 4 0 1 1-8 0v-18a4 4 0 0 1 4-4z"
                }), s.createElement("path", {
                    className: i.arrow,
                    d: "M5.5 10l-2 3.5 2 3.5"
                })))
            }
        },
        81814: (t, e, i) => {
            "use strict";
            i.d(e, {
                VerticalScroll: () => u
            });
            var s = i(59496),
                n = i(97754),
                a = i.n(n),
                r = i(7270),
                o = i(72571),
                l = i(42609),
                h = i(85787),
                d = i(60306),
                c = i(86219);
            class u extends s.PureComponent {
                constructor(t) {
                    super(t), this._scroll = null, this._handleScrollTop = () => {
                        this.animateTo(Math.max(0, this.currentPosition() - (this.state.heightWrap - 50)))
                    }, this._handleScrollBot = () => {
                        this.animateTo(Math.min((this.state.heightContent || 0) - (this.state.heightWrap || 0), this.currentPosition() + (this.state.heightWrap - 50)))
                    }, this._handleResizeWrap = ({
                        height: t
                    }) => {
                        this.setState({
                            heightWrap: t
                        })
                    }, this._handleResizeContent = ({
                        height: t
                    }) => {
                        this.setState({
                            heightContent: t
                        })
                    }, this._handleScroll = () => {
                        const {
                            onScroll: t
                        } = this.props;
                        t && t(this.currentPosition(), this.isAtTop(), this.isAtBot()), this._checkButtonsVisibility()
                    }, this._checkButtonsVisibility = () => {
                        const {
                            isVisibleTopButton: t,
                            isVisibleBotButton: e
                        } = this.state, i = this.isAtTop(), s = this.isAtBot();
                        i || t ? i && t && this.setState({
                            isVisibleTopButton: !1
                        }) : this.setState({
                            isVisibleTopButton: !0
                        }), s || e ? s && e && this.setState({
                            isVisibleBotButton: !1
                        }) : this.setState({
                            isVisibleBotButton: !0
                        })
                    }, this.state = {
                        heightContent: 0,
                        heightWrap: 0,
                        isVisibleBotButton: !1,
                        isVisibleTopButton: !1
                    }
                }
                componentDidMount() {
                    this._checkButtonsVisibility()
                }
                componentDidUpdate(t, e) {
                    e.heightWrap === this.state.heightWrap && e.heightContent === this.state.heightContent || this._handleScroll()
                }
                currentPosition() {
                    return this._scroll ? this._scroll.scrollTop : 0
                }
                isAtTop() {
                    return this.currentPosition() <= 1
                }
                isAtBot() {
                    return this.currentPosition() + this.state.heightWrap >= this.state.heightContent - 1
                }
                animateTo(t, e = h.dur) {
                    const i = this._scroll;
                    i && (0, l.doAnimate)({
                        onStep(t, e) {
                            i.scrollTop = e
                        },
                        from: i.scrollTop,
                        to: Math.round(t),
                        easing: h.easingFunc.easeInOutCubic,
                        duration: e
                    })
                }
                render() {
                    const {
                        children: t,
                        isVisibleScrollbar: e,
                        isVisibleFade: i,
                        isVisibleButtons: n,
                        onMouseOver: l,
                        onMouseOut: h
                    } = this.props, {
                        heightContent: u,
                        heightWrap: g,
                        isVisibleBotButton: p,
                        isVisibleTopButton: m
                    } = this.state;
                    return s.createElement(r, {
                        whitelist: ["height"],
                        onMeasure: this._handleResizeWrap
                    }, s.createElement("div", {
                        className: d.wrap,
                        onMouseOver: l,
                        onMouseOut: h
                    }, s.createElement("div", {
                        className: a()(d.scrollWrap, {
                            [d.noScrollBar]: !e
                        }),
                        onScroll: this._handleScroll,
                        ref: t => this._scroll = t
                    }, s.createElement(r, {
                        onMeasure: this._handleResizeContent,
                        whitelist: ["height"]
                    }, s.createElement("div", {
                        className: d.content
                    }, t))), i && s.createElement("div", {
                        className: a()(d.fadeTop, {
                            [d.isVisible]: m && u > g
                        })
                    }), i && s.createElement("div", {
                        className: a()(d.fadeBot, {
                            [d.isVisible]: p && u > g
                        })
                    }), n && s.createElement("div", {
                        className: a()(d.scrollTop, {
                            [d.isVisible]: m && u > g
                        }),
                        onClick: this._handleScrollTop
                    }, s.createElement("div", {
                        className: d.iconWrap
                    }, s.createElement(o.Icon, {
                        icon: c,
                        className: d.icon
                    }))), n && s.createElement("div", {
                        className: a()(d.scrollBot, {
                            [d.isVisible]: p && u > g
                        }),
                        onClick: this._handleScrollBot
                    }, s.createElement("div", {
                        className: d.iconWrap
                    }, s.createElement(o.Icon, {
                        icon: c,
                        className: d.icon
                    })))))
                }
            }
            u.defaultProps = {
                isVisibleScrollbar: !0
            }
        },
        23404: (t, e, i) => {
            "use strict";
            i.d(e, {
                validateRegistry: () => o,
                RegistryProvider: () => l,
                registryContextType: () => h
            });
            var s = i(59496),
                n = i(19036),
                a = i.n(n);
            const r = s.createContext({});

            function o(t, e) {
                a().checkPropTypes(e, t, "context", "RegistryContext")
            }

            function l(t) {
                const {
                    validation: e,
                    value: i
                } = t;
                return o(i, e), s.createElement(r.Provider, {
                    value: i
                }, t.children)
            }

            function h() {
                return r
            }
        },
        58884: (t, e, i) => {
            "use strict";
            async function s(t, e, i) {
                let s;
                for (let n = 0; n < e; ++n) try {
                    return await t(s)
                } catch (t) {
                    s = t, await i(n)
                }
                throw s
            }
            async function n(t, e) {
                return s(t, e, () => Promise.resolve())
            }
            i.d(e, {
                getAllSourcesIcons: () => c,
                loadAllSourcesIcons: () => d
            });
            const a = (0, i(51951).getLogger)("DataSourcesIcons");
            let r = null;

            function o() {
                const t = i.c[26872];
                return t ? Promise.resolve(t.exports.lineToolsIcons) : i.e(1890).then(i.bind(i, 26872)).then(t => t.lineToolsIcons)
            }

            function l() {
                const t = i.c[93790];
                return t ? Promise.resolve(t.exports.SERIES_ICONS) : i.e(3718).then(i.bind(i, 93790)).then(t => t.SERIES_ICONS)
            }
            let h = null;

            function d() {
                return null === h && (h = function() {
                    const t = n(o, 2).then(t => t).catch(t => (a.logWarn(t), {})),
                        e = n(l, 2).then(t => t).catch(t => (a.logWarn(t), {}));
                    return Promise.all([t, e])
                }()), h.then(t => (r = {
                    linetool: t[0],
                    series: t[1]
                }, r))
            }

            function c() {
                return r
            }
        },
        92086: (t, e, i) => {
            "use strict";
            i.r(e), i.d(e, {
                DataWindowWidget: () => P
            });
            var s = i(88537),
                n = i(24377),
                a = i(25177),
                r = i(18517),
                o = i(34537),
                l = i(73779),
                h = i(55236),
                d = i(94662),
                c = i(90687),
                u = i(9696),
                g = i(10559),
                p = i(93605),
                m = i(17501),
                _ = i(59930),
                v = i(95932),
                f = i(58767),
                w = i(86892);
            const b = new r.TranslatedString("change visibility", (0, a.t)("change visibility")),
                y = new r.TranslatedString("hide {title}", (0, a.t)("hide {title}")),
                C = new r.TranslatedString("show {title}", (0, a.t)("show {title}")),
                S = (0, a.t)("Data Window"),
                T = (0, a.t)("Color line"),
                B = (0, a.t)("Show"),
                x = (0, a.t)("Hide data"),
                E = (0, a.t)("Show data");
            class P {
                constructor(t) {
                    var e;
                    const i = null === (e = t.getChartWidgetCollection) || void 0 === e ? void 0 : e.call(t);
                    if (!i) throw new Error("ChartWidgetCollection is required");
                    this._chartWidgetCollection = i, this._chartWidget = this._chartWidgetCollection.activeChartWidget.value(), this._views = [], this._headerBinding = [], this._boxesBinding = [];
                    const s = this._container = document.createElement("div");
                    s.classList.add("chart-data-window"), t.container.appendChild(s), this._scroll = new g.SidebarCustomScroll(t.container, s), this.visible = t.visible.value(), this._updateChartWidget(), this._updateSource(), this._updateLayout(), this._chartWidgetCollection.activeChartWidget.subscribe(this.fullUpdate.bind(this)), t.visible.subscribe(this._onVisibilityChange.bind(this)), this._chartWidgetCollection.selectedSources.subscribe(t => {
                        const e = t[0];
                        e && this.updateHighlight({
                            source: e,
                            updateScroll: !0
                        })
                    }), t.setTitle(S)
                }
                update() {
                    this.visible && (this.updateHighlight(), this.updateValues())
                }
                updateHighlight(t) {
                    const e = (t || {}).source,
                        i = !!(t || {}).updateScroll;
                    if (!this.visible || !this._chartWidget || !this._chartWidget.hasModel()) return;
                    const s = this._chartWidget.model().hoveredSource(),
                        n = e || this._chartWidgetCollection.selectedSources.value()[0];
                    let a;
                    for (let t = 0; t < this._boxesBinding.length; ++t) {
                        const e = this._boxesBinding[t].src,
                            i = this._boxesBinding[t].element;
                        if (e) {
                            const t = !(!n || e !== n);
                            i.classList.toggle("hover", !(!s || e !== s)), i.classList.toggle("active", t), t && (a = i)
                        }
                    }
                    a && i && this._scroll.scrollTo(a)
                }
                updateValues() {
                    if (!this.visible) return;
                    const t = t => t.visible(),
                        e = t => ({
                            value: t.value(),
                            title: (0, m.clean)(t.title(), !0),
                            color: t.color(),
                            showColorInBox: this._showColorInBox(t.color())
                        });
                    for (let i = 0; i < this._boxesBinding.length; ++i) {
                        const s = this._boxesBinding[i];
                        s.body.innerHTML = "", s.view.items().filter(t).map(e).forEach(t => {
                            var e, i;
                            const n = document.createElement("div");
                            n.classList.add("chart-data-window-item");
                            const a = document.createElement("div");
                            a.classList.add("chart-data-window-item-title"), a.textContent = t.title, n.appendChild(a);
                            const r = document.createElement("div");
                            if (r.classList.add("chart-data-window-item-value"), n.appendChild(r), t.showColorInBox) {
                                const i = document.createElement("div");
                                i.classList.add("real-color"), i.style.backgroundColor = null !== (e = t.color) && void 0 !== e ? e : "", i.title = T, r.appendChild(i), r.appendChild(document.createTextNode(t.value))
                            } else {
                                const e = document.createElement("span");
                                e.style.color = null !== (i = t.color) && void 0 !== i ? i : "", e.textContent = t.value, r.appendChild(e)
                            }
                            s.body.appendChild(n)
                        })
                    }
                    for (let t = 0; t < this._headerBinding.length; t++) {
                        const e = this._headerBinding[t].element;
                        e && (e.textContent = (0, m.clean)(this._headerBinding[t].value.header(), !0), e.title = (0, m.clean)(this._headerBinding[t].value.title(), !0))
                    }
                }
                fullUpdate() {
                    this._updateChartWidget(), this._updateSource(), this._updateLayout()
                }
                setSelectedSource(t) {
                    this._chartWidget.model().selectionMacro(e => {
                        e.addSourceToSelection(t)
                    })
                }
                showContextMenuForSource(t, e) {
                    t.hasContextMenu() && (this.setSelectedSource(t), t instanceof _.Series ? this._showSeriesContextMenu(t, e) : t instanceof v.Study && this._showStudyContextMenu(t, e))
                }
                createActionShow(t) {
                    const e = new c.Action({
                        actionId: "Chart.SelectedObject.Show",
                        label: B,
                        icon: w,
                        checkable: !0
                    });
                    return e.setBinding(new o.ActionBinder(e, t.properties().visible, this._chartWidget.model(), b)), e.getBinding().setValue(t.properties().visible.value()), e
                }
                _updateChartWidget() {
                    const t = this._chartWidget,
                        e = this._chartWidgetCollection.activeChartWidget.value();
                    t && t.removeDataWindowWidget(), e && (this._chartWidget = e, e.setDataWindowWidget(this))
                }
                _updateSource() {
                    if (!this.visible) return;
                    if (this._views = [], !this._chartWidget.hasModel()) return;
                    const t = this._chartWidget.model().model().dataSources();
                    for (let e = 0; e < t.length; e++) {
                        const i = t[e].dataWindowView();
                        i && this._views.push(i)
                    }
                }
                _updateLayout() {
                    if (this.visible) {
                        this._container.innerHTML = "", this._headerBinding = [];
                        for (let t = this._boxesBinding.length - 1; t >= 0; t--) {
                            const e = this._boxesBinding[t];
                            e.src && e.src.properties().visible.unsubscribe(this, e.visibilityHandler)
                        }
                        this._boxesBinding = [];
                        for (let t = 0; t < this._views.length; ++t) {
                            const e = this._views[t];
                            e.items().length && this._bindView(e)
                        }
                        this.updateHighlight(), this.updateValues(), this._scroll.resize()
                    }
                }
                _bindView(t) {
                    let e;
                    t instanceof l.SeriesDataWindowView ? e = t.series() : (t instanceof d.StudyDataWindowView || t instanceof h.OverlayDataWindowView) && (e = t.study());
                    const i = (0, p.parseHtmlElement)('<div class="box with-actions"><div class="chart-data-window-header"><span class="text"></span><div class="hover-source-icon"></div></div><div class="chart-data-window-body"></div></div>'),
                        n = (0, s.ensureNotNull)(i.querySelector(".chart-data-window-body")),
                        a = (0, s.ensureNotNull)(i.querySelector(".chart-data-window-header"));
                    if (a.classList.toggle("js-hidden", !Boolean(t.header())), this._container.appendChild(i), void 0 !== e) {
                        const t = e;
                        i.classList.toggle("hidden", !t.properties().visible.value()),
                            i.addEventListener("click", e => {
                                e.preventDefault(), this.setSelectedSource(t)
                            }), i.addEventListener("contextmenu", e => {
                                e.preventDefault(), this._chartWidget.readOnly() || this.showContextMenuForSource(t, e)
                            })
                    }

                    function o(t) {
                        return t ? x : E
                    }

                    function c(t) {
                        i.classList.toggle("hidden", !t.value()), i.querySelectorAll(".toggle-source-icon").forEach(e => {
                            e.title = o(t.value())
                        })
                    }
                    if (t.header() && void 0 !== e) {
                        const t = e,
                            i = document.createElement("div");
                        i.classList.add("toggle-source-icon"), i.title = o(t.properties().visible.value()), i.innerHTML = f, i.addEventListener("click", e => {
                            e.stopPropagation();
                            const i = t.properties().visible.value();
                            this._chartWidget.model().setProperty(t.properties().visible, !i, (i ? y : C).format({
                                title: new r.TranslatedString(t.name(), t.title())
                            }))
                        }), a.appendChild(i), a.addEventListener("dblclick", () => {
                            this._chartWidget.showChartPropertiesForSource(t)
                        })
                    }
                    void 0 !== e && e.properties().visible.subscribe(this, c), this._headerBinding.push({
                        value: t,
                        element: a.querySelector(".text")
                    }), this._boxesBinding.push({
                        view: t,
                        src: e,
                        element: i,
                        body: n,
                        visibilityHandler: c
                    })
                }
                _onVisibilityChange(t) {
                    this.visible = !!t, t && this.fullUpdate()
                }
                _showColorInBox(t) {
                    return !!(t && 255 - (0, n.rgbToGrayscale)((0, n.parseRgb)(t)) < 20)
                }
                _showSeriesContextMenu(t, e) {
                    const i = this._chartWidget.actions(),
                        s = t.properties().visible.value();
                    u.ContextMenuManager.showMenu([i.format, s ? i.seriesHide : this.createActionShow(t)], e, void 0, {
                        menuName: "DataWindowWidgetSeriesContextMenu",
                        detail: {
                            type: "series",
                            id: t.instanceId()
                        }
                    })
                }
                _showStudyContextMenu(t, e) {
                    const i = this._chartWidget.actions(),
                        s = t.properties().visible.value();
                    u.ContextMenuManager.showMenu([i.format, s ? i.studyHide : this.createActionShow(t), i.studyRemove], e, void 0, {
                        menuName: "DataWindowWidgetStudyContextMenu",
                        detail: {
                            type: "study",
                            id: t.id()
                        }
                    })
                }
            }
        },
        10559: (t, e, i) => {
            "use strict";
            i.d(e, {
                SidebarCustomScroll: () => u
            });
            var s = i(72535),
                n = i(97496),
                a = i.n(n),
                r = i(2369),
                o = i(42609),
                l = i(96818),
                h = i(81436),
                d = (i(69445), i(99158));
            const c = {
                headerHeight: 0,
                additionalClass: "",
                alwaysVisible: !1,
                showBottomShadow: !0,
                scrollMarginTop: 1,
                bubbleScrollEvent: !1
            };
            class u {
                constructor(t, e, i = {}) {
                    if (this.scrolled = new(a()), this.scrolltoend = new(a()), this.scrolltostart = new(a()), this.visibilityCallbacks = [], this._scrollTargetTop = 0, this._scrollSpeed = 40, this._shadowOffset = 10, this._shadowTop = null, this._shadowBottom = null, this._bottomFixed = !1, this._dragInitialized = !1, this._dragging = !1, this._draggable = null, this._atStart = !1, this._atEnd = !1, this._stickyBottom = null, this._tempIntervalID = void 0, this._animation = null, this._saved = null, this._options = { ...c,
                            ...i
                        }, this._wrapper = t, this._wrapper.classList.add(d.wrapper), this._content = e, this._headerHeight = this._options.headerHeight, this._scrollMarginTop = this._options.scrollMarginTop, this._scrollBar = document.createElement("div"), this._scrollBar.classList.add("sb-scrollbar", "sb-scrollbar-body"), this._options.additionalClass && this._scrollBar.classList.add(this._options.additionalClass), this._scrollBar.classList.toggle("active-always", this._options.alwaysVisible), this._scrollBarWrapper = document.createElement("div"),
                        this._scrollBarWrapper.classList.add("sb-scrollbar-wrap"), this._touch = s.touch, this._touch) return this._content.style.position = "relative", this._wrapper.classList.add(d.touch), void this._wrapper.addEventListener("scroll", () => this._onScroll());
                    this._wrapper.style.overflow = "hidden", this._unsubscribe = (() => {
                        const t = () => {
                                this._bottomFixed || this._dragging || (this._options.alwaysVisible || this._scrollBar.classList.add("active"), this._onScroll())
                            },
                            e = () => {
                                this._bottomFixed || this._dragging || (this._options.alwaysVisible || this._scrollBar.classList.remove("active"), this._onScroll())
                            },
                            i = t => {
                                if (!t.defaultPrevented) {
                                    const e = (0, h.getPixelsFromEvent)(t, () => ({
                                        height: this._wrapper.clientHeight
                                    })).y;
                                    this.scroll(-e, 1) || (t.stopPropagation(), t.preventDefault())
                                }
                            };
                        return this._wrapper.addEventListener("mouseenter", t), this._wrapper.addEventListener("mouseleave", e), this._wrapper.addEventListener("wheel", i), () => {
                            this._wrapper.removeEventListener("mouseenter", t), this._wrapper.removeEventListener("mouseleave", e), this._wrapper.removeEventListener("wheel", i)
                        }
                    })(), !1 !== this._options.showTopShadow && (this._shadowTop = document.createElement("div"), this._shadowTop.classList.add("sb-inner-shadow", "top", "i-invisible"), this._wrapper.appendChild(this._shadowTop)), !1 !== this._options.showBottomShadow && (this._shadowBottom = document.createElement("div"), this._shadowBottom.classList.add("sb-inner-shadow"), this._wrapper.appendChild(this._shadowBottom)), this._shadowTop && this._headerHeight && (this._shadowTop.style.top = this._headerHeight - this._shadowOffset + "px"), this._wrapper.appendChild(this._scrollBarWrapper), this._scrollBarWrapper.appendChild(this._scrollBar), this._onScroll()
                }
                isTouch() {
                    return this._touch
                }
                getScrollBar() {
                    return this._scrollBar
                }
                initDraggable() {
                    return this._dragInitialized || (this._draggable = new l.Draggable({
                        axis: "y",
                        source: this._scrollBar,
                        containment: this._scrollBarWrapper,
                        start: () => {
                            this._dragging = !0
                        },
                        stop: () => {
                            this._dragging = !1
                        },
                        drag: () => {
                            this.updateScroll()
                        }
                    }), this._dragInitialized = !0), this
                }
                updateScroll() {
                    if (this._touch) return this;
                    const t = Math.ceil((0, r.position)(this._scrollBar).top - this._scrollMarginTop - this._headerHeight),
                        e = this.getContainerHeightWithoutHeader(),
                        i = (0, r.outerHeight)(this._content),
                        s = i - e - 1;
                    return e <= 0 || (this._scrollTargetTop = s <= 0 ? this._headerHeight : Math.min(-t * i / e + this._headerHeight, this._headerHeight), t + (0, r.contentHeight)(this._scrollBar) + 2 >= e ? this.scrollToEnd() : (this._content.style.top = this._scrollTargetTop + "px", this._onScroll())), this
                }
                getContainerHeightWithoutHeader() {
                    return this._wrapper.getBoundingClientRect().height - this._headerHeight
                }
                getContainerHeight() {
                    return this._wrapper.getBoundingClientRect().height
                }
                getContentHeight() {
                    return this._content.getBoundingClientRect().height
                }
                updateScrollBar() {
                    if (this._touch) return this;
                    const t = (0, r.position)(this._content).top,
                        e = this.getContentHeight(),
                        i = this.getContainerHeight(),
                        s = this.getContainerHeightWithoutHeader(),
                        n = 1 + this._headerHeight,
                        a = s - 2,
                        o = (Math.abs(t) - this._headerHeight) * a / e,
                        l = i * i / e;
                    return this.isContentShort() ? (this._scrollBar.classList.add("js-hidden"),
                        this._wrapper.classList.remove("sb-scroll-active")) : (this._scrollBar.classList.remove("js-hidden"), this._scrollBar.style.height = l + "px", this._scrollBar.style.top = n + o + "px", this._wrapper.classList.add("sb-scroll-active"), this.initDraggable()), this
                }
                scroll(t, e) {
                    const i = (0, r.position)(this._content).top,
                        s = (0, r.outerHeight)(this._content) - this.getContainerHeightWithoutHeader() - 1,
                        n = e || this._scrollSpeed;
                    return s <= 0 || (this._scrollTargetTop = Math.max(-s + this._headerHeight, Math.min(this._headerHeight, i + t * n)), this.setContentTop(this._scrollTargetTop), this._onScroll())
                }
                animateTo(t) {
                    if (this._touch) return this;
                    const e = (0, r.outerHeight)(this._content) - this.getContainerHeightWithoutHeader() - 1;
                    if (e <= 0) return !0;
                    this._scrollTargetTop = Math.max(-e + this._headerHeight, Math.min(this._headerHeight, -t)), this._animation && this._animation.stop(), this._animation = (0, o.doAnimate)({
                        duration: 500,
                        from: parseFloat(getComputedStyle(this._content).top),
                        to: this._scrollTargetTop,
                        onStep: (t, e) => {
                            this._content.style.top = e + "px"
                        },
                        onComplete: () => {
                            this._onScroll()
                        }
                    })
                }
                resize() {
                    if (this._bottomFixed) return;
                    const t = (0, r.outerHeight)(this._content),
                        e = (0, r.outerHeight)(this._wrapper);
                    !this._options.vAlignBottom && t < e ? this.atStart() || this.scrollToStart() : this.atEnd() ? this.scrollToEnd() : "number" == typeof this._stickyBottom && this.setContentTop(Math.min(0, this._stickyBottom + (0, r.outerHeight)(this._wrapper) - (0, r.outerHeight)(this._content)))
                }
                resizeHeader(t) {
                    const e = t - this._headerHeight;
                    this._headerHeight = t, this._scrollTargetTop += e, this._shadowTop && (this._shadowTop.style.top = this._headerHeight - this._shadowOffset + "px"), this.resize()
                }
                scrollTo(t, e) {
                    const i = {
                        position: "visible",
                        areaHeight: t instanceof HTMLElement ? (0, r.contentHeight)(t) : 0,
                        ...e
                    };
                    t instanceof HTMLElement && (t = i.offsetTop || (0, r.position)(t).top);
                    const s = (0, r.position)(this._content).top,
                        n = this._content.getBoundingClientRect().height,
                        a = this.getContainerHeightWithoutHeader();
                    if (n - a - 1 <= 0) return !0;
                    const o = -1 * (s - this._headerHeight),
                        l = o + a;
                    let h = 0;
                    if ("visible" === i.position) {
                        if (t > o && t + i.areaHeight < l) return !1;
                        h = t + i.areaHeight > l ? l - t - i.areaHeight : o - t
                    } else "top" === i.position && (h = o - t);
                    return this.scroll(h, 1), this._onScroll(), !1
                }
                scrollToEnd() {
                    const t = (0, r.position)(this._content).top,
                        e = (0, r.outerHeight)(this._content),
                        i = (0, r.outerHeight)(this._wrapper),
                        s = e > i ? t + (i - (e + t)) + 1 : 1;
                    return this.setContentTop(s), this._onScroll(), this
                }
                scrollToStart() {
                    return this.setContentTop(this._headerHeight), this._onScroll(), this
                }
                currentPosition() {
                    return Math.round((0, r.position)(this._content).top)
                }
                atStart() {
                    return Math.round((0, r.position)(this._content).top) >= this._headerHeight
                }
                atEnd(t) {
                    "number" == typeof t && isFinite(t) || (t = 0);
                    const e = Math.round((0, r.position)(this._content).top),
                        i = Math.round((0, r.outerHeight)(this._content)),
                        s = Math.round((0, r.outerHeight)(this._wrapper));
                    return i - Math.abs(e) - 1 <= s + t
                }
                checkContentVisibility() {
                    this._onContentVisible()
                }
                subscribeToContentVisible(t, e, i) {
                    this.visibilityCallbacks.push({
                        id: t,
                        element: e,
                        callback: i
                    })
                }
                triggerVisibilityCallbacks(t) {
                    this._onContentVisible(t)
                }
                save() {
                    return this._saved = {
                        top: (0, r.position)(this._content).top,
                        height: (0, r.outerHeight)(this._content)
                    }, this
                }
                restore() {
                    if (this._saved) {
                        if (this._saved.top === (0, r.position)(this._content).top && this._saved.height === (0, r.outerHeight)(this._content)) return this._saved = null, this;
                        this._options.vAlignBottom && (this._saved.top -= (0, r.outerHeight)(this._content) - this._saved.height, this._saved.top > this._headerHeight && (this._saved.top = this._headerHeight)), this.setContentTop(this._saved.top), this._saved = null, this._onScroll(!0)
                    }
                    return this
                }
                fixBottom() {
                    if (this._bottomFixed) return this;
                    if (this._touch) {
                        const t = (0, r.outerHeight)(this._content),
                            e = this._wrapper.scrollTop;
                        this._tempIntervalID = setInterval(() => {
                            this._wrapper.scrollTop = e + ((0, r.outerHeight)(this._content) - t)
                        }, 0)
                    } else this._content.style.top = "auto", this._content.style.bottom = (0, r.outerHeight)(this._wrapper) - (0, r.position)(this._content).top - (0, r.outerHeight)(this._content) + "px";
                    return this._bottomFixed = !0, this
                }
                releaseBottom() {
                    return this._bottomFixed ? (this._touch ? clearInterval(this._tempIntervalID) : (this._content.style.bottom = "auto", this._content.style.top = (0, r.position)(this._content).top + "px"), this._bottomFixed = !1, this._onScroll(), this) : this
                }
                setContentTop(t) {
                    return this._touch ? this._options.vAlignBottom && (0, r.outerHeight)(this._content) < (0, r.outerHeight)(this._wrapper) ? (this._wrapper.style.overflowY = "visible", this._content.style.position = "absolute", this._content.style.bottom = "0px") : (this._content.style.position = "relative", this._content.style.position = "auto", this._wrapper.style.overflowY = "auto", this._wrapper.scrollTop = -t) : this._content.style.top = t + "px", this
                }
                isContentShort() {
                    return this.getContentHeight() <= this.getContainerHeightWithoutHeader()
                }
                destroy() {
                    var t;
                    this._animation && this._animation.stop(), this._scrollBarWrapper && this._scrollBarWrapper.remove(), this._shadowBottom && this._shadowBottom.remove(), this._shadowTop && this._shadowTop.remove(), this._draggable && (this._draggable.destroy(), this._draggable = null), this._content.style.cssText = "", this._wrapper.style.cssText = "", null === (t = this._unsubscribe) || void 0 === t || t.call(this)
                }
                _onScroll(t) {
                    this._touch || (this._content.style.bottom = "auto"), this.scrolled.fire(), this._dragging && !0 !== t || this.updateScrollBar();
                    const e = this.atStart(),
                        i = this.atEnd();
                    return this._shadowTop && this._shadowTop.classList.toggle("i-invisible", !!e), this._shadowBottom && this._shadowBottom.classList.toggle("i-invisible", !!i), this._onContentVisible(), !this._atStart && e ? (this._atStart = !0, this.scrolltostart.fire()) : this._atStart && !e && (this._atStart = !1), !this._atEnd && i ? (this._atEnd = !0, this.scrolltoend.fire()) : this._atEnd && !i && (this._atEnd = !1), this._options.vAlignBottom && (this._stickyBottom = (0, r.outerHeight)(this._content) - Math.abs((0, r.position)(this._content).top) - (0, r.outerHeight)(this._wrapper)), (this._atStart || this._atEnd) && ("function" == typeof this._options.bubbleScrollEvent ? Boolean(this._options.bubbleScrollEvent()) : Boolean(this._options.bubbleScrollEvent))
                }
                _contentIsVisible(t) {
                    return (0, r.position)(t.element).top > -1 * this.currentPosition()
                }
                _onContentVisible(t) {
                    if (!this.visibilityCallbacks.length) return;
                    const e = t || this._contentIsVisible.bind(this),
                        i = [],
                        s = this.visibilityCallbacks.filter((t, s) => {
                            if (!this._content.contains(t.element)) return !1;
                            const n = e(t);
                            return n && i.push(s), !n
                        });
                    i.forEach(e => {
                        this.visibilityCallbacks[e].callback(!!t)
                    }), this.visibilityCallbacks = s
                }
            }
        },
        3741: (t, e, i) => {
            "use strict";
            i.r(e), i.d(e, {
                WidgetBarNews: () => v
            });
            var s = i(88537),
                n = i(10559),
                a = i(21162);
            var r = i(47465),
                o = i(82527),
                l = i(70842);

            function h(t) {
                return function(t) {
                    let e, i = 0;
                    if (0 === t.length) return i;
                    for (var s = 0; s < t.length; s++) e = t.charCodeAt(s), i = (i << 5) - i + e, i &= i;
                    return i
                }(t.title + t.published)
            }
            var d = i(51951);
            const c = new Set([".", "۔", "܁", "܂", "…", "、", "。", "．", ",", ":", ";", "-", "ー", " ", "(", ")"]);

            function u(t, e) {
                if (e <= 0) return t;
                const i = t.length;
                if (i <= e) return t;
                if (i > e) {
                    const i = t[e],
                        s = t[e - 1];
                    if (c.has(i) && !c.has(s)) return g(t, e)
                }
                let s = null;
                for (let i = e - 1; i > 0; i--) {
                    const e = t[i];
                    if (c.has(e)) s = i;
                    else if (null !== s) return g(t, s)
                }
                return t + "…"
            }

            function g(t, e) {
                return t.slice(0, e) + "…"
            }
            var p = i(26800),
                m = (i(45285), i(25669), i(54854));
            const _ = (0, d.getLogger)("News.Widget");
            class v {
                constructor(t) {
                    this.widgetName = "widgetbar", this._newsScrollIterator = null, this._newsDiffResolver = null, this._updateWhenVisible = null, this._pendingNewsRequest = null, this._updateIntervalHandle = null, this._needsFullUpdate = !0, this._dataProvider = null, this._resize = this.resize.bind(this), this._onSymbolChange = this.onSymbolChange.bind(this), this._quoteSymbol = null, this._quoteMetaInfo = null, this._symbolName = null, this._bridge = t, this._widgetTitle = (0, s.ensureNotNull)(this._bridge.header.querySelector(".widgetbar-widgettitle")), this._container = t.container, this._prepareLayout(this._container);
                    const e = function() {
                        if (o.enabled("charting_library_base")) return new l.LibraryNewsProvider
                    }();
                    e && (this._dataProvider = e), this._bridge.symbol.subscribe(this._onSymbolChange, {
                        callWithLast: !0
                    }), window.loginStateChange.subscribe(this, this._onLoginChange)
                }
                refresh() {
                    this.update(!0)
                }
                update(t) {
                    if (!this._dataProvider) return;
                    if (!this._bridge.visible.value()) return void(null === this._updateWhenVisible && (this._updateWhenVisible = t => {
                        t && (null !== this._updateIntervalHandle && this._setUpdateInterval(), this._bridge.visible.unsubscribe(this._updateWhenVisible), this._updateWhenVisible = null, this.update())
                    }, this._bridge.visible.subscribe(this._updateWhenVisible), this._updateIntervalHandle && clearInterval(this._updateIntervalHandle)));
                    const e = this._quoteMetaInfo;
                    if (!e) return this._clear(), void this._stopLoading();
                    const i = e.short_name;
                    this._needsFullUpdate = t || i !== this._symbolName, this._symbolName = i, this._needsFullUpdate && (this._startLoading(), this._updateIntervalHandle && clearInterval(this._updateIntervalHandle), this._setUpdateInterval()), this._pendingNewsRequest && this._pendingNewsRequest.cancel(), this._pendingNewsRequest = (0, r.makeCancelable)(this._dataProvider.getNews(e)), this._pendingNewsRequest.promise.then(t => {
                        this._pendingNewsRequest = null, this._stopLoading(), this._setTitle(t.title), this.updateData(t.newsItems)
                    }).catch(t => {
                        if (!(0, r.isCancelled)(t)) throw this._pendingNewsRequest = null, this._stopLoading(), t
                    })
                }
                updateData(t) {
                    var e;
                    if (t && t.length)
                        if (this._needsFullUpdate) {
                            this._clear(), this._newsScrollIterator = function(t, e) {
                                if (!Number.isInteger(e)) throw new TypeError("Chunks size must be an integer");
                                if (e <= 0) throw new RangeError("Chunk size must be a positive number");
                                const i = t.slice();
                                return {
                                    next() {
                                        const t = i.splice(0, e);
                                        return {
                                            value: t,
                                            done: !t.length
                                        }
                                    }
                                }
                            }(t, 20);
                            const i = this._newsScrollIterator.next().value,
                                s = h(i[0]);
                            this._newsDiffResolver = (e = s, {
                                getDiff(t) {
                                    if (0 === t.length) return [];
                                    const i = t.findIndex(t => h(t) === e);
                                    return e = h(t[0]), t.slice(0, -1 === i ? t.length : i)
                                }
                            }), this._renderItems(i, !1)
                        } else {
                            if (!this._newsDiffResolver) return void _.logError("Attempt to perform partial update before full update was committed");
                            const e = this._newsDiffResolver.getDiff(t);
                            this._renderItems(e, !0)
                        }
                }
                resize() {
                    this._scroll.resize()
                }
                highlight(t) {
                    t.classList.add(m["news-item--highlight"]);
                    const e = () => {
                        t.classList.remove(m["news-item--highlight"]), t.removeEventListener("animationend", e)
                    };
                    t.addEventListener("animationend", e)
                }
                onSymbolChange(t) {
                    if ((0, p.safeShortName)(t) === this._symbolName) return;
                    const e = (0, a.getQuoteSessionInstance)("full");
                    if (this._quoteSymbol && e.unsubscribe(this._bridge.id, this._quoteSymbol), this._quoteMetaInfo = null, !t) return void(this._quoteSymbol = null);
                    this._quoteSymbol = t, this._needsFullUpdate && this.update(), this._bridge.clearNotifications();
                    let i = !1;
                    e.subscribe(this._bridge.id, t, s => {
                        i || ("permission_denied" === s.status && s.values && s.values.alternative ? this.onSymbolChange(s.values.alternative) : s.values && s.values.short_name && (this._quoteMetaInfo = {
                            pro_name: s.values.pro_name,
                            short_name: s.values.short_name,
                            type: s.values.type,
                            typespecs: s.values.typespecs,
                            exchange: s.values.exchange
                        }, this.update(), i = !0, setTimeout(() => {
                            e.unsubscribe(this._bridge.id, t)
                        }, 0)))
                    })
                }
                destroy() {
                    this._quoteSymbol && (0, a.getQuoteSessionInstance)("full").unsubscribe(this._bridge.id, this._quoteSymbol), this._updateIntervalHandle && (clearInterval(this._updateIntervalHandle), this._updateIntervalHandle = null), this._scroll.scrolltoend.unsubscribe(this, this._onScrollToEnd), this._updateWhenVisible && this._bridge.visible.unsubscribe(this._updateWhenVisible), this._unmountAllNewsItems(), this._bridge.height.unsubscribe(this._resize), this._bridge.visible.unsubscribe(this._resize), this._bridge.symbol.unsubscribe(this._onSymbolChange), window.loginStateChange.unsubscribe(this, this._onLoginChange)
                }
                _setTitle(t) {
                    this._dataProvider && (this._widgetTitle.textContent = t)
                }
                _clear() {
                    this._clearListUI(), this._scroll.scrolltoend.unsubscribe(this, this._onScrollToEnd), this._scroll.scrollToStart(), this._scroll.scrolltoend.subscribe(this, this._onScrollToEnd)
                }
                _prepareLayout(t) {
                    this._container = t;
                    const e = this._widget = document.createElement("div");
                    e.classList.add("tv-news"), this._container.appendChild(e);
                    const i = this._data = document.createElement("div");
                    i.classList.add("ns-data"), i.setAttribute("data-name", "news_list"), e.appendChild(i), this._scroll = new n.SidebarCustomScroll(this._widget, this._data), this._bridge.height.subscribe(this._resize), this._bridge.visible.subscribe(this._resize)
                }
                _setUpdateInterval() {
                    if (!this._dataProvider) return;
                    const t = this._dataProvider.timeout();
                    t && (this._updateIntervalHandle = setInterval(this.update.bind(this), t))
                }
                _renderItems(t, e = !1) {
                    if (!this._dataProvider) return;
                    const i = document.createDocumentFragment();
                    for (const s of t) {
                        const t = { ...s
                        };
                        t.shortDescription = u(s.shortDescription, 170);
                        const n = this._dataProvider.renderItem(t);
                        this._dataProvider.addClickHandlers(s, n), e && this.highlight(n), i.appendChild(n)
                    }
                    e ? this._data.prepend(i) : this._data.append(i)
                }
                _onScrollToEnd() {
                    this._newsScrollIterator && this._renderItems(this._newsScrollIterator.next().value, !1)
                }
                _onLoginChange() {
                    window.is_authenticated || this.update()
                }
                _startLoading() {
                    this._data.classList.add("loading")
                }
                _stopLoading() {
                    this._data.classList.remove("loading")
                }
                _clearListUI() {
                    this._data.innerHTML = "", this._unmountAllNewsItems()
                }
                _unmountAllNewsItems() {
                    this._dataProvider && this._dataProvider.unmountItems()
                }
            }
        },
        7270: function(t, e, i) {
            var s, n, a;
            t.exports = (s = i(59496), n = i(87995), a = i(59255), function(t) {
                function e(s) {
                    if (i[s]) return i[s].exports;
                    var n = i[s] = {
                        exports: {},
                        id: s,
                        loaded: !1
                    };
                    return t[s].call(n.exports, n, n.exports, e), n.loaded = !0, n.exports
                }
                var i = {};
                return e.m = t, e.c = i, e.p = "dist/", e(0)
            }([function(t, e, i) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var s = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(i(1));
                e.default = s.default, t.exports = e.default
            }, function(t, e, i) {
                "use strict";

                function s(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var n = function() {
                        function t(t, e) {
                            for (var i = 0; i < e.length; i++) {
                                var s = e[i];
                                s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(t, s.key, s)
                            }
                        }
                        return function(e, i, s) {
                            return i && t(e.prototype, i), s && t(e, s), e
                        }
                    }(),
                    a = i(2),
                    r = (s(a), i(3)),
                    o = s(r),
                    l = s(i(13)),
                    h = s(i(14)),
                    d = s(i(15)),
                    c = function(t) {
                        function e(t) {
                            ! function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e);
                            var i = function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t));
                            return i.measure = function() {
                                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : i.props.includeMargin;
                                if (i.props.shouldMeasure) {
                                    i._node.parentNode || i._setDOMNode();
                                    var e = i.getDimensions(i._node, t),
                                        s = "function" == typeof i.props.children;
                                    i._propsToMeasure.some((function(t) {
                                        if (e[t] !== i._lastDimensions[t]) return i.props.onMeasure(e), s && void 0 !== i && i.setState({
                                            dimensions: e
                                        }), i._lastDimensions = e, !0
                                    }))
                                }
                            }, i.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, i._node = null, i._propsToMeasure = i._getPropsToMeasure(t), i._lastDimensions = {}, i
                        }
                        return function(t, e) {
                            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                            t.prototype = Object.create(e && e.prototype, {
                                constructor: {
                                    value: t,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                        }(e, t), n(e, [{
                            key: "componentDidMount",
                            value: function() {
                                var t = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new h.default((function() {
                                    return t.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(t) {
                                var e = (t.config, t.whitelist),
                                    i = t.blacklist;
                                this.props.whitelist === e && this.props.blacklist === i || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: e,
                                    blacklist: i
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = l.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, d.default)(t, {
                                    margin: e
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(t) {
                                var e = t.whitelist,
                                    i = t.blacklist;
                                return e.filter((function(t) {
                                    return i.indexOf(t) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var t = this.props.children;
                                return a.Children.only("function" == typeof t ? t(this.state.dimensions) : t)
                            }
                        }]), e
                    }(a.Component);
                c.propTypes = {
                    whitelist: o.default.array,
                    blacklist: o.default.array,
                    includeMargin: o.default.bool,
                    useClone: o.default.bool,
                    cloneOptions: o.default.object,
                    shouldMeasure: o.default.bool,
                    onMeasure: o.default.func
                }, c.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, e.default = c, t.exports = e.default
            }, function(t, e) {
                t.exports = s
            }, function(t, e, i) {
                (function(e) {
                    "use strict";
                    var s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    };
                    if ("production" !== e.env.NODE_ENV) {
                        var n = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        t.exports = i(5)((function(t) {
                            return "object" === (void 0 === t ? "undefined" : s(t)) && null !== t && t.$$typeof === n
                        }), !0)
                    } else t.exports = i(12)()
                }).call(e, i(4))
            }, function(t, e) {
                "use strict";

                function i() {
                    throw new Error("setTimeout has not been defined")
                }

                function s() {
                    throw new Error("clearTimeout has not been defined")
                }

                function n(t) {
                    if (h === setTimeout) return setTimeout(t, 0);
                    if ((h === i || !h) && setTimeout) return h = setTimeout, setTimeout(t, 0);
                    try {
                        return h(t, 0)
                    } catch (e) {
                        try {
                            return h.call(null, t, 0)
                        } catch (e) {
                            return h.call(this, t, 0)
                        }
                    }
                }

                function a() {
                    p && u && (p = !1, u.length ? g = u.concat(g) : m = -1, g.length && r())
                }

                function r() {
                    if (!p) {
                        var t = n(a);
                        p = !0;
                        for (var e = g.length; e;) {
                            for (u = g, g = []; ++m < e;) u && u[m].run();
                            m = -1, e = g.length
                        }
                        u = null, p = !1,
                            function(t) {
                                if (d === clearTimeout) return clearTimeout(t);
                                if ((d === s || !d) && clearTimeout) return d = clearTimeout, clearTimeout(t);
                                try {
                                    d(t)
                                } catch (e) {
                                    try {
                                        return d.call(null, t)
                                    } catch (e) {
                                        return d.call(this, t)
                                    }
                                }
                            }(t)
                    }
                }

                function o(t, e) {
                    this.fun = t, this.array = e
                }

                function l() {}
                var h, d, c = t.exports = {};
                ! function() {
                    try {
                        h = "function" == typeof setTimeout ? setTimeout : i
                    } catch (t) {
                        h = i
                    }
                    try {
                        d = "function" == typeof clearTimeout ? clearTimeout : s
                    } catch (t) {
                        d = s
                    }
                }();
                var u, g = [],
                    p = !1,
                    m = -1;
                c.nextTick = function(t) {
                    var e = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var i = 1; i < arguments.length; i++) e[i - 1] = arguments[i];
                    g.push(new o(t, e)), 1 !== g.length || p || n(r)
                }, o.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, c.title = "browser", c.browser = !0, c.env = {}, c.argv = [], c.version = "", c.versions = {}, c.on = l, c.addListener = l, c.once = l, c.off = l, c.removeListener = l, c.removeAllListeners = l, c.emit = l, c.prependListener = l, c.prependOnceListener = l, c.listeners = function(t) {
                    return []
                }, c.binding = function(t) {
                    throw new Error("process.binding is not supported")
                }, c.cwd = function() {
                    return "/"
                }, c.chdir = function(t) {
                    throw new Error("process.chdir is not supported")
                }, c.umask = function() {
                    return 0
                }
            }, function(t, e, i) {
                (function(e) {
                    "use strict";
                    var s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                            return typeof t
                        } : function(t) {
                            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                        },
                        n = i(6),
                        a = i(7),
                        r = i(8),
                        o = i(9),
                        l = i(10),
                        h = i(11);
                    t.exports = function(t, i) {
                        function d(t, e) {
                            return t === e ? 0 !== t || 1 / t == 1 / e : t != t && e != e
                        }

                        function c(t) {
                            this.message = t, this.stack = ""
                        }

                        function u(t) {
                            function s(s, h, d, u, g, p, m) {
                                if (u = u || b, p = p || d, m !== l)
                                    if (i) a(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== e.env.NODE_ENV && "undefined" != typeof console) {
                                    var _ = u + ":" + d;
                                    !n[_] && o < 3 && (r(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", p, u), n[_] = !0, o++)
                                }
                                return null == h[d] ? s ? new c(null === h[d] ? "The " + g + " `" + p + "` is marked as required in `" + u + "`, but its value is `null`." : "The " + g + " `" + p + "` is marked as required in `" + u + "`, but its value is `undefined`.") : null : t(h, d, u, g, p)
                            }
                            if ("production" !== e.env.NODE_ENV) var n = {},
                                o = 0;
                            var h = s.bind(null, !1);
                            return h.isRequired = s.bind(null, !0), h
                        }

                        function g(t) {
                            return u((function(e, i, s, n, a, r) {
                                var o = e[i];
                                return m(o) !== t ? new c("Invalid " + n + " `" + a + "` of type `" + _(o) + "` supplied to `" + s + "`, expected `" + t + "`.") : null
                            }))
                        }

                        function p(e) {
                            switch (void 0 === e ? "undefined" : s(e)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !e;
                                case "object":
                                    if (Array.isArray(e)) return e.every(p);
                                    if (null === e || t(e)) return !0;
                                    var i = function(t) {
                                        var e = t && (f && t[f] || t[w]);
                                        if ("function" == typeof e) return e
                                    }(e);
                                    if (!i) return !1;
                                    var n, a = i.call(e);
                                    if (i !== e.entries) {
                                        for (; !(n = a.next()).done;)
                                            if (!p(n.value)) return !1
                                    } else
                                        for (; !(n = a.next()).done;) {
                                            var r = n.value;
                                            if (r && !p(r[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function m(t) {
                            var e = void 0 === t ? "undefined" : s(t);
                            return Array.isArray(t) ? "array" : t instanceof RegExp ? "object" : function(t, e) {
                                return "symbol" === t || "Symbol" === e["@@toStringTag"] || "function" == typeof Symbol && e instanceof Symbol
                            }(e, t) ? "symbol" : e
                        }

                        function _(t) {
                            if (null == t) return "" + t;
                            var e = m(t);
                            if ("object" === e) {
                                if (t instanceof Date) return "date";
                                if (t instanceof RegExp) return "regexp"
                            }
                            return e
                        }

                        function v(t) {
                            var e = _(t);
                            switch (e) {
                                case "array":
                                case "object":
                                    return "an " + e;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + e;
                                default:
                                    return e
                            }
                        }
                        var f = "function" == typeof Symbol && Symbol.iterator,
                            w = "@@iterator",
                            b = "<<anonymous>>",
                            y = {
                                array: g("array"),
                                bool: g("boolean"),
                                func: g("function"),
                                number: g("number"),
                                object: g("object"),
                                string: g("string"),
                                symbol: g("symbol"),
                                any: u(n.thatReturnsNull),
                                arrayOf: function(t) {
                                    return u((function(e, i, s, n, a) {
                                        if ("function" != typeof t) return new c("Property `" + a + "` of component `" + s + "` has invalid PropType notation inside arrayOf.");
                                        var r = e[i];
                                        if (!Array.isArray(r)) return new c("Invalid " + n + " `" + a + "` of type `" + m(r) + "` supplied to `" + s + "`, expected an array.");
                                        for (var o = 0; o < r.length; o++) {
                                            var h = t(r, o, s, n, a + "[" + o + "]", l);
                                            if (h instanceof Error) return h
                                        }
                                        return null
                                    }))
                                },
                                element: u((function(e, i, s, n, a) {
                                    var r = e[i];
                                    return t(r) ? null : new c("Invalid " + n + " `" + a + "` of type `" + m(r) + "` supplied to `" + s + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(t) {
                                    return u((function(e, i, s, n, a) {
                                        if (!(e[i] instanceof t)) {
                                            var r = t.name || b;
                                            return new c("Invalid " + n + " `" + a + "` of type `" + function(t) {
                                                return t.constructor && t.constructor.name ? t.constructor.name : b
                                            }(e[i]) + "` supplied to `" + s + "`, expected instance of `" + r + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: u((function(t, e, i, s, n) {
                                    return p(t[e]) ? null : new c("Invalid " + s + " `" + n + "` supplied to `" + i + "`, expected a ReactNode.")
                                })),
                                objectOf: function(t) {
                                    return u((function(e, i, s, n, a) {
                                        if ("function" != typeof t) return new c("Property `" + a + "` of component `" + s + "` has invalid PropType notation inside objectOf.");
                                        var r = e[i],
                                            o = m(r);
                                        if ("object" !== o) return new c("Invalid " + n + " `" + a + "` of type `" + o + "` supplied to `" + s + "`, expected an object.");
                                        for (var h in r)
                                            if (r.hasOwnProperty(h)) {
                                                var d = t(r, h, s, n, a + "." + h, l);
                                                if (d instanceof Error) return d
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(t) {
                                    return Array.isArray(t) ? u((function(e, i, s, n, a) {
                                        for (var r = e[i], o = 0; o < t.length; o++)
                                            if (d(r, t[o])) return null;
                                        return new c("Invalid " + n + " `" + a + "` of value `" + r + "` supplied to `" + s + "`, expected one of " + JSON.stringify(t) + ".")
                                    })) : ("production" !== e.env.NODE_ENV && r(!1, "Invalid argument supplied to oneOf, expected an instance of array."), n.thatReturnsNull)
                                },
                                oneOfType: function(t) {
                                    if (!Array.isArray(t)) return "production" !== e.env.NODE_ENV && r(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), n.thatReturnsNull;
                                    for (var i = 0; i < t.length; i++) {
                                        var s = t[i];
                                        if ("function" != typeof s) return r(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", v(s), i), n.thatReturnsNull
                                    }
                                    return u((function(e, i, s, n, a) {
                                        for (var r = 0; r < t.length; r++)
                                            if (null == (0, t[r])(e, i, s, n, a, l)) return null;
                                        return new c("Invalid " + n + " `" + a + "` supplied to `" + s + "`.")
                                    }))
                                },
                                shape: function(t) {
                                    return u((function(e, i, s, n, a) {
                                        var r = e[i],
                                            o = m(r);
                                        if ("object" !== o) return new c("Invalid " + n + " `" + a + "` of type `" + o + "` supplied to `" + s + "`, expected `object`.");
                                        for (var h in t) {
                                            var d = t[h];
                                            if (d) {
                                                var u = d(r, h, s, n, a + "." + h, l);
                                                if (u) return u
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(t) {
                                    return u((function(e, i, s, n, a) {
                                        var r = e[i],
                                            h = m(r);
                                        if ("object" !== h) return new c("Invalid " + n + " `" + a + "` of type `" + h + "` supplied to `" + s + "`, expected `object`.");
                                        var d = o({}, e[i], t);
                                        for (var u in d) {
                                            var g = t[u];
                                            if (!g) return new c("Invalid " + n + " `" + a + "` key `" + u + "` supplied to `" + s + "`.\nBad object: " + JSON.stringify(e[i], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(t), null, "  "));
                                            var p = g(r, u, s, n, a + "." + u, l);
                                            if (p) return p
                                        }
                                        return null
                                    }))
                                }
                            };
                        return c.prototype = Error.prototype, y.checkPropTypes = h, y.PropTypes = y, y
                    }
                }).call(e, i(4))
            }, function(t, e) {
                "use strict";

                function i(t) {
                    return function() {
                        return t
                    }
                }
                var s = function() {};
                s.thatReturns = i, s.thatReturnsFalse = i(!1), s.thatReturnsTrue = i(!0), s.thatReturnsNull = i(null), s.thatReturnsThis = function() {
                    return this
                }, s.thatReturnsArgument = function(t) {
                    return t
                }, t.exports = s
            }, function(t, e, i) {
                (function(e) {
                    "use strict";
                    var i = function(t) {};
                    "production" !== e.env.NODE_ENV && (i = function(t) {
                        if (void 0 === t) throw new Error("invariant requires an error message argument")
                    }), t.exports = function(t, e, s, n, a, r, o, l) {
                        if (i(e), !t) {
                            var h;
                            if (void 0 === e) h = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var d = [s, n, a, r, o, l],
                                    c = 0;
                                (h = new Error(e.replace(/%s/g, (function() {
                                    return d[c++]
                                })))).name = "Invariant Violation"
                            }
                            throw h.framesToPop = 1, h
                        }
                    }
                }).call(e, i(4))
            }, function(t, e, i) {
                (function(e) {
                    "use strict";
                    var s = i(6);
                    if ("production" !== e.env.NODE_ENV) {
                        var n = function(t) {
                            for (var e = arguments.length, i = Array(e > 1 ? e - 1 : 0), s = 1; s < e; s++) i[s - 1] = arguments[s];
                            var n = 0,
                                a = "Warning: " + t.replace(/%s/g, (function() {
                                    return i[n++]
                                }));
                            "undefined" != typeof console && console.error(a);
                            try {
                                throw new Error(a)
                            } catch (t) {}
                        };
                        s = function(t, e) {
                            if (void 0 === e) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== e.indexOf("Failed Composite propType: ") && !t) {
                                for (var i = arguments.length, s = Array(i > 2 ? i - 2 : 0), a = 2; a < i; a++) s[a - 2] = arguments[a];
                                n.apply(void 0, [e].concat(s))
                            }
                        }
                    }
                    t.exports = s
                }).call(e, i(4))
            }, function(t, e) {
                "use strict";

                function i(t) {
                    if (null == t) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(t)
                }
                var s = Object.getOwnPropertySymbols,
                    n = Object.prototype.hasOwnProperty,
                    a = Object.prototype.propertyIsEnumerable;
                t.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var t = new String("abc");
                        if (t[5] = "de", "5" === Object.getOwnPropertyNames(t)[0]) return !1;
                        for (var e = {}, i = 0; i < 10; i++) e["_" + String.fromCharCode(i)] = i;
                        if ("0123456789" !== Object.getOwnPropertyNames(e).map((function(t) {
                                return e[t]
                            })).join("")) return !1;
                        var s = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(t) {
                            s[t] = t
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, s)).join("")
                    } catch (t) {
                        return !1
                    }
                }() ? Object.assign : function(t, e) {
                    for (var r, o, l = i(t), h = 1; h < arguments.length; h++) {
                        for (var d in r = Object(arguments[h])) n.call(r, d) && (l[d] = r[d]);
                        if (s) {
                            o = s(r);
                            for (var c = 0; c < o.length; c++) a.call(r, o[c]) && (l[o[c]] = r[o[c]])
                        }
                    }
                    return l
                }
            }, function(t, e) {
                "use strict";
                t.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(t, e, i) {
                (function(e) {
                    "use strict";
                    var s = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    };
                    if ("production" !== e.env.NODE_ENV) var n = i(7),
                        a = i(8),
                        r = i(10),
                        o = {};
                    t.exports = function(t, i, l, h, d) {
                        if ("production" !== e.env.NODE_ENV)
                            for (var c in t)
                                if (t.hasOwnProperty(c)) {
                                    var u;
                                    try {
                                        n("function" == typeof t[c], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", h || "React class", l, c, s(t[c])), u = t[c](i, c, h, l, null, r)
                                    } catch (t) {
                                        u = t
                                    }
                                    if (a(!u || u instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", h || "React class", l, c, void 0 === u ? "undefined" : s(u)), u instanceof Error && !(u.message in o)) {
                                        o[u.message] = !0;
                                        var g = d ? d() : "";
                                        a(!1, "Failed %s type: %s%s", l, u.message, null != g ? g : "")
                                    }
                                }
                    }
                }).call(e, i(4))
            }, function(t, e, i) {
                "use strict";
                var s = i(6),
                    n = i(7),
                    a = i(10);
                t.exports = function() {
                    function t(t, e, i, s, r, o) {
                        o !== a && n(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function e() {
                        return t
                    }
                    t.isRequired = t;
                    var i = {
                        array: t,
                        bool: t,
                        func: t,
                        number: t,
                        object: t,
                        string: t,
                        symbol: t,
                        any: t,
                        arrayOf: e,
                        element: t,
                        instanceOf: e,
                        node: t,
                        objectOf: e,
                        oneOf: e,
                        oneOfType: e,
                        shape: e,
                        exact: e
                    };
                    return i.checkPropTypes = s, i.PropTypes = i, i
                }
            }, function(t, e) {
                t.exports = n
            }, function(t, e) {
                t.exports = a
            }, function(t, e, i) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        i = t.getBoundingClientRect(),
                        n = void 0,
                        a = void 0,
                        r = void 0;
                    return e.margin && (r = (0, s.default)(getComputedStyle(t))), e.margin ? (n = r.left + i.width + r.right, a = r.top + i.height + r.bottom) : (n = i.width, a = i.height), {
                        width: n,
                        height: a,
                        top: i.top,
                        right: i.right,
                        bottom: i.bottom,
                        left: i.left
                    }
                };
                var s = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(i(16));
                t.exports = e.default
            }, function(t, e) {
                "use strict";
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = function(t) {
                    return {
                        top: i((t = t || {}).marginTop),
                        right: i(t.marginRight),
                        bottom: i(t.marginBottom),
                        left: i(t.marginLeft)
                    }
                };
                var i = function(t) {
                    return parseInt(t) || 0
                };
                t.exports = e.default
            }]))
        },
        47152: (t, e, i) => {
            "use strict";

            function s(t) {
                let e = null;
                return (i, ...s) => (null == e || e.abort(), e = new AbortController, null == i || i.addEventListener("error", () => null == e ? void 0 : e.abort(), {
                    once: !0
                }), t(e.signal, ...s))
            }

            function n(t) {
                if (!l(t)) throw t
            }

            function a(t) {
                if (l(t)) throw t
            }

            function r(t) {
                return (null == t ? void 0 : t.aborted) ? Promise.reject(o()) : new Promise((e, i) => {
                    null == t || t.addEventListener("abort", () => i(o()), {
                        once: !0
                    })
                })
            }

            function o() {
                return new DOMException("Aborted", "AbortError")
            }

            function l(t) {
                return t instanceof Error && "AbortError" === t.name
            }

            function h(t, e) {
                return Promise.race([r(t), e])
            }
            async function d(t, e) {
                let i;
                try {
                    await h(t, new Promise(t => {
                        i = setTimeout(t, e)
                    }))
                } finally {
                    clearTimeout(i)
                }
            }
            i.d(e, {
                respectLatest: () => s,
                skipAbortError: () => n,
                rethrowAbortError: () => a,
                isAbortError: () => l,
                respectAbort: () => h,
                delay: () => d
            })
        },
        96818: (t, e, i) => {
            "use strict";
            i.d(e, {
                Draggable: () => o,
                PointerBackend: () => l
            });
            var s = i(88537),
                n = i(2369),
                a = i(1227),
                r = i(72535);
            class o {
                constructor(t) {
                    var e, i;
                    this._helper = null, this._handleDragStart = t => {
                        var e;
                        if (null !== this._helper) return;
                        const i = this._source;
                        i.classList.add("ui-draggable-dragging");
                        const [s, a] = [(0, n.outerWidth)(i), (0, n.outerHeight)(i)];
                        this._helper = {
                            startTop: parseFloat(i.style.top) || 0,
                            startLeft: parseFloat(i.style.left) || 0,
                            nextTop: null,
                            nextLeft: null,
                            raf: null,
                            size: [s, a],
                            containment: this._containment instanceof HTMLElement ? [parseInt(getComputedStyle(this._containment).borderLeftWidth) + parseInt(getComputedStyle(this._containment).paddingLeft), parseInt(getComputedStyle(this._containment).borderTopWidth) + parseInt(getComputedStyle(this._containment).paddingTop), this._containment.offsetWidth - parseInt(getComputedStyle(this._containment).borderRightWidth) - parseInt(getComputedStyle(this._containment).paddingRight) - parseInt(getComputedStyle(i).marginLeft) - parseInt(getComputedStyle(i).marginRight) - s, this._containment.offsetHeight - parseInt(getComputedStyle(this._containment).borderBottomWidth) - parseInt(getComputedStyle(this._containment).paddingBottom) - parseInt(getComputedStyle(i).marginTop) - parseInt(getComputedStyle(i).marginBottom) - a] : "window" === this._containment ? [window.scrollX, window.scrollY, window.scrollX + document.documentElement.offsetWidth - s, window.scrollY + document.documentElement.offsetHeight - a] : null
                        }, null === (e = this._start) || void 0 === e || e.call(this)
                    }, this._handleDragMove = t => {
                        var e;
                        if (null === this._helper) return;
                        const {
                            current: i,
                            initial: s
                        } = t.detail, n = this._source, a = this._helper.nextTop, r = this._helper.nextLeft, o = "y" === this._axis || !1 === this._axis || 0 !== i.movementY;
                        if (o) {
                            const t = this._helper.startTop;
                            isFinite(t) && (this._helper.nextTop = i.clientY - s.clientY + t)
                        }
                        const l = "x" === this._axis || !1 === this._axis || 0 !== i.movementY;
                        if (l) {
                            const t = this._helper.startLeft;
                            isFinite(t) && (this._helper.nextLeft = i.clientX - s.clientX + t)
                        }
                        if (null !== this._helper.containment) {
                            const [t, e, i, s] = this._helper.containment;
                            o && this._helper.nextTop && (this._helper.nextTop = Math.min(this._helper.nextTop, s), this._helper.nextTop = Math.max(this._helper.nextTop, e)), l && this._helper.nextLeft && (this._helper.nextLeft = Math.min(this._helper.nextLeft, i), this._helper.nextLeft = Math.max(this._helper.nextLeft, t))
                        }
                        null !== this._helper.raf || a === this._helper.nextTop && r === this._helper.nextLeft || (this._helper.raf = requestAnimationFrame(() => {
                            null !== this._helper && (null !== this._helper.nextTop && (n.style.top = this._helper.nextTop + "px", this._helper.nextTop = null), null !== this._helper.nextLeft && (n.style.left = this._helper.nextLeft + "px", this._helper.nextLeft = null), this._helper.raf = null)
                        })), null === (e = this._drag) || void 0 === e || e.call(this)
                    }, this._handleDragStop = t => {
                        var e;
                        if (null === this._helper) return;
                        this._source.classList.remove("ui-draggable-dragging"), this._helper = null,
                            null === (e = this._stop) || void 0 === e || e.call(this)
                    };
                    const s = this._source = t.source;
                    s.classList.add("ui-draggable");
                    const a = this._handle = null !== (e = t.handle ? s.querySelector(t.handle) : null) && void 0 !== e ? e : s;
                    a.classList.add("ui-draggable-handle"), this._start = t.start, this._stop = t.stop, this._drag = t.drag, this._backend = new l({
                        handle: a,
                        onDragStart: this._handleDragStart,
                        onDragMove: this._handleDragMove,
                        onDragStop: this._handleDragStop
                    }), this._axis = null !== (i = t.axis) && void 0 !== i && i, this._containment = t.containment
                }
                destroy() {
                    const t = this._source;
                    t.classList.remove("ui-draggable"), t.classList.remove("ui-draggable-dragging");
                    this._handle.classList.remove("ui-draggable-handle"), this._backend.destroy(), null !== this._helper && (this._helper.raf && cancelAnimationFrame(this._helper.raf), this._helper = null)
                }
            }
            class l {
                constructor(t) {
                    this._initial = null, this._handlePointerDown = t => {
                        if (null !== this._initial) return;
                        if (!(t.target instanceof Element && this._handle.contains(t.target))) return;
                        if (this._initial = t, !this._dispatchEvent(this._createEvent("pointer-drag-start", t))) return void(this._initial = null);
                        t.preventDefault();
                        const e = this._getEventTarget();
                        e.addEventListener("pointermove", this._handlePointerMove), e.addEventListener("pointerup", this._handlePointerUp), e.addEventListener("pointercancel", this._handlePointerUp), e.addEventListener("lostpointercapture", this._handlePointerUp), e.setPointerCapture(t.pointerId)
                    }, this._handlePointerMove = t => {
                        null !== this._initial && this._initial.pointerId === t.pointerId && (t.preventDefault(), this._dispatchEvent(this._createEvent("pointer-drag-move", t)))
                    }, this._handlePointerUp = t => {
                        if (null === this._initial || this._initial.pointerId !== t.pointerId) return;
                        t.preventDefault();
                        const e = this._getEventTarget();
                        e.removeEventListener("pointermove", this._handlePointerMove), e.removeEventListener("pointerup", this._handlePointerUp), e.removeEventListener("pointercancel", this._handlePointerUp), e.removeEventListener("lostpointercapture", this._handlePointerUp), e.releasePointerCapture(this._initial.pointerId), this._dispatchEvent(this._createEvent("pointer-drag-stop", t)), this._initial = null
                    };
                    const e = this._handle = t.handle;
                    this._onDragStart = t.onDragStart, this._onDragMove = t.onDragMove, this._onDragStop = t.onDragStop, e.style.touchAction = "none";
                    this._getEventTarget().addEventListener("pointerdown", this._handlePointerDown)
                }
                destroy() {
                    this._handle.style.touchAction = "";
                    const t = this._getEventTarget();
                    t.removeEventListener("pointerdown", this._handlePointerDown), t.removeEventListener("pointermove", this._handlePointerMove), t.removeEventListener("pointerup", this._handlePointerUp), t.removeEventListener("pointercancel", this._handlePointerUp), t.removeEventListener("lostpointercapture", this._handlePointerUp), null !== this._initial && (t.releasePointerCapture(this._initial.pointerId), this._initial = null)
                }
                _getEventTarget() {
                    return a.CheckMobile.iOS() || (0, a.isMac)() && r.touch ? window.document.documentElement : this._handle
                }
                _dispatchEvent(t) {
                    switch (t.type) {
                        case "pointer-drag-start":
                            this._onDragStart(t);
                            break;
                        case "pointer-drag-move":
                            this._onDragMove(t);
                            break;
                        case "pointer-drag-stop":
                            this._onDragStop(t)
                    }
                    return !t.defaultPrevented
                }
                _createEvent(t, e) {
                    return (0, s.assert)(null !== this._initial), new CustomEvent(t, {
                        bubbles: !0,
                        cancelable: !0,
                        detail: {
                            backend: this,
                            initial: this._initial,
                            current: e
                        }
                    })
                }
            }
        },
        2369: (t, e, i) => {
            "use strict";
            i.d(e, {
                contentHeight: () => n,
                html: () => o,
                outerHeight: () => a,
                outerWidth: () => r,
                position: () => h
            });
            var s = i(88537);

            function n(t) {
                const {
                    paddingTop: e,
                    paddingBottom: i
                } = window.getComputedStyle(t);
                return [e, i].reduce((t, e) => t - Number((e || "").replace("px", "")), t.clientHeight)
            }

            function a(t, e = !1) {
                const i = getComputedStyle(t),
                    s = [i.height];
                return "border-box" !== i.boxSizing && s.push(i.paddingTop, i.paddingBottom, i.borderTopWidth, i.borderBottomWidth), e && s.push(i.marginTop, i.marginBottom), s.reduce((t, e) => t + (parseFloat(e) || 0), 0)
            }

            function r(t, e = !1) {
                const i = getComputedStyle(t),
                    s = [i.width];
                return "border-box" !== i.boxSizing && s.push(i.paddingLeft, i.paddingRight, i.borderLeftWidth, i.borderRightWidth), e && s.push(i.marginLeft, i.marginRight), s.reduce((t, e) => t + (parseFloat(e) || 0), 0)
            }

            function o(t, e) {
                return void 0 === e || (null === e && (t.innerHTML = ""), "string" != typeof e && "number" != typeof e || (t.innerHTML = String(e))), t
            }

            function l(t) {
                if (!t.getClientRects().length) return {
                    top: 0,
                    left: 0
                };
                const e = t.getBoundingClientRect(),
                    i = (0, s.ensureNotNull)(t.ownerDocument.defaultView);
                return {
                    top: e.top + i.pageYOffset,
                    left: e.left + i.pageXOffset
                }
            }

            function h(t) {
                const e = getComputedStyle(t);
                let i, s = {
                    top: 0,
                    left: 0
                };
                if ("fixed" === e.position) i = t.getBoundingClientRect();
                else {
                    i = l(t);
                    const e = t.ownerDocument;
                    let n = t.offsetParent || e.documentElement;
                    for (; n && (n === e.body || n === e.documentElement) && "static" === getComputedStyle(n).position;) n = n.parentElement;
                    n && n !== t && 1 === n.nodeType && (s = l(n), s.top += parseFloat(getComputedStyle(n).borderTopWidth), s.left += parseFloat(getComputedStyle(n).borderLeftWidth))
                }
                return {
                    top: i.top - s.top - parseFloat(e.marginTop),
                    left: i.left - s.left - parseFloat(e.marginLeft)
                }
            }
        },
        79796: (t, e, i) => {
            "use strict";
            i.r(e), i.d(e, {
                DetailsContainer: () => l,
                Widget: () => h
            });
            var s = i(51951),
                n = i(48547),
                a = i(94489);
            const r = new(i.n(a)())(!1),
                o = (0, s.getLogger)("Platform.GUI.Widgetbar.DetailsWidget");
            class l extends n.WidgetbarWidgetRenderer {
                constructor(t) {
                    super(t), this._history = null, this._mounted = !1, this._contentRenderer = null, this._bridge = t, this.mount()
                }
                navigate(t, e) {
                    var i;
                    null === (i = this._history) || void 0 === i || i.replace(t, e)
                }
                mount() {
                    this._mounted ? o.logWarn("Mount was called on already mounted widget") : (this._mounted = !0, this._load())
                }
                unmount() {
                    this._mounted ? (this._mounted = !1, r.setValue(!1), super.unmount(), this._loadModulePromise = null) : o.logWarn("Unmount was called on already unmounted widget")
                }
                destroy() {
                    super.destroy()
                }
                _load() {
                    if (this._contentRenderer) return r.setValue(!0), void this._contentRenderer();
                    const t = this._loadModulePromise = Promise.all([Promise.all([i.e(510), i.e(9879), i.e(7459), i.e(6991)]).then(i.bind(i, 20182)), Promise.resolve().then(i.t.bind(i, 59496, 19)), Promise.resolve().then(i.t.bind(i, 87995, 19))]).then(([e, i, s]) => {
                        t === this._loadModulePromise && (this._contentRenderer = () => {
                            s.render(i.createElement(e.DetailsWrapper, {
                                bridge: this._bridge,
                                widgetHeaderElement: this._headerContainer,
                                history: this._history
                            }), this._container)
                        }, this._contentRenderer(), r.setValue(!0))
                    })
                }
                _handleLoginStateChange() {
                    0
                }
            }
            const h = l
        },
        4095: (t, e, i) => {
            "use strict";
            i.r(e), i.d(e, {
                ObjectTreeRenderer: () => r
            });
            var s = i(33290),
                n = i(85473),
                a = i(58884);
            class r {
                constructor(t) {
                    this._viewModel = null, this._promise = null, this._activityChangeHandler = t => {
                        t ? this.mount() : this.destroy()
                    }, this._container = t.container, t.active.value() && this.mount(), t.active.subscribe(this._activityChangeHandler)
                }
                mount() {
                    const t = this._promise = Promise.all([Promise.resolve().then(i.t.bind(i, 59496, 19)), Promise.resolve().then(i.t.bind(i, 87995, 19)), Promise.all([i.e(9685), i.e(5514), i.e(9129), i.e(2e3), i.e(6363), i.e(9289), i.e(3466), i.e(7836), i.e(3921), i.e(7419), i.e(9042), i.e(510), i.e(9859), i.e(3956), i.e(4976), i.e(3199), i.e(5827), i.e(2930), i.e(8765), i.e(3259), i.e(5031)]).then(i.bind(i, 20779)), Promise.all([i.e(9685), i.e(5514), i.e(9129), i.e(2e3), i.e(6363), i.e(9289), i.e(3466), i.e(7836), i.e(3921), i.e(7419), i.e(9042), i.e(510), i.e(9859), i.e(3956), i.e(4976), i.e(3199), i.e(5827), i.e(2930), i.e(8765), i.e(3259), i.e(5031)]).then(i.bind(i, 93321)), Promise.all([i.e(9685), i.e(5514), i.e(9129), i.e(2e3), i.e(6363), i.e(9289), i.e(3466), i.e(7836), i.e(3921), i.e(7419), i.e(9042), i.e(510), i.e(9859), i.e(3956), i.e(4976), i.e(3199), i.e(5827), i.e(2930), i.e(8765), i.e(3259), i.e(5031)]).then(i.bind(i, 42997)), (0, a.loadAllSourcesIcons)()]).then(([e, i, a, r, o]) => {
                        if (this._promise === t) {
                            const t = (0, s.service)(n.CHART_WIDGET_COLLECTION_SERVICE);
                            null === this._viewModel && (this._viewModel = new o.ObjectTree(t.activeChartWidget)), i.render(e.createElement(r.ObjectTree, {
                                nodeRenderer: a.NodeRenderer,
                                viewModel: this._viewModel
                            }), this._container)
                        }
                    })
                }
                unmount() {
                    this._promise = null;
                    const t = i.c[87995];
                    if (t) {
                        t.exports.unmountComponentAtNode(this._container)
                    }
                }
                destroy() {
                    this.unmount(), null !== this._viewModel && (this._viewModel.destroy(), this._viewModel = null)
                }
            }
        },
        26800: (t, e, i) => {
            "use strict";
            i.d(e, {
                safeShortName: () => n
            });
            var s = i(10248);

            function n(t) {
                try {
                    return (0, s.shortName)(t)
                } catch (e) {
                    return t
                }
            }
        },
        21258: (t, e, i) => {
            "use strict";
            i.d(e, {
                hoverMouseEventFilter: () => a,
                useAccurateHover: () => r,
                useHover: () => n
            });
            var s = i(59496);

            function n() {
                const [t, e] = (0, s.useState)(!1);
                return [t, {
                    onMouseOver: function(t) {
                        a(t) && e(!0)
                    },
                    onMouseOut: function(t) {
                        a(t) && e(!1)
                    }
                }]
            }

            function a(t) {
                return !t.currentTarget.contains(t.relatedTarget)
            }

            function r(t) {
                const [e, i] = (0, s.useState)(!1);
                return (0, s.useEffect)(() => {
                    const e = e => {
                        if (null === t.current) return;
                        const s = t.current.contains(e.target);
                        i(s)
                    };
                    return document.addEventListener("mouseover", e), () => document.removeEventListener("mouseover", e)
                }, []), e
            }
        },
        81436: (t, e, i) => {
            "use strict";
            i.d(e, {
                getPixelsFromEvent: () => n
            });
            const s = [() => navigator.userAgent.includes("Win") && navigator.userAgent.includes("Chrome") ? 1 / window.devicePixelRatio : 1, () => 16, (t = (() => 0)) => {
                var e;
                return .8 * (null !== (e = t()) && void 0 !== e ? e : 0)
            }];

            function n(t, e = (() => ({}))) {
                return {
                    x: t.deltaX * s[t.deltaMode](() => e().width),
                    y: t.deltaY * s[t.deltaMode](() => e().height)
                }
            }
        },
        91046: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        86219: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 10" width="20" height="10"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 1l8 8 8-8"/></svg>'
        },
        58767: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 16" width="23px" height="16px"><path d="M11.404 15.2c6.298 0 11.404-7.6 11.404-7.6S17.702 0 11.404 0 0 7.6 0 7.6s5.106 7.6 11.404 7.6zm-3.8-7.6c0-2.11 1.688-3.8 3.8-3.8s3.8 1.69 3.8 3.8-1.72 3.8-3.8 3.8c-2.112 0-3.8-1.69-3.8-3.8z"/></svg>'
        },
        35982: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M22.308 8.606a.5.5 0 0 0-.616 0l-11.5 9a.5.5 0 0 0 0 .788l11.5 9a.5.5 0 0 0 .616 0l11.5-9a.5.5 0 0 0 0-.788l-11.5-9zM22 26.366L11.311 18 22 9.635 32.689 18 22 26.365zm0 4l-11.192-8.76-.616.788 11.5 9a.5.5 0 0 0 .616 0l11.5-9-.616-.788L22 30.366zm0 4l-11.192-8.76-.616.788 11.5 9a.5.5 0 0 0 .616 0l11.5-9-.616-.788L22 34.366z"/></svg>'
        },
        5775: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="45" height="45"><g fill="none" stroke="currentColor"><path d="M14.5 27.5c0 4.97 3.03 8 8 8 4.97 0 8-3.03 8-8v-6a3 3 0 0 0-3-3h-10a3 3 0 0 0-3 3v6z"/><path stroke-linecap="square" d="M22.5 19v16"/><path d="M27.5 18.5a5 5 0 1 0-10 0m13 3h2a2 2 0 0 1 2 2V25m-4 2.5h2a2 2 0 0 1 2 2V31M29 32.5h1.5a2 2 0 0 1 2 2V36m-18-14.5h-2a2 2 0 0 0-2 2V25m4 2.5h-2a2 2 0 0 0-2 2V31m5.5 1.5h-1.5a2 2 0 0 0-2 2V36"/><g transform="translate(12 8)"><circle cx="2.5" cy="2.5" r="2"/><path d="M3.911 3.911L7 7"/></g><g transform="translate(26 8)"><circle cx="4.5" cy="2.5" r="2"/><path d="M3.115 3.885L0 7"/></g></g></svg>'
        },
        48200: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="45" height="45"><path fill="currentcolor" d="m5 12v-1h4v1zm5-6h1v4h-1zm0 7h1v4h-1zm2-1v-1h4v1zm7 0v-1h10.5a4.5 4.5 0 0 1 4.5 4.5v14a4.5 4.5 0 0 1-4.5 4.5h-15a4.5 4.5 0 0 1-4.5-4.5V20h1v9.5a3.5 3.5 0 0 0 3.5 3.5h15a3.5 3.5 0 0 0 3.5-3.5v-14a3.5 3.5 0 0 0-3.5-3.5H19zm-3 5a1 1 0 0 0 0 2h12a1 1 0 0 0 0-2H16zm0-1h12a2 2 0 1 1 0 4H16a2 2 0 1 1 0-4zm-1 8v-1h8v1zm0 4v-1h8v1zm11-4v-1h3v1zm0 4v-1h3v1z"/></svg>'
        },
        95387: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="45" height="45"><path fill="currentcolor" d="m17 30a1 1 0 0 1 0 4h-4a1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2m0-7a1 1 0 0 1 0 4h-4a1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2m6 5a1 1 0 0 1 0 4 1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2 1 1 0 0 0 0-2m0-7a1 1 0 0 1 0 4 1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2 1 1 0 0 0 0-2m0-7a1 1 0 0 1 0 4 1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2 1 1 0 0 0 0-2m0-7a1 1 0 0 1 0 4 1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2 1 1 0 0 0 0-2m10 5a1 1 0 0 1 0 4h-4a1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2m0-7a1 1 0 0 1 0 4h-4a1 1 0 0 1 0-4m0 1a1 1 0 0 0 0 2h4a1 1 0 0 0 0-2"/></svg>'
        },
        86126: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="45" height="45"><path fill="currentcolor" d="m18 18v-.5c0-1.2.6-2 1.5-2.7.8-.5 2-.8 3-.8s2.2.3 3 .8c.9.6 1.5 1.5 1.5 2.7a4 4 0 0 1-1.3 2.8l-2.3 2c-.3.3-.4.6-.4 1.2v.5h-1v-.5c0-.8.2-1.4.6-1.9l2.4-2c.6-.7 1-1.3 1-2.1a2 2 0 0 0-1-1.8c-.7-.5-1.6-.7-2.5-.7-1 0-1.8.2-2.5.7-.6.4-1 1-1 1.8v.5m3.5 8a1 1 0 0 0 0 5 1 1 0 0 0 0-5m0 1a1 1 0 0 1 0 3 1 1 0 0 1 0-3m0-17a1 1 0 0 0 0 25 1 1 0 0 0 0-25m0 1a1 1 0 0 1 0 23 1 1 0 0 1 0-23"/></svg>'
        },
        42353: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45" width="45" height="45"><path fill="currentcolor" d="M16.5 21.5l8.146 8.146a.914.914 0 0 1-1.292 1.293L16.5 24.086l-6.854 6.853a.914.914 0 0 1-1.292-1.293L16.5 21.5zm0 4l6.146 6.146a1.914 1.914 0 0 0 2.708-2.707L16.5 20.086l-8.854 8.853a1.914 1.914 0 1 0 2.708 2.707L16.5 25.5zm13 0l8.146-8.146a.914.914 0 0 0-1.292-1.293L29.5 22.914l-6.854-6.853a.914.914 0 0 0-1.292 1.293L29.5 25.5zm0-4l6.146-6.146a1.914 1.914 0 0 1 2.708 2.707L29.5 26.914l-8.854-8.853a1.914 1.914 0 1 1 2.708-2.707L29.5 21.5z"/></svg>'
        },
        62759: t => {
            t.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="45" height="45"><path fill="currentcolor" d="m29.5 11a4.5 4.5 0 0 1 4.5 4.5v14a4.5 4.5 0 0 1-4.5 4.5h-15a4.5 4.5 0 0 1-4.5-4.5v-14a4.5 4.5 0 0 1 4.5-4.5m0 1a3.5 3.5 0 0 0-3.5 3.5v14a3.5 3.5 0 0 0 3.5 3.5h15a3.5 3.5 0 0 0 3.5-3.5v-14a3.5 3.5 0 0 0-3.5-3.5M15 17v-1h14v1zm0 4v-1h14v1zm0 4v-1h14v1zm0 4v-1h14v1z"/></svg>'
        }
    }
]);
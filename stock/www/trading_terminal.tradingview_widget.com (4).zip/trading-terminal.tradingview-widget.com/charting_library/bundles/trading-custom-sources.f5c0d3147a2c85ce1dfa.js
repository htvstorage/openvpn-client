"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2650], {
        51763: (t, e, i) => {
            var o;
            i.d(e, {
                    TradedItemType: () => o
                }),
                function(t) {
                    t[t.Position = 0] = "Position", t[t.Order = 1] = "Order"
                }(o || (o = {}))
        },
        9016: (t, e, i) => {
            i.d(e, {
                priceToPips: () => r,
                riskInCurrencyToPips: () => s,
                riskInPercentToPips: () => a,
                pipsToPrice: () => l,
                pipsToRiskInCurrency: () => n,
                pipsToRiskInPercent: () => d
            });
            var o = i(60521);

            function r(t, e, i, r) {
                return (0, o.Big)(t).minus(e).div(r).div(i).toNumber()
            }

            function s(t, e, i, r, s) {
                const a = (0, o.Big)(i).mul(e).mul(s || 1);
                if (a.eq(0)) return 0;
                const l = (0, o.Big)(t).div(a).mul(r).toNumber();
                return Math.floor(l)
            }

            function a(t, e, i, r, s, a) {
                const l = (0, o.Big)(r).mul(e).mul(a || 1).mul(100);
                if (l.eq(0)) return 0;
                const n = (0, o.Big)(t).mul(i).div(l).mul(s).toNumber();
                return Math.floor(n)
            }

            function l(t, e, i, r) {
                return (0, o.Big)(i).mul(t).mul(r).plus(e).toNumber()
            }

            function n(t, e, i, r, s) {
                return (0, o.Big)(t).mul(i).mul(e).mul(s || 1).div(r).toNumber()
            }

            function d(t, e, i, r, s, a) {
                return i ? (0, o.Big)(t).mul(r).mul(e).mul(a || 1).mul(100).div(i).div(s).toNumber() : 0
            }
        },
        80160: (t, e, i) => {
            i.r(e), i.d(e, {
                ExecutionsService: () => c
            });
            var o = i(88537),
                r = i(2683),
                s = i(1397),
                a = i(7053),
                l = i(97496),
                n = i.n(l),
                d = i(50681);
            class c extends a.BrokerService {
                constructor(t, e, i) {
                    super(t), this._allExecutionsID = new Set, this._executions = [], this._executionsAdded = new(n()), this._executionsCleared = new(n()), this._formatter = new s.PriceFormatter, this._symbol = "", this._dataEvents = e, this._getSymbolName = i, this._initialized = !0, this._tryToStart()
                }
                destroy() {
                    this.stopService()
                }
                formatter() {
                    return this._formatter
                }
                executions() {
                    return this._executions
                }
                executionsAdded() {
                    return this._executionsAdded
                }
                executionsCleared() {
                    return this._executionsCleared
                }
                startService() {
                    var t;
                    (null === (t = this.activeBroker()) || void 0 === t ? void 0 : t.config.supportExecutions) && (this._canBeStarted = !0, this._tryToStart())
                }
                stopService() {
                    this._canBeStarted = !1, this._isStarted && this._stop()
                }
                _tryToStart() {
                    (0, o.assert)(!this._isStarted, "Execution's service has already started"), this._canBeStarted && this._initialized && this._start()
                }
                _start() {
                    (0, o.assert)(!this._isStarted, "Execution's service has already started"), this._isStarted = !0, this._dataEvents.symbolResolved().subscribe(this, this._createExecutions), this._dataEvents.symbolError().subscribe(this, this._createExecutions), this._createExecutions()
                }
                _stop() {
                    this._isStarted = !1, this._clearExecutions();
                    (0, o.ensure)(this.activeBroker()).executionUpdate.unsubscribeAll(this), this._dataEvents.symbolResolved().unsubscribeAll(this), this._dataEvents.symbolError().unsubscribeAll(this)
                }
                _createExecutions() {
                    this._clearExecutions(), this._symbol = this._getSymbolName(), this._symbol && this._requestFormatterAndExecutions()
                }
                _clearExecutions() {
                    this._allExecutionsID = new Set, this._executions = [], this._executionsCleared.fire()
                }
                async _requestFormatterAndExecutions() {
                    const t = this.activeBroker();
                    if (!t) return;
                    if (!this._symbol) return;
                    if (!(await t.isTradable(this._symbol)).tradable) return;
                    const e = this._symbol;
                    Promise.all([t.formatter(this._symbol, !1), t.executions(this._symbol)]).then(([i, o]) => {
                        this._symbol === e && (this._formatter = i,
                            this._executions = o.map(t => this._createExecutionData(t)).filter(r.notNull), this._executionsAdded.fire(this._executions), t.executionUpdate.unsubscribeAll(this), t.executionUpdate.subscribe(this, this._addExecution))
                    })
                }
                _addExecution(t) {
                    const e = this._createExecutionData(t);
                    null !== e && this._executionsAdded.fire([e])
                }
                _createExecutionData(t) {
                    return t.symbol !== this._symbol || this._allExecutionsID.has(t.id) ? null : (this._allExecutionsID.add(t.id), { ...t,
                        tooltip: (0, d.executionText)(t, this._formatter)
                    })
                }
            }
        },
        30050: (t, e, i) => {
            i.r(e), i.d(e, {
                ExecutionsPointsManager: () => l
            });
            var o = i(42894),
                r = i(97496),
                s = i.n(r);

            function a(t) {
                return void 0 !== t.index
            }
            class l {
                constructor(t, e, i) {
                    this._points = [], this._existingExecutionPointsCache = null, this._offsetOfFirstExistingPoint = null, this._existingPointsChanged = new(s()), this._pointsets = [], this._pointsetManagerFactory = e, this._firstSeriesTimePointWV = i, this._firstSeriesTimePointWV.subscribe(this._updateExistingPoints.bind(this)), this._executionsService = t, this._addPoints(this._executionsService.executions()), this._executionsService.executionsAdded().subscribe(this, this._addPoints), this._executionsService.executionsCleared().subscribe(this, this._clearPoints)
                }
                destroy() {
                    this._clearPoints(), this._firstSeriesTimePointWV.destroy(), this._executionsService.executionsAdded().unsubscribeAll(this), this._executionsService.executionsCleared().unsubscribeAll(this), this._executionsService.destroy()
                }
                existingPoints() {
                    return null === this._offsetOfFirstExistingPoint ? [] : (null === this._existingExecutionPointsCache && (this._existingExecutionPointsCache = this._points.slice(this._offsetOfFirstExistingPoint).filter(a)), this._existingExecutionPointsCache)
                }
                existingPointsChanged() {
                    return this._existingPointsChanged
                }
                _onExistingStartPointChanged() {
                    this._existingExecutionPointsCache = null, this._existingPointsChanged.fire(this.existingPoints())
                }
                _addPoints(t) {
                    if (0 === t.length) return;
                    const e = function(t) {
                        return t.map(t => {
                            const e = Math.round(t.time / 1e3);
                            return {
                                id: t.id,
                                price: t.price,
                                time_t: e,
                                index: void 0,
                                isBuyDirection: 1 === t.side,
                                tooltip: t.tooltip
                            }
                        })
                    }(t);
                    e.sort((t, e) => t.time_t - e.time_t);
                    let i = 0;
                    const r = this._points.length > 0;
                    r && (i = (0, o.upperbound)(this._points, e[0].time_t, (t, e) => e.time_t > t, 0)), this._points = this._points.slice(0, i).concat(e).concat(this._points.slice(i));
                    const s = this._firstSeriesTimePointWV.value();
                    null !== this._offsetOfFirstExistingPoint && null !== s && e[0].time_t < s ? this._offsetOfFirstExistingPoint = this._offsetOfFirstExistingPoint + e.length : ((null === this._offsetOfFirstExistingPoint || e[0].time_t < this._points[this._offsetOfFirstExistingPoint].time_t) && (this._offsetOfFirstExistingPoint = this._calcOffsetOfFirstExistingPoint()), null !== this._offsetOfFirstExistingPoint && (r ? i >= this._offsetOfFirstExistingPoint && this._sendPointsToServer(i, i + e.length) : this._sendPointsToServer(this._offsetOfFirstExistingPoint, this._points.length)))
                }
                _updateExistingPoints() {
                    const t = this._calcOffsetOfFirstExistingPoint();
                    null !== t && (null === this._offsetOfFirstExistingPoint && (this._offsetOfFirstExistingPoint = this._points.length),
                        t < this._offsetOfFirstExistingPoint && (this._sendPointsToServer(t, this._offsetOfFirstExistingPoint), this._offsetOfFirstExistingPoint = t))
                }
                _clearPoints() {
                    for (const t of this._pointsets) t.onUpdate().unsubscribeAll(this), t.destroy();
                    this._pointsets = [], this._points = [], this._offsetOfFirstExistingPoint = null, this._onExistingStartPointChanged()
                }
                _sendPointsToServer(t, e) {
                    const i = this._points.slice(t, e).map(t => ({
                        time_t: t.time_t,
                        offset: 0
                    }));
                    if (0 === i.length) return;
                    const o = this._pointsetManagerFactory(i);
                    null !== o && (o.onUpdate().subscribe(this, this._updatePointsFromServer), this._pointsets.push(o))
                }
                _updatePointsFromServer(t) {
                    if (null === this._offsetOfFirstExistingPoint) return;
                    const e = (0, o.lowerbound)(this._points, t[0].time_t, (t, e) => t.time_t < e, this._offsetOfFirstExistingPoint);
                    let i = Math.max(this._offsetOfFirstExistingPoint, e);
                    for (const e of t)
                        for (let t = i; t < this._points.length && (i = t, !(this._points[t].time_t > e.time_t)); t++) this._points[t].time_t === e.time_t && (this._points[t].index = e.index);
                    this._onExistingStartPointChanged()
                }
                _calcOffsetOfFirstExistingPoint() {
                    const t = this._firstSeriesTimePointWV.value();
                    return null === t ? null : (0, o.upperbound)(this._points, t, (t, e) => e.time_t > t, 0, this._offsetOfFirstExistingPoint || this._points.length)
                }
            }
        },
        26945: (t, e, i) => {
            i.r(e), i.d(e, {
                ExecutionsSource: () => L
            });
            var o = i(70120),
                r = i(82527),
                s = i(88537),
                a = i(2996),
                l = i(42894),
                n = i(35368),
                d = i(95935),
                c = i(91084),
                h = i(66425),
                u = i(27905),
                _ = i(42265),
                p = i(36267);
            const b = 2,
                m = 12,
                v = 6,
                f = 10,
                y = "normal";
            class P {
                constructor() {
                    this._data = {
                        points: [],
                        labels: [],
                        arrowHeight: 0,
                        arrowSpacing: 0
                    }, this._textWidthCache = new u.TextWidthCache, this._font = (0, _.makeFont)(m, h.CHART_FONT_FAMILY, y)
                }
                setData(t) {
                    this._data = t
                }
                hitTest(t) {
                    for (const e of this._data.points) {
                        const i = Math.round(e.x),
                            o = Math.round(e.y),
                            r = 2 * b;
                        let s, a;
                        if (e.arrowUp ? (s = o, a = o + this._data.arrowHeight + this._data.arrowSpacing) : (s = o - this._data.arrowHeight - this._data.arrowSpacing, a = o), t.x >= i - b && t.x <= i + b && t.y >= s && t.y <= a && "" !== e.tooltip) {
                            const t = {
                                activeItem: e.id
                            };
                            return e.tooltip && (t.tooltip = {
                                below: !1,
                                text: e.tooltip,
                                rect: {
                                    x: i - b,
                                    y: s,
                                    w: r,
                                    h: a - s
                                }
                            }), new c.HitTestResult(c.HitTestResult.CUSTOM, t)
                        }
                    }
                    return null
                }
                draw(t, e) {
                    const i = e.pixelRatio;
                    t.save(), t.lineWidth = Math.max(1, Math.floor(t.lineWidth * i));
                    const o = 2 * b,
                        r = Math.max(1, Math.round(o * i)),
                        s = Math.max(1, Math.round(this._data.arrowHeight * i));
                    for (const e of this._data.points) {
                        const o = Math.round((e.x - b) * i),
                            a = Math.round(e.y * i);
                        (0, p.drawArrow)(t, o, a, e.arrowColor, e.outlineColor, !e.arrowUp, s, r, !1)
                    }
                    for (const e of this._data.labels) {
                        const o = Math.round((e.x - b) * i),
                            r = Math.round(e.y * i);
                        (0, p.drawOutlinedText)(t, i, e.text, o, r, this._textYMidCorrection(t, e.text), e.color, this._font, e.outlineColor)
                    }
                    if (this._data.executionEntryPoint) {
                        const e = Math.round((this._data.executionEntryPoint.x - v / 2) * i),
                            o = Math.round(this._data.executionEntryPoint.y * i),
                            r = Math.max(1, Math.round(f * i)),
                            s = Math.max(1, Math.round(v * i));
                        (0, p.drawOutlinedArrowHead)(t, e, o, this._data.executionEntryPoint.arrowColor, this._data.executionEntryPoint.outlineColor, r, s)
                    }
                    t.restore()
                }
                _textYMidCorrection(t, e) {
                    if (!e) return 0;
                    const i = t.font;
                    t.font = (0, s.ensureNotNull)(this._font);
                    const o = Math.ceil(this._textWidthCache.yMidCorrection(t, e));
                    return t.font = i, o
                }
            }
            var g = i(76036),
                C = i(28978);
            const x = a.colorsPalette["color-tv-blue-500"],
                k = a.colorsPalette["color-ripe-red-500"],
                T = {
                    textColor: a.colorsPalette["color-cold-gray-200"],
                    overlayColor: (0, g.generateColor)(a.colorsPalette["color-cold-gray-900"], 50),
                    outlineColor: a.colorsPalette["color-cold-gray-900"]
                },
                S = {
                    textColor: a.colorsPalette["color-cold-gray-900"],
                    overlayColor: (0, g.generateColor)(a.colorsPalette["color-white"], 50),
                    outlineColor: a.colorsPalette["color-white"]
                };
            const w = {
                    ArrowHeight: 8,
                    ArrowSpacing: 11,
                    ArrowToBarSpacing: 11,
                    LabelSpacing: 15,
                    ArrowToLabelSpacing: 10
                },
                M = a.colorsPalette["color-tv-blue-500"],
                I = a.colorsPalette["color-ripe-red-500"];
            class B {
                constructor(t, e) {
                    this._invalidated = !0, this._points = [], this._renderer = new P, this._chartModel = t, this._source = e
                }
                update() {
                    this._invalidated = !0
                }
                renderer() {
                    return this._invalidated && (this._updateImpl(), this._invalidated = !1), this._renderer
                }
                _updateImpl() {
                    this._renderer.setData({
                        points: [],
                        labels: [],
                        arrowHeight: 0,
                        arrowSpacing: 0
                    }), this._points = [];
                    const t = this._chartModel.timeScale().visibleBarsStrictRange();
                    if (null === t) return;
                    const e = this._source.points();
                    if (0 === e.length) return;
                    const i = (0, l.lowerbound)(e, t.firstBar(), (t, e) => t.index < e, 0),
                        o = (0, l.upperbound)(e, t.lastBar(), (t, e) => e.index > t, i);
                    if (i >= o) return;
                    const r = e.slice(i, o),
                        a = (r.find(t => this._source.hoveredExecution() === t.id), this._chartModel.mainSeries().priceScale().isInverted()),
                        n = new Map,
                        d = function(t) {
                            const e = t ? T : S,
                                {
                                    textColor: i,
                                    outlineColor: o
                                } = e,
                                r = (0, C.blendColors)(x, e.overlayColor),
                                s = (0, C.blendColors)(k, e.overlayColor);
                            return {
                                buyArrowColor: x,
                                sellArrowColor: k,
                                inactiveBuyArrowColor: r,
                                inactiveSellArrowColor: s,
                                textColor: i,
                                outlineColor: o
                            }
                        }(this._chartModel.isDark());
                    let c;
                    for (const t of r) {
                        const e = n.get(t.index) || D(a);
                        if (void 0 === e.x) {
                            const i = this._getXCoordinate(t.index);
                            if (null === i) continue;
                            e.x = i
                        }
                        const i = t.isBuyDirection !== a,
                            o = i ? "arrowUp" : "arrowDown",
                            r = i ? 1 : -1,
                            l = e[o].y;
                        if (void 0 === l) {
                            const i = this._getYCoordinate(t.index, t.isBuyDirection);
                            if (null === i) continue;
                            e[o].y = i + r * w.ArrowToBarSpacing
                        } else e[o].y = l + r * (w.ArrowHeight + w.ArrowSpacing);
                        n.set(t.index, e), this._points.push({
                            id: t.id,
                            x: (0, s.ensureDefined)(e.x),
                            y: (0, s.ensureDefined)(e[o].y),
                            arrowUp: i,
                            arrowColor: e[o].color,
                            outlineColor: d.outlineColor,
                            tooltip: this._source.isLabelsVisible() ? void 0 : t.tooltip
                        })
                    }
                    const h = [];
                    this._renderer.setData({
                        points: this._points,
                        labels: h,
                        executionEntryPoint: c,
                        arrowHeight: w.ArrowHeight,
                        arrowSpacing: w.ArrowSpacing
                    })
                }
                _getXCoordinate(t) {
                    const e = this._chartModel.mainSeries().bars().lastIndex();
                    return null === e || t > e ? null : this._chartModel.timeScale().indexToCoordinate(t)
                }
                _getYCoordinate(t, e) {
                    let i = null;
                    const o = this._chartModel.mainSeries(),
                        r = o.priceSource(),
                        s = null !== r ? r : e ? "low" : "high",
                        a = (0, n.barFunction)(s),
                        l = o.nearestData(t, d.PlotRowSearchMode.NearestLeft);
                    if (void 0 !== l) {
                        const t = a(l.value);
                        Number.isNaN(t) || (i = this._priceToCoordinate(t))
                    }
                    return i
                }
                _priceToCoordinate(t) {
                    const e = this._chartModel.mainSeries(),
                        i = e.firstValue();
                    return i ? e.priceScale().priceToCoordinate(t, i) : null
                }
            }

            function D(t) {
                let e, i;
                return t ? (e = I, i = M) : (e = M, i = I), {
                    x: void 0,
                    arrowUp: {
                        y: void 0,
                        color: e
                    },
                    arrowDown: {
                        y: void 0,
                        color: i
                    }
                }
            }
            class L extends o.CustomSourceBase {
                constructor(t, e, i, o, r, s) {
                    super(t, e), this._paneViews = [], this._executionsPointsManager = s, this._executionsPointsManager.existingPointsChanged().subscribe(this, this.redraw), this._showExecutions = o.arrowVisibility, this._showExecutionLabels = o.labelVisibility, this._globalVisibility = r, this._globalVisibility.subscribe(this.redraw.bind(this)), this._paneViews.push(new B(e, this))
                }
                destroy() {
                    this._executionsPointsManager.existingPointsChanged().unsubscribeAll(this), this._executionsPointsManager.destroy(), this._showExecutions.destroy(), this._globalVisibility.unsubscribe()
                }
                redraw() {
                    this.updateAllViews(), this._model.updateSource(this)
                }
                points() {
                    return this._executionsPointsManager.existingPoints()
                }
                updateAllViews() {
                    for (const t of this._paneViews) t.update()
                }
                paneViews(t) {
                    return this._isSourceShouldBeShown(t) ? this._paneViews : []
                }
                hoveredExecution() {
                    const t = this._model.hoveredSource() === this && this._model.lastHittestData() || null;
                    return null === t || void 0 === t.activeItem ? null : t.activeItem
                }
                isLabelsVisible() {
                    return this._showExecutionLabels.value()
                }
                _isSourceShouldBeShown(t) {
                    return !!this._globalVisibility.value() && (!!t.containsMainSeries() && (!!this._showExecutions.value() && !(window.TradingView.printing && !r.enabled("snapshot_trading_drawings"))))
                }
            }
        },
        51466: (t, e, i) => {
            i.d(e, {
                TradedSource: () => Le,
                isTradedSource: () => Me
            });
            var o = i(88537),
                r = i(25177),
                s = i(2683),
                a = i(24818),
                l = i(51763),
                n = i(70120),
                d = i(82527);

            function c(t, e) {
                (0, o.assert)(!(t.origin && e.origin || t.event && e.event), "origin and event should be only in one params object");
                const i = { ...t,
                    ...e
                };
                return t.label && e.label && (i.label = `${t.label} ${e.label}`), i
            }
            var h = i(93751),
                u = i(86441),
                _ = i(1962),
                p = i(44963),
                b = i(50317),
                m = i(90687);

            function v(t, e, i, o) {
                return (t - e) / o * (1 === i ? -1 : 1)
            }
            var f = i(18833),
                y = i(9696);
            (0, r.t)("No overlap orders and positions");
            async function P(t, e, i) {
                return y.ContextMenuManager.createMenu(t, {}, {
                    menuName: "TradingOrderContextMenu"
                }, i).then(t => (t.show(e), t))
            }
            async function g(t) {
                return null
            }
            const C = (0, f.appendEllipsis)((0, r.t)("Modify Order")),
                x = (0, r.t)("Cancel Order");
            var k = i(72249),
                T = i(54620),
                S = i(1397),
                w = i(97496),
                M = i.n(w),
                I = i(76337),
                B = i(8329),
                D = i(9016),
                L = i(34581);

            function R(t, e) {
                return `${t>0?"+":t<0?"−":""}${e?" ":""}`
            }
            const O = {
                integerFormatter: new B.NumericFormatter(0),
                oneDecimalFormatter: new B.NumericFormatter(1),
                twoDecimalFormatter: new B.NumericFormatter(2)
            };
            class W {
                constructor(t, e, i, o, r, s, a) {
                    this._symbolData = {
                        minTick: 1,
                        pipSize: 1,
                        lotSize: 1,
                        quantityFormatter: new T.QuantityFormatter,
                        priceFormatter: new S.PriceFormatter
                    }, this._contextMenu = null, this._last = null, this._profitLossChanged = new(M()), this._currency = null, this._mainSeries = i, this._source = e, this._symbolDataProvider = o, this._symbolData.minTick = 1 / this._mainSeries.base(), this._gaOrigin = r, this._infoGetters = s, this._itemCommands = a, this._updateLastHandler = this._updateLast.bind(this), this.setData(t), this._formatPlWV = (0, I.createWVFromGetterAndSubscription)(() => this.profitLossText(), this._profitLossChanged), this._plColorWV = (0,
                        I.createWVFromGetterAndSubscription)(() => this.profitLossTextColor(), this._profitLossChanged)
                }
                clearRealtime() {
                    this._symbolDataProvider.unsubscribeRealtime(this._data.symbol, this._updateLastHandler), this._symbolDataProvider.onStatusChanged.unsubscribeAll(this)
                }
                subscribeRealtime() {
                    this._symbolDataProvider.subscribeRealtime(this._data.symbol, this._updateLastHandler), this._symbolDataProvider.onStatusChanged.subscribe(this, this._updateSymbolData), this._updateSymbolData()
                }
                destroy() {
                    var t;
                    this.clearRealtime(), this._formatPlWV.destroy(), this._plColorWV.destroy(), this._profitLossChanged.destroy(), null === (t = this._contextMenu) || void 0 === t || t.hide()
                }
                id() {
                    return this._data.id
                }
                data() {
                    return this._data
                }
                price() {
                    return this._data.price
                }
                setData(t) {
                    this._data = (0, s.clone)(t)
                }
                priceText() {
                    return this._symbolData.priceFormatter.format((0, o.ensureNotNull)(this._data.price))
                }
                supportBrackets() {
                    return this._data.supportBrackets
                }
                supportOnlyPairBrackets() {
                    return this._data.supportOnlyPairBrackets
                }
                hasContextMenu() {
                    return this.supportModify() || this.supportClose()
                }
                isBuyDirection() {
                    return 1 === this._data.side
                }
                isVisible() {
                    return this._infoGetters.visibility()
                }
                async updateCurrency(t) {
                    null === this._currency && (this._currency = "", this._currency = await this._infoGetters.currency(t), this._profitLossChanged.fire(), this._source.redraw())
                }
                fireProfitLossChange() {
                    this._profitLossChanged.fire()
                }
                currency() {
                    var t;
                    return null !== (t = this._currency) && void 0 !== t ? t : ""
                }
                profitLossText(t) {
                    if (!this._data) return "";
                    const e = this._potentialProfitLoss();
                    if (null === e) return "";
                    let i;
                    switch (this._infoGetters.displayMode.value()) {
                        case _.PlDisplay.Money:
                            i = this.moneyText(e, !0);
                            break;
                        case _.PlDisplay.Pips:
                            i = this.pipsText(e, !0);
                            break;
                        case _.PlDisplay.Percentage:
                            i = this.percentageText(e, !0)
                    }
                    return (0, L.startWithLTR)(i)
                }
                percentageText(t, e) {
                    var i;
                    const o = R(t, e),
                        r = this._source.baseItem(),
                        s = null !== (i = null == r ? void 0 : r.price()) && void 0 !== i ? i : null;
                    if (null === s) return "";
                    const a = 100 * t / s * this._data.side;
                    return `${o}${(0,k.splitThousands)(O.twoDecimalFormatter.format(Math.abs(a))," ")}%`
                }
                moneyText(t, e) {
                    var i;
                    const o = R(t, e),
                        r = t / (this._symbolData.pipSize || this._symbolData.minTick) * this._data.side,
                        s = null === (i = this._source.pipValueWV()) || void 0 === i ? void 0 : i.value();
                    if (void 0 === s) return "";
                    const a = this.isBuyDirection() ? s.buyPipValue : s.sellPipValue,
                        l = Math.abs((0, D.pipsToRiskInCurrency)(r, this._data.qty, a, 1, this._symbolData.lotSize));
                    return `${o}${O.twoDecimalFormatter.format(l)} ${this.currency()}`
                }
                pipsText(t, e) {
                    const i = R(t, e),
                        o = isFinite(this._symbolData.pipSize) && this._symbolData.pipSize !== this._symbolData.minTick ? O.oneDecimalFormatter : O.integerFormatter,
                        s = parseFloat(o.format(t / (this._symbolData.pipSize || this._symbolData.minTick))) * this._data.side;
                    if (this._source.pipValueType() === a.PipValueType.Pips) {
                        return `${i}${(0,r.t)("{pips} pip",{plural:"{pips} pips",count:Math.abs(s)}).replace("{pips}",(0,k.splitThousands)(Math.abs(s).toFixed(1)," "))}`
                    }
                    if (this._source.pipValueType() === a.PipValueType.Ticks) {
                        return `${i}${(0,r.t)("{ticks} tick",{plural:"{ticks} ticks",count:Math.abs(s)}).replace("{ticks}",(0,
k.splitThousands)(Math.abs(s).toFixed(0)," "))}`
                    }
                    return ""
                }
                tryBasePlOnLast() {
                    return !1
                }
                async _updateSymbolData() {
                    const [t, e, i] = await Promise.all([this._symbolDataProvider.quantityFormatter(this._data.symbol), this._symbolDataProvider.formatter(this._data.symbol), this._symbolDataProvider.symbolInfo(this._data.symbol)]);
                    this._symbolData.quantityFormatter = t, this._symbolData.priceFormatter = e, this._symbolData.minTick = i.minTick, this._symbolData.pipSize = i.pipSize, this._symbolData.lotSize = i.lotSize, this._source.redraw()
                }
                _trackEventGA(t) {
                    const {
                        origin: e = this._gaOrigin,
                        event: i,
                        label: r
                    } = t;
                    (0, o.assert)(!!i, "GA Event shouldn' be empty"), this._itemCommands.trackEvent(e, i, r)
                }
                _quantityText(t) {
                    return this._symbolData.quantityFormatter.format(t)
                }
            }
            const V = (0, r.t)("Trailing Stop"),
                A = (0, r.t)("Stop Loss"),
                H = (0, r.t)("Take Profit"),
                E = (0, r.t)("TS", {
                    context: "Trailing stop"
                }),
                N = (0, r.t)("SL", {
                    context: "Stop loss"
                }),
                F = (0, r.t)("TP", {
                    context: "Take profit"
                }),
                q = d.enabled("chart_hide_close_order_button");

            function j(t) {
                return 3 === t.type ? t.stopType === p.StopType.TrailingStop ? a.BracketType.TrailingStop : a.BracketType.StopLoss : 1 === t.type ? a.BracketType.TakeProfit : null
            }
            class z extends W {
                constructor(t, e, i, o, r, s) {
                    super(t, e, i, o, "Chart Order", r, s), this._inEdit = !1, this._isBracket() && this._source.bracketsDisplayMode().subscribe(this, this.fireProfitLossChange)
                }
                destroy() {
                    var t;
                    this._symbolDataProvider.onStatusChanged.unsubscribeAll(this), this._source.bracketsDisplayMode().unsubscribe(this, this.fireProfitLossChange), null === (t = this._contextMenu) || void 0 === t || t.hide()
                }
                id() {
                    return this._id
                }
                setData(t) {
                    this._inEdit || (super.setData(t), this.fireProfitLossChange(), this._id = this._calcId())
                }
                setInEdit(t) {
                    this._inEdit = t
                }
                type() {
                    return this._data.type
                }
                bracketType() {
                    return this._isBracket() ? j(this._data) : null
                }
                qtyText() {
                    return super._quantityText(this._data.considerFilledQty ? this._data.qty - (this._data.filledQty || 0) : this._data.qty)
                }
                qty() {
                    return this._data.qty
                }
                isWorking() {
                    return 6 === this._data.status
                }
                profitLossText(t) {
                    var e;
                    return this._data && this._isBracket() && (null === (e = this._source.isBracketsPLVisible()) || void 0 === e ? void 0 : e.value()) && this.bracketType() !== a.BracketType.TrailingStop ? super.profitLossText(t) : this._bracketTypeText(t)
                }
                supportOnlyPairBrackets() {
                    return !1
                }
                profitLossTextColor() {
                    if (!this._data) return "";
                    const t = this._infoGetters.style(this);
                    if (!this._isBracket()) return t.text.textColor;
                    const e = this._potentialProfitLoss();
                    return null === e ? t.text.textColor : e > 0 ? t.positivePlColor : e < 0 ? t.negativePlColor : t.text.textColor
                }
                profitLossTooltip() {
                    var t;
                    const e = this._source.mainItem(),
                        i = null == e ? void 0 : e.price();
                    if (null == i || !this._isBracket()) return "";
                    const o = this._potentialProfitLoss();
                    if (null === o) return "" + this._bracketTypeText();
                    if (!(null === (t = this._source.isBracketsPLVisible()) || void 0 === t ? void 0 : t.value()) || this.bracketType() === a.BracketType.TrailingStop) return "";
                    switch (this._infoGetters.displayMode.value()) {
                        case _.PlDisplay.Money:
                            return `${this._bracketTypeText()} ${this.percentageText(o)} ${this.pipsText(o)}`;
                        case _.PlDisplay.Percentage:
                            return `${this._bracketTypeText()} ${this.moneyText(o)} ${this.pipsText(o)}`;
                        case _.PlDisplay.Pips:
                            return `${this._bracketTypeText()} ${this.moneyText(o)} ${this.percentageText(o)}`;
                        default:
                            return `${this._bracketTypeText()} ${this.pipsText(o)} ${this.percentageText(o)} ${this.moneyText(o)}`
                    }
                }
                supportModify() {
                    return Boolean(this._data.callbacks.modifyOrder)
                }
                async onModify(t = {}, e, i) {
                    this._source.setIsBlocked(!0);
                    const r = (0, s.clone)(this._data);
                    await this._addTrailingStopPipsData(r), this._trackEventGA(c(t, {
                        event: "Edit Order"
                    }));
                    const a = await (0, o.ensureDefined)(this._data.callbacks.modifyOrder)(r.id, r, e, i);
                    return this._source.setIsBlocked(!1), this._source.syncData(), a
                }
                isMovingEnabled() {
                    return Boolean(this._data.callbacks.moveOrder)
                }
                calcPriceDiff(t) {
                    const e = new u.Point(t.localX, t.localY),
                        i = this._mainSeries.priceScale(),
                        r = this._mainSeries.firstValue();
                    if (null === r) return null;
                    const s = (0, o.ensureNotNull)(this._data.price);
                    return i.coordinateToPrice(e.y, r) - s
                }
                applyPriceDiff(t) {
                    this._inEdit = !0;
                    const e = (0, o.ensureNotNull)(this._data.price);
                    this._data.price = (0, h.fixComputationError)(this._symbolData.minTick * Math.round((t + e) / this._symbolData.minTick))
                }
                onMove(t) {
                    const e = this.calcPriceDiff(t);
                    null !== e && (this.applyPriceDiff(e), t.isTouch && (0, o.ensureDefined)(this._itemCommands.exitTrackingMode)())
                }
                async onFinishMove(t = {}, e = {}, i = !0, r, a = !0) {
                    var l, n, d;
                    i && this._source.setIsBlocked(!0);
                    const c = (0, s.clone)(this._data),
                        h = (0, o.ensureNotNull)(c.price);
                    if (c.limitPrice = null !== (l = e.limitPrice) && void 0 !== l ? l : c.limitPrice, c.takeProfit = null !== (n = e.takeProfit) && void 0 !== n ? n : c.takeProfit, c.stopLoss = null !== (d = e.stopLoss) && void 0 !== d ? d : c.stopLoss, c.stopPrice ? c.stopPrice = h : c.limitPrice && (c.limitPrice = h), await this._addTrailingStopPipsData(c, e.trailingStop), this._trackEventGA(t), !this._data.callbacks.moveOrder && !this._data.supportModifyOrderPrice) {
                        const t = (0, o.ensureDefined)(this._data.callbacks.modifyOrder)(c.id, c, r, a);
                        return this._inEdit = !1, t
                    }
                    const u = (0, o.ensureDefined)(this._data.callbacks.moveOrder)(c.id, c, r);
                    return this._inEdit = !1, u
                }
                supportClose() {
                    return !q && Boolean(this._data.callbacks.cancelOrder)
                }
                async onClose(t = {}) {
                    this._source.isBlocked() || (this._source.setIsBlocked(!0), this._trackEventGA(c(t, {
                        event: "Cancel Order"
                    })), await (0, o.ensureDefined)(this._data.callbacks.cancelOrder)(this._data.id), this._source.setIsBlocked(!1), this._source.syncData())
                }
                hasContextMenu() {
                    return super.hasContextMenu() || this.isMovingEnabled()
                }
                async onContextMenu(t, e) {
                    this.fireProfitLossChange();
                    const i = {};
                    e = c(e, {
                        origin: "Chart Order Context Menu"
                    }), this.supportClose() && (i.cancelOrder = this.onClose.bind(this, e)), this.supportModify() && (i.modifyOrder = this.onModify.bind(this, e));
                    (0, b.sideToText)(this._data.side), this.qtyText(), this.priceText(), (0, b.orderTypeToText)(this._data.type), this._isBracket() && this._formatPlWV;
                    const o = await async function(t, e) {
                            const i = [],
                                o = t.modifyOrder,
                                r = await g();
                            r && i.push(r), void 0 !== o && i.push(new m.Action({
                                actionId: "Trading.EditOrder",
                                label: C,
                                onExecute: o
                            }));
                            const s = t.cancelOrder;
                            return void 0 !== s && i.push(new m.Action({
                                actionId: "Trading.CancelOrder",
                                label: x,
                                onExecute: s
                            })), i
                        }(i),
                        r = this._infoGetters.noOverlapAction(e, t => this._trackEventGA(t));
                    r && (o.push(new m.Separator), o.push(r)), this._contextMenu = await P(o, t, () => {
                        this._contextMenu = null
                    })
                }
                _calcId() {
                    return void 0 !== this._data.parentId ? (0, o.ensureNotNull)(j(this._data)) : this._data.id
                }
                async _addTrailingStopPipsData(t, e) {
                    const i = this._source.mainItem();
                    if (i) {
                        const {
                            side: r,
                            type: s,
                            stopPrice: a,
                            limitPrice: l
                        } = i.data(), {
                            pipSize: n
                        } = await this._symbolDataProvider.symbolInfo(this._data.symbol);
                        if (void 0 !== e) {
                            const i = (0, o.ensureDefined)(t.stopPrice || t.limitPrice);
                            t.trailingStopPips = v(e, i, r, n)
                        } else if (t.parentId && t.stopType === p.StopType.TrailingStop) {
                            const {
                                bid: e,
                                ask: d
                            } = await this._symbolDataProvider.quotesSnapshot(t.symbol);
                            let c;
                            c = i instanceof z ? 3 === s ? a : l : 1 === r ? e : d, t.trailingStopPips = v((0, o.ensureDefined)(t.stopPrice || t.limitPrice), c, r, n)
                        }
                    }
                    return t
                }
                _bracketTypeText(t) {
                    if (!this._data) return "";
                    if (this._isBracket()) {
                        const e = function(t, e, i) {
                            return 3 === t ? e === p.StopType.TrailingStop ? i ? E : V : i ? N : A : 1 === t ? i ? F : H : null
                        }(this._data.type, this._data.stopType, t);
                        if (null !== e) return e
                    }
                    return t ? (0, b.orderTypeToText)(this._data.type, !0, !0) : `${(0,b.sideToText)(this._data.side)} ${(0,b.orderTypeToText)(this._data.type,!1)}`
                }
                _potentialProfitLoss() {
                    const t = this._source.baseItem();
                    if (!this._data || !t) return null;
                    const e = this._data.price,
                        {
                            ask: i,
                            bid: o
                        } = this._last || {},
                        r = t.tryBasePlOnLast() && 3 === this._data.type && this._data.stopType === p.StopType.TrailingStop;
                    if (!(0, s.isNumber)(e)) return null;
                    const a = r ? this.isBuyDirection() ? i : o : t.price();
                    return (0, s.isNumber)(a) ? (a - e) * this._data.side : null
                }
                _updateLast(t, e) {
                    var i, o, r;
                    this._last = {
                        trade: null !== (i = e.trade) && void 0 !== i ? i : NaN,
                        ask: null !== (o = e.ask) && void 0 !== o ? o : NaN,
                        bid: null !== (r = e.bid) && void 0 !== r ? r : NaN
                    }, this._data.plBasedOnLast && this._isBracket() && (this.fireProfitLossChange(), this._source.redraw())
                }
                _isBracket() {
                    if (!this._data.parentId) return !1;
                    const t = this._source.mainItem();
                    return 1 !== this._data.parentType || void 0 !== t && t.data().side !== this._data.side
                }
            }
            var G = i(37978),
                U = i(51951);
            const $ = (0, f.appendEllipsis)((0, r.t)("Protect Position")),
                Q = (0, r.t)("Close Position"),
                Y = (0, r.t)("Reverse Position");
            const X = (0, U.getLogger)("Trading.Positions"),
                K = d.enabled("chart_hide_close_position_button");
            class J extends W {
                constructor(t, e, i, o, r, s) {
                    super(t, e, i, o, "Chart Position", r, s), this._source.positionDisplayMode().subscribe(this, this.fireProfitLossChange)
                }
                destroy() {
                    this._source.positionDisplayMode().unsubscribe(this, this.fireProfitLossChange), super.destroy()
                }
                profitLossTextColor() {
                    if (!this._data) return "";
                    const t = this._infoGetters.style(this);
                    switch (this._data.profitState) {
                        case "negative":
                            return t.negativePlColor;
                        case "positive":
                            return t.positivePlColor;
                        default:
                            return t.text.textColor
                    }
                }
                id() {
                    return super.id()
                }
                setData(t) {
                    var e;
                    const i = null === (e = this.data()) || void 0 === e ? void 0 : e.pl;
                    super.setData(t), this.data().pl !== i && this.fireProfitLossChange()
                }
                qtyText() {
                    return super._quantityText(this._data.qtyBySide)
                }
                qty() {
                    return this._data.qtyBySide
                }
                profitState() {
                    return this._data.profitState
                }
                supportReverse() {
                    return this._data.supportReverse
                }
                async onReverse(t = {}) {
                    t = c(t, {
                        event: "Reverse Position"
                    }), await this._doActionWithBlock("reversePosition", !0, t)
                }
                supportClose() {
                    return !K && this._data.supportClose
                }
                async onClose(t = {}) {
                    t = c(t, {
                        event: "Close Position"
                    }), await this._doActionWithBlock("closePosition", !0, t)
                }
                supportModify() {
                    return this._data.supportBrackets
                }
                async onModify(t = {}) {
                    return t = c(t, {
                        event: "Edit Position"
                    }), this._doActionWithBlock("modifyPosition", !0, t, void 0, void 0, !1)
                }
                async onModifyWithBracket(t = {}, e = {}, i = !0, o, r = !0) {
                    var s, a;
                    if (void 0 !== e.trailingStop && (null === (s = this._last) || void 0 === s ? void 0 : s.bid) && (null === (a = this._last) || void 0 === a ? void 0 : a.ask)) {
                        const t = 1 === this._data.side ? this._last.bid : this._last.ask;
                        e.trailingStopPips = v(e.trailingStop, t, this._data.side, this._symbolData.pipSize), e.trailingStop = void 0
                    }
                    return this._doActionWithBlock("modifyPosition", i, t, e, o, r)
                }
                hasContextMenu() {
                    return super.hasContextMenu() || this.supportReverse()
                }
                moneyText(t, e) {
                    return `${R(t,e)}${Math.abs(t).toFixed(2)} ${this.currency()}`
                }
                async onContextMenu(t, e) {
                    this.fireProfitLossChange();
                    const i = {};
                    e = c(e, {
                        origin: "Chart Position Context Menu"
                    }), this.supportClose() && (i.closePosition = this.onClose.bind(this, e)), this.supportReverse() && (i.reversePosition = this.onReverse.bind(this, e)), this.supportModify() && (i.modifyPosition = this.onModify.bind(this, e));
                    (0, b.sideToText)(this._data.side), this.qtyText(), this.priceText(), this._formatPlWV, this._plColorWV;
                    const o = await async function(t, e) {
                            const i = [],
                                o = await g();
                            return o && i.push(o), void 0 !== t.modifyPosition && i.push(new m.Action({
                                actionId: "Trading.ModifyPosition",
                                label: $,
                                onExecute: t.modifyPosition
                            })), void 0 !== t.closePosition && i.push(new m.Action({
                                actionId: "Trading.ClosePosition",
                                label: Q,
                                onExecute: t.closePosition
                            })), void 0 !== t.reversePosition && i.push(new m.Action({
                                actionId: "Trading.ReversePosition",
                                label: Y,
                                onExecute: t.reversePosition
                            })), i
                        }(i),
                        r = this._infoGetters.noOverlapAction(e, t => this._trackEventGA(t));
                    r && (o.push(new m.Separator), o.push(r)), this._contextMenu = await P(o, t, () => {
                        this._contextMenu = null
                    })
                }
                tryBasePlOnLast() {
                    return !0
                }
                _potentialProfitLoss() {
                    var t;
                    if (!this._source.isPositionPLVisible().value() || !this._data) return null;
                    const {
                        pl: e,
                        side: i,
                        price: o
                    } = this._data;
                    if (null === e) return null;
                    if (this._infoGetters.displayMode.value() === _.PlDisplay.Money) return e;
                    const {
                        trade: r,
                        ask: a,
                        bid: l
                    } = this._last || {}, n = null !== (t = this._data.plBasedOnLast ? r : this.isBuyDirection() ? l : a) && void 0 !== t ? t : o;
                    return (0, s.isNumber)(n) ? (n - o) * i : null
                }
                _updateLast(t, e) {
                    var i, o, r, s, a, l;
                    (this._data.plBasedOnLast ? (null === (r = this._last) || void 0 === r ? void 0 : r.trade) !== e.trade : (null === (i = this._last) || void 0 === i ? void 0 : i.ask) !== e.ask || (null === (o = this._last) || void 0 === o ? void 0 : o.bid) !== e.bid) && (this._last = {
                        trade: null !== (s = e.trade) && void 0 !== s ? s : NaN,
                        ask: null !== (a = e.ask) && void 0 !== a ? a : NaN,
                        bid: null !== (l = e.bid) && void 0 !== l ? l : NaN
                    }, this._infoGetters.displayMode.value() !== _.PlDisplay.Money && this._source.redraw(), this.fireProfitLossChange())
                }
                async _doActionWithBlock(t, e, i = {}, r = {}, s, a) {
                    if (void 0 === this._data.callbacks[t]) return !1;
                    e && this._source.setIsBlocked(!0), this._trackEventGA(i);
                    let l = !1;
                    try {
                        l = "modifyPosition" === t ? await (0, o.ensureDefined)(this._data.callbacks.modifyPosition)(this._data.id, r, s, a) : await (0, o.ensureDefined)(this._data.callbacks[t])(this._data.id)
                    } catch (e) {
                        X.logWarn(`Try to ${t}, but got error: ${(0,G.errorToString)(e)}`)
                    } finally {
                        e && (this._source.setIsBlocked(!1), this._source.syncData())
                    }
                    return l
                }
            }
            var Z, tt = i(67912),
                et = i(76036),
                it = i(91604),
                ot = i(91084),
                rt = i(28303),
                st = i(1227),
                at = i(30551),
                lt = i(36267);

            function nt(t, e, i, o, r, s) {
                t.save(), t.fillStyle = s, t.fillRect(e, i, o, r), t.restore()
            }! function(t) {
                t[t.Position = 0] = "Position", t[t.WithBracketButtons = 1] = "WithBracketButtons", t[t.Projection = 2] = "Projection", t[t.Default = 3] = "Default"
            }(Z || (Z = {}));
            const dt = st.CheckMobile.any();
            class ct {
                constructor(t, e, i, o) {
                    this._height = dt ? 23 : 19, this._bodyBorderRadius = 4, this._font = null, this._offsets = null, this._alignedTop = null, this._cache = null, this._cacheWithOffset = null, this._wasSourceMoved = !1, this._textWidthCache = e, this._minMainTextWidthGetter = o, this._data = t, this._font = i, this._initCtx()
                }
                setFont(t) {
                    this._font !== t && (this._font = t, this.clearCache())
                }
                data() {
                    return this._data
                }
                clearCache() {
                    this._cache = null, this._cacheWithOffset = null
                }
                applyOffset(t) {
                    this._offsets = t, this.clearCache()
                }
                setAlignedTopCoordinate(t) {
                    this._alignedTop = t
                }
                hitTest(t, e) {
                    var i;
                    const r = this.rectWithOffsets(e),
                        s = e.pixelRatio,
                        a = Math.round(t.x * s),
                        l = Math.round(t.y * s),
                        n = a >= r.body.left,
                        d = a <= r.body.right,
                        c = n && d;
                    if (!(l >= r.top && l <= r.bottom) || !c) return null;
                    const h = {
                        cursorType: rt.PaneCursorType.Default,
                        hideCrosshairLinesOnHover: !0,
                        activeItem: {
                            id: this._data.id,
                            part: 6
                        }
                    };
                    if (this._data.disabled) return new ot.HitTestResult(ot.HitTestResult.CUSTOM, h);
                    let u = {};
                    if (void 0 !== this._data.callbacks.onMove) {
                        const t = t => {
                                var e;
                                (null === (e = this._data) || void 0 === e ? void 0 : e.callbacks.onMove) && this._data.callbacks.onMove(t), this._wasSourceMoved = !0
                            },
                            e = () => {
                                var t;
                                this._wasSourceMoved && (null === (t = this._data) || void 0 === t ? void 0 : t.callbacks.onFinishMove) && this._data.callbacks.onFinishMove(), this._wasSourceMoved = !1
                            };
                        u = {
                            cursorType: rt.PaneCursorType.Pointer,
                            pressedMouseMoveHandler: t,
                            touchMoveHandler: t,
                            mouseUpHandler: e,
                            touchEndHandler: e
                        }
                    }
                    const _ = this._data.callbacks.onContextMenu,
                        p = this._data.callbacks.onContextMenu,
                        b = { ...h,
                            ...u,
                            hasOwnShortcutsBehaviourFor: {
                                shiftKey: !0
                            },
                            contextMenuHandler: _,
                            touchContextMenuHandler: p
                        },
                        m = Math.round(r.body.left / s),
                        v = Math.round(r.top / s);
                    if (a >= r.close.left && d && void 0 !== this._data.callbacks.onClose) {
                        const t = Math.round(r.body.right / s),
                            e = Math.round(r.close.left / s);
                        return new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ...b,
                            activeItem: {
                                id: this._data.id,
                                part: 2
                            },
                            cursorType: rt.PaneCursorType.Default,
                            clickHandler: this._data.callbacks.onClose,
                            tapHandler: this._data.callbacks.onClose,
                            tooltip: {
                                extendMargin: !0,
                                text: (0, o.ensureDefined)(this._data.close).title,
                                rect: {
                                    x: e,
                                    y: v,
                                    w: t - e,
                                    h: this._height
                                }
                            }
                        })
                    }
                    if (a >= r.text.left && a < r.close.left) {
                        const t = Math.round(r.close.left / s),
                            e = Math.round(r.text.left / s);
                        return new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ...b,
                            tooltip: {
                                extendMargin: !0,
                                text: this._data.text.title,
                                rect: {
                                    x: e,
                                    y: v,
                                    w: t - e,
                                    h: this._height
                                }
                            }
                        })
                    }
                    if (null === (i = this._data.callbacks) || void 0 === i ? void 0 : i.allInteractionsHandler) return new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ...h,
                        clickHandler: this._data.callbacks.allInteractionsHandler,
                        tapHandler: this._data.callbacks.allInteractionsHandler,
                        contextMenuHandler: this._data.callbacks.allInteractionsHandler,
                        touchContextMenuHandler: this._data.callbacks.allInteractionsHandler
                    });
                    if (n && a < r.text.left && void 0 !== this._data.callbacks.onModify) {
                        const t = Math.round(r.text.left / s);
                        return new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ...b,
                            activeItem: {
                                id: this._data.id,
                                part: 1
                            },
                            cursorType: rt.PaneCursorType.Default,
                            clickHandler: this._data.callbacks.onModify,
                            tapHandler: this._data.callbacks.onModify,
                            tooltip: {
                                extendMargin: !0,
                                text: (0, o.ensureDefined)(this._data.qty).title,
                                rect: {
                                    x: m,
                                    y: v,
                                    w: t - m,
                                    h: this._height
                                }
                            }
                        })
                    }
                    return new ot.HitTestResult(ot.HitTestResult.CUSTOM, b)
                }
                drawBackground(t, e) {
                    !this._data.line.drawOnTop && this._data.visible && this._drawLine(t, e)
                }
                drawLine(t, e) {
                    this._isDataVisibleInViewport(e) && this._data.line.drawOnTop && this._data.visible && this._drawLine(t, e)
                }
                drawPointOnLine(t, e, i) {
                    if (!this._isDataVisibleInViewport(e) || !this._data.point.visible || !this._data.visible) return;
                    const o = this.rectWithOffsets(e),
                        r = Math.round(3 * e.pixelRatio),
                        s = Math.max(1, Math.floor(1 * e.pixelRatio)),
                        a = s / 2,
                        l = 2.5 * e.pixelRatio + a,
                        n = i + (a % 1 == 0 ? 0 : .5),
                        d = o.yMid + (a % 1 == 0 ? 0 : .5);
                    this._data.line.extend || this._data.bodyAlignment !== _.TradingSourcesHorizontalAlignment.Left || (t.save(), t.strokeStyle = this._data.line.color, t.lineWidth = Math.max(1, Math.floor(this._data.line.thickness * e.pixelRatio)), (0, it.setLineStyle)(t, this._data.line.style), (0, at.drawHorizontalLine)(t, o.yMid, n, o.left), t.restore()), t.save(), t.lineWidth = s, (0, it.setLineStyle)(t, this._data.point.borderStyle), this._data.point.shadowColor && !this._data.disabled && (t.fillStyle = this._data.point.shadowColor, (0, at.createCircle)(t, n, d, l + r), t.fill()), t.strokeStyle = this._data.point.borderColor, t.fillStyle = this._data.point.backgroundColor, (0, at.createCircle)(t, n, d, l), t.fill(), t.stroke(), t.restore()
                }
                draw(t, e) {
                    if (!this._data.visible) return;
                    const i = e.pixelRatio,
                        r = this.rectWithOffsets(e);
                    if (!this._isDataVisibleInViewport(e)) return;
                    const s = 0 !== r.qty.width,
                        a = 0 !== r.text.width,
                        l = 0 !== r.close.width,
                        n = r.body.right - r.body.left,
                        d = r.bottom - r.top,
                        c = r.top + r.borderWidth,
                        h = d - 2 * r.borderWidth,
                        u = r.borderRadius - r.borderWidth;
                    (0, at.drawRoundRectWithInnerBorder)(t, r.body.left, r.top, n, d, this._data.borderBackgroundColor, r.borderRadius, r.borderWidth, this._data.borderColor, this._data.borderStyle);
                    let _ = r.body.left + r.borderWidth;
                    if (s) {
                        const e = (0, o.ensureDefined)(this._data.qty);
                        this._drawQtyWithBackground(t, i, r, !0, !l && !a), _ += r.qty.width, r.qty.rightDividerWidth && (nt(t, _, c, r.qty.rightDividerWidth, h, e.dividerColor), _ += r.qty.rightDividerWidth)
                    }
                    if (a && (this._drawTextWithBackground(t, i, r, !s, !l), _ += r.text.width, r.text.rightDividerWidth && (nt(t, _, c, r.text.rightDividerWidth, h, this._data.text.dividerColor), _ += r.text.rightDividerWidth)), l) {
                        const e = (0, o.ensureDefined)(this._data.close),
                            s = r.body.right - _ - r.borderWidth;
                        (0,
                            at.drawRoundRectWithInnerBorder)(t, _, c, s, h, e.backgroundColor, [0, u, u, 0]), e.active.visible && (0, at.drawRoundRectWithInnerBorder)(t, _, c, s, h, e.active.backgroundColor, [0, u, u, 0]), this._drawCloseButton(t, i, _, r.top, r.close.width, d, r.borderWidth)
                    }
                }
                rect(t) {
                    return null === this._cache && (this._cache = this._calculateCacheRect(t)), this._cache
                }
                rectWithOffsets(t) {
                    return null === this._cacheWithOffset && (this._cacheWithOffset = this._calculateCacheRectWithOffsets(t)), this._cacheWithOffset
                }
                _calculateCacheRect(t) {
                    const e = t.pixelRatio,
                        i = Math.round(t.cssWidth * e),
                        o = Math.max(1, Math.floor(1 * e)),
                        r = this._bodyBorderRadius,
                        s = Math.max(r, Math.floor(r * e)),
                        a = this._quantityWidth(this._ctxInternal),
                        l = Math.round(a * e),
                        n = this._mainTextWidth(this._ctxInternal),
                        d = Math.round(n * e),
                        c = this._data.callbacks.onClose ? this._closeWidth() : 0,
                        h = Math.round(c * e);
                    let u = 0;
                    const p = a && (n || c),
                        b = n && c;
                    u += p && 1, u += b && 1;
                    const m = l + d + h + o * u + 2 * o;
                    let v = Math.round(this._height * e);
                    const f = Math.max(1, Math.floor(e));
                    v % 2 != f % 2 && (v += 1);
                    const y = Math.round(this._data.y * e),
                        P = Math.floor(y + f / 2 - v / 2) - Math.floor(.5 * e),
                        g = this._data.bodyAlignment === _.TradingSourcesHorizontalAlignment.Center ? Math.round(40 * i / 100) : Math.round(this._data.rightPadding * e);
                    let C = g;
                    this._data.bodyAlignment === _.TradingSourcesHorizontalAlignment.Left && (C = i - g - m);
                    const x = i - C,
                        k = x - m,
                        T = k + l + (l && o) + (l && o);
                    return {
                        borderWidth: o,
                        borderRadius: s,
                        yMid: y,
                        top: P,
                        bottom: P + v,
                        left: k,
                        right: x,
                        body: {
                            left: k,
                            right: x
                        },
                        qty: {
                            width: l,
                            left: k + (l && o),
                            rightDividerWidth: p ? o : 0
                        },
                        text: {
                            width: d,
                            left: T,
                            rightDividerWidth: b ? o : 0
                        },
                        close: {
                            width: h,
                            left: T + d + (d && o)
                        }
                    }
                }
                _calculateCacheRectWithOffsets(t) {
                    const e = this.rect(t),
                        {
                            left: i,
                            right: o
                        } = this._calcCoordinateWithOffset(e.left, e.right),
                        {
                            left: r,
                            right: s
                        } = this._calcCoordinateWithOffset(e.body.left, e.body.right);
                    return { ...e,
                        left: i,
                        right: o,
                        top: this._alignedTop ? this._alignedTop : e.top,
                        bottom: this._alignedTop ? this._alignedTop + (e.bottom - e.top) : e.bottom,
                        body: { ...e.body,
                            left: r,
                            right: s
                        },
                        qty: { ...e.qty,
                            left: this._calcCoordinateWithOffset(e.qty.left, e.qty.left + e.qty.width).left
                        },
                        text: { ...e.text,
                            left: this._calcCoordinateWithOffset(e.text.left, e.text.left + e.text.width).left
                        },
                        close: { ...e.close,
                            left: this._calcCoordinateWithOffset(e.close.left, e.close.left + e.close.width).left
                        }
                    }
                }
                _calcCoordinateWithOffset(t, e) {
                    var i, o, r, s;
                    if (null !== this._cache) {
                        const a = null !== (o = null === (i = this._offsets) || void 0 === i ? void 0 : i.leftmostForItemOffset) && void 0 !== o ? o : null;
                        if (null !== a) {
                            const i = t - (this._cache.left - a);
                            return {
                                left: i,
                                right: i + (e - t)
                            }
                        }
                        const l = null !== (s = null === (r = this._offsets) || void 0 === r ? void 0 : r.rightmostForItemOffset) && void 0 !== s ? s : null;
                        if (null !== l) {
                            const i = e + (l - this._cache.right);
                            return {
                                left: i - (e - t),
                                right: i
                            }
                        }
                    }
                    return {
                        left: t,
                        right: e
                    }
                }
                _calcAllWidth(t, e, i, o, r, s) {
                    return e + i + o + r + 2 * s
                }
                _isDataVisibleInViewport(t) {
                    const e = Math.ceil(this._height / 2);
                    return this._data.y >= -e && this._data.y <= t.cssHeight + e
                }
                _mainTextWidth(t) {
                    return this._data.text.text ? this._minMainTextWidthGetter(this._data, t) + 14 : 0
                }
                _closeWidth() {
                    return 23
                }
                _textWidth(t, e) {
                    if (!e) return 0;
                    const i = t.font;
                    t.font = (0, o.ensureNotNull)(this._font);
                    const r = Math.ceil(this._textWidthCache.measureText(t, e));
                    return t.font = i,
                        r ? Math.round(14 + r) : 0
                }
                _quantityWidth(t) {
                    var e;
                    if (void 0 === this._data.qty) return 0;
                    const i = t.font;
                    t.font = (0, o.ensureNotNull)(this._font);
                    const r = Math.ceil(this._textWidthCache.measureText(t, this._data.qty.text));
                    return t.font = i, Math.round(Math.max(this._height, 14 + r, null !== (e = this._data.qty.minTextWidth) && void 0 !== e ? e : 0))
                }
                _drawLine(t, e) {
                    const i = e.pixelRatio,
                        o = this.rectWithOffsets(e),
                        r = Math.round(e.physicalWidth);
                    t.save(), t.strokeStyle = this._data.line.color, t.lineWidth = Math.max(1, Math.floor(this._data.line.thickness * i)), (0, it.setLineStyle)(t, this._data.line.style), (0, at.drawHorizontalLine)(t, o.yMid, o.body.right, r), this._data.line.extend && (0, at.drawHorizontalLine)(t, o.yMid, 0, o.body.right), t.restore()
                }
                _drawQtyWithBackground(t, e, i, r, s) {
                    const a = (0, o.ensureDefined)(this._data.qty),
                        l = i.bottom - i.top,
                        n = i.top + i.borderWidth,
                        d = l - 2 * i.borderWidth,
                        c = i.borderRadius - i.borderWidth;
                    let h = 0;
                    s ? h = r ? c : [0, c, c, 0] : r && (h = [c, 0, 0, c]), (0, at.drawRoundRectWithInnerBorder)(t, i.qty.left, n, i.qty.width, d, a.backgroundColor, h), a.active.visible && (0, at.drawRoundRectWithInnerBorder)(t, i.qty.left, n, i.qty.width, d, a.active.backgroundColor, h);
                    const u = (i.top + i.bottom) / 2,
                        _ = i.qty.left + i.qty.width / 2;
                    this._drawText(t, e, a.text, a.textColor, _, u)
                }
                _drawTextWithBackground(t, e, i, r, s) {
                    const a = i.bottom - i.top,
                        l = i.top + i.borderWidth,
                        n = a - 2 * i.borderWidth,
                        d = i.borderRadius - i.borderWidth;
                    let c = 0;
                    s ? c = r ? d : [0, d, d, 0] : r && (c = [d, 0, 0, d]), (0, at.drawRoundRectWithInnerBorder)(t, i.text.left, l, i.text.width, n, this._data.text.backgroundColor, c);
                    const h = i.top + a / 2,
                        u = i.text.left + i.text.width / 2,
                        _ = (this._data.qty || this._data.text).text,
                        p = this._textWidthCache.yMidCorrection(t, _) * e;
                    (0, lt.drawText)(t, e, this._data.text.text, u, h, p, this._data.text.textColor, (0, o.ensureNotNull)(this._font))
                }
                _drawText(t, e, i, r, s, a) {
                    const l = this._textWidthCache.yMidCorrection(t, i) * e;
                    (0, lt.drawText)(t, e, i, s, a, l, r, (0, o.ensureNotNull)(this._font))
                }
                _drawUnderlinedText(t, e, i, r, s, a) {
                    const l = this._textWidthCache.yMidCorrection(t, i) * e,
                        n = this._textWidthCache.getMetrics(t, i);
                    (0, lt.drawUnderlinedText)(t, e, i, s, a, l, r, (0, o.ensureNotNull)(this._font), n)
                }
                _drawCloseButton(t, e, i, r, s, a, l) {
                    const n = (0, o.ensureDefined)(this._data.close);
                    t.save(), t.lineWidth = l, t.strokeStyle = n.iconColor;
                    const d = r + a,
                        c = Math.max(1, Math.ceil(7 * e)),
                        h = Math.round((s - c) / 2),
                        _ = Math.round((a - c) / 2);
                    (0, it.drawPoly)(t, [new u.Point(i + h, r + _), new u.Point(i + h + c, d - _)], !0), (0, it.drawPoly)(t, [new u.Point(i + h + c, r + _), new u.Point(i + h, d - _)], !0), t.restore()
                }
                _initCtx() {
                    const t = document.createElement("canvas");
                    t.width = 0, t.height = 0, this._ctxInternal = (0, o.ensureNotNull)(t.getContext("2d"))
                }
            }
            const ht = (0, r.t)("SL", {
                    context: "Stop loss"
                }),
                ut = (0, r.t)("TS", {
                    context: "Trailing stop"
                }),
                _t = (0, r.t)("TP", {
                    context: "Take profit"
                }),
                pt = (0, r.t)("Add Take Profit"),
                bt = (0, r.t)("Add Stop Loss"),
                mt = (0, r.t)("Add Trailing Stop");

            function vt(t) {
                return t instanceof ft
            }
            class ft extends z {
                constructor(t, e, i, o, r, s, a) {
                    super(t, e, i, o, r, s), this._isTypeMenuOpened = !1, this._handleTypeMenuClose = (t, e) => {
                        t(e) || this._handleTypeMenuDestroy()
                    }, this._handleTypeMenuDestroy = () => {
                        this._isTypeMenuOpened = !1
                    }, this._typeMenuCallbacks = a
                }
                destroy() {
                    var t;
                    null === (t = this._typeMenuCallbacks) || void 0 === t || t.closeDropdownMenuHandler(), super.destroy()
                }
                price() {
                    return this.data().price
                }
                setPrice(t) {
                    null !== t && (t = (0, h.fixComputationError)(this._symbolData.minTick * Math.round(t / this._symbolData.minTick))), this.setData({ ...(0, s.clone)(this.data()),
                        price: t
                    })
                }
                qtyText() {
                    return this._bracketTypeText(!0)
                }
                tooltip() {
                    switch (this.bracketType()) {
                        case a.BracketType.TakeProfit:
                            return pt;
                        case a.BracketType.StopLoss:
                            return bt;
                        case a.BracketType.TrailingStop:
                            return mt;
                        default:
                            throw new Error("Unknown bracket type")
                    }
                }
                isWorking() {
                    return !0
                }
                profitLossText(t) {
                    var e;
                    return (null === (e = this._source.isBracketsPLVisible()) || void 0 === e ? void 0 : e.value()) && this.bracketType() !== a.BracketType.TrailingStop ? super.profitLossText(t) : ""
                }
                isMinifyMode() {
                    return null === this.price()
                }
                toggleType(t, e, i = {}) {
                    this._typeMenuCallbacks && (this._isTypeMenuOpened = !this._isTypeMenuOpened, this._toggleTypeMenu(t, e, i))
                }
                bracketType() {
                    return this.data().bracketType
                }
                isMovingEnabled() {
                    return !0
                }
                async onMove(t) {
                    const e = new u.Point(t.localX, t.localY),
                        i = this._mainSeries.priceScale(),
                        r = this._mainSeries.firstValue();
                    if (null === r) return;
                    const s = i.coordinateToPrice(e.y, r);
                    this.setPrice(s), t.isTouch && (0, o.ensureDefined)(this._itemCommands.exitTrackingMode)()
                }
                _isBracket() {
                    return !0
                }
                _bracketTypeText(t) {
                    return this._data ? this.bracketType() === a.BracketType.TakeProfit ? _t : this._source.bracketStopType() === p.StopType.TrailingStop ? ut : ht : ""
                }
                _toggleTypeMenu(t, e = new u.Point(0, 0), i) {
                    (0, o.ensureDefined)(this._typeMenuCallbacks).onToggleTypeMenuHandler(this._isTypeMenuOpened, e, e => this._handleTypeMenuClose(t, e), this._handleTypeMenuDestroy, i)
                }
            }
            var yt = i(2996),
                Pt = i(28978);
            const gt = (0, et.generateColor)(yt.colorsPalette["color-tv-blue-500"], 85),
                Ct = ((0, et.generateColor)(yt.colorsPalette["color-tv-blue-500"], 80), (0, et.generateColor)(yt.colorsPalette["color-ripe-red-500"], 85)),
                xt = ((0, et.generateColor)(yt.colorsPalette["color-ripe-red-500"], 80), (0, et.generateColor)(yt.colorsPalette["color-minty-green-500"], 85)),
                kt = ((0, et.generateColor)(yt.colorsPalette["color-minty-green-500"], 80), (0, et.generateColor)(yt.colorsPalette["color-tan-orange-500"], 85)),
                Tt = ((0, et.generateColor)(yt.colorsPalette["color-tan-orange-500"], 80), (0, et.generateColor)(yt.colorsPalette["color-tv-blue-500"], 70)),
                St = (0, et.generateColor)(yt.colorsPalette["color-ripe-red-500"], 70),
                wt = (0, et.generateColor)(yt.colorsPalette["color-minty-green-500"], 70),
                Mt = (0, et.generateColor)(yt.colorsPalette["color-tan-orange-500"], 70),
                It = (0, et.generateColor)(yt.colorsPalette["color-cold-gray-900"], 50),
                Bt = {
                    pointShadowColor: Tt,
                    labelTickColor: yt.colorsPalette["color-tv-blue-500"],
                    lineColor: yt.colorsPalette["color-tv-blue-500"],
                    borderBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    borderColor: yt.colorsPalette["color-tv-blue-500"],
                    pointBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    disabledLineColor: yt.colorsPalette["color-tv-blue-a700"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-tv-blue-500"],
                        dividerColor: yt.colorsPalette["color-tv-blue-a800"],
                        activeColor: gt
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-tv-blue-500"],
                        dividerColor: yt.colorsPalette["color-tv-blue-a800"],
                        buttonTextColor: yt.colorsPalette["color-tv-blue-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        iconColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: gt
                    }
                },
                Dt = {
                    pointShadowColor: St,
                    labelTickColor: yt.colorsPalette["color-ripe-red-500"],
                    lineColor: yt.colorsPalette["color-ripe-red-500"],
                    borderBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    borderColor: yt.colorsPalette["color-ripe-red-500"],
                    pointBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    disabledLineColor: yt.colorsPalette["color-ripe-red-a800"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-ripe-red-500"],
                        dividerColor: yt.colorsPalette["color-ripe-red-a800"],
                        activeColor: Ct
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-ripe-red-500"],
                        dividerColor: yt.colorsPalette["color-ripe-red-a800"],
                        buttonTextColor: yt.colorsPalette["color-ripe-red-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        iconColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: Ct
                    }
                },
                Lt = {
                    pointShadowColor: wt,
                    labelTickColor: yt.colorsPalette["color-minty-green-500"],
                    lineColor: yt.colorsPalette["color-minty-green-500"],
                    borderBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    borderColor: yt.colorsPalette["color-minty-green-500"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-minty-green-500"],
                        dividerColor: "#0D3D41",
                        activeColor: xt
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-minty-green-500"],
                        dividerColor: "#0D3D41",
                        buttonTextColor: yt.colorsPalette["color-minty-green-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        iconColor: yt.colorsPalette["color-minty-green-500"],
                        activeColor: xt
                    }
                },
                Rt = {
                    pointShadowColor: Mt,
                    labelTickColor: yt.colorsPalette["color-tan-orange-500"],
                    lineColor: yt.colorsPalette["color-tan-orange-500"],
                    borderBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    borderColor: yt.colorsPalette["color-tan-orange-500"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-tan-orange-500"],
                        dividerColor: "#453826",
                        activeColor: kt
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-tan-orange-500"],
                        dividerColor: "#453826",
                        buttonTextColor: yt.colorsPalette["color-tan-orange-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        iconColor: yt.colorsPalette["color-tan-orange-500"],
                        activeColor: kt
                    }
                },
                Ot = {
                    buy: {
                        normal: Bt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Bt, It)
                    },
                    sell: {
                        normal: Dt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Dt, It)
                    },
                    takeProfit: {
                        normal: Lt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Lt, It)
                    },
                    stopLoss: {
                        normal: Rt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Rt, It)
                    }
                },
                Wt = (0, et.generateColor)(yt.colorsPalette["color-tv-blue-500"], 80),
                Vt = (0, et.generateColor)(yt.colorsPalette["color-ripe-red-500"], 80),
                At = (0, et.generateColor)(yt.colorsPalette["color-minty-green-500"], 80),
                Ht = (0, et.generateColor)(yt.colorsPalette["color-tan-orange-500"], 80),
                Et = (0, et.generateColor)(yt.colorsPalette["color-white"], 50),
                Nt = {
                    pointShadowColor: Wt,
                    labelTickColor: yt.colorsPalette["color-tv-blue-500"],
                    lineColor: yt.colorsPalette["color-tv-blue-500"],
                    borderBackgroundColor: yt.colorsPalette["color-white"],
                    borderColor: yt.colorsPalette["color-tv-blue-500"],
                    pointBackgroundColor: yt.colorsPalette["color-white"],
                    disabledLineColor: yt.colorsPalette["color-tv-blue-100"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-tv-blue-500"],
                        dividerColor: yt.colorsPalette["color-tv-blue-50"],
                        activeColor: gt
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-tv-blue-500"],
                        dividerColor: yt.colorsPalette["color-tv-blue-50"],
                        buttonTextColor: yt.colorsPalette["color-tv-blue-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        iconColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: gt
                    }
                },
                Ft = {
                    pointShadowColor: Vt,
                    labelTickColor: yt.colorsPalette["color-ripe-red-500"],
                    lineColor: yt.colorsPalette["color-ripe-red-500"],
                    borderBackgroundColor: yt.colorsPalette["color-white"],
                    borderColor: yt.colorsPalette["color-ripe-red-500"],
                    pointBackgroundColor: yt.colorsPalette["color-white"],
                    disabledLineColor: yt.colorsPalette["color-ripe-red-100"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-ripe-red-500"],
                        dividerColor: yt.colorsPalette["color-ripe-red-50"],
                        activeColor: Ct
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-ripe-red-500"],
                        dividerColor: yt.colorsPalette["color-ripe-red-50"],
                        buttonTextColor: yt.colorsPalette["color-ripe-red-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        iconColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: Ct
                    }
                },
                qt = {
                    pointShadowColor: At,
                    labelTickColor: yt.colorsPalette["color-minty-green-500"],
                    lineColor: yt.colorsPalette["color-minty-green-500"],
                    borderBackgroundColor: yt.colorsPalette["color-white"],
                    borderColor: yt.colorsPalette["color-minty-green-500"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-minty-green-500"],
                        dividerColor: yt.colorsPalette["color-minty-green-50"],
                        activeColor: xt
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-minty-green-500"],
                        dividerColor: yt.colorsPalette["color-minty-green-50"],
                        buttonTextColor: yt.colorsPalette["color-minty-green-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        iconColor: yt.colorsPalette["color-minty-green-500"],
                        activeColor: xt
                    }
                },
                jt = {
                    pointShadowColor: Ht,
                    labelTickColor: yt.colorsPalette["color-tan-orange-500"],
                    lineColor: yt.colorsPalette["color-tan-orange-500"],
                    borderBackgroundColor: yt.colorsPalette["color-white"],
                    borderColor: yt.colorsPalette["color-tan-orange-500"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-tan-orange-500"],
                        dividerColor: yt.colorsPalette["color-tan-orange-50"],
                        activeColor: kt
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-tan-orange-500"],
                        dividerColor: yt.colorsPalette["color-tan-orange-50"],
                        buttonTextColor: yt.colorsPalette["color-tan-orange-500"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        iconColor: yt.colorsPalette["color-tan-orange-500"],
                        activeColor: kt
                    }
                },
                zt = {
                    buy: {
                        normal: Nt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Nt, Et)
                    },
                    sell: {
                        normal: Ft,
                        disabled: (0, Pt.generateDisabledThemeColors)(Ft, Et)
                    },
                    takeProfit: {
                        normal: qt,
                        disabled: (0, Pt.generateDisabledThemeColors)(qt, Et)
                    },
                    stopLoss: {
                        normal: jt,
                        disabled: (0, Pt.generateDisabledThemeColors)(jt, Et)
                    }
                };

            function Gt(t, e, i, o = {}) {
                const r = i() ? Ot : zt;
                let s;
                const l = t.bracketType();
                s = null !== l ? l === a.BracketType.TakeProfit ? r.takeProfit : r.stopLoss : t.isBuyDirection() ? r.buy : r.sell;
                const n = vt(t),
                    d = e.isBlocked() ? s.disabled : s.normal,
                    c = !t.isWorking(),
                    h = n ? tt.LineStyle.Dashed : c ? tt.LineStyle.Dotted : tt.LineStyle.Solid;
                return { ...d,
                    lineStyle: h,
                    borderStyle: h,
                    labelBorderVisible: !0,
                    ...o
                }
            }
            const Ut = {
                    pointShadowColor: Tt,
                    lineColor: yt.colorsPalette["color-tv-blue-500"],
                    borderBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    borderColor: yt.colorsPalette["color-tv-blue-500"],
                    pointBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    disabledLineColor: yt.colorsPalette["color-tv-blue-a700"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-tv-blue-500"],
                        textColor: yt.colorsPalette["color-white"],
                        dividerColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: yt.colorsPalette["color-tv-blue-600"]
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-cold-gray-600"],
                        dividerColor: yt.colorsPalette["color-tv-blue-a800"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        iconColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: gt
                    },
                    reverse: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        borderColor: yt.colorsPalette["color-tv-blue-500"],
                        iconColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: gt
                    }
                },
                $t = {
                    pointShadowColor: St,
                    lineColor: yt.colorsPalette["color-ripe-red-500"],
                    borderBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    borderColor: yt.colorsPalette["color-ripe-red-500"],
                    pointBackgroundColor: yt.colorsPalette["color-cold-gray-900"],
                    disabledLineColor: yt.colorsPalette["color-ripe-red-a800"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-ripe-red-500"],
                        textColor: yt.colorsPalette["color-white"],
                        dividerColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: yt.colorsPalette["color-ripe-red-600"]
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        textColor: yt.colorsPalette["color-cold-gray-600"],
                        dividerColor: yt.colorsPalette["color-ripe-red-a800"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        iconColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: Ct
                    },
                    reverse: {
                        backgroundColor: yt.colorsPalette["color-cold-gray-900"],
                        borderColor: yt.colorsPalette["color-ripe-red-500"],
                        iconColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: Ct
                    }
                },
                Qt = {
                    buy: {
                        normal: Ut,
                        disabled: (0, Pt.generateDisabledThemeColors)(Ut, It)
                    },
                    sell: {
                        normal: $t,
                        disabled: (0, Pt.generateDisabledThemeColors)($t, It)
                    }
                },
                Yt = {
                    pointShadowColor: Wt,
                    lineColor: yt.colorsPalette["color-tv-blue-500"],
                    borderBackgroundColor: yt.colorsPalette["color-white"],
                    borderColor: yt.colorsPalette["color-tv-blue-500"],
                    pointBackgroundColor: yt.colorsPalette["color-white"],
                    disabledLineColor: yt.colorsPalette["color-tv-blue-100"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-tv-blue-500"],
                        textColor: yt.colorsPalette["color-white"],
                        dividerColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: yt.colorsPalette["color-tv-blue-600"]
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-cold-gray-300"],
                        dividerColor: yt.colorsPalette["color-tv-blue-50"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        iconColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: gt
                    },
                    reverse: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        borderColor: yt.colorsPalette["color-tv-blue-500"],
                        iconColor: yt.colorsPalette["color-tv-blue-500"],
                        activeColor: gt
                    }
                },
                Xt = {
                    pointShadowColor: Vt,
                    lineColor: yt.colorsPalette["color-ripe-red-500"],
                    borderBackgroundColor: yt.colorsPalette["color-white"],
                    borderColor: yt.colorsPalette["color-ripe-red-500"],
                    pointBackgroundColor: yt.colorsPalette["color-white"],
                    disabledLineColor: yt.colorsPalette["color-ripe-red-100"],
                    positivePlColor: yt.colorsPalette["color-minty-green-500"],
                    negativePlColor: yt.colorsPalette["color-ripe-red-500"],
                    qty: {
                        backgroundColor: yt.colorsPalette["color-ripe-red-500"],
                        textColor: yt.colorsPalette["color-white"],
                        dividerColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: yt.colorsPalette["color-ripe-red-600"]
                    },
                    text: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        textColor: yt.colorsPalette["color-cold-gray-300"],
                        dividerColor: yt.colorsPalette["color-ripe-red-50"]
                    },
                    close: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        iconColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: Ct
                    },
                    reverse: {
                        backgroundColor: yt.colorsPalette["color-white"],
                        borderColor: yt.colorsPalette["color-ripe-red-500"],
                        iconColor: yt.colorsPalette["color-ripe-red-500"],
                        activeColor: Ct
                    }
                },
                Kt = {
                    buy: {
                        normal: Yt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Yt, Et)
                    },
                    sell: {
                        normal: Xt,
                        disabled: (0, Pt.generateDisabledThemeColors)(Xt, Et)
                    }
                };

            function Jt(t, e, i) {
                const o = i() ? Qt : Kt,
                    r = t.isBuyDirection() ? o.buy : o.sell;
                return { ...e.isBlocked() ? r.disabled : r.normal,
                    lineStyle: tt.LineStyle.Solid,
                    borderStyle: tt.LineStyle.Solid,
                    labelBorderVisible: !1
                }
            }
            var Zt = i(66425),
                te = i(42265),
                ee = i(27905);

            function ie(t) {
                return t.hasOwnProperty("tp") && t.hasOwnProperty("sl")
            }
            class oe extends ct {
                constructor() {
                    super(...arguments), this._wasTPMoved = !1, this._wasSLMoved = !1
                }
                hitTest(t, e) {
                    var i, r;
                    const s = e.pixelRatio,
                        a = this.rectWithOffsets(e),
                        l = Math.round(t.x * s),
                        n = Math.round(t.y * s),
                        d = l >= a.left,
                        c = l <= a.right,
                        h = d && c;
                    if (!(n >= a.top && n <= a.bottom) || !h) return null;
                    const _ = {
                        cursorType: rt.PaneCursorType.Pointer,
                        hideCrosshairLinesOnHover: !0,
                        activeItem: {
                            id: this._data.id,
                            part: 6
                        },
                        contextMenuHandler: this._data.callbacks.onContextMenu,
                        touchContextMenuHandler: this._data.callbacks.onContextMenu
                    };
                    if (this._data.disabled) return new ot.HitTestResult(ot.HitTestResult.CUSTOM, _);
                    const p = Math.round(a.top / s),
                        b = void 0 !== this._data.callbacks.onMoveProjectionTP && 1 === (null === (i = this._data.tp) || void 0 === i ? void 0 : i.visibility);
                    if (b && l >= a.tp.left && l < a.tp.left + a.tp.width) {
                        const t = Math.round(a.tp.left / s),
                            e = Math.round(a.tp.width / s),
                            i = t => {
                                var e;
                                (null === (e = this._data) || void 0 === e ? void 0 : e.callbacks.onMoveProjectionTP) && this._data.callbacks.onMoveProjectionTP(t), this._wasTPMoved = !0
                            },
                            r = () => {
                                var t;
                                this._wasTPMoved && (null === (t = this._data) || void 0 === t ? void 0 : t.callbacks.onFinishMoveTP) && this._data.callbacks.onFinishMoveTP(), this._wasTPMoved = !1
                            };
                        return new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ..._,
                            activeItem: {
                                id: (0, o.ensureDefined)(this._data.tp).id,
                                part: 4
                            },
                            pressedMouseMoveHandler: i,
                            touchMoveHandler: i,
                            mouseUpHandler: r,
                            touchEndHandler: r,
                            tooltip: {
                                extendMargin: !0,
                                text: (0, o.ensureDefined)(this._data.tp).title,
                                rect: {
                                    x: t,
                                    y: p,
                                    w: e,
                                    h: this._height
                                }
                            }
                        })
                    }
                    const m = a.sl.left + a.sl.width,
                        v = void 0 !== this._data.callbacks.onMoveProjectionSL && 1 === (null === (r = this._data.sl) || void 0 === r ? void 0 : r.visibility);
                    if (v && l >= a.sl.left && l < m) {
                        const t = Math.round(a.sl.width / s),
                            e = Math.round(a.sl.left / s),
                            i = Math.round(a.bottom / s),
                            r = t => {
                                var e;
                                (null === (e = this._data) || void 0 === e ? void 0 : e.callbacks.onMoveProjectionSL) && this._data.callbacks.onMoveProjectionSL(t), this._wasSLMoved = !0
                            },
                            l = () => {
                                var t;
                                this._wasSLMoved && (null === (t = this._data) || void 0 === t ? void 0 : t.callbacks.onFinishMoveSL) && this._data.callbacks.onFinishMoveSL(), this._wasSLMoved = !1
                            };
                        let n, d;
                        const c = this._data.callbacks.onClickSL;
                        if (void 0 !== c) {
                            const o = o => {
                                const r = o.clientX - o.localX,
                                    s = o.clientY - o.localY,
                                    a = new u.Point(e + r, i + s);
                                c(o => o.x > e && o.x <= e + t && o.y > p && o.y <= i, a)
                            };
                            n = o, d = t => {
                                t.preventDefault(), o(t)
                            }
                        }
                        return new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ..._,
                            activeItem: {
                                id: (0,
                                    o.ensureDefined)(this._data.sl).id,
                                part: 5
                            },
                            pressedMouseMoveHandler: r,
                            touchMoveHandler: r,
                            mouseUpHandler: l,
                            touchEndHandler: l,
                            clickHandler: n,
                            tapHandler: d,
                            tooltip: {
                                extendMargin: !0,
                                text: (0, o.ensureDefined)(this._data.sl).title,
                                rect: {
                                    x: e,
                                    y: p,
                                    w: t,
                                    h: this._height
                                }
                            }
                        })
                    }
                    const f = m - a.body.left < 0 ? l >= m && l < a.body.left : l >= a.body.right && l < a.tp.left;
                    return (b || v) && f ? new ot.HitTestResult(ot.HitTestResult.CUSTOM, _) : super.hitTest(t, e)
                }
                draw(t, e) {
                    if (super.draw(t, e), !this._isTPSLVisible() || !this._isDataVisibleInViewport(e) || !this._data.visible) return;
                    const i = this.rectWithOffsets(e),
                        r = i.bottom - i.top,
                        s = i.yMid;
                    0 !== i.tp.width && 1 === (0, o.ensureDefined)(this._data.tp).visibility && this._drawBracketButton(t, e, r, i.borderRadius, s, i.tp, this._data.tp), 0 !== i.sl.width && 1 === (0, o.ensureDefined)(this._data.sl).visibility && this._drawBracketButton(t, e, r, i.borderRadius, s, i.sl, this._data.sl)
                }
                rect(t) {
                    return super.rect(t)
                }
                rectWithOffsets(t) {
                    return super.rectWithOffsets(t)
                }
                _calculateCacheRectWithOffsets(t) {
                    const e = super._calculateCacheRectWithOffsets(t);
                    return { ...e,
                        tp: { ...e.tp,
                            left: this._calcCoordinateWithOffset(e.tp.left, e.tp.left + e.tp.width).left
                        },
                        sl: { ...e.sl,
                            left: this._calcCoordinateWithOffset(e.sl.left, e.sl.left + e.sl.width).left
                        }
                    }
                }
                _calculateCacheRect(t) {
                    const e = super._calculateCacheRect(t),
                        i = this._calcTPSLRect(t.pixelRatio, e.borderWidth);
                    let o = 0,
                        r = 0;
                    this._data.bodyAlignment === _.TradingSourcesHorizontalAlignment.Left ? (r = e.body.right + i.offset, o = r + i.tp - (i.tp > 0 ? e.borderWidth : 0)) : (o = e.body.left - i.offset - i.sl, r = o - (i.tp > 0 ? i.tp - e.borderWidth : 0));
                    let s = r,
                        a = e.right;
                    return this._data.bodyAlignment === _.TradingSourcesHorizontalAlignment.Left && (s = e.left, a = o + i.sl), { ...e,
                        left: s,
                        right: a,
                        tp: {
                            width: i.tp,
                            left: r
                        },
                        sl: {
                            width: i.sl,
                            left: o
                        }
                    }
                }
                _drawLine(t, e) {
                    var i, o, r, s;
                    if (!(null === (i = this._data) || void 0 === i ? void 0 : i.callbacks.onFinishMoveSL) && !(null === (o = this._data) || void 0 === o ? void 0 : o.callbacks.onFinishMoveTP)) return void super._drawLine(t, e);
                    const a = e.pixelRatio,
                        l = this.rectWithOffsets(e),
                        n = Math.round(e.physicalWidth);
                    if (t.save(), t.strokeStyle = this._data.line.color, t.lineWidth = Math.max(1, Math.floor(this._data.line.thickness * a)), (0, it.setLineStyle)(t, this._data.line.style), (0, at.drawHorizontalLine)(t, l.yMid, l.body.right, n), this._data.line.extend)(0, at.drawHorizontalLine)(t, l.yMid, 0, l.body.left);
                    else {
                        const e = 1 === (null === (r = this._data.tp) || void 0 === r ? void 0 : r.visibility),
                            i = 1 === (null === (s = this._data.sl) || void 0 === s ? void 0 : s.visibility);
                        if (e || i) {
                            const e = i ? l.sl.left + l.sl.width : l.tp.left + l.tp.width;
                            (0, at.drawHorizontalLine)(t, l.yMid, e, l.body.left)
                        }
                    }
                    t.restore()
                }
                _calcAllWidth(t, e, i, o, r, s) {
                    const a = super._calcAllWidth(t, e, i, o, r, s);
                    if (!this._data.tp && !this._data.sl) return a;
                    const l = this._calcTPSLRect(t, s);
                    return a + l.tp + l.sl + l.offset
                }
                _calcTPSLRect(t, e) {
                    const i = 2 * e,
                        o = this._textWidth(this._ctxInternal, void 0 !== this._data.tp ? this._data.tp.text : ""),
                        r = Math.round(o * t) + (o && i),
                        s = this._textWidth(this._ctxInternal, void 0 !== this._data.sl ? this._data.sl.text : ""),
                        a = Math.round(s * t) + (s && i);
                    return {
                        tp: r,
                        sl: a,
                        offset: a > 0 || r > 0 ? Math.round(10 * t) : 0
                    }
                }
                _drawBracketButton(t, e, i, o, r, s, a) {
                    if (void 0 === a) return;
                    const l = this.rectWithOffsets(e);
                    (0, at.drawRoundRectWithInnerBorder)(t, s.left, l.top, s.width, i, a.backgroundColor, o), a.active.visible && (0, at.drawRoundRectWithInnerBorder)(t, s.left, l.top, s.width, i, a.active.backgroundColor, o), (0, at.drawRoundRectWithInnerBorder)(t, s.left, l.top, s.width, i, "transparent", o, l.borderWidth, a.borderColor, a.borderStyle);
                    const n = s.left + s.width / 2;
                    a.underlineText ? this._drawUnderlinedText(t, e.pixelRatio, a.text, a.textColor, n, r) : this._drawText(t, e.pixelRatio, a.text, a.textColor, n, r)
                }
                _isTPSLVisible() {
                    return Boolean(this._data.tp) || Boolean(this._data.sl)
                }
            }
            class re extends oe {
                constructor() {
                    super(...arguments), this._bodyBorderRadius = 4
                }
                hitTest(t, e) {
                    const i = e.pixelRatio,
                        r = this.rectWithOffsets(e),
                        s = Math.round(t.x * i),
                        a = Math.round(t.y * i),
                        l = s >= r.left,
                        n = s <= r.right,
                        d = l && n,
                        c = a >= r.top && a <= r.bottom,
                        h = Math.round(r.top / i);
                    if (!c || !d) return null;
                    const u = {
                        cursorType: rt.PaneCursorType.Default,
                        hideCrosshairLinesOnHover: !0,
                        activeItem: {
                            id: this._data.id,
                            part: 6
                        }
                    };
                    if (this._data.disabled) return new ot.HitTestResult(ot.HitTestResult.CUSTOM, u);
                    const _ = this._hasReverseButton() && (0, o.ensureDefined)(this._data.reverse);
                    if (_ && 1 === _.visibility) {
                        const t = r.reverse.left + r.reverse.width;
                        if (s >= r.reverse.left && s < t) {
                            const t = Math.round(r.reverse.left / i),
                                e = Math.round(r.reverse.width / i);
                            return new ot.HitTestResult(ot.HitTestResult.CUSTOM, {
                                activeItem: {
                                    id: this._data.id,
                                    part: 3
                                },
                                cursorType: rt.PaneCursorType.Default,
                                hideCrosshairLinesOnHover: !0,
                                contextMenuHandler: this._data.callbacks.onContextMenu,
                                touchContextMenuHandler: this._data.callbacks.onContextMenu,
                                clickHandler: this._data.callbacks.onReverse,
                                tapHandler: this._data.callbacks.onReverse,
                                tooltip: {
                                    text: _.title,
                                    rect: {
                                        x: t,
                                        y: h,
                                        w: e,
                                        h: this._height
                                    }
                                }
                            })
                        }
                        const o = this._calcReverseRect(e.pixelRatio).offset;
                        if (t - r.body.left < 0 ? s >= t && s < r.tp.left : s >= r.reverse.left - o && s < r.reverse.left) return new ot.HitTestResult(ot.HitTestResult.CUSTOM, u)
                    }
                    return super.hitTest(t, e)
                }
                draw(t, e) {
                    if (super.draw(t, e), !this._isReverseVisible() || !this._isDataVisibleInViewport(e) || !this._data.visible) return;
                    const i = this.rectWithOffsets(e);
                    this._drawReverseButton(t, e.pixelRatio, i.reverse.left, i.top, i.reverse.width, i.bottom - i.top, i.borderWidth, i.borderRadius)
                }
                rect(t) {
                    return super.rect(t)
                }
                rectWithOffsets(t) {
                    return super.rectWithOffsets(t)
                }
                _calculateCacheRectWithOffsets(t) {
                    const e = super._calculateCacheRectWithOffsets(t);
                    return { ...e,
                        reverse: { ...e.reverse,
                            left: this._calcCoordinateWithOffset(e.reverse.left, e.reverse.left + e.reverse.width).left
                        }
                    }
                }
                _calculateCacheRect(t) {
                    var e;
                    const i = super._calculateCacheRect(t);
                    if (!(null === (e = this._data) || void 0 === e ? void 0 : e.callbacks.onReverse) || !this._hasReverseButton()) return { ...i,
                        reverse: {
                            width: 0,
                            left: 0
                        }
                    };
                    const o = this._calcReverseRect(t.pixelRatio),
                        r = this._data.bodyAlignment === _.TradingSourcesHorizontalAlignment.Left,
                        s = r ? i.right + o.offset : i.left - o.width - o.offset,
                        a = r ? i.left : s,
                        l = r ? s + o.width : i.right;
                    return { ...i,
                        left: a,
                        right: l,
                        reverse: {
                            width: o.width,
                            left: s
                        }
                    }
                }
                _calcAllWidth(t, e, i, o, r, s) {
                    var a;
                    const l = super._calcAllWidth(t, e, i, o, r, s);
                    if (!(null === (a = this._data) || void 0 === a ? void 0 : a.callbacks.onReverse) || !this._hasReverseButton()) return l;
                    const n = this._calcReverseRect(t);
                    return l + n.width + n.offset
                }
                _drawLine(t, e) {
                    var i;
                    if (!(null === (i = this._data) || void 0 === i ? void 0 : i.callbacks.onReverse)) return void super._drawLine(t, e);
                    const o = e.pixelRatio,
                        r = this.rectWithOffsets(e),
                        s = Math.round(e.physicalWidth),
                        a = r.reverse.left + r.reverse.width;
                    if (t.save(), t.strokeStyle = this._data.line.color, t.lineWidth = Math.max(1, Math.floor(this._data.line.thickness * o)), (0, it.setLineStyle)(t, this._data.line.style), (0, at.drawHorizontalLine)(t, r.yMid, r.body.right, s), this._isReverseVisible() && (0, at.drawHorizontalLine)(t, r.yMid, a, r.body.left), this._data.line.extend) {
                        const e = this._isReverseVisible() ? r.reverse.left : r.body.left;
                        (0, at.drawHorizontalLine)(t, r.yMid, 0, e)
                    }
                    t.restore()
                }
                _calcReverseRect(t) {
                    return {
                        width: Math.round(29 * t),
                        offset: Math.round(10 * t)
                    }
                }
                _drawReverseButton(t, e, i, r, s, a, l, n) {
                    const d = (0, o.ensureDefined)(this._data.reverse),
                        c = d.active;
                    t.save(), (0, at.drawRoundRectWithInnerBorder)(t, i, r, s, a, d.backgroundColor, n, l, this._data.borderColor), c.visible && (0, at.drawRoundRectWithInnerBorder)(t, i, r, s, a, c.backgroundColor, n, l, "transparent");
                    const h = Math.round(3 * e),
                        u = Math.round(3 * e),
                        _ = Math.round(9 * e),
                        p = Math.round(i + (s - h) / 2),
                        b = Math.round(p + h),
                        m = r + l + Math.round((a - _) / 2 - l),
                        v = m + _,
                        f = d.iconColor;
                    t.lineWidth = l, (0, lt.drawHalfArrow)(t, p, m, f, !1, _, u), (0, lt.drawHalfArrow)(t, b, v, f, !0, _, u), t.restore()
                }
                _isReverseVisible() {
                    return this._hasReverseButton() && 1 === (0, o.ensureDefined)(this._data.reverse).visibility
                }
                _hasReverseButton() {
                    return Boolean(this._data.callbacks.onReverse && this._data.reverse)
                }
            }
            class se extends ct {
                constructor() {
                    super(...arguments), this._left = 0
                }
                hitTest(t, e) {
                    const i = e.pixelRatio,
                        o = this.rectWithOffsets(e),
                        r = Math.round(t.x * i),
                        s = Math.round(t.y * i),
                        a = r >= o.left,
                        l = r <= o.right,
                        n = a && l;
                    if (!(s >= o.top && s <= o.bottom) || !n) return null;
                    const d = {
                        cursorType: rt.PaneCursorType.Default,
                        hideCrosshairLinesOnHover: !0,
                        activeItem: {
                            id: this._data.id
                        }
                    };
                    return this._data.disabled ? new ot.HitTestResult(ot.HitTestResult.CUSTOM, d) : new ot.HitTestResult(ot.HitTestResult.CUSTOM, { ...d,
                        activeItem: {
                            id: this._data.id,
                            part: 6
                        }
                    })
                }
                applyOffset(t) {
                    const e = (0, o.ensureDefined)(this._data.drawWithTPOffset ? t.projItemTpLeft : this._data.drawWithSLOffset ? t.projItemSlLeft : 0);
                    this._left !== e && (this._left = e, this.clearCache())
                }
                _drawQtyWithBackground(t, e, i, r, s) {
                    const a = (0, o.ensureDefined)(this._data.qty),
                        l = i.top + (i.bottom - i.top) / 2,
                        n = i.qty.left + i.qty.width / 2;
                    this._drawText(t, e, a.text, a.textColor, n, l)
                }
                _drawTextWithBackground(t, e, i, o, r) {
                    const s = i.top + (i.bottom - i.top) / 2,
                        a = i.text.left + i.text.width / 2;
                    this._drawText(t, e, this._data.text.text, this._data.text.textColor, a, s)
                }
                _calculateCacheRect(t) {
                    const e = t.pixelRatio;
                    let i = super._calculateCacheRect(t);
                    const o = 2 * i.borderWidth,
                        r = this._mainTextWidth(this._ctxInternal),
                        s = this._quantityWidth(this._ctxInternal),
                        a = Math.round(r * e + s * e) + (r && o) + (s && i.borderWidth),
                        l = this._left + a;
                    return i = { ...i,
                        left: this._left,
                        right: l,
                        body: { ...i.body,
                            left: this._left,
                            right: l
                        },
                        text: {
                            left: this._left + i.qty.width + i.borderWidth,
                            width: i.text.width,
                            rightDividerWidth: 0
                        },
                        qty: {
                            left: this._left,
                            width: i.qty.width,
                            rightDividerWidth: i.qty.rightDividerWidth
                        }
                    }, this._data.bodyAlignment !== _.TradingSourcesHorizontalAlignment.Left ? i : { ...i,
                        top: i.top,
                        bottom: i.bottom,
                        body: {
                            left: i.body.left - i.text.width - Number(i.qty.rightDividerWidth) - i.borderWidth,
                            right: i.qty.left + i.qty.width + i.borderWidth
                        },
                        text: {
                            left: i.body.left - i.text.width - Number(i.qty.rightDividerWidth),
                            width: i.text.width + Number(i.qty.rightDividerWidth),
                            rightDividerWidth: i.qty.rightDividerWidth
                        },
                        qty: {
                            left: i.qty.left,
                            width: i.qty.width - Number(i.qty.rightDividerWidth),
                            rightDividerWidth: 0
                        }
                    }
                }
                _calcAllWidth(t, e, i, o, r, s) {
                    const a = 2 * s;
                    return Math.round(i * t) + (i && a)
                }
            }
            class ae {
                constructor(t) {
                    this._prevCssWidth = null, this._prevPixelRatio = null, this._prevFontSize = null, this._font = null, this._itemsRectsInfo = null, this._textWidthCache = new ee.TextWidthCache, this._minMainTextWidthCache = new Map, this._tradedItems = [], this._vertLineData = null, this._tradedSourceRenderersController = t
                }
                itemRenderers() {
                    return this._tradedItems
                }
                clearCache() {
                    this._itemsRectsInfo = null, this._tradedSourceRenderersController.invalidateCache()
                }
                setHorizontalAlignment(t) {
                    this._horizontalAlignment = t
                }
                setVertLineData(t) {
                    this._vertLineData = t
                }
                setData(t) {
                    this._data = t
                }
                setFontSize(t) {
                    if (this._prevFontSize !== t) {
                        this._checkCacheValid({
                            pixelRatio: this._prevPixelRatio,
                            cssWidth: this._prevCssWidth
                        }, t), this._prevFontSize = t, this._font = null === t ? null : (0, te.makeFont)(t, Zt.CHART_FONT_FAMILY, "", "normal");
                        for (const t of this._tradedItems) t.setFont(this._font)
                    }
                }
                clearItems() {
                    this._tradedItems = []
                }
                addItem(t) {
                    const e = function(t, e, i, o) {
                        if (t.type === Z.Position) return new re(t, e, i, o);
                        if (t.type === Z.WithBracketButtons) return new oe(t, e, i, o);
                        if (t.type === Z.Projection) return new se(t, e, i, o);
                        if (t.type === Z.Default) return new ct(t, e, i, o);
                        throw new Error("Unknown traded item renderer's type")
                    }(t, this._textWidthCache, (0, o.ensureNotNull)(this._font), this._minTextWidth.bind(this));
                    this._tradedItems.push(e)
                }
                hitTest(t, e) {
                    var i;
                    if (!this._paneHasVisibleItems()) return null;
                    this._checkCacheValid(e, this._prevFontSize), this._tradedSourceRenderersController.alignItems(e), this._calcItemsRectsInfo(e);
                    for (let i = this._tradedItems.length - 1; i >= 0; i--) {
                        const r = this._tradedItems[i];
                        r.applyOffset((0, o.ensureNotNull)(this._itemsRectsInfo));
                        const s = r.hitTest(t, e);
                        if (null !== s) return s
                    }
                    return (null === (i = this._data) || void 0 === i ? void 0 : i.disableNoOverlap) ? new ot.HitTestResult(ot.HitTestResult.MOVEPOINT_BACKGROUND, {
                        clickHandler: this._data.disableNoOverlap,
                        tapHandler: this._data.disableNoOverlap,
                        contextMenuHandler: this._data.disableNoOverlap,
                        touchContextMenuHandler: this._data.disableNoOverlap
                    }) : null
                }
                drawBackground(t, e) {
                    if (this._paneHasVisibleItems()) {
                        this._checkCacheValid(e, this._prevFontSize), this._tradedSourceRenderersController.alignItems(e), this._calcItemsRectsInfo(e);
                        for (const i of this._tradedItems) i.applyOffset((0, o.ensureNotNull)(this._itemsRectsInfo)), i.drawBackground(t, e)
                    }
                }
                draw(t, e) {
                    var i, r, s, a;
                    if (!this._paneHasVisibleItems()) return;
                    this._checkCacheValid(e, this._prevFontSize), this._tradedSourceRenderersController.alignItems(e),
                        this._calcItemsRectsInfo(e);
                    for (const i of this._tradedItems) i.applyOffset((0, o.ensureNotNull)(this._itemsRectsInfo)), i.drawLine(t, e);
                    const l = null !== (r = null === (i = this._itemsRectsInfo) || void 0 === i ? void 0 : i.rightmostBorder) && void 0 !== r ? r : null,
                        n = null !== (a = null === (s = this._itemsRectsInfo) || void 0 === s ? void 0 : s.leftmostBorder) && void 0 !== a ? a : null,
                        d = Math.round(e.cssWidth * e.pixelRatio),
                        c = Math.round(12 * e.pixelRatio),
                        h = this._horizontalAlignment === _.TradingSourcesHorizontalAlignment.Left,
                        u = h ? n : l,
                        p = h ? -1 : 1;
                    if (null !== u && u + p * c <= d) {
                        const i = h ? 0 : d,
                            o = Math.round(this._data.rightPadding * e.pixelRatio),
                            r = u + p * (Math.min(o, i - p * u) / 2);
                        this._drawVertLine(t, e, r);
                        for (const i of this._tradedItems) i.drawPointOnLine(t, e, r)
                    }
                    for (const i of this._tradedItems) i.draw(t, e)
                }
                clearMinTextWidthByItemId(t) {
                    this._minMainTextWidthCache.has(t) && this._minMainTextWidthCache.delete(t)
                }
                clearMinTextWidthCache() {
                    this._minMainTextWidthCache.clear()
                }
                _minTextWidth(t, e) {
                    var i;
                    if (!t.text.text) return 0;
                    e.save(), e.font = (0, o.ensureNotNull)(this._font);
                    const r = Math.ceil(this._textWidthCache.measureText(e, t.text.text)),
                        s = this._minMainTextWidthCache.get(t.id);
                    if (void 0 === s || r > s) {
                        const i = Math.ceil(this._textWidthCache.measureText(e, "0"));
                        this._minMainTextWidthCache.set(t.id, r + i)
                    }
                    return e.restore(), null !== (i = this._minMainTextWidthCache.get(t.id)) && void 0 !== i ? i : 0
                }
                _checkCacheValid(t, e) {
                    const i = this._prevFontSize !== e || this._prevPixelRatio !== t.pixelRatio,
                        o = this._prevCssWidth !== t.cssWidth;
                    if (i || o) {
                        i && this._textWidthCache.reset();
                        for (const t of this._tradedItems) t.clearCache()
                    }
                }
                _calcItemsRectsInfo(t) {
                    if (null !== this._itemsRectsInfo) return;
                    const e = this._tradedItems.filter(t => t.data().visible).map(e => e.rect(t)),
                        i = this._tradedSourceRenderersController.getBorderPoint(this);
                    let r, s, a, l, {
                            rightmostBorder: n,
                            leftmostBorder: d
                        } = (0, o.ensureNotNull)(i),
                        c = e[0].yMid,
                        h = e[0].yMid;
                    for (const t of e) {
                        t.yMid < c && (c = t.yMid), t.yMid > h && (h = t.yMid);
                        ie(t) && (r = t.tp.left, s = t.sl.left)
                    }
                    const u = n - d;
                    if (this._horizontalAlignment === _.TradingSourcesHorizontalAlignment.Left) n > t.physicalWidth && (l = Math.max(t.physicalWidth - u, Math.round(12 * t.pixelRatio)));
                    else if (d < 0) {
                        const e = Math.round(12 * t.pixelRatio);
                        a = t.physicalWidth - u > e ? u : t.physicalWidth - e
                    }
                    if (void 0 !== r && void 0 !== s) {
                        if (void 0 !== l) {
                            const t = d - l;
                            r -= t, s -= t
                        }
                        if (void 0 !== a) {
                            const t = a - n;
                            r += t, s += t
                        }
                    }
                    void 0 !== l && (d = l), void 0 !== a && (n = a), this._itemsRectsInfo = {
                        rightmostBorder: n,
                        leftmostBorder: d,
                        leftmostForItemOffset: l,
                        rightmostForItemOffset: a,
                        yMin: c,
                        yMax: h,
                        projItemTpLeft: r,
                        projItemSlLeft: s
                    }
                }
                _drawVertLine(t, e, i) {
                    const o = this._vertLineData;
                    if (null === o || null === this._itemsRectsInfo || this._itemsRectsInfo.yMax === this._itemsRectsInfo.yMin) return;
                    const r = e.pixelRatio;
                    t.strokeStyle = o.color, t.lineWidth = Math.max(1, Math.floor(o.thickness * r)), (0, it.setLineStyle)(t, o.style), (0, at.drawVerticalLine)(t, i, this._itemsRectsInfo.yMin, this._itemsRectsInfo.yMax)
                }
                _paneHasVisibleItems() {
                    return this._tradedItems.filter(t => t.data().visible).length > 0
                }
            }
            class le extends z {
                isWorking() {
                    return !1
                }
                async onFinishMove(t, e = {}, i = !0, r) {
                    this._source.setIsBlocked(i);
                    const a = (0, s.clone)(this.data()),
                        l = (0, o.ensureNotNull)(a.price);
                    a.limitPrice = l, a.takeProfit = e.takeProfit || a.takeProfit, a.stopLoss = e.stopLoss || a.stopLoss, await this._addTrailingStopPipsData(a), void 0 === r && (r = 1), this._trackEventGA(t);
                    const n = await (0, o.ensureDefined)(this._data.callbacks.moveOrder)(a.id, a, r);
                    return this._inEdit = !1, this._source.setIsBlocked(!1), this._source.syncData(), n
                }
                profitLossText(t) {
                    return this._bracketTypeText(t)
                }
                supportClose() {
                    return !1
                }
                _calcId() {
                    return this.data().type
                }
            }

            function ne(t) {
                return "profitState" in t && "onReverse" in t
            }

            function de(t) {
                return function(t) {
                    return "isMovingEnabled" in t && "onMove" in t && "onFinishMove" in t
                }(t) && "bracketType" in t && "isWorking" in t
            }

            function ce(t) {
                return t instanceof le
            }
            var he;

            function ue(t) {
                let e, i, o;
                return t.forEach(t => {
                    switch (de(t) ? t.bracketType() : j(t)) {
                        case a.BracketType.TakeProfit:
                            e = t;
                            break;
                        case a.BracketType.TrailingStop:
                            o = t;
                            break;
                        case a.BracketType.StopLoss:
                            i = t
                    }
                }), {
                    takeProfit: e,
                    trailingStop: o,
                    stopLoss: i
                }
            }! function(t) {
                t[t.Position = 0] = "Position", t[t.Order = 1] = "Order", t[t.LimitPartStopLimitOrder = 2] = "LimitPartStopLimitOrder", t[t.ProjectionBracket = 3] = "ProjectionBracket"
            }(he || (he = {}));

            function _e(t) {
                return null === t ? "0" : ((0, s.isNumber)(t) && t < 0 && (t = "− " + Math.abs(t)), (0, L.forceLTRStr)((0, k.splitThousands)(t, " ")))
            }
            var pe;
            ! function(t) {
                t[t.Large = 380] = "Large", t[t.Small = 280] = "Small"
            }(pe || (pe = {}));
            const be = (0, r.t)("Modify Order..."),
                me = (0, r.t)("Cancel Order"),
                ve = (0, f.appendEllipsis)((0, r.t)("Protect Position")),
                fe = (0, r.t)("Reverse Position"),
                ye = (0, r.t)("Close Position");
            class Pe {
                constructor(t, e, i) {
                    this._prevTradedItemTokens = new Map, this._displayMode = 2, this._invalidated = !0, this._chartModel = t, this._source = e, this._tradedSourceRenderersController = i, this._showOrderProperty = e.showOrderProperty(), this._showPositionProperty = e.showPositionProperty(), this._renderer = new ae(this._tradedSourceRenderersController), this._tradedSourceRenderersController.registerRenderer(this._renderer), this._renderer.setFontSize(13), this._source.positionDisplayMode().subscribe(this._renderer, this._renderer.clearMinTextWidthCache), this._source.bracketsDisplayMode().subscribe(this._renderer, this._renderer.clearMinTextWidthCache)
                }
                destroy() {
                    this._tradedSourceRenderersController.removeRenderer(this._renderer), this._source.positionDisplayMode().unsubscribe(this._renderer, this._renderer.clearMinTextWidthCache), this._source.bracketsDisplayMode().unsubscribe(this._renderer, this._renderer.clearMinTextWidthCache)
                }
                update() {
                    this._invalidated = !0
                }
                renderer(t, e) {
                    if (this._invalidated) {
                        const t = this._displayMode;
                        this._calculateMode(e), this._updateImpl(), t !== this._displayMode && this._renderer.clearMinTextWidthCache(), this._renderer.clearCache(), this._invalidated = !1
                    }
                    return this._renderer
                }
                priceToCoordinate(t) {
                    if (null === t) return null;
                    const e = this._chartModel.mainSeries(),
                        i = e.firstValue();
                    return null === i ? null : e.priceScale().priceToCoordinate(t, i)
                }
                _isProfitLossHidden() {
                    return 0 === this._displayMode
                }
                _isProfitLossShorten() {
                    return 2 !== this._displayMode
                }
                _isCloseVisible() {
                    return 0 !== this._displayMode
                }
                _minQtyWidth() {
                    return 0 === this._displayMode ? 30 : 0
                }
                _isReverseVisible() {
                    return 2 === this._displayMode && !this._tradedSourceRenderersController.isNoOverlapMode()
                }
                _rightPadding() {
                    return 2 !== this._displayMode ? 40 : 64
                }
                _isHoveredItem(t) {
                    var e;
                    return (null === (e = this._source.hoveredItem()) || void 0 === e ? void 0 : e.id) === t.id()
                }
                _isHoveredItemPart(t, e) {
                    var i;
                    return this._isHoveredItem(t) && (null === (i = this._source.hoveredItem()) || void 0 === i ? void 0 : i.part) === e
                }
                _isSelectedItem(t) {
                    var e;
                    return (null === (e = this._source.selectedItem()) || void 0 === e ? void 0 : e.id) === t.id()
                }
                _isMovingItem(t) {
                    var e;
                    return (null === (e = this._source.movingItem()) || void 0 === e ? void 0 : e.id) === t.id()
                }
                _calculateMode(t) {
                    if (!d.enabled("adaptive_trading_sources")) return;
                    const e = t < pe.Large ? t < pe.Small ? 0 : 1 : 2;
                    this._displayMode = e
                }
                _sortedItems() {
                    const t = [],
                        e = this._source.tradedItems();
                    let i = null,
                        o = null,
                        r = null;
                    const s = e.brackets.slice();
                    if (s.push(...e.projection.brackets), void 0 !== e.stopLimit && s.push(e.stopLimit), void 0 !== e.main && s.push(e.main), this._tradedSourceRenderersController.isNoOverlapMode()) return s;
                    for (const e of s) this._isMovingItem(e) ? r = e : this._isHoveredItem(e) ? o = e : this._isSelectedItem(e) ? i = e : t.push(e);
                    return null !== i && t.push(i), null !== o && t.push(o), null !== r && t.push(r), t
                }
                _updateImpl() {
                    if (this._renderer.clearItems(), !this._showOrderProperty.value() && !this._showPositionProperty.value() || this._isNoData()) return;
                    let t = null;
                    const e = this._mainItemStyle(),
                        i = this._source.isSelected(),
                        r = i && this._source.isHoveredOtherTradedSource() ? (0, o.ensureDefined)(e.disabledLineColor) : e.lineColor;
                    (this._source.isHovered() || i) && (t = {
                        thickness: this._source.lineWidth(),
                        style: e.lineStyle,
                        color: r
                    });
                    const s = {
                        rightPadding: this._rightPadding()
                    };
                    this._renderer.setHorizontalAlignment(this._source.horizontalAlignment()), this._renderer.setVertLineData(t), this._tradedSourceRenderersController.isNoOverlapMode() && (s.disableNoOverlap = () => this._tradedSourceRenderersController.setNoOverlapMode(!1)), this._renderer.setData(s);
                    const a = new Map;
                    for (const t of this._sortedItems()) {
                        const i = this.priceToCoordinate(t.price());
                        if (null === i) continue;
                        let o;
                        o = ne(t) ? this._rendererDataForPositionItem(t, i, r) : vt(t) ? this._rendererDataForProjectionBracketItem(t, e, i, r) : this._rendererDataForOrderItem(t, e, i, r), null !== o && (this._renderer.addItem(o), a.set(`${o.id} ${t.isBuyDirection()}`, o.id))
                    }
                    this._prevTradedItemTokens.forEach((t, e) => {
                        a.has(e) || this._renderer.clearMinTextWidthByItemId(t)
                    }), this._prevTradedItemTokens = a
                }
                _modeGaLabel() {
                    switch (this._displayMode) {
                        case 2:
                            return "Standard view";
                        case 1:
                            return "Medium view";
                        case 0:
                            return "Minimal view"
                    }
                }
                _createCallbacks(t, e = []) {
                    const i = this._source,
                        o = {},
                        r = {
                            label: `[${this._modeGaLabel()}]`
                        };
                    if (ne(t) || !t.isMovingEnabled() || this._tradedSourceRenderersController.isNoOverlapMode() || (o.onMove = e => i.onMove(t.id(), e), vt(t) || (o.onFinishMove = () => i.onFinishMove(t.id(), r))), t.hasContextMenu() && (o.onContextMenu = e => t.onContextMenu(e, r)), vt(t)) return o;
                    ne(t) && t.supportReverse() && this._isReverseVisible() && (o.onReverse = () => t.onReverse(r)), t.supportClose() && this._isCloseVisible() && (o.onClose = () => t.onClose(r)), t.supportModify() && (o.onModify = () => t.onModify(r));
                    const {
                        takeProfit: s,
                        stopLoss: a,
                        trailingStop: l
                    } = ue(e);
                    s && (o.onMoveProjectionTP = t => i.onMove(s.id(), t), o.onFinishMoveTP = () => i.modifyAllItems(s.id(), r));
                    const n = a || l;
                    return n && (o.onMoveProjectionSL = t => i.onMove(n.id(), t), o.onFinishMoveSL = () => i.modifyAllItems(n.id(), r), i.isTrailingStopSupported() && (o.onClickSL = (t, e) => n.toggleType(t, e, r))), this._tradedSourceRenderersController.isNoOverlapMode() && (o.allInteractionsHandler = () => this._tradedSourceRenderersController.setNoOverlapMode(!1)), o
                }
                _isNoData() {
                    const t = this._source.tradedItems();
                    return void 0 === t.main && void 0 === t.stopLimit && 0 === t.brackets.length
                }
                _rendererDataForPositionItem(t, e, i) {
                    var r;
                    const s = Jt(t, this._source, () => this._chartModel.isDark()),
                        a = s.reverse,
                        l = this._source.isHovered() || this._source.isSelected(),
                        n = this._isHoveredItemPart(t, 1),
                        d = this._isHoveredItemPart(t, 2),
                        c = this._isHoveredItemPart(t, 3),
                        {
                            takeProfit: h,
                            stopLoss: u,
                            trailingStop: _
                        } = ue(this._source.tradedItems().projection.brackets),
                        p = u || _,
                        b = h && null === h.price() && this._isHoveredItem(h),
                        m = p && null === p.price() && this._isHoveredItem(p),
                        v = this._isHoveredItem(t) || b || m ? s.pointShadowColor : void 0,
                        f = this._isHoveredItemWithButtons(t) || this._source.isSelected(),
                        y = {
                            type: Z.Position,
                            borderBackgroundColor: s.borderStyle === tt.LineStyle.Solid ? "transparent" : s.borderBackgroundColor,
                            borderColor: s.borderColor,
                            borderStyle: s.borderStyle,
                            bodyAlignment: this._source.horizontalAlignment(),
                            y: e,
                            visible: t.isVisible(),
                            sortingIndex: null !== (r = t.price()) && void 0 !== r ? r : 0,
                            id: t.id(),
                            disabled: this._source.isBlocked(),
                            callbacks: this._createCallbacks(t, this._projectionBracketsForItem(t)),
                            rightPadding: this._rightPadding(),
                            ...this._renderDataForTPSLButtons(t),
                            line: {
                                drawOnTop: l && !this._tradedSourceRenderersController.isNoOverlapMode(),
                                thickness: this._source.lineWidth(),
                                style: s.lineStyle,
                                color: s.lineColor,
                                extend: this._source.isLineExtended()
                            },
                            qty: {
                                title: ve,
                                text: _e(t.qtyText()),
                                minTextWidth: this._minQtyWidth(),
                                textColor: s.qty.textColor,
                                backgroundColor: s.qty.backgroundColor,
                                dividerColor: s.qty.dividerColor,
                                active: {
                                    visible: n,
                                    backgroundColor: s.qty.activeColor
                                }
                            },
                            text: {
                                text: this._isProfitLossHidden() ? "" : t.profitLossText(),
                                textColor: t.profitLossTextColor(),
                                backgroundColor: s.text.backgroundColor,
                                dividerColor: s.text.dividerColor,
                                title: ""
                            },
                            point: {
                                visible: l,
                                backgroundColor: this._isSelectedItem(t) ? i : (0, o.ensureDefined)(s.pointBackgroundColor),
                                borderStyle: s.lineStyle,
                                borderColor: i,
                                shadowColor: v
                            }
                        };
                    return this._isCloseVisible() && (y.close = {
                        title: ye,
                        backgroundColor: s.close.backgroundColor,
                        iconColor: s.close.iconColor,
                        active: {
                            visible: d,
                            backgroundColor: s.close.activeColor
                        }
                    }), this._source.isReverseVisible() && this._isReverseVisible() && (y.reverse = {
                        visibility: f ? 1 : 0,
                        title: fe,
                        backgroundColor: a.backgroundColor,
                        iconColor: a.iconColor,
                        active: {
                            visible: c,
                            backgroundColor: a.activeColor
                        }
                    }), y
                }
                _rendererDataForOrderItem(t, e, i, r) {
                    var s;
                    const a = Gt(t, this._source, () => this._chartModel.isDark()),
                        l = this._source.isHovered() || this._source.isSelected(),
                        n = this._isHoveredItemPart(t, 1),
                        d = this._isHoveredItemPart(t, 2),
                        c = (0,
                            et.generateColor)(a.borderColor, 85),
                        h = this._renderDataForTPSLButtons(t),
                        {
                            takeProfit: u,
                            stopLoss: _,
                            trailingStop: p
                        } = ue(this._source.tradedItems().projection.brackets),
                        b = _ || p,
                        m = t === this._itemWithButton(),
                        v = m && u && null === u.price() && this._isHoveredItem(u),
                        f = m && b && null === b.price() && this._isHoveredItem(b),
                        y = this._isHoveredItem(t) || v || f ? e.pointShadowColor : void 0,
                        P = {
                            type: m ? Z.WithBracketButtons : Z.Default,
                            borderBackgroundColor: a.borderStyle === tt.LineStyle.Solid ? "transparent" : a.borderBackgroundColor,
                            borderColor: a.borderColor,
                            borderStyle: a.borderStyle,
                            bodyAlignment: this._source.horizontalAlignment(),
                            rightPadding: this._rightPadding(),
                            y: i,
                            visible: t.isVisible(),
                            sortingIndex: null !== (s = t.price()) && void 0 !== s ? s : 0,
                            id: t.id(),
                            disabled: this._source.isBlocked(),
                            callbacks: this._createCallbacks(t, this._projectionBracketsForItem(t)),
                            ...h,
                            line: {
                                drawOnTop: l && !this._tradedSourceRenderersController.isNoOverlapMode(),
                                thickness: this._source.lineWidth(),
                                style: a.lineStyle,
                                color: a.lineColor,
                                extend: this._source.isLineExtended()
                            },
                            qty: {
                                title: be,
                                text: _e(t.qtyText()),
                                minTextWidth: this._minQtyWidth(),
                                textColor: a.qty.textColor,
                                backgroundColor: a.qty.backgroundColor,
                                dividerColor: a.qty.dividerColor,
                                active: {
                                    visible: n,
                                    backgroundColor: c
                                }
                            },
                            text: {
                                text: this._isProfitLossHidden() ? "" : t.profitLossText(this._isProfitLossShorten()),
                                textColor: a.text.textColor,
                                backgroundColor: a.text.backgroundColor,
                                dividerColor: a.text.dividerColor,
                                title: t.profitLossTooltip()
                            },
                            point: {
                                visible: l,
                                backgroundColor: this._isSelectedItem(t) ? r : (0, o.ensureDefined)(e.pointBackgroundColor),
                                borderStyle: e.lineStyle,
                                borderColor: r,
                                shadowColor: y
                            }
                        };
                    return this._isCloseVisible() && (P.close = {
                        title: me,
                        backgroundColor: a.close.backgroundColor,
                        iconColor: a.close.iconColor,
                        active: {
                            visible: d,
                            backgroundColor: c
                        }
                    }), P
                }
                _rendererDataForProjectionBracketItem(t, e, i, r) {
                    var s;
                    const l = Gt(t, this._source, () => this._chartModel.isDark()),
                        n = this._source.isHovered() || this._source.isSelected(),
                        d = this._isHoveredItem(t) ? e.pointShadowColor : void 0,
                        c = this._isHoveredItemPart(t, 6),
                        h = (0, et.generateColor)(l.borderColor, 85);
                    return {
                        type: Z.Projection,
                        borderBackgroundColor: l.borderStyle === tt.LineStyle.Solid ? "transparent" : l.borderBackgroundColor,
                        borderColor: l.borderColor,
                        borderStyle: l.borderStyle,
                        bodyAlignment: this._source.horizontalAlignment(),
                        y: i,
                        visible: t.isVisible(),
                        sortingIndex: null !== (s = t.price()) && void 0 !== s ? s : 0,
                        id: t.id(),
                        disabled: this._source.isBlocked(),
                        callbacks: this._createCallbacks(t),
                        drawWithTPOffset: t.bracketType() === a.BracketType.TakeProfit,
                        drawWithSLOffset: t.bracketType() === a.BracketType.StopLoss || t.bracketType() === a.BracketType.TrailingStop,
                        rightPadding: this._rightPadding(),
                        line: {
                            drawOnTop: n && !this._tradedSourceRenderersController.isNoOverlapMode(),
                            thickness: this._source.lineWidth(),
                            style: l.lineStyle,
                            color: l.lineColor,
                            extend: this._source.isLineExtended()
                        },
                        qty: {
                            text: t.qtyText(),
                            textColor: l.text.textColor,
                            backgroundColor: l.text.backgroundColor,
                            dividerColor: l.text.dividerColor,
                            active: {
                                visible: c,
                                backgroundColor: h
                            }
                        },
                        text: {
                            text: t.profitLossText(),
                            textColor: l.text.textColor,
                            backgroundColor: l.text.backgroundColor,
                            dividerColor: l.text.dividerColor,
                            active: {
                                visible: c,
                                backgroundColor: h
                            }
                        },
                        point: {
                            visible: n,
                            backgroundColor: this._isSelectedItem(t) ? r : (0, o.ensureDefined)(e.pointBackgroundColor),
                            borderStyle: e.lineStyle,
                            borderColor: r,
                            shadowColor: d
                        }
                    }
                }
                _isHoveredItemWithButtons(t) {
                    if (!t) return !1;
                    const {
                        takeProfit: e,
                        stopLoss: i,
                        trailingStop: o
                    } = ue(this._source.tradedItems().projection.brackets);
                    return this._isHoveredItem(t) || Boolean(e && this._isHoveredItem(e)) || Boolean(i && this._isHoveredItem(i)) || Boolean(o && this._isHoveredItem(o))
                }
                _isHoveredStopItemStopLimit() {
                    const t = this._source.tradedItems().main,
                        e = this._source.tradedItems().stopLimit;
                    return !!(t && e && ce(e)) && this._isHoveredItem(t)
                }
                _renderDataForTPSLButtons(t) {
                    if (t !== this._itemWithButton()) return {};
                    const e = {
                            borderStyle: tt.LineStyle.Solid
                        },
                        i = {},
                        {
                            takeProfit: o,
                            stopLoss: r,
                            trailingStop: s
                        } = ue(this._source.tradedItems().projection.brackets),
                        a = this._isHoveredItemWithButtons(t) || this._isHoveredStopItemStopLimit() || this._source.isSelected();
                    if (o) {
                        const t = null === o.price(),
                            r = this._isHoveredItemPart(o, 4),
                            s = Gt(o, this._source, () => this._chartModel.isDark(), e);
                        i.tp = {
                            id: o.id(),
                            visibility: t && a ? 1 : 0,
                            text: o.qtyText(),
                            title: o.tooltip(),
                            underlineText: !1,
                            textColor: t ? s.text.buttonTextColor : s.text.textColor,
                            backgroundColor: s.text.backgroundColor,
                            borderColor: s.borderColor,
                            borderStyle: s.borderStyle,
                            active: {
                                visible: r,
                                backgroundColor: s.text.backgroundColor
                            }
                        }
                    }
                    const l = r || s;
                    if (l) {
                        const t = null === l.price(),
                            o = this._isHoveredItemPart(l, 5),
                            r = Gt(l, this._source, () => this._chartModel.isDark(), e),
                            s = (0, et.generateColor)(r.borderColor, 85);
                        i.sl = {
                            id: l.id(),
                            visibility: t && a ? 1 : 0,
                            text: l.qtyText(),
                            title: l.tooltip(),
                            underlineText: this._source.isTrailingStopSupported(),
                            textColor: t ? r.text.buttonTextColor : r.text.textColor,
                            backgroundColor: r.text.backgroundColor,
                            borderColor: r.borderColor,
                            borderStyle: r.borderStyle,
                            active: {
                                visible: o,
                                backgroundColor: this._source.isTrailingStopSupported() ? s : r.text.backgroundColor
                            }
                        }
                    }
                    return i
                }
                _itemWithButton() {
                    if (!this._tradedSourceRenderersController.isNoOverlapMode()) return this._source.baseItem()
                }
                _projectionBracketsForItem(t) {
                    return t !== this._itemWithButton() ? [] : this._source.tradedItems().projection.brackets
                }
                _mainItemStyle() {
                    const t = this._source.mainItem();
                    return void 0 === t ? function(t, e, i) {
                        const o = i() ? Ot : zt,
                            r = t.isBuyDirection() ? o.sell : o.buy;
                        return { ...e.isBlocked() ? r.disabled : r.normal,
                            lineStyle: t.isWorking() ? e.lineStyle() : tt.LineStyle.Dotted,
                            borderStyle: t.isWorking() ? tt.LineStyle.Solid : tt.LineStyle.Dotted,
                            labelBorderVisible: !0
                        }
                    }(this._source.tradedItems().brackets[0], this._source, () => this._chartModel.isDark()) : ne(t) ? Jt(t, this._source, () => this._chartModel.isDark()) : Gt(t, this._source, () => this._chartModel.isDark())
                }
            }
            var ge = i(9540);
            class Ce extends ge.PriceAxisView {
                constructor(t, e, i, o) {
                    super(), this._model = t, this._data = e, this._source = i, this._styleGetter = o
                }
                itemId() {
                    return this._data.id()
                }
                _updateRendererData(t, e, i) {
                    if (t.visible = !1, !this._data.isVisible()) return;
                    const o = this._model.mainSeries(),
                        r = o.priceScale(),
                        s = o.firstValue();
                    if (null === s) return;
                    const a = this._data.price();
                    if (null === a) return;
                    const l = this._styleGetter();
                    i.background = l.qty.backgroundColor, i.borderColor = l.labelBorderVisible ? l.borderColor : void 0, i.borderStyle = l.labelBorderVisible ? l.borderStyle : void 0, i.textColor = l.qty.textColor, i.coordinate = r.priceToCoordinate(a, s), t.borderVisible = l.labelBorderVisible, t.text = this._formatPrice(a), t.tickColor = l.labelTickColor, t.visible = !0
                }
                _formatPrice(t) {
                    return this._source.priceScaleFormatter().format(t)
                }
            }
            var xe = i(12669);
            class ke extends xe.PriceLineAxisView {
                constructor(t, e, i, o, r, s, a) {
                    super(), this._chartModel = t, this._data = e, this._source = i, this._showProperty = s, this._height = o, this._verticalPadding = r, this._styleGetter = a
                }
                itemId() {
                    return this._data.id()
                }
                _value() {
                    const t = this._chartModel.mainSeries(),
                        e = t.firstValue(),
                        i = this._data.price();
                    if (null === i || null === e) return {
                        noData: !0
                    };
                    const o = t.priceScale().priceToCoordinate(i, e);
                    return {
                        noData: !1,
                        floatCoordinate: o,
                        coordinate: o,
                        color: "",
                        formattedPricePercentage: "",
                        formattedPriceAbsolute: "",
                        formattedPriceIndexedTo100: "",
                        text: "",
                        index: 0
                    }
                }
                _updateRendererData(t, e, i) {
                    const o = this._styleGetter();
                    t.linestyle = o.lineStyle, i.additionalPaddingTop = this._verticalPadding, i.additionalPaddingBottom = this._verticalPadding, super._updateRendererData(t, e, i)
                }
                _priceLineColor(t) {
                    return this._styleGetter().lineColor
                }
                _lineWidth() {
                    return this._source.lineWidth()
                }
                _lineStyle() {
                    return this._styleGetter().lineStyle
                }
                _backgroundAreaHeight() {
                    return this._height
                }
                _isVisible() {
                    return this._showProperty.value()
                }
            }

            function Te(t, e, i) {
                if (ne(i)) {
                    const o = () => Jt(i, e, () => t.isDark());
                    return {
                        priceAxisView: new Ce(t, i, e, o),
                        priceLineAxisView: new ke(t, i, e, 19, 0, e.showPositionProperty(), o)
                    }
                }
                const o = () => Gt(i, e, () => t.isDark());
                return {
                    priceAxisView: new Ce(t, i, e, o),
                    priceLineAxisView: new ke(t, i, e, 17, 1, e.showOrderProperty(), o)
                }
            }
            class Se {
                constructor(t, e) {
                    this._model = t, this._source = e
                }
                updateAllViews(t) {
                    void 0 !== this._views.main && (this._views.main.priceAxisView.update(t), this._views.main.priceLineAxisView.update(t)), void 0 !== this._views.stopLimit && (this._views.stopLimit.priceAxisView.update(t), this._views.stopLimit.priceLineAxisView.update(t));
                    for (const e of this._views.brackets) e.priceAxisView.update(t), e.priceLineAxisView.update(t);
                    for (const e of this._views.project.brackets) e.priceAxisView.update(t), e.priceLineAxisView.update(t)
                }
                views(t, e) {
                    const i = this._source.movingItem() || null,
                        o = this._source.hoveredItem() || null,
                        r = this._source.selectedItem() || null,
                        s = null !== i ? i.id : null,
                        a = null !== o ? o.id : null,
                        l = null !== r ? r.id : null,
                        n = [],
                        d = [];
                    let c = null,
                        h = null,
                        u = null,
                        _ = null,
                        p = null,
                        b = null;
                    const m = this._views.brackets.slice();
                    m.push(...this._views.project.brackets), this._views.main && m.push(this._views.main), this._views.stopLimit && m.push(this._views.stopLimit);
                    for (const t of m) t.priceAxisView.itemId() === s ? (c = t.priceAxisView, h = t.priceLineAxisView) : t.priceAxisView.itemId() === a ? (u = t.priceAxisView, _ = t.priceLineAxisView) : t.priceAxisView.itemId() === l ? (p = t.priceAxisView, b = t.priceLineAxisView) : (n.push(t.priceAxisView), d.push(t.priceLineAxisView));
                    return null !== p && null !== b && (n.push(p), d.push(b)), null !== u && null !== _ && (n.push(u), d.push(_)), null !== c && null !== h && (n.push(c), d.push(h)), [n, d]
                }
                recreateViews() {
                    const t = this._source.tradedItems(),
                        e = t.projection.brackets.filter(t => null !== t.price()).map(t => Te(this._model, this._source, t));
                    this._views = {
                        brackets: t.brackets.map(t => Te(this._model, this._source, t)),
                        project: {
                            brackets: e
                        }
                    }, void 0 !== t.main && (this._views.main = Te(this._model, this._source, t.main)), void 0 !== t.stopLimit && (this._views.stopLimit = Te(this._model, this._source, t.stopLimit))
                }
            }
            var we = i(36907);

            function Me(t) {
                return t instanceof Le
            }

            function Ie(t, e, i, o, r) {
                return {
                    price: null,
                    considerFilledQty: !1,
                    supportModify: !1,
                    supportMove: !0,
                    supportCancel: !1,
                    supportBrackets: !1,
                    plBasedOnLast: t.plBasedOnLast,
                    callbacks: {},
                    id: e,
                    symbol: t.symbol,
                    type: o,
                    bracketType: i,
                    stopType: r,
                    side: -1 === t.side ? 1 : -1,
                    qty: t.qty,
                    status: 6
                }
            }
            const Be = (0, r.t)("Stop loss"),
                De = (0, r.t)("Trailing stop");
            class Le extends n.CustomSourceBase {
                constructor(t, e, i, o, r, s, a, l, n, d) {
                    super(t, e), this._bracketStopType = p.StopType.StopLoss, this._symbol = null, this._isActualSymbol = !1, this._tradedItems = {
                        brackets: [],
                        projection: {
                            brackets: []
                        }
                    }, this._blockedData = null, this._isBlocked = !1, this._hadBeenModifiedAllItems = !1, this._isDestroyed = !1, this._resetProjBracketsTimeout = null, this._pipValueWV = null, this._mainSeries = e.mainSeries(), this._properties = i, this._globalVisibility = o, this._globalVisibility.subscribe(this.redraw.bind(this)), this._callbacks = n, this._pipValueTypeSpawn = r.spawn(), this._pipValueTypeSpawn.subscribe(this.redraw.bind(this)), this._pipValueWVCtor = l, this._symbolDataProvider = a;
                    const c = this._mainSeries.dataEvents();
                    c.symbolResolved().subscribe(this, this._updateActualSymbolAndFormatter), c.symbolError().subscribe(this, this._updateActualSymbolAndFormatter), this._updateActualSymbolAndFormatter(), this._paneView = new Pe(this._model, this, d), this._tradedSourceRenderersController = d, this._priceViewsGroup = new Se(this._model, this), this._rawDataSpawn = s.spawn(), this._setData(this._rawDataSpawn.value(), !1), this._rawDataSpawn.subscribe(this._setData.bind(this)), this._properties.positionPL.visibility.subscribe(this, this.redraw), this._properties.bracketsPL.visibility.subscribe(this, this.redraw), this._properties.positionPL.display.subscribe(this, () => {
                        this.redraw()
                    }), this._properties.bracketsPL.display.subscribe(this, () => {
                        this.redraw()
                    }), this._properties.showPositions.subscribe(this, () => {
                        this._tradedSourceRenderersController.setNoOverlapMode(!1)
                    }), this._properties.showOrders.subscribe(this, () => {
                        this._tradedSourceRenderersController.setNoOverlapMode(!1)
                    }), this._tradedSourceRenderersController.noOverlapModeChanged().subscribe(this.redraw.bind(this)), this._callbacks.onDataUpdateRejected.subscribe(this, this._resetProjBracketsHandler), this._model.hoveredSourceChanged().subscribe(this, () => {
                        if (!this._isActualSymbol) return;
                        const t = this._model.hoveredSource();
                        (null === t || t !== this && t instanceof Le) && this.redraw()
                    })
                }
                destroy() {
                    var t, e, i;
                    this._properties.showOrders.destroy(), this._properties.showPositions.destroy(), this._properties.positionPL.visibility.unsubscribeAll(this), this._properties.positionPL.display.unsubscribeAll(this), this._properties.bracketsPL.visibility.unsubscribeAll(this),
                        this._properties.bracketsPL.display.unsubscribeAll(this);
                    const o = this._mainSeries.dataEvents();
                    o.symbolResolved().unsubscribeAll(this), o.symbolError().unsubscribeAll(this), this._rawDataSpawn.destroy(), this._pipValueTypeSpawn.destroy(), null === (t = this._tradedItems.main) || void 0 === t || t.destroy(), null === (e = this._tradedItems.stopLimit) || void 0 === e || e.destroy(), this._tradedItems.brackets.forEach(t => t.destroy()), this._tradedItems.projection.brackets.forEach(t => t.destroy()), this._globalVisibility.unsubscribe(), this._callbacks.onDataUpdateRejected.unsubscribeAll(this), this._paneView.destroy(), null === (i = this._pipValueWV) || void 0 === i || i.destroy(), this._isDestroyed = !0
                }
                isSelectionEnabled() {
                    return !0
                }
                priceScaleFormatter() {
                    return this._mainSeries.formatter()
                }
                showPositionProperty() {
                    return this._properties.showPositions
                }
                showOrderProperty() {
                    return this._properties.showOrders
                }
                bracketStopType() {
                    return this._bracketStopType
                }
                setBracketStopType(t) {
                    this._bracketStopType = t, this._updateProjectionBracketsItems(!0), this.redraw()
                }
                isTrailingStopSupported() {
                    var t;
                    return Boolean(null === (t = this.tradedItems().main) || void 0 === t ? void 0 : t.data().supportTrailingStop)
                }
                isReverseVisible() {
                    return this._properties.showReverse.value()
                }
                lineWidth() {
                    return this._properties.lineProperties.width.value()
                }
                lineStyle() {
                    return this._properties.lineProperties.style.value()
                }
                isLineExtended() {
                    return this._properties.lineProperties.extend.value()
                }
                isPositionPLVisible() {
                    return this._properties.positionPL.visibility
                }
                positionDisplayMode() {
                    return this._properties.positionPL.display
                }
                isBracketsPLVisible() {
                    return null
                }
                bracketsDisplayMode() {
                    return this._properties.bracketsPL.display
                }
                pipValueType() {
                    return (0, o.ensureNotNull)(this._pipValueTypeSpawn).value()
                }
                horizontalAlignment() {
                    return this._properties.horizontalAlignment.value()
                }
                isBlocked() {
                    return this._isBlocked
                }
                setIsBlocked(t) {
                    this._isBlocked = t, this.redraw()
                }
                isHovered() {
                    return this._model.hoveredSource() === this
                }
                isHoveredOtherTradedSource() {
                    return !this.isHovered() && Me(this._model.hoveredSource())
                }
                isSelected() {
                    return this._model.selection().isSelected(this)
                }
                tradedItems(t, e) {
                    if (t) {
                        const t = [];
                        return this._tradedItems.stopLimit && !(null == e ? void 0 : e.exceptStopLimit) && t.push(this._tradedItems.stopLimit), this._tradedItems.main && !(null == e ? void 0 : e.exceptMain) && t.push(this._tradedItems.main), (null == e ? void 0 : e.exceptBrackets) || t.push(...this._tradedItems.brackets), (null == e ? void 0 : e.exceptProjection) || t.push(...this._tradedItems.projection.brackets), t
                    }
                    return this._tradedItems
                }
                mainItem() {
                    return this._tradedItems.main
                }
                baseItem() {
                    var t;
                    return null !== (t = this._tradedItems.stopLimit) && void 0 !== t ? t : this._tradedItems.main
                }
                findItem(t) {
                    const e = this.tradedItems(!0).find(e => e.id() === t);
                    return (0, o.assert)(void 0 !== e, `Traded item with id ${t} is not found`), e
                }
                findItemWithType(t, e) {
                    const i = e === l.TradedItemType.Position ? ne : de;
                    return this.tradedItems(!0, {
                        exceptStopLimit: !0
                    }).find(e => i(e) && e.data().id === t)
                }
                movingItem() {
                    const t = this._model.customSourceBeingMoved() === this && this._model.customSourceMovingHitTestData() || null;
                    return null === t || void 0 === t.activeItem ? null : t.activeItem
                }
                hoveredItem() {
                    const t = this._model.hoveredSource() === this && this._model.lastHittestData() || null;
                    return null === t || void 0 === t.activeItem ? null : t.activeItem
                }
                selectedItem() {
                    const t = this._model.selection().isSelected(this) && this._model.lastSelectedHittestData() || null;
                    return null === t || void 0 === t.activeItem ? null : t.activeItem
                }
                priceScale() {
                    return this._mainSeries.priceScale()
                }
                updateAllViews() {
                    this._paneView.update(), this._priceViewsGroup.updateAllViews((0, we.dataSourceChangeEvent)(this.id()))
                }
                updateViewsForPane(t) {
                    this._isSourceShouldBeShownOnPane(t) && this.updateAllViews()
                }
                paneViews(t) {
                    return this._isSourceShouldBeShownOnPane(t) ? [this._paneView] : []
                }
                priceAxisViews(t, e) {
                    if (!this._isSourceShouldBeShownOnPane(t)) return [];
                    const [i, o] = this._priceViewsGroup.views(t, e);
                    return t.findTargetPriceAxisViews(this, e, i, o)
                }
                redraw() {
                    this.updateAllViews(), this._isSourceShouldBeShown() && this._model.updateSource(this)
                }
                syncData() {
                    this._isDestroyed || (null !== this._blockedData ? (this._setData(this._blockedData), this._blockedData = null) : this._setData(this._rawDataSpawn.value()))
                }
                allItemsSupportMove(t) {
                    if (void 0 === this._tradedItems.main) return !1;
                    for (const t of this._tradedItems.projection.brackets)
                        if (null !== t.price()) return !1;
                    return !(t.length < 2) && t.every(t => de(t) && t.isMovingEnabled())
                }
                onMove(t, e) {
                    const i = this.findItem(t),
                        r = i.price(),
                        s = this.tradedItems(!0);
                    if (e.shiftKey && null !== i.price() && this.allItemsSupportMove(s)) {
                        this._hadBeenModifiedAllItems = !0;
                        const t = (0, o.ensureNotNull)(i.calcPriceDiff(e));
                        s.forEach(e => {
                            vt(e) || e.applyPriceDiff(t)
                        }), this._callbacks.hideChartHint()
                    } else i.onMove(e), this._moveOtherProjectionBracketIfNeeded(i);
                    null === r && null !== i.price() && this._priceViewsGroup.recreateViews(), this.redraw()
                }
                async onFinishMove(t, e) {
                    if (this._hadBeenModifiedAllItems) return this.modifyAllItems(t, e);
                    this.setIsBlocked(!0);
                    const i = this.findItem(t);
                    (0, o.assert)(de(i), "This item does not support move"), e = c(e, {
                        event: "Move Order",
                        label: "single"
                    });
                    const r = await i.onFinishMove(e);
                    return this.setIsBlocked(!1), this.syncData(), this.redraw(), this.allItemsSupportMove(this.tradedItems(!0)) && this._callbacks.showChartHint(), r
                }
                async modifyAllItems(t, e) {
                    var i, r, s, l, n, d, h, u;
                    this.setIsBlocked(!0);
                    const {
                        takeProfit: _,
                        stopLoss: p,
                        trailingStop: b
                    } = ue(this._tradedItems.projection.brackets), {
                        takeProfit: m,
                        stopLoss: v,
                        trailingStop: f
                    } = ue(this._tradedItems.brackets), y = {
                        limitPrice: null !== (r = null === (i = this._tradedItems.stopLimit) || void 0 === i ? void 0 : i.price()) && void 0 !== r ? r : void 0,
                        takeProfit: null !== (l = null !== (s = null == m ? void 0 : m.price()) && void 0 !== s ? s : null == _ ? void 0 : _.price()) && void 0 !== l ? l : void 0,
                        stopLoss: null !== (d = null !== (n = null == v ? void 0 : v.price()) && void 0 !== n ? n : null == p ? void 0 : p.price()) && void 0 !== d ? d : void 0,
                        trailingStop: null !== (u = null !== (h = null == f ? void 0 : f.price()) && void 0 !== h ? h : null == b ? void 0 : b.price()) && void 0 !== u ? u : void 0
                    }, P = (0, o.ensureDefined)(this._tradedItems.main), g = this.findItem(t);
                    (0, o.assert)(de(g), "This item does not support move");
                    const C = this._hadBeenModifiedAllItems ? "Move Order" : "Add bracket from button";
                    e = c(e, {
                        event: C,
                        label: function(t, e, i) {
                            return ne(i) || "Move Order" === t ? "group" : e.supportOnlyPairBrackets() ? "both bracket" : i.bracketType() === a.BracketType.TakeProfit ? "take profit" : i.bracketType() === a.BracketType.TrailingStop ? "trailing stop" : "stop loss"
                        }(C, P, g)
                    });
                    const x = this._ticketFocus(g);
                    let k = !1;
                    return ne(P) ? k = await P.onModifyWithBracket(e, y, !1, x) : (k = await P.onFinishMove(e, y, !1, x), this.tradedItems(!0).forEach(t => {
                        t.setInEdit(!1)
                    })), k ? this._resetProjectionBracketByTimeout() : (null == b || b.setPrice(null), null == _ || _.setPrice(null), null == p || p.setPrice(null)), this.setIsBlocked(!1), this.syncData(), this.redraw(), this._hadBeenModifiedAllItems = !1, k
                }
                pipValueWV() {
                    return this._pipValueWV
                }
                _createPipValueWV() {
                    this._pipValueWVCtor && this._symbol && this._isActualSymbol && (this._pipValueWV || (this._pipValueWV = this._pipValueWVCtor(this._symbol), this._pipValueWV.subscribe(() => {
                        this.tradedItems(!0).forEach(t => {
                            t.fireProfitLossChange()
                        }), this.redraw()
                    })))
                }
                _isSourceShouldBeShown() {
                    return !!this._globalVisibility.value() && (!!this._isActualSymbol && !(window.TradingView.printing && !d.enabled("snapshot_trading_drawings")))
                }
                _getToggleTypeMenuHandler() {
                    const t = [{
                        title: Be,
                        bracketType: p.StopType.StopLoss
                    }];
                    return this.isTrailingStopSupported() && t.push({
                        title: De,
                        bracketType: p.StopType.TrailingStop
                    }), (e, i, o, r, s) => {
                        var a;
                        const l = this.mainItem();
                        if (e) {
                            const t = l && ne(l) ? "Chart Position" : "Chart Order";
                            this._callbacks.trackEvent(t, "Stop loss type menu opening", null !== (a = s.label) && void 0 !== a ? a : "")
                        }
                        t.length > 1 && updateDropdownMenu(e, i, t, o, r, t => this.setBracketStopType(t))
                    }
                }
                _resetProjectionBracketByTimeout() {
                    this._clearResetProjBracketsTimeout(), this._resetProjBracketsTimeout = setTimeout(() => this._resetProjBracketsHandler(), 2e4)
                }
                _resetProjBracketsHandler() {
                    this._clearResetProjBracketsTimeout();
                    const {
                        takeProfit: t,
                        stopLoss: e,
                        trailingStop: i
                    } = ue(this._tradedItems.projection.brackets);
                    null == t || t.setPrice(null), null == e || e.setPrice(null), null == i || i.setPrice(null), this.redraw()
                }
                _clearResetProjBracketsTimeout() {
                    null !== this._resetProjBracketsTimeout && (clearTimeout(this._resetProjBracketsTimeout), this._resetProjBracketsTimeout = null)
                }
                _ticketFocus(t) {
                    if (!ne(t)) {
                        if (null !== t.bracketType()) return t.bracketType() === a.BracketType.TakeProfit ? 3 : 4;
                        switch (t.type()) {
                            case 4:
                                return ce(t) ? 1 : 2;
                            case 1:
                                return 1;
                            case 3:
                                return 2
                        }
                    }
                    return 5
                }
                _moveOtherProjectionBracketIfNeeded(t) {
                    const e = this._tradedItems.main;
                    if (!vt(t) || void 0 === e || !e.supportOnlyPairBrackets() || this._tradedItems.projection.brackets.length < 2) return;
                    const i = (0, o.ensureNotNull)(e.price()),
                        r = (0, o.ensureNotNull)(t.price()) - i,
                        s = this._tradedItems.projection.brackets.find(e => e !== t);
                    (0, o.ensureDefined)(s).setPrice(i - r)
                }
                _createMainItem(t) {
                    var e, i;
                    let o;
                    return 0 === (null === (e = t.main) || void 0 === e ? void 0 : e.mainType) ? o = this._createItem(he.Order, t.main) : 1 === (null === (i = t.main) || void 0 === i ? void 0 : i.mainType) && (o = this._createItem(he.Position, t.main)), o
                }
                _createItem(t, e, i = !1) {
                    const o = function(t, e, i, o, r, a, l, n) {
                        const d = o.mainSeries(),
                            c = (t, e) => (r.tradedSourceRenderersController, null),
                            h = t => Gt(t, i, () => o.isDark());
                        if (t === he.Order) return new z(e, i, d, r.symbolDataProvider, {
                            displayMode: i.bracketsDisplayMode(),
                            currency: a.currencyGetter,
                            style: h,
                            visibility: l.order,
                            noOverlapAction: c
                        }, {
                            trackEvent: a.trackEvent,
                            exitTrackingMode: a.exitTrackingMode
                        });
                        if (t === he.Position) {
                            const t = t => Jt(t, i, () => o.isDark());
                            return new J(e, i, d, r.symbolDataProvider, {
                                displayMode: i.positionDisplayMode(),
                                currency: a.currencyGetter,
                                style: t,
                                visibility: l.position,
                                noOverlapAction: c
                            }, {
                                trackEvent: a.trackEvent
                            })
                        }
                        if (t === he.LimitPartStopLimitOrder) {
                            const t = (0, s.merge)((0, s.clone)(e), {
                                price: e.limitPrice,
                                considerFilledQty: !1
                            });
                            return new le(t, i, d, r.symbolDataProvider, {
                                displayMode: i.bracketsDisplayMode(),
                                currency: a.currencyGetter,
                                style: h,
                                visibility: l.order,
                                noOverlapAction: c
                            }, {
                                trackEvent: a.trackEvent,
                                exitTrackingMode: a.exitTrackingMode
                            })
                        }
                        if (t === he.ProjectionBracket) return new ft(e, i, d, r.symbolDataProvider, {
                            displayMode: i.bracketsDisplayMode(),
                            currency: a.currencyGetter,
                            style: h,
                            visibility: l.order,
                            noOverlapAction: c
                        }, {
                            trackEvent: a.trackEvent,
                            exitTrackingMode: a.exitTrackingMode
                        }, n);
                        throw new Error("Unknown traded item type")
                    }(t, e, this, this._model, {
                        symbolDataProvider: this._symbolDataProvider,
                        tradedSourceRenderersController: this._tradedSourceRenderersController
                    }, this._callbacks, {
                        order: this._orderVisibilityGetter.bind(this),
                        position: this._positionVisibilityGetter.bind(this)
                    }, void 0);
                    return this._symbol && this._isActualSymbol && (o.subscribeRealtime(), o.updateCurrency(this._symbol)), o
                }
                _createStopLimitItem(t, e) {
                    let i;
                    if (void 0 !== t.main && e instanceof z && 4 === e.type()) {
                        const e = (0, s.merge)((0, s.clone)(t.main), {
                            price: t.main.limitPrice,
                            considerFilledQty: !1
                        });
                        i = this._createItem(he.LimitPartStopLimitOrder, e)
                    }
                    return i
                }
                _createItems(t) {
                    const e = this._createMainItem(t),
                        i = this._createStopLimitItem(t, e);
                    this._tradedItems = {
                        main: e,
                        stopLimit: i,
                        brackets: t.brackets.map((t, e) => this._createItem(he.Order, t)),
                        projection: {
                            brackets: []
                        }
                    }
                }
                _updateItems(t) {
                    if (void 0 !== this._tradedItems.main)
                        if (void 0 !== t.main)
                            if (this._tradedItems.main instanceof z) {
                                if (0 !== t.main.mainType) throw new Error("Main item was order");
                                this._tradedItems.main.setData(t.main), void 0 !== this._tradedItems.stopLimit && (4 !== t.main.type ? (this._tradedItems.main.setData((0, s.merge)(this._tradedItems.stopLimit.data(), {
                                    type: t.main.type,
                                    price: t.main.price,
                                    callbacks: t.main.callbacks
                                })), this._tradedItems.stopLimit.destroy(), delete this._tradedItems.stopLimit) : this._tradedItems.stopLimit.setData((0, s.merge)((0, s.clone)(t.main), {
                                    price: t.main.limitPrice
                                })))
                            } else {
                                if (1 !== t.main.mainType) throw new Error("Main item was order");
                                this._tradedItems.main.setData(t.main)
                            }
                    else this._tradedItems.main.destroy(), delete this._tradedItems.main, this._tradedItems.stopLimit && (this._tradedItems.stopLimit.destroy(), delete this._tradedItems.stopLimit);
                    else void 0 !== t.main && (this._tradedItems.main = this._createMainItem(t), this._tradedItems.stopLimit = this._createStopLimitItem(t, this._tradedItems.main));
                    this._updateBrackets(t.brackets)
                }
                _updateBrackets(t) {
                    const e = [];
                    this._tradedItems.brackets.forEach(i => {
                        const o = t.find(t => t.id === i.data().id);
                        o ? i.setData(o) : e.push(i)
                    }), e.forEach(t => {
                        const e = this._tradedItems.brackets.findIndex(e => e.data().id === t.data().id); - 1 !== e && (this._tradedItems.brackets[e].destroy(), this._tradedItems.brackets.splice(e, 1))
                    }), t.length > this._tradedItems.brackets.length && t.slice(this._tradedItems.brackets.length).forEach(t => {
                        this._tradedItems.brackets.push(this._createItem(he.Order, t))
                    })
                }
                _updateProjectionBracketsItems(t = !1) {
                    const e = this._tradedItems.main;
                    if (void 0 === e || !e.supportBrackets()) return;
                    const {
                        takeProfit: i,
                        stopLoss: o,
                        trailingStop: r
                    } = ue(this._tradedItems.brackets), s = null != o ? o : r, {
                        takeProfit: l,
                        stopLoss: n,
                        trailingStop: d
                    } = ue(this._tradedItems.projection.brackets), c = null != n ? n : d;
                    [
                        [i, l],
                        [s, c]
                    ].forEach(([t, e]) => {
                        if (t && e) {
                            const t = this._tradedItems.projection.brackets.indexOf(e);
                            this._tradedItems.projection.brackets[t].destroy(), this._tradedItems.projection.brackets.splice(t, 1)
                        }
                    });
                    const h = e.data();
                    if (!i && !l) {
                        const t = Ie(h, "Projection TakeProfit", a.BracketType.TakeProfit, 1);
                        this._tradedItems.projection.brackets.push(this._createItem(he.ProjectionBracket, t))
                    }
                    if (!s && !c || t) {
                        const t = this._bracketStopType === p.StopType.TrailingStop ? p.StopType.TrailingStop : void 0,
                            e = this._bracketStopType === p.StopType.StopLoss ? a.BracketType.StopLoss : a.BracketType.TrailingStop,
                            i = Ie(h, this._bracketStopType === p.StopType.StopLoss ? "Projection StopLoss" : "Projection TrailingStop", e, 3, t);
                        c ? c.setData(i) : this._tradedItems.projection.brackets.push(this._createItem(he.ProjectionBracket, i, !0))
                    }
                }
                _setData(t, e = !0) {
                    var i, o;
                    this.isBlocked() ? (this._blockedData = t, this._tradedItems.main instanceof J && void 0 !== t.main && this._tradedItems.main.setData(t.main)) : (e ? this._updateItems(t) : this._createItems(t), this._updateProjectionBracketsItems(), this._priceViewsGroup.recreateViews());
                    const r = (null === (i = t.main) || void 0 === i ? void 0 : i.symbol) || (null === (o = t.brackets[0]) || void 0 === o ? void 0 : o.symbol) || null;
                    r !== this._symbol && (this._symbol = r, this._updateActualSymbolAndFormatter()), this.redraw()
                }
                _updateActualSymbolAndFormatter() {
                    if (null === this._symbol) return;
                    if (null === this._mainSeries.symbolInfo()) this._isActualSymbol = !1;
                    else {
                        const t = this._mainSeries.isConvertedToOtherCurrency() || this._mainSeries.isConvertedToOtherUnit();
                        this._isActualSymbol = !t && this._mainSeries.symbolSameAsCurrent(this._symbol)
                    }
                    this._updateItemBySymbol(), this.redraw()
                }
                _updateItemBySymbol() {
                    var t;
                    const e = this._symbol;
                    if (null === e || !this._isActualSymbol) return this.tradedItems(!0).forEach(t => t.clearRealtime()), null === (t = this._pipValueWV) || void 0 === t || t.destroy(), void(this._pipValueWV = null);
                    this.tradedItems(!0).forEach(t => {
                        t.subscribeRealtime(), t.updateCurrency(e)
                    }), this._createPipValueWV()
                }
                _isSourceShouldBeShownOnPane(t) {
                    return t.containsMainSeries()
                }
                _positionVisibilityGetter() {
                    return this._isSourceShouldBeShown() && this.showPositionProperty().value()
                }
                _orderVisibilityGetter() {
                    return this._isSourceShouldBeShown() && this.showOrderProperty().value()
                }
            }
        },
        46841: (t, e, i) => {
            i.r(e), i.d(e, {
                TradedSourcesManager: () => y
            });
            var o, r = i(88537),
                s = i(2683),
                a = i(83450),
                l = i(51951),
                n = i(37978),
                d = i(1962),
                c = i(76337),
                h = i(51466),
                u = i(94489),
                _ = i.n(u);
            ! function(t) {
                t[t.Threshold = 4] = "Threshold"
            }(o || (o = {}));
            class p {
                constructor(t, e) {
                    this._computedBorderPoint = new Map, this._isNoOverlapMode = new(_()), this._isItemsOverlap = !1, this._invalidated = !0, this._sortedItemRenderers = null, this._itemsByPosition = null, t.subscribe(t => {
                        t.filter(t => !(0, h.isTradedSource)(t)).length > 0 && this._isNoOverlapMode.setValue(!1)
                    }), e.subscribe(this, () => {
                        this._isNoOverlapMode.setValue(!1)
                    })
                }
                registerRenderer(t) {
                    this._computedBorderPoint.set(t, null)
                }
                removeRenderer(t) {
                    t && this._computedBorderPoint.delete(t), this.invalidateCache()
                }
                invalidateCache() {
                    for (const t of this._computedBorderPoint.keys()) this._computedBorderPoint.set(t, null);
                    this._sortedItemRenderers = null, this._itemsByPosition = null, this._invalidated = !0
                }
                isInvalidated() {
                    return this._invalidated
                }
                isItemsOverlap() {
                    return this._isItemsOverlap
                }
                setNoOverlapMode(t, e = !0) {
                    e && this.invalidateCache(), this._isNoOverlapMode.setValue(t)
                }
                isNoOverlapMode() {
                    return this._isNoOverlapMode.value()
                }
                noOverlapModeChanged() {
                    return this._isNoOverlapMode.readonly()
                }
                getBorderPoint(t) {
                    const e = this._computedBorderPoint.get(t);
                    return e || null
                }
                alignItems(t) {
                    if (this._invalidated) {
                        if (this._alignItemsHorizontally(t), this._checkIfItemsOverlap(t), this._isNoOverlapMode.value()) {
                            if (!this._isItemsOverlap) return void this.setNoOverlapMode(!1, !1);
                            this._alignItemsVertically(t)
                        }
                        this._invalidated = !1
                    }
                }
                _checkIfItemsOverlap(t) {
                    const e = this._getSortedRenderers(t);
                    let i = !1;
                    for (let r = 1; r < e.length; r++) {
                        const s = e[r],
                            a = e[r - 1];
                        if (s.rect(t).top - a.rect(t).bottom + o.Threshold <= 0) {
                            i = !0;
                            break
                        }
                    }
                    this._isItemsOverlap = i
                }
                _alignItemsVertically(t) {
                    const e = this._getSortedRenderers(t);
                    for (let i = 1; i < e.length; i++) {
                        const r = e[i],
                            s = e[i - 1];
                        r.rectWithOffsets(t).top - s.rectWithOffsets(t).bottom + o.Threshold <= 0 && (s.clearCache(), r.clearCache(), r.setAlignedTopCoordinate(s.rectWithOffsets(t).bottom))
                    }
                }
                _alignItemsHorizontally(t) {
                    const e = this._computeRightmostAndLeftmostBorder(t);
                    if (!e) return;
                    const {
                        rightmostBorder: i,
                        leftmostBorder: o
                    } = e;
                    for (const t of this._computedBorderPoint.keys()) this._computedBorderPoint.set(t, {
                        rightmostBorder: i,
                        leftmostBorder: o
                    })
                }
                _computeRightmostAndLeftmostBorder(t) {
                    const e = this._getItemRenderers().map(e => e.rect(t));
                    let i = e[0].right,
                        o = e[0].left;
                    for (const t of e) t.right > i && (i = t.right), t.left < o && (o = t.left);
                    return {
                        rightmostBorder: i,
                        leftmostBorder: o
                    }
                }
                _getSortedRenderers(t) {
                    return null !== this._sortedItemRenderers || (this._sortedItemRenderers = this._getItemsByPosition(t).inFieldOfView.sort((t, e) => e.data().sortingIndex - t.data().sortingIndex)), this._sortedItemRenderers
                }
                _getItemsByPosition(t) {
                    return null !== this._itemsByPosition || (this._itemsByPosition = this._getItemRenderers().reduce((e, i) => {
                        const o = i.rect(t);
                        return o.top > t.physicalHeight ? e.overflownBottom.push(i) : o.bottom < 0 ? e.overflownTop.push(i) : e.inFieldOfView.push(i), e
                    }, {
                        inFieldOfView: [],
                        overflownTop: [],
                        overflownBottom: []
                    })), this._itemsByPosition
                }
                _getItemRenderers() {
                    return [...this._computedBorderPoint.keys()].reduce((t, e) => [...t, ...e.itemRenderers()], []).filter(t => t.data().visible)
                }
            }
            const b = () => {},
                m = () => {};

            function v(t, e, i, o, s, a, l, n) {
                const {
                    realtimeProvider: u,
                    pipValueType: v,
                    currencyGetter: f
                } = a;
                s.addCustomSource("traded" + t, (t, d) => {
                    const y = d.properties().childs().tradingProperties.childs(),
                        P = (0, c.createPrimitivePropertyFromGetterAndSubscription)(d.isInReplay.bind(d), d.onInReplayStateChanged()),
                        g = a.realtimeProvider,
                        C = (0, r.ensureNotNull)(g.activeBroker()),
                        x = (0, c.combineProperty)((t, e) => e, P, y.showOrders),
                        k = (0, c.combineProperty)((t, e) => e, P, y.showPositions),
                        T = {
                            lineProperties: {
                                width: y.lineWidth,
                                style: y.lineStyle,
                                extend: y.extendLeft
                            },
                            horizontalAlignment: y.horizontalAlignment,
                            showOrders: x,
                            showPositions: k,
                            showReverse: y.showReverse,
                            positionPL: y.positionPL.childs(),
                            bracketsPL: y.bracketsPL.childs()
                        };
                    if (!l.has(d)) {
                        const t = (0, c.createWVFromGetterAndSubscription)(() => d.selection().allSources(), d.onSelectedSourceChanged());
                        l.set(d, new p(t, d.mainSeries().dataEvents().symbolResolved()))
                    }
                    const S = (0, r.ensureDefined)(l.get(d));
                    return new h.TradedSource(t, d, T, o, v, e, u, t => function(t, e, i, o) {
                        const r = t => ({
                                sellPipValue: t,
                                buyPipValue: t
                            }),
                            s = new(_())(r(1));
                        let a = !1;
                        (async () => {
                            if (!a) {
                                const i = await e(t);
                                s.setValue(r(i.pipValue))
                            }
                        })();
                        const l = (t, e) => {
                            a = !0, s.setValue(e)
                        };
                        return i(t, l), s.readonly().spawn(() => o(t, l))
                    }(t, g.symbolInfo.bind(g), C.subscribePipValue.bind(C), C.unsubscribePipValue.bind(C)), {
                        exitTrackingMode: () => s.activeChartWidget.value().exitTrackingMode(),
                        currencyGetter: f,
                        onDataUpdateRejected: i,
                        trackEvent: n,
                        showChartHint: b,
                        hideChartHint: m
                    }, S)
                }, d.CustomSourceLayer.Topmost)
            }
            const f = (0, l.getLogger)("Trading.Order");
            class y {
                constructor(t, e, i, o) {
                    this._tradedSourceData = new Map, this._ordersData = new Map, this._positionsData = new Map, this._positionsRealToParentIds = new Map, this._tradedSourceRenderersControllerMap = new WeakMap, this._ordersService = t, this._positionsService = e, this._chartWidgetCollection = i, this._realtimeProvider = o.realtimeProvider, this._brokerCommandsUIGetter = o.brokerCommandsUI, this._trackEvent = o.trackEvent, this._showTradedSources = o.showTradedSources, this._pipValueType = o.pipValueType, this._addOrderItems(this._ordersService.activeOrders()), this._ordersService.activeOrdersUpdated().subscribe(this, t => this._addOrderItems([t])), this._ordersService.activeOrdersRemoved().subscribe(this, this._removeTradedSourceItems), this._addPositionItems(this._positionsService.positions()), this._positionsService.positionUpdate().subscribe(this, t => this._addPositionItems([t])), this._positionsService.positionsRemoved().subscribe(this, this._removeTradedSourceItems)
                }
                destroy() {
                    this._ordersService.activeOrdersUpdated().unsubscribeAll(this), this._ordersService.activeOrdersRemoved().unsubscribeAll(this), this._ordersData.clear(), this._positionsService.positionUpdate().unsubscribeAll(this), this._positionsService.positionsRemoved().unsubscribeAll(this), this._positionsData.clear(), this._tradedSourceData.clear()
                }
                _getBrackets(t) {
                    const e = [];
                    if (!this._ordersData.has(t)) {
                        const e = this._positionsRealToParentIds.get(t);
                        void 0 !== e && (t = e)
                    }
                    return this._ordersData.forEach(i => {
                        i.parentId === t && e.push((0, s.merge)((0, s.clone)(i), {
                            callbacks: this._createCallbacksForOrder(i)
                        }))
                    }), e
                }
                _createTradedSourceData(t) {
                    let e;
                    const i = this._ordersData.get(t),
                        o = this._positionsData.get(t);
                    return void 0 !== i ? e = (0, s.merge)((0, s.clone)(i), {
                        mainType: 0,
                        callbacks: this._createCallbacksForOrder(i)
                    }) : void 0 !== o && (e = (0, s.merge)((0, s.clone)(o), {
                        mainType: 1,
                        callbacks: this._createCallbacksForPosition()
                    })), {
                        main: e,
                        brackets: this._getBrackets(t)
                    }
                }
                _recreateTradedSource(t) {
                    const e = this._createTradedSourceData(t),
                        i = this._tradedSourceData.get(t);
                    if (void 0 !== i) i.setValue(e);
                    else {
                        const i = new a.WatchedObject(e);
                        v(t, i, this._ordersService.orderRejected(), this._showTradedSources, this._chartWidgetCollection, {
                            realtimeProvider: this._realtimeProvider,
                            pipValueType: this._pipValueType,
                            currencyGetter: this._positionsService.getCurrency.bind(this._positionsService)
                        }, this._tradedSourceRenderersControllerMap, this._trackEvent), this._tradedSourceData.set(t, i)
                    }
                }
                async _findPositionRealIdByParentId(t) {
                    const e = this._positionsData.get(t);
                    let i;
                    if (void 0 !== e) i = e.id;
                    else if (i = await this._positionsService.realIdFromBroker(t), null === i) {
                        const e = this._currentRealPositionIdByParentId(t);
                        return null !== e && this._positionsRealToParentIds.delete(e), null
                    }
                    return this._positionsRealToParentIds.set(i, t), i
                }
                _currentRealPositionIdByParentId(t) {
                    for (const e of Array.from(this._positionsRealToParentIds.keys()))
                        if (this._positionsRealToParentIds.get(e) === t) return e;
                    return null
                }
                async _findAndUpdateParentPosition(t, e = !1) {
                    const i = this._currentRealPositionIdByParentId(t),
                        o = await this._findPositionRealIdByParentId(t);
                    if (null !== i && null === o && this._tradedSourceData.has(i) && this._recreateTradedSource(i), null === i && null !== o) {
                        const e = this._tradedSourceData.get(t);
                        void 0 !== e && void 0 === e.value().main && this._removeTradedSource(t)
                    }
                    e && i === o || this._recreateTradedSource(o || t)
                }
                _addOrderItems(t) {
                    for (const e of t) {
                        this._removeSourceIfChangedParent(e), this._ordersData.set(e.id, e);
                        const t = void 0 !== e.parentId ? e.parentId : e.id;
                        if (2 === e.parentType || 3 === e.parentType) return void this._findAndUpdateParentPosition(t);
                        this._recreateTradedSource(t)
                    }
                }
                _addPositionItems(t) {
                    for (const e of t) {
                        const t = e.id;
                        this._positionsData.set(t, e), this._recreateTradedSource(t);
                        this._ordersService.activeOrders().filter(t => 1 !== t.parentType && void 0 !== t.parentType && t.symbol === e.symbol).forEach(t => {
                            this._findAndUpdateParentPosition(t.parentId, !0)
                        })
                    }
                }
                _removeSourceIfChangedParent(t) {
                    const e = this._ordersData.get(t.id);
                    void 0 === e || e.parentId === t.parentId && e.parentType === t.parentType || this._removeTradedSourceItems([e.id])
                }
                _removeTradedSourceItems(t) {
                    for (const e of t) {
                        let t = e;
                        if (!this._tradedSourceData.has(e))
                            for (const i of this._tradedSourceData.keys()) {
                                for (const o of (0, r.ensureDefined)(this._tradedSourceData.get(i)).value().brackets)
                                    if (o.id === e) {
                                        t = i;
                                        break
                                    }
                                if (t === i) break
                            }
                        this._positionsData.delete(e), this._ordersData.delete(e);
                        const i = this._createTradedSourceData(t);
                        if (void 0 === i.main && 0 === i.brackets.length) this._removeTradedSource(t);
                        else {
                            const e = this._tradedSourceData.get(t);
                            void 0 !== e && e.setValue(i)
                        }
                    }
                }
                _removeTradedSource(t) {
                    var e, i;
                    this._tradedSourceData.delete(t), e = this._chartWidgetCollection, i = t, e.removeCustomSource("traded" + i)
                }
                _createCallbacksForOrder(t) {
                    const e = {};
                    return t.supportModify && (e.modifyOrder = this._modifyOrder.bind(this)),
                        t.supportMove && (e.moveOrder = this._moveOrder.bind(this)), t.supportCancel && (e.cancelOrder = this._cancelOrder.bind(this)), e
                }
                _createCallbacksForPosition() {
                    return {
                        reversePosition: this._reversePosition.bind(this),
                        modifyPosition: this._modifyPosition.bind(this),
                        closePosition: this._closePosition.bind(this)
                    }
                }
                async _processingModifyOrder(t, e, i, o) {
                    let s = !1;
                    try {
                        s = await (0, r.ensureNotNull)(this._brokerCommandsUIGetter()).modifyOrder(t, i, o)
                    } catch (t) {
                        f.logError("Try to modify order with error " + (0, n.errorToString)(t))
                    }
                    return s
                }
                _modifyOrder(t, e, i, o) {
                    const s = (0, r.ensureNotNull)(this._ordersService.find(t));
                    return this._processingModifyOrder(e, s, o, i)
                }
                _moveOrder(t, e, i) {
                    const o = (0, r.ensureNotNull)(this._ordersService.find(t));
                    return this._processingModifyOrder(e, o, !0, i)
                }
                _cancelOrder(t) {
                    return (0, r.ensureNotNull)(this._brokerCommandsUIGetter()).cancelOrder(t)
                }
                _reversePosition(t) {
                    return (0, r.ensureNotNull)(this._brokerCommandsUIGetter()).reversePosition(t)
                }
                _modifyPosition(t, e = {}, i, o) {
                    const s = (0, r.ensureNotNull)(this._brokerCommandsUIGetter());
                    return this._positionsService.isDisplayModeTrades() ? (0, r.ensureDefined)(s.editTradeBrackets).call(s, t, e, i, o) : s.editPositionBrackets(t, e, i, o)
                }
                _closePosition(t) {
                    const e = (0, r.ensureNotNull)(this._brokerCommandsUIGetter());
                    return this._positionsService.isDisplayModeTrades() ? e.closeTrade(t) : e.closePosition(t)
                }
            }
        },
        36267: (t, e, i) => {
            i.d(e, {
                drawArrow: () => l,
                drawOutlinedArrowHead: () => n,
                drawHalfArrow: () => d,
                drawText: () => c,
                drawUnderlinedText: () => h,
                drawOutlinedText: () => u
            });
            var o = i(67912),
                r = i(91604),
                s = i(30551),
                a = i(69639);

            function l(t, e, i, o, r, s, a, l, n) {
                t.save();
                const d = t.lineWidth,
                    c = t.lineWidth % 2 ? .5 : 0;
                t.translate(e + c, i + c), s && t.scale(1, -1);
                const h = Math.round(l / 2),
                    u = h,
                    _ = h;
                n && (t.strokeStyle = r, t.lineWidth = 2 * t.lineWidth, t.lineCap = "square", t.beginPath(), t.moveTo(0, h), t.lineTo(u, 0), t.lineTo(l, h), t.stroke(), t.lineCap = "butt", t.beginPath(), t.moveTo(_, a + (t.lineWidth - d) / 2), t.lineTo(u, 0), t.stroke()), t.lineWidth = d, t.strokeStyle = o, t.lineCap = "square", t.beginPath(), t.moveTo(0, h), t.lineTo(u, 0), t.lineTo(l, h), t.stroke(), t.lineCap = "butt", t.beginPath(), t.moveTo(_, a), t.lineTo(u, 0), t.stroke(), t.restore()
            }

            function n(t, e, i, o, r, s, a, l = 90) {
                t.save();
                const n = t.lineWidth,
                    d = 2 * t.lineWidth,
                    c = t.lineWidth % 2 ? .5 : 0;
                t.translate(e + c + a / 2 - n, i + c), t.rotate(l * Math.PI / 180);
                const h = Math.round(a / 2);
                t.lineCap = "square", t.lineWidth = d, t.strokeStyle = r, t.beginPath(), t.moveTo(0, h), t.lineTo(h, 0), t.lineTo(a, h), t.stroke(), t.lineCap = "square", t.lineWidth = n, t.strokeStyle = o, t.beginPath(), t.moveTo(0, h), t.lineTo(h, 0), t.lineTo(a, h), t.stroke(), t.restore()
            }

            function d(t, e, i, o, r, s, a) {
                t.save(), t.strokeStyle = o, t.lineJoin = "miter";
                const l = t.lineWidth % 2 ? .5 : 0,
                    n = Math.round(s / 3);
                t.translate(e + l, i + l), r && t.scale(-1, -1), t.beginPath(), t.moveTo(0, s), t.lineTo(0, 0), t.lineTo(-a, n), t.stroke(), t.restore()
            }

            function c(t, e, i, o, r, s, l, n) {
                t.save(), t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = l, t.font = n, t.translate(o, r + s), (0, a.drawScaled)(t, e, () => {
                    t.fillText(i, 0, 0)
                }), t.restore()
            }

            function h(t, e, i, l, n, d, c, h, u) {
                t.save(), t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = c, t.font = h;
                const _ = 1,
                    p = 1,
                    b = (o.LineStyle.Dashed, Math.round(10 * e) / 2),
                    m = Math.max(1, Math.floor(p * e)),
                    v = u.width * e,
                    f = Math.max(1, Math.floor(_ * e)),
                    y = Math.round(l - v / 2),
                    P = Math.round(n + b + f);
                t.save(), t.strokeStyle = c, t.lineWidth = m;
                const g = Math.round(3 * t.lineWidth),
                    C = Math.round(3 * t.lineWidth / 2),
                    x = Math.round(2 * t.lineWidth);
                let k = Math.trunc(v / (g + x));
                const T = Math.trunc(v % (g + x) / 2),
                    S = [];
                for (S.push(C + T); k > 1;) S.push(x, g), k--;
                S.push(x, C + T), (0, r.setLineDash)(t, S), (0, s.drawHorizontalLine)(t, P, y, y + Math.round(v)), t.translate(l, n + d), (0, a.drawScaled)(t, e, () => {
                    t.fillText(i, 0, 0)
                }), t.restore()
            }

            function u(t, e, i, o, r, s, l, n, d) {
                t.save(), t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = l, t.font = n, t.lineJoin = "round", t.translate(o, r + s), (0, a.drawScaled)(t, e, () => {
                    t.strokeStyle = d, t.strokeText(i, 0, 0), t.fillText(i, 0, 0)
                }), t.restore()
            }
        },
        28978: (t, e, i) => {
            i.d(e, {
                blendColors: () => s,
                generateDisabledThemeColors: () => a
            });
            var o = i(24377),
                r = i(2683);
            const s = (t, e) => (0, o.rgbaToString)((0, o.blendRgba)((0, o.parseRgba)(t), (0, o.parseRgba)(e)));

            function a(t, e) {
                const i = (0, r.clone)(t);
                for (const [o, r] of Object.entries(t)) i[o] = "string" == typeof r ? s(r, e) : a(r, e);
                return i
            }
        },
        15479: (t, e, i) => {
            i.r(e), i.d(e, {
                TradedItemsChartCollectionFacade: () => l
            });
            var o = i(88537),
                r = i(1962),
                s = i(91084),
                a = i(51466);
            class l {
                constructor(t) {
                    this._chartWidgetCollection = t
                }
                dropHoveredItem() {
                    this._activeWidgetChartModel().setHoveredSource(null, null)
                }
                setHoveredItem(t) {
                    this._setItemState(t, (t, e) => {
                        this._activeWidgetChartModel().setHoveredSource(t, e)
                    })
                }
                setSelectedItem(t) {
                    this._setItemState(t, (t, e) => {
                        this._activeWidgetChartModel().selectionMacro(i => {
                            if (t) i.clearSelection(), i.addSourceToSelection(t, e);
                            else {
                                i.selection().customSources().find(a.isTradedSource) && i.clearSelection()
                            }
                        })
                    })
                }
                _setItemState(t, e) {
                    const {
                        source: i,
                        item: o
                    } = this._findSourceAndItem(t.id, t.type);
                    if (!i || !o) return void e(null, null);
                    e(i, new s.HitTestResult(s.HitTestResult.CUSTOM, {
                        activeItem: {
                            id: o.id(),
                            part: 6
                        }
                    }).data())
                }
                _activeWidgetChartModel() {
                    return (0, o.ensureNotNull)(this._chartWidgetCollection.activeChartWidget.value()).model().model()
                }
                _findSourceAndItem(t, e) {
                    for (const i of this._activeWidgetChartModel().customSources(r.CustomSourceLayer.Topmost))
                        if ((0, a.isTradedSource)(i)) {
                            const o = i.findItemWithType(t, e);
                            if (o) return {
                                source: i,
                                item: o
                            }
                        }
                    return {}
                }
            }
        },
        60818: (t, e, i) => {
            i.r(e), i.d(e, {
                BidAsk: () => m
            });
            var o = i(88537),
                r = i(2683),
                s = i(80601),
                a = i(70120),
                l = i(12669);
            class n extends l.PriceLineAxisView {
                constructor(t, e, i) {
                    super(), this._model = t, this._source = e, this._priceType = i
                }
                _value() {
                    const t = this._model.mainSeries(),
                        e = t.priceScale(),
                        i = t.firstValue();
                    if (null === i) return {
                        noData: !0
                    };
                    const o = this._source.getPrice(this._priceType);
                    if (null === o) return {
                        noData: !0
                    };
                    const r = e.priceToCoordinate(o, i);
                    return {
                        noData: !1,
                        floatCoordinate: r,
                        coordinate: r,
                        color: "",
                        formattedPricePercentage: "",
                        formattedPriceAbsolute: "",
                        formattedPriceIndexedTo100: "",
                        text: "",
                        index: 0
                    }
                }
                _priceLineColor(t) {
                    const e = this._source.properties().childs();
                    return 0 === this._priceType ? e.bidLineColor.value() : e.askLineColor.value()
                }
                _lineWidth() {
                    return this._source.properties().childs().lineWidth.value()
                }
                _lineStyle() {
                    return this._source.properties().childs().lineStyle.value()
                }
                _isVisible() {
                    return this._source.properties().childs().visible.value()
                }
            }
            var d = i(25177),
                c = i(9540);
            class h extends c.PriceAxisView {
                constructor(t, e, i) {
                    super(), this._model = t, this._source = e, this._priceType = i
                }
                _updateRendererData(t, e, i) {
                    if (t.visible = !1, e.visible = !1, !this._model.properties().childs().scalesProperties.childs().showBidAskLabels.value()) return;
                    const o = this._model.mainSeries(),
                        r = o.priceScale(),
                        s = o.firstValue();
                    if (null === s) return;
                    const a = this._source.getPrice(this._priceType);
                    if (null === a) return;
                    t.visible = !0, e.visible = !0, t.text = r.formatPriceAbsolute(a), e.text = 0 === this._priceType ? (0, d.t)("Bid") : (0, d.t)("Ask"), i.coordinate = r.priceToCoordinate(a, s);
                    const l = this._source.properties().childs();
                    i.background = 0 === this._priceType ? l.bidLineColor.value() : l.askLineColor.value()
                }
            }
            var u = i(3084),
                _ = i(91084);
            class p extends u.HorizontalLinePaneView {
                constructor(t, e, i, o) {
                    super(), this._model = t, this._source = e, this._priceType = i;
                    const r = {
                        doubleClickHandler: o,
                        doubleTapHandler: o
                    };
                    this._lineRenderer.setHitTest(new _.HitTestResult(_.HitTestResult.REGULAR, r))
                }
                _updateImpl() {
                    const t = this._lineRendererData;
                    t.visible = !1;
                    const e = this._source.properties().childs();
                    if (!e.visible.value()) return;
                    const i = this._model.mainSeries(),
                        o = i.priceScale(),
                        r = i.firstValue();
                    if (null === r) return;
                    const s = this._source.getPrice(this._priceType);
                    null !== s && (t.visible = !0, t.y = o.priceToCoordinate(s, r), t.linestyle = e.lineStyle.value(), t.linewidth = e.lineWidth.value(), t.color = 0 === this._priceType ? e.bidLineColor.value() : e.askLineColor.value())
                }
            }
            var b = i(36907);
            class m extends a.CustomSourceBase {
                constructor(t, e, i, o) {
                    super(t, e), this._ask = null, this._bid = null, this._symbol = null, this._realtimeProvider = i, this._bidLinesPaneView = new p(e, this, 0, o), this._askLinesPaneView = new p(e, this, 1, o), this._bidPriceAxisView = new h(e, this, 0), this._askPriceAxisView = new h(e, this, 1), this._regularPriceAxisViews = [this._bidPriceAxisView, this._askPriceAxisView], this._bidLabelPaneView = new s.PanePriceAxisView(this._bidPriceAxisView, e.mainSeries(), e), this._askLabelPaneView = new s.PanePriceAxisView(this._askPriceAxisView, e.mainSeries(), e), this._bidPriceLineAxisView = new n(e, this, 0), this._askPriceLineAxisView = new n(e, this, 1), this._externalPriceAxisViews = [this._bidPriceLineAxisView, this._askPriceLineAxisView], this._updateRealtimeDataHandler = this._updateRealtimeData.bind(this);
                    const r = e.mainSeries().dataEvents();
                    r.symbolResolved().subscribe(this, this._createTradedSymbol), r.symbolError().subscribe(this, this._createTradedSymbol), this._createTradedSymbol()
                }
                destroy() {
                    const t = this._model.mainSeries().dataEvents();
                    t.symbolResolved().unsubscribeAll(this), t.symbolError().unsubscribeAll(this), this._clearTradedSymbol()
                }
                paneViews(t) {
                    return this._isMainSourcePane(t) ? [this._bidLinesPaneView, this._askLinesPaneView] : []
                }
                labelPaneViews(t) {
                    return this._isMainSourcePane(t) ? [this._bidLabelPaneView, this._askLabelPaneView] : []
                }
                priceAxisViews(t, e) {
                    return this._isMainSourcePane(t) ? t.findTargetPriceAxisViews(this, e, this._regularPriceAxisViews, this._externalPriceAxisViews) : []
                }
                priceScale() {
                    return this._model.mainSeries().priceScale()
                }
                updateAllViews(t) {
                    this._bidLinesPaneView.update(t), this._askLinesPaneView.update(t), this._bidPriceAxisView.update(t), this._askPriceAxisView.update(t), this._bidPriceLineAxisView.update(t), this._askPriceLineAxisView.update(t), this._bidLabelPaneView.update(t), this._askLabelPaneView.update(t)
                }
                getPrice(t) {
                    return 1 === t ? this._ask : this._bid
                }
                properties() {
                    return this._model.mainSeries().properties().childs().bidAsk
                }
                _createTradedSymbol() {
                    const t = function(t) {
                        if (t.isConvertedToOtherCurrency() || t.isConvertedToOtherUnit()) return null;
                        const e = t.symbolInfo();
                        return null === e ? t.proSymbol() : e.pro_name || e.full_name || e.name || null
                    }(this._model.mainSeries());
                    t !== this._symbol && (this._clearTradedSymbol(), null !== t && this._initTradedSymbol(t))
                }
                _initTradedSymbol(t) {
                    this._symbol = t, this._realtimeProvider.subscribeRealtime(this._symbol, this._updateRealtimeDataHandler)
                }
                _clearTradedSymbol() {
                    this._ask = null, this._bid = null, null !== this._symbol && (this._realtimeProvider.unsubscribeRealtime((0, o.ensureNotNull)(this._symbol), this._updateRealtimeDataHandler), this._symbol = null)
                }
                _updateRealtimeData(t, e, i) {
                    const o = e.ask,
                        s = e.bid;
                    o === s ? (this._ask = null, this._bid = null) : ((0, r.isNumber)(o) && (this._ask = o), (0, r.isNumber)(s) && (this._bid = s)), (this._model.mainSeries().properties().childs().bidAsk.childs().visible.value() || this._model.properties().childs().scalesProperties.childs().showBidAskLabels.value()) && (this.updateAllViews((0, b.dataSourceChangeEvent)(this.id())), this._model.updateSource(this))
                }
                _isMainSourcePane(t) {
                    return this._model.paneForSource(this._model.mainSeries()) === t
                }
            }
        }
    }
]);
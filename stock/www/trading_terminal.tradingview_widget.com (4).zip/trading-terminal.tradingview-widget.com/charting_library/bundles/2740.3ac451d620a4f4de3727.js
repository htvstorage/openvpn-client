(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2740, 8890], {
        55576: e => {
            e.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        96746: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        67179: e => {
            e.exports = {
                dialog: "dialog-HExheUfY",
                wrapper: "wrapper-HExheUfY",
                separator: "separator-HExheUfY"
            }
        },
        91441: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                container: "container-tuOy5zvD",
                unsetAlign: "unsetAlign-tuOy5zvD",
                title: "title-tuOy5zvD",
                subtitle: "subtitle-tuOy5zvD",
                ellipsis: "ellipsis-tuOy5zvD",
                close: "close-tuOy5zvD"
            }
        },
        28712: e => {
            e.exports = {
                container: "container-CcsqUMct",
                inputContainer: "inputContainer-CcsqUMct",
                withCancel: "withCancel-CcsqUMct",
                input: "input-CcsqUMct",
                icon: "icon-CcsqUMct",
                cancel: "cancel-CcsqUMct"
            }
        },
        74246: e => {
            e.exports = {
                actions: "actions-FZxvEi7a",
                actionButton: "actionButton-FZxvEi7a"
            }
        },
        82132: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                itemRow: "itemRow-uhHv1IHJ",
                multiLine: "multiLine-uhHv1IHJ",
                cell: "cell-uhHv1IHJ",
                itemInfoCell: "itemInfoCell-uhHv1IHJ",
                description: "description-uhHv1IHJ",
                symbolDescription: "symbolDescription-uhHv1IHJ",
                flag: "flag-uhHv1IHJ",
                exchangeDescription: "exchangeDescription-uhHv1IHJ",
                marketType: "marketType-uhHv1IHJ",
                exchangeName: "exchangeName-uhHv1IHJ",
                actionHandleWrap: "actionHandleWrap-uhHv1IHJ",
                hover: "hover-uhHv1IHJ",
                selected: "selected-uhHv1IHJ",
                active: "active-uhHv1IHJ",
                highlighted: "highlighted-uhHv1IHJ",
                light: "light-uhHv1IHJ",
                "highlight-animation-theme-light": "highlight-animation-theme-light-uhHv1IHJ",
                dark: "dark-uhHv1IHJ",
                "highlight-animation-theme-dark": "highlight-animation-theme-dark-uhHv1IHJ",
                markedFlag: "markedFlag-uhHv1IHJ",
                offset: "offset-uhHv1IHJ",
                descriptionCell: "descriptionCell-uhHv1IHJ",
                addition: "addition-uhHv1IHJ",
                exchangeCell: "exchangeCell-uhHv1IHJ",
                fixedWidth: "fixedWidth-uhHv1IHJ",
                expandHandle: "expandHandle-uhHv1IHJ",
                expanded: "expanded-uhHv1IHJ",
                symbolTitle: "symbolTitle-uhHv1IHJ",
                invalid: "invalid-uhHv1IHJ",
                noDescription: "noDescription-uhHv1IHJ",
                highlightedText: "highlightedText-uhHv1IHJ",
                icon: "icon-uhHv1IHJ",
                narrow: "narrow-uhHv1IHJ",
                dataMode: "dataMode-uhHv1IHJ",
                actionsCell: "actionsCell-uhHv1IHJ",
                action: "action-uhHv1IHJ",
                targetAction: "targetAction-uhHv1IHJ",
                removeAction: "removeAction-uhHv1IHJ",
                addAction: "addAction-uhHv1IHJ",
                markedFlagWrap: "markedFlagWrap-uhHv1IHJ",
                markedFlagMobile: "markedFlagMobile-uhHv1IHJ",
                logo: "logo-uhHv1IHJ",
                isExpandable: "isExpandable-uhHv1IHJ"
            }
        },
        42608: e => {
            e.exports = {
                wrap: "wrap-nJ9riypy",
                libAllSelected: "libAllSelected-nJ9riypy",
                container: "container-nJ9riypy",
                iconWrap: "iconWrap-nJ9riypy",
                icon: "icon-nJ9riypy",
                title: "title-nJ9riypy",
                highlighted: "highlighted-nJ9riypy",
                description: "description-nJ9riypy",
                mobile: "mobile-nJ9riypy",
                allSelected: "allSelected-nJ9riypy",
                desktop: "desktop-nJ9riypy",
                allSelectedIcon: "allSelectedIcon-nJ9riypy",
                selected: "selected-nJ9riypy",
                titleWithoutDesc: "titleWithoutDesc-nJ9riypy",
                textBlock: "textBlock-nJ9riypy",
                bordered: "bordered-nJ9riypy"
            }
        },
        90819: e => {
            e.exports = {
                container: "container-ZOfHxh0z",
                contentList: "contentList-ZOfHxh0z",
                contentListDesktop: "contentListDesktop-ZOfHxh0z",
                searchSourceItemsContainer: "searchSourceItemsContainer-ZOfHxh0z",
                searchSourceItemsContainerDesktop: "searchSourceItemsContainerDesktop-ZOfHxh0z",
                groupTitleDesktop: "groupTitleDesktop-ZOfHxh0z",
                emptyText: "emptyText-ZOfHxh0z",
                noResultsDesktop: "noResultsDesktop-ZOfHxh0z"
            }
        },
        77338: e => {
            e.exports = {
                wrap: "wrap-LlwUhJDs",
                item: "item-LlwUhJDs",
                small: "small-LlwUhJDs",
                text: "text-LlwUhJDs",
                exchange: "exchange-LlwUhJDs"
            }
        },
        74915: e => {
            e.exports = {
                wrap: "wrap-SLQfcZ66",
                watchlist: "watchlist-SLQfcZ66",
                noFeed: "noFeed-SLQfcZ66",
                scrollContainer: "scrollContainer-SLQfcZ66",
                listContainer: "listContainer-SLQfcZ66",
                multiLineItemsContainer: "multiLineItemsContainer-SLQfcZ66"
            }
        },
        98749: e => {
            e.exports = {
                button: "button-v1WheJQo",
                desktop: "desktop-v1WheJQo"
            }
        },
        92540: e => {
            e.exports = {
                search: "search-RSKUFnp7",
                upperCase: "upperCase-RSKUFnp7",
                symbolType: "symbolType-RSKUFnp7",
                spinnerWrap: "spinnerWrap-RSKUFnp7",
                emptyText: "emptyText-RSKUFnp7",
                noResultsDesktop: "noResultsDesktop-RSKUFnp7",
                brokerCheckboxWrap: "brokerCheckboxWrap-RSKUFnp7"
            }
        },
        53474: e => {
            e.exports = {
                flagWrap: "flagWrap-7I0uFLqE",
                icon: "icon-7I0uFLqE",
                caret: "caret-7I0uFLqE",
                title: "title-7I0uFLqE"
            }
        },
        6215: e => {
            e.exports = {
                dialog: "dialog-JcokGZNe",
                tabletDialog: "tabletDialog-JcokGZNe",
                desktopDialog: "desktopDialog-JcokGZNe"
            }
        },
        70516: e => {
            e.exports = {
                childrenWrapper: "childrenWrapper-HNZPlz4e",
                container: "container-HNZPlz4e"
            }
        },
        99167: e => {
            e.exports = {
                bubbles: "bubbles-bgopH9MJ",
                multiLine: "multiLine-bgopH9MJ",
                bubble: "bubble-bgopH9MJ"
            }
        },
        74765: e => {
            e.exports = {
                bubble: "bubble-vcCjkHCG",
                animated: "animated-vcCjkHCG",
                content: "content-vcCjkHCG",
                "appearance-default": "appearance-default-vcCjkHCG",
                active: "active-vcCjkHCG",
                red: "red-vcCjkHCG",
                blue: "blue-vcCjkHCG",
                green: "green-vcCjkHCG",
                orange: "orange-vcCjkHCG",
                purple: "purple-vcCjkHCG",
                cyan: "cyan-vcCjkHCG",
                pink: "pink-vcCjkHCG",
                "appearance-text": "appearance-text-vcCjkHCG",
                "fontSize-s": "fontSize-s-vcCjkHCG",
                "fontSize-m": "fontSize-m-vcCjkHCG",
                "size-m": "size-m-vcCjkHCG",
                "size-l": "size-l-vcCjkHCG"
            }
        },
        22932: e => {
            e.exports = {
                highlighted: "highlighted-YWUtZHTy"
            }
        },
        91626: e => {
            e.exports = {
                separator: "separator-jtAq6E4V"
            }
        },
        40367: e => {
            e.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        73850: (e, t, n) => {
            "use strict";
            n.d(t, {
                SEPARATOR_PREFIX: () => r
            });
            const r = "###"
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => o
            });
            var r = n(59496);
            const o = r.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...o
                } = e;
                return r.createElement("span", { ...o,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        417: (e, t, n) => {
            "use strict";

            function r(e) {
                return a(e, s)
            }

            function o(e) {
                return a(e, i)
            }

            function a(e, t) {
                const n = Object.entries(e).filter(t),
                    r = {};
                for (const [e, t] of n) r[e] = t;
                return r
            }

            function s(e) {
                const [t, n] = e;
                return 0 === t.indexOf("data-") && "string" == typeof n
            }

            function i(e) {
                return 0 === e[0].indexOf("aria-")
            }
            n.d(t, {
                filterDataProps: () => r,
                filterAriaProps: () => o,
                filterProps: () => a,
                isDataAttribute: () => s,
                isAriaAttribute: () => i
            })
        },
        75803: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => l,
                ToolWidgetButton: () => c
            });
            var r = n(59496),
                o = n(97754),
                a = n(72571),
                s = n(4257),
                i = n(55576);
            const l = i,
                c = r.forwardRef((e, t) => {
                    const {
                        icon: n,
                        isActive: l,
                        isOpened: c,
                        isDisabled: u,
                        isGrouped: d,
                        isHovered: h,
                        onClick: p,
                        text: m,
                        textBeforeIcon: v,
                        title: f,
                        theme: g = i,
                        className: y,
                        forceInteractive: b,
                        "data-name": S,
                        ...x
                    } = e, C = o(y, g.button, f && "apply-common-tooltip", {
                        [g.isActive]: l,
                        [g.isOpened]: c,
                        [g.isInteractive]: (b || Boolean(p)) && !u,
                        [g.isDisabled]: u,
                        [g.isGrouped]: d,
                        [g.hover]: h,
                        [g.newStyles]: s.hasNewHeaderToolbarStyles
                    }), w = n && ("string" == typeof n ? r.createElement(a.Icon, {
                        className: g.icon,
                        icon: n
                    }) : r.cloneElement(n, {
                        className: o(g.icon, n.props.className)
                    }));
                    return r.createElement("div", { ...x,
                        ref: t,
                        "data-role": "button",
                        className: C,
                        onClick: u ? void 0 : p,
                        title: f,
                        "data-name": S
                    }, v && m && r.createElement("div", {
                        className: o("js-button-text", g.text)
                    }, m), w, !v && m && r.createElement("div", {
                        className: o("js-button-text", g.text)
                    }, m))
                })
        },
        4257: (e, t, n) => {
            "use strict";
            n.d(t, {
                hasNewHeaderToolbarStyles: () => r
            });
            n(82527);
            const r = !1
        },
        12650: (e, t, n) => {
            "use strict";
            n.d(t, {
                marketType: () => l
            });
            var r = n(25177);
            n(35897);
            const o = new Map,
                a = {
                    context: "market_type"
                },
                s = {
                    cfd: (0, r.t)("cfd", a),
                    bitcoin: (0, r.t)("crypto", a),
                    crypto: (0, r.t)("crypto", a),
                    dr: (0, r.t)("dr", a),
                    forex: (0, r.t)("forex", a),
                    futures: (0, r.t)("futures", a),
                    index: (0, r.t)("index", a),
                    stock: (0, r.t)("stock", a),
                    economic: (0, r.t)("economy", a)
                },
                i = new Set(["cfd", "spreadbet", "defi"]);

            function l(e, t = []) {
                const n = t.filter(e => i.has(e)),
                    l = `${e}_${n.sort().join("_")}`,
                    c = o.get(l);
                if (void 0 !== c) return c;
                const u = Boolean(t.length) ? (0, r.t)(e, a) + " " + n.join(" ") : s[e] || e;
                return o.set(l, u), u
            }
        },
        47152: (e, t, n) => {
            "use strict";

            function r(e) {
                let t = null;
                return (n, ...r) => (null == t || t.abort(), t = new AbortController, null == n || n.addEventListener("error", () => null == t ? void 0 : t.abort(), {
                    once: !0
                }), e(t.signal, ...r))
            }

            function o(e) {
                if (!l(e)) throw e
            }

            function a(e) {
                if (l(e)) throw e
            }

            function s(e) {
                return (null == e ? void 0 : e.aborted) ? Promise.reject(i()) : new Promise((t, n) => {
                    null == e || e.addEventListener("abort", () => n(i()), {
                        once: !0
                    })
                })
            }

            function i() {
                return new DOMException("Aborted", "AbortError")
            }

            function l(e) {
                return e instanceof Error && "AbortError" === e.name
            }

            function c(e, t) {
                return Promise.race([s(e), t])
            }
            async function u(e, t) {
                let n;
                try {
                    await c(e, new Promise(e => {
                        n = setTimeout(e, t)
                    }))
                } finally {
                    clearTimeout(n)
                }
            }
            n.d(t, {
                respectLatest: () => r,
                skipAbortError: () => o,
                rethrowAbortError: () => a,
                isAbortError: () => l,
                respectAbort: () => c,
                delay: () => u
            })
        },
        33054: (e, t, n) => {
            "use strict";
            n.d(t, {
                mediaQueryAddEventListener: () => r,
                mediaQueryRemoveEventListener: () => o
            });
            const r = (e, t) => {
                    (null == e ? void 0 : e.addEventListener) ? e.addEventListener("change", t): e.addListener(t)
                },
                o = (e, t) => {
                    (null == e ? void 0 : e.removeEventListener) ? e.removeEventListener("change", t): e.removeListener(t)
                }
        },
        21709: (e, t, n) => {
            "use strict";

            function r(e, t, n, r, o) {
                function a(o) {
                    if (e > o.timeStamp) return;
                    const a = o.target;
                    void 0 !== n && null !== t && null !== a && a.ownerDocument === r && (t.contains(a) || n(o))
                }
                return o.click && r.addEventListener("click", a, !1), o.mouseDown && r.addEventListener("mousedown", a, !1), o.touchEnd && r.addEventListener("touchend", a, !1), o.touchStart && r.addEventListener("touchstart", a, !1), () => {
                    r.removeEventListener("click", a, !1), r.removeEventListener("mousedown", a, !1), r.removeEventListener("touchend", a, !1), r.removeEventListener("touchstart", a, !1)
                }
            }
            n.d(t, {
                addOutsideEventListener: () => r
            })
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => l
            });
            var r = n(35922);
            const o = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                a = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let s = 0,
                i = !1;

            function l(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++s) {
                    const e = (0, r.getCSSProperty)(t, "overflow"),
                        o = (0, r.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, r.setStyle)(n, "right", (0, r.getScrollbarWidth)() + "px"), t.style.paddingRight = o + (0, r.getScrollbarWidth)() + "px", i = !0), t.classList.add("i-no-scroll")
                } else if (!e && s > 0 && 0 == --s && (t.classList.remove("i-no-scroll"), i)) {
                    (0, r.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (l = (0, r.getContentWidth)(n), o() ? 0 : a() ? 46 : Math.min(Math.max(l, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, r.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", i = !1
                }
                var l
            }
        },
        96038: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogBreakpoints: () => o
            });
            var r = n(96746);
            const o = {
                SmallHeight: r["small-height-breakpoint"],
                TabletSmall: r["tablet-small-breakpoint"],
                TabletNormal: r["tablet-normal-breakpoint"]
            }
        },
        53337: (e, t, n) => {
            "use strict";
            n.d(t, {
                AdaptivePopupDialog: () => k
            });
            var r = n(59496),
                o = n(88537),
                a = n(33054),
                s = n(97754),
                i = n.n(s),
                l = n(80185),
                c = n(98043),
                u = n(40766),
                d = n(94707),
                h = n(96038),
                p = n(30052),
                m = n(10549),
                v = n(6594),
                f = n(59410),
                g = n(72571),
                y = n(90410),
                b = n(35487),
                S = n(91441);

            function x(e) {
                const {
                    title: t,
                    subtitle: n,
                    showCloseIcon: o = !0,
                    onClose: a,
                    renderBefore: s,
                    renderAfter: l,
                    draggable: c,
                    className: u,
                    unsetAlign: d
                } = e, [h, p] = (0, r.useState)(!1);
                return r.createElement(y.DialogHeaderContext.Provider, {
                    value: {
                        setHideClose: p
                    }
                }, r.createElement("div", {
                    className: i()(S.container, u, (n || d) && S.unsetAlign)
                }, s, r.createElement("div", {
                    "data-dragg-area": c,
                    className: S.title
                }, r.createElement("div", {
                    className: S.ellipsis
                }, t), n && r.createElement("div", {
                    className: i()(S.ellipsis, S.subtitle)
                }, n)), l, o && !h && r.createElement(g.Icon, {
                    className: S.close,
                    icon: b,
                    onClick: a,
                    "data-name": "close",
                    "data-role": "button"
                })))
            }
            var C = n(67179);
            const w = {
                    vertical: 20
                },
                E = {
                    vertical: 0
                };
            class k extends r.PureComponent {
                constructor() {
                    super(...arguments), this._controller = null, this._reference = null, this._orientationMediaQuery = null, this._renderChildren = (e, t) => (this._controller = e, this.props.render({
                        requestResize: this._requestResize,
                        centerAndFit: this._centerAndFit,
                        isSmallWidth: t
                    })), this._handleReference = e => this._reference = e, this._handleClose = () => {
                        this.props.onClose()
                    }, this._handleOpen = () => {
                        void 0 !== this.props.onOpen && this.props.isOpened && this.props.onOpen(this.props.fullScreen || window.matchMedia(h.DialogBreakpoints.TabletSmall).matches)
                    }, this._handleKeyDown = e => {
                        var t;
                        if (!e.defaultPrevented) switch (this.props.onKeyDown && this.props.onKeyDown(e), (0, l.hashFromEvent)(e)) {
                            case 27:
                                if (e.defaultPrevented) return;
                                if (this.props.forceCloseOnEsc && this.props.forceCloseOnEsc()) return void this._handleClose();
                                const {
                                    activeElement: n
                                } = document, r = (0, o.ensureNotNull)(this._reference);
                                if (null !== n) {
                                    if (e.preventDefault(), "true" === (t = n).getAttribute("data-haspopup") && "true" !== t.getAttribute("data-expanded")) return void this._handleClose();
                                    if ((0, c.isTextEditingField)(n)) return void r.focus();
                                    if (r.contains(n)) return void this._handleClose()
                                }
                        }
                    }, this._requestResize = () => {
                        null !== this._controller && this._controller.recalculateBounds()
                    }, this._centerAndFit = () => {
                        null !== this._controller && this._controller.centerAndFit()
                    }
                }
                componentDidMount() {
                    f.subscribe(v.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), this._handleOpen(), void 0 !== this.props.onOpen && (this._orientationMediaQuery = window.matchMedia("(orientation: portrait)"), (0, a.mediaQueryAddEventListener)(this._orientationMediaQuery, this._handleOpen))
                }
                componentWillUnmount() {
                    f.unsubscribe(v.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), null !== this._orientationMediaQuery && (0, a.mediaQueryRemoveEventListener)(this._orientationMediaQuery, this._handleOpen)
                }
                focus() {
                    (0, o.ensureNotNull)(this._reference).focus()
                }
                getElement() {
                    return this._reference
                }
                contains(e) {
                    var t, n;
                    return null !== (n = null === (t = this._reference) || void 0 === t ? void 0 : t.contains(e)) && void 0 !== n && n
                }
                render() {
                    const {
                        className: e,
                        wrapperClassName: t,
                        headerClassName: n,
                        isOpened: o,
                        title: a,
                        dataName: s,
                        onClickOutside: l,
                        additionalElementPos: c,
                        additionalHeaderElement: v,
                        backdrop: f,
                        shouldForceFocus: g = !0,
                        showSeparator: y,
                        subtitle: b,
                        draggable: S = !0,
                        fullScreen: k = !1,
                        showCloseIcon: I = !0,
                        rounded: _ = !0,
                        isAnimationEnabled: N,
                        growPoint: H,
                        dialogTooltip: D,
                        unsetHeaderAlign: M,
                        onDragStart: T,
                        dataDialogName: L
                    } = this.props, A = "after" !== c ? v : void 0, F = "after" === c ? v : void 0, R = "string" == typeof a ? a : L || "";
                    return r.createElement(p.MatchMedia, {
                        rule: h.DialogBreakpoints.SmallHeight
                    }, c => r.createElement(p.MatchMedia, {
                        rule: h.DialogBreakpoints.TabletSmall
                    }, h => r.createElement(u.PopupDialog, {
                        rounded: !(h || k) && _,
                        className: i()(C.dialog, e),
                        isOpened: o,
                        reference: this._handleReference,
                        onKeyDown: this._handleKeyDown,
                        onClickOutside: l,
                        onClickBackdrop: l,
                        fullscreen: h || k,
                        guard: c ? E : w,
                        boundByScreen: h || k,
                        shouldForceFocus: g,
                        backdrop: f,
                        draggable: S,
                        isAnimationEnabled: N,
                        growPoint: H,
                        name: this.props.dataName,
                        dialogTooltip: D,
                        onDragStart: T
                    }, r.createElement("div", {
                        className: i()(C.wrapper, t),
                        "data-name": s,
                        "data-dialog-name": R
                    }, void 0 !== a && r.createElement(x, {
                        draggable: S && !(h || k),
                        onClose: this._handleClose,
                        renderAfter: F,
                        renderBefore: A,
                        subtitle: b,
                        title: a,
                        showCloseIcon: I,
                        className: n,
                        unsetAlign: M
                    }), y && r.createElement(d.Separator, {
                        className: C.separator
                    }), r.createElement(m.PopupContext.Consumer, null, e => this._renderChildren(e, h || k))))))
                }
            }
        },
        90410: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogHeaderContext: () => r
            });
            const r = n(59496).createContext({
                setHideClose: () => {}
            })
        },
        31862: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogSearch: () => u
            });
            var r = n(59496),
                o = n(97754),
                a = n.n(o),
                s = n(25177),
                i = n(72571),
                l = n(80200),
                c = n(28712);

            function u(e) {
                const {
                    children: t,
                    renderInput: n,
                    onCancel: o,
                    ...u
                } = e;
                return r.createElement("div", {
                    className: c.container
                }, r.createElement("div", {
                    className: a()(c.inputContainer, o && c.withCancel)
                }, n || r.createElement(d, { ...u
                })), t, r.createElement(i.Icon, {
                    className: c.icon,
                    icon: l
                }), o && r.createElement("div", {
                    className: c.cancel,
                    onClick: o
                }, (0, s.t)("Cancel")))
            }

            function d(e) {
                const {
                    className: t,
                    reference: n,
                    value: o,
                    onChange: s,
                    onFocus: i,
                    onBlur: l,
                    onKeyDown: u,
                    onSelect: d,
                    placeholder: h,
                    ...p
                } = e;
                return r.createElement("input", { ...p,
                    ref: n,
                    type: "text",
                    className: a()(t, c.input),
                    autoComplete: "off",
                    "data-role": "search",
                    placeholder: h,
                    value: o,
                    onChange: s,
                    onFocus: i,
                    onBlur: l,
                    onSelect: d,
                    onKeyDown: u
                })
            }
        },
        56871: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchDialogContentItem: () => g
            });
            var r = n(59496),
                o = n(97754),
                a = n.n(o),
                s = n(88537),
                i = n(72571),
                l = (n(82527), n(60598)),
                c = n(12991),
                u = n(44080),
                d = n(11982),
                h = n(97265),
                p = n(2054),
                m = n(72535),
                v = n(34677),
                f = n(82132);

            function g(e) {
                const {
                    dangerousTitleHTML: t,
                    title: n,
                    dangerousDescriptionHTML: o,
                    description: g,
                    searchToken: y,
                    exchangeName: b,
                    marketType: S,
                    onClick: x,
                    isSelected: C,
                    isEod: w = !1,
                    isActive: E = !1,
                    isOffset: k = !1,
                    invalid: I = !1,
                    isHighlighted: _ = !1,
                    hideExchange: N = !1,
                    hideMarkedListFlag: H = !1,
                    onExpandClick: D,
                    isExpanded: M,
                    hoverComponent: T,
                    country: L,
                    providerId: A,
                    source: F,
                    type: R,
                    flag: O,
                    itemRef: P,
                    onMouseOut: B,
                    onMouseOver: W,
                    className: J,
                    actions: z,
                    reference: V,
                    fullSymbolName: q,
                    logoId: U,
                    currencyLogoId: Z,
                    baseCurrencyLogoId: G,
                    shortName: j,
                    hideLogo: Q = !1
                } = e, {
                    isSmallWidth: K,
                    isMobile: $
                } = (0, s.ensureNotNull)((0, r.useContext)(u.SymbolSearchItemsDialogContext)), Y = Boolean(T), X = !I && !N && ($ || !Y), ee = (0, h.useWatchedValueReadonly)({
                    watchedValue: p.watchedTheme
                }) === d.StdTheme.Dark ? f.dark : f.light, te = T;
                return r.createElement("div", {
                    className: a()(f.itemRow, K && f.multiLine, _ && f.highlighted, _ && ee, C && f.selected, E && f.active, I && f.invalid, !$ && m.mobiletouch && Y && f.hover, J),
                    onClick: function(e, t) {
                        if (!e || t.defaultPrevented) return;
                        t.preventDefault(), e(t)
                    }.bind(null, x),
                    "data-role": e["data-role"] || "list-item",
                    "data-active": E,
                    "data-name": "symbol-search-dialog-content-item",
                    onMouseOut: B,
                    onMouseOver: W,
                    ref: V
                }, r.createElement("div", {
                    ref: P,
                    className: a()(f.itemInfoCell, f.cell, k && f.offset)
                }, r.createElement("div", {
                    className: a()(f.actionHandleWrap, f.fixedWidth)
                }, r.createElement(r.Fragment, null, !1, D && r.createElement("div", {
                    onClick: function(e) {
                        if (!D || e.defaultPrevented) return;
                        e.preventDefault(), D(e)
                    }
                }, r.createElement(i.Icon, {
                    className: a()(f.expandHandle, M && f.expanded, C && f.selected),
                    icon: v
                })), !1)), r.createElement("div", {
                    className: a()(f.description, !1)
                }, n && r.createElement("div", {
                    className: a()(f.symbolTitle, E && f.active, I && f.invalid, !Boolean(o) && f.noDescription),
                    "data-name": "list-item-title"
                }, "string" == typeof n && y ? r.createElement(l.HighlightedText, {
                    className: f.highlightedText,
                    text: n,
                    queryString: y,
                    rules: (0, c.createRegExpList)(y)
                }) : n, w && r.createElement("span", {
                    className: f.dataMode
                }, "E")), !n && t && r.createElement("div", {
                    className: a()(f.symbolTitle, E && f.active, I && f.invalid),
                    "data-name": "list-item-title"
                }, r.createElement("span", {
                    dangerouslySetInnerHTML: {
                        __html: t
                    }
                }), w && r.createElement("span", {
                    className: f.dataMode
                }, "E")), K && ne())), !K && r.createElement("div", {
                    className: a()(f.cell, f.descriptionCell, Boolean(te) && f.addition)
                }, ne(), te ? r.createElement(te, { ...e,
                    className: f.actions,
                    onMouseOver: void 0,
                    onMouseOut: void 0
                }) : null), K && te ? r.createElement(te, { ...e,
                    className: f.cell,
                    onMouseOver: void 0,
                    onMouseOut: void 0
                }) : null, X && r.createElement("div", {
                    className: a()(f.exchangeCell, f.cell)
                }, r.createElement("div", {
                    className: a()(f.exchangeDescription)
                }, r.createElement("div", {
                    className: a()(f.marketType, E && f.active)
                }, S), "economic" === R && F ? r.createElement("div", {
                    className: a()(f.exchangeName, E && f.active, "apply-common-tooltip", f.narrow),
                    title: F
                }, F) : r.createElement("div", {
                    className: a()(f.exchangeName, E && f.active)
                }, b)), !1), r.createElement("div", {
                    className: a()(f.cell, Boolean(z) && f.actionsCell)
                }, z));

                function ne() {
                    if (I) return null;
                    const e = a()(f.symbolDescription, E && f.active, !m.mobiletouch && "apply-overflow-tooltip apply-overflow-tooltip--allow-text");
                    return g ? r.createElement("div", {
                        className: e
                    }, y ? r.createElement(l.HighlightedText, {
                        className: f.highlightedText,
                        text: g,
                        queryString: y,
                        rules: (0, c.createRegExpList)(y)
                    }) : g) : o ? r.createElement("div", {
                        className: e,
                        dangerouslySetInnerHTML: {
                            __html: o
                        }
                    }) : null
                }
            }
        },
        42923: (e, t, n) => {
            "use strict";
            n.d(t, {
                qualifyProName: () => s,
                QualifiedSources: () => r
            });
            var r, o = n(88537),
                a = n(82527);
            n(21167);

            function s(e) {
                return e
            }! function(e) {
                function t(e) {
                    return e.pro_name
                }

                function n(e) {
                    {
                        const t = a.enabled("pay_attention_to_ticker_not_symbol") ? e.ticker : e.full_name;
                        return (0, o.ensureDefined)(t)
                    }
                }
                e.fromQuotesSnapshot = function(e) {
                    return "error" === e.status ? e.symbolname : e.values.pro_name
                }, e.fromQuotesResponse = function(e) {
                    const {
                        values: n,
                        symbolname: r,
                        status: o
                    } = e;
                    return "error" === o && r ? r : t(n)
                }, e.fromQuotes = t, e.fromSymbolSearchResult = function(e, t) {
                    {
                        const {
                            ticker: n,
                            full_name: r
                        } = null != t ? t : e;
                        return a.enabled("pay_attention_to_ticker_not_symbol") ? (0, o.ensureDefined)(null != n ? n : r) : (0, o.ensureDefined)(r)
                    }
                }, e.fromSymbolInfo = n, e.fromSymbolMessage = function(e, t) {
                    return "symbol_resolved" === t.method ? n(t.params[1]) : e
                }
            }(r || (r = {}))
        },
        27989: (e, t, n) => {
            "use strict";
            n.d(t, {
                QuoteSessionContext: () => r
            });
            const r = n(59496).createContext(null)
        },
        84327: (e, t, n) => {
            "use strict";

            function r(e) {
                return "" === e.value()
            }

            function o(e, t) {
                return e.filter(e => e.includes(t))
            }

            function a(e) {
                const t = new Map;
                return e.forEach(e => {
                    t.has(e.group()) ? t.get(e.group()).push(e) : t.set(e.group(), [e])
                }), t
            }

            function s(e, t) {
                return t.map(t => new e(t))
            }
            n.d(t, {
                isAllSearchSourcesSelected: () => r,
                filterSearchSources: () => o,
                splitSearchSourcesByGroup: () => a,
                createSearchSources: () => s
            })
        },
        58323: (e, t, n) => {
            "use strict";
            n.d(t, {
                showSymbolSearchItemsDialog: () => c
            });
            var r = n(59496),
                o = n(87995),
                a = n(53327),
                s = n(27989),
                i = n(63192),
                l = n(155);

            function c(e) {
                const {
                    initialMode: t = "symbolSearch",
                    autofocus: n = !0,
                    defaultValue: c,
                    showSpreadActions: u,
                    selectSearchOnInit: d,
                    onSearchComplete: h,
                    onSearchFeedReady: p,
                    dialogTitle: m,
                    placeholder: v,
                    fullscreen: f,
                    initialScreen: g,
                    wrapper: y,
                    dialog: b,
                    contentItem: S,
                    onClose: x,
                    footer: C,
                    symbolTypes: w,
                    searchInput: E,
                    emptyState: k,
                    hideMarkedListFlag: I,
                    dialogWidth: _ = "auto",
                    manager: N
                } = e;
                if (i.dialogsOpenerManager.isOpened("SymbolSearch") || i.dialogsOpenerManager.isOpened("ChangeIntervalDialog")) return;
                const H = document.createElement("div"),
                    D = r.createElement(a.SlotContext.Provider, {
                        value: null != N ? N : null
                    }, r.createElement(s.QuoteSessionContext.Provider, {
                        value: null
                    }, r.createElement(l.SymbolSearchItemsDialog, {
                        onClose: M,
                        initialMode: t,
                        defaultValue: c,
                        showSpreadActions: u,
                        hideMarkedListFlag: I,
                        onSearchFeedReady: p,
                        selectSearchOnInit: d,
                        onSearchComplete: h,
                        dialogTitle: m,
                        placeholder: v,
                        fullscreen: f,
                        initialScreen: g,
                        wrapper: y,
                        dialog: b,
                        contentItem: S,
                        footer: C,
                        symbolTypes: w,
                        searchInput: E,
                        emptyState: k,
                        autofocus: n,
                        dialogWidth: _
                    })));

                function M() {
                    o.unmountComponentAtNode(H), i.dialogsOpenerManager.setAsClosed("SymbolSearch"), x && x()
                }
                return o.render(D, H), i.dialogsOpenerManager.setAsOpened("SymbolSearch"), {
                    close: M
                }
            }
        },
        59223: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchDialogBodyContext: () => r
            });
            const r = n(59496).createContext(null)
        },
        44080: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchItemsDialogContext: () => r
            });
            const r = n(59496).createContext(null)
        },
        155: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchItemsDialog: () => Be
            });
            var r = n(59496),
                o = n(97754),
                a = n.n(o),
                s = n(25177),
                i = n(7002),
                l = n(32012),
                c = n(13739),
                u = n(82527),
                d = n(96038),
                h = n(53337),
                p = n(72571),
                m = n(44080),
                v = n(31862),
                f = n(84327),
                g = n(70516);

            function y(e) {
                const {
                    children: t,
                    className: n
                } = e;
                return r.createElement("div", {
                    className: a()(g.container, n)
                }, r.createElement("div", {
                    className: g.childrenWrapper
                }, t))
            }
            var b = n(88537),
                S = n(40976),
                x = n(60598),
                C = n(12991),
                w = n(58311),
                E = n(42608);

            function k(e) {
                const {
                    searchSource: t,
                    onClick: n,
                    queryString: o
                } = e, {
                    selectedSearchSource: s,
                    isAllSearchSourcesSelected: i,
                    isMobile: l
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext), c = (0, b.ensureNotNull)(s).value(), u = i(t), d = t.value() === c, h = (0, r.useMemo)(() => (0, C.createRegExpList)(o), [o]), v = t.description(), f = v && !u, g = a()(E.container, l ? E.mobile : E.desktop, d && E.selected, u && E.allSelected, u && E.libAllSelected, !u && l && E.bordered);
                return r.createElement("div", {
                    className: a()(!l && E.wrap, u && E.libAllSelected),
                    onClick: n
                }, r.createElement("div", {
                    className: g
                }, r.createElement("div", {
                    className: E.iconWrap
                }, !!u && r.createElement(p.Icon, {
                    className: a()(E.icon, E.allSelectedIcon),
                    icon: w
                })), r.createElement("div", {
                    className: E.textBlock
                }, r.createElement("div", {
                    className: a()(E.title, !f && !l && E.titleWithoutDesc)
                }, r.createElement(x.HighlightedText, {
                    className: a()(d && E.highlighted),
                    queryString: o,
                    text: t.name(),
                    rules: h
                })), f && r.createElement("div", {
                    className: a()(E.description, "apply-overflow-tooltip")
                }, r.createElement(x.HighlightedText, {
                    className: E.highlighted,
                    queryString: o,
                    rules: h,
                    text: v
                })))))
            }
            var I = n(97265),
                _ = n(2054),
                N = n(51049),
                H = n(59223),
                D = n(75606),
                M = n(505),
                T = n(90819);
            const L = {
                emptyTextClassName: T.emptyText
            };

            function A(e) {
                const {
                    searchSources: t
                } = e, {
                    setSelectedSearchSource: n,
                    setMode: o,
                    isMobile: i,
                    emptyState: l,
                    autofocus: c
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext), u = (0, I.useWatchedValueReadonly)({
                    watchedValue: _.watchedTheme
                }) === N.StdTheme.Dark ? D : M, [d, h] = (0, r.useState)(""), g = (0, r.useMemo)(() => [{
                    group: null,
                    sources: (0, f.filterSearchSources)(t, d)
                }], [t, d]), b = (0, r.useRef)(null), x = (0, r.useRef)(null);
                (0, r.useLayoutEffect)(() => {
                    var e;
                    c && (null === (e = null == b ? void 0 : b.current) || void 0 === e || e.focus())
                }, []);
                const C = l ? r.createElement(l, null) : r.createElement(y, {
                        className: T.noResultsDesktop
                    }, r.createElement(p.Icon, {
                        icon: u
                    }), r.createElement("div", {
                        className: T.emptyText
                    }, (0, s.t)("No exchanges match your criteria"))),
                    w = !(g.length && g.every(e => 0 === e.sources.length));
                return r.createElement(H.SymbolSearchDialogBodyContext.Provider, {
                    value: L
                }, r.createElement(v.DialogSearch, {
                    placeholder: (0, s.t)("Search"),
                    onChange: function(e) {
                        h(e.target.value), x && x.current && (x.current.scrollTop = 0)
                    },
                    reference: b
                }), w ? r.createElement("div", {
                    ref: x,
                    className: a()(T.contentList, !i && T.contentListDesktop),
                    onTouchStart: function() {
                        var e;
                        null === (e = b.current) || void 0 === e || e.blur()
                    }
                }, g.map(e => {
                    const {
                        group: t,
                        sources: n
                    } = e;
                    return 0 === n.length ? r.createElement(r.Fragment, {
                        key: t
                    }) : r.createElement(r.Fragment, {
                        key: t
                    }, !1, r.createElement("div", {
                        className: a()(T.searchSourceItemsContainer, !i && T.searchSourceItemsContainerDesktop)
                    }, n.map(e => r.createElement(k, {
                        key: e.value(),
                        searchSource: e,
                        queryString: d,
                        onClick: E.bind(null, e)
                    }))))
                })) : C);

                function E(e) {
                    n(e), o("symbolSearch")
                }
            }
            var F = n(87995),
                R = n(47152);
            n(47668), n(10645);

            function O(e) {
                return e.hasOwnProperty("exchange")
            }
            async function P(e) {
                return new Promise(t => {
                    window.ChartApiInstance.searchSymbols(e.text || "", e.exchange || "", e.type || "", "", !1, !0, "", !0, "", e => {
                        t(e)
                    })
                })
            }
            var B = n(21167),
                W = n(73026),
                J = n(32133),
                z = n(80185),
                V = n(75803),
                q = n(91118),
                U = n(7753),
                Z = n(78989),
                G = n(51448),
                j = n(26502),
                Q = n(15402),
                K = n(74246);

            function $(e) {
                var t;
                const {
                    state: n,
                    update: o
                } = e, {
                    searchRef: a,
                    forceUpdate: s,
                    upperCaseEnabled: c
                } = (0, b.ensureNotNull)((0, r.useContext)(m.SymbolSearchItemsDialogContext)), d = (0, i.tokenize)(null === (t = a.current) || void 0 === t ? void 0 : t.value), h = (0, l.validate)(d);
                let p = [{
                    icon: q,
                    insert: "/",
                    type: "binaryOp",
                    name: "division"
                }, {
                    icon: U,
                    insert: "-",
                    type: "binaryOp",
                    name: "subtraction"
                }, {
                    icon: Z,
                    insert: "+",
                    type: "binaryOp",
                    name: "addition"
                }, {
                    icon: G,
                    insert: "*",
                    type: "binaryOp",
                    name: "multiplication"
                }];
                return u.enabled("hide_exponentiation_spread_operator") || (p = p.concat([{
                    icon: j,
                    insert: "^",
                    type: "binaryOp",
                    name: "exponentiation"
                }])), u.enabled("hide_reciprocal_spread_operator") || (p = p.concat([{
                    icon: Q,
                    type: "complete",
                    name: "1/x",
                    callback: () => {
                        !a.current || h.errors.length || h.warnings.length || (a.current.value = (0, l.stringifyTokens)((0, l.flip)(d)), s())
                    }
                }])), r.createElement("div", {
                    className: K.actions
                }, p.map(e => r.createElement(V.ToolWidgetButton, {
                    className: K.actionButton,
                    icon: e.icon,
                    key: e.name,
                    isDisabled: Y(e, h),
                    onClick: () => function(e) {
                        var t;
                        if (!Y(e, h)) {
                            if (e.insert && a.current) {
                                const t = a.current.value + e.insert;
                                a.current.value = t, a.current.setSelectionRange(t.length, t.length);
                                const [r, , i] = (0,
                                    l.getCurrentTokenParamsFromInput)(a.current, c);
                                n.current && (n.current.selectedIndexValue = -1, n.current.searchSpreadsValue = (0, l.isSpread)(i), n.current.searchTokenValue = r), s(), o()
                            }
                            e.callback && e.callback(), null === (t = a.current) || void 0 === t || t.focus(), (0, J.trackEvent)("GUI", "SS", e.name)
                        }
                    }(e)
                })))
            }

            function Y(e, t) {
                let n = !1;
                if (!t.errors.length) switch (e.type) {
                    case "binaryOp":
                        n = "var" === t.currentState;
                        break;
                    case "openBrace":
                        n = "var" !== t.currentState;
                        break;
                    case "closeBrace":
                        n = "var" === t.currentState && t.braceBalance > 0;
                        break;
                    case "complete":
                        n = !t.errors.length && !t.warnings.length
                }
                return !n
            }
            var X = n(417),
                ee = n(74765);

            function te(e) {
                const {
                    title: t,
                    isActive: n,
                    isAnimated: r,
                    activeColor: o,
                    size: s = "m",
                    appearance: i = "default",
                    fontSize: l = "m",
                    className: c
                } = e;
                return a()(ee.bubble, n && ee.active, o && ee[o], t && "apply-common-tooltip", s && ee["size-" + s], l && ee["fontSize-" + l], i && ee["appearance-" + i], r && ee.animated, c)
            }

            function ne(e) {
                const {
                    id: t,
                    title: n,
                    tabIndex: o,
                    role: s,
                    contentClassName: i,
                    children: l,
                    onClick: c,
                    onMouseDown: u,
                    reference: d,
                    ...h
                } = e;
                return r.createElement("span", { ...(0, X.filterAriaProps)(h),
                    ...(0, X.filterDataProps)(h),
                    id: t,
                    title: n,
                    tabIndex: o,
                    role: s,
                    className: te(e),
                    onClick: c,
                    onMouseDown: u,
                    ref: d
                }, r.createElement("span", {
                    className: a()(ee.content, i)
                }, l))
            }
            var re = n(99167);

            function oe(e) {
                const {
                    className: t,
                    itemClassName: n,
                    itemContentClassName: a,
                    items: s,
                    getItemTitle: i,
                    getItemTooltip: l,
                    getItemKey: c,
                    checkItemIsActive: u,
                    getItemColor: d,
                    onBubbleClick: h,
                    multiline: p,
                    children: m,
                    BubbleComponent: v = ne,
                    reference: f,
                    fontSize: g
                } = e;
                return r.createElement("div", {
                    className: o(t, re.bubbles, p && re.multiLine),
                    ref: f
                }, s.map((e, t) => r.createElement(v, {
                    key: c ? c(e) : t,
                    id: c ? c(e) : t.toString(),
                    className: o(re.bubble, n),
                    contentClassName: a,
                    onClick: function() {
                        h(e)
                    },
                    onMouseDown: function(e) {
                        e.preventDefault()
                    },
                    isActive: !!u && u(e),
                    activeColor: d ? d(e) : void 0,
                    fontSize: g,
                    title: l ? l(e) : void 0
                }, i(e))), m)
            }
            var ae = n(32455),
                se = n(83199),
                ie = n(7270),
                le = n.n(ie),
                ce = n(15783),
                ue = n(53474);

            function de(e) {
                const {
                    mode: t,
                    setMode: n,
                    searchRef: o,
                    cachedInputValue: i,
                    selectedSearchSource: l,
                    isAllSearchSourcesSelected: c,
                    upperCaseEnabled: u
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext), d = (0, b.ensureNotNull)(l), h = "symbolSearch" === t, v = c(d);
                return h ? r.createElement("div", {
                    className: a()(ue.flagWrap, "apply-common-tooltip"),
                    title: (0, s.t)("Select source"),
                    onClick: function() {
                        o.current && (i.current = u ? o.current.value.toUpperCase() : o.current.value);
                        n("exchange")
                    }
                }, !!v && r.createElement(p.Icon, {
                    className: ue.icon,
                    icon: w
                }), r.createElement("div", {
                    className: ue.title
                }, d.name()), r.createElement(ce.ToolWidgetCaret, {
                    className: ue.caret,
                    dropped: !1
                })) : null
            }
            var he = n(77338);

            function pe(e) {
                const {
                    isSmallWidth: t,
                    selectedSearchSource: n,
                    searchSources: o
                } = (0, b.ensureNotNull)((0, r.useContext)(m.SymbolSearchItemsDialogContext)), i = n && o.length > 1 && !(0, B.exchangeSelectDisabled)();
                return r.createElement("div", {
                    className: a()(he.wrap, t && he.small)
                }, r.createElement("div", {
                    className: he.item
                }, r.createElement("div", {
                    className: he.text
                }, t ? (0, s.t)("Symbol & description") : (0, s.t)("Symbol"))), r.createElement("div", {
                    className: he.item
                }, !t && r.createElement("div", {
                    className: he.text
                }, (0,
                    s.t)("Description")), i && r.createElement("div", {
                    className: he.exchange
                }, r.createElement(de, null))))
            }
            var me = n(34581),
                ve = n(74915);

            function fe(e) {
                const {
                    onTouchMove: t,
                    listRef: n,
                    className: o,
                    listWrapRef: s,
                    virtualListKey: i,
                    items: l,
                    getItemSize: c,
                    hideFeed: u
                } = e, {
                    mode: d,
                    isSmallWidth: h,
                    handleListWidth: p
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext), [v, f] = (0, r.useState)(null), g = (0, r.useCallback)(e => {
                    const {
                        index: t,
                        style: n
                    } = e;
                    return r.createElement("div", {
                        style: n
                    }, l[t])
                }, [l]), y = (0, r.useCallback)(e => (0, b.ensure)(l[e].key), [l]), x = "watchlist" === d && null !== v;
                return r.createElement(le(), {
                    onMeasure: function(e) {
                        f(e.height), p(e.width)
                    }
                }, r.createElement("div", {
                    ref: s,
                    className: a()(ve.wrap, x && ve.watchlist, u && ve.noFeed, o),
                    onTouchMove: t
                }, r.createElement("div", {
                    className: a()(ve.scrollContainer, u && ve.noFeed)
                }, x ? r.createElement(se.VariableSizeList, {
                    key: i,
                    ref: n,
                    className: ve.listContainer,
                    width: "100%",
                    height: (0, b.ensureNotNull)(v),
                    itemCount: l.length,
                    itemSize: c,
                    children: g,
                    itemKey: y,
                    overscanCount: 20,
                    direction: (0, me.isRtl)() ? "rtl" : "ltr"
                }) : r.createElement("div", {
                    className: a()(ve.listContainer, h && ve.multiLineItemsContainer)
                }, r.createElement(pe, null), ...l))))
            }
            var ge = n(56871),
                ye = n(92540);
            const be = u.enabled("hide_image_invalid_symbol");

            function Se(e) {
                const {
                    token: t,
                    state: n,
                    otherSymbolsCount: o,
                    onChangeSymbolTypeFilter: a,
                    onResetFilters: s,
                    onListTouchMove: i,
                    brokerTitle: l,
                    isBrokerChecked: c,
                    onBrokerCheckboxChange: u,
                    listRef: d,
                    listWrapRef: h
                } = e, {
                    mode: p,
                    isMobile: v,
                    selectedSymbolType: f,
                    symbolTypes: g,
                    feedItems: y,
                    contentItem: b,
                    emptyState: x = xe
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext), C = l && r.createElement(BrokerCheckbox, {
                    brokerTitle: l,
                    checked: c,
                    onCheckboxChange: u
                }), w = "symbolSearch" === p && "good" === n, E = null != b ? b : ge.SymbolSearchDialogContentItem, k = (0, r.useMemo)(() => y.map(e => r.createElement(E, { ...e,
                    searchToken: t
                })), [y]);
                return r.createElement(r.Fragment, null, "symbolSearch" === p && r.createElement(r.Fragment, null, g.length > 0 && r.createElement(oe, {
                    itemClassName: ye.symbolType,
                    items: g,
                    getItemTitle: e => e.name,
                    getItemKey: e => e.value,
                    checkItemIsActive: e => e.value === f,
                    onBubbleClick: a,
                    multiline: !v
                }, !v && C), v && g.length > 0 && l && r.createElement("div", {
                    className: ye.brokerCheckboxWrap
                }, C)), r.createElement(fe, {
                    listRef: d,
                    listWrapRef: h,
                    onTouchMove: i,
                    items: k,
                    getItemSize: () => we,
                    hideFeed: !w
                }), "loading" === n && r.createElement("div", {
                    className: ye.spinnerWrap
                }, r.createElement(ae.Spinner, null)), "symbolSearch" === p && r.createElement(r.Fragment, null, !1, "empty" === n && r.createElement(x, null)))
            }

            function xe(e) {
                const t = (0, I.useWatchedValueReadonly)({
                    watchedValue: _.watchedTheme
                }) === N.StdTheme.Dark ? D : M;
                return r.createElement(y, {
                    className: ye.noResultsDesktop
                }, !be && r.createElement(p.Icon, {
                    icon: t
                }), r.createElement("div", {
                    className: ye.emptyText
                }, (0, s.t)("No symbols match your criteria")))
            }
            const Ce = (0, B.getDefaultSearchSource)(),
                we = 52;

            function Ee(e) {
                const {
                    mode: t,
                    setMode: n,
                    setSelectedIndex: o,
                    isMobile: i,
                    selectedSearchSource: c,
                    setSelectedSearchSource: d,
                    isAllSearchSourcesSelected: h,
                    selectedSymbolType: p,
                    setSelectedSymbolType: f,
                    setRenderSymbolSearchList: g,
                    searchRef: y,
                    cachedInputValue: b,
                    setSearchSpreads: x,
                    showSpreadActions: C,
                    selectedItem: w,
                    onSearchFeedReady: E,
                    forceUpdate: k,
                    placeholder: I,
                    initialScreen: _,
                    footer: N,
                    searchInput: D,
                    upperCaseEnabled: M,
                    externalInput: T,
                    handleKeyDown: L,
                    customSearchSymbols: A
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext), V = (0, r.useRef)(t);
                V.current = t;
                const q = (0, r.useRef)(new AbortController),
                    [U, Z] = (0, r.useState)(0),
                    [G, j] = (0, r.useState)("noop"),
                    Q = (0, r.useRef)(0),
                    [K, Y] = (0, r.useState)(b.current),
                    X = (0, r.useRef)(null),
                    ee = (0, r.useRef)(null),
                    te = (0, r.useRef)({
                        selectedIndexValue: -1,
                        searchTokenValue: "",
                        searchSpreadsValue: !0
                    }),
                    ne = (0, r.useRef)(null),
                    re = (0, r.useRef)(null),
                    {
                        broker: oe = null,
                        brokerId: ae,
                        brokerTitle: se,
                        isBrokerChecked: ie = !1,
                        setIsBrokerChecked: le = (() => {}),
                        unhideSymbolSearchGroups: ce = ""
                    } = {
                        brokerId: void 0,
                        brokerTitle: void 0
                    };
                (0, r.useEffect)(() => () => {
                    q.current.abort(), Ie()
                }, []), (0, r.useEffect)(() => {
                    (null == y ? void 0 : y.current) && Y(y.current.value)
                }, []), (0, r.useEffect)(() => {
                    const e = y.current;
                    if (e) return e.addEventListener("input", ge), e.addEventListener("focus", Ee), e.addEventListener("select", fe), e.addEventListener("click", fe), e.addEventListener("keyup", ke), T && L && e.addEventListener("keydown", L), () => {
                        e && (e.removeEventListener("input", ge), e.removeEventListener("focus", Ee), e.removeEventListener("select", fe), e.removeEventListener("click", fe), e.removeEventListener("keyup", ke), T && L && e.removeEventListener("keydown", L))
                    }
                }, [L]), (0, r.useEffect)(() => {
                    Boolean(_) && "" === K.trim() || (xe(K, p, c), X.current && (X.current.scrollTop = 0))
                }, [K, p, c, ie, _]), (0, r.useEffect)(() => {
                    if (!w || !y.current) return;
                    if (!u.enabled("show_spread_operators")) return y.current.value = w.symbol, void k();
                    const e = O(w) ? w.exchange : w.parent.exchange,
                        t = {
                            name: w.symbol,
                            exchange: e,
                            prefix: w.prefix,
                            fullName: w.full_name
                        },
                        [n, r] = (0, l.getNextSymbolInputValueAndPosition)(y.current, t, M);
                    y.current.value = n, y.current.setSelectionRange(r, r), k()
                }, [w]);
                const ue = (0, r.useCallback)(e => E ? E(e) : e, [E]),
                    de = null != _ ? _ : "div",
                    he = Boolean(_) && "symbolSearch" !== t,
                    pe = null != D ? D : v.DialogSearch,
                    me = (0, r.useMemo)(() => ({
                        listRef: ee,
                        resetRecommends: we,
                        updateRecommends: xe,
                        searchToken: K,
                        emptyTextClassName: ye.emptyText,
                        isBrokerChecked: ie,
                        symbolSearchState: G,
                        currentMode: V
                    }), [ee, K, ie, G, V]);
                return r.createElement(H.SymbolSearchDialogBodyContext.Provider, {
                    value: me
                }, !(T && "symbolSearch" === t) && r.createElement(pe, {
                    reference: y,
                    className: a()(ye.search, M && ye.upperCase),
                    placeholder: I || (0, s.t)("Search")
                }, C && r.createElement($, {
                    state: te,
                    update: be
                })), he ? r.createElement(de, null) : r.createElement(Se, {
                    token: K,
                    state: G,
                    otherSymbolsCount: U,
                    onListTouchMove: function() {
                        var e;
                        null === (e = y.current) || void 0 === e || e.blur()
                    },
                    onChangeSymbolTypeFilter: function(e) {
                        const {
                            value: t
                        } = e;
                        f(t), o(-1)
                    },
                    onResetFilters: function() {
                        var e;
                        f((0, B.getAllSymbolTypesValue)()), Ce && d(Ce);
                        le(!1), i || null === (e = y.current) || void 0 === e || e.focus()
                    },
                    brokerTitle: se,
                    isBrokerChecked: ie,
                    onBrokerCheckboxChange: function(e) {
                        le("on" !== e)
                    },
                    listRef: ee,
                    listWrapRef: X
                }), N);

                function ve() {
                    if (!y.current) return;
                    const [e, t, n] = (0, l.getCurrentTokenParamsFromInput)(y.current, M);
                    Q.current = t, te.current = {
                        selectedIndexValue: -1,
                        searchSpreadsValue: (0, l.isSpread)(n),
                        searchTokenValue: e
                    }, ne.current || (ne.current = setTimeout(be, 0))
                }

                function fe() {
                    if (!y.current) return;
                    const [, e] = (0, l.getCurrentTokenParamsFromInput)(y.current, M);
                    e !== Q.current && ve()
                }

                function ge() {
                    u.enabled("show_spread_operators") ? ve() : y.current && (te.current = {
                        selectedIndexValue: -1,
                        searchSpreadsValue: !1,
                        searchTokenValue: y.current.value
                    }, ne.current || (ne.current = setTimeout(be, 0)))
                }

                function be() {
                    const {
                        selectedIndexValue: e,
                        searchTokenValue: t,
                        searchSpreadsValue: n
                    } = te.current;
                    ne.current = null, (0, F.unstable_batchedUpdates)(() => {
                        x(n), o(e), Y(M ? t.toUpperCase() : t)
                    })
                }
                async function xe(e, t, n) {
                    try {
                        "noop" === G ? j("loading") : (Ie(), re.current = setTimeout(() => {
                            j("loading")
                        }, 500)), _e();
                        const r = await async function(e, t, n, r) {
                                var o, a, s, i;
                                const d = u.enabled("show_spread_operators") ? (0, l.shortName)(t) : null === (o = y.current) || void 0 === o ? void 0 : o.value;
                                let h;
                                if (ie && oe) {
                                    const t = await (0, R.respectAbort)(e, oe.accountMetainfo());
                                    h = t.prefix
                                }
                                const p = u.enabled("show_spread_operators") ? null !== (s = null !== (a = (0, l.getExchange)(t)) && void 0 !== a ? a : h) && void 0 !== s ? s : null == r ? void 0 : r.getRequestExchangeValue() : null == c ? void 0 : c.getRequestExchangeValue(),
                                    m = (0, l.getExchange)(t) || null === (i = r || c) || void 0 === i ? void 0 : i.getRequestCountryValue(),
                                    v = {
                                        serverHighlight: !1,
                                        text: d,
                                        exchange: p,
                                        country: m,
                                        type: n,
                                        lang: window.language || "",
                                        brokerId: ae,
                                        onlyTradable: Boolean(ae) && ie,
                                        unhideSymbolSearchGroups: ce,
                                        signal: e
                                    },
                                    f = (0, W.getSearchRequestDelay)();
                                void 0 !== f && await (0, R.delay)(e, f);
                                return A ? A(v) : P(v)
                            }(q.current.signal, e, t, n),
                            o = ue(function(e, t = window.ChartApiInstance.symbolsGrouping()) {
                                var n;
                                const r = {},
                                    o = [];
                                for (let a = 0; a < e.length; ++a) {
                                    const s = e[a];
                                    if (s.prefix || Array.isArray(s.contracts)) return e;
                                    const i = t[s.type];
                                    if (void 0 === i) {
                                        o.push(s);
                                        continue
                                    }
                                    const l = i.exec(s.symbol);
                                    if (l) {
                                        const e = l[1];
                                        let t;
                                        r.hasOwnProperty(e) ? t = r[e] : (t = o.length, r[e] = t, o.push({
                                            type: s.type,
                                            symbol: e,
                                            exchange: s.exchange,
                                            description: s.description,
                                            full_name: s.exchange + ":" + e,
                                            contracts: []
                                        })), null === (n = o[t].contracts) || void 0 === n || n.push(s)
                                    } else o.push(s)
                                }
                                return o
                            }(r));
                        if (!o.length) return Ie(), void j("empty");
                        Ie(), g(o), j("good")
                    } catch (e) {
                        (0, R.skipAbortError)(e)
                    }
                }

                function we() {
                    _e(), j("empty"), Y(""), x(!1), Ie()
                }

                function Ee() {
                    "watchlist" === V.current && (n("symbolSearch"), (0, J.trackEvent)("Watchlist", "Mobile SS", "Go to SS page"))
                }

                function ke(e) {
                    switch ((0, z.hashFromEvent)(e)) {
                        case 37:
                        case 39:
                            fe()
                    }
                }

                function Ie() {
                    re.current && clearTimeout(re.current)
                }

                function _e() {
                    q.current.abort(), q.current = new AbortController
                }
            }
            var ke = n(88902),
                Ie = n(98749);

            function _e(e) {
                const {
                    theme: t = Ie
                } = e, {
                    setMode: n,
                    isMobile: o
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext);
                return r.createElement(p.Icon, {
                    className: a()(e.className, t.button, !o && t.desktop),
                    icon: ke,
                    onClick: function() {
                        n("symbolSearch")
                    }
                })
            }
            var Ne = n(12650),
                He = n(42923),
                De = n(70122);

            function Me(e) {
                const [t, n] = (0, r.useState)(() => {
                    const {
                        defaultSearchSource: t,
                        searchSources: n
                    } = e, r = De.getValue("symboledit.exchangefilter", "");
                    return n.find(e => e.value() === r) || t
                });
                return [t, (0, r.useCallback)(e => {
                    var t;
                    n(e), t = e, De.setValue("symboledit.exchangefilter", t.value())
                }, [])]
            }

            function Te(e) {
                const [t, n] = (0, r.useState)(() => {
                    if (1 === e.types.length) return e.types[0].value;
                    const t = De.getValue("symboledit.filter", (0, B.getAllSymbolTypesValue)());
                    return e.types.find(e => e.value === t) ? t : (0, B.getAllSymbolTypesValue)()
                });
                return [t, (0, r.useCallback)(e => {
                    var t;
                    n(e), t = e, De.setValue("symboledit.filter", t)
                }, [])]
            }
            var Le = n(85938),
                Ae = n(26800),
                Fe = n(6215);
            const Re = (0, B.getAvailableSearchSources)(),
                Oe = (0, B.getDefaultSearchSource)(),
                Pe = u.enabled("uppercase_instrument_names");

            function Be(e) {
                var t;
                const {
                    onClose: n,
                    initialMode: o,
                    defaultValue: a = "",
                    showSpreadActions: h,
                    hideMarkedListFlag: p,
                    selectSearchOnInit: v = !0,
                    onSearchComplete: g,
                    onSearchFeedReady: y,
                    dialogTitle: b = (0, s.t)("Symbol Search"),
                    placeholder: S,
                    fullscreen: x,
                    initialScreen: C,
                    wrapper: w,
                    dialog: E,
                    contentItem: k,
                    footer: I,
                    searchInput: _,
                    emptyState: N,
                    autofocus: H,
                    dialogWidth: D,
                    onKeyDown: M,
                    searchSourcesScreen: T,
                    customSearchSymbols: L,
                    isDisableFiltering: F
                } = e, R = (0, r.useMemo)(() => F ? [] : e.symbolTypes ? e.symbolTypes : (0, B.getAvailableSymbolTypes)(), []), W = void 0 !== e.input, J = F ? [] : Re, [V, q] = (0, r.useState)(o), U = (0, r.useRef)(a), [Z, G] = Me({
                    searchSources: J,
                    defaultSearchSource: Oe
                }), [j, Q] = Te({
                    types: R
                }), [K, $] = (0, r.useState)([]), [Y, X] = (0, r.useState)(!1), [ee, te] = (0, r.useState)(-1), ne = (0, r.useRef)(null !== (t = e.input) && void 0 !== t ? t : null), [re, oe] = (0, r.useState)(!1), ae = (0, Le.useForceUpdate)(), [se, ie] = (0, r.useState)(new Set), {
                    broker: le = null,
                    brokerId: ce,
                    unhideSymbolSearchGroups: ue = "",
                    displayBrokerSymbol: de = !1
                } = {
                    brokerId: void 0
                };
                (0, r.useLayoutEffect)(() => {
                    var e;
                    !(null == ne ? void 0 : ne.current) || !W && Boolean(null === (e = ne.current) || void 0 === e ? void 0 : e.value) || (W || "compare" === V || (ne.current.value = U.current), !H || W && "symbolSearch" !== V || ne.current.focus())
                }, [V]), (0, r.useEffect)(() => {
                    (null == ne ? void 0 : ne.current) && v && H && ne.current.select()
                }, []);
                const he = (0, r.useMemo)(() => K.reduce((e, t) => {
                        const n = ze(t),
                            r = se.has(n);
                        return e.push(t), r && t.contracts && e.push(...t.contracts.map(e => ({ ...e,
                            parent: t
                        }))), e
                    }, []), [K, se]),
                    pe = (0, r.useRef)(null);
                (0, r.useEffect)(() => {
                    var e; - 1 !== ee && (null === (e = pe.current) || void 0 === e || e.scrollIntoView({
                        block: "nearest"
                    }))
                }, [ee, pe]);
                const me = (0, r.useMemo)(() => he.map((e, t) => {
                        var n, r, o, a;
                        if (O(e)) {
                            const o = ze(e),
                                a = e.contracts ? se.has(o) : void 0,
                                s = t === ee;
                            return {
                                key: t,
                                id: o,
                                title: Je(e, de),
                                description: e.description,
                                isOffset: !1,
                                onClick: xe.bind(null, e),
                                providerId: e.provider_id,
                                source: e.source,
                                country: null === (n = e.country) || void 0 === n ? void 0 : n.toLocaleLowerCase(),
                                type: e.type,
                                exchangeName: e.exchange,
                                marketType: (0, Ne.marketType)(e.type, e.typespecs),
                                isEod: null === (r = e.params) || void 0 === r ? void 0 : r.includes("eod"),
                                isExpanded: a,
                                onExpandClick: e.contracts ? Ce.bind(null, o) : void 0,
                                fullSymbolName: B.isOpenFirstContractEnabled && e.contracts ? He.QualifiedSources.fromSymbolSearchResult(e, e.contracts[0]) : He.QualifiedSources.fromSymbolSearchResult(e),
                                itemRef: s ? pe : void 0,
                                isSelected: t === ee,
                                hideMarkedListFlag: p,
                                item: e,
                                logoId: e.logoid,
                                currencyLogoId: e["currency-logoid"],
                                baseCurrencyLogoId: e["base-currency-logoid"],
                                shortName: (0, Ae.safeShortName)(He.QualifiedSources.fromSymbolSearchResult(e)),
                                currencyCode: e.currency_code
                            }
                        } {
                            const {
                                parent: n
                            } = e, r = ze(n), s = t === ee;
                            return {
                                key: t,
                                id: r + e.symbol,
                                dangerousTitleHTML: Je(e, de),
                                dangerousDescriptionHTML: `${n.description} (${e.description})`,
                                isOffset: !0,
                                isEod: null === (o = e.params) || void 0 === o ? void 0 : o.includes("eod"),
                                onClick: we.bind(null, e.parent, e),
                                providerId: n.provider_id,
                                country: null === (a = n.country) || void 0 === a ? void 0 : a.toLowerCase(),
                                type: n.type,
                                exchangeName: n.exchange,
                                marketType: (0, Ne.marketType)(n.type, e.typespecs),
                                fullSymbolName: He.QualifiedSources.fromSymbolSearchResult(e.parent, e),
                                itemRef: s ? pe : void 0,
                                isSelected: s,
                                hideMarkedListFlag: p,
                                item: e
                            }
                        }
                    }), [K, se, V, ee, M]),
                    ve = null != E ? E : qe,
                    fe = ve !== qe && !W,
                    ge = (e, t) => ({
                        mode: V,
                        setMode: q,
                        selectedSearchSource: Z,
                        setSelectedSearchSource: G,
                        isAllSearchSourcesSelected: f.isAllSearchSourcesSelected,
                        selectedSymbolType: j,
                        setSelectedSymbolType: Q,
                        selectedIndex: ee,
                        setSelectedIndex: te,
                        onClose: n,
                        setRenderSymbolSearchList: $,
                        searchRef: ne,
                        cachedInputValue: U,
                        searchSpreads: Y,
                        setSearchSpreads: X,
                        handleListWidth: ke,
                        isSmallWidth: re,
                        feedItems: me,
                        isMobile: e,
                        showSpreadActions: h,
                        selectSearchOnInit: v,
                        isTablet: t,
                        selectedItem: he[ee],
                        onSearchFeedReady: y,
                        forceUpdate: ae,
                        placeholder: S,
                        initialScreen: C,
                        toggleExpand: Ce,
                        openedItems: se,
                        onSubmit: Fe,
                        onSearchComplete: g,
                        footer: I,
                        symbolTypes: R,
                        contentItem: k,
                        searchInput: _,
                        emptyState: N,
                        autofocus: H,
                        upperCaseEnabled: Pe,
                        externalInput: W,
                        handleKeyDown: fe ? void 0 : De,
                        customSearchSymbols: L,
                        searchSources: J
                    }),
                    ye = null != T ? T : A,
                    be = "exchange" === V ? {
                        title: (0, s.t)("Sources"),
                        dataName: "exchanges-search",
                        render: () => r.createElement(ye, {
                            searchSources: J
                        }),
                        additionalHeaderElement: r.createElement(_e, null),
                        additionalElementPos: "before"
                    } : {
                        title: b,
                        dataName: "symbol-search-items-dialog",
                        render: () => r.createElement(Ee, null),
                        additionalElementPos: "after"
                    },
                    Se = null != w ? w : "div";
                return r.createElement(Se, null, r.createElement(c.MatchMediaMap, {
                    rules: d.DialogBreakpoints
                }, ({
                    TabletSmall: e,
                    TabletNormal: t
                }) => r.createElement(m.SymbolSearchItemsDialogContext.Provider, {
                    value: ge(e, t)
                }, r.createElement(ve, { ...be,
                    fullScreen: x,
                    onClose: n,
                    onClickOutside: n,
                    onKeyDown: fe ? void 0 : De,
                    isOpened: !0
                }))));

                function xe(e) {
                    if (e.contracts) return B.isOpenFirstContractEnabled && e.contracts.length ? void we(e, e.contracts[0]) : void Ce(ze(e));
                    we(e)
                }

                function Ce(e) {
                    const t = new Set(se);
                    t.has(e) ? t.delete(e) : t.add(e), ie(t)
                }

                function we(e, t) {
                    const r = t || e,
                        {
                            exchange: o
                        } = e;
                    if (u.enabled("show_spread_operators")) {
                        const e = {
                            name: r.symbol,
                            exchange: o,
                            prefix: r.prefix,
                            fullName: r.full_name
                        };
                        if (Y) return Ie(e), void ae();
                        if (ne.current && ne.current.value.includes(",")) return void Ie(e)
                    }
                    const a = [{
                        resolved: !0,
                        symbol: He.QualifiedSources.fromSymbolSearchResult(e, t),
                        result: r
                    }];
                    g(a), n()
                }

                function ke(e) {
                    oe("fixed" === D || e <= 640)
                }

                function Ie(e) {
                    if (!ne.current) return;
                    const [t, n] = (0, l.getNextSymbolInputValueAndPosition)(ne.current, e, Pe);
                    ne.current.value = t, ne.current.setSelectionRange(n, n), ne.current.focus()
                }

                function De(e) {
                    switch ((0, z.hashFromEvent)(e)) {
                        case 38:
                            if (e.preventDefault(), 0 === ee) return;
                            if (-1 === ee) return void te(0);
                            te(ee - 1);
                            break;
                        case 40:
                            if (e.preventDefault(), ee === me.length - 1) return;
                            te(ee + 1);
                            break;
                        case 37:
                            {
                                if (-1 === ee) return;
                                const t = me[ee],
                                    {
                                        id: n,
                                        isOffset: r,
                                        onExpandClick: o
                                    } = t;
                                if (r || !n || !se.has(n) || !Boolean(o) || B.isOpenFirstContractEnabled && Boolean(M) || (e.preventDefault(), Ce(n)), o) return void(null == M || M(e, !0));
                                break
                            }
                        case 39:
                            {
                                if (-1 === ee) return;
                                const t = me[ee],
                                    {
                                        id: n,
                                        isOffset: r,
                                        onExpandClick: o
                                    } = t;
                                if (r || !n || se.has(n) || !Boolean(o) || B.isOpenFirstContractEnabled && Boolean(M) || (e.preventDefault(), Ce(n)), o) return void(null == M || M(e, !0));
                                break
                            }
                        case 13:
                            e.preventDefault(), Fe(!0);
                            break;
                        case 27:
                            e.preventDefault(), n()
                    }
                    null == M || M(e)
                }

                function Fe(e) {
                    if (!ne.current) return;
                    const t = ne.current.value;
                    if (u.enabled("show_spread_operators") && Y && t) {
                        if (t.includes(",")) {
                            const r = Ve(t);
                            if (r.some(e => !Be(e))) return;
                            return g(r.map(We)), void(e && n())
                        }
                        if (!Be(t)) return;
                        return g([{
                            symbol: Pe ? t.toUpperCase() : t,
                            resolved: !1
                        }]), void(e && n())
                    }
                    if (t.includes(",")) return g(Ve(t).map(We)), void(e && n());
                    if (-1 !== ee) {
                        me[ee].onClick()
                    } else {
                        const r = Pe ? t.toUpperCase() : t;
                        if (r && "" !== r.trim()) {
                            const e = Ve(r);
                            if (void 0 !== ce && -1 === r.indexOf(":"))(function(e) {
                                let t = !1;
                                return Promise.all(e.map(e => -1 !== e.indexOf(":") || t ? Promise.resolve({
                                    symbol: e,
                                    resolved: !1
                                }) : (t = !0, async function(e) {
                                    var t;
                                    null === (t = await (null == le ? void 0 : le.accountMetainfo())) || void 0 === t || t.prefix;
                                    const n = await P({
                                        strictMatch: !0,
                                        serverHighlight: !1,
                                        text: e,
                                        lang: window.language || "",
                                        brokerId: ce,
                                        onlyTradable: !0,
                                        unhideSymbolSearchGroups: ue,
                                        exchange: void 0
                                    });
                                    if (0 !== n.length) {
                                        const e = n[0],
                                            {
                                                contracts: t
                                            } = e,
                                            r = t && t.length > 0 ? t[0] : void 0,
                                            o = e.prefix || e.exchange,
                                            a = r ? r.symbol : e.symbol;
                                        if (o && a) return {
                                            symbol: He.QualifiedSources.fromSymbolSearchResult(e, r),
                                            resolved: !0,
                                            result: e
                                        }
                                    }
                                    return {
                                        symbol: e,
                                        resolved: !1
                                    }
                                }(e))))
                            })(e).then(e => g(e));
                            else {
                                const t = e.map(We);
                                g(t)
                            }
                        }
                        e && n()
                    }
                }

                function Be(e) {
                    const t = (0, i.tokenize)(e),
                        n = (0, l.validate)(t);
                    if (n.errors.length || n.warnings.length) return !1;
                    const r = me[ee];
                    return !r || void 0 === r.isExpanded || (r.onClick(), !1)
                }
            }

            function We(e) {
                return {
                    symbol: Pe ? e.toUpperCase() : e,
                    resolved: !1
                }
            }

            function Je(e, t) {
                const {
                    broker_symbol: n,
                    symbol: r
                } = e;
                return `${r}${t&&n?` (${n})`:""}`
            }

            function ze(e) {
                return e.symbol + e.exchange + e.description
            }

            function Ve(e) {
                return e.split(",").map(e => e.trim()).filter(e => "" !== e)
            }

            function qe(e) {
                const {
                    isMobile: t,
                    isTablet: n
                } = (0, S.useEnsuredContext)(m.SymbolSearchItemsDialogContext);
                return r.createElement(h.AdaptivePopupDialog, { ...e,
                    className: a()(Fe.dialog, !t && (n ? Fe.tabletDialog : Fe.desktopDialog)),
                    backdrop: !0,
                    draggable: !1
                })
            }
        },
        32012: (e, t, n) => {
            "use strict";
            n.d(t, {
                validate: () => s,
                flip: () => i,
                stringifyTokens: () => l,
                isSpread: () => u,
                shortName: () => h,
                getExchange: () => p,
                getNextSymbolInputValueAndPosition: () => v,
                getCurrentTokenParamsFromInput: () => f
            });
            var r = n(82527),
                o = n(7002),
                a = n(21167);

            function s(e) {
                const t = {
                    braceBalance: 0,
                    currentState: "var",
                    warnings: [],
                    errors: []
                };
                if (r.enabled("charting_library_base") && !r.enabled("show_spread_operators")) return t;
                let n = "init";
                const o = [];
                for (let r = 0; r < e.length; r++) {
                    const a = e[r];
                    if ("whitespace" !== a.type) {
                        if ("incompleteSymbol" === a.type || "incompleteNumber" === a.type) {
                            const n = r !== e.length - 1,
                                o = {
                                    status: n ? "error" : "incomplete",
                                    reason: "incomplete_token",
                                    offset: a.offset,
                                    token: a
                                };
                            if (n ? t.errors.push(o) : t.warnings.push(o), n) continue
                        }
                        switch (a.type) {
                            case "symbol":
                            case "number":
                                if ("var" === n) {
                                    t.errors.push({
                                        status: "error",
                                        reason: "unexpected_token",
                                        offset: a.offset,
                                        token: a
                                    });
                                    continue
                                }
                                n = "var";
                                break;
                            case "plus":
                            case "minus":
                            case "multiply":
                            case "divide":
                            case "power":
                                if ("var" !== n) {
                                    t.errors.push({
                                        status: "error",
                                        reason: "unexpected_token",
                                        offset: a.offset,
                                        token: a
                                    });
                                    continue
                                }
                                n = "operator";
                                break;
                            case "openBrace":
                                if ("var" === n) {
                                    t.errors.push({
                                        status: "error",
                                        reason: "unexpected_token",
                                        offset: a.offset,
                                        token: a
                                    });
                                    continue
                                }
                                o.push(a), n = "init";
                                break;
                            case "closeBrace":
                                if ("var" !== n) {
                                    t.errors.push({
                                        status: "error",
                                        reason: "unexpected_token",
                                        offset: a.offset,
                                        token: a
                                    });
                                    continue
                                }
                                o.pop() || t.errors.push({
                                    status: "error",
                                    reason: "unbalanced_brace",
                                    offset: a.offset,
                                    token: a
                                }), n = "var";
                                break;
                            case "unparsed":
                                t.errors.push({
                                    status: "error",
                                    reason: "unparsed_entity",
                                    offset: a.offset,
                                    token: a
                                })
                        }
                    }
                }
                for (t.braceBalance = o.length, "var" !== n && t.warnings.push({
                        status: "incomplete",
                        token: e[e.length - 1]
                    }); o.length;) {
                    const e = o.pop();
                    e && t.warnings.push({
                        status: "incomplete",
                        reason: "unbalanced_brace",
                        offset: e.offset,
                        token: e
                    })
                }
                return t.currentState = n, t
            }

            function i(e) {
                const t = function(e) {
                    let t, n = 0,
                        r = 0;
                    for (let o = 0; o < e.length; o++) {
                        const a = e[o];
                        if ("whitespace" !== a.type) switch (n) {
                            case 0:
                                if ("number" !== a.type || 1 != +a.value) return [];
                                n = 1;
                                break;
                            case 1:
                                if (1 !== n || "divide" !== a.type) return [];
                                n = 2, t = o + 1;
                                break;
                            case 2:
                                if ("openBrace" === a.type) n = 3, r = 1;
                                else if (c(a.type)) return [];
                                break;
                            case 3:
                                "openBrace" === a.type ? r++ : "closeBrace" === a.type && (r--, r <= 0 && (n = 2))
                        }
                    }
                    return e.slice(t)
                }(e);
                return t.length ? d(t) : d((0, o.tokenize)("1/(" + l(e) + ")"))
            }

            function l(e) {
                return e.reduce((e, t) => "symbol" === t.type && o.symbolTokenEscapeRe.test(t.value) ? e + `'${t.value}'` : e + t.value, "")
            }

            function c(e) {
                return "plus" === e || "minus" === e || "multiply" === e || "divide" === e || "power" === e
            }

            function u(e) {
                return e.length > 1 && e.some(e => c(e.type))
            }

            function d(e) {
                e = function(e) {
                    const t = [];
                    for (const n of e) "whitespace" !== n.type && t.push(n);
                    return t
                }(e);
                const t = [],
                    n = [];
                let r;
                for (let o = 0; o < e.length; o++) {
                    const a = e[o];
                    switch (a.type) {
                        case "plus":
                        case "minus":
                        case "multiply":
                        case "divide":
                        case "power":
                            n.length && n[n.length - 1].minPrecedence > a.precedence && (n[n.length - 1].minPrecedence = a.precedence);
                            break;
                        case "openBrace":
                            r = {
                                minPrecedence: 1 / 0,
                                openBraceIndex: o
                            }, n.push(r);
                            break;
                        case "closeBrace":
                            {
                                if (r = n.pop(), !r) break;
                                const a = e[r.openBraceIndex - 1],
                                    s = e[o + 1],
                                    i = a && ("plus" === a.type || "multiply" === a.type);
                                (!c(null == s ? void 0 : s.type) || (null == s ? void 0 : s.precedence) <= r.minPrecedence) && (!c(null == a ? void 0 : a.type) || (null == a ? void 0 : a.precedence) < (null == r ? void 0 : r.minPrecedence) || (null == a ? void 0 : a.precedence) === (null == r ? void 0 : r.minPrecedence) && i) && (t.unshift(r.openBraceIndex), t.push(o), n.length && n[n.length - 1].minPrecedence > r.minPrecedence && (n[n.length - 1].minPrecedence = r.minPrecedence))
                            }
                    }
                }
                for (let n = t.length; n--;) e.splice(t[n], 1);
                return e
            }

            function h(e) {
                return d((0, o.tokenize)(e)).reduce((e, t) => {
                    if ("symbol" !== t.type) return e + t.value;
                    const [, n] = m(t);
                    return n ? e + n : e
                }, "")
            }

            function p(e) {
                const t = function(e) {
                    const t = (0, o.tokenize)(e),
                        n = [];
                    return t.forEach(e => {
                        if ("symbol" !== e.type) return;
                        const [t] = m(e);
                        t && n.push(t)
                    }), n
                }(e);
                if (1 === t.length) return t[0]
            }

            function m(e) {
                const t = /^'?(?:([A-Z0-9_]+):)?(.*?)'?$/i.exec(e.value);
                return null === t ? [void 0, void 0] : [t[1], t[2]]
            }

            function v(e, t, n) {
                const r = e.value,
                    [s, i] = f(e, n),
                    l = (0, a.getSymbolFullName)(t),
                    c = o.symbolTokenEscapeRe.test(l) ? `'${l}'` : l;
                return [r.substring(0, i) + c + r.substring(i + s.length), i + c.length]
            }

            function f(e, t) {
                const {
                    value: n,
                    selectionStart: r
                } = e, a = (0, o.tokenize)(t ? n.toUpperCase() : n), s = function(e, t) {
                    for (let n = 0; n < e.length; n++) {
                        const r = e[n],
                            o = "symbol" === r.type || "incompleteSymbol" === r.type || "number" === r.type;
                        if (r.offset <= t && t <= r.offset + r.value.length && o) return r
                    }
                    return null
                }(a, r || 0);
                return [(null == s ? void 0 : s.value) || "", s ? s.offset : n.length, a]
            }
        },
        21167: (e, t, n) => {
            "use strict";
            n.d(t, {
                exchangeSelectDisabled: () => p,
                getAllSymbolTypesValue: () => h,
                getAvailableExchanges: () => c,
                getAvailableSearchSources: () => l,
                getAvailableSymbolTypes: () => d,
                getDefaultSearchSource: () => i,
                getSymbolFullName: () => s,
                isOpenFirstContractEnabled: () => m
            });
            var r = n(25177),
                o = n(84327);
            class a {
                constructor(e) {
                    this._exchange = e
                }
                value() {
                    return this._exchange.value
                }
                name() {
                    return (0, o.isAllSearchSourcesSelected)(this) ? (0, r.t)("All sources") : this._exchange.name
                }
                description() {
                    return this._exchange.desc
                }
                country() {
                    return this._exchange.country
                }
                providerId() {
                    return this._exchange.providerId
                }
                group() {
                    return this._exchange.group
                }
                includes(e) {
                    return function(e, t) {
                        const n = t.toLowerCase(),
                            {
                                name: r,
                                desc: o,
                                searchTerms: a
                            } = e;
                        return r.toLowerCase().includes(n) || o.toLowerCase().includes(n) || void 0 !== a && a.some(e => e.toLowerCase().includes(n))
                    }(this._exchange, e)
                }
                getRequestExchangeValue() {
                    return this._exchange.value
                }
                getRequestCountryValue() {}
            }

            function s(e) {
                if (e.fullName) return e.fullName;
                let t;
                return t = e.prefix || e.exchange ? (e.prefix || e.exchange) + ":" + e.name : e.name, t.replace(/<\/?[^>]+(>|$)/g, "")
            }

            function i() {
                const e = l();
                return e.find(o.isAllSearchSourcesSelected) || e[0] || null
            }

            function l() {
                return (0, o.createSearchSources)(a, u())
            }

            function c() {
                return u()
            }

            function u() {
                return window.ChartApiInstance.supportedExchangesList().map(e => ({ ...e,
                    country: "",
                    providerId: "",
                    flag: ""
                }))
            }

            function d() {
                return window.ChartApiInstance.supportedSymbolsTypes()
            }

            function h() {
                return ""
            }

            function p() {
                return !1
            }
            const m = !1
        },
        63192: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogsOpenerManager: () => r,
                dialogsOpenerManager: () => o
            });
            class r {
                constructor() {
                    this._storage = new Map
                }
                setAsOpened(e, t) {
                    this._storage.set(e, t)
                }
                setAsClosed(e) {
                    this._storage.delete(e)
                }
                isOpened(e) {
                    return this._storage.has(e)
                }
                getDialogPayload(e) {
                    return this._storage.get(e)
                }
            }
            const o = new r
        },
        26800: (e, t, n) => {
            "use strict";
            n.d(t, {
                safeShortName: () => o
            });
            var r = n(10248);

            function o(e) {
                try {
                    return (0, r.shortName)(e)
                } catch (t) {
                    return e
                }
            }
        },
        7002: (e, t, n) => {
            "use strict";
            n.d(t, {
                symbolTokenEscapeRe: () => s,
                tokenize: () => c
            });
            var r = n(82527),
                o = n(73850);
            const a = r.enabled("charting_library_base") ? /(?:[^-+\/*^\s]'|[a-zA-Z0-9_\u0370-\u1FFF_\u2E80-\uFFFF^])(?:[^-+\/*^\s]'|[a-zA-Z0-9_\u0020\u0370-\u1FFF_\u2E80-\uFFFF_!:.&])*|'.+?'/ : /(?:[^-+\/*^\s]'|[a-zA-Z0-9_\u0370-\u1FFF_\u2E80-\uFFFF])(?:[^-+\/*^\s]'|[a-zA-Z0-9_\u0020\u0370-\u1FFF_\u2E80-\uFFFF_!|:.&])*|'.+?'/,
                s = /[+\-/*]/,
                i = {
                    number: /\d+(?:\.\d*|(?![a-zA-Z0-9_!:.&]))|\.\d+/,
                    incompleteNumber: /\./,
                    symbol: a,
                    incompleteSymbol: /'[^']*/,
                    separatorPrefix: o.SEPARATOR_PREFIX,
                    openBrace: "(",
                    closeBrace: ")",
                    plus: "+",
                    minus: "-",
                    multiply: "*",
                    divide: "/",
                    power: "^",
                    whitespace: /[\0-\x20\s]+/,
                    unparsed: null
                },
                l = new RegExp(Object.values(i).map(e => {
                    return null === e ? "" : `(${"string"==typeof e?(t=e,t.replace(/[\^$()[\]{}*+?|\\]/g,"\\$&")):e.source})`;
                    var t
                }).filter(e => "" !== e).concat(".").join("|"), "g");

            function c(e) {
                if (!e) return [];
                const t = [],
                    n = Object.keys(i);
                let r;
                for (; r = l.exec(e);) {
                    let e = !1;
                    for (let o = n.length; o--;)
                        if (r[o + 1]) {
                            n[o] && t.push({
                                value: r[o + 1],
                                type: n[o],
                                precedence: 0,
                                offset: r.index
                            }), e = !0;
                            break
                        }
                    e || t.push({
                        value: r[0],
                        type: "unparsed",
                        precedence: 0,
                        offset: r.index
                    })
                }
                return t
            }
        },
        12991: (e, t, n) => {
            "use strict";
            n.d(t, {
                rankedSearch: () => o,
                createRegExpList: () => a,
                getHighlightedChars: () => s
            });
            var r = n(2683);

            function o(e) {
                const {
                    data: t,
                    rules: n,
                    queryString: o,
                    isPreventedFromFiltering: a,
                    primaryKey: s,
                    secondaryKey: i = s,
                    optionalPrimaryKey: l
                } = e;
                return t.map(e => {
                    const t = l && e[l] ? e[l] : e[s],
                        a = e[i];
                    let c, u = 0;
                    return n.forEach(e => {
                        var n, s, i, l;
                        const {
                            re: d,
                            fullMatch: h
                        } = e;
                        return d.lastIndex = 0, t && t.toLowerCase() === o.toLowerCase() ? (u = 3, void(c = null === (n = t.match(h)) || void 0 === n ? void 0 : n.index)) : (0, r.isString)(t) && h.test(t) ? (u = 2, void(c = null === (s = t.match(h)) || void 0 === s ? void 0 : s.index)) : (0, r.isString)(a) && h.test(a) ? (u = 1, void(c = null === (i = a.match(h)) || void 0 === i ? void 0 : i.index)) : void((0, r.isString)(a) && d.test(a) && (u = 1, c = null === (l = a.match(d)) || void 0 === l ? void 0 : l.index))
                    }), {
                        matchPriority: u,
                        matchIndex: c,
                        item: e
                    }
                }).filter(e => a || e.matchPriority).sort((e, t) => {
                    if (e.matchPriority < t.matchPriority) return 1;
                    if (e.matchPriority > t.matchPriority) return -1;
                    if (e.matchPriority === t.matchPriority) {
                        if (void 0 === e.matchIndex || void 0 === t.matchIndex) return 0;
                        if (e.matchIndex > t.matchIndex) return 1;
                        if (e.matchIndex < t.matchIndex) return -1
                    }
                    return 0
                }).map(({
                    item: e
                }) => e)
            }

            function a(e, t) {
                const n = [],
                    r = e.toLowerCase(),
                    o = e.split("").map((e, t) => `(${0!==t?"[/\\s-]"+i(e):i(e)})`).join("(.*?)") + "(.*)";
                return n.push({
                    fullMatch: new RegExp(`(${i(e)})`, "i"),
                    re: new RegExp("^" + o, "i"),
                    reserveRe: new RegExp(o, "i"),
                    fuzzyHighlight: !0
                }), t && t.hasOwnProperty(r) && n.push({
                    fullMatch: t[r],
                    re: t[r],
                    fuzzyHighlight: !1
                }), n
            }

            function s(e, t, n) {
                const r = [];
                return e && n ? (n.forEach(e => {
                    const {
                        fullMatch: n,
                        re: o,
                        reserveRe: a
                    } = e;
                    n.lastIndex = 0, o.lastIndex = 0;
                    const s = n.exec(t),
                        i = s || o.exec(t) || a && a.exec(t);
                    if (e.fuzzyHighlight = !s, i)
                        if (e.fuzzyHighlight) {
                            let e = i.index;
                            for (let t = 1; t < i.length; t++) {
                                const n = i[t],
                                    o = i[t].length;
                                if (t % 2) {
                                    const t = n.startsWith(" ") || n.startsWith("/") || n.startsWith("-");
                                    r[t ? e + 1 : e] = !0
                                }
                                e += o
                            }
                        } else
                            for (let e = 0; e < i[0].length; e++) r[i.index + e] = !0
                }), r) : r
            }

            function i(e) {
                return e.replace(/[!-/[-^{-}]/g, "\\$&")
            }
        },
        60598: (e, t, n) => {
            "use strict";
            n.d(t, {
                HighlightedText: () => i
            });
            var r = n(59496),
                o = n(97754),
                a = n(12991),
                s = n(22932);

            function i(e) {
                const {
                    queryString: t,
                    rules: n,
                    text: i,
                    className: l
                } = e, c = (0, r.useMemo)(() => (0, a.getHighlightedChars)(t, i, n), [t, n, i]);
                return r.createElement(r.Fragment, null, c.length ? i.split("").map((e, t) => r.createElement(r.Fragment, {
                    key: t
                }, c[t] ? r.createElement("span", {
                    className: o(s.highlighted, l)
                }, e) : r.createElement("span", null, e))) : i)
            }
        },
        40976: (e, t, n) => {
            "use strict";
            n.d(t, {
                useEnsuredContext: () => a
            });
            var r = n(59496),
                o = n(88537);

            function a(e) {
                return (0, o.ensureNotNull)((0, r.useContext)(e))
            }
        },
        85938: (e, t, n) => {
            "use strict";
            n.d(t, {
                useForceUpdate: () => o
            });
            var r = n(59496);
            const o = () => {
                const [, e] = (0, r.useReducer)((e, t) => e + 1, 0);
                return e
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => a
            });
            var r = n(59496),
                o = n(21709);

            function a(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: a,
                    touchStart: s,
                    handler: i,
                    reference: l,
                    ownerDocument: c = document
                } = e, u = (0, r.useRef)(null), d = (0, r.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, r.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: a,
                            touchStart: s
                        },
                        r = l ? l.current : u.current;
                    return (0, o.addOutsideEventListener)(d.current, r, i, c, e)
                }, [t, n, a, s, i]), l || u
            }
        },
        97265: (e, t, n) => {
            "use strict";
            n.d(t, {
                useWatchedValueReadonly: () => o
            });
            var r = n(59496);
            const o = (e, t = !1) => {
                const n = "watchedValue" in e ? e.watchedValue : void 0,
                    o = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                    [a, s] = (0, r.useState)(n ? n.value() : o);
                return (t ? r.useLayoutEffect : r.useEffect)(() => {
                    if (n) {
                        s(n.value());
                        const e = e => s(e);
                        return n.subscribe(e), () => n.unsubscribe(e)
                    }
                    return () => {}
                }, [n]), a
            }
        },
        13739: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMediaMap: () => s
            });
            var r = n(59496),
                o = n(66783),
                a = n.n(o);
            class s extends r.Component {
                constructor(e) {
                    super(e), this._handleMediaChange = () => {
                        const e = l(this.state.queries, (e, t) => t.matches);
                        let t = !1;
                        for (const n in e)
                            if (e.hasOwnProperty(n) && this.state.matches[n] !== e[n]) {
                                t = !0;
                                break
                            }
                        t && this.setState({
                            matches: e
                        })
                    };
                    const {
                        rules: t
                    } = this.props;
                    this.state = i(t)
                }
                shouldComponentUpdate(e, t) {
                    return !a()(e, this.props) || (!a()(t.rules, this.state.rules) || !a()(t.matches, this.state.matches))
                }
                componentDidMount() {
                    this._migrate(null, this.state.queries)
                }
                componentDidUpdate(e, t) {
                    a()(e.rules, this.props.rules) || this._migrate(t.queries, this.state.queries)
                }
                componentWillUnmount() {
                    this._migrate(this.state.queries, null)
                }
                render() {
                    return this.props.children(this.state.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    if (a()(e.rules, t.rules)) return null;
                    const {
                        rules: n
                    } = e;
                    return i(n)
                }
                _migrate(e, t) {
                    null !== e && l(e, (e, t) => {
                        t.removeListener(this._handleMediaChange)
                    }), null !== t && l(t, (e, t) => {
                        t.addListener(this._handleMediaChange)
                    })
                }
            }

            function i(e) {
                const t = l(e, (e, t) => window.matchMedia(t));
                return {
                    queries: t,
                    matches: l(t, (e, t) => t.matches),
                    rules: { ...e
                    }
                }
            }

            function l(e, t) {
                const n = {};
                for (const r in e) e.hasOwnProperty(r) && (n[r] = t(r, e[r]));
                return n
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => o
            });
            var r = n(59496);
            class o extends r.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        94707: (e, t, n) => {
            "use strict";
            n.d(t, {
                Separator: () => s
            });
            var r = n(59496),
                o = n(97754),
                a = n(91626);

            function s(e) {
                return r.createElement("div", {
                    className: o(a.separator, e.className)
                })
            }
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => a,
                getRootOverlapManager: () => i
            });
            var r = n(88537);
            class o {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class a {
                constructor(e = document) {
                    this._storage = new o, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const r = this._document.createElement("div");
                    if (r.style.position = t.position, r.style.zIndex = this._index.toString(), r.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(r);
                        else if (t.index <= 0) this._container.insertBefore(r, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(r, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(r, this._container.firstChild) : this._container.appendChild(r);
                    return this._windows.set(e, r), ++this._index, r
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const s = new WeakMap;

            function i(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, r.ensureDefined)(s.get(t)); {
                    const t = new a(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return s.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => l,
                PortalContext: () => c
            });
            var r = n(59496),
                o = n(87995),
                a = n(16345),
                s = n(63212),
                i = n(53327);
            class l extends r.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, a.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", o.createPortal(r.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, s.getRootOverlapManager)() : this.context
                }
            }
            l.contextType = i.SlotContext;
            const c = r.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => o,
                SlotContext: () => a
            });
            var r = n(59496);
            class o extends r.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return r.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const a = r.createContext(null)
        },
        32455: (e, t, n) => {
            "use strict";
            n.d(t, {
                Spinner: () => s
            });
            var r = n(59496),
                o = n(97754),
                a = n(63654);
            n(24780);

            function s(e) {
                const t = o(e.className, "tv-spinner", "tv-spinner--shown", "tv-spinner--size_" + a.spinnerSizeMap[e.size || a.DEFAULT_SIZE]);
                return r.createElement("div", {
                    className: t,
                    style: e.style,
                    role: "progressbar"
                })
            }
        },
        15783: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetCaret: () => l
            });
            var r = n(59496),
                o = n(97754),
                a = n(72571),
                s = n(40367),
                i = n(21538);

            function l(e) {
                const {
                    dropped: t,
                    className: n
                } = e;
                return r.createElement(a.Icon, {
                    className: o(n, s.icon, {
                        [s.dropped]: t
                    }),
                    icon: i
                })
            }
        },
        88902: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentcolor" stroke-width="1.2" d="M17 21l-7.5-7.5L17 6"/></svg>'
        },
        58311: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M2.5 14.5c1.68-1.26 3.7-2 6.5-2s4.91.74 6.5 2m-13-11c1.68 1.26 3.7 2 6.5 2s4.91-.74 6.5-2"/><circle stroke="currentColor" cx="9" cy="9" r="8.5"/><path stroke="currentColor" d="M13.5 9c0 2.42-.55 4.58-1.4 6.12-.87 1.56-1.98 2.38-3.1 2.38s-2.23-.82-3.1-2.38c-.85-1.54-1.4-3.7-1.4-6.12s.55-4.58 1.4-6.12C6.77 1.32 7.88.5 9 .5s2.23.82 3.1 2.38c.85 1.54 1.4 3.7 1.4 6.12z"/></svg>'
        },
        35487: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        75606: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120"><path fill="#B2B5BE" fill-rule="evenodd" d="M23 39a36 36 0 0 1 72 0v13.15l15.1 8.44 2.16 1.2-1.64 1.86-12.85 14.59 3.73 4.03L98.57 85 95 81.13V117H77v-12H67v9H50V95H40v22H23V81.28l-3.8 3.61-2.76-2.9 4.05-3.84-12.77-14.5-1.64-1.86 2.16-1.2L23 52.34V39Zm72 36.33 10.98-12.46L95 56.73v18.6ZM23 56.92v18.03L12.35 62.87 23 56.92ZM59 7a32 32 0 0 0-32 32v74h9V91h18v19h9v-9h18v12h10V39A32 32 0 0 0 59 7Zm-7 36a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm19 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></svg>'
        },
        505: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120"><path fill="#131722" fill-rule="evenodd" d="M23 39a36 36 0 0 1 72 0v13.15l15.1 8.44 2.16 1.2-1.64 1.86-12.85 14.59 3.73 4.03L98.57 85 95 81.13V117H77v-12H67v9H50V95H40v22H23V81.28l-3.8 3.61-2.76-2.9 4.05-3.84-12.77-14.5-1.64-1.86 2.16-1.2L23 52.34V39Zm72 36.33 10.98-12.46L95 56.73v18.6ZM23 56.92v18.03L12.35 62.87 23 56.92ZM59 7a32 32 0 0 0-32 32v74h9V91h18v19h9v-9h18v12h10V39A32 32 0 0 0 59 7Zm-7 36a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm19 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></svg>'
        },
        80200: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path stroke="currentColor" d="M12.4 12.5a7 7 0 1 0-4.9 2 7 7 0 0 0 4.9-2zm0 0l5.101 5"/></svg>'
        },
        34677: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path stroke="currentColor" d="M8 5l3.5 3.5L8 12"/></svg>'
        },
        91118: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="none" stroke="currentColor" stroke-linecap="square" d="M2.5 6.5h9"/><circle fill="currentColor" cx="7" cy="3" r="1"/><circle fill="currentColor" cx="7" cy="10" r="1"/></svg>'
        },
        15402: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><g fill="none" fill-rule="evenodd" stroke="currentColor"><path stroke-linecap="square" stroke-linejoin="round" d="M3.5 10V2.5L1 5"/><path stroke-linecap="square" d="M1.5 10.5h4"/><path d="M8 12l3-11"/></g></svg>'
        },
        7753: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="none" stroke="currentColor" stroke-linecap="square" d="M2.5 6.5h8"/></svg>'
        },
        51448: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="none" stroke="currentColor" stroke-linecap="square" d="M3 10l7-7M3 3l7 7"/></svg>'
        },
        78989: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="none" stroke="currentColor" stroke-linecap="square" d="M2.5 6.5h8m-4-4v8"/></svg>'
        },
        26502: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13" width="13" height="13"><path fill="none" stroke="currentColor" stroke-linecap="square" d="M3 7l3.5-3.5L10 7"/></svg>'
        }
    }
]);
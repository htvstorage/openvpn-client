(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [7636], {
        59142: function(e, t) {
            var i, s, o;
            s = [t], void 0 === (o = "function" == typeof(i = function(e) {
                "use strict";

                function t(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, i = Array(e.length); t < e.length; t++) i[t] = e[t];
                        return i
                    }
                    return Array.from(e)
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var i = !1;
                if ("undefined" != typeof window) {
                    var s = {
                        get passive() {
                            i = !0
                        }
                    };
                    window.addEventListener("testPassive", null, s), window.removeEventListener("testPassive", null, s)
                }
                var o = "undefined" != typeof window && window.navigator && window.navigator.platform && /iP(ad|hone|od)/.test(window.navigator.platform),
                    r = [],
                    n = !1,
                    a = -1,
                    l = void 0,
                    d = void 0,
                    c = function(e) {
                        return r.some((function(t) {
                            return !(!t.options.allowTouchMove || !t.options.allowTouchMove(e))
                        }))
                    },
                    h = function(e) {
                        var t = e || window.event;
                        return !!c(t.target) || 1 < t.touches.length || (t.preventDefault && t.preventDefault(), !1)
                    },
                    u = function() {
                        setTimeout((function() {
                            void 0 !== d && (document.body.style.paddingRight = d, d = void 0), void 0 !== l && (document.body.style.overflow = l, l = void 0)
                        }))
                    };
                e.disableBodyScroll = function(e, s) {
                    if (o) {
                        if (!e) return void console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.");
                        if (e && !r.some((function(t) {
                                return t.targetElement === e
                            }))) {
                            var u = {
                                targetElement: e,
                                options: s || {}
                            };
                            r = [].concat(t(r), [u]), e.ontouchstart = function(e) {
                                1 === e.targetTouches.length && (a = e.targetTouches[0].clientY)
                            }, e.ontouchmove = function(t) {
                                var i, s, o, r;
                                1 === t.targetTouches.length && (s = e, r = (i = t).targetTouches[0].clientY - a, !c(i.target) && (s && 0 === s.scrollTop && 0 < r || (o = s) && o.scrollHeight - o.scrollTop <= o.clientHeight && r < 0 ? h(i) : i.stopPropagation()))
                            }, n || (document.addEventListener("touchmove", h, i ? {
                                passive: !1
                            } : void 0), n = !0)
                        }
                    } else {
                        _ = s, setTimeout((function() {
                            if (void 0 === d) {
                                var e = !!_ && !0 === _.reserveScrollBarGap,
                                    t = window.innerWidth - document.documentElement.clientWidth;
                                e && 0 < t && (d = document.body.style.paddingRight, document.body.style.paddingRight = t + "px")
                            }
                            void 0 === l && (l = document.body.style.overflow, document.body.style.overflow = "hidden")
                        }));
                        var m = {
                            targetElement: e,
                            options: s || {}
                        };
                        r = [].concat(t(r), [m])
                    }
                    var _
                }, e.clearAllBodyScrollLocks = function() {
                    o ? (r.forEach((function(e) {
                        e.targetElement.ontouchstart = null, e.targetElement.ontouchmove = null
                    })), n && (document.removeEventListener("touchmove", h, i ? {
                        passive: !1
                    } : void 0), n = !1), r = [], a = -1) : (u(), r = [])
                }, e.enableBodyScroll = function(e) {
                    if (o) {
                        if (!e) return void console.error("enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices.");
                        e.ontouchstart = null, e.ontouchmove = null, r = r.filter((function(t) {
                            return t.targetElement !== e
                        })), n && 0 === r.length && (document.removeEventListener("touchmove", h, i ? {
                            passive: !1
                        } : void 0), n = !1)
                    } else 1 === r.length && r[0].targetElement === e ? (u(), r = []) : r = r.filter((function(t) {
                        return t.targetElement !== e
                    }))
                }
            }) ? i.apply(t, s) : i) || (e.exports = o)
        },
        54572: () => {},
        59058: () => {},
        86247: () => {},
        45911: () => {},
        39553: () => {},
        39227: () => {},
        61309: () => {},
        91180: e => {
            e.exports = {
                container: "container-eV1JGUCM"
            }
        },
        27734: e => {
            e.exports = {
                headerWrapper: "headerWrapper-XC8bg61C",
                header: "header-XC8bg61C",
                customField: "customField-XC8bg61C",
                duration: "duration-XC8bg61C",
                arrow: "arrow-XC8bg61C",
                upperCase: "upperCase-XC8bg61C",
                textBlock: "textBlock-XC8bg61C",
                summaryLine: "summaryLine-XC8bg61C"
            }
        },
        42542: e => {
            e.exports = {
                wrapper: "wrapper-EPTOFbcO"
            }
        },
        63858: e => {
            e.exports = {
                wrapper: "wrapper-ujSWJc5Z",
                title: "title-ujSWJc5Z"
            }
        },
        65278: e => {
            e.exports = {
                upperBlock: "upperBlock-MV5k0cdb",
                bottomBlock: "bottomBlock-MV5k0cdb"
            }
        },
        16933: e => {
            e.exports = {
                mainblock: "mainblock-I1BpoUXV"
            }
        },
        58499: e => {
            e.exports = {
                wrapper: "wrapper-DLXhl95v",
                marketBlock: "marketBlock-DLXhl95v",
                tradingActionBlock: "tradingActionBlock-DLXhl95v",
                container: "container-DLXhl95v",
                row: "row-DLXhl95v",
                button: "button-DLXhl95v",
                buttonOrdinary: "buttonOrdinary-DLXhl95v button-DLXhl95v",
                buttonBuy: "buttonBuy-DLXhl95v button-DLXhl95v",
                buttonSell: "buttonSell-DLXhl95v button-DLXhl95v"
            }
        },
        93659: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                wrapper: "wrapper-3UY5VZ5u",
                select: "select-3UY5VZ5u",
                selectMenu: "selectMenu-3UY5VZ5u",
                dateTimePickerWrapper: "dateTimePickerWrapper-3UY5VZ5u",
                dateTimePickerInput: "dateTimePickerInput-3UY5VZ5u",
                focused: "focused-3UY5VZ5u",
                icon: "icon-3UY5VZ5u",
                title: "title-3UY5VZ5u"
            }
        },
        67857: e => {
            e.exports = {
                wrapper: "wrapper-yv5OuExK",
                title: "title-yv5OuExK",
                dateTimeWrapper: "dateTimeWrapper-yv5OuExK",
                mobileDateTimeWrapper: "mobileDateTimeWrapper-yv5OuExK",
                mobilePickerControl: "mobilePickerControl-yv5OuExK",
                mobileDateInputContainer: "mobileDateInputContainer-yv5OuExK",
                mobileDateInput: "mobileDateInput-yv5OuExK",
                mobileDateInputIcon: "mobileDateInputIcon-yv5OuExK",
                timeInput: "timeInput-yv5OuExK",
                buttonWrapper: "buttonWrapper-yv5OuExK",
                button: "button-yv5OuExK"
            }
        },
        82515: e => {
            e.exports = {
                mobile: "screen and (max-width: 567px)"
            }
        },
        1753: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                DomePanel: () => Ee
            });
            var s, o = i(87995),
                r = i(59496),
                n = (i(59058), i(25177)),
                a = i(94489),
                l = i.n(a),
                d = (i(32133), i(47488)),
                c = i(88537),
                h = i(88401),
                u = i(70122),
                m = i(81436),
                _ = i(97280),
                p = i(59255),
                v = i(74617),
                g = i(1397),
                b = i(35687),
                y = i(49984),
                f = i(90687),
                w = i(9696),
                k = i(93605),
                x = i(36376),
                S = i(50681);
            ! function(e) {
                e[e.Inside = 0] = "Inside", e[e.Lower = 1] = "Lower", e[e.Higher = 2] = "Higher"
            }(s || (s = {}));
            var P = i(60521),
                C = i(37538),
                I = i(80185);
            i(39553);
            const D = {
                limitOrder: (0, n.t)("Limit"),
                stopOrder: (0, n.t)("Stop")
            };
            class T {
                constructor(e) {
                    this._pool = [], this._handlers = e || {}, this._ordersPool = new L(this._handlers), this._useCssTransform = "transform" in document.createElement("span").style
                }
                allocate() {
                    return this._pool.pop() || new O(this._ordersPool, this._handlers, this._useCssTransform)
                }
                free(e) {
                    e.destroy(), this._pool.push(e)
                }
            }
            class O {
                constructor(e, t, i) {
                    this._price = 0, this._useCssTransform = i, this._ordersPool = e, this._handlers = t, this._allocatedOrderViews = [];
                    const s = document.createElement("div");
                    s.setAttribute("class", "tv-dome-widget-main__row");
                    const o = document.createElement("span");
                    o.setAttribute("class", "tv-dome-widget-main__value tv-dome-widget-main__value--price");
                    const r = document.createElement("span");
                    r.setAttribute("class", "tv-dome-widget-main__value tv-dome-widget-main__value--sell");
                    const n = document.createElement("span");
                    n.setAttribute("class", "tv-dome-widget-main__value tv-dome-widget-main__value--buy");
                    const a = document.createElement("span");
                    a.setAttribute("class", "tv-dome-widget-main__meter tv-dome-widget-main__meter--sell");
                    const l = document.createElement("span");
                    l.setAttribute("class", "tv-dome-widget-main__meter tv-dome-widget-main__meter--buy");
                    const d = document.createElement("span");
                    d.setAttribute("class", "tv-dome-widget-main__value-readout");
                    const c = document.createElement("span");
                    c.setAttribute("class", "tv-dome-widget-main__value-readout");
                    const h = document.createTextNode(""),
                        u = document.createTextNode(""),
                        m = document.createTextNode("");
                    this._useCssTransform && (a.style.width = l.style.width = "100%", a.style.transform = l.style.transform = "scale(0, 1)");
                    const _ = document.createElement("span");
                    _.setAttribute("class", "tv-dome-widget-main__value tv-dome-widget-main__value--orders-buy");
                    const p = document.createElement("span");
                    p.textContent = D.limitOrder, p.setAttribute("class", "tv-dome-widget-main__label"), _.appendChild(p);
                    const v = document.createElement("span");
                    v.setAttribute("class", "tv-dome-widget-main__value tv-dome-widget-main__value--orders-sell");
                    const g = document.createElement("span");
                    g.textContent = D.limitOrder, g.setAttribute("class", "tv-dome-widget-main__label"), v.appendChild(g), s.appendChild(r), s.appendChild(n), s.appendChild(o), s.appendChild(_), s.appendChild(v), o.appendChild(m), r.appendChild(a), n.appendChild(l), r.appendChild(d), n.appendChild(c), d.appendChild(h), c.appendChild(u), this._priceCell = o, this._priceText = m, this._askText = h, this._bidText = u, this._askMeter = a, this._bidMeter = l, this._ordersBuy = _, this._ordersSell = v, this._orderBuyLabel = p, this._orderSellLabel = g, this._isHigherThanBestBid = !1, this._isLowerThanBestAsk = !1, this._orderType = 1, t && t.bidAskClick && (r.addEventListener("click", e => this._handlerCellClick(-1, e), !1), n.addEventListener("click", e => this._handlerCellClick(1, e), !1)), t && t.bidAskContextMenu && (r.addEventListener("contextmenu", e => {
                        t.bidAskContextMenu.call(null, e, {
                            price: this._price,
                            side: -1
                        })
                    }, !1), n.addEventListener("contextmenu", e => {
                        t.bidAskContextMenu.call(null, e, {
                            price: this._price,
                            side: 1
                        })
                    }, !1)), r.addEventListener("mouseover", e => {
                        g.textContent = (0, I.modifiersFromEvent)(e) === I.Modifiers.Mod ? D.stopOrder : D.limitOrder, g.style.visibility = "visible"
                    }, !1), r.addEventListener("mouseout", () => {
                        g.style.visibility = "hidden"
                    }, !1), n.addEventListener("mouseover", e => {
                        p.textContent = (0, I.modifiersFromEvent)(e) === I.Modifiers.Mod ? D.stopOrder : D.limitOrder, p.style.visibility = "visible"
                    }, !1), n.addEventListener("mouseout", () => {
                        p.style.visibility = "hidden"
                    }, !1), this.element = s
                }
                updatePriceText(e) {
                    this._priceText.nodeValue = e
                }
                updateBidVolume(e) {
                    this._bidText.nodeValue !== e && (this._bidText.nodeValue = e)
                }
                updateAskVolume(e) {
                    this._askText.nodeValue !== e && (this._askText.nodeValue = e)
                }
                updateBidMeter(e) {
                    const t = Math.min(Math.max(e, 0), 1) || 0;
                    this._useCssTransform ? this._bidMeter.style.transform = `scale(${t}, 1)` : this._bidMeter.style.width = 100 * t + "%"
                }
                updateAskMeter(e) {
                    const t = Math.min(Math.max(e, 0), 1) || 0;
                    this._useCssTransform ? this._askMeter.style.transform = `scale(${t}, 1)` : this._askMeter.style.width = 100 * t + "%"
                }
                updatePriceHighlight(e, t) {
                    const i = this._priceCell.classList;
                    if (i) i.toggle("tv-dome-widget-main__value--highlighted", e), i.toggle("tv-dome-widget-main__value--long-position", t > 0), i.toggle("tv-dome-widget-main__value--short-position", t < 0);
                    else {
                        let i = "tv-dome-widget-main__value tv-dome-widget-main__value--price";
                        e && (i += " tv-dome-widget-main__value--highlighted"), t > 0 ? i += " tv-dome-widget-main__value--long-position" : t < 0 && (i += " tv-dome-widget-main__value--short-position"), this._priceCell.setAttribute("class", i)
                    }
                }
                setHigherThanBid(e) {
                    this._isHigherThanBestBid = e, this._updateLabelColor(this._orderBuyLabel, this._isActive(e))
                }
                updateAskLabels(e) {
                    this._isLowerThanBestAsk = e, this._updateLabelColor(this._orderSellLabel, this._isActive(e))
                }
                handlerKey(e) {
                    const t = (0, I.modifiersFromEvent)(e) === I.Modifiers.Mod;
                    this._orderType = t ? 3 : 1, this._orderSellLabel.textContent = t ? D.stopOrder : D.limitOrder, this._orderBuyLabel.textContent = t ? D.stopOrder : D.limitOrder, this._updateLabelColor(this._orderBuyLabel, this._isActive(this._isHigherThanBestBid)), this._updateLabelColor(this._orderSellLabel, this._isActive(this._isLowerThanBestAsk))
                }
                updatePrice(e) {
                    this._price = e
                }
                updateOrders(e) {
                    for (var t; this._allocatedOrderViews.length > e.length;) {
                        const e = this._allocatedOrderViews.pop();
                        e && this._ordersPool.free(e)
                    }
                    for (; this._allocatedOrderViews.length < e.length;) this._allocatedOrderViews.push(this._ordersPool.allocate());
                    const i = {};
                    for (let s = 0; s < e.length; s++) {
                        const o = e[s],
                            r = this._allocatedOrderViews[s],
                            n = Boolean(o.buy),
                            a = n ? 1 : -1;
                        null === (t = i[a]) || void 0 === t || t.collapse(), i[a] = o.noCollapse ? void 0 : r, o.order !== r.order() && (r.updateOrderData(o.order, o.pricePropertyName), r.updateQty(o.qty), r.updateTypeText(o.typeText), n ? this._ordersBuy.prepend(r.element) : this._ordersSell.append(r.element)), r.updateClassName({
                            isBuy: n,
                            type: o.type,
                            inactive: o.inactive,
                            ghost: o.ghost,
                            highlighted: o.highlighted,
                            isModifiable: o.isModifiable,
                            isMovable: o.isMovable,
                            isCancellable: o.isCancellable
                        })
                    }
                }
                destroy() {
                    const e = this._allocatedOrderViews.length;
                    if (e > 0) {
                        for (let t = 0; t < e; t++) this._ordersPool.free(this._allocatedOrderViews[t]);
                        this._allocatedOrderViews.length = 0
                    }
                }
                paintPrice(e) {
                    const t = this.element.classList;
                    t.toggle("tv-dome-widget-main__value--color-ask", "ask" === e), t.toggle("tv-dome-widget-main__value--color-bid", "bid" === e)
                }
                _handlerCellClick(e, t) {
                    const i = (0, I.modifiersFromEvent)(t);
                    if (![I.Modifiers.None, I.Modifiers.Mod].includes(i)) return;
                    const s = 1 === e ? this._bidMeter : this._askMeter,
                        o = 1 === e ? "buy" : "sell";
                    clearTimeout(this._activeStateTimerId), s.classList.add(`tv-dome-widget-main__meter--${o}-active`), this._activeStateTimerId = setTimeout(() => {
                        s.classList.remove(`tv-dome-widget-main__meter--${o}-active`)
                    }, 500), this._handlers.bidAskClick.call(null, t, {
                        price: this._price,
                        side: e,
                        type: i === I.Modifiers.Mod ? 3 : 1
                    })
                }
                _updateLabelColor(e, t) {
                    const i = e.classList;
                    if (i) i.toggle("tv-dome-widget-main__label--active", t);
                    else {
                        let i = "tv-dome-widget-main__label";
                        t && (i += " tv-dome-widget-main__label--active"), e.setAttribute("class", i)
                    }
                }
                _isActive(e) {
                    const t = 3 === this._orderType;
                    return t && !e || !t && e
                }
            }
            class L {
                constructor(e) {
                    this._pool = [], this._handlers = e
                }
                allocate() {
                    return this._pool.pop() || new B(this._handlers)
                }
                free(e) {
                    e.destroy(), this._pool.push(e)
                }
            }
            class B {
                constructor(e) {
                    this._order = null, this._pricePropertyName = null;
                    const t = document.createElement("div");
                    t.setAttribute("class", "tv-dome-widget-main__order tv-dome-widget-order");
                    const s = document.createElement("div");
                    s.innerHTML = i(59094), s.setAttribute("class", "tv-dome-widget-order__close");
                    const o = document.createElement("span");
                    o.setAttribute("class", "tv-dome-widget-order__qty");
                    const r = document.createTextNode(""),
                        n = document.createElement("span");
                    n.setAttribute("class", "tv-dome-widget-order__type");
                    const a = document.createTextNode("");
                    t.appendChild(s), t.appendChild(o), o.appendChild(r), t.appendChild(n), n.appendChild(a), e && e.closeButtonClick && s.addEventListener("click", t => {
                        e.closeButtonClick.call(null, t, this._order)
                    }, !1), e && e.qtyClick && o.addEventListener("click", t => {
                        e.qtyClick.call(null, t, this._order)
                    }, !1), e && e.orderMousedown && o.addEventListener("mousedown", t => {
                        null !== this._order && null !== this._pricePropertyName && e.orderMousedown.call(null, t, {
                            order: this._order,
                            pricePropertyName: this._pricePropertyName
                        })
                    }, !1), this.element = t, this._qtyText = r, this._typeText = a
                }
                order() {
                    return this._order
                }
                updateQty(e) {
                    this._qtyText.nodeValue = e || ""
                }
                updateTypeText(e) {
                    this._typeText.nodeValue = e || ""
                }
                updateClassName(e) {
                    const {
                        isBuy: t,
                        type: i,
                        inactive: s,
                        ghost: o,
                        highlighted: r,
                        isModifiable: n,
                        isMovable: a,
                        isCancellable: l
                    } = e, d = this.element;
                    d.className = "tv-dome-widget-main__order tv-dome-widget-order", d.classList.toggle("tv-dome-widget-order--buy", !!t), d.classList.toggle("tv-dome-widget-order--type-" + i, !!i), d.classList.toggle("tv-dome-widget-order--inactive", !!s), d.classList.toggle("tv-dome-widget-order--ghost", !!o), d.classList.toggle("tv-dome-widget-order--highlighted", !!r), d.classList.toggle("tv-dome-widget-order--unmodified", !1 === n), d.classList.toggle("tv-dome-widget-order--immovable", !1 === a), d.classList.toggle("tv-dome-widget-order--notcanceled", !1 === l)
                }
                collapse() {
                    this.element.classList.add("tv-dome-widget-main__order--collapsed")
                }
                updateOrderData(e, t) {
                    this._order = e, this._pricePropertyName = t
                }
                destroy() {
                    this.element.parentNode && this.element.parentNode.removeChild(this.element), this._order = null
                }
            }
            var N = i(8329),
                M = i(42894);
            class V {
                constructor(e, t, i) {
                    this._container = null, this._listContainer = null, this._dragShield = null, this._viewsList = [], this._bids = {}, this._asks = {}, this._indexes = [], this._sortableVisibleIndexes = [], this._bestAskIndex = 1 / 0, this._bestBidIndex = -1 / 0, this._repaintScheduled = !1, this._worstBidIndex = 1 / 0, this._worstAskIndex = -1 / 0, this._currentVolumeMax = 0, this._orders = {}, this._positionIndex = NaN, this._positionQty = 0, this._orderGhost = null, this._totalVolumeBid = 0, this._totalVolumeAsk = 0, this._buyOrdersValue = 0, this._sellOrdersValue = 0, this._buyOrdersValueInactive = 0, this._sellOrdersValueInactive = 0, this._buyOrdersQuantity = 0, this._sellOrdersQuantity = 0, this._offscreenIndexLocation$ = new C.Subject, this._handlers = e || {}, this._realtimeProvider = i,
                        this._showPricesWith = t, this.autoCenterRequired = new(l())(!1), this.height = 0, this.topIndex = NaN, this._symbolData = null, this._lastPriceIndex = NaN, this._viewAllocated = new Map, this._viewPool = null, this._invalidatedAsk = {}, this._invalidatedBid = {}, this._invalidatedPriceHighlight = {}, this._invalidatedOrders = {}, this._dynamicModeState = !1, this._numericFormatter = new N.NumericFormatter, this._showPricesWith.zeroVolume.subscribe(this.centerOnLast.bind(this)), this._showPricesWith.spread.subscribe(this.centerOnLast.bind(this)), this.reset()
                }
                reset() {
                    this.topIndex = NaN, this._symbolData = null, this._lastPriceIndex = NaN, this.resetData(), this.resetView(), this.resetOrders(), this.resetOrderGhost(), this.resetPosition(), this.autoCenterRequired.setValue(!1)
                }
                resetData() {
                    if (this._bids = {}, this._asks = {}, this._totalVolumeBid = 0, this._totalVolumeAsk = 0, this._recalcMaxVolume(), this._recalcBestWorstBid(), this._recalcBestWorstAsk(), this._viewAllocated)
                        for (const [e] of this._viewAllocated) this._invalidatedAsk[e] = !0, this._invalidatedBid[e] = !0;
                    this._offscreenIndexLocation$.next(s.Inside), this.scheduleRepaint()
                }
                resetOrders() {
                    if (this._orders)
                        for (const e in this._orders) this._orders.hasOwnProperty(e) && (this._invalidatedOrders[e] = !0);
                    this._orders = {}, this._buyOrdersValue = 0, this._sellOrdersValue = 0, this._buyOrdersValueInactive = 0, this._sellOrdersValueInactive = 0, this._buyOrdersQuantity = 0, this._sellOrdersQuantity = 0, this.scheduleRepaint()
                }
                resetPosition() {
                    this._invalidatedPriceHighlight[this._positionIndex] = !0, this._positionIndex = NaN, this._positionQty = 0, this.scheduleRepaint()
                }
                resetView() {
                    if (this._viewAllocated && this._viewPool)
                        for (const [e] of this._viewAllocated) {
                            const t = this._viewAllocated.get(e);
                            t && (t.element.remove(), this._viewPool.free(t), this._viewAllocated.delete(e))
                        }
                    this._listContainer && (this._viewsList.length = 0, this._listContainer.innerHTML = ""), this.setDragShield(!1, !1), this.scheduleRepaint()
                }
                setSymbolInfo(e) {
                    this._symbolData = { ...e
                    }
                }
                setContainer(e) {
                    if (this._container === e) return;
                    this._container && (this.resetView(), this._container.innerHTML = ""), this._container = e, this._viewPool = new T(this._handlers), this._viewAllocated = new Map;
                    const t = this._listContainer = document.createElement("div");
                    t.className = "tv-dome-widget-main__anchor", e.append(t);
                    const i = this._dragShield = document.createElement("div");
                    i.className = "tv-dome-widget-main__drag-shield js-hidden", e.append(i), this._repaintScheduled = !1, this.scheduleRepaint()
                }
                setHeight(e) {
                    e !== this.height && (this.height = e, this.checkAutoCenter(), this.scheduleRepaint())
                }
                shiftTopIndexRelativeToIndex(e, t) {
                    this._setTopIndex(e + t)
                }
                handlerKey(e) {
                    let t = this.topIndex;
                    this._canIndexBeDisplayed(t) || (t = this.correctIndex(t, -1));
                    const i = this.correctIndex(t, 1 - this.height);
                    if (!isFinite(i)) return;
                    const s = this._viewAllocated;
                    for (const [, t] of s) t && t.handlerKey(e)
                }
                correctIndex(e, t = 0) {
                    const i = e + t,
                        s = this._bestBidIndex >= this._bestAskIndex,
                        o = this._showPricesWith.zeroVolume.value(),
                        r = s || this._showPricesWith.spread.value();
                    if (o && r) return i;
                    if (i > this._worstAskIndex) return i;
                    if (!this._hasQuotes()) return i;
                    const n = this._fiendVisibleIndex(this._bestAskIndex),
                        a = this._fiendVisibleIndex(this._bestBidIndex),
                        l = this._bestAskIndex - this._bestBidIndex - 1,
                        d = a - n - 1,
                        c = r ? l : 0;
                    if (!o) {
                        const e = this._worstAskIndex - i,
                            t = this._fiendVisibleIndex(this._worstBidIndex),
                            s = r ? l : d;
                        if (e <= n) return Number(this._sortableVisibleIndexes[e]);
                        if (e <= n + s) return r ? this._bestAskIndex - e + n : Number(this._sortableVisibleIndexes[e]);
                        const o = r ? d : 0;
                        if (e <= t + c - o) return Number(this._sortableVisibleIndexes[e - c + o]);
                        const h = n + s + t - a + 1;
                        return i - this._worstAskIndex + this._worstBidIndex + h - o
                    }
                    if (!r && i < this._bestAskIndex) {
                        const e = this._bestAskIndex - i,
                            t = this._sortableVisibleIndexes.slice(n + 1, a);
                        return e <= t.length ? Number(t[e - 1]) : i + t.length - l
                    }
                    return i
                }
                centerOnLast() {
                    this.autoCenterRequired.setValue(!1);
                    const e = this._autoCenterTargetTopIndex();
                    isFinite(e) && this._setTopIndex(e)
                }
                guessOrderType(e, t) {
                    const i = this.priceToIndex(e);
                    if (!isFinite(e)) return null;
                    if (1 !== t && -1 !== t) return null;
                    let s = this._bestAskIndex,
                        o = this._bestBidIndex;
                    return isFinite(s) || (s = o + 1), isFinite(o) || (o = s - 1), isFinite(s) || isFinite(o) || (s = o = this._lastPriceIndex), 1 === t ? i && i < s ? 1 : 3 : i && i > o ? 1 : 3
                }
                indexToPrice(e) {
                    return null === this._symbolData ? NaN : (0, P.Big)(e).mul(this._symbolData.minTick).toNumber()
                }
                priceToIndex(e) {
                    return this._symbolData ? Math.round(e / this._symbolData.minTick) : NaN
                }
                updateData(e) {
                    this._indexes.forEach(e => {
                        isFinite(this._asks[e]) || delete this._asks[e], isFinite(this._bids[e]) || delete this._bids[e]
                    });
                    let t = !1;
                    if (e.snapshot) {
                        const e = 0 === Object.keys(this._asks).length && 0 === Object.keys(this._bids).length;
                        t = !this._showPricesWith.zeroVolume.value() && !this._showPricesWith.spread.value() && e, this.resetData()
                    }
                    let i = !1;
                    if (e.bids)
                        for (let t = 0; t < e.bids.length; t++) {
                            const s = (0, c.ensureDefined)(e.bids[t]),
                                o = this.priceToIndex(s.price),
                                r = s.volume,
                                n = this._bids[o] || null;
                            n !== r && (i = !0, r > 0 ? (this._totalVolumeBid += r - Number(n), this._bids[o] = r) : (this._totalVolumeBid -= Number(n), delete this._bids[o]), this._invalidatedBid[o] = !0)
                        }
                    if (e.asks)
                        for (let t = 0; t < e.asks.length; t++) {
                            const s = (0, c.ensureDefined)(e.asks[t]),
                                o = this.priceToIndex(s.price),
                                r = s.volume,
                                n = this._asks[o] || null;
                            n !== r && (i = !0, r > 0 ? (this._totalVolumeAsk += r - Number(n), this._asks[o] = r) : (this._totalVolumeAsk -= Number(n), delete this._asks[o]), this._invalidatedAsk[o] = !0)
                        }
                    if (this._collectIndexes(), !this._hasDataInDom()) {
                        if (i = !0, 0 !== e.bids.length) {
                            const t = this.priceToIndex(e.bids[0].price);
                            this._bids[t] = 1 / 0
                        }
                        if (0 !== e.asks.length) {
                            const t = this.priceToIndex(e.asks[0].price);
                            this._asks[t] = 1 / 0
                        }
                        this._collectIndexes()
                    }
                    this._recalcBestWorstBid(), this._recalcBestWorstAsk(), i && this._recalcSortVisibleIndexes(), this._recalcMaxVolume(), t ? this.centerOnLast() : this.checkAutoCenter(), this._dynamicModeState && this.centerOnLast(), this.scheduleRepaint()
                }
                totalVolumeBid() {
                    return this._totalVolumeBid
                }
                totalVolumeAsk() {
                    return this._totalVolumeAsk
                }
                buyOrdersValue() {
                    return this._buyOrdersValue
                }
                sellOrdersValue() {
                    return this._sellOrdersValue
                }
                buyInactiveOrdersValue() {
                    return this._buyOrdersValueInactive
                }
                sellInactiveOrdersValue() {
                    return this._sellOrdersValueInactive
                }
                buyOrdersQuantity() {
                    return this._numericFormatter.format(this._buyOrdersQuantity)
                }
                sellOrdersQuantity() {
                    return this._numericFormatter.format(this._sellOrdersQuantity)
                }
                updateOrders(e) {
                    this.resetOrders();
                    for (let t = 0; t < e.length; t++) {
                        const i = e[t],
                            s = 6 === i.status;
                        if (1 === i.side ? (this._buyOrdersValue += Number(s), this._buyOrdersValueInactive += Number(!s), this._buyOrdersQuantity += s ? i.qty : 0) : (this._sellOrdersValue += Number(s), this._sellOrdersValueInactive += Number(!s), this._sellOrdersQuantity += s ? i.qty : 0), i.stopPrice) {
                            const e = this.priceToIndex(i.stopPrice);
                            this._orders[e] || (this._orders[e] = []), this._orders[e].push({
                                order: i,
                                pricePropertyName: "stopPrice"
                            }), this._invalidatedOrders[e] = !0
                        }
                        if (void 0 !== i.limitPrice) {
                            const e = this.priceToIndex(i.limitPrice);
                            this._orders[e] || (this._orders[e] = []), this._orders[e].push({
                                order: i,
                                pricePropertyName: "limitPrice"
                            }), this._invalidatedOrders[e] = !0
                        }
                    }
                    this._recalcSortVisibleIndexes(), this.scheduleRepaint()
                }
                updateLast(e) {
                    const t = this.priceToIndex(e);
                    t !== this._lastPriceIndex && (this._invalidatedPriceHighlight[this._lastPriceIndex] = !0, this._invalidatedPriceHighlight[t] = !0, this._lastPriceIndex = t, this.checkAutoCenter(), this.scheduleRepaint())
                }
                updatePosition(e) {
                    if (!e || !e.qty) return void this.resetPosition();
                    const t = this.priceToIndex(e.avgPrice),
                        i = Math.abs(e.qty) * (1 === e.side ? 1 : -1);
                    this._positionIndex === t && this._positionQty === i || (this._invalidatedPriceHighlight[this._positionIndex] = !0, this._invalidatedPriceHighlight[t] = !0, this._positionIndex = t, this._positionQty = i, this.scheduleRepaint())
                }
                resetOrderGhost() {
                    this._orderGhost && (this._invalidatedOrders[this._orderGhost.index] = !0, this._invalidatedOrders[this._orderGhost.originIndex] = !0, this._orderGhost = null, this.scheduleRepaint())
                }
                setOrderGhost(e) {
                    const {
                        order: t,
                        pricePropertyName: i,
                        price: s
                    } = e;
                    this.resetOrderGhost();
                    const o = this.priceToIndex(s);
                    isFinite(o) && (this._orderGhost = {
                        ghost: !0,
                        order: t,
                        pricePropertyName: i,
                        price: s,
                        index: o,
                        originIndex: this.priceToIndex(t[i])
                    }, this._invalidatedOrders[o] = !0, this.scheduleRepaint())
                }
                setDragShield(e, t) {
                    this._dragShield && (this._dragShield.classList.toggle("js-hidden", !e), this._dragShield.classList.toggle("tv-dome-widget-main__drag-shield--order", t))
                }
                scheduleRepaint() {
                    this._repaintScheduled || this._symbolData && (requestAnimationFrame(() => this.repaint()), this._repaintScheduled = !0)
                }
                formatVolume(e) {
                    return null === this._symbolData ? String(e) : this._symbolData.volumeFormatter.format(e)
                }
                repaint() {
                    if (this._repaintScheduled = !1, !this._listContainer) return;
                    if (null === this._viewPool) return;
                    const e = this.topIndex,
                        t = this.correctIndex(e, 1 - this.height);
                    if (isFinite(t)) {
                        for (; this._viewsList.length < this.height;) {
                            const e = this._viewPool.allocate();
                            this._listContainer.append(e.element), this._viewsList.push(e)
                        }
                        for (; this._viewsList.length > this.height;) {
                            const e = (0, c.ensureDefined)(this._viewsList.pop());
                            e.element.remove(), this._viewPool.free(e)
                        }
                        this._oldViewAllocated = this._viewAllocated, this._viewAllocated = new Map;
                        for (let t = 0; t < this._viewsList.length; t++) {
                            const i = this.correctIndex(e, -t),
                                s = this._viewsList[t];
                            this._viewAllocated.set(i, s), this._updateRow(i)
                        }
                        this._updateOffscreenIndexLocation(this._lastPriceIndex, e, t);
                        for (const e in this._invalidatedBid) this._invalidatedBid.hasOwnProperty(e) && delete this._invalidatedBid[e];
                        for (const e in this._invalidatedAsk) this._invalidatedAsk.hasOwnProperty(e) && delete this._invalidatedAsk[e];
                        for (const e in this._invalidatedPriceHighlight) this._invalidatedPriceHighlight.hasOwnProperty(e) && delete this._invalidatedPriceHighlight[e];
                        for (const e in this._invalidatedOrders) this._invalidatedOrders.hasOwnProperty(e) && delete this._invalidatedOrders[e]
                    }
                }
                typePrice(e) {
                    return e >= this._bestAskIndex ? "ask" : e <= this._bestBidIndex ? "bid" : void 0
                }
                toggleDynamicModeState() {
                    return this._dynamicModeState = !this._dynamicModeState, this._dynamicModeState
                }
                getDynamicModeState() {
                    return this._dynamicModeState
                }
                checkAutoCenter() {
                    isFinite(this.topIndex) || this.centerOnLast();
                    const e = this.topIndex,
                        t = this.correctIndex(this.topIndex, 1 - this.height);
                    let i;
                    i = isFinite(this._bestBidIndex) ? this._bestBidIndex : isFinite(this._bestAskIndex) ? this._bestAskIndex : isFinite(this._lastPriceIndex) ? this._lastPriceIndex : NaN;
                    let s = NaN;
                    isFinite(this._bestAskIndex) ? s = this._bestAskIndex : isFinite(this._bestBidIndex) ? s = this._bestBidIndex : isFinite(this._lastPriceIndex) && (i = this._lastPriceIndex);
                    let o = !1;
                    (s + 3 > e || i - 3 < t) && this.topIndex !== this._autoCenterTargetTopIndex() && (o = !0), this.autoCenterRequired.setValue(o)
                }
                isSpread(e) {
                    return this._bestAskIndex > e && e > this._bestBidIndex
                }
                getOffscreenIndexLocationObservable() {
                    return this._offscreenIndexLocation$.asObservable()
                }
                _hasDataInDom() {
                    return 0 !== this._indexes.length
                }
                _updateOffscreenIndexLocation(e, t, i) {
                    isFinite(this._lastPriceIndex) && (e > t ? this._offscreenIndexLocation$.next(s.Higher) : e < i ? this._offscreenIndexLocation$.next(s.Lower) : this._offscreenIndexLocation$.next(s.Inside))
                }
                _hasQuotes() {
                    return this._indexes.length > 1
                }
                _collectIndexes() {
                    this._indexes = Object.keys(Object.assign({}, this._asks, this._bids))
                }
                _fiendVisibleIndex(e) {
                    return (0, M.lowerbound)(this._sortableVisibleIndexes, e, (e, t) => e > t, 0, this._sortableVisibleIndexes.length)
                }
                _recalcSortVisibleIndexes() {
                    this._sortableVisibleIndexes = [...Object.keys(this._asks), ...Object.keys(this._bids)].map(Number);
                    const e = [...Object.keys(this._orders)].map(Number);
                    for (const t of e) t <= this._worstAskIndex && t >= this._worstBidIndex && !this._sortableVisibleIndexes.includes(t) && this._sortableVisibleIndexes.push(t);
                    this._sortableVisibleIndexes.sort((e, t) => t - e).filter((e, t, i) => e !== i[t - 1])
                }
                _updateRow(e) {
                    var t;
                    if (!this._symbolData) return;
                    const i = this._oldViewAllocated,
                        s = this._viewAllocated;
                    let o = s.get(e);
                    this._viewPool && !o && (o = this._viewPool.allocate(), s.set(e, o));
                    const r = this._orderGhost;
                    if (i && i.get(e) !== s.get(e)) {
                        const t = this.indexToPrice(e);
                        o.updatePrice(t), o.updatePriceText(this._symbolData.priceFormatter.format(t))
                    }
                    o.paintPrice(this.typePrice(e)), this._asks[e] && this._asks[e] !== 1 / 0 ? o.updateAskVolume(this.formatVolume(this._asks[e])) : o.updateAskVolume(""), o.updateAskLabels(e < this._bestAskIndex), this._bids[e] && this._bids[e] !== 1 / 0 ? o.updateBidVolume(this.formatVolume(this._bids[e])) : o.updateBidVolume(""),
                        o.setHigherThanBid(e > this._bestBidIndex), o.updateAskMeter(this._asks[e] === 1 / 0 ? 100 : this._asks[e] / this._currentVolumeMax || 0), o.updateBidMeter(this._bids[e] === 1 / 0 ? 100 : this._bids[e] / this._currentVolumeMax || 0);
                    const a = e === this._lastPriceIndex,
                        l = e === this._positionIndex ? this._positionQty : 0;
                    o.updatePriceHighlight(a, l);
                    let d, c, h = this._orders[e] || [];
                    null !== r && (r.index === e && (r.originIndex !== e ? h = h.concat(r) : c = r.order.id), r.index !== e && r.originIndex !== e || (d = r.order.side));
                    const u = null === (t = this._realtimeProvider.activeBroker()) || void 0 === t ? void 0 : t.metainfo().configFlags;
                    for (let e = 0; e < h.length; e++) {
                        const t = h[e],
                            i = t.order,
                            s = i.filledQty || 0;
                        switch (t.inactive = 6 !== i.status || 4 === i.type && "limitPrice" === t.pricePropertyName, t.isModifiable = void 0 !== u && (0, S.isModifyOrderSupported)(i, u), t.isMovable = void 0 !== u && (0, S.isMoveOrderSupported)(i, u), t.isCancellable = !0, i.type) {
                            case 2:
                                t.typeText = (0, n.t)("Market"), t.type = "market";
                                break;
                            case 1:
                                t.typeText = i.parentId ? (0, n.t)("TakeProfit") : (0, n.t)("Limit"), t.type = "limit";
                                break;
                            case 3:
                                t.typeText = i.parentId ? (0, n.t)("StopLoss") : (0, n.t)("Stop", {
                                    context: "order"
                                }), t.type = "stop";
                                break;
                            case 4:
                                t.typeText = (0, n.t)("StopLimit"), t.type = "stoplimit";
                                break;
                            default:
                                t.typeText = ""
                        }
                        t.qty = this._symbolData.quantityFormatter.format(i.qty - s), t.buy = 1 === i.side, t.noCollapse = i.side === d, t.highlighted = null !== r && void 0 !== c && i.id === c && r.pricePropertyName === t.pricePropertyName
                    }
                    o.updateOrders(h)
                }
                _setTopIndex(e) {
                    e !== this.topIndex && (this.topIndex = e, this.checkAutoCenter()), this.scheduleRepaint()
                }
                _canIndexBeDisplayed(e) {
                    const t = this._showPricesWith.zeroVolume.value(),
                        i = this._showPricesWith.spread.value();
                    if (t && !this.isSpread(e)) return !0;
                    if (i && this.isSpread(e)) return !0;
                    const s = e === this._lastPriceIndex,
                        o = e === this._positionIndex,
                        r = this._bids.hasOwnProperty(e) || this._asks.hasOwnProperty(e),
                        n = e <= this._worstBidIndex || this._worstAskIndex <= e,
                        a = this._orders[e] || [],
                        l = this._orderGhost && this._orderGhost.index === e;
                    return o || s || l || n || r || 0 !== a.length
                }
                _getGapMiddleIndex() {
                    let e = this._bestAskIndex,
                        t = this._bestBidIndex;
                    return isFinite(e) || (e = t), isFinite(t) || (t = e), Math.floor((t + e) / 2)
                }
                _autoCenterTargetTopIndex() {
                    const e = Math.floor(this.height / 2);
                    return this._showPricesWith.zeroVolume.value() && this._showPricesWith.spread.value() ? this.correctIndex(Math.floor(this._getCenterIndex()), e) : this._getCorrectCenterIndex() + e
                }
                _getCorrectCenterIndex() {
                    const e = this._getCenterIndex();
                    let t = e;
                    return this._showPricesWith.zeroVolume.value() || (t = e + this._worstAskIndex - this._bestAskIndex - 1 - this._fiendVisibleIndex(this._bestAskIndex) + 1), this._showPricesWith.spread.value() || (t += this._bestAskIndex - e), t
                }
                _getCenterIndex() {
                    const e = this._getGapMiddleIndex();
                    return isFinite(e) ? e : isFinite(this._bestBidIndex) ? this._bestBidIndex : isFinite(this._bestAskIndex) ? this._bestAskIndex : isFinite(this._lastPriceIndex) ? this._lastPriceIndex : NaN
                }
                _recalcMaxVolume() {
                    let e = 0;
                    for (const t in this._asks) this._asks.hasOwnProperty(t) && (e = Math.max(this._asks[t], e));
                    for (const t in this._bids) this._bids.hasOwnProperty(t) && (e = Math.max(this._bids[t], e));
                    e !== this._currentVolumeMax && (this._currentVolumeMax = e)
                }
                _recalcBestWorstBid() {
                    let e = -1 / 0,
                        t = 1 / 0;
                    for (const i in this._bids) this._bids.hasOwnProperty(i) && (+i > e && (e = +i), +i < t && (t = +i));
                    this._bestBidIndex = e, this._worstBidIndex = t
                }
                _recalcBestWorstAsk() {
                    let e = 1 / 0,
                        t = -1 / 0;
                    for (const i in this._asks) this._asks.hasOwnProperty(i) && (+i < e && (e = +i), +i > t && (t = +i));
                    this._bestAskIndex = e, this._worstAskIndex = t
                }
            }
            i(54572), i(61309);
            class E {
                constructor(e) {
                    this._nodes = null, this._symbolData = null, this._positionInvalidated = !0, this._plInvalidated = !0, this._repaintScheduled = !1, this._calculatePLUsingLast = !1, this._plDirectionCache = 0, this._plTextCache = "", this._hasLotSize = new(l())(!1), this._handlers = e || {}, this._numericFormatter = new N.NumericFormatter, this._uiState = {
                        plViewType: u.getJSON(v.settingsKeys.PROFIT_VIEW_TYPE, 0)
                    }, this.reset(), this._integerFormatter = new N.NumericFormatter(0), this._oneDecimalFormatter = new N.NumericFormatter(1), this.qty = new(l())(1), this.qty.subscribe(e => this._handlers.qtyChange.call(null, e)), this._qtyProperties = new(l())({
                        min: 1,
                        step: 1,
                        max: 1,
                        format: null
                    })
                }
                reset() {
                    this._position = void 0, this._pl = void 0, this._lastPrice = void 0, this._bid = void 0, this._ask = void 0, this._symbolData = null, this._positionInvalidated = !0, this._plInvalidated = !0, this.scheduleRepaint()
                }
                setBrokerConfigFlags(e) {
                    this._calculatePLUsingLast = e.calculatePLUsingLast
                }
                setSymbolInfo(e) {
                    const {
                        qtyProperties: t
                    } = e;
                    this._symbolData = e, this._qtyProperties.setValue({
                        min: t.min,
                        step: t.step,
                        uiStep: t.uiStep,
                        max: t.max,
                        format: this._numericFormatter
                    })
                }
                getQtyProperties() {
                    return this._qtyProperties
                }
                updatePosition(e) {
                    this._position = e, this._position || (this._pl = void 0), this._positionInvalidated = !0, this._plInvalidated = !0, this.scheduleRepaint()
                }
                updatePL(e) {
                    this._pl = e, this._position && (this._plInvalidated = !0, this.scheduleRepaint())
                }
                updateLast(e, t, i) {
                    this._lastPrice = e, this._bid = t, this._ask = i, this._position && 0 !== this._uiState.plViewType && (this._plInvalidated = !0, this.scheduleRepaint())
                }
                bid() {
                    return this._bid
                }
                ask() {
                    return this._ask
                }
                removeNodesIfExist() {
                    if (null !== this._nodes) {
                        const e = this._nodes.container;
                        for (; null !== e.firstChild;) e.removeChild(e.firstChild);
                        let t;
                        for (t in this._nodes) t in this._nodes && delete this._nodes[t]
                    }
                    this._plDirectionCache = 0, this._plTextCache = ""
                }
                onPlClick(e) {
                    e.preventDefault(), this._uiState.plViewType = -~this._uiState.plViewType % 3, this._plInvalidated = !0, u.setValue(v.settingsKeys.PROFIT_VIEW_TYPE, this._uiState.plViewType), this.scheduleRepaint()
                }
                onPositionClick(e) {
                    var t;
                    e.preventDefault();
                    const i = Math.abs(Number(null === (t = this._position) || void 0 === t ? void 0 : t.qty));
                    i > 0 && isFinite(i) && this.qty.setValue(i)
                }
                setNodes(e) {
                    this._nodes = e
                }
                scheduleRepaint() {
                    this._repaintScheduled || (window.requestAnimationFrame ? window.requestAnimationFrame(() => this.repaint()) : window.setTimeout(() => this.repaint(), 0), this._repaintScheduled = !0)
                }
                repaint() {
                    var e, t, i, s;
                    this._repaintScheduled = !1;
                    const o = this._nodes;
                    if (null == o ? void 0 : o.container) {
                        if (this._positionInvalidated) {
                            this._positionInvalidated = !1;
                            const s = (null === (e = this._position) || void 0 === e ? void 0 : e.qty) || 0;
                            if (o.pl.classList.toggle("tv-dome-calc-block__pl--disabled", 0 === s), 0 !== s && this._symbolData) {
                                const e = Math.abs(s),
                                    i = null === (t = this._position) || void 0 === t ? void 0 : t.avgPrice,
                                    r = this._symbolData.priceFormatter.format(i);
                                let n;
                                n = this._symbolData.volumeFormatter ? this._symbolData.volumeFormatter.format(e) : e + "", o.positionText.nodeValue = `${n} @ ${r}`
                            } else o.positionText.nodeValue = "—";
                            const r = null === (i = this._position) || void 0 === i ? void 0 : i.side;
                            o.position.classList.toggle("tv-dome-calc-block__position--buy", 0 !== s && 1 === r), o.position.classList.toggle("tv-dome-calc-block__position--sell", 0 !== s && -1 === r), o.position.classList.toggle("tv-dome-calc-block__position--disabled", 0 === s)
                        }
                        if (this._plInvalidated) {
                            this._plInvalidated = !1;
                            let e = 0,
                                t = "—",
                                i = NaN;
                            if (this._position) {
                                let t = Number(this._lastPrice);
                                const s = -1 === this._position.side;
                                this._calculatePLUsingLast || (t = Number(s ? this._ask : this._bid)), i = (t - this._position.avgPrice) * (s ? -1 : 1), e = i < 0 ? -1 : 1
                            }
                            if (2 === this._uiState.plViewType) {
                                let e = NaN;
                                this._position && (e = i / this._position.avgPrice), t = isFinite(e) ? (100 * e).toFixed(2) + "%" : "—"
                            } else if (1 === this._uiState.plViewType) {
                                let e = NaN;
                                if (this._position && this._symbolData) {
                                    const {
                                        pipSize: t,
                                        minTick: s
                                    } = this._symbolData, o = isFinite(t) && t !== s ? this._oneDecimalFormatter : this._integerFormatter;
                                    e = parseFloat(o.format(i / (t || s)))
                                }
                                t = isFinite(e) ? (0, n.t)("{pips} pips").format({
                                    pips: String(e)
                                }) : "—"
                            } else void 0 !== this._pl ? (t = this._pl.toFixed(2), void 0 !== (null === (s = this._symbolData) || void 0 === s ? void 0 : s.positionCurrency) && (t = `${t} ${this._symbolData.positionCurrency}`)) : t = "—";
                            this._plTextCache !== t && (o.plText.nodeValue = t, this._plTextCache = t), this._plDirectionCache !== e && (o.pl.classList.toggle("tv-dome-calc-block__pl--loss", e < 0), o.pl.classList.toggle("tv-dome-calc-block__pl--profit", e > 0), this._plDirectionCache = e)
                        }
                    }
                }
                setHasLotSize(e) {
                    this._hasLotSize.setValue(e)
                }
                hasLotSize() {
                    return this._hasLotSize.readonly()
                }
            }
            class A {
                constructor(e, t, i) {
                    this._expiresAt = 0, this._delay = e, this._doneCb = t, this._progressCb = i
                }
                run() {
                    if (this._timeoutId) return;
                    const e = Date.now ? Date.now() : +new Date;
                    this._expiresAt = e + this._delay, this._timeoutId = window.setTimeout(() => {
                        this.abort(), this._doneCb()
                    }, this._delay), this._trackProgressScheduled || this._trackProgress()
                }
                revert() {
                    this._timeoutId && (window.clearTimeout(this._timeoutId), this._timeoutId = void 0, this.run())
                }
                abort() {
                    this._timeoutId && (window.clearTimeout(this._timeoutId), this._timeoutId = void 0, this._expiresAt = 0, this._progressCb && this._progressCb(0))
                }
                setWindow(e) {
                    this._wnd = e
                }
                _trackProgress() {
                    if (this._trackProgressScheduled = !1, !this._progressCb || !this._timeoutId) return;
                    const e = Date.now ? Date.now() : +new Date;
                    let t = 1 - (this._expiresAt - e) / this._delay;
                    t = Math.max(Math.min(t, 1), 0), this._progressCb(t), this._wnd && this._wnd.requestAnimationFrame ? this._wnd.requestAnimationFrame(() => {
                        this._trackProgress()
                    }) : window.setTimeout(() => {
                        this._trackProgress()
                    }, 40), this._trackProgressScheduled = !0
                }
            }
            var F = i(97496),
                q = i.n(F);
            class H {
                constructor() {
                    this._customFieldsCount = new(l())(0), this._currentValuesSummaryLine = new(l())(""), this._onCustomFieldsUpdate = new(q()), this._selectedComboBoxValues = new Map, this._checkboxFieldsStates = new Map, this._comboBoxItems = new(l())([]),
                        this._checkboxFields = new(l())([]), this._rewriteDisplayedSelectedItems = () => {
                            const e = [...this._getSelectedComboBoxItemsNames(), ...this._getCheckedCheckboxFieldsTitles()],
                                t = this._getCurrentDurationName();
                            void 0 !== t && e.push(t);
                            const i = e.join(", ");
                            this._currentValuesSummaryLine.setValue(i)
                        }, this._getSelectedComboBoxItemsNames = () => {
                            const e = [];
                            for (const t of this._comboBoxItems.value()) {
                                const i = (0, c.ensureDefined)(this._selectedComboBoxValues.get(t.id)).value(),
                                    s = t.items.find(e => e.value === i);
                                e.push((0, c.ensureDefined)(s).text)
                            }
                            return e
                        }, this._recountCustomFields = () => {
                            var e;
                            let t = void 0 !== this._currentDuration ? 1 : 0;
                            void 0 !== (null === (e = this._currentDuration) || void 0 === e ? void 0 : e.datetime) && t++, this._customFieldsCount.setValue(this._comboBoxItems.value().length + this._checkboxFields.value().length + t)
                        }, this._recountCustomFields()
                }
                setCustomFields(e) {
                    const t = [],
                        i = [],
                        s = new Map,
                        o = new Map;
                    e.forEach(e => {
                        if ("ComboBox" === e.inputType) {
                            const i = this._selectedComboBoxValues.get(e.id);
                            if (void 0 !== i) this._selectedComboBoxValues.delete(e.id), s.set(e.id, i), i.setValue(e.items[0].value);
                            else {
                                const t = new(l())(e.items[0].value);
                                s.set(e.id, t), t.subscribe(this._rewriteDisplayedSelectedItems)
                            }
                            t.push(e)
                        }
                        if ("Checkbox" === e.inputType) {
                            const t = this._checkboxFieldsStates.get(e.id);
                            if (void 0 !== t) this._checkboxFieldsStates.delete(e.id), o.set(e.id, t), t.setValue(e.value);
                            else {
                                const t = new(l())(e.value);
                                o.set(e.id, t), t.subscribe(this._rewriteDisplayedSelectedItems)
                            }
                            i.push(e)
                        }
                    }), this._selectedComboBoxValues.forEach(e => e.unsubscribe(this._rewriteDisplayedSelectedItems)), this._selectedComboBoxValues = s, this._checkboxFieldsStates.forEach(e => e.unsubscribe(this._rewriteDisplayedSelectedItems)), this._checkboxFieldsStates = o, this._comboBoxItems.setValue(t), this._checkboxFields.setValue(i), this._rewriteDisplayedSelectedItems(), this._recountCustomFields(), this._onCustomFieldsUpdate.fire()
                }
                comboBoxItems() {
                    return this._comboBoxItems.readonly()
                }
                getSelectedComboBoxValues() {
                    return this._selectedComboBoxValues
                }
                checkboxFields() {
                    return this._checkboxFields.readonly()
                }
                getCheckboxFieldsStates() {
                    return this._checkboxFieldsStates
                }
                getCustomFieldsCount() {
                    return this._customFieldsCount.value()
                }
                currentValuesSummaryLine() {
                    return this._currentValuesSummaryLine.readonly()
                }
                setDurationsInfo(e, t) {
                    void 0 !== t && (this._durationsMetaInfo = t), this._currentDuration = e, this._rewriteDisplayedSelectedItems(), this._recountCustomFields()
                }
                _getCheckedCheckboxFieldsTitles() {
                    const e = [];
                    for (const t of this._checkboxFields.value()) {
                        (0, c.ensureDefined)(this._checkboxFieldsStates.get(t.id)).value() && e.push(t.title)
                    }
                    return e
                }
                _getCurrentDurationName() {
                    var e, t;
                    const i = null === (e = this._currentDuration) || void 0 === e ? void 0 : e.type,
                        s = null === (t = this._durationsMetaInfo) || void 0 === t ? void 0 : t.find(e => e.value === i);
                    return null == s ? void 0 : s.name
                }
            }
            var R = i(61851),
                U = i(72571),
                W = i(97754),
                z = i(1317),
                j = i(97265),
                Q = i(87374),
                $ = i(49688),
                K = i(57947);

            function G(e) {
                const {
                    currentDuration: t,
                    durationMetaInfoList: i,
                    onDurationChanged: s
                } = e;
                return r.createElement(K.DurationControl, {
                    currentDuration: t,
                    durationMetaInfoList: i,
                    onDurationChanged: s
                })
            }
            var X = i(27734),
                Y = i(23799),
                Z = i(62410);

            function J(e) {
                const t = e.domDetails,
                    [i, s] = (0, z.useWatchedValue)(e.openState),
                    o = (0, j.useWatchedValueReadonly)({
                        watchedValue: e.currentDuration
                    }),
                    a = (0, j.useWatchedValueReadonly)({
                        watchedValue: e.durationMetaInfoList
                    }),
                    l = (0, j.useWatchedValueReadonly)({
                        watchedValue: t.currentValuesSummaryLine()
                    }),
                    d = (0, j.useWatchedValueReadonly)({
                        watchedValue: t.comboBoxItems()
                    }),
                    h = (0, j.useWatchedValueReadonly)({
                        watchedValue: t.checkboxFields()
                    }),
                    u = e.onDurationChanged,
                    m = t.getSelectedComboBoxValues(),
                    _ = t.getCheckboxFieldsStates();
                return r.createElement(r.Fragment, null, r.createElement("div", {
                    className: X.headerWrapper
                }, r.createElement("div", {
                    className: X.header,
                    onClick: () => s(!i)
                }, r.createElement("div", {
                    className: W(X.textBlock, X.summaryLine)
                }, r.createElement("span", {
                    className: X.upperCase
                }, (0, n.t)("Details") + ": "), l), r.createElement("div", {
                    className: X.arrow
                }, r.createElement(U.Icon, {
                    icon: i ? Y : Z
                })))), i && r.createElement(r.Fragment, null, r.createElement("div", null, d.length > 0 && m.size > 0 && r.createElement(r.Fragment, null, d.map(e => {
                    const t = (0, c.ensureDefined)(m.get(e.id));
                    return r.createElement("div", {
                        key: e.id,
                        className: X.customField
                    }, r.createElement(Q.CustomComboboxContainer, {
                        title: e.title,
                        items: e.items,
                        selectedItem: t,
                        forceUserToSelectValue: !1,
                        alwaysShowAttachedErrors: !1
                    }))
                })), h.length > 0 && _.size > 0 && r.createElement(r.Fragment, null, h.map(e => r.createElement("div", {
                    key: e.id,
                    className: X.customField
                }, r.createElement($.CheckboxCustomField, {
                    title: e.title,
                    help: e.help,
                    checked: (0, c.ensureDefined)(_.get(e.id))
                })))), r.createElement("div", {
                    className: X.duration
                }, void 0 !== o && void 0 !== a && r.createElement(G, {
                    currentDuration: o,
                    durationMetaInfoList: a,
                    onDurationChanged: u
                })))))
            }
            var ee = i(87125),
                te = i(84039),
                ie = i(63858);

            function se(e) {
                const {
                    calcData: t
                } = e, [i, s] = (0, r.useState)(!1), [o, a] = (0, r.useState)(), [l, d] = (0, r.useState)(t.qty.value()), [c, h] = (0, z.useWatchedValue)(t.qty), u = (0, j.useWatchedValueReadonly)({
                    watchedValue: t.getQtyProperties()
                }), m = (0, j.useWatchedValueReadonly)({
                    watchedValue: t.hasLotSize()
                }) ? (0, n.t)("Lots") : (0, n.t)("Units");
                return (0, r.useEffect)(() => {
                    if (c === l) return;
                    const {
                        res: e,
                        msg: t
                    } = (0, te.checkQtyError)(u, c, !0);
                    e || d(c), s(e), a(t)
                }, [c, u, l]), r.createElement("div", {
                    className: ie.wrapper
                }, r.createElement("span", {
                    className: ie.title
                }, m), r.createElement(ee.NumberInput, {
                    alwaysUpdateValueFromProps: !0,
                    mode: "float",
                    value: c,
                    onValueChange: e => h(e),
                    errorHandler: e => s(e),
                    errorMessage: o,
                    error: i,
                    onBlur: function() {
                        if (l === c) return;
                        h(l)
                    },
                    min: u.min,
                    max: u.max,
                    step: u.step,
                    uiStep: u.uiStep
                }))
            }
            var oe = i(25784),
                re = i(58499);
            const ne = (0, oe.hotKeySerialize)({
                    keys: ["Shift", "B"],
                    text: "{0} + {1}"
                }),
                ae = (0, oe.hotKeySerialize)({
                    keys: ["Shift", "S"],
                    text: "{0} + {1}"
                }),
                le = (0, n.t)("Buy Mkt"),
                de = (0, n.t)("Sell Mkt");

            function ce(e) {
                const {
                    uiPlaceOrder: t
                } = e;
                return r.createElement("div", {
                    className: W(re.row, re.wrapper, re.marketBlock)
                }, r.createElement("button", {
                    className: W(re.buttonBuy, "apply-common-tooltip"),
                    "data-tooltip-hotkey": ne,
                    onClick: e => {
                        e.preventDefault(), t({
                            type: 2,
                            side: 1
                        })
                    }
                }, le), r.createElement("button", {
                    className: W(re.buttonSell, "apply-common-tooltip"),
                    "data-tooltip-hotkey": ae,
                    onClick: e => {
                        e.preventDefault(), t({
                            type: 2,
                            side: -1
                        })
                    }
                }, de))
            }
            const he = (0, n.t)("CXL All"),
                ue = (0, n.t)("Flatten"),
                me = (0, n.t)("Reverse"),
                _e = (0, n.t)("Cancel all orders for the current symbol"),
                pe = (0, n.t)("Close the position"),
                ve = (0, n.t)("Reverse the position");

            function ge(e) {
                return r.createElement("div", {
                    className: W(re.row, re.wrapper, re.tradingActionBlock)
                }, r.createElement("button", {
                    className: W(re.buttonOrdinary, "apply-common-tooltip"),
                    title: pe,
                    disabled: e.isPositionBlocked || !e.isTradable || !e.hasPosition || !e.hasFlatten,
                    onClick: t => {
                        t.preventDefault(), e.uiClosePosition()
                    }
                }, ue), r.createElement("button", {
                    className: W(re.buttonOrdinary, "apply-common-tooltip"),
                    title: _e,
                    disabled: !e.isTradable || !(e.hasBuyOrders || e.hasSellOrders),
                    onClick: t => {
                        t.preventDefault(), e.uiCancelAllOrders()
                    }
                }, he), r.createElement("button", {
                    className: W(re.buttonOrdinary, "apply-common-tooltip"),
                    title: ve,
                    disabled: e.isPositionBlocked || !e.isTradable || !e.hasPosition || !e.hasReverse,
                    onClick: t => {
                        t.preventDefault(), e.uiReversePosition()
                    }
                }, me))
            }
            var be = i(91180);

            function ye(e) {
                const t = (0, R.useObservable)(e.uiState$, {
                        isTradable: !1,
                        isPositionBlocked: !1,
                        hasPosition: !1,
                        hasBuyOrders: !1,
                        hasSellOrders: !1,
                        qty: 1,
                        gtcOrder: !1,
                        hasFlatten: !1,
                        hasReverse: !1
                    }),
                    i = e.domDetailsDropdownProps.domDetails.getCustomFieldsCount();
                return r.createElement("div", {
                    className: be.container
                }, r.createElement(ge, { ...e.tradingActionBlockControllers,
                    ...t
                }), r.createElement(se, { ...e.domNumberContainerProps
                }), r.createElement(ce, { ...e.domMarketActionBlockProps
                }), t.isTradable && 0 !== i && r.createElement(J, { ...e.domDetailsDropdownProps
                }))
            }
            i(86247), i(45911), i(39227);
            var fe = i(42542),
                we = i(65278),
                ke = i(54071),
                xe = i(59243),
                Se = i(34868);

            function Pe(e, t) {
                return `${v.settingsKeys.DOM_DURATION}${e}.${t}`
            }
            const Ce = {
                1: "LIMIT",
                2: "MARKET",
                3: "STOP",
                4: "STOPLIMIT"
            };

            function Ie(e) {
                var t, i;
                return e instanceof MouseEvent ? e.pageY : null !== (i = null === (t = e.touches[0]) || void 0 === t ? void 0 : t.pageY) && void 0 !== i ? i : 0
            }
            class De {
                constructor(e, t, i, s) {
                    this.delayedData = new(l())(!1), this.isBats = new(l())(!1), this._container = null, this._warning = null, this._mainBlock = null, this._svgTimerPath = null, this._noDataNoticeBlock = null, this._totalVolumeBidTextNode = null, this._totalVolumeAskTextNode = null, this._countVolumeBuyTextNode = null, this._countVolumeSellTextNode = null, this._countVolumeBid = null, this._countVolumeAsk = null, this._subscription = null, this._noDataTimeout = null, this._actionMarketButtons = null, this._actionPositionButtons = null, this._navButtons = null, this._currentDuration = new(l()), this._durationMetaInfoList = new(l()), this._viewTotalVolumeScheduled = !1, this._detailsOpenState = new(l())(!1), this._csxAllTitle = (0, n.t)("Cancel all orders for the current symbol"), this._flattenTitle = (0, n.t)("Close the position"), this._reverseTitle = (0, n.t)("Reverse the position"), this._onDurationChanged = e => {
                        this._currentDuration.setValue(e), this._domDetails.setDurationsInfo(e);
                        const t = this._realtimeProvider.activeBroker();
                        if (null === t) return;
                        const i = Pe(t.metainfo().id, h.linking.proSymbol.value());
                        u.setValue(i, e.type)
                    }, this._onSuggestedQtyChange = e => {
                        this._calcData.qty.setValue(e), this._mergeUiState({
                            qty: e
                        })
                    }, this._visible = t, this._symbolData = null, this._supportedOrderTypes = [2], this._domDetails = new H, this._trading = i, this._qtySuggester = s, this._realtimeProvider = this._trading.realtimeProvider();
                    const o = this._handlers(),
                        r = {
                            zeroVolume: this._trading.showPricesWith().zeroVolume.readonly(),
                            spread: this._trading.showPricesWith().spread.readonly()
                        };
                    this._data = new V(o, r, this._realtimeProvider), this._calcData = new E(o), this._uiState = {
                        isTradable: !1,
                        isPositionBlocked: !1,
                        hasPosition: !1,
                        hasBuyOrders: !1,
                        hasSellOrders: !1,
                        qty: 1,
                        gtcOrder: !1,
                        hasFlatten: !1,
                        hasReverse: !1
                    }, this._upperBlockResizeObserver = new p.default(e => {
                        for (const t of e) {
                            const e = Math.ceil(t.target.clientHeight / 20);
                            this._data.setHeight(e)
                        }
                    }), this._uiState$ = new d.BehaviorSubject(this._uiState), this._timerLockState = {}, this._timer = new A(2e3, () => {
                        this._data.centerOnLast()
                    }, e => {
                        this._updateTimerUi(e)
                    }), this._data.autoCenterRequired.subscribe(e => {
                        this._mergeTimerLockState({
                            autoCenterRequired: e
                        })
                    }), e.subscribe(e => this._recreateLayout(e), {
                        callWithLast: !0
                    }), h.linking.proSymbol.subscribe(() => {
                        this._onStateChange(), this._updateDetails()
                    }), this._realtimeProvider.onStatusChanged.subscribe(null, () => {
                        this._onStateChange(), this._updateDetails()
                    }), t.subscribe(() => {
                        this._onStateChange()
                    }), this._onStateChange(), this._updateDetails()
                }
                uiScroll(e) {
                    this._data.getDynamicModeState() || (this._data.shiftTopIndexRelativeToIndex(this._data.topIndex, 0 | e), this._timer.revert())
                }
                uiCenter() {
                    this._data.centerOnLast(), this._trackEvent("Center")
                }
                uiCancelOrder(e) {
                    this._uiState.isTradable && null !== e && ((0, c.ensureNotNull)(this._trading.brokerCommandsUI() || null).cancelOrder(e), this._trackEvent("Cancel Order"))
                }
                uiModifyOrder(e, t = null) {
                    if (!e || !this._uiState.isTradable || void 0 === this._configFlags || !(0, S.isModifyOrderSupported)(e, this._configFlags)) return Promise.resolve();
                    let i = !0;
                    null === t && (t = {}, i = !1);
                    const s = (0, c.ensureNotNull)(this._trading.brokerCommandsUI() || null).modifyOrder({ ...e,
                        ...t
                    }, i, void 0, !0);
                    return this._lockTimerUntilSettled(s), this._trackEvent("Modify Order"), Promise.resolve()
                }
                uiPlaceOrder({
                    side: e,
                    type: t,
                    price: i = NaN,
                    altPrice: s = NaN
                }) {
                    var o;
                    if (!this._realtimeProvider.activeBroker()) return void this._trading.toggleTradingWidget().then(() => {
                        this._trading.onNeedSelectBroker.fire()
                    });
                    if (!(null === (o = this._subscription) || void 0 === o ? void 0 : o.broker)) return void this._trading.toggleTradingWidget();
                    if (2 !== t && !isFinite(i)) return;
                    null === t && (t = this._data.guessOrderType(i, e));
                    let r = !0;
                    if (null === t && (r = !1, t = 1), !this._isOrderTypeSupported(t)) return;
                    const n = {};
                    for (const [e, t] of this._domDetails.getSelectedComboBoxValues()) n[e] = t.value();
                    for (const [e, t] of this._domDetails.getCheckboxFieldsStates()) n[e] = t.value();
                    const a = 1 === e ? this._calcData.ask() : this._calcData.bid(),
                        l = {
                            symbol: h.linking.proSymbol.value(),
                            qty: this._calcData.qty.value(),
                            side: e,
                            type: t,
                            seenPrice: null != a ? a : null,
                            duration: this._currentDuration.value(),
                            customFields: n
                        };
                    3 === l.type && (l.stopPrice = i), 1 === l.type && (l.limitPrice = i), 4 === l.type && (l.stopPrice = i, isFinite(s) ? l.limitPrice = s : r = !1), this._lockTimerUntilSettled((0,
                        c.ensureNotNull)(this._trading.brokerCommandsUI() || null).placeOrder(l, r, !0)), this._trackEvent("Place Order", Ce[t])
                }
                uiCancelAllOrders(e) {
                    const t = this._uiState;
                    if (!t.isTradable || !t.hasBuyOrders && !t.hasSellOrders || 1 === e && !t.hasBuyOrders || -1 === e && !t.hasSellOrders) return Promise.resolve();
                    const i = (0, c.ensureNotNull)(this._trading.brokerCommandsUI() || null).cancelOrders(h.linking.proSymbol.value(), e);
                    return this._lockTimerUntilSettled(i), e ? this._trackEvent("Cancel All " + (1 === e ? "Buy" : "Sell") + " Orders") : this._trackEvent("Cancel All Orders"), Promise.resolve()
                }
                async uiClosePosition() {
                    if (this._uiState.isPositionBlocked || !this._uiState.isTradable || !this._uiState.hasPosition || !this._uiState.hasFlatten) return;
                    const e = this._realtimeProvider.activeBroker();
                    if (!e) return;
                    this._mergeUiState({
                        isPositionBlocked: !0
                    });
                    const t = e.positions(h.linking.proSymbol.value()).then(e => {
                        for (const t of e)
                            if (0 !== t.qty) return (0, c.ensureNotNull)(this._trading.brokerCommandsUI()).closePosition(t.id);
                        return Promise.resolve(!1)
                    }).finally(() => this._mergeUiState({
                        isPositionBlocked: !1
                    }));
                    this._lockTimerUntilSettled(t), this._trackEvent("Close Position")
                }
                async uiReversePosition() {
                    if (this._uiState.isPositionBlocked || !this._uiState.isTradable || !this._uiState.hasPosition || !this._uiState.hasReverse) return;
                    const e = this._realtimeProvider.activeBroker();
                    if (!e) return;
                    this._mergeUiState({
                        isPositionBlocked: !0
                    });
                    const t = e.positions(h.linking.proSymbol.value()).then(e => {
                        for (const t of e)
                            if (0 !== t.qty) return (0, c.ensureNotNull)(this._trading.brokerCommandsUI()).reversePosition(t.id);
                        return Promise.resolve(!1)
                    }).finally(() => this._mergeUiState({
                        isPositionBlocked: !1
                    }));
                    this._lockTimerUntilSettled(t), this._trackEvent("Reverse")
                }
                uiOrderMousedown(e, t, i) {
                    if (1 !== e.buttons || null === t || null === this._mainBlock || null === this._subscription) return;
                    this.uiStopOrderDrag();
                    const s = t[i],
                        o = this._subscription;
                    let r = NaN;
                    o.orderMouseRoot = document.documentElement, o.orderMousemoveHandler = e => {
                        if (e.preventDefault(), 1 !== (e.buttons || e.which) || void 0 === this._configFlags || !(0, S.isMoveOrderSupported)(t, this._configFlags)) return void this.uiStopOrderDrag();
                        const s = (0, c.ensureNotNull)(this._mainBlock).getBoundingClientRect().y,
                            o = Ie(e) - s,
                            n = -Math.floor(o / 20),
                            a = this._data.correctIndex(this._data.topIndex, n);
                        r = this._data.indexToPrice(a), this._data.setDragShield(!0, !0), this._mergeTimerLockState({
                            drag: !0
                        }), this._data.setOrderGhost({
                            order: t,
                            pricePropertyName: i,
                            price: r
                        })
                    }, o.orderMouseupHandler = () => {
                        this.uiStopOrderDrag();
                        this._realtimeProvider.activeBroker() && isFinite(r) && r !== s && (this._data.setOrderGhost({
                            order: t,
                            pricePropertyName: i,
                            price: r
                        }), this._data.setDragShield(!0, !0), this._trackEvent("Move Order"), this.uiModifyOrder(t, {
                            [i]: r
                        }).then(() => this.uiStopOrderDrag()).catch(() => this.uiStopOrderDrag()))
                    }, o.orderMousedownHandler = () => {
                        this.uiStopOrderDrag()
                    }, o.orderMouseRoot.addEventListener("mousemove", o.orderMousemoveHandler), o.orderMouseRoot.addEventListener("mouseup", o.orderMouseupHandler), setTimeout(() => {
                        const {
                            orderMouseRoot: e,
                            orderMousedownHandler: t
                        } = o;
                        e && t && e.addEventListener("mousedown", t)
                    }, 0)
                }
                uiStopOrderDrag() {
                    if (this._data.setDragShield(!1, !1), this._data.resetOrderGhost(), this._mergeTimerLockState({
                            drag: !1
                        }), !this._subscription) return;
                    const {
                        orderMousemoveHandler: e,
                        orderMouseupHandler: t,
                        orderMousedownHandler: i,
                        orderMouseRoot: s
                    } = this._subscription;
                    delete this._subscription.orderMousemoveHandler, delete this._subscription.orderMouseupHandler, delete this._subscription.orderMousedownHandler, delete this._subscription.orderMouseRoot, s && e && s.removeEventListener("mousemove", e), s && t && s.removeEventListener("mouseup", t), s && i && s.removeEventListener("mousedown", i)
                }
                uiContextMenu(e, t, i) {
                    if (!this._uiState.isTradable) return;
                    if (1 !== t && -1 !== t) return;
                    const s = this._uiState.qty || NaN,
                        o = h.linking.seriesShortSymbol.value() || h.linking.proSymbol.value(),
                        r = (0, y.abbreviatedNumber)(s),
                        a = [],
                        l = this._symbolData && this._symbolData.priceFormatter || new g.PriceFormatter;
                    if (this._trackEvent("Context Menu"), isFinite(i)) {
                        const e = l.format(i);
                        if (this._isOrderTypeSupported(3)) {
                            const s = {
                                stopPrice: e,
                                qty: r,
                                symbol: o
                            };
                            let l = "";
                            l = 1 === t ? (0, n.t)("Buy {qty} {symbol} @ {stopPrice} Stop", {
                                replace: s
                            }) : (0, n.t)("Sell {qty} {symbol} @ {stopPrice} Stop", {
                                replace: s
                            });
                            const d = new f.Action({
                                actionId: "Trading.DomePlaceStopOrder",
                                label: l,
                                onExecute: () => {
                                    this.uiPlaceOrder({
                                        side: t,
                                        price: i,
                                        type: 3
                                    })
                                }
                            });
                            a.push(d)
                        }
                        if (this._isOrderTypeSupported(1)) {
                            const s = {
                                limitPrice: e,
                                qty: r,
                                symbol: o
                            };
                            let l = "";
                            l = 1 === t ? (0, n.t)("Buy {qty} {symbol} @ {limitPrice} Limit", {
                                replace: s
                            }) : (0, n.t)("Sell {qty} {symbol} @ {limitPrice} Limit", {
                                replace: s
                            });
                            const d = new f.Action({
                                actionId: "Trading.DomePlaceLimitOrder",
                                label: l,
                                onExecute: () => {
                                    this.uiPlaceOrder({
                                        side: t,
                                        price: i,
                                        type: 1
                                    })
                                }
                            });
                            a.push(d)
                        }
                        if (this._symbolData && this._hasStopLimit) {
                            const s = i + this._symbolData.minTick * (1 === t ? 1 : -1),
                                d = {
                                    stopPrice: e,
                                    limitPrice: l.format(s),
                                    qty: r,
                                    symbol: o
                                };
                            let c = "";
                            c = 1 === t ? (0, n.t)("Buy {qty} {symbol} @ {stopPrice} Stop {limitPrice} Limit", {
                                replace: d
                            }) : (0, n.t)("Sell {qty} {symbol} @ {stopPrice} Stop {limitPrice} Limit", {
                                replace: d
                            });
                            const h = new f.Action({
                                actionId: "Trading.DomePlaceStopLimitOrder",
                                label: c,
                                onExecute: () => {
                                    this.uiPlaceOrder({
                                        side: t,
                                        price: i,
                                        altPrice: s,
                                        type: 4
                                    })
                                }
                            });
                            a.push(h)
                        }
                    }
                    if (this._isOrderTypeSupported(2)) {
                        const e = {
                            qty: r,
                            symbol: o
                        };
                        let i = "";
                        i = 1 === t ? (0, n.t)("Buy {qty} {symbol} @ Market", {
                            replace: e
                        }) : (0, n.t)("Sell {qty} {symbol} @ Market", {
                            replace: e
                        });
                        const s = new f.Action({
                            actionId: "Trading.DomePlaceMarketOrder",
                            label: i,
                            onExecute: () => {
                                this.uiPlaceOrder({
                                    side: t,
                                    type: 2
                                })
                            }
                        });
                        a.push(s)
                    }
                    a.length && w.ContextMenuManager.showMenu(a, e, void 0, {
                        menuName: "DomeWidgetContextMenu"
                    })
                }
                _recreateLayout(e) {
                    null !== this._container && (this._container.innerHTML = "");
                    const t = document.createElement("div"),
                        o = document.createElement("div");
                    this._upperBlockResizeObserver.disconnect(), this._upperBlockResizeObserver.observe(t), t.classList.add(we.upperBlock), o.classList.add(we.bottomBlock), this._calcData.removeNodesIfExist(), this._container = e;
                    const r = function(e) {
                        const t = document.createElement("span"),
                            o = document.createElement("span");
                        return t.className = "tv-dome-widget-main__offscreen-arrow tv-dome-widget-main__offscreen-arrow--higher js-hidden",
                            o.className = "tv-dome-widget-main__offscreen-arrow tv-dome-widget-main__offscreen-arrow--lower js-hidden", t.innerHTML = i(39022), o.innerHTML = i(37885), e.append(t), e.append(o), e => {
                                t.classList.toggle("js-hidden", e !== s.Higher), o.classList.toggle("js-hidden", e !== s.Lower)
                            }
                    }(t);
                    this._data.getOffscreenIndexLocationObservable().subscribe(r), this._createMainBlock(t), this._createNavBlock(o), this._createCalculatorBlock(o), this._createDomBottomWidget(o), this._container.append(t), this._container.append(o), this._calcData.reset()
                }
                _createMainBlock(e) {
                    const t = document.createElement("div");
                    t.className = "tv-dome-widget-main", e.append(t);
                    const i = this._warning = document.createElement("div");
                    i.className = "tv-dome-panel__warning i-hidden", i.textContent = (0, n.t)("No data"), t.append(i), this._data.setContainer(t);
                    let s = 0;
                    t.addEventListener("wheel", e => {
                        if (e.preventDefault(), !this._data.getDynamicModeState() && (e.deltaMode !== e.DOM_DELTA_PAGE ? s -= (0, m.getPixelsFromEvent)(e).y / 100 : s -= (0, _.clamp)(e.deltaY, -1, 1), Math.abs(s) >= 1)) {
                            const e = s % 1;
                            this.uiScroll(s - e), s = e
                        }
                    });
                    let o = !1;
                    const r = e => {
                        if (o) return;
                        const t = "touches" in e;
                        if (!t && 1 !== (e.buttons || e.which)) return;
                        const i = this._data.topIndex;
                        if (!isFinite(i)) return;
                        if (t && 1 !== e.touches.length) return;
                        if (!(e.target instanceof Element)) return;
                        if (!e.target.closest(".tv-dome-widget-main__value--price")) return;
                        o = !0;
                        const s = Ie(e),
                            r = document.documentElement,
                            n = () => {
                                ["mouseup", "mousedown", "touchend", "touchstart", "touchcancel"].forEach(e => r.removeEventListener(e, n)), r.removeEventListener("mousemove", a), r.removeEventListener("touchmove", a), o = !1, this._data.setDragShield(!1, !1), this._mergeTimerLockState({
                                    scroll: !1
                                })
                            },
                            a = e => {
                                if (e.preventDefault(), !this._data.getDynamicModeState()) {
                                    if (!t && 1 !== (e.buttons || e.which)) return void n();
                                    const o = Ie(e) - s,
                                        r = Math.round(o / 20);
                                    r && (this._data.setDragShield(!0, !1), this._mergeTimerLockState({
                                        scroll: !0
                                    })), this._data.shiftTopIndexRelativeToIndex(i, r)
                                }
                            };
                        r.addEventListener(t ? "touchmove" : "mousemove", a), r.addEventListener(t ? "touchend" : "mouseup", n), t && r.addEventListener("touchcancel", n), setTimeout(() => {
                            o && r.addEventListener(t ? "touchstart" : "mousedown", n)
                        }, 0)
                    };
                    t.addEventListener("mousedown", r), t.addEventListener("touchstart", r), t.addEventListener("dblclick", e => {
                        if (!(e.target instanceof Element)) return;
                        e.target.closest(".tv-dome-widget-main__value--price") && this.uiCenter()
                    }), this._mainBlock = t, document.addEventListener("keydown", e => this._data.handlerKey(e), !1), document.addEventListener("keyup", e => this._data.handlerKey(e), !1)
                }
                _createDomBottomWidget(e) {
                    const t = document.createElement("div");
                    e.append(t);
                    const i = {
                            domDetails: this._domDetails,
                            currentDuration: this._currentDuration,
                            durationMetaInfoList: this._durationMetaInfoList,
                            onDurationChanged: this._onDurationChanged,
                            openState: this._detailsOpenState
                        },
                        s = {
                            calcData: this._calcData
                        },
                        n = {
                            uiPlaceOrder: e => this.uiPlaceOrder(e)
                        },
                        a = {
                            uiClosePosition: () => this.uiClosePosition(),
                            uiCancelAllOrders: () => this.uiCancelAllOrders(),
                            uiReversePosition: () => this.uiReversePosition()
                        };
                    ! function(e, t) {
                        o.render(r.createElement(ye, { ...t
                        }), e)
                    }(t, {
                        uiState$: this._uiState$.asObservable(),
                        tradingActionBlockControllers: a,
                        domDetailsDropdownProps: i,
                        domNumberContainerProps: s,
                        domMarketActionBlockProps: n
                    })
                }
                _createCalculatorBlock(e) {
                    const t = document.createElement("div");
                    t.classList.add("tv-dome-widget-actions"), e.append(t), t.appendChild((0, c.ensureNotNull)((0, k.parseHtmlElement)(`\n\t\t\t\t<div class="tv-dome-widget-calculator tv-dome-calc-block ${fe.wrapper}">\n\t\t\t\t\t<div class="tv-dome-calc-block__wrap">\n\t\t\t\t\t\t<span class="tv-dome-calc-block__position tv-dome-calc-block__position--disabled js-position"></span>\n\t\t\t\t\t\t<span class="tv-dome-calc-block__pl tv-dome-calc-block__pl--disabled js-pl"></span>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t`))), t.classList.add("tv-dome-calc-block");
                    const i = document.createTextNode(""),
                        s = document.createTextNode(""),
                        o = (0, c.ensureNotNull)(t.querySelector(".js-position"));
                    o.classList.add("apply-common-tooltip"), o.setAttribute("title", (0, n.t)("Position")), o.appendChild(s);
                    const r = (0, c.ensureNotNull)(t.querySelector(".js-pl"));
                    r.classList.add("apply-common-tooltip"), r.setAttribute("title", (0, n.t)("Profit/Loss")), r.appendChild(i), this._calcData.setNodes({
                        container: t,
                        position: o,
                        pl: r,
                        plText: i,
                        positionText: s
                    }), o.addEventListener("click", e => {
                        this._calcData.onPositionClick(e)
                    }), r.addEventListener("click", e => {
                        this._calcData.onPlClick(e)
                    }), this._calcData.scheduleRepaint()
                }
                _createNavBlock(e) {
                    const t = {
                            on: xe,
                            off: Se
                        },
                        i = (0, c.ensureNotNull)((0,
                            k.parseHtmlElement)(`\n\t\t\t<div class="tv-dome-widget-nav-wrapper">\n\t\t\t\t<div class="tv-dome-widget-nav">\n\t\t\t\t\t<div class="tv-dome-widget-nav__button-block tv-dome-widget-nav__button-block--orders">\n\t\t\t\t\t\t<span class="apply-common-tooltip tv-dome-widget-nav__button tv-dome-widget-nav__button--clear-ask js-clear-ask">\n\t\t\t\t\t\t\t${ke}\n\t\t\t\t\t\t</span>\n\t\t\t\t\t\t<span class="tv-dome-widget-nav_count-volume js-count-volume-buy"></span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class="tv-dome-widget-nav__button-block tv-dome-widget-nav__button-block--price">\n\t\t\t\t\t\t<div class="tv-dome-widget-nav_overall-volume tv-dome-widget-nav_overall-volume--bid">\n\t\t\t\t\t\t\t<span class="apply-common-tooltip js-total-volume-bid"></span>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class="tv-dome-widget-nav_center apply-common-tooltip js-center">\n\t\t\t\t\t\t\t<svg class="tv-dome-widget-nav__timer" viewBox="-1 -1 2 2" width="2" height="2">\n\t\t\t\t\t\t\t\t<path d="M 0,0" class="js-timer-path"></path>\n\t\t\t\t\t\t\t</svg>\n\t\t\t\t\t\t\t<span class="tv-dome-widget-nav__button tv-dome-widget-nav__button--center js-center-target">\n\t\t\t\t\t\t\t\t${t.off}\n\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class="tv-dome-widget-nav_overall-volume tv-dome-widget-nav_overall-volume--ask">\n\t\t\t\t\t\t\t<span class="apply-common-tooltip js-total-volume-ask"></span>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class="tv-dome-widget-nav__button-block tv-dome-widget-nav__button-block--orders">\n\t\t\t\t\t\t<span class="tv-dome-widget-nav_count-volume js-count-volume-sell"></span>\n\t\t\t\t\t\t<span class="apply-common-tooltip tv-dome-widget-nav__button tv-dome-widget-nav__button--clear-bid js-clear-bid">\n\t\t\t\t\t\t\t${ke}\n\t\t\t\t\t\t</span>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t`)),
                        s = (0, c.ensureNotNull)(i.querySelector(".js-clear-ask")),
                        o = (0, c.ensureNotNull)(i.querySelector(".js-clear-bid")),
                        r = (0, c.ensureNotNull)(i.querySelector(".js-center")),
                        a = (0, c.ensureNotNull)(i.querySelector(".js-center-target"));
                    this._totalVolumeBidTextNode = document.createTextNode("-"), this._totalVolumeAskTextNode = document.createTextNode("-"), this._countVolumeBuyTextNode = document.createTextNode(""), this._countVolumeSellTextNode = document.createTextNode("");
                    const l = (0, c.ensureNotNull)(i.querySelector(".js-total-volume-bid")),
                        d = (0, c.ensureNotNull)(i.querySelector(".js-total-volume-ask")),
                        h = (0, c.ensureNotNull)(this._countVolumeBid = i.querySelector(".js-count-volume-buy")),
                        u = (0, c.ensureNotNull)(this._countVolumeAsk = i.querySelector(".js-count-volume-sell"));
                    l.appendChild(this._totalVolumeBidTextNode), l.setAttribute("title", (0, n.t)("Total buy quantity")), d.appendChild(this._totalVolumeAskTextNode), d.setAttribute("title", (0, n.t)("Total sell quantity")), h.appendChild(this._countVolumeBuyTextNode), u.appendChild(this._countVolumeSellTextNode), s.setAttribute("title", (0, n.t)("Cancel all buy orders")), o.setAttribute("title", (0, n.t)("Cancel all sell orders")), r.setAttribute("title", (0, n.t)("Disable dynamic mode")),
                        s.addEventListener("click", e => {
                            e.preventDefault(), this.uiCancelAllOrders(1)
                        }), o.addEventListener("click", e => {
                            e.preventDefault(), this.uiCancelAllOrders(-1)
                        }), r.addEventListener("click", e => {
                            e.preventDefault(), this.uiCenter();
                            const i = this._data.toggleDynamicModeState(),
                                s = i ? t.on : t.off,
                                o = i ? (0, n.t)("Enable dynamic mode") : (0, n.t)("Disable dynamic mode");
                            r.setAttribute("title", o), a.removeChild(a.children[0]), a.appendChild((0, c.ensureNotNull)((0, k.parseHtmlElement)(s)))
                        }), this._svgTimerPath = i.querySelector(".js-timer-path"), this._navButtons = {
                            clearBuy: s,
                            clearSell: o
                        }, e.append(i)
                }
                _createNoticeBlock() {
                    const e = (0, c.ensureNotNull)(this._container);
                    this._noDataNoticeBlock = document.createElement("div"), this._noDataNoticeBlock.className = "tv-dome-panel__no-data-notice", e.append(this._noDataNoticeBlock)
                }
                _showNoDataNotice() {
                    var e;
                    const t = null === (e = this._realtimeProvider.activeBroker()) || void 0 === e ? void 0 : e.metainfo().title;
                    null !== this._noDataNoticeBlock && void 0 !== t && o.render(r.createElement(Informer, {
                        header: (0, n.t)("Caution!"),
                        content: (0, n.t)("Trading with {brokerName} is not possible at the moment due to the market data not being provided. Please try again later.").replace("{brokerName}", t),
                        informerIntent: "warning"
                    }), this._noDataNoticeBlock)
                }
                _hideNoDataNotice() {
                    null !== this._noDataNoticeBlock && o.unmountComponentAtNode(this._noDataNoticeBlock)
                }
                _syncActionButtons() {
                    const {
                        isPositionBlocked: e,
                        isTradable: t,
                        hasPosition: i,
                        hasBuyOrders: s,
                        hasSellOrders: o,
                        hasFlatten: r,
                        hasReverse: n
                    } = this._uiState;
                    if (this._actionPositionButtons && this._actionMarketButtons) {
                        const a = { ...this._actionPositionButtons,
                                ...this._actionMarketButtons
                            },
                            l = "i-disabled";
                        a.flatten.disabled = e || !t || !i || !r, a.reverse.disabled = e || !t || !i || !n, a.clear.disabled = !t || !(s || o), a.flatten.title = this._flattenTitle, a.reverse.title = this._reverseTitle, a.clear.title = this._csxAllTitle;
                        const d = this._isOrderTypeSupported(2);
                        a.buyMarket.classList.toggle(l, !d), a.sellMarket.classList.toggle(l, !d)
                    }
                    if (this._navButtons) {
                        const e = this._navButtons,
                            i = "tv-dome-widget-nav__button--disabled";
                        e.clearBuy.classList.toggle(i, !t || !s), e.clearSell.classList.toggle(i, !t || !o)
                    }
                }
                _mergeUiState(e) {
                    const t = this._uiState;
                    let i, s = !1;
                    for (i in e) t[i] !== e[i] && (t[i] = e[i], s = !0);
                    s && (this._uiState$.next({ ...t
                    }), this._syncActionButtons())
                }
                _handlers() {
                    return {
                        closeButtonClick: (e, t) => {
                            e.preventDefault(), this.uiCancelOrder(t && t.id)
                        },
                        qtyClick: (e, t) => {
                            e.preventDefault(), this.uiModifyOrder(t)
                        },
                        bidAskClick: (e, {
                            side: t,
                            price: i,
                            type: s
                        }) => {
                            e.preventDefault(), this.uiPlaceOrder({
                                side: t,
                                price: i,
                                type: s || null
                            })
                        },
                        bidAskContextMenu: (e, {
                            side: t,
                            price: i
                        }) => {
                            e.preventDefault(), this.uiContextMenu(e, t, i)
                        },
                        qtyChange: e => {
                            !isFinite(e) || e < 0 || (this._qtySuggester.setQty(h.linking.proSymbol.value(), e), this._mergeUiState({
                                qty: e
                            }))
                        },
                        qtyInput: e => {
                            !isFinite(e) || e < 0 || this._mergeUiState({
                                qty: e
                            })
                        },
                        orderMousedown: (e, {
                            order: t,
                            pricePropertyName: i
                        }) => {
                            this.uiOrderMousedown(e, t, i)
                        }
                    }
                }
                _mergeTimerLockState(e) {
                    const t = this._timerLockState;
                    let i, s = !1;
                    for (i in e) t[i] !== e[i] && (t[i] = e[i], s = !0);
                    s && (!t.autoCenterRequired || t.scroll || t.drag || t.dialog ? this._timer.abort() : this._timer.run())
                }
                _lockTimerUntilSettled(e) {
                    if (!e) return;
                    this._mergeTimerLockState({
                        dialog: e
                    });
                    const t = () => {
                        this._timerLockState.dialog === e && this._mergeTimerLockState({
                            dialog: null
                        })
                    };
                    e.then(t, t)
                }
                _updateTimerUi(e) {
                    e = e || 0, (0, c.ensureNotNull)(this._svgTimerPath).setAttribute("d", (e => {
                        let t = "M 0 0";
                        return e > 0 && (e >= 1 ? t = "M 0 -1" : t += "L 0 -1", e > .5 && (t += "A 1 1 0 0 1 0 1"), t += "A 1 1 0 0 1 " + Math.sin(2 * e * Math.PI) + " " + -Math.cos(2 * e * Math.PI) + "Z"), t
                    })(e))
                }
                async _getSymbolData(e) {
                    var t;
                    const [i, s, o, r] = await Promise.all([this._realtimeProvider.symbolInfo(e), this._realtimeProvider.formatter(e), this._realtimeProvider.quantityFormatter(e), null === (t = this._realtimeProvider.activeBroker()) || void 0 === t ? void 0 : t.getPositionCurrency(e)]), n = Math.ceil(-Math.log10(i.qty.step)), a = new b.VolumeFormatter(n);
                    return {
                        minTick: i.minTick,
                        pipSize: i.pipSize,
                        priceFormatter: s,
                        volumeFormatter: a,
                        quantityFormatter: o,
                        qtyProperties: i.qty,
                        lotSize: i.lotSize,
                        positionCurrency: r
                    }
                }
                _unsubscribeData() {
                    var e;
                    if (!this._subscription) return;
                    const {
                        broker: t,
                        symbol: i,
                        domeHandler: s,
                        realtimeHandler: o,
                        orderHandler: r,
                        positionHandler: n,
                        plHandler: a,
                        plPositionId: l,
                        fullUpdateOrders: d,
                        fullUpdatePosition: c
                    } = this._subscription;
                    this._subscription = null, i && o && this._realtimeProvider.unsubscribeRealtime(i, o), i && s && this._realtimeProvider.unsubscribeDOME(i, s), t && r && t.orderUpdate.unsubscribe(null, r), t && n && t.positionUpdate.unsubscribe(null, n), t && a && l && t.unsubscribePL(l, a), t && d && t.currentAccountUpdate.unsubscribe(null, d), t && c && t.currentAccountUpdate.unsubscribe(null, c), null === (e = this._suggestedQtySubscription) || void 0 === e || e.unsubscribe()
                }
                _trackEvent(e, t) {
                    this._trading.trackEvent("DOM", e, t)
                }
                _processOrders(e) {
                    const t = [];
                    let i = !1,
                        s = !1;
                    for (let o = 0; o < e.length; o++) {
                        const r = e[o];
                        if (4 === r.status || 3 === r.status || 6 === r.status) switch (t.push(r), r.side) {
                            case 1:
                                i = !0;
                                break;
                            case -1:
                                s = !0
                        }
                    }
                    this._data.updateOrders(t), this._updateValueBuySellOrders(), this._mergeUiState({
                        hasBuyOrders: i,
                        hasSellOrders: s
                    })
                }
                _processPositions(e, t, i) {
                    const s = i.filter(e => 0 !== e.qty)[0];
                    this._mergeUiState({
                        hasPosition: !!s
                    }), s && s.id === t.plPositionId || t.plPositionId && t.plHandler && e.unsubscribePL && (e.unsubscribePL(t.plPositionId, t.plHandler), delete t.plPositionId, t.plHandler = null), s && (t.plPositionId === s.id && t.plHandler || (t.plHandler = (e, i) => {
                        this._subscription === t && this._calcData.updatePL(i)
                    }, t.plPositionId = s.id, e.subscribePL(t.plPositionId, t.plHandler))), this._data.updatePosition(s), this._calcData.updatePosition(s)
                }
                _updateDurationMetainfo(e, t) {
                    if (this._durationMetaInfoList.setValue(null == e ? void 0 : e.metainfo().durations), null === e || void 0 === this._durationMetaInfoList.value()) return;
                    const i = Pe(e.metainfo().id, t),
                        s = u.getValue(i),
                        o = void 0 !== s ? this._makeOrderDuration(s) : this._makeDefaultOrderDuration();
                    this._currentDuration.setValue(o), void 0 !== o && this._domDetails.setDurationsInfo(o, this._durationMetaInfoList.value())
                }
                _makeDefaultOrderDuration() {
                    if (void 0 === this._durationMetaInfoList.value()) return;
                    const e = this._durationMetaInfoList.value();
                    if (void 0 === e || 0 === e.length) return;
                    const t = e.find(e => !0 === e.default) || e[0];
                    return (0, x.makeOrderDuration)(t)
                }
                _makeOrderDuration(e) {
                    var t;
                    const i = null === (t = this._durationMetaInfoList.value()) || void 0 === t ? void 0 : t.find(t => t.value === e);
                    return void 0 !== i ? (0, x.makeOrderDuration)(i) : void 0
                }
                async _onStateChange() {
                    var e;
                    const t = h.linking.proSymbol.value(),
                        i = this._realtimeProvider.activeBroker(),
                        s = null == i ? void 0 : i.metainfo().configFlags.calculatePLUsingLast;
                    if (this._updateDurationMetainfo(i, t), !this._visible.value()) return void this._unsubscribeData();
                    this._noDataTimeout && clearTimeout(this._noDataTimeout), this._noDataTimeout = setTimeout(() => {
                        var e;
                        null === (e = this._warning) || void 0 === e || e.classList.remove("i-hidden")
                    }, 3e3), this._symbolData = null, this._unsubscribeData(), this._data.reset(), this._calcData.setBrokerConfigFlags({
                        calculatePLUsingLast: !0 === s
                    }), this._calcData.reset();
                    const o = null === i || (null == i ? void 0 : i.metainfo().configFlags.supportDOM);
                    this._configFlags = null == i ? void 0 : i.metainfo().configFlags, this._hasStopLimit = null !== i && i.metainfo().configFlags.supportStopLimitOrders, this._mergeUiState({
                        isTradable: !1,
                        hasPosition: !1,
                        hasBuyOrders: !1,
                        hasSellOrders: !1,
                        qty: void 0,
                        hasFlatten: null !== i && !i.metainfo().configFlags.supportMultiposition,
                        hasReverse: null !== i && i.metainfo().configFlags.supportReversePosition
                    }), this._mergeTimerLockState({
                        scroll: !1,
                        drag: !1,
                        dialog: null
                    }), this.uiStopOrderDrag();
                    let r = [],
                        n = [];
                    if (!t || !o) return;
                    const a = {
                        broker: i,
                        symbol: t,
                        domeHandler: null,
                        realtimeHandler: null,
                        orderHandler: null,
                        positionHandler: null,
                        plHandler: null,
                        plPositionId: void 0,
                        fullUpdateOrders: null,
                        fullUpdatePosition: null
                    };
                    this._subscription = a;
                    const l = await this._qtySuggester.getQty(t);
                    this._onSuggestedQtyChange(l), this._suggestedQtySubscription = this._qtySuggester.suggestedQtyChanged(t).subscribe(this._onSuggestedQtyChange);
                    const d = await this._getSymbolData(t);
                    if (this._calcData.setHasLotSize(void 0 !== d.lotSize), !d) return;
                    if (this._subscription !== a) return;
                    this._symbolData = d, this._data.setSymbolInfo(d), this._calcData.setSymbolInfo(d), this.isBats.setValue(!1), a.realtimeHandler = (e, t) => {
                        var i;
                        const s = t.trade || t.bid || t.ask;
                        s && this._noDataTimeout && (null === (i = this._warning) || void 0 === i || i.classList.add("i-hidden"), clearTimeout(this._noDataTimeout), this._noDataTimeout = null), this._data.updateLast(s || NaN), this._calcData.updateLast(t.trade || NaN, t.bid || NaN, t.ask || NaN), this.delayedData.setValue(Boolean(t.isDelayed)), !this.isBats.value() && (0, S.isBatsQuotes)(t) && this.isBats.setValue(!0)
                    }, a.domeHandler = (e, t) => {
                        this._data.updateData(t), this._scheduleUpdateViewTotalVolume()
                    };
                    const c = null === (e = await this._realtimeProvider.isTradable(t)) || void 0 === e ? void 0 : e.tradable;
                    this._mergeUiState({
                        isTradable: c
                    }), this._realtimeProvider.subscribeRealtime(t, a.realtimeHandler), this._realtimeProvider.subscribeDOME(t, a.domeHandler), this._supportedOrderTypes = this._getSupportedOrderTypes(i), i && c && (a.orderHandler = e => {
                        if (e.symbol !== a.symbol) return;
                        const t = r.findIndex(t => t.id === e.id); - 1 !== t ? r[t] = e : r.push(e), this._processOrders(r)
                    }, a.positionHandler = e => {
                        if (e.symbol !== a.symbol) return;
                        const t = n.findIndex(t => t.id === e.id); - 1 !== t ? n[t] = e : n.push(e), this._processPositions(i, a, n)
                    }, a.fullUpdateOrders = () => {
                        const e = i.orders(t);
                        a.orderPromise = e, e.then(t => {
                            this._subscription === a && a.orderPromise === e && (r = t, this._processOrders(t))
                        })
                    }, a.fullUpdatePosition = () => {
                        const e = i.positions(t);
                        a.positionPromise = e, e.then(t => {
                            this._subscription === a && a.positionPromise === e && (n = t, this._processPositions(i, a, t))
                        })
                    }, i.orderUpdate.subscribe(null, a.orderHandler), i.positionUpdate.subscribe(null, a.positionHandler), i.currentAccountUpdate.subscribe(null, a.fullUpdateOrders), i.currentAccountUpdate.subscribe(null, a.fullUpdatePosition), a.fullUpdateOrders(), a.fullUpdatePosition()), this._updateValueBuySellOrders()
                }
                async _updateDetails() {
                    var e, t;
                    const i = await (null === (e = this._realtimeProvider.activeBroker()) || void 0 === e ? void 0 : e.getOrderDialogOptions(h.linking.proSymbol.value())),
                        s = null !== (t = null == i ? void 0 : i.customFields) && void 0 !== t ? t : [];
                    this._domDetails.setCustomFields(s)
                }
                _getSupportedOrderTypes(e) {
                    const t = [];
                    return null === e || 1 !== e.connectionStatus() ? [2] : (e.metainfo().configFlags.supportMarketOrders && t.push(2), e.metainfo().configFlags.supportLimitOrders && t.push(1), e.metainfo().configFlags.supportStopOrders && t.push(3), e.metainfo().configFlags.supportStopLimitOrders && t.push(4), t)
                }
                _isOrderTypeSupported(e) {
                    return -1 !== this._supportedOrderTypes.indexOf(e)
                }
                _scheduleUpdateViewTotalVolume() {
                    this._viewTotalVolumeScheduled || (this._viewTotalVolumeScheduled = !0, window.requestAnimationFrame(() => this._updateViewTotalVolume()))
                }
                _updateViewTotalVolume() {
                    if (this._viewTotalVolumeScheduled = !1, this._symbolData) {
                        const e = this._data.totalVolumeBid(),
                            t = this._data.totalVolumeAsk(),
                            i = (0, c.ensureNotNull)(this._totalVolumeBidTextNode),
                            s = (0, c.ensureNotNull)(this._totalVolumeAskTextNode);
                        i.nodeValue = isFinite(e) ? this._data.formatVolume(e) : "-", s.nodeValue = isFinite(t) ? this._data.formatVolume(t) : "-"
                    }
                }
                _updateValueBuySellOrders() {
                    const e = this._data.buyOrdersValue(),
                        t = this._data.sellOrdersValue(),
                        i = this._data.buyInactiveOrdersValue(),
                        s = this._data.sellInactiveOrdersValue(),
                        o = this._data.buyOrdersQuantity(),
                        r = this._data.sellOrdersQuantity(),
                        n = (0, c.ensureNotNull)(this._countVolumeBid),
                        a = (0, c.ensureNotNull)(this._countVolumeAsk),
                        l = (0, c.ensureNotNull)(this._countVolumeBuyTextNode),
                        d = (0, c.ensureNotNull)(this._countVolumeSellTextNode);
                    0 !== e || 0 !== i ? (n.setAttribute("title", this._setFormattingTextForCountVolume(e, i, +o)), n.classList.add("apply-common-tooltip")) : (n.setAttribute("title", ""), n.classList.remove("apply-common-tooltip")), 0 !== t || 0 !== s ? (a.setAttribute("title", this._setFormattingTextForCountVolume(t, s, +r)), a.classList.add("apply-common-tooltip")) : (a.setAttribute("title", ""), a.classList.remove("apply-common-tooltip")), l.nodeValue = String(i > 0 ? e : e || ""), d.nodeValue = String(s > 0 ? t : t || "")
                }
                _setFormattingTextForCountVolume(e, t, i) {
                    const s = (0, n.t)("{countOrders} active order x {countQuantity}", {
                            plural: "{countOrders} active orders x {countQuantity}",
                            count: e
                        }).format({
                            countOrders: String(e),
                            countQuantity: String(i)
                        }),
                        o = (0, n.t)("{countInactiveOrders} inactive order", {
                            plural: "{countInactiveOrders} inactive orders",
                            count: t
                        }).format({
                            countInactiveOrders: String(t)
                        });
                    return s + (t > 0 ? ", " + o : "")
                }
            }
            var Te = i(79266),
                Oe = i(26909);
            const Le = (0,
                    n.t)("Show zero trade volume prices"),
                Be = (0, n.t)("Show prices between the best bid/ask"),
                Ne = (0, n.t)("You are seeing delayed data in the DOM. You need to get the data from your broker, if you want to see it real-time.");

            function Me(e) {
                const t = (0, j.useWatchedValueReadonly)({
                        watchedValue: e.symbol
                    }),
                    i = (0, j.useWatchedValueReadonly)({
                        watchedValue: e.delayedData
                    }),
                    s = (0, j.useWatchedValueReadonly)({
                        watchedValue: e.isBats
                    }),
                    [o, n] = (0, z.useWatchedValue)(e.domeSettings.zeroVolume),
                    [a, l] = (0, z.useWatchedValue)(e.domeSettings.spread),
                    d = r.createElement(r.Fragment, null, r.createElement(Te.PopupMenuItemToggle, {
                        label: Le,
                        isChecked: o,
                        onClick: () => n(!o)
                    }), r.createElement(Te.PopupMenuItemToggle, {
                        label: Be,
                        isChecked: a,
                        onClick: () => l(!a)
                    }));
                return r.createElement(Oe.Header, {
                    title: t.symbol,
                    description: t.exchange && ", " + t.exchange,
                    symbol: t.symbol,
                    settingsItems: d,
                    hasDelayedWarning: i,
                    hasCloseButton: !0,
                    close: e.closePanel,
                    delayedWarningMessage: Ne,
                    hasBatsQuotes: s
                })
            }
            var Ve = i(16933);
            class Ee {
                constructor(e, t, i) {
                    var s;
                    this._widget = null;
                    this._resizerBridge = t, this._height = this._resizerBridge.height, this._innerHeight = new(l()), this._widgetBody = new(l()), this._height.subscribe(e => {
                        this._innerHeight.setValue(Math.max(e - 42, 0))
                    }, {
                        callWithLast: !0
                    }), this._visible = new(l())(!1), this._close = () => {}, this._trading = e, this._qtySuggester = i, this._body = this._resizerBridge.container.value().querySelector(".trading-panel-content"), this._header = document.createElement("div"), this._container = document.createElement("div");
                    const o = h.linking.proSymbol.value(),
                        r = null === (s = this._trading.activeBroker()) || void 0 === s ? void 0 : s.metainfo().title;
                    this._symbol = new(l())({
                        symbol: o || "",
                        exchange: r || ""
                    });
                    const a = () => {
                            const e = this._trading.activeBroker();
                            let t;
                            if (e && 1 === e.connectionStatus() && !e.metainfo().configFlags.supportDOM) {
                                const e = document.querySelector(".tv-dome-panel__content");
                                if (null !== document.querySelector(".tv-dome-panel__disabled") || null === e) return;
                                const i = document.createElement("span");
                                return t = document.createElement("div"), i.classList.add("tv-dome-panel__disabled-warning"), i.innerText = (0, n.t)("The DOM window is currently unavailable for this broker"), t.classList.add("tv-dome-panel__disabled"), t.appendChild(i), void e.insertBefore(t, e.firstChild)
                            }
                            t = document.querySelector(".tv-dome-panel__disabled"), t && t.parentNode && t.parentNode.removeChild(t)
                        },
                        d = e => {
                            var t, i;
                            e ? (this._body.append(this._header), this._body.append(this._container)) : (null === (t = this._body.querySelector(".tv-dome-header")) || void 0 === t || t.remove(), null === (i = this._body.querySelector(".tv-dome-panel")) || void 0 === i || i.remove()), this._displayHeader(this._header, e)
                        };
                    this._trading.onConnectionStatusChange.subscribe(null, a), this._visible.subscribe(a), a(), this._visible.when(() => {
                        this._updateSymbol(h.linking.proSymbol.value()), this._resizerBridge.container.subscribe(e => {
                                this._body = e.querySelector(".trading-panel-content"), this._createLayout(), this._trading.onBrokerChange.subscribe(this, () => this._updateSymbol(h.linking.proSymbol.value())), h.linking.proSymbol.spawn().subscribe(e => this._updateSymbol(e)), a()
                            }, {
                                callWithLast: !0
                            }),
                            this._widget = new De(this._widgetBody, this._visible, this._trading, this._qtySuggester), this._visible.subscribe(d), this._displayHeader(this._header, !0)
                    })
                }
                setCloseHandler(e) {
                    this._close = e
                }
                setVisibility(e) {
                    this._visible.setValue(e)
                }
                _displayHeader(e, t) {
                    t && this._widget ? o.render(r.createElement(Me, {
                        symbol: this._symbol,
                        closePanel: this._close,
                        domeSettings: this._trading.showPricesWith(),
                        delayedData: this._widget.delayedData,
                        isBats: this._widget.isBats
                    }), e) : o.unmountComponentAtNode(e)
                }
                _createLayout() {
                    this._header.classList.add("tv-dome-header"), this._body.append(this._header), this._container.classList.add("tv-dome-panel");
                    const e = document.createElement("div");
                    return e.classList.add("tv-dome-panel__content", Ve.mainblock), this._container.append(e), this._container.addEventListener("contextmenu", e => {
                        e.target instanceof HTMLElement && e.target.matches("input, textarea") || e.preventDefault()
                    }), this._body.append(this._container), this._widgetBody.setValue(e), e
                }
                _updateSymbol(e) {
                    var t;
                    const i = e,
                        s = null === (t = this._trading.activeBroker()) || void 0 === t ? void 0 : t.metainfo().title;
                    this._symbol.setValue({
                        symbol: i || "",
                        exchange: s || ""
                    })
                }
            }
        },
        57947: (e, t, i) => {
            "use strict";
            i.d(t, {
                DurationControl: () => M
            });
            var s = i(25177),
                o = i(59496),
                r = i(1227),
                n = i(54936),
                a = i(72571),
                l = i(2691),
                d = i(85673),
                c = i(97496),
                h = i.n(c),
                u = i(28466),
                m = i(36118),
                _ = i(92063),
                p = i(34816),
                v = i(36376),
                g = i(50681),
                b = i(28599),
                y = i(50324),
                f = i(93173),
                w = i(37294),
                k = i(44807),
                x = i(8550),
                S = i(14793),
                P = i(67857);
            const C = (0, f.mergeThemes)(y.DEFAULT_INPUT_DATE_THEME, {
                    container: P.mobileDateInputContainer,
                    date: P.mobileDateInput,
                    icon: P.mobileDateInputIcon
                }),
                I = r.CheckMobile.any(),
                D = r.CheckMobile.iOS();

            function T(e) {
                return o.createElement(y.DateInput, {
                    theme: I ? C : void 0,
                    ...e
                })
            }
            class O extends o.PureComponent {
                constructor(e) {
                    super(e), this._todayMidnight = new Date((new Date).setHours(0, 0, 0, 0)), this._onSelect = () => {
                        this.props.onSelect(this.state.date, this.state.time)
                    }, this._onDateSelect = e => {
                        null !== e && this.setState({
                            date: e
                        }, this._handleMobileSelect)
                    }, this._onTimeSelect = e => {
                        const t = function(e) {
                            const [t, i] = e.split(":"), s = new Date;
                            return s.setHours(Number(t), Number(i)), s
                        }(e);
                        this.setState({
                            time: t
                        }, this._handleMobileSelect)
                    }, this._handleMobileSelect = () => {
                        I && !D && this._onSelect()
                    }, this._onKeyDown = e => {
                        e.stopPropagation()
                    }, this.state = {
                        date: this.props.initDateTime,
                        time: this.props.initDateTime
                    }
                }
                render() {
                    const e = o.createElement(S.DatePicker, {
                            minDate: this._todayMidnight,
                            initial: this.state.date,
                            InputComponent: T,
                            withCalendar: !1,
                            onPick: this._onDateSelect,
                            revertInvalidData: !0
                        }),
                        t = o.createElement(k.TimeInput, {
                            className: !I && P.timeInput,
                            value: (i = this.state.time, (0, x.twoDigitsFormat)(i.getHours()) + ":" + (0, x.twoDigitsFormat)(i.getMinutes())),
                            onChange: this._onTimeSelect
                        });
                    var i;
                    return I ? o.createElement("div", {
                        className: P.mobileDateTimeWrapper
                    }, this.props.durationMetaInfo.hasDatePicker && o.createElement("div", {
                        className: P.mobilePickerControl
                    }, o.createElement("span", {
                        className: P.title
                    }, (0, s.t)("Date")), e), this.props.durationMetaInfo.hasTimePicker && o.createElement("div", {
                        className: P.mobilePickerControl
                    }, o.createElement("span", {
                        className: P.title
                    }, (0,
                        s.t)("Time")), t)) : o.createElement("div", {
                        className: P.wrapper,
                        onKeyDown: this._onKeyDown
                    }, o.createElement("div", {
                        className: P.dateTimeWrapper
                    }, this.props.durationMetaInfo.hasDatePicker && e, this.props.durationMetaInfo.hasTimePicker && t), this.props.durationMetaInfo.hasDatePicker && o.createElement(w.Calendar, {
                        key: this.state.date.valueOf(),
                        selectedDate: this.state.date,
                        minDate: this._todayMidnight,
                        onSelect: this._onDateSelect,
                        popupStyle: !1
                    }), o.createElement("div", {
                        className: P.buttonWrapper
                    }, o.createElement(b.Button, {
                        className: P.button,
                        type: "submit",
                        size: "l",
                        onClick: this._onSelect
                    }, this._makeButtonText())))
                }
                _makeButtonText() {
                    const e = this.state.date.getFullYear(),
                        t = this.state.date.toLocaleString("default", {
                            month: "2-digit"
                        }),
                        i = this.state.date.toLocaleString("default", {
                            day: "2-digit"
                        }),
                        o = (0, v.formatTime)(this.state.time);
                    return (0, s.t)("Set {dateTime}").replace("{dateTime}", `${e}-${t}-${i} ${o}`)
                }
            }
            var L = i(93659),
                B = i(21279);
            const N = new(h());

            function M(e) {
                const {
                    currentDuration: t,
                    durationMetaInfoList: i,
                    onDurationChanged: c,
                    onClick: h
                } = e, _ = (0, g.findDurationMetaInfo)(i, t.type);
                if (void 0 === _) return null;
                const b = _.hasDatePicker || _.hasTimePicker,
                    y = r.CheckMobile.any(),
                    f = (0, o.useMemo)(() => void 0 !== t.datetime ? new Date(t.datetime) : ["GTT", "GTD"].includes(t.type) ? (0, g.makeDatePlus24UTCHours)() : new Date, [t.datetime, t.type]),
                    w = (0, o.useMemo)(() => (0, v.formatDateTime)(f, _), [f, _]),
                    k = (0, o.useMemo)(() => i.map(e => ({
                        content: e.name,
                        value: e.value
                    })), [i]),
                    x = k.length < 2,
                    S = o.createElement(O, {
                        durationMetaInfo: _,
                        initDateTime: f,
                        onSelect: function(t, i) {
                            const s = Date.UTC(t.getFullYear(), t.getMonth(), t.getDate(), i.getUTCHours(), i.getUTCMinutes());
                            e.onDurationChanged({
                                type: e.currentDuration.type,
                                datetime: s
                            }), M()
                        }
                    }),
                    P = o.createElement(m.Select, {
                        onClick: h,
                        className: L.select,
                        menuClassName: L.selectMenu,
                        value: _.value,
                        items: k,
                        "data-name": "duration-type-selector",
                        disabled: x,
                        hideArrowButton: x,
                        onChange: T,
                        stretch: !0,
                        matchButtonAndListboxWidths: !0
                    }),
                    [C, I] = (0, o.useState)(!1),
                    D = o.createElement(n.Input, {
                        className: C && !y ? L.focused : null,
                        inputClassName: L.dateTimePickerInput,
                        value: w,
                        "data-name": "duration-datetime-selector",
                        stretch: !0,
                        readonly: !0,
                        intent: C && !y ? "primary" : "default",
                        noReadonlyStyles: !0,
                        endSlot: o.createElement(l.EndSlot, {
                            icon: !0,
                            interactive: !1
                        }, o.createElement(a.Icon, {
                            icon: B,
                            className: L.icon
                        }))
                    });
                return o.createElement("div", {
                    className: L.wrapper
                }, o.createElement("span", {
                    className: L.title
                }, (0, s.t)("Time in Force")), y ? o.createElement(p.ToolWidgetMenu, {
                    className: L.menuButton,
                    content: P,
                    arrow: !1,
                    children: o.createElement(V, {
                        menuItems: k,
                        onTypeSelect: T
                    }),
                    isDrawer: !0,
                    isDisabled: x,
                    closeOnClickOutside: !0
                }) : P, b && (y ? S : o.createElement(u.CloseDelegateContext.Provider, {
                    value: N
                }, o.createElement(p.ToolWidgetMenu, {
                    className: L.dateTimePickerWrapper,
                    content: D,
                    arrow: !1,
                    closeOnClickOutside: !0,
                    verticalDropDirection: d.VerticalDropDirection.FromBottomToTop,
                    horizontalDropDirection: d.HorizontalDropDirection.FromRightToLeft,
                    horizontalAttachEdge: d.HorizontalAttachEdge.Right,
                    verticalAttachEdge: d.VerticalAttachEdge.Top,
                    onOpen: function() {
                        I(!0)
                    },
                    onClose: function() {
                        I(!1)
                    }
                }, S))));

                function T(e) {
                    const s = {
                            type: e
                        },
                        o = (0,
                            g.findDurationMetaInfo)(i, e);
                    void 0 !== o && (o.hasDatePicker || o.hasTimePicker) && (s.datetime = t.datetime || (0, v.getTimestamp)((0, g.makeDatePlus24UTCHours)())), c(s), M()
                }

                function M() {
                    void 0 !== e.onClose && e.onClose(), N.fire()
                }
            }

            function V(e) {
                const {
                    menuItems: t,
                    onTypeSelect: i
                } = e;
                return o.createElement(o.Fragment, null, Object.values(t).map(e => {
                    var t;
                    return o.createElement(_.PopupMenuItem, {
                        key: e.value,
                        label: null !== (t = e.content) && void 0 !== t ? t : e.value,
                        onClick: i,
                        onClickArg: e.value
                    })
                }))
            }
        },
        63111: (e, t, i) => {
            "use strict";
            i.d(t, {
                OrderPanelStatus: () => s,
                OrderPlacingStatus: () => o,
                OrderEditorDisplayMode: () => r,
                PriceType: () => n,
                BracketDefaultPips: () => a,
                BracketSubControlType: () => l,
                QuantitySubControlType: () => d,
                PriceSubControlType: () => c,
                CalculatorDecKeyCodes: () => h,
                CalculatorIncKeyCodes: () => u,
                Context: () => p,
                orderTypes: () => v
            });
            var s, o, r, n, a, l, d, c, h, u, m = i(59496),
                _ = i(25177);
            ! function(e) {
                e[e.Wait = 0] = "Wait", e[e.Active = 1] = "Active", e[e.Editing = 2] = "Editing", e[e.Preview = 3] = "Preview"
            }(s || (s = {})),
            function(e) {
                e[e.Creating = 0] = "Creating", e[e.Placed = 1] = "Placed"
            }(o || (o = {})),
            function(e) {
                e.Popup = "popup", e.Panel = "panel"
            }(r || (r = {})),
            function(e) {
                e[e.Stop = 0] = "Stop", e[e.Limit = 1] = "Limit"
            }(n || (n = {})),
            function(e) {
                e[e.TakeProfit = 75] = "TakeProfit", e[e.StopLoss = 25] = "StopLoss"
            }(a || (a = {})),
            function(e) {
                e.Price = "Price", e.Pips = "Pips", e.Money = "Money", e.Percent = "Percent"
            }(l || (l = {})),
            function(e) {
                e.Units = "Units", e.RiskInCurrency = "RiskInCurrency", e.RiskInPercent = "RiskInPercent", e.BaseCurrency = "BaseCurrency", e.QuoteCurrency = "QuoteCurrency"
            }(d || (d = {})),
            function(e) {
                e.Absolute = "Absolute", e.Relative = "Relative"
            }(c || (c = {})),
            function(e) {
                e[e.Minus = 189] = "Minus", e[e.NumMinus = 109] = "NumMinus", e[e.FirefoxMinus = 173] = "FirefoxMinus"
            }(h || (h = {})),
            function(e) {
                e[e.Plus = 187] = "Plus", e[e.NumPlus = 107] = "NumPlus", e[e.FirefoxPlus = 61] = "FirefoxPlus"
            }(u || (u = {}));
            const p = m.createContext({
                    resizerWidth: null,
                    mode: r.Panel,
                    supportTrailingStop: !1
                }),
                v = {
                    1: (0, _.t)("Limit"),
                    2: (0, _.t)("Market"),
                    3: (0, _.t)("Stop"),
                    4: (0, _.t)("Stop Limit")
                }
        },
        12334: (e, t, i) => {
            "use strict";
            i.d(t, {
                TradingLayoutBreakpoint: () => o
            });
            var s = i(82515);
            const o = {
                Mobile: s.mobile
            }
        },
        32207: (e, t, i) => {
            "use strict";
            i.d(t, {
                SplitThousandsFormatter: () => r
            });
            var s = i(72249),
                o = i(34581);
            class r {
                constructor(e = " ") {
                    this._divider = e
                }
                format(e) {
                    const t = (0, s.splitThousands)(e, this._divider);
                    return (0, o.isRtl)() ? (0, o.startWithLTR)(t) : t
                }
                parse(e) {
                    const t = (0, o.stripLTRMarks)(e).split(this._divider).join(""),
                        i = Number(t);
                    return isNaN(i) || /e/i.test(t) ? {
                        res: !1
                    } : {
                        res: !0,
                        value: i,
                        suggest: this.format(i)
                    }
                }
            }
        },
        81436: (e, t, i) => {
            "use strict";
            i.d(t, {
                getPixelsFromEvent: () => o
            });
            const s = [() => navigator.userAgent.includes("Win") && navigator.userAgent.includes("Chrome") ? 1 / window.devicePixelRatio : 1, () => 16, (e = (() => 0)) => {
                var t;
                return .8 * (null !== (t = e()) && void 0 !== t ? t : 0)
            }];

            function o(e, t = (() => ({}))) {
                return {
                    x: e.deltaX * s[e.deltaMode](() => t().width),
                    y: e.deltaY * s[e.deltaMode](() => t().height)
                }
            }
        },
        62410: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentcolor" stroke-linecap="round" d="M4 7l5 4 5-4"/></svg>'
        },
        23799: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentcolor" stroke-linecap="round" d="M4 11l5-4 5 4"/></svg>'
        },
        54071: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 9" width="9" height="9"><path stroke="currentcolor" stroke-width="1.2" d="M1 1l7 7m0-7L1 8"/></svg>'
        },
        59243: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 17" width="16" height="17" fill="none"><rect width="15" height="9" stroke="currentcolor" rx="2.5" x=".5" y="7.5"/><circle stroke="currentcolor" cx="8" cy="12" r=".5"/><path stroke="currentcolor" d="M3.5 7c0 .28.22.5.5.5h8a.5.5 0 0 0 .5-.5V5a4.5 4.5 0 1 0-9 0v2z"/></svg>'
        },
        34868: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 17" width="16" height="17" fill="none"><path fill="currentcolor" fill-rule="evenodd" clip-rule="evenodd" d="M4 5v2h9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a5 5 0 0 1 8.66-3.4l-.74.66A3.99 3.99 0 0 0 4 5z"/><rect width="15" height="9" stroke="currentcolor" rx="2.5" x=".5" y="7.5"/><circle stroke="currentcolor" cx="8" cy="12" r=".5"/></svg>'
        },
        37885: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 7" width="12" height="7"><path d="M1 0a1 1 0 0 0-1 1c0 .276.1.538.28.72l5 5c.182.18.444.28.72.28.276 0 .538-.1.72-.28l5-5c.18-.182.28-.444.28-.72a1 1 0 0 0-1-1c-.276 0-.538.1-.72.28L6 4.563 1.72.282C1.537.1 1.275 0 1 0z"/></svg>'
        },
        39022: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 7" width="12" height="7"><path d="M1 7a1 1 0 0 1-1-1c0-.276.1-.538.28-.72l5-5C5.463.1 5.725 0 6 0c.276 0 .538.1.72.28l5 5c.18.182.28.444.28.72a1 1 0 0 1-1 1c-.276 0-.538-.1-.72-.28L6 2.437l-4.28 4.28C1.537 6.9 1.275 7 1 7z"/></svg>'
        },
        59094: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 9" width="9px" height="9px"><path d="M2 1L1 2l2.5 2.5L1 7l1 1 2.5-2.5L7 8l1-1-2.5-2.5L8 2 7 1 4.5 3.5z"/></svg>'
        }
    }
]);
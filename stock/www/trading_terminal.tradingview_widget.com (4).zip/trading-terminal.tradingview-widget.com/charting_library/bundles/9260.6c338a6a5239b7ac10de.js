(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [9260], {
        6539: e => {
            e.exports = {
                button: "button-YKkCvwjV",
                content: "content-YKkCvwjV",
                "icon-only": "icon-only-YKkCvwjV",
                "color-brand": "color-brand-YKkCvwjV",
                "variant-primary": "variant-primary-YKkCvwjV",
                "variant-secondary": "variant-secondary-YKkCvwjV",
                "color-gray": "color-gray-YKkCvwjV",
                "color-green": "color-green-YKkCvwjV",
                "color-red": "color-red-YKkCvwjV",
                "size-xsmall": "size-xsmall-YKkCvwjV",
                "size-small": "size-small-YKkCvwjV",
                "size-medium": "size-medium-YKkCvwjV",
                "size-large": "size-large-YKkCvwjV",
                "size-xlarge": "size-xlarge-YKkCvwjV",
                "with-start-icon": "with-start-icon-YKkCvwjV",
                "with-end-icon": "with-end-icon-YKkCvwjV",
                "start-icon-wrap": "start-icon-wrap-YKkCvwjV",
                "end-icon-wrap": "end-icon-wrap-YKkCvwjV",
                animated: "animated-YKkCvwjV",
                stretch: "stretch-YKkCvwjV",
                grouped: "grouped-YKkCvwjV",
                "adjust-position": "adjust-position-YKkCvwjV",
                "first-row": "first-row-YKkCvwjV",
                "first-col": "first-col-YKkCvwjV",
                "no-corner-top-left": "no-corner-top-left-YKkCvwjV",
                "no-corner-top-right": "no-corner-top-right-YKkCvwjV",
                "no-corner-bottom-right": "no-corner-bottom-right-YKkCvwjV",
                "no-corner-bottom-left": "no-corner-bottom-left-YKkCvwjV"
            }
        },
        88722: e => {
            e.exports = {
                wrap: "wrap-TyQYOCnx",
                input: "input-TyQYOCnx"
            }
        },
        24451: e => {
            e.exports = {
                icon: "icon-P882WPW5"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        28599: (e, t, n) => {
            "use strict";
            n.d(t, {
                Button: () => b
            });
            var o = n(59496),
                r = n(97754),
                s = n(31774),
                l = n(72571),
                i = n(6539),
                c = n.n(i);

            function a(e) {
                const {
                    color: t = "brand",
                    size: n = "medium",
                    variant: o = "primary",
                    stretch: l = !1,
                    icon: i,
                    startIcon: a,
                    endIcon: u,
                    iconOnly: d = !1,
                    className: h,
                    isGrouped: f,
                    cellState: p,
                    disablePositionAdjustment: m = !1
                } = e, v = function(e) {
                    let t = "";
                    return 0 !== e && (1 & e && (t = r(t, c()["no-corner-top-left"])), 2 & e && (t = r(t, c()["no-corner-top-right"])), 4 & e && (t = r(t, c()["no-corner-bottom-right"])), 8 & e && (t = r(t, c()["no-corner-bottom-left"]))), t
                }((0, s.getGroupCellRemoveRoundBorders)(p));
                return r(h, c().button, c()["size-" + n], c()["color-" + t], c()["variant-" + o], l && c().stretch, (i || a) && c()["with-start-icon"], u && c()["with-end-icon"], d && c()["icon-only"], v, f && c().grouped, f && !m && c()["adjust-position"], f && p.isTop && c()["first-row"], f && p.isLeft && c()["first-col"])
            }

            function u(e) {
                const {
                    size: t,
                    startIcon: n,
                    icon: r,
                    iconOnly: s,
                    children: i,
                    endIcon: a
                } = e, u = null != n ? n : r;
                return o.createElement(o.Fragment, null, u && "xsmall" !== t && o.createElement(l.Icon, {
                    icon: u,
                    className: c()["start-icon-wrap"]
                }), i && o.createElement("span", {
                    className: c().content
                }, i), a && !s && "xsmall" !== t && o.createElement(l.Icon, {
                    icon: a,
                    className: c()["end-icon-wrap"]
                }))
            }
            var d = n(80327),
                h = n(417);

            function f(e) {
                const {
                    className: t,
                    color: n,
                    variant: o,
                    size: r,
                    stretch: s,
                    animated: l,
                    icon: i,
                    iconOnly: c,
                    startIcon: a,
                    endIcon: u,
                    ...d
                } = e;
                return { ...d,
                    ...(0, h.filterDataProps)(e),
                    ...(0, h.filterAriaProps)(e)
                }
            }

            function p(e) {
                const {
                    reference: t,
                    ...n
                } = e, {
                    isGrouped: r,
                    cellState: s,
                    disablePositionAdjustment: l
                } = (0, o.useContext)(d.ControlGroupContext), i = a({ ...n,
                    isGrouped: r,
                    cellState: s,
                    disablePositionAdjustment: l
                });
                return o.createElement("button", { ...f(n),
                    className: i,
                    ref: t
                }, o.createElement(u, { ...n
                }))
            }

            function m(e = "default") {
                switch (e) {
                    case "default":
                        return "primary";
                    case "stroke":
                        return "secondary"
                }
            }

            function v(e = "primary") {
                switch (e) {
                    case "primary":
                        return "brand";
                    case "success":
                        return "green";
                    case "default":
                        return "gray";
                    case "danger":
                        return "red"
                }
            }

            function g(e = "m") {
                switch (e) {
                    case "s":
                        return "xsmall";
                    case "m":
                        return "small";
                    case "l":
                        return "large"
                }
            }

            function C(e) {
                const {
                    intent: t,
                    size: n,
                    appearance: o,
                    useFullWidth: r,
                    icon: s,
                    ...l
                } = e;
                return { ...l,
                    color: v(t),
                    size: g(n),
                    variant: m(o),
                    stretch: r,
                    startIcon: s
                }
            }

            function b(e) {
                return o.createElement(p, { ...C(e)
                })
            }
        },
        44807: (e, t, n) => {
            "use strict";
            n.d(t, {
                TimeInput: () => V
            });
            var o = n(1227),
                r = n(59496),
                s = n(97754),
                l = n.n(s),
                i = n(88537),
                c = n(69842),
                a = n(2691),
                u = n(54936),
                d = n(72571),
                h = n(24451),
                f = n(76427);

            function p(e) {
                return r.createElement(d.Icon, {
                    className: h.icon,
                    icon: f
                })
            }
            var m = n(83836),
                v = n(88722);
            var g = n(61174),
                C = n(97280);
            const b = {
                0: {
                    pattern: /\d/
                },
                9: {
                    pattern: /\d/,
                    optional: !0
                },
                "#": {
                    pattern: /\d/,
                    recursive: !0
                },
                A: {
                    pattern: /[a-zA-Z0-9]/
                },
                S: {
                    pattern: /[a-zA-Z]/
                }
            };

            function w(e, t, n) {
                const o = [],
                    r = n;
                let s = 0,
                    l = 0;
                const i = e.length,
                    c = r.length;
                let a = -1,
                    u = 0;
                const d = [],
                    h = i - 1,
                    f = [];
                let p;
                for (; s < i && l < c;) {
                    const n = e.charAt(s),
                        i = r.charAt(l),
                        c = b[n];
                    c ? (i.match(c.pattern) ? (o.push(i), c.recursive && (-1 === a ? a = s : s === h && s !== a && (s = a - 1), h === a && (s -= 1)), s += 1) : i === p ? (u--, p = void 0) : c.optional ? (s += 1, l -= 1) : c.fallback ? (o.push(c.fallback), s += 1, l -= 1) : f.push({
                        p: l,
                        v: i,
                        e: c.pattern
                    }), l += 1) : (t || o.push(n), i === n ? (d.push(l), l += 1) : (p = n, d.push(l + u), u++), s += 1)
                }
                const m = e.charAt(h);
                i !== c + 1 || b[m] || o.push(m);
                const v = o.join("");
                return [v, function(e, t) {
                    const n = {};
                    for (let e = 0; e < t.length; e++) n[t[e] + 0] = 1;
                    return n
                }(0, d), f]
            }

            function E(e, t, n) {
                const o = function(e) {
                        let t = !0;
                        for (let n = 0; n < e.length; n++) {
                            const o = b[e.charAt(n)];
                            if (o && o.recursive) {
                                t = !1;
                                break
                            }
                        }
                        return t ? e.length : void 0
                    }(e),
                    [s, l] = w(e, !1, t),
                    [c, a] = (0, r.useState)(s),
                    [u, d] = (0, r.useState)(0),
                    [h, f] = (0, r.useState)(!1),
                    p = (0, r.useRef)(l),
                    m = (0, r.useRef)(c);
                return (0, r.useEffect)(() => {
                    const [n, o] = w(e, !1, t);
                    a(n), v(o)
                }, [t, e]), (0, r.useLayoutEffect)(() => {
                    const e = (0, i.ensureNotNull)(n.current);
                    h && (e.setSelectionRange(u, u), f(!1)), d(y(e))
                }, [h]), [t, m, {
                    onChange: function() {
                        const t = (0, i.ensureNotNull)(n.current),
                            o = t.value,
                            [r, s] = w(e, !1, o);
                        a(r), m.current = r;
                        const l = v(s),
                            h = function(e, t, n, o, r, s) {
                                if (e !== t) {
                                    const l = t.length,
                                        i = e.length;
                                    let c = 0,
                                        a = 0,
                                        u = 0,
                                        d = 0,
                                        h = 0;
                                    for (h = o; h < l && r[h]; h++) a++;
                                    for (h = o - 1; h >= 0 && r[h]; h--) c++;
                                    for (h = o - 1; h >= 0; h--) r[h] && u++;
                                    for (h = n - 1; h >= 0; h--) s[h] && d++;
                                    if (o > i) o = 10 * l;
                                    else if (n >= o && n !== i) {
                                        if (s[o]) {
                                            const e = o;
                                            o -= d - u, r[o -= c] && (o = e)
                                        }
                                    } else o > n && (o += u - d, o += a)
                                }
                                return o
                            }(c, r, u, y(t), s, l);
                        d(h), f(!0)
                    },
                    onSelect: function() {
                        const e = (0, i.ensureNotNull)(n.current);
                        d(y(e))
                    },
                    maxLength: o
                }];

                function v(e) {
                    const t = p.current;
                    return p.current = e, t
                }
            }

            function y(e) {
                return e.selectionStart || 0
            }

            function _(e) {
                const {
                    value: t,
                    mask: n,
                    onChange: o,
                    ...s
                } = e, l = (0, r.useRef)(null), [i, c, a] = E(n, t, l);
                return (0, r.useLayoutEffect)(() => {
                    void 0 !== e.reference && (e.reference.current = l.current)
                }, [e.reference]), r.createElement(u.InputControl, { ...s,
                    maxLength: a.maxLength,
                    value: i,
                    autoComplete: "off",
                    reference: function(e) {
                        l.current = e
                    },
                    onChange: function() {
                        a.onChange(), o(c.current)
                    },
                    onSelect: a.onSelect
                })
            }
            var S = n(80185),
                k = n(44377),
                M = n(92063),
                x = n(42894);
            const N = (() => {
                const e = [];
                for (let t = 0; t < 24; ++t)
                    for (let n = 0; n < 60; n += 15) {
                        const [o, r] = [T(t.toString()), T(n.toString())], s = `${o}:${r}`, l = j(s) ? s : P(s);
                        e.push(l)
                    }
                return e
            })();

            function O(e) {
                let t = !1;
                const n = (0, r.useRef)(null),
                    o = (0, r.useRef)(null),
                    s = (0, r.useRef)(null),
                    c = (0, r.useRef)(null),
                    [u, d] = (0, m.useFocus)(),
                    [h, f] = (0, r.useState)(e.value),
                    v = R(h),
                    b = j(v) ? v : P(v),
                    [w, E] = (0, r.useState)(b),
                    y = u || z().some(e => null !== e && e.contains(document.activeElement));
                (0, r.useLayoutEffect)(() => f(e.value), [e.value]), (0, r.useLayoutEffect)(() => E(b), [h, y]), (0, r.useEffect)(() => I(w === b ? "auto" : "smooth"), [w]);
                const O = (0, x.lowerbound)(N, b, (e, t) => e < t);
                let T = N;
                N[O] !== b && (T = [...N], T.splice(O, 0, b));
                const K = (0, g.useOutsideEvent)({
                    mouseDown: !0,
                    touchStart: !0,
                    handler: function(e) {
                        null !== o.current && y && e.target instanceof Node && null !== s.current && !s.current.contains(e.target) && o.current.blur()
                    }
                });
                return r.createElement("div", {
                    className: l()(e.className),
                    onKeyDown: function(e) {
                        if (e.defaultPrevented) return;
                        const t = (0, S.hashFromEvent)(e.nativeEvent);
                        if (38 === t) {
                            e.preventDefault();
                            const t = (T.indexOf(w) + T.length - 1) % T.length;
                            E(T[t])
                        }
                        if (40 === t) {
                            e.preventDefault();
                            const t = (T.indexOf(w) + T.length + 1) % T.length;
                            E(T[t])
                        }
                    },
                    onFocus: function(e) {
                        Y(e) || d.onFocus(e)
                    },
                    onBlur: function(e) {
                        Y(e) || d.onBlur(e)
                    },
                    ref: K
                }, r.createElement(_, {
                    disabled: e.disabled,
                    name: e.name,
                    endSlot: r.createElement(a.EndSlot, {
                        icon: !0
                    }, r.createElement(p, null)),
                    reference: o,
                    containerReference: n,
                    mask: "09:00",
                    value: h,
                    onFocus: function(e) {
                        setTimeout(H, 0)
                    },
                    onBlur: function(e) {
                        Y(e) || V(h)
                    },
                    onChange: function(t) {
                        f(t), e.onInput && e.onInput(t)
                    },
                    onKeyDown: function(e) {
                        if (e.defaultPrevented) return;
                        const t = (0, S.hashFromEvent)(e.nativeEvent);
                        13 === t && (e.preventDefault(), V(w), (0, i.ensureNotNull)(o.current).blur());
                        27 === t && (e.preventDefault(), (0, i.ensureNotNull)(o.current).blur())
                    }
                }), r.createElement(k.PopupMenu, {
                    onOpen: function() {
                        I()
                    },
                    onClose: function() {},
                    position: function() {
                        const e = (0, i.ensureNotNull)(n.current).getBoundingClientRect(),
                            t = window.innerHeight - e.bottom,
                            o = e.top;
                        let r = 231,
                            s = e.bottom;
                        if (r > o && r > t) {
                            const n = (0, C.clamp)(r, 0, o),
                                l = (0, C.clamp)(r, 0, t);
                            r = Math.max(n, l), s = n > l ? e.top - n : e.bottom
                        } else r > t && (s = e.top - r);
                        return {
                            x: e.left,
                            y: s,
                            overrideWidth: e.width,
                            overrideHeight: r
                        }
                    },
                    closeOnClickOutside: !1,
                    isOpened: y,
                    tabIndex: -1,
                    reference: s
                }, T.map(e => r.createElement(M.PopupMenuItem, {
                    key: e,
                    label: e,
                    isActive: e === b,
                    isHovered: e === w,
                    reference: e === w ? W : void 0,
                    onClick: F,
                    onClickArg: e
                }))));

                function V(n) {
                    const o = R(n),
                        r = j(o) ? o : P(o);
                    f(r), t || (t = !0, e.onChange(r))
                }

                function W(e) {
                    c.current = e
                }

                function F(e) {
                    V((0, i.ensureDefined)(e)), (0, i.ensureNotNull)(s.current).blur()
                }

                function Y(e) {
                    return u && (null !== D(document.activeElement) || null !== D(e.relatedTarget))
                }

                function D(e) {
                    return e instanceof Node && z().find(t => null !== t && t.contains(e)) || null
                }

                function z() {
                    return [s.current, o.current]
                }

                function I(e = "auto") {
                    if (null !== c.current) {
                        const t = (0, i.ensureNotNull)(s.current).getBoundingClientRect(),
                            n = c.current.getBoundingClientRect();
                        (t.top > n.top || t.bottom < n.bottom) && c.current.scrollIntoView({
                            behavior: e
                        })
                    }
                }

                function H() {
                    const e = o.current;
                    if (null !== e) {
                        const t = e.value || "";
                        e.setSelectionRange(0, t.length)
                    }
                }
            }

            function R(e) {
                const [t = "", n = ""] = e.split(":"), [o, r] = [T(t), K(n)];
                return `${o}:${r}`
            }

            function j(e) {
                return /^(0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/g.test(e)
            }

            function P(e) {
                const [t, n] = e.split(":"), [o, r] = [(0, C.clamp)(parseInt(t), 0, 23), (0, C.clamp)(parseInt(n), 0, 59)], [s, l] = [T(o.toString()), K(r.toString())];
                return `${s}:${l}`
            }

            function T(e) {
                return e.slice(0, 2).padStart(2, "0")
            }

            function K(e) {
                return e.slice(0, 2).padEnd(2, "0")
            }
            const V = o.CheckMobile.any() ? function(e) {
                const {
                    onChange: t,
                    onFocus: n,
                    value: o,
                    className: s,
                    ...d
                } = e, h = (0, r.useRef)(null), [f, g] = (0, m.useFocus)(), C = (0, c.createSafeMulticastEventHandler)(g.onBlur, (function() {
                    h.current && o && (h.current.defaultValue = o)
                }));
                return (0, r.useLayoutEffect)(() => {
                    h.current && o && (h.current.defaultValue = o)
                }, []), (0, r.useLayoutEffect)(() => {
                    h.current && o && (h.current.value = o)
                }, [o]), r.createElement("div", {
                    className: l()(v.wrap, s)
                }, r.createElement(u.InputControl, { ...d,
                    type: "text",
                    endSlot: r.createElement(a.EndSlot, {
                        icon: !0
                    }, r.createElement(p, null)),
                    value: o,
                    highlight: f,
                    intent: f ? "primary" : void 0,
                    onFocus: function(e) {
                        (0, i.ensureNotNull)(h.current).focus(), n && n(e)
                    },
                    onChange: function() {}
                }), r.createElement("input", { ...g,
                    disabled: e.disabled,
                    className: v.input,
                    type: "time",
                    onBlur: C,
                    onChange: function(e) {
                        const {
                            value: n
                        } = e.currentTarget;
                        t && n && t(n)
                    },
                    ref: h
                }))
            } : O
        },
        30553: (e, t, n) => {
            "use strict";
            n.d(t, {
                MenuContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        10618: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_MENU_THEME: () => v,
                Menu: () => g
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                l = n(88537),
                i = n(97280),
                c = n(12777),
                a = n(53327),
                u = n(70981),
                d = n(63212),
                h = n(82027),
                f = n(94488),
                p = n(30553),
                m = n(16059);
            const v = m;
            class g extends o.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new d.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                        this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                    }, this._handleScrollWrapRef = e => {
                        this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                    }, this._handleMeasure = ({
                        callback: e,
                        forceRecalcPosition: t
                    } = {}) => {
                        var n, o, r, s;
                        if (this.state.isMeasureValid && !t) return;
                        const {
                            position: c
                        } = this.props, a = (0, l.ensureNotNull)(this._containerRef);
                        let u = a.getBoundingClientRect();
                        const d = document.documentElement.clientHeight,
                            h = document.documentElement.clientWidth,
                            f = null !== (n = this.props.closeOnScrollOutsideOffset) && void 0 !== n ? n : 0;
                        let p = d - 0 - f;
                        const m = u.height > p;
                        if (m) {
                            (0, l.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", u = a.getBoundingClientRect()
                        }
                        const {
                            width: v,
                            height: g
                        } = u, C = "function" == typeof c ? c(v, g, d) : c, b = h - (null !== (o = C.overrideWidth) && void 0 !== o ? o : v) - 0, w = (0, i.clamp)(C.x, 0, Math.max(0, b)), E = 0 + f, y = d - (null !== (r = C.overrideHeight) && void 0 !== r ? r : g) - 0;
                        let _ = (0, i.clamp)(C.y, E, Math.max(E, y));
                        if (C.forbidCorrectYCoord && _ < C.y && (p -= C.y - _, _ = C.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && C.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                        const S = null !== (s = C.overrideHeight) && void 0 !== s ? s : m ? p : void 0;
                        this.setState({
                            appearingMenuHeight: t ? this.state.appearingMenuHeight : S,
                            appearingMenuWidth: t ? this.state.appearingMenuWidth : C.overrideWidth,
                            appearingPosition: {
                                x: w,
                                y: _
                            },
                            isMeasureValid: !0
                        }, () => {
                            this._restoreScrollPosition(), e && e()
                        })
                    }, this._restoreScrollPosition = () => {
                        const e = document.activeElement,
                            t = (0, l.ensureNotNull)(this._containerRef);
                        if (null !== e && t.contains(e)) try {
                            e.scrollIntoView()
                        } catch (e) {} else(0, l.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                    }, this._resizeForced = () => {
                        this.setState({
                            appearingMenuHeight: void 0,
                            appearingMenuWidth: void 0,
                            appearingPosition: void 0,
                            isMeasureValid: void 0
                        })
                    }, this._resize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            }), this._raf = null
                        }))
                    }, this._handleGlobalClose = e => {
                        this.props.onClose(e)
                    }, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }, this._handleScroll = () => {
                        this._scroll = (0, l.ensureNotNull)(this._scrollWrapRef).scrollTop
                    }, this._handleScrollOutsideEnd = () => {
                        clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            })
                        }, 80)
                    }, this._handleScrollOutside = e => {
                        e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            }), this._scrollRaf = null
                        })))
                    }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = h.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(),
                        this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        children: l,
                        minWidth: i,
                        theme: u = m,
                        className: d,
                        maxHeight: h,
                        onMouseOver: v,
                        onMouseOut: g,
                        onKeyDown: b,
                        onFocus: w,
                        onBlur: E
                    } = this.props, {
                        appearingMenuHeight: y,
                        appearingMenuWidth: _,
                        appearingPosition: S,
                        isMeasureValid: k
                    } = this.state;
                    return o.createElement(p.MenuContext.Provider, {
                        value: this
                    }, o.createElement(f.SubmenuHandler, null, o.createElement(a.SlotContext.Provider, {
                        value: this._manager
                    }, o.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        className: s()(d, u.menuWrap, !k && u.isMeasuring),
                        style: {
                            height: y,
                            left: S && S.x,
                            minWidth: i,
                            position: "fixed",
                            top: S && S.y,
                            width: _
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: c.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: v,
                        onMouseOut: g,
                        onKeyDown: b,
                        onFocus: w,
                        onBlur: E
                    }, o.createElement("div", {
                        className: s()(u.scrollWrap, !this.props.noMomentumBasedScroll && u.momentumBased),
                        style: {
                            overflowY: void 0 !== y ? "scroll" : "auto",
                            maxHeight: h
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, o.createElement(C, {
                        className: u.menuBox
                    }, l)))), o.createElement(a.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function C(e) {
                const t = (0, l.ensureNotNull)((0, o.useContext)(f.SubmenuContext)),
                    n = o.useRef(null);
                return o.createElement("div", {
                    ref: n,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (o = e.target, null === (r = n.current) || void 0 === r ? void 0 : r.contains(o)))) return;
                        var o, r;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            g.contextType = f.SubmenuContext
        },
        92063: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => a,
                PopupMenuItem: () => h
            });
            var o = n(59496),
                r = n(97754),
                s = n(70981),
                l = n(32133),
                i = n(417),
                c = n(23576);
            const a = c;

            function u(e) {
                const {
                    reference: t,
                    ...n
                } = e, r = { ...n,
                    ref: t
                };
                return o.createElement(e.href ? "a" : "div", r)
            }

            function d(e) {
                e.stopPropagation()
            }

            function h(e) {
                const {
                    id: t,
                    role: n,
                    "aria-selected": a,
                    className: h,
                    title: f,
                    labelRowClassName: p,
                    labelClassName: m,
                    shortcut: v,
                    forceShowShortcuts: g,
                    icon: C,
                    isActive: b,
                    isDisabled: w,
                    isHovered: E,
                    appearAsDisabled: y,
                    label: _,
                    link: S,
                    showToolboxOnHover: k,
                    target: M,
                    rel: x,
                    toolbox: N,
                    reference: O,
                    onMouseOut: R,
                    onMouseOver: j,
                    suppressToolboxClick: P = !0,
                    theme: T = c
                } = e, K = (0, i.filterDataProps)(e), V = (0, o.useRef)(null);
                return o.createElement(u, { ...K,
                    id: t,
                    role: n,
                    "aria-selected": a,
                    className: r(h, T.item, C && T.withIcon, {
                        [T.isActive]: b,
                        [T.isDisabled]: w || y,
                        [T.hovered]: E
                    }),
                    title: f,
                    href: S,
                    target: M,
                    rel: x,
                    reference: function(e) {
                        V.current = e, "function" == typeof O && O(e);
                        "object" == typeof O && (O.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: n,
                            onClick: o,
                            onClickArg: r,
                            trackEventObject: i
                        } = e;
                        if (w) return;
                        i && (0, l.trackEvent)(i.category, i.event, i.label);
                        o && o(r, t);
                        n || (0, s.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: n,
                            trackRightClick: o
                        } = e;
                        n && o && (0, l.trackEvent)(n.category, n.event, n.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: n,
                            trackMouseWheelClick: o
                        } = e;
                        if (1 === t.button && S && n) {
                            let e = n.label;
                            o && (e += "_mouseWheelClick"), (0, l.trackEvent)(n.category, n.event, e)
                        }
                    },
                    onMouseOver: j,
                    onMouseOut: R
                }, void 0 !== C && o.createElement("div", {
                    className: T.icon,
                    dangerouslySetInnerHTML: {
                        __html: C
                    }
                }), o.createElement("div", {
                    className: r(T.labelRow, p)
                }, o.createElement("div", {
                    className: r(T.label, m)
                }, _)), (void 0 !== v || g) && o.createElement("div", {
                    className: T.shortcut
                }, (W = v) && W.split("+").join(" + ")), void 0 !== N && o.createElement("div", {
                    onClick: P ? d : void 0,
                    className: r(T.toolbox, {
                        [T.showOnHover]: k
                    })
                }, N));
                var W
            }
        },
        28466: (e, t, n) => {
            "use strict";
            n.d(t, {
                CloseDelegateContext: () => s
            });
            var o = n(59496),
                r = n(70981);
            const s = o.createContext(r.globalCloseDelegate)
        },
        44377: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenu: () => a
            });
            var o = n(59496),
                r = n(87995),
                s = n(8361),
                l = n(10618),
                i = n(28466),
                c = n(61174);

            function a(e) {
                const {
                    controller: t,
                    children: n,
                    isOpened: a,
                    closeOnClickOutside: u = !0,
                    doNotCloseOn: d,
                    onClickOutside: h,
                    onClose: f,
                    ...p
                } = e, m = (0, o.useContext)(i.CloseDelegateContext), v = (0, c.useOutsideEvent)({
                    handler: function(e) {
                        h && h(e);
                        if (!u) return;
                        if (d && e.target instanceof Node) {
                            const t = r.findDOMNode(d);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        f()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return a ? o.createElement(s.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, o.createElement("span", {
                    ref: v,
                    style: {
                        pointerEvents: "auto"
                    }
                }, o.createElement(l.Menu, { ...p,
                    onClose: f,
                    onScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    },
                    customCloseDelegate: m,
                    ref: t
                }, n))) : null
            }
        },
        94488: (e, t, n) => {
            "use strict";
            n.d(t, {
                SubmenuContext: () => r,
                SubmenuHandler: () => s
            });
            var o = n(59496);
            const r = o.createContext(null);

            function s(e) {
                const [t, n] = (0, o.useState)(null), s = (0, o.useRef)(null), l = (0, o.useRef)(new Map);
                return (0, o.useEffect)(() => () => {
                    null !== s.current && clearTimeout(s.current)
                }, []), o.createElement(r.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== s.current && (clearTimeout(s.current), s.current = null);
                            null === t ? n(e) : s.current = setTimeout(() => {
                                s.current = null, n(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return l.current.set(e, t), () => {
                                l.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(l.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        76427: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17"><path fill="currentColor" d="M1 8.5a7.5 7.5 0 1 1 15 0 7.5 7.5 0 0 1-15 0zM8.5 0a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM9 9V3H8v5H5v1h4z"/></svg>'
        }
    }
]);
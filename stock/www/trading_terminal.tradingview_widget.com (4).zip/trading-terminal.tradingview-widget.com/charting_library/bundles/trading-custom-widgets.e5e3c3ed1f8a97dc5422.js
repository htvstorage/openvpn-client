(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [3809], {
        37279: e => {
            e.exports = {
                "css-value-calculator-width": "150px",
                calculator: "calculator-DDGMhaxA",
                calculator__inputBorder: "calculator__inputBorder-DDGMhaxA",
                calculator__input: "calculator__input-DDGMhaxA",
                calculator__input__innerInput: "calculator__input__innerInput-DDGMhaxA",
                calculator__btns: "calculator__btns-DDGMhaxA",
                buttonIcon: "buttonIcon-DDGMhaxA"
            }
        },
        109: e => {
            e.exports = {
                menuBox: "menuBox-MViAqvOq"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        13191: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                render: () => r
            });
            var o = n(59496),
                s = n(87995),
                l = n(29018);

            function r(e, t, n) {
                e ? s.render(o.createElement(l.QuantityCalculator, { ...n
                }), t) : s.unmountComponentAtNode(t)
            }
        },
        29018: (e, t, n) => {
            "use strict";
            n.d(t, {
                QuantityCalculator: () => x
            });
            var o = n(59496),
                s = n(60521),
                l = n(47898),
                r = n(44377),
                i = n(10618),
                a = n(93173),
                u = n(72571),
                c = n(297),
                h = n(87125),
                p = n(84039),
                d = n(80185),
                m = n(37729),
                f = n(2739),
                _ = n(94280),
                v = n(80589),
                g = n(37279);

            function C(e) {
                const {
                    min: t,
                    max: n,
                    step: s,
                    uiStep: l,
                    reference: r,
                    withInput: i,
                    valueInput: a,
                    onChangeValueInput: C,
                    onClick: y,
                    onClose: M,
                    onFocus: x
                } = e, [E, B] = (0, o.useState)(!1), [b, w] = (0, o.useState)(void 0), [S, N] = (0, o.useState)(!1), k = o.createElement(u.Icon, {
                    className: g.buttonIcon,
                    icon: f
                }), R = o.createElement(u.Icon, {
                    className: g.buttonIcon,
                    icon: m
                }), T = o.createElement(u.Icon, {
                    className: g.buttonIcon,
                    icon: _
                }), D = o.createElement(u.Icon, {
                    className: g.buttonIcon,
                    icon: v
                }), I = (0, o.useCallback)(e => {
                    const o = {
                            min: t,
                            max: n,
                            step: s
                        },
                        l = (0, p.checkQtyError)(o, e, !0),
                        r = S || l.res,
                        i = S ? void 0 : l.msg;
                    B(r), w(i)
                }, [S, t, n, s]);
                return (0, o.useEffect)(() => {
                    I(a)
                }, [I, a]), o.createElement("div", {
                    className: g.calculator,
                    tabIndex: -1,
                    ref: r,
                    onFocus: x,
                    onKeyDown: e => {
                        a && !E && 13 === (0, d.hashFromEvent)(e) && M()
                    }
                }, i && o.createElement("div", {
                    className: g.calculator__inputBorder
                }, o.createElement(h.NumberInput, {
                    className: g.calculator__input,
                    inputClassName: g.calculator__innerInput,
                    borderStyle: "none",
                    value: a,
                    max: n,
                    min: t,
                    step: s,
                    uiStep: l,
                    mode: "float",
                    error: E,
                    errorMessage: b,
                    errorHandler: function(e) {
                        N(e)
                    },
                    onValueChange: C
                })), o.createElement("div", {
                    className: g.calculator__btns
                }, o.createElement(c.Button, {
                    value: -s,
                    type: c.ButtonType.IncDec,
                    icon: k,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: s,
                    type: c.ButtonType.IncDec,
                    icon: R,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 1,
                    type: c.ButtonType.PlusValue,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 5,
                    type: c.ButtonType.PlusValue,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 25,
                    type: c.ButtonType.PlusValue,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 100,
                    type: c.ButtonType.PlusValue,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 500,
                    type: c.ButtonType.PlusValue,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 1e3,
                    type: c.ButtonType.PlusValue,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: 0,
                    type: c.ButtonType.Clear,
                    icon: T,
                    onClick: y
                }), o.createElement(c.Button, {
                    value: t || s,
                    type: c.ButtonType.Default,
                    icon: D,
                    onClick: y
                })))
            }
            var y = n(109);
            const M = (0, a.mergeThemes)(i.DEFAULT_MENU_THEME, {
                menuBox: y.menuBox
            });
            class x extends o.PureComponent {
                constructor(e) {
                    super(e), this._setCalcRef = e => {
                        this.props.calcReference && this.props.calcReference(e)
                    }, this._calculatorStepHandler = (e, t) => {
                        const {
                            min: n,
                            max: o,
                            uiStep: r,
                            trackEventTarget: i,
                            trackEvent: a
                        } = this.props;
                        if (void 0 !== a && void 0 !== i && a(i, "Calculator Button", (0, l.prepareCalculatorEventText)(e, t)), t === c.ButtonType.Clear || t === c.ButtonType.Default) return this._updateValueByCalc(e);
                        const u = this.props.valueGetter();
                        if (null === u) return;
                        let h = Number((0, s.Big)(u).plus(e));
                        if ((h < n || o < h) && t !== c.ButtonType.IncDec) return this._updateValueByCalc(u);
                        if (t === c.ButtonType.IncDec) {
                            if (h = this._calcByStep(u, e, n, r), o < h) return this._updateValueByCalc(o);
                            if (h < n) return this._updateValueByCalc(n)
                        }
                        return this._updateValueByCalc(h)
                    }, this._updateValueByCalc = e => {
                        this._handlerValueInput(e), this.props.onValueChange(e, !0), this.props.calculatorUsedStat && this.props.calculatorUsedStat()
                    }, this.state = {
                        valueInput: e.valueGetter()
                    }, this._handlerValueInput = this._handlerValueInput.bind(this)
                }
                render() {
                    const {
                        min: e,
                        max: t,
                        step: n,
                        uiStep: s,
                        withInput: l,
                        targetEl: i,
                        position: a,
                        onFocus: u,
                        onClose: c
                    } = this.props;
                    return o.createElement(r.PopupMenu, {
                        isOpened: !0,
                        onClose: c,
                        position: a,
                        doNotCloseOn: i,
                        theme: M
                    }, o.createElement(C, {
                        min: e,
                        max: t,
                        step: n,
                        uiStep: s,
                        withInput: l,
                        reference: this._setCalcRef,
                        valueInput: this.state.valueInput,
                        onChangeValueInput: this._updateValueByCalc,
                        onClick: this._calculatorStepHandler,
                        onFocus: u,
                        onClose: c
                    }))
                }
                _calcByStep(e, t, n, o) {
                    const l = Math.sign(t),
                        r = Math.abs(null != o ? o : t),
                        i = new s.Big(e),
                        a = i.minus(n).mod(t);
                    let u = i.plus(l * r);
                    return a.eq(0) || (u = u.plus((l > 0 ? 0 : 1) * r).minus(a)), u.toNumber()
                }
                _handlerValueInput(e) {
                    this.setState({
                        valueInput: e
                    })
                }
            }
        },
        32207: (e, t, n) => {
            "use strict";
            n.d(t, {
                SplitThousandsFormatter: () => l
            });
            var o = n(72249),
                s = n(34581);
            class l {
                constructor(e = " ") {
                    this._divider = e
                }
                format(e) {
                    const t = (0, o.splitThousands)(e, this._divider);
                    return (0, s.isRtl)() ? (0, s.startWithLTR)(t) : t
                }
                parse(e) {
                    const t = (0, s.stripLTRMarks)(e).split(this._divider).join(""),
                        n = Number(t);
                    return isNaN(n) || /e/i.test(t) ? {
                        res: !1
                    } : {
                        res: !0,
                        value: n,
                        suggest: this.format(n)
                    }
                }
            }
        },
        30553: (e, t, n) => {
            "use strict";
            n.d(t, {
                MenuContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        10618: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_MENU_THEME: () => _,
                Menu: () => v
            });
            var o = n(59496),
                s = n(97754),
                l = n.n(s),
                r = n(88537),
                i = n(97280),
                a = n(12777),
                u = n(53327),
                c = n(70981),
                h = n(63212),
                p = n(82027),
                d = n(94488),
                m = n(30553),
                f = n(16059);
            const _ = f;
            class v extends o.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new h.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                        this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                    }, this._handleScrollWrapRef = e => {
                        this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e),
                            "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                    }, this._handleMeasure = ({
                        callback: e,
                        forceRecalcPosition: t
                    } = {}) => {
                        var n, o, s, l;
                        if (this.state.isMeasureValid && !t) return;
                        const {
                            position: a
                        } = this.props, u = (0, r.ensureNotNull)(this._containerRef);
                        let c = u.getBoundingClientRect();
                        const h = document.documentElement.clientHeight,
                            p = document.documentElement.clientWidth,
                            d = null !== (n = this.props.closeOnScrollOutsideOffset) && void 0 !== n ? n : 0;
                        let m = h - 0 - d;
                        const f = c.height > m;
                        if (f) {
                            (0, r.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", c = u.getBoundingClientRect()
                        }
                        const {
                            width: _,
                            height: v
                        } = c, g = "function" == typeof a ? a(_, v, h) : a, C = p - (null !== (o = g.overrideWidth) && void 0 !== o ? o : _) - 0, y = (0, i.clamp)(g.x, 0, Math.max(0, C)), M = 0 + d, x = h - (null !== (s = g.overrideHeight) && void 0 !== s ? s : v) - 0;
                        let E = (0, i.clamp)(g.y, M, Math.max(M, x));
                        if (g.forbidCorrectYCoord && E < g.y && (m -= g.y - E, E = g.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && g.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                        const B = null !== (l = g.overrideHeight) && void 0 !== l ? l : f ? m : void 0;
                        this.setState({
                            appearingMenuHeight: t ? this.state.appearingMenuHeight : B,
                            appearingMenuWidth: t ? this.state.appearingMenuWidth : g.overrideWidth,
                            appearingPosition: {
                                x: y,
                                y: E
                            },
                            isMeasureValid: !0
                        }, () => {
                            this._restoreScrollPosition(), e && e()
                        })
                    }, this._restoreScrollPosition = () => {
                        const e = document.activeElement,
                            t = (0, r.ensureNotNull)(this._containerRef);
                        if (null !== e && t.contains(e)) try {
                            e.scrollIntoView()
                        } catch (e) {} else(0, r.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                    }, this._resizeForced = () => {
                        this.setState({
                            appearingMenuHeight: void 0,
                            appearingMenuWidth: void 0,
                            appearingPosition: void 0,
                            isMeasureValid: void 0
                        })
                    }, this._resize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            }), this._raf = null
                        }))
                    }, this._handleGlobalClose = e => {
                        this.props.onClose(e)
                    }, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }, this._handleScroll = () => {
                        this._scroll = (0, r.ensureNotNull)(this._scrollWrapRef).scrollTop
                    }, this._handleScrollOutsideEnd = () => {
                        clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            })
                        }, 80)
                    }, this._handleScrollOutside = e => {
                        e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            }), this._scrollRaf = null
                        })))
                    }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = c.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = p.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = c.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": s,
                        children: r,
                        minWidth: i,
                        theme: c = f,
                        className: h,
                        maxHeight: p,
                        onMouseOver: _,
                        onMouseOut: v,
                        onKeyDown: C,
                        onFocus: y,
                        onBlur: M
                    } = this.props, {
                        appearingMenuHeight: x,
                        appearingMenuWidth: E,
                        appearingPosition: B,
                        isMeasureValid: b
                    } = this.state;
                    return o.createElement(m.MenuContext.Provider, {
                        value: this
                    }, o.createElement(d.SubmenuHandler, null, o.createElement(u.SlotContext.Provider, {
                        value: this._manager
                    }, o.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": s,
                        className: l()(h, c.menuWrap, !b && c.isMeasuring),
                        style: {
                            height: x,
                            left: B && B.x,
                            minWidth: i,
                            position: "fixed",
                            top: B && B.y,
                            width: E
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: a.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: _,
                        onMouseOut: v,
                        onKeyDown: C,
                        onFocus: y,
                        onBlur: M
                    }, o.createElement("div", {
                        className: l()(c.scrollWrap, !this.props.noMomentumBasedScroll && c.momentumBased),
                        style: {
                            overflowY: void 0 !== x ? "scroll" : "auto",
                            maxHeight: p
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, o.createElement(g, {
                        className: c.menuBox
                    }, r)))), o.createElement(u.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function g(e) {
                const t = (0, r.ensureNotNull)((0, o.useContext)(d.SubmenuContext)),
                    n = o.useRef(null);
                return o.createElement("div", {
                    ref: n,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (o = e.target, null === (s = n.current) || void 0 === s ? void 0 : s.contains(o)))) return;
                        var o, s;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            v.contextType = d.SubmenuContext
        },
        28466: (e, t, n) => {
            "use strict";
            n.d(t, {
                CloseDelegateContext: () => l
            });
            var o = n(59496),
                s = n(70981);
            const l = o.createContext(s.globalCloseDelegate)
        },
        44377: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenu: () => u
            });
            var o = n(59496),
                s = n(87995),
                l = n(8361),
                r = n(10618),
                i = n(28466),
                a = n(61174);

            function u(e) {
                const {
                    controller: t,
                    children: n,
                    isOpened: u,
                    closeOnClickOutside: c = !0,
                    doNotCloseOn: h,
                    onClickOutside: p,
                    onClose: d,
                    ...m
                } = e, f = (0, o.useContext)(i.CloseDelegateContext), _ = (0, a.useOutsideEvent)({
                    handler: function(e) {
                        p && p(e);
                        if (!c) return;
                        if (h && e.target instanceof Node) {
                            const t = s.findDOMNode(h);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        d()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return u ? o.createElement(l.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, o.createElement("span", {
                    ref: _,
                    style: {
                        pointerEvents: "auto"
                    }
                }, o.createElement(r.Menu, { ...m,
                    onClose: d,
                    onScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    },
                    customCloseDelegate: f,
                    ref: t
                }, n))) : null
            }
        },
        94488: (e, t, n) => {
            "use strict";
            n.d(t, {
                SubmenuContext: () => s,
                SubmenuHandler: () => l
            });
            var o = n(59496);
            const s = o.createContext(null);

            function l(e) {
                const [t, n] = (0, o.useState)(null), l = (0, o.useRef)(null), r = (0, o.useRef)(new Map);
                return (0, o.useEffect)(() => () => {
                    null !== l.current && clearTimeout(l.current)
                }, []), o.createElement(s.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== l.current && (clearTimeout(l.current), l.current = null);
                            null === t ? n(e) : l.current = setTimeout(() => {
                                l.current = null, n(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return r.current.set(e, t), () => {
                                r.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(r.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        93173: (e, t, n) => {
            "use strict";

            function o(e, t, n = {}) {
                const o = Object.assign({}, t);
                for (const s of Object.keys(t)) {
                    const l = n[s] || s;
                    l in e && (o[s] = [e[l], t[s]].join(" "))
                }
                return o
            }

            function s(e, t, n = {}) {
                return Object.assign({}, e, o(e, t, n))
            }
            n.d(t, {
                weakComposeClasses: () => o,
                mergeThemes: () => s
            })
        },
        94280: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><path fill="none" stroke="currentColor" stroke-width="2" d="M17.09 6.5A7.5 7.5 0 1 0 11.5 19a7.481 7.481 0 0 0 5.59-2.5"/></svg>'
        },
        2739: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><path fill="currentColor" stroke="none" d="M2 10h18v2H2z"/></svg>'
        },
        37729: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><g fill="currentColor" stroke="none"><path d="M3 10h18v2H3z"/><path d="M11 2h2v18h-2z"/></g></svg>'
        },
        80589: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><g fill="none"><path stroke="currentColor" stroke-width="2" d="M4 12.5A7.5 7.5 0 1 0 11.5 5h-6"/><path fill="currentColor" d="M3 5l4-4v8z"/></g></svg>'
        }
    }
]);
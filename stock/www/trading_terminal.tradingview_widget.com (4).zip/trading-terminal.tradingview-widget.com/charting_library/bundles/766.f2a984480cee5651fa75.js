(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [766], {
        17683: t => {
            t.exports = {
                dialog: "dialog-Nh5Cqdeo",
                rounded: "rounded-Nh5Cqdeo",
                shadowed: "shadowed-Nh5Cqdeo",
                fullscreen: "fullscreen-Nh5Cqdeo",
                darker: "darker-Nh5Cqdeo",
                backdrop: "backdrop-Nh5Cqdeo"
            }
        },
        12114: t => {
            t.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "tooltip-offset": "20px",
                dialog: "dialog-hxnnZcZ6",
                dragging: "dragging-hxnnZcZ6",
                dialogAnimatedAppearance: "dialogAnimatedAppearance-hxnnZcZ6",
                dialogAnimation: "dialogAnimation-hxnnZcZ6",
                dialogTooltip: "dialogTooltip-hxnnZcZ6"
            }
        },
        31537: (t, e, i) => {
            "use strict";
            i.d(e, {
                Dialog: () => h
            });
            var s = i(59496),
                o = i(97754),
                n = i(53327),
                a = i(63212),
                r = i(417),
                l = i(17683);
            class h extends s.PureComponent {
                constructor() {
                    super(...arguments), this._manager = new a.OverlapManager, this._handleSlot = t => {
                        this._manager.setContainer(t)
                    }
                }
                render() {
                    const {
                        rounded: t = !0,
                        shadowed: e = !0,
                        fullscreen: i = !1,
                        darker: a = !1,
                        className: h,
                        backdrop: d
                    } = this.props, c = o(h, l.dialog, t && l.rounded, e && l.shadowed, i && l.fullscreen, a && l.darker), u = (0, r.filterDataProps)(this.props), g = this.props.style ? { ...this._createStyles(),
                        ...this.props.style
                    } : this._createStyles();
                    return s.createElement(s.Fragment, null, s.createElement(n.SlotContext.Provider, {
                        value: this._manager
                    }, d && s.createElement("div", {
                        onClick: this.props.onClickBackdrop,
                        className: l.backdrop
                    }), s.createElement("div", { ...u,
                        className: c,
                        style: g,
                        ref: this.props.reference,
                        onFocus: this.props.onFocus,
                        onMouseDown: this.props.onMouseDown,
                        onMouseUp: this.props.onMouseUp,
                        onClick: this.props.onClick,
                        onKeyDown: this.props.onKeyDown,
                        tabIndex: -1
                    }, this.props.children)), s.createElement(n.Slot, {
                        reference: this._handleSlot
                    }))
                }
                _createStyles() {
                    const {
                        bottom: t,
                        left: e,
                        width: i,
                        right: s,
                        top: o,
                        zIndex: n,
                        height: a
                    } = this.props;
                    return {
                        bottom: t,
                        left: e,
                        right: s,
                        top: o,
                        zIndex: n,
                        maxWidth: i,
                        height: a
                    }
                }
            }
        },
        10549: (t, e, i) => {
            "use strict";
            i.d(e, {
                PopupContext: () => s
            });
            const s = i(59496).createContext(null)
        },
        40766: (t, e, i) => {
            "use strict";
            i.d(e, {
                PopupDialog: () => E
            });
            var s = i(59496),
                o = i(97754),
                n = i(88537),
                a = i(31537),
                r = i(74485),
                l = i(23235),
                h = i(97280);

            function d(t, e, i, s) {
                return t + e > s && (t = s - e), t < i && (t = i), t
            }

            function c(t) {
                return {
                    x: (0, h.clamp)(t.x, 20, document.documentElement.clientWidth - 20),
                    y: (0, h.clamp)(t.y, 20, window.innerHeight - 20)
                }
            }

            function u(t) {
                return {
                    x: t.clientX,
                    y: t.clientY
                }
            }

            function g(t) {
                return {
                    x: t.touches[0].clientX,
                    y: t.touches[0].clientY
                }
            }
            class p {
                constructor(t, e, i = {
                    boundByScreen: !0
                }) {
                    this._drag = null, this._canBeTouchClick = !1, this._frame = null, this._onMouseDragStart = t => {
                        if (0 !== t.button || this._isTargetNoDraggable(t)) return;
                        t.preventDefault(), document.addEventListener("mousemove", this._onMouseDragMove), document.addEventListener("mouseup", this._onMouseDragEnd);
                        const e = c(u(t));
                        this._dragStart(e)
                    }, this._onTouchDragStart = t => {
                        if (this._isTargetNoDraggable(t)) return;
                        this._canBeTouchClick = !0, t.preventDefault(), this._header.addEventListener("touchmove", this._onTouchDragMove, {
                            passive: !1
                        });
                        const e = c(g(t));
                        this._dragStart(e)
                    }, this._onMouseDragEnd = t => {
                        t.target instanceof Node && this._header.contains(t.target) && t.preventDefault(),
                            document.removeEventListener("mousemove", this._onMouseDragMove), document.removeEventListener("mouseup", this._onMouseDragEnd), this._onDragStop()
                    }, this._onTouchDragEnd = t => {
                        this._header.removeEventListener("touchmove", this._onTouchDragMove), this._onDragStop(), this._canBeTouchClick && (this._canBeTouchClick = !1, function(t) {
                            if (t instanceof SVGElement) {
                                const e = document.createEvent("SVGEvents");
                                e.initEvent("click", !0, !0), t.dispatchEvent(e)
                            }
                            t instanceof HTMLElement && t.click()
                        }(t.target))
                    }, this._onMouseDragMove = t => {
                        const e = c(u(t));
                        this._dragMove(e)
                    }, this._onTouchDragMove = t => {
                        this._canBeTouchClick = !1, t.preventDefault();
                        const e = c(g(t));
                        this._dragMove(e)
                    }, this._onDragStop = () => {
                        this._drag = null, this._header.classList.remove("dragging")
                    }, this._dialog = t, this._header = e, this._options = i, this._header.addEventListener("mousedown", this._onMouseDragStart), this._header.addEventListener("touchstart", this._onTouchDragStart), this._header.addEventListener("touchend", this._onTouchDragEnd)
                }
                destroy() {
                    null !== this._frame && cancelAnimationFrame(this._frame), this._header.removeEventListener("mousedown", this._onMouseDragStart), document.removeEventListener("mouseup", this._onMouseDragEnd), this._header.removeEventListener("touchstart", this._onTouchDragStart), this._header.removeEventListener("touchend", this._onTouchDragEnd), document.removeEventListener("mouseleave", this._onMouseDragEnd)
                }
                updateOptions(t) {
                    this._options = t
                }
                _dragStart(t) {
                    const e = this._dialog.getBoundingClientRect();
                    this._drag = {
                        startX: t.x,
                        startY: t.y,
                        finishX: t.x,
                        finishY: t.y,
                        dialogX: e.left,
                        dialogY: e.top
                    };
                    const i = Math.round(e.left),
                        s = Math.round(e.top);
                    this._dialog.style.transform = `translate(${i}px, ${s}px)`, this._header.classList.add("dragging"), this._options.onDragStart && this._options.onDragStart()
                }
                _dragMove(t) {
                    if (this._drag) {
                        if (this._drag.finishX = t.x, this._drag.finishY = t.y, null !== this._frame) return;
                        this._frame = requestAnimationFrame(() => {
                            if (this._drag) {
                                const e = t.x - this._drag.startX,
                                    i = t.y - this._drag.startY;
                                this._moveDialog(this._drag.dialogX + e, this._drag.dialogY + i)
                            }
                            this._frame = null
                        })
                    }
                }
                _moveDialog(t, e) {
                    const i = this._dialog.getBoundingClientRect(),
                        {
                            boundByScreen: s
                        } = this._options,
                        o = d(t, i.width, s ? 0 : -1 / 0, s ? window.innerWidth : 1 / 0),
                        n = d(e, i.height, s ? 0 : -1 / 0, s ? window.innerHeight : 1 / 0);
                    this._dialog.style.transform = `translate(${Math.round(o)}px, ${Math.round(n)}px)`
                }
                _isTargetNoDraggable(t) {
                    return t.target instanceof Element && null !== t.target.closest("[data-disable-drag]")
                }
            }
            const _ = {
                vertical: 0
            };
            class m {
                constructor(t, e) {
                    this._frame = null, this._isFullscreen = !1, this._handleResize = () => {
                        null === this._frame && (this._frame = requestAnimationFrame(() => {
                            this.recalculateBounds(), this._frame = null
                        }))
                    }, this._dialog = t, this._guard = e.guard || _, this._calculateDialogPosition = e.calculateDialogPosition, this._initialHeight = t.style.height, window.addEventListener("resize", this._handleResize)
                }
                updateOptions(t) {
                    this._guard = t.guard || _, this._calculateDialogPosition = t.calculateDialogPosition
                }
                setFullscreen(t) {
                    this._isFullscreen !== t && (this._isFullscreen = t, this.recalculateBounds())
                }
                centerAndFit() {
                    const {
                        x: t,
                        y: e
                    } = this.getDialogsTopLeftCoordinates(), i = this._calcAvailableHeight(), s = this._calcDialogHeight();
                    if (i === s)
                        if (this._calculateDialogPosition) {
                            const {
                                left: t,
                                top: e
                            } = this._calculateDialogPosition(this._dialog, document.documentElement, this._guard);
                            this._dialog.style.transform = `translate(${Math.round(t)}px, ${Math.round(e)}px)`
                        } else this._dialog.style.height = s + "px";
                    this._dialog.style.top = "0px", this._dialog.style.left = "0px", this._dialog.style.transform = `translate(${t}px, ${e}px)`
                }
                getDialogsTopLeftCoordinates() {
                    const {
                        clientHeight: t,
                        clientWidth: e
                    } = document.documentElement, i = this._calcDialogHeight(), s = e / 2 - this._dialog.clientWidth / 2, o = t / 2 - i / 2;
                    return {
                        x: Math.round(s),
                        y: Math.round(o)
                    }
                }
                recalculateBounds() {
                    const {
                        clientHeight: t,
                        clientWidth: e
                    } = document.documentElement;
                    if (this._isFullscreen) this._dialog.style.top = "0px", this._dialog.style.left = "0px", this._dialog.style.width = "100%", this._dialog.style.height = "100%", this._dialog.style.transform = "none";
                    else {
                        const {
                            vertical: i
                        } = this._guard;
                        if (this._calculateDialogPosition) {
                            const s = this._calculateDialogPosition(this._dialog, {
                                    clientWidth: e,
                                    clientHeight: t
                                }, {
                                    vertical: i
                                }),
                                {
                                    left: o,
                                    top: n
                                } = s;
                            this._dialog.style.transform = `translate(${Math.round(o)}px, ${Math.round(n)}px)`
                        } else {
                            this._dialog.style.width = "", this._dialog.style.height = "";
                            const s = this._dialog.getBoundingClientRect(),
                                o = t - 2 * i,
                                n = d(s.left, s.width, 0, e),
                                a = d(s.top, s.height, i, t);
                            this._dialog.style.top = "0px", this._dialog.style.left = "0px", this._dialog.style.transform = `translate(${Math.round(n)}px, ${Math.round(a)}px)`, this._dialog.style.height = o < s.height ? o + "px" : this._initialHeight
                        }
                    }
                }
                destroy() {
                    window.removeEventListener("resize", this._handleResize), null !== this._frame && (cancelAnimationFrame(this._frame), this._frame = null)
                }
                _calcDialogHeight() {
                    const t = this._calcAvailableHeight();
                    return t < this._dialog.clientHeight ? t : this._dialog.clientHeight
                }
                _calcAvailableHeight() {
                    return document.documentElement.clientHeight - 2 * this._guard.vertical
                }
            }
            var f = i(8361),
                v = i(10549),
                y = i(85089),
                D = i(12114);
            D["tooltip-offset"];
            class x extends s.PureComponent {
                constructor(t) {
                    super(t), this._dialog = null, this._handleDialogRef = t => {
                        const {
                            reference: e
                        } = this.props;
                        this._dialog = t, "function" == typeof e && e(t)
                    }, this._handleFocus = t => {
                        this._moveToTop()
                    }, this._handleMouseDown = t => {
                        this._moveToTop()
                    }, this._handleTouchStart = t => {
                        this._moveToTop()
                    }, this.state = {
                        canFitTooltip: !1
                    }
                }
                render() {
                    return s.createElement(v.PopupContext.Provider, {
                        value: this
                    }, s.createElement(l.OutsideEvent, {
                        mouseDown: !0,
                        touchStart: !0,
                        handler: this.props.onClickOutside
                    }, t => s.createElement("div", {
                        ref: t,
                        "data-outside-boundary-for": this.props.name,
                        onFocus: this._handleFocus,
                        onMouseDown: this._handleMouseDown,
                        onTouchStart: this._handleTouchStart,
                        "data-dialog-name": this.props["data-dialog-name"]
                    }, s.createElement(a.Dialog, {
                        style: this._applyAnimationCSSVariables(),
                        ...this.props,
                        reference: this._handleDialogRef,
                        className: o(D.dialog, this.props.className)
                    }, !1, this.props.children))))
                }
                componentDidMount() {
                    const {
                        draggable: t,
                        boundByScreen: e,
                        onDragStart: i
                    } = this.props, s = (0, n.ensureNotNull)(this._dialog);
                    if (t) {
                        const t = s.querySelector("[data-dragg-area]");
                        t && t instanceof HTMLElement && (this._drag = new p(s, t, {
                            boundByScreen: Boolean(e),
                            onDragStart: i
                        }))
                    }
                    this.props.autofocus && !s.contains(document.activeElement) && s.focus(), (this._isFullScreen() || this.props.fixedBody) && (0, y.setFixedBodyState)(!0);
                    const {
                        guard: o,
                        calculateDialogPosition: a
                    } = this.props;
                    this._resize = new m(s, {
                        guard: o,
                        calculateDialogPosition: a
                    }), this.props.isAnimationEnabled && this.props.growPoint && this._applyAppearanceAnimation(this.props.growPoint), this.props.centeredOnMount && this._resize.centerAndFit(), this._resize.setFullscreen(this._isFullScreen()), this.props.shouldForceFocus && s.focus()
                }
                componentDidUpdate() {
                    if (this._resize) {
                        const {
                            guard: t,
                            calculateDialogPosition: e
                        } = this.props;
                        this._resize.updateOptions({
                            guard: t,
                            calculateDialogPosition: e
                        }), this._resize.setFullscreen(this._isFullScreen())
                    }
                    this._drag && this._drag.updateOptions({
                        boundByScreen: Boolean(this.props.boundByScreen),
                        onDragStart: this.props.onDragStart
                    })
                }
                componentWillUnmount() {
                    this._drag && this._drag.destroy(), this._resize && this._resize.destroy(), (this._isFullScreen() || this.props.fixedBody) && (0, y.setFixedBodyState)(!1)
                }
                focus() {
                    this._dialog && this._dialog.focus()
                }
                centerAndFit() {
                    this._resize && this._resize.centerAndFit()
                }
                recalculateBounds() {
                    this._resize && this._resize.recalculateBounds()
                }
                _moveToTop() {
                    null !== this.context && this.context.moveToTop()
                }
                _applyAnimationCSSVariables() {
                    return {
                        "--animationTranslateStartX": null,
                        "--animationTranslateStartY": null,
                        "--animationTranslateEndX": null,
                        "--animationTranslateEndY": null
                    }
                }
                _applyAppearanceAnimation(t) {
                    if (this._resize && this._dialog) {
                        const {
                            x: e,
                            y: i
                        } = t, {
                            x: s,
                            y: o
                        } = this._resize.getDialogsTopLeftCoordinates();
                        this._dialog.style.setProperty("--animationTranslateStartX", e + "px"), this._dialog.style.setProperty("--animationTranslateStartY", i + "px"), this._dialog.style.setProperty("--animationTranslateEndX", s + "px"), this._dialog.style.setProperty("--animationTranslateEndY", o + "px"), this._dialog.classList.add(D.dialogAnimatedAppearance)
                    }
                }
                _handleTooltipFit() {
                    0
                }
                _isFullScreen() {
                    return Boolean(this.props.fullscreen)
                }
            }
            x.contextType = f.PortalContext, x.defaultProps = {
                boundByScreen: !0,
                draggable: !0,
                centeredOnMount: !0
            };
            const E = (0, r.makeOverlapable)(x)
        },
        23235: (t, e, i) => {
            "use strict";
            i.d(e, {
                OutsideEvent: () => o
            });
            var s = i(61174);

            function o(t) {
                const {
                    children: e,
                    ...i
                } = t;
                return e((0, s.useOutsideEvent)(i))
            }
        },
        74485: (t, e, i) => {
            "use strict";
            i.d(e, {
                makeOverlapable: () => n
            });
            var s = i(59496),
                o = i(8361);

            function n(t) {
                return class extends s.PureComponent {
                    render() {
                        const {
                            isOpened: e,
                            root: i
                        } = this.props;
                        if (!e) return null;
                        const n = s.createElement(t, { ...this.props,
                            zIndex: 150
                        });
                        return "parent" === i ? n : s.createElement(o.Portal, null, n)
                    }
                }
            }
        }
    }
]);
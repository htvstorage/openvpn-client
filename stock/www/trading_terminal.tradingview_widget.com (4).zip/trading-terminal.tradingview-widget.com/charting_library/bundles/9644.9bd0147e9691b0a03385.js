(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [9644, 766], {
        37593: e => {
            e.exports = {
                wrapper: "wrapper-5Xd5conM",
                input: "input-5Xd5conM",
                box: "box-5Xd5conM",
                icon: "icon-5Xd5conM",
                noOutline: "noOutline-5Xd5conM",
                "intent-danger": "intent-danger-5Xd5conM",
                check: "check-5Xd5conM",
                dot: "dot-5Xd5conM"
            }
        },
        96670: e => {
            e.exports = {
                checkbox: "checkbox-GxG6nBa7",
                reverse: "reverse-GxG6nBa7",
                label: "label-GxG6nBa7",
                baseline: "baseline-GxG6nBa7"
            }
        },
        12857: e => {
            e.exports = {
                "textarea-container": "textarea-container-I5L4qQPj",
                "change-highlight": "change-highlight-I5L4qQPj",
                focused: "focused-I5L4qQPj",
                "resize-vertical": "resize-vertical-I5L4qQPj",
                "resize-horizontal": "resize-horizontal-I5L4qQPj",
                "resize-both": "resize-both-I5L4qQPj",
                textarea: "textarea-I5L4qQPj"
            }
        },
        15994: e => {
            e.exports = {
                radio: "radio-vpA3AYsc",
                input: "input-vpA3AYsc",
                box: "box-vpA3AYsc",
                reverse: "reverse-vpA3AYsc",
                label: "label-vpA3AYsc",
                wrapper: "wrapper-vpA3AYsc",
                noOutline: "noOutline-vpA3AYsc"
            }
        },
        74588: e => {
            e.exports = {
                wrap: "wrap-sYKPueSl",
                thicknessItem: "thicknessItem-sYKPueSl",
                checked: "checked-sYKPueSl",
                radio: "radio-sYKPueSl",
                bar: "bar-sYKPueSl"
            }
        },
        16300: e => {
            e.exports = {
                titleWrap: "titleWrap-ZYQL0yaM",
                groupFooter: "groupFooter-ZYQL0yaM"
            }
        },
        23128: e => {
            e.exports = {
                inlineRow: "inlineRow-CqPNtHDN"
            }
        },
        70199: e => {
            e.exports = {
                icon: "icon-OTC0ma9h"
            }
        },
        6041: e => {
            e.exports = {
                input: "input-pBN3Orju",
                symbol: "symbol-pBN3Orju",
                checkbox: "checkbox-pBN3Orju",
                label: "label-pBN3Orju",
                dropdownMenu: "dropdownMenu-pBN3Orju",
                sessionStart: "sessionStart-pBN3Orju",
                sessionEnd: "sessionEnd-pBN3Orju",
                sessionInputContainer: "sessionInputContainer-pBN3Orju",
                sessionDash: "sessionDash-pBN3Orju",
                inputGroup: "inputGroup-pBN3Orju",
                textarea: "textarea-pBN3Orju",
                inlineGroup: "inlineGroup-pBN3Orju",
                hasTooltip: "hasTooltip-pBN3Orju"
            }
        },
        46828: e => {
            e.exports = {
                content: "content-ByXdMGQj",
                cell: "cell-ByXdMGQj",
                inner: "inner-ByXdMGQj",
                first: "first-ByXdMGQj",
                inlineCell: "inlineCell-ByXdMGQj",
                fill: "fill-ByXdMGQj",
                top: "top-ByXdMGQj",
                topCenter: "topCenter-ByXdMGQj",
                offset: "offset-ByXdMGQj",
                inlineRow: "inlineRow-ByXdMGQj",
                grouped: "grouped-ByXdMGQj",
                separator: "separator-ByXdMGQj",
                groupSeparator: "groupSeparator-ByXdMGQj",
                big: "big-ByXdMGQj",
                adaptive: "adaptive-ByXdMGQj",
                checkableTitle: "checkableTitle-ByXdMGQj"
            }
        },
        300: e => {
            e.exports = {
                wrap: "wrap-l3G0HrB9",
                labelWrap: "labelWrap-l3G0HrB9",
                label: "label-l3G0HrB9",
                hasTooltip: "hasTooltip-l3G0HrB9"
            }
        },
        91131: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                footer: "footer-xe9kH1lJ",
                submitButton: "submitButton-xe9kH1lJ",
                buttons: "buttons-xe9kH1lJ"
            }
        },
        55914: e => {
            e.exports = {
                wrap: "wrap-GsOqvniR",
                icon: "icon-GsOqvniR",
                text: "text-GsOqvniR",
                disabled: "disabled-GsOqvniR"
            }
        },
        14348: e => {
            e.exports = {
                colorPickerWrap: "colorPickerWrap-pz6IRAmC",
                focused: "focused-pz6IRAmC",
                readonly: "readonly-pz6IRAmC",
                disabled: "disabled-pz6IRAmC",
                "size-small": "size-small-pz6IRAmC",
                "size-medium": "size-medium-pz6IRAmC",
                "size-large": "size-large-pz6IRAmC",
                "font-size-small": "font-size-small-pz6IRAmC",
                "font-size-medium": "font-size-medium-pz6IRAmC",
                "font-size-large": "font-size-large-pz6IRAmC",
                "border-none": "border-none-pz6IRAmC",
                shadow: "shadow-pz6IRAmC",
                "border-thin": "border-thin-pz6IRAmC",
                "border-thick": "border-thick-pz6IRAmC",
                "intent-default": "intent-default-pz6IRAmC",
                "intent-success": "intent-success-pz6IRAmC",
                "intent-warning": "intent-warning-pz6IRAmC",
                "intent-danger": "intent-danger-pz6IRAmC",
                "intent-primary": "intent-primary-pz6IRAmC",
                "corner-top-left": "corner-top-left-pz6IRAmC",
                "corner-top-right": "corner-top-right-pz6IRAmC",
                "corner-bottom-right": "corner-bottom-right-pz6IRAmC",
                "corner-bottom-left": "corner-bottom-left-pz6IRAmC",
                colorPicker: "colorPicker-pz6IRAmC",
                swatch: "swatch-pz6IRAmC",
                placeholderContainer: "placeholderContainer-pz6IRAmC",
                placeholder: "placeholder-pz6IRAmC",
                mixedColor: "mixedColor-pz6IRAmC",
                white: "white-pz6IRAmC",
                opacitySwatch: "opacitySwatch-pz6IRAmC",
                colorLine: "colorLine-pz6IRAmC",
                multiWidth: "multiWidth-pz6IRAmC",
                line: "line-pz6IRAmC",
                thicknessContainer: "thicknessContainer-pz6IRAmC",
                thicknessTitle: "thicknessTitle-pz6IRAmC"
            }
        },
        83421: e => {
            e.exports = {
                thicknessContainer: "thicknessContainer-ofeynovw",
                thicknessTitle: "thicknessTitle-ofeynovw"
            }
        },
        83998: e => {
            e.exports = {
                hasTooltip: "hasTooltip-0t5K1wco",
                uppercase: "uppercase-0t5K1wco"
            }
        },
        26527: e => {
            e.exports = {
                wrap: "wrap-dHwHcgvB"
            }
        },
        27345: e => {
            e.exports = {
                checkbox: "checkbox-24x04noU",
                title: "title-24x04noU"
            }
        },
        51842: e => {
            e.exports = {
                titleWrap: "titleWrap-O5QDBhZc",
                title: "title-O5QDBhZc"
            }
        },
        10667: e => {
            e.exports = {
                container: "container-WiTVOllB",
                sectionTitle: "sectionTitle-WiTVOllB",
                separator: "separator-WiTVOllB",
                customButton: "customButton-WiTVOllB"
            }
        },
        99565: e => {
            e.exports = {
                container: "container-UpS01XRM",
                form: "form-UpS01XRM",
                swatch: "swatch-UpS01XRM",
                inputWrap: "inputWrap-UpS01XRM",
                inputHash: "inputHash-UpS01XRM",
                input: "input-UpS01XRM",
                buttonWrap: "buttonWrap-UpS01XRM",
                hueSaturationWrap: "hueSaturationWrap-UpS01XRM",
                saturation: "saturation-UpS01XRM",
                hue: "hue-UpS01XRM"
            }
        },
        24429: e => {
            e.exports = {
                hue: "hue-oQv2KoOx",
                pointer: "pointer-oQv2KoOx",
                pointerContainer: "pointerContainer-oQv2KoOx"
            }
        },
        15381: e => {
            e.exports = {
                opacity: "opacity-YL5Gjk00",
                opacitySlider: "opacitySlider-YL5Gjk00",
                opacitySliderGradient: "opacitySliderGradient-YL5Gjk00",
                pointer: "pointer-YL5Gjk00",
                dragged: "dragged-YL5Gjk00",
                opacityPointerWrap: "opacityPointerWrap-YL5Gjk00",
                opacityInputWrap: "opacityInputWrap-YL5Gjk00",
                opacityInput: "opacityInput-YL5Gjk00",
                opacityInputPercent: "opacityInputPercent-YL5Gjk00"
            }
        },
        88440: e => {
            e.exports = {
                saturation: "saturation-lJHGRPyu",
                pointer: "pointer-lJHGRPyu"
            }
        },
        24590: e => {
            e.exports = {
                swatches: "swatches-qgksmXjR",
                swatch: "swatch-qgksmXjR",
                hover: "hover-qgksmXjR",
                empty: "empty-qgksmXjR",
                white: "white-qgksmXjR",
                selected: "selected-qgksmXjR",
                contextItem: "contextItem-qgksmXjR"
            }
        },
        17683: e => {
            e.exports = {
                dialog: "dialog-Nh5Cqdeo",
                rounded: "rounded-Nh5Cqdeo",
                shadowed: "shadowed-Nh5Cqdeo",
                fullscreen: "fullscreen-Nh5Cqdeo",
                darker: "darker-Nh5Cqdeo",
                backdrop: "backdrop-Nh5Cqdeo"
            }
        },
        12114: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "tooltip-offset": "20px",
                dialog: "dialog-hxnnZcZ6",
                dragging: "dragging-hxnnZcZ6",
                dialogAnimatedAppearance: "dialogAnimatedAppearance-hxnnZcZ6",
                dialogAnimation: "dialogAnimation-hxnnZcZ6",
                dialogTooltip: "dialogTooltip-hxnnZcZ6"
            }
        },
        66230: e => {
            e.exports = {
                button: "button-h8C3IU2n",
                "button-children": "button-children-h8C3IU2n",
                hiddenArrow: "hiddenArrow-h8C3IU2n",
                invisibleFocusHandler: "invisibleFocusHandler-h8C3IU2n"
            }
        },
        99171: e => {
            e.exports = {
                button: "button-1ARG85Og",
                disabled: "disabled-1ARG85Og",
                hidden: "hidden-1ARG85Og",
                icon: "icon-1ARG85Og",
                dropped: "dropped-1ARG85Og"
            }
        },
        79756: e => {
            e.exports = {
                placeholder: "placeholder-fKHYe1Lk"
            }
        },
        8323: (e, t, n) => {
            "use strict";
            n.d(t, {
                CheckboxInput: () => c
            });
            var o = n(59496),
                s = n(97754),
                r = n(72571),
                i = n(57369),
                a = n(37593),
                l = n.n(a);

            function c(e) {
                const t = s(l().box, l()["intent-" + e.intent], {
                        [l().check]: !Boolean(e.indeterminate),
                        [l().dot]: Boolean(e.indeterminate),
                        [l().noOutline]: -1 === e.tabIndex
                    }),
                    n = s(l().wrapper, e.className);
                return o.createElement("span", {
                    className: n,
                    title: e.title
                }, o.createElement("input", {
                    id: e.id,
                    tabIndex: e.tabIndex,
                    className: l().input,
                    type: "checkbox",
                    name: e.name,
                    checked: e.checked,
                    disabled: e.disabled,
                    value: e.value,
                    autoFocus: e.autoFocus,
                    role: e.role,
                    onChange: function() {
                        e.onChange && e.onChange(e.value)
                    },
                    ref: e.reference
                }), o.createElement("span", {
                    className: t
                }, o.createElement(r.Icon, {
                    icon: i,
                    className: l().icon
                })))
            }
        },
        2946: (e, t, n) => {
            "use strict";
            n.d(t, {
                Checkbox: () => c
            });
            var o = n(59496),
                s = n(97754),
                r = n(32834),
                i = n(8323),
                a = n(96670),
                l = n.n(a);
            class c extends o.PureComponent {
                render() {
                    const {
                        inputClassName: e,
                        labelClassName: t,
                        ...n
                    } = this.props, r = s(this.props.className, l().checkbox, {
                        [l().reverse]: Boolean(this.props.labelPositionReverse),
                        [l().baseline]: Boolean(this.props.labelAlignBaseline)
                    }), a = s(l().label, t, {
                        [l().disabled]: this.props.disabled
                    });
                    let c = null;
                    return this.props.label && (c = o.createElement("span", {
                        className: a,
                        title: this.props.title
                    }, this.props.label)), o.createElement("label", {
                        className: r
                    }, o.createElement(i.CheckboxInput, { ...n,
                        className: e
                    }), c)
                }
            }
            c.defaultProps = {
                value: "on"
            };
            (0, r.makeSwitchGroupItem)(c)
        },
        58213: (e, t, n) => {
            "use strict";
            n.d(t, {
                Textarea: () => C
            });
            var o, s = n(59496),
                r = n(97754),
                i = n(28606),
                a = n(83836),
                l = n(21778),
                c = n(3548),
                u = n(69842),
                d = n(1811),
                p = n(34735),
                h = n(2691),
                m = n(12857),
                g = n.n(m);
            ! function(e) {
                e.None = "none", e.Vertical = "vertical", e.Horizontal = "horizontal", e.Both = "both"
            }(o || (o = {}));
            const f = s.forwardRef((e, t) => {
                const {
                    id: n,
                    title: o,
                    tabIndex: i,
                    containerTabIndex: a,
                    role: l,
                    inputClassName: c,
                    autoComplete: u,
                    autoFocus: d,
                    cols: m,
                    disabled: f,
                    isFocused: b,
                    form: v,
                    maxLength: C,
                    minLength: y,
                    name: _,
                    placeholder: x,
                    readonly: E,
                    required: S,
                    rows: w,
                    value: N,
                    defaultValue: T,
                    wrap: k,
                    containerReference: P,
                    onChange: I,
                    onSelect: R,
                    onFocus: B,
                    onContainerFocus: D,
                    onBlur: M,
                    "aria-describedby": O,
                    ...A
                } = e, z = {
                    id: n,
                    title: o,
                    tabIndex: i,
                    role: l,
                    autoComplete: u,
                    autoFocus: d,
                    cols: m,
                    disabled: f,
                    form: v,
                    maxLength: C,
                    minLength: y,
                    name: _,
                    placeholder: x,
                    readOnly: E,
                    required: S,
                    rows: w,
                    value: N,
                    defaultValue: T,
                    wrap: k,
                    onChange: I,
                    onSelect: R,
                    onFocus: B,
                    onBlur: M,
                    "aria-describedby": O
                };
                return s.createElement(p.ControlSkeleton, { ...A,
                    tabIndex: a,
                    disabled: f,
                    readonly: E,
                    isFocused: b,
                    ref: P,
                    onFocus: D,
                    middleSlot: s.createElement(h.MiddleSlot, null, s.createElement("textarea", { ...z,
                        className: r(g().textarea, c),
                        ref: t
                    }))
                })
            });
            f.displayName = "TextareaView";
            const b = (e, t, n) => t ? void 0 : e ? -1 : n,
                v = (e, t, n) => t ? void 0 : e ? n : -1,
                C = s.forwardRef((e, t) => {
                    e = (0,
                        l.useControl)(e);
                    const {
                        className: n,
                        disabled: p,
                        autoSelectOnFocus: h,
                        tabIndex: m = 0,
                        borderStyle: C,
                        highlight: y,
                        resize: _,
                        containerReference: x = null,
                        onFocus: E,
                        onBlur: S,
                        ...w
                    } = e, N = (0, s.useRef)(null), T = (0, s.useRef)(null), {
                        isMouseDown: k,
                        handleMouseDown: P,
                        handleMouseUp: I
                    } = (0, c.useIsMouseDown)(), [R, B] = (0, a.useFocus)(), D = (0, u.createSafeMulticastEventHandler)(B.onFocus, (function(e) {
                        h && !k.current && (0, d.selectAllContent)(e.currentTarget)
                    }), E), M = (0, u.createSafeMulticastEventHandler)(B.onBlur, S), O = void 0 !== _ && _ !== o.None, A = null != C ? C : O ? y ? "thick" : "thin" : void 0, z = null != y ? y : !O && void 0;
                    return s.createElement(f, { ...w,
                        className: r(g()["textarea-container"], O && g()["change-highlight"], _ && _ !== o.None && g()["resize-" + _], R && g().focused, n),
                        disabled: p,
                        isFocused: R,
                        containerTabIndex: b(R, p, m),
                        tabIndex: v(R, p, m),
                        borderStyle: A,
                        highlight: z,
                        onContainerFocus: function(e) {
                            T.current === e.target && null !== N.current && N.current.focus()
                        },
                        onFocus: D,
                        onBlur: M,
                        onMouseDown: P,
                        onMouseUp: I,
                        ref: function(e) {
                            N.current = e, "function" == typeof t ? t(e) : t && (t.current = e)
                        },
                        containerReference: (0, i.useMergedRefs)([x, T])
                    })
                });
            C.displayName = "Textarea"
        },
        32834: (e, t, n) => {
            "use strict";
            n.d(t, {
                SwitchGroup: () => r,
                makeSwitchGroupItem: () => i
            });
            var o = n(59496),
                s = n(19036);
            class r extends o.PureComponent {
                constructor() {
                    super(...arguments), this._subscriptions = new Set, this._getName = () => this.props.name, this._getValues = () => this.props.values, this._getOnChange = () => this.props.onChange, this._subscribe = e => {
                        this._subscriptions.add(e)
                    }, this._unsubscribe = e => {
                        this._subscriptions.delete(e)
                    }
                }
                getChildContext() {
                    return {
                        switchGroupContext: {
                            getName: this._getName,
                            getValues: this._getValues,
                            getOnChange: this._getOnChange,
                            subscribe: this._subscribe,
                            unsubscribe: this._unsubscribe
                        }
                    }
                }
                render() {
                    return this.props.children
                }
                componentDidUpdate(e) {
                    this._notify(this._getUpdates(this.props.values, e.values))
                }
                _notify(e) {
                    this._subscriptions.forEach(t => t(e))
                }
                _getUpdates(e, t) {
                    return [...t, ...e].filter(n => t.includes(n) ? !e.includes(n) : e.includes(n))
                }
            }

            function i(e) {
                var t;
                return (t = class extends o.PureComponent {
                    constructor() {
                        super(...arguments), this._onChange = e => {
                            this.context.switchGroupContext.getOnChange()(e)
                        }, this._onUpdate = e => {
                            e.includes(this.props.value) && this.forceUpdate()
                        }
                    }
                    componentDidMount() {
                        this.context.switchGroupContext.subscribe(this._onUpdate)
                    }
                    render() {
                        return o.createElement(e, { ...this.props,
                            name: this._getName(),
                            onChange: this._onChange,
                            checked: this._isChecked()
                        })
                    }
                    componentWillUnmount() {
                        this.context.switchGroupContext.unsubscribe(this._onUpdate)
                    }
                    _getName() {
                        return this.context.switchGroupContext.getName()
                    }
                    _isChecked() {
                        return this.context.switchGroupContext.getValues().includes(this.props.value)
                    }
                }).contextTypes = {
                    switchGroupContext: s.any.isRequired
                }, t
            }
            r.childContextTypes = {
                switchGroupContext: s.any.isRequired
            }
        },
        14823: (e, t, n) => {
            "use strict";
            n.d(t, {
                createDomId: () => l,
                joinDomIds: () => c
            });
            const o = /\s/g;

            function s(e) {
                return "string" == typeof e
            }

            function r(e) {
                switch (typeof e) {
                    case "string":
                        return e;
                    case "number":
                    case "bigint":
                        return e.toString(10);
                    case "boolean":
                    case "symbol":
                        return e.toString();
                    default:
                        return null
                }
            }

            function i(e) {
                return e.trim().length > 0
            }

            function a(e) {
                return e.replace(o, "-")
            }

            function l(...e) {
                const t = e.map(r).filter(s).filter(i).map(a);
                return (t.length > 0 && t[0].startsWith("id_") ? t : ["id", ...t]).join("_")
            }

            function c(...e) {
                return e.map(r).filter(s).filter(i).join(" ")
            }
        },
        72249: (e, t, n) => {
            "use strict";
            n.d(t, {
                splitThousands: () => s
            });
            var o = n(93751);

            function s(e, t = "&nbsp;") {
                let n = e + ""; - 1 !== n.indexOf("e") && (n = function(e) {
                    return (0, o.fixComputationError)(e).toFixed(10).replace(/\.?0+$/, "")
                }(Number(e)));
                const s = n.split(".");
                return s[0].replace(/\B(?=(\d{3})+(?!\d))/g, t) + (s[1] ? "." + s[1] : "")
            }
        },
        43963: (e, t, n) => {
            "use strict";
            n.d(t, {
                bind: () => i,
                setter: () => a
            });
            var o = n(59496),
                s = n(33376),
                r = n(86176);

            function i(e) {
                var t;
                return (t = class extends o.PureComponent {
                    constructor() {
                        super(...arguments), this._onChange = (e, t, n) => {
                            const {
                                setValue: o
                            } = this.context, {
                                onChange: s
                            } = this.props;
                            a(o, s)(e, t, n)
                        }
                    }
                    render() {
                        const {
                            input: t
                        } = this.props, {
                            values: n,
                            model: s
                        } = this.context;
                        return o.createElement(e, { ...this.props,
                            value: n[t.id],
                            tzName: (0, r.getTimezoneName)(s),
                            onChange: this._onChange
                        })
                    }
                }).contextType = s.PropertyContext, t
            }

            function a(e, t) {
                return (n, o, s) => {
                    e(o, n, s), t && t(n, o, s)
                }
            }
        },
        33376: (e, t, n) => {
            "use strict";
            n.d(t, {
                PropertyContext: () => c,
                PropertyContainer: () => u
            });
            var o = n(59496),
                s = n(88537),
                r = n(25177),
                i = n(18517);
            const a = (0, n(51951).getLogger)("Platform.GUI.StudyInputPropertyContainer"),
                l = new i.TranslatedString("change {propertyName} property", (0, r.t)("change {propertyName} property")),
                c = o.createContext(null);
            class u extends o.PureComponent {
                constructor(e) {
                    super(e), this._setValue = (e, t, n) => {
                        const {
                            property: o,
                            model: c
                        } = this.props, u = (0, s.ensureDefined)(o.child(e));
                        a.logNormal(`Changing property "${e}" value from "${o.value()}" to "${t}"`);
                        const d = new i.TranslatedString(n, function(e) {
                            return (0, r.t)(e, {
                                context: "input"
                            })
                        }(n));
                        c.setProperty(u, t, l.format({
                            propertyName: d
                        }))
                    };
                    const {
                        property: t
                    } = e, n = {};
                    t.childNames().forEach(e => {
                        const o = (0, s.ensureDefined)(t.child(e));
                        n.hasOwnProperty(e) || (n[e] = o.value())
                    }), this.state = n
                }
                componentDidMount() {
                    const {
                        property: e,
                        onStudyInputChange: t
                    } = this.props;
                    e.childNames().forEach(n => {
                        (0, s.ensureDefined)(e.child(n)).subscribe(this, e => {
                            const o = e.value();
                            a.logNormal(`Property "${n}" updated to value "${o}"`), this.setState({
                                [n]: o
                            }), null == t || t(o, n)
                        })
                    })
                }
                componentWillUnmount() {
                    const {
                        property: e
                    } = this.props;
                    e.childNames().forEach(t => {
                        (0, s.ensureDefined)(e.child(t)).unsubscribeAll(this)
                    })
                }
                render() {
                    const {
                        study: e,
                        model: t,
                        children: n
                    } = this.props, s = {
                        study: e,
                        model: t,
                        values: this.state,
                        setValue: this._setValue
                    };
                    return o.createElement(c.Provider, {
                        value: s
                    }, n)
                }
            }
        },
        59816: (e, t, n) => {
            "use strict";
            n.d(t, {
                ModelContext: () => s,
                bindModel: () => r
            });
            var o = n(59496);
            const s = o.createContext(null);

            function r(e, t) {
                return o.createElement(s.Consumer, null, n => n ? o.createElement(e, { ...Object.assign({
                        model: n
                    }, t)
                }) : null)
            }
        },
        26175: (e, t, n) => {
            "use strict";
            n.d(t, {
                StylePropertyContext: () => r,
                StylePropertyContainer: () => i,
                bindPropertyContext: () => a
            });
            var o = n(59496),
                s = n(59816);
            const r = o.createContext(null);
            class i extends o.PureComponent {
                constructor() {
                    super(...arguments), this._setValue = (e, t, n) => {
                        const {
                            model: o
                        } = this.props;
                        o.setProperty(e, t, n)
                    }
                }
                componentDidMount() {
                    const {
                        property: e
                    } = this.props;
                    e.subscribe(this, () => this.forceUpdate())
                }
                componentWillUnmount() {
                    const {
                        property: e
                    } = this.props;
                    e.unsubscribeAll(this)
                }
                render() {
                    const e = {
                        setValue: this._setValue
                    };
                    return o.createElement(r.Provider, {
                        value: e
                    }, this.props.children)
                }
            }

            function a(e, t) {
                return (0, s.bindModel)(({
                    model: n
                }) => o.createElement(i, {
                    model: n,
                    property: t.property
                }, o.createElement(e, { ...t
                })), t)
            }
        },
        14460: (e, t, n) => {
            "use strict";
            n.d(t, {
                InputTooltip: () => h
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(72571),
                a = n(44471),
                l = n(72535),
                c = n(70199),
                u = n(47189);

            function d() {
                document.removeEventListener("scroll", d), document.removeEventListener("touchstart", d), (0, a.hide)()
            }

            function p(e) {
                l.mobiletouch && ((0, a.showOnElement)(e.currentTarget, {
                    tooltipDelay: 0
                }), document.addEventListener("scroll", d), document.addEventListener("touchstart", d))
            }

            function h(e) {
                const {
                    className: t,
                    title: n
                } = e;
                return o.createElement(i.Icon, {
                    icon: u,
                    className: r()(t, "apply-common-tooltip", c.icon),
                    title: n,
                    onClick: p
                })
            }
        },
        11786: (e, t, n) => {
            "use strict";
            n.d(t, {
                isGroup: () => s,
                isInputInlines: () => r,
                getInputGroups: () => i
            });
            var o = n(88537);

            function s(e) {
                return e.hasOwnProperty("groupType")
            }

            function r(e) {
                return s(e) && "inline" === e.groupType
            }

            function i(e) {
                const t = [],
                    n = new Map,
                    s = new Map;
                return s.set(void 0, new Map), e.forEach(e => {
                    const {
                        group: r,
                        inline: i
                    } = e;
                    if (void 0 !== r || void 0 !== i)
                        if (void 0 !== r)
                            if (void 0 !== i)
                                if (n.has(r)) {
                                    const t = (0, o.ensureDefined)(n.get(r));
                                    let l;
                                    s.has(t) ? l = (0, o.ensureDefined)(s.get(t)) : (l = new Map, s.set(t, l)), a(e, "inline", i, l, t.children)
                                } else {
                                    const o = {
                                            id: i,
                                            groupType: "inline",
                                            children: [e]
                                        },
                                        a = {
                                            id: r,
                                            groupType: "group",
                                            children: [o]
                                        },
                                        l = new Map;
                                    l.set(i, o), s.set(a, l), n.set(r, a), t.push(a)
                                }
                    else a(e, "group", r, n, t);
                    else {
                        const n = (0, o.ensureDefined)(s.get(void 0));
                        a(e, "inline", (0, o.ensureDefined)(i), n, t)
                    } else t.push(e)
                }), t
            }

            function a(e, t, n, s, r) {
                if (s.has(n))(0, o.ensureDefined)(s.get(n)).children.push(e);
                else {
                    const o = {
                        id: n,
                        groupType: t,
                        children: [e]
                    };
                    s.set(n, o), r.push(o)
                }
            }
        },
        39747: (e, t, n) => {
            "use strict";
            n.d(t, {
                InputRow: () => K
            });
            var o = n(25177),
                s = n(59496),
                r = n(88537),
                i = n(4926),
                a = n(74598),
                l = n(15955),
                c = n(29699),
                u = n(97754),
                d = n.n(u),
                p = n(54936),
                h = n(43963),
                m = n(57229),
                g = n(6041);
            class f extends s.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            input: {
                                id: t,
                                name: n
                            },
                            onChange: o
                        } = this.props;
                        o(e.currentTarget.value, t, n)
                    }
                }
                render() {
                    const {
                        input: {
                            defval: e
                        },
                        value: t,
                        disabled: n,
                        onBlur: o,
                        onKeyDown: r,
                        hasTooltip: i
                    } = this.props;
                    return s.createElement(p.InputControl, {
                        className: d()(g.input, i && g.hasTooltip),
                        value: void 0 === t ? e : t,
                        onChange: this._onChange,
                        onBlur: o,
                        onKeyDown: r,
                        disabled: n
                    })
                }
            }
            const b = (0, m.debounced)(f),
                v = (0, h.bind)(b);
            var C = n(2406),
                y = n(13143);

            function _(e) {
                const {
                    className: t
                } = e, n = (0, s.useContext)(y.PropertyTable.InlineRowContext);
                return s.createElement("div", {
                    className: u(g.inputGroup, n && g.inlineGroup, t)
                }, e.children)
            }
            var x = n(44807);

            function E(e = "") {
                const [, t = "", n = "", o = "", s = ""] = Array.from(e.match(/^(\d\d)(\d\d)-(\d\d)(\d\d)/) || []);
                return [`${t}:${n}`, `${o}:${s}`]
            }
            class S extends s.PureComponent {
                constructor(e) {
                    super(e), this._onStartPick = e => {
                        this.setState({
                            startTime: e
                        }, this._onChange)
                    }, this._onEndPick = e => {
                        this.setState({
                            endTime: e
                        }, this._onChange)
                    }, this._onChange = () => {
                        const {
                            input: {
                                id: e,
                                name: t
                            },
                            onChange: n
                        } = this.props, {
                            startTime: o,
                            endTime: s
                        } = this.state;
                        n(o.replace(":", "") + "-" + s.replace(":", ""), e, t)
                    };
                    const t = e.value || e.input.defval,
                        [n, o] = E(t);
                    this.state = {
                        prevValue: t,
                        startTime: n,
                        endTime: o
                    }
                }
                render() {
                    const {
                        startTime: e,
                        endTime: t
                    } = this.state, {
                        hasTooltip: n,
                        disabled: o
                    } = this.props;
                    return s.createElement(_, {
                        className: d()(n && g.hasTooltip)
                    }, s.createElement("div", {
                        className: g.sessionStart
                    }, s.createElement(x.TimeInput, {
                        className: d()(g.input, g.sessionInputContainer),
                        name: "start",
                        value: (0, r.ensureDefined)(e),
                        onChange: this._onStartPick,
                        disabled: o
                    }), s.createElement("span", {
                        className: g.sessionDash
                    }, " — ")), s.createElement("div", {
                        className: g.sessionEnd
                    }, s.createElement(x.TimeInput, {
                        className: d()(g.input, g.sessionInputContainer),
                        name: "end",
                        value: (0, r.ensureDefined)(t),
                        onChange: this._onEndPick,
                        disabled: o
                    })))
                }
                static getDerivedStateFromProps(e, t) {
                    if (e.value === t.prevValue) return t;
                    const [n, o] = E(e.value);
                    return {
                        prevValue: e.value,
                        startTime: n,
                        endTime: o
                    }
                }
            }
            const w = (0, h.bind)(S);
            var N = n(82527),
                T = n(10392),
                k = n.n(T),
                P = n(33376),
                I = n(36118);
            class R extends s.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            input: {
                                id: t,
                                name: n
                            },
                            onChange: o
                        } = this.props;
                        o(e, t, n)
                    }
                }
                render() {
                    const {
                        input: {
                            id: e,
                            defval: t,
                            options: n,
                            optionsTitles: r
                        },
                        value: i,
                        disabled: a,
                        hasTooltip: l
                    } = this.props, c = n.map(e => {
                        const t = r && r[e] ? r[e] : e;
                        return {
                            value: e,
                            content: (0, o.t)(t, {
                                context: "input"
                            })
                        }
                    }), u = void 0 !== i && n.includes(i) ? i : t;
                    return s.createElement(I.Select, {
                        id: e,
                        className: d()(g.input, l && g.hasTooltip),
                        menuClassName: g.dropdownMenu,
                        value: u,
                        items: c,
                        onChange: this._onChange,
                        disabled: a
                    })
                }
            }
            const B = (0, h.bind)(R);
            var D = n(55640);
            const M = {
                open: (0, o.t)("open"),
                high: (0, o.t)("high"),
                low: (0, o.t)("low"),
                close: (0, o.t)("close"),
                hl2: (0, o.t)("hl2"),
                hlc3: (0, o.t)("hlc3"),
                ohlc4: (0, o.t)("ohlc4"),
                hlcc4: (0, o.t)("hlcc4")
            };
            class O extends s.PureComponent {
                render() {
                    const {
                        input: e
                    } = this.props, {
                        study: t,
                        model: n
                    } = this.context;
                    let o = { ...M
                    };
                    delete o.hlcc4;
                    const i = (0, D.createAdapter)(t);
                    if (t && this._isStudy(t) && t.isChildStudy()) {
                        const t = i.parentSource(),
                            n = t.title(),
                            s = k().getChildSourceInputTitles(e, t.metaInfo(), n);
                        o = { ...o,
                            ...s
                        }
                    }
                    if (N.enabled("study_on_study") && t && this._isStudy(t) && (t.isChildStudy() || k().canBeChild(t.metaInfo()))) {
                        const e = [t, ...i.getAllChildren()];
                        n.model().allStudies().filter(t => t.canHaveChildren() && !e.includes(t)).forEach(e => {
                            const t = e.title(!0, void 0, !0),
                                n = e.sourceId() || "#" + e.id(),
                                s = e.metaInfo(),
                                i = s.styles,
                                a = s.plots || [];
                            if (1 === a.length) o[n + "$0"] = t;
                            else if (a.length > 1) {
                                const e = a.reduce((e, o, s) => {
                                    if (!k().canPlotBeSourceOfChildStudy(o.type)) return e;
                                    let a;
                                    try {
                                        a = (0, r.ensureDefined)((0, r.ensureDefined)(i)[o.id]).title
                                    } catch (e) {
                                        a = o.id
                                    }
                                    return { ...e,
                                        [`${n}$${s}`]: `${t}: ${a}`
                                    }
                                }, {});
                                o = { ...o,
                                    ...e
                                }
                            }
                        })
                    }
                    const a = { ...e,
                        type: "text",
                        options: Object.keys(o),
                        optionsTitles: o
                    };
                    return s.createElement(B, { ...this.props,
                        input: a
                    })
                }
                _isStudy(e) {
                    return !e.hasOwnProperty("isInputsStudy")
                }
            }
            O.contextType = P.PropertyContext;
            var A = n(41083),
                z = n(2117);
            const L = void 0,
                F = ["1", "3", "5", "15", "30", "45", "60", "120", "180", "240", "1D", "1W", "1M"];
            class G extends s.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            input: {
                                id: t,
                                name: n
                            },
                            onChange: o
                        } = this.props;
                        o(e, t, n)
                    }
                }
                render() {
                    const {
                        input: e,
                        value: t,
                        disabled: n,
                        hasTooltip: r
                    } = this.props, i = A.Interval.parse(void 0 === t ? e.defval : t), a = i.isValid() ? i.value() : t, l = L ? L.get().filter(e => !A.Interval.parse(e).isRange()) : [], c = (0, z.mergeResolutions)(F, l);
                    return c.unshift(""), s.createElement(I.Select, {
                        id: e.id,
                        className: d()(g.input, g.resolution, r && g.hasTooltip),
                        menuClassName: d()(g.dropdownMenu, g.resolution),
                        items: (u = c, u.map(e => ({
                            value: e,
                            content: "" === e ? (0, o.t)("Chart") : (0, z.getTranslatedResolutionModel)(e).hint
                        }))),
                        value: a,
                        onChange: this._onChange,
                        disabled: n
                    });
                    var u
                }
            }
            const W = (0, h.bind)(G);
            var H = n(91409),
                V = n(26175);
            class j extends s.PureComponent {
                render() {
                    return s.createElement(P.PropertyContext.Consumer, null, e => e ? this._getColorInputWithContext(e) : null)
                }
                _getColorInputWithContext(e) {
                    var t;
                    const {
                        input: {
                            id: n
                        },
                        disabled: o,
                        hasTooltip: r
                    } = this.props, {
                        model: i,
                        study: a
                    } = e;
                    if ("properties" in a || "tempProperties" in a) {
                        const e = "properties" in a ? a.properties().inputs[n] : null === (t = a.tempProperties) || void 0 === t ? void 0 : t.inputs.child(n);
                        return s.createElement(V.StylePropertyContainer, {
                            model: i,
                            property: e
                        }, s.createElement(H.ColorWithThicknessSelect, {
                            className: d()(r && g.hasTooltip),
                            color: e,
                            disabled: o
                        }))
                    }
                    return null
                }
            }
            class X extends s.PureComponent {
                render() {
                    const {
                        input: e,
                        disabled: t,
                        onChange: n,
                        tzName: o,
                        hasTooltip: r
                    } = this.props;
                    if ((0, i.isStudyInputOptionsInfo)(e)) return s.createElement(B, {
                        input: e,
                        disabled: t,
                        onChange: n,
                        hasTooltip: r
                    });
                    switch (e.type) {
                        case "integer":
                            return s.createElement(a.IntegerInput, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "float":
                        case "price":
                            return s.createElement(l.FloatInput, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "bool":
                            return s.createElement(c.BoolInput, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "text":
                            return s.createElement(v, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "symbol":
                            return s.createElement(C.SymbolInput, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "session":
                            return s.createElement(w, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "source":
                            return s.createElement(O, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "resolution":
                            return s.createElement(W, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        case "time":
                            return null;
                        case "color":
                            return s.createElement(j, {
                                input: e,
                                disabled: t,
                                onChange: n,
                                hasTooltip: r
                            });
                        default:
                            return null
                    }
                }
            }
            var U = n(14460);
            class K extends s.PureComponent {
                render() {
                    const {
                        label: e,
                        children: t,
                        input: n,
                        disabled: i,
                        onChange: a,
                        labelAlign: l,
                        grouped: c,
                        tooltip: u,
                        offset: d
                    } = this.props;
                    return s.createElement(y.PropertyTable.Row, null, s.createElement(y.PropertyTable.Cell, {
                        placement: "first",
                        verticalAlign: l,
                        grouped: c,
                        offset: d
                    }, void 0 !== e ? e : (0, o.t)((0, r.ensureDefined)(n).name, {
                        context: "input"
                    })), s.createElement(y.PropertyTable.Cell, {
                        placement: "last",
                        grouped: c
                    }, t || s.createElement(X, {
                        input: (0, r.ensureDefined)(n),
                        onChange: a,
                        disabled: i,
                        hasTooltip: Boolean(u)
                    }), u && s.createElement(U.InputTooltip, {
                        title: u
                    })))
                }
            }
        },
        34453: (e, t, n) => {
            "use strict";
            n.d(t, {
                InputsTabContent: () => F
            });
            var o, s = n(59496),
                r = n(25177),
                i = n(33376),
                a = n(13143),
                l = n(32834),
                c = n(97754),
                u = n.n(c),
                d = n(15994),
                p = n.n(d);
            const h = (0, l.makeSwitchGroupItem)(((o = class extends s.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = () => {
                        this.props.onChange && this.props.onChange(this.props.value)
                    }
                }
                render() {
                    const e = c(this.props.className, p().radio, {
                            [p().reverse]: Boolean(this.props.labelPositionReverse)
                        }),
                        t = c(p().label, {
                            [p().disabled]: this.props.disabled
                        }),
                        n = c(p().box, {
                            [p().noOutline]: -1 === this.props.tabIndex
                        });
                    let o = null;
                    return this.props.label && (o = s.createElement("span", {
                        className: t
                    }, this.props.label)), s.createElement("label", {
                        className: e
                    }, s.createElement("span", {
                        className: p().wrapper,
                        title: this.props.title
                    }, s.createElement("input", {
                        id: this.props.id,
                        tabIndex: this.props.tabIndex,
                        autoFocus: this.props.autoFocus,
                        role: this.props.role,
                        className: p().input,
                        type: "radio",
                        name: this.props.name,
                        checked: this.props.checked,
                        disabled: this.props.disabled,
                        value: this.props.value,
                        onChange: this._onChange,
                        ref: this.props.reference
                    }), s.createElement("span", {
                        className: n
                    })), o)
                }
            }).defaultProps = {
                value: "on"
            }, o));
            var m = n(88537),
                g = n(2406),
                f = n(43963),
                b = n(14460),
                v = n(6041);

            function C(e) {
                const {
                    children: t,
                    input: n,
                    disabled: o,
                    onChange: c,
                    grouped: u,
                    tooltip: d
                } = e, p = (0, s.useContext)(i.PropertyContext), {
                    values: C,
                    setValue: y
                } = (0, m.ensureNotNull)(p), _ = C[n.id], [x, E] = (0, s.useState)(_ ? "another-symbol" : "main-symbol"), [S, w] = (0, s.useState)(_);
                return (0, s.useEffect)(() => {
                    _ && w(_)
                }, [_]), s.createElement(l.SwitchGroup, {
                    name: "symbol-source-" + n.id,
                    values: [x],
                    onChange: function(e) {
                        E(e), "main-symbol" === e ? (0, f.setter)(y)("", n.id, n.name) : "another-symbol" === e && S && (0, f.setter)(y, c)(S, n.id, n.name)
                    }
                }, s.createElement(a.PropertyTable.Row, null, s.createElement(a.PropertyTable.Cell, {
                    colSpan: 2,
                    placement: "first",
                    grouped: u
                }, s.createElement(h, {
                    value: "main-symbol",
                    className: v.checkbox,
                    disabled: o,
                    label: s.createElement("span", {
                        className: v.label
                    }, (0, r.t)("Main chart symbol", {
                        context: "input"
                    }))
                }))), s.createElement(a.PropertyTable.Row, null, s.createElement(a.PropertyTable.Cell, {
                    placement: "first",
                    grouped: u
                }, s.createElement(h, {
                    value: "another-symbol",
                    className: v.checkbox,
                    disabled: o,
                    label: s.createElement("span", {
                        className: v.label
                    }, (0, r.t)("Another symbol", {
                        context: "input"
                    }))
                })), s.createElement(a.PropertyTable.Cell, {
                    placement: "last",
                    grouped: u
                }, t || s.createElement(g.SymbolInput, {
                    input: (0, m.ensureDefined)(n),
                    onChange: c,
                    disabled: o || "main-symbol" === x,
                    hasTooltip: Boolean(d)
                }), d && s.createElement(b.InputTooltip, {
                    title: d
                }))))
            }
            var y = n(29699);
            class _ extends s.PureComponent {
                render() {
                    const {
                        label: e,
                        input: t,
                        tooltip: n
                    } = this.props;
                    return s.createElement(a.PropertyTable.Row, null, s.createElement(a.PropertyTable.Cell, {
                        placement: "first",
                        colSpan: 2
                    }, s.createElement(y.BoolInput, {
                        label: e,
                        input: t,
                        hasTooltip: Boolean(n)
                    }), n && s.createElement(b.InputTooltip, {
                        title: n
                    })))
                }
            }
            var x = n(39747),
                E = n(58213),
                S = n(34735),
                w = n(57229);
            class N extends s.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = e => {
                        const {
                            input: {
                                id: t,
                                name: n
                            },
                            onChange: o
                        } = this.props;
                        o(e.currentTarget.value, t, n)
                    }
                }
                render() {
                    const {
                        input: {
                            defval: e
                        },
                        value: t,
                        disabled: n,
                        onBlur: o,
                        onKeyDown: r
                    } = this.props;
                    return s.createElement(E.Textarea, {
                        className: u()(v.input, v.textarea, S.InputClasses.FontSizeMedium),
                        value: void 0 === t ? e : t,
                        onChange: this._onChange,
                        onBlur: o,
                        onKeyDown: r,
                        disabled: n
                    })
                }
            }
            const T = (0, w.debounced)(N),
                k = (0, f.bind)(T);
            var P = n(300);

            function I(e) {
                const {
                    input: t,
                    label: n,
                    tooltip: o
                } = e;
                return s.createElement(a.PropertyTable.Row, null, s.createElement(a.PropertyTable.Cell, {
                    placement: "first",
                    colSpan: 2,
                    className: P.wrap
                }, s.createElement("div", {
                    className: P.labelWrap
                }, s.createElement("span", {
                    className: u()(P.label, o && P.hasTooltip)
                }, n), o && s.createElement(b.InputTooltip, {
                    title: o
                })), s.createElement(k, {
                    input: t
                })))
            }

            function R(e) {
                const {
                    input: t,
                    tooltip: n
                } = e;
                return "symbol" === t.type && t.optional ? s.createElement(C, {
                    input: t,
                    tooltip: n
                }) : "bool" === t.type ? s.createElement(_, {
                    label: (0, r.t)(t.name, {
                        context: "input"
                    }),
                    input: t,
                    tooltip: n
                }) : "text_area" === t.type ? s.createElement(I, {
                    label: (0, r.t)(t.name, {
                        context: "input"
                    }),
                    input: t,
                    tooltip: n
                }) : s.createElement(x.InputRow, {
                    labelAlign: function(e) {
                        switch (e) {
                            case "session":
                                return "adaptive";
                            case "time":
                                return "topCenter";
                            default:
                                return
                        }
                    }(t.type),
                    input: t,
                    tooltip: n
                })
            }
            var B = n(52830),
                D = n(23128);

            function M(e) {
                const {
                    content: t
                } = e;
                let n;
                return s.createElement(a.PropertyTable.InlineRowContext.Provider, {
                    value: !0
                }, s.createElement("div", {
                    className: D.inlineRow
                }, t.children.map((e, o) => (void 0 !== e.tooltip && (n = e.tooltip), s.createElement(R, {
                    key: e.id,
                    input: e,
                    tooltip: o === t.children.length - 1 ? n : void 0
                })))))
            }
            var O = n(11786),
                A = n(16300);

            function z(e) {
                const {
                    content: t
                } = e;
                return (0, O.isGroup)(t) ? (0, O.isInputInlines)(t) ? s.createElement(M, {
                    content: t
                }) : s.createElement(s.Fragment, null, s.createElement("div", {
                    className: A.titleWrap
                }, s.createElement(B.GroupTitleSection, {
                    title: (0, r.t)(t.id, {
                        context: "input"
                    }),
                    name: t.id
                })), t.children.map(e => (0, O.isGroup)(e) ? s.createElement(M, {
                    key: e.id,
                    content: e
                }) : s.createElement(R, {
                    key: e.id,
                    input: e,
                    tooltip: e.tooltip
                })), s.createElement("div", {
                    className: A.groupFooter
                })) : s.createElement(R, {
                    input: t,
                    tooltip: t.tooltip
                })
            }
            const L = {
                offset: (0, r.t)("Offset")
            };
            class F extends s.PureComponent {
                render() {
                    const {
                        reference: e,
                        inputs: t,
                        property: n,
                        study: o,
                        model: r,
                        onStudyInputChange: i,
                        className: l
                    } = this.props, {
                        offset: c,
                        offsets: u
                    } = n;
                    return s.createElement(a.PropertyTable, {
                        reference: e,
                        className: l
                    }, s.createElement(G, {
                        study: o,
                        model: r,
                        property: n.inputs,
                        inputs: t,
                        onStudyInputChange: i
                    }), c && this._createOffsetSection(c), u && u.childNames().map(e => {
                        const t = u.childs()[e];
                        return this._createOffsetSection(t)
                    }))
                }
                _createOffsetSection(e) {
                    const t = e.childs();
                    return s.createElement(G, {
                        key: "offset_" + t.title.value(),
                        study: this.props.study,
                        model: this.props.model,
                        inputs: [W(t)],
                        property: e
                    })
                }
            }

            function G(e) {
                const {
                    study: t,
                    model: n,
                    inputs: o,
                    property: r,
                    onStudyInputChange: a
                } = e, l = o, c = (0, s.useMemo)(() => (0, O.getInputGroups)(l), [l]);
                return s.createElement(i.PropertyContainer, {
                    property: r,
                    study: t,
                    model: n,
                    onStudyInputChange: a
                }, !1, c.map(e => s.createElement(z, {
                    key: e.id,
                    content: e
                })))
            }

            function W(e) {
                return {
                    id: "val",
                    name: e.title.value() || L.offset,
                    defval: e.val.value(),
                    type: "integer",
                    min: e.min.value(),
                    max: e.max.value()
                }
            }
        },
        29699: (e, t, n) => {
            "use strict";
            n.d(t, {
                BoolInputComponent: () => c,
                BoolInput: () => u
            });
            var o = n(59496),
                s = n(2946),
                r = n(97754),
                i = n.n(r),
                a = n(43963),
                l = n(6041);
            class c extends o.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = () => {
                        const {
                            input: {
                                id: e,
                                name: t
                            },
                            value: n,
                            onChange: o
                        } = this.props;
                        o(!n, e, t)
                    }
                }
                render() {
                    const {
                        input: {
                            defval: e
                        },
                        value: t,
                        disabled: n,
                        label: r,
                        hasTooltip: a
                    } = this.props, c = void 0 === t ? e : t;
                    return o.createElement(s.Checkbox, {
                        className: i()(l.checkbox, a && l.hasTooltip),
                        disabled: n,
                        checked: c,
                        onChange: this._onChange,
                        label: o.createElement("span", {
                            className: l.label
                        }, r),
                        labelAlignBaseline: !0
                    })
                }
            }
            const u = (0, a.bind)(c)
        },
        57229: (e, t, n) => {
            "use strict";
            n.d(t, {
                debounced: () => r
            });
            var o = n(59496);
            const s = {
                blur: 0,
                commit: 0,
                change: 1 / 0
            };

            function r(e, t = s) {
                return class extends o.PureComponent {
                    constructor(e) {
                        super(e), this._onChange = (e, n, o) => {
                            const s = t.change;
                            s ? (clearTimeout(this._timeout), this.setState({
                                value: e
                            }, () => {
                                s !== 1 / 0 && (this._timeout = setTimeout(() => this._flush(), s))
                            })) : this._flush(e)
                        }, this._onBlur = () => {
                            this._debounce(t.blur);
                            const {
                                onBlur: e
                            } = this.props;
                            e && e()
                        }, this._onKeyDown = e => {
                            13 === e.keyCode && this._debounce(t.commit)
                        }, this.state = {
                            prevValue: e.value,
                            value: e.value
                        }
                    }
                    componentWillUnmount() {
                        this._flush()
                    }
                    render() {
                        const {
                            value: t
                        } = this.state;
                        return o.createElement(e, { ...this.props,
                            value: t,
                            onChange: this._onChange,
                            onBlur: this._onBlur,
                            onKeyDown: this._onKeyDown
                        })
                    }
                    static getDerivedStateFromProps(e, t) {
                        return e.value === t.prevValue ? t : {
                            prevValue: e.value,
                            value: e.value
                        }
                    }
                    _debounce(e) {
                        e ? (clearTimeout(this._timeout), e !== 1 / 0 && (this._timeout = setTimeout(() => this._flush(), e))) : this.setState(e => {
                            this._flush(e.value)
                        })
                    }
                    _flush(e) {
                        const {
                            input: {
                                id: t,
                                name: n
                            },
                            onChange: o
                        } = this.props, {
                            prevValue: s,
                            value: r
                        } = this.state;
                        clearTimeout(this._timeout);
                        const i = void 0 !== e ? e : r;
                        void 0 !== i && i !== s && o(i, t, n)
                    }
                }
            }
        },
        15955: (e, t, n) => {
            "use strict";
            n.d(t, {
                FloatInputComponent: () => d,
                FloatInput: () => p
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(96072),
                a = n(43963),
                l = n(57229),
                c = n(6041);
            class u extends o.PureComponent {
                render() {
                    const {
                        hasTooltip: e
                    } = this.props;
                    return o.createElement(i.NumericInput, { ...this.props,
                        className: r()(c.input, e && c.hasTooltip),
                        stretch: !1
                    })
                }
            }
            const d = (0, l.debounced)(u, {
                    change: 1 / 0,
                    commit: 0,
                    blur: 0
                }),
                p = (0, a.bind)(d)
        },
        74598: (e, t, n) => {
            "use strict";
            n.d(t, {
                IntegerInputComponent: () => d,
                IntegerInput: () => p
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(43963),
                a = n(57229),
                l = n(96072),
                c = n(6041);
            class u extends o.PureComponent {
                render() {
                    const {
                        hasTooltip: e
                    } = this.props;
                    return o.createElement(l.NumericInput, { ...this.props,
                        mode: "integer",
                        className: r()(c.input, e && c.hasTooltip),
                        stretch: !1
                    })
                }
            }
            const d = (0, a.debounced)(u, {
                    change: 1 / 0,
                    commit: 0,
                    blur: 0
                }),
                p = (0, i.bind)(d)
        },
        96072: (e, t, n) => {
            "use strict";
            n.d(t, {
                NumericInput: () => i
            });
            var o = n(59496),
                s = n(88537),
                r = n(87125);
            class i extends o.PureComponent {
                constructor() {
                    super(...arguments), this._container = null, this._handleContainerRef = e => this._container = e, this._onChange = (e, t) => {
                        const {
                            input: {
                                id: n,
                                name: o
                            },
                            onChange: s,
                            onBlur: r
                        } = this.props;
                        s(e, n, o), "step" === t && r && r()
                    }, this._onBlur = e => {
                        const {
                            onBlur: t
                        } = this.props;
                        if (t) {
                            const n = (0, s.ensureNotNull)(this._container);
                            n.contains(document.activeElement) || n.contains(e.relatedTarget) || t()
                        }
                    }
                }
                render() {
                    const {
                        input: {
                            defval: e,
                            min: t,
                            max: n,
                            step: s
                        },
                        value: i,
                        disabled: a,
                        onKeyDown: l,
                        className: c,
                        mode: u,
                        stretch: d
                    } = this.props;
                    return o.createElement(r.NumberInput, {
                        className: c,
                        value: Number(void 0 === i ? e : i),
                        min: t,
                        max: n,
                        step: s,
                        mode: u,
                        onBlur: this._onBlur,
                        onValueChange: this._onChange,
                        onKeyDown: l,
                        disabled: a,
                        containerReference: this._handleContainerRef,
                        fontSizeStyle: "medium",
                        roundByStep: !1,
                        stretch: d
                    })
                }
            }
        },
        2406: (e, t, n) => {
            "use strict";
            n.d(t, {
                getSymbolName: () => c,
                SymbolInput: () => u
            });
            var o = n(59496),
                s = n(88537),
                r = n(33376),
                i = n(43963),
                a = n(55640),
                l = n(93315);

            function c(e, t) {
                const n = (0, a.createAdapter)(t).resolvedSymbolInfoBySymbol(e);
                return n && (n.ticker || n.full_name) ? n.ticker || n.full_name : e
            }
            const u = (0, i.bind)((function(e) {
                const t = (0, o.useContext)(r.PropertyContext),
                    {
                        study: n
                    } = (0, s.ensureNotNull)(t),
                    {
                        input: {
                            defval: i
                        },
                        value: a
                    } = e;
                return o.createElement(l.SymbolInputsButton, { ...e,
                    value: c(a || i || "", n),
                    study: n
                })
            }))
        },
        91409: (e, t, n) => {
            "use strict";
            n.d(t, {
                ColorWithThicknessSelect: () => f
            });
            var o = n(59496),
                s = n(24377),
                r = n(25177),
                i = n(18517),
                a = n(76036),
                l = n(26175),
                c = n(52315),
                u = n(56988),
                d = n(32133);
            const p = new i.TranslatedString("change thickness", (0, r.t)("change thickness")),
                h = new i.TranslatedString("change color", (0, r.t)("change color")),
                m = new i.TranslatedString("change opacity", (0, r.t)("change opacity")),
                g = [1, 2, 3, 4];
            class f extends o.PureComponent {
                constructor() {
                    super(...arguments), this._trackEventLabel = null, this._getTransparencyValue = () => {
                        const {
                            transparency: e
                        } = this.props;
                        return e ? e.value() : 0
                    }, this._getOpacityValue = () => {
                        const {
                            color: e
                        } = this.props, t = (0, u.getPropertyValue)(e);
                        if (t) return (0, a.isHexColor)(t) ? (0, a.transparencyToAlpha)(this._getTransparencyValue()) : (0, s.parseRgba)(t)[3]
                    }, this._getColorValueInHex = () => {
                        const {
                            color: e
                        } = this.props, t = (0, u.getPropertyValue)(e);
                        return t ? (0, a.isHexColor)(t) ? t : (0, s.rgbToHexString)((0, s.parseRgb)(t)) : null
                    }, this._onThicknessChange = e => {
                        const {
                            thickness: t
                        } = this.props;
                        void 0 !== t && this._setProperty(t, e, p)
                    }, this._onColorChange = e => {
                        const {
                            color: t,
                            isPaletteColor: n
                        } = this.props, o = (0, u.getPropertyValue)(t);
                        let r = 0;
                        o && (r = (0, a.isHexColor)(o) ? this._getTransparencyValue() : (0, a.alphaToTransparency)((0, s.parseRgba)(o)[3])), this._setProperty(t, (0, a.generateColor)(String(e), r, !0), h), this._trackEventLabel = "Plot color > " + (n ? "Palette" : "Single")
                    }, this._onOpacityChange = e => {
                        const {
                            color: t
                        } = this.props, n = (0, u.getPropertyValue)(t);
                        this._setProperty(t, (0, a.generateColor)(n, (0, a.alphaToTransparency)(e), !0), m)
                    }, this._onPopupClose = () => {
                        this._trackEventLabel && ((0, d.trackEvent)("GUI", "Study settings", this._trackEventLabel), this._trackEventLabel = null)
                    }
                }
                componentWillUnmount() {
                    this._onPopupClose()
                }
                render() {
                    const {
                        selectOpacity: e = !0,
                        disabled: t,
                        className: n
                    } = this.props;
                    return o.createElement(c.ColorSelect, {
                        className: n,
                        disabled: t,
                        color: this._getColorValueInHex(),
                        selectOpacity: e,
                        opacity: this._getOpacityValue(),
                        thickness: this._getThicknessValue(),
                        thicknessItems: g,
                        onColorChange: this._onColorChange,
                        onOpacityChange: this._onOpacityChange,
                        onThicknessChange: this._onThicknessChange,
                        onPopupClose: this._onPopupClose
                    })
                }
                _getThicknessValue() {
                    const {
                        thickness: e
                    } = this.props;
                    return e ? (0, u.getPropertyValue)(e) : void 0
                }
                _setProperty(e, t, n) {
                    const {
                        setValue: o
                    } = this.context;
                    (0, u.setPropertyValue)(e, e => o(e, t, n))
                }
            }
            f.contextType = l.StylePropertyContext
        },
        13143: (e, t, n) => {
            "use strict";
            n.d(t, {
                PropertyTable: () => l
            });
            var o = n(59496),
                s = n(97754),
                r = n(417),
                i = n(46828);
            const a = o.createContext(!1);
            class l extends o.PureComponent {
                render() {
                    return o.createElement("div", {
                        ref: this.props.reference,
                        className: s(i.content, this.props.className)
                    }, this.props.children)
                }
            }
            l.InlineRowContext = a, l.Row = function(e) {
                const {
                    children: t
                } = e;
                return (0, o.useContext)(a) ? o.createElement("span", {
                    className: i.inlineRow
                }, t) : o.createElement(o.Fragment, null, t)
            }, l.Cell = function(e) {
                const t = (0, o.useContext)(a),
                    n = s(i.cell, e.offset && i.offset, e.grouped && i.grouped, t && i.inlineCell, "top" === e.verticalAlign && i.top, "topCenter" === e.verticalAlign && i.topCenter, "adaptive" === e.verticalAlign && i.adaptive, e.checkableTitle && i.checkableTitle, 2 === e.colSpan && i.fill, "first" === e.placement && 2 !== e.colSpan && i.first, "last" === e.placement && 2 !== e.colSpan && i.last),
                    l = (0, r.filterDataProps)(e);
                return o.createElement("div", { ...l,
                    className: n
                }, o.createElement("div", {
                    className: s(i.inner, e.className)
                }, e.children))
            }, l.Separator = function(e) {
                return o.createElement(l.Row, null, o.createElement("div", {
                    className: s(i.cell, i.separator, i.fill)
                }))
            }, l.GroupSeparator = function(e) {
                const t = e.size || 0;
                return o.createElement(l.Row, null, o.createElement("div", {
                    className: s(i.cell, i.groupSeparator, i.fill, 1 === t && i.big)
                }))
            }
        },
        56988: (e, t, n) => {
            "use strict";

            function o(e) {
                return Array.isArray(e) ? e[0].value() : e.value()
            }

            function s(e, t) {
                if (Array.isArray(e))
                    for (const n of e) t(n);
                else t(e)
            }
            n.d(t, {
                getPropertyValue: () => o,
                setPropertyValue: () => s
            })
        },
        32207: (e, t, n) => {
            "use strict";
            n.d(t, {
                SplitThousandsFormatter: () => r
            });
            var o = n(72249),
                s = n(34581);
            class r {
                constructor(e = " ") {
                    this._divider = e
                }
                format(e) {
                    const t = (0, o.splitThousands)(e, this._divider);
                    return (0, s.isRtl)() ? (0, s.startWithLTR)(t) : t
                }
                parse(e) {
                    const t = (0, s.stripLTRMarks)(e).split(this._divider).join(""),
                        n = Number(t);
                    return isNaN(n) || /e/i.test(t) ? {
                        res: !1
                    } : {
                        res: !0,
                        value: n,
                        suggest: this.format(n)
                    }
                }
            }
        },
        76669: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                AdaptiveConfirmDialog: () => p
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(28599),
                a = n(88537),
                l = n(25177),
                c = n(80185),
                u = n(53337),
                d = n(91131);
            class p extends o.PureComponent {
                constructor() {
                    super(...arguments), this._dialogRef = o.createRef(), this._handleClose = () => {
                        const {
                            defaultActionOnClose: e,
                            onSubmit: t,
                            onCancel: n,
                            onClose: o
                        } = this.props;
                        switch (e) {
                            case "submit":
                                t();
                                break;
                            case "cancel":
                                n()
                        }
                        o()
                    }, this._handleCancel = () => {
                        this.props.onCancel(), this.props.onClose()
                    }, this._handleKeyDown = e => {
                        const {
                            onSubmit: t,
                            submitButtonDisabled: n,
                            submitOnEnterKey: o
                        } = this.props;
                        13 === (0, c.hashFromEvent)(e) && o && (e.preventDefault(), n || t())
                    }
                }
                render() {
                    const {
                        render: e,
                        onClose: t,
                        onSubmit: n,
                        onCancel: s,
                        footerLeftRenderer: r,
                        submitButtonText: i,
                        submitButtonDisabled: a,
                        defaultActionOnClose: l,
                        submitOnEnterKey: c,
                        ...d
                    } = this.props;
                    return o.createElement(u.AdaptivePopupDialog, { ...d,
                        ref: this._dialogRef,
                        onKeyDown: this._handleKeyDown,
                        render: this._renderChildren(),
                        onClose: this._handleClose
                    })
                }
                focus() {
                    (0, a.ensureNotNull)(this._dialogRef.current).focus()
                }
                _renderChildren() {
                    return e => {
                        const {
                            render: t,
                            footerLeftRenderer: n,
                            additionalButtons: s,
                            submitButtonText: a,
                            submitButtonDisabled: c,
                            onSubmit: u,
                            cancelButtonText: p,
                            showCancelButton: h = !0,
                            submitButtonClassName: m,
                            cancelButtonClassName: g,
                            buttonsWrapperClassName: f
                        } = this.props;
                        return o.createElement(o.Fragment, null, t(e), o.createElement("div", {
                            className: d.footer
                        }, n && n(e.isSmallWidth), o.createElement("div", {
                            className: r()(d.buttons, f)
                        }, s, h && o.createElement(i.Button, {
                            className: g,
                            name: "cancel",
                            appearance: "stroke",
                            onClick: this._handleCancel
                        }, null != p ? p : (0, l.t)("Cancel")), o.createElement("span", {
                            className: d.submitButton
                        }, o.createElement(i.Button, {
                            className: m,
                            disabled: c,
                            name: "submit",
                            onClick: u,
                            "data-name": "submit-button"
                        }, null != a ? a : (0, l.t)("Ok"))))))
                    }
                }
            }
            p.defaultProps = {
                defaultActionOnClose: "submit",
                submitOnEnterKey: !0
            }
        },
        27950: (e, t, n) => {
            "use strict";
            n.d(t, {
                EditButton: () => l
            });
            var o = n(59496),
                s = n(97754),
                r = n(72571),
                i = n(17354),
                a = n(55914);

            function l(e) {
                const {
                    value: t,
                    onClick: n,
                    className: l,
                    startSlot: c,
                    disabled: u = !1
                } = e;
                return o.createElement("div", {
                    className: s(a.wrap, u && a.disabled, l),
                    onClick: n,
                    "data-name": "edit-button"
                }, o.createElement("div", {
                    className: s(a.text, "apply-overflow-tooltip")
                }, void 0 !== c && c, o.createElement("span", null, t)), o.createElement(r.Icon, {
                    icon: i,
                    className: a.icon
                }))
            }
        },
        52315: (e, t, n) => {
            "use strict";
            n.d(t, {
                ColorSelect: () => w
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(88537),
                a = n(80185),
                l = n(44377),
                c = n(83836),
                u = n(57630),
                d = n(30553);

            function p(e) {
                const {
                    button: t,
                    children: n,
                    className: s,
                    onPopupClose: r,
                    ...p
                } = e, [h, m] = (0, o.useState)(!1), [g, f] = (0, o.useState)(!1), [b, v] = (0, c.useFocus)(), C = (0, o.useRef)(null);
                return o.createElement("div", {
                    className: s
                }, o.createElement("div", {
                    tabIndex: e.disabled ? void 0 : -1,
                    ref: C,
                    onClick: y,
                    onFocus: v.onFocus,
                    onBlur: v.onBlur,
                    onKeyDown: _
                }, "function" == typeof t ? t(g, b) : t), o.createElement(l.PopupMenu, {
                    isOpened: g,
                    onClose: x,
                    position: function() {
                        const e = (0, i.ensureNotNull)(C.current).getBoundingClientRect();
                        return {
                            x: e.left,
                            y: e.top + e.height
                        }
                    },
                    doNotCloseOn: C.current,
                    onKeyDown: _
                }, o.createElement(d.MenuContext.Consumer, null, e => o.createElement(u.ColorPicker, { ...p,
                    onToggleCustom: m,
                    menu: e
                })), !h && n));

                function y() {
                    e.disabled || (f(e => !e), m(!1))
                }

                function _(e) {
                    switch ((0, a.hashFromEvent)(e)) {
                        case 27:
                            g && (e.preventDefault(), x())
                    }
                }

                function x() {
                    y(), (0, i.ensureNotNull)(C.current).focus(), r && r()
                }
            }
            var h = n(6397),
                m = n(76036),
                g = n(60184),
                f = n(25177),
                b = n(32834),
                v = n(74588);
            const C = (0, b.makeSwitchGroupItem)(class extends o.PureComponent {
                constructor() {
                    super(...arguments), this._onChange = () => {
                        this.props.onChange && this.props.onChange(this.props.value)
                    }
                }
                render() {
                    const {
                        name: e,
                        checked: t,
                        value: n
                    } = this.props, r = s(v.thicknessItem, {
                        [v.checked]: t
                    }), i = s(v.bar, {
                        [v.checked]: t
                    }), a = {
                        borderTopWidth: parseInt(n)
                    };
                    return o.createElement("div", {
                        className: r
                    }, o.createElement("input", {
                        type: "radio",
                        className: v.radio,
                        name: e,
                        value: n,
                        onChange: this._onChange,
                        checked: t
                    }), o.createElement("div", {
                        className: i,
                        style: a
                    }, " "))
                }
            });

            function y(e) {
                const {
                    name: t,
                    values: n,
                    selectedValues: s,
                    onChange: r
                } = e, i = n.map((e, t) => o.createElement(C, {
                    key: t,
                    value: e.toString()
                })), a = s.map(e => e.toString());
                return o.createElement("div", {
                    className: v.wrap
                }, o.createElement(b.SwitchGroup, {
                    name: t,
                    onChange: e => {
                        r(parseInt(e))
                    },
                    values: a
                }, i))
            }
            var _ = n(83421);
            const x = (0, f.t)("Thickness");

            function E(e) {
                const {
                    value: t,
                    items: n,
                    onChange: s
                } = e;
                return o.createElement("div", {
                    className: _.thicknessContainer
                }, o.createElement("div", {
                    className: _.thicknessTitle
                }, x), o.createElement(y, {
                    name: "color_picker_thickness_select",
                    onChange: s,
                    values: n,
                    selectedValues: "mixed" === t ? [] : [t]
                }))
            }
            var S = n(14348);

            function w(e) {
                const {
                    className: t,
                    selectOpacity: n = void 0 !== e.opacity,
                    thickness: s,
                    color: i,
                    disabled: a,
                    opacity: l = 1,
                    onColorChange: c,
                    onOpacityChange: u,
                    onThicknessChange: d,
                    thicknessItems: m,
                    onPopupClose: g
                } = e, [f, b, v] = (0, h.useCustomColors)();
                return o.createElement(p, {
                    className: t,
                    disabled: a,
                    color: "mixed" !== i ? i : null,
                    selectOpacity: n,
                    opacity: l,
                    selectCustom: !0,
                    customColors: f,
                    onColorChange: c,
                    onOpacityChange: i ? u : void 0,
                    onAddColor: b,
                    onRemoveCustomColor: v,
                    button: function(e, t) {
                        const n = e || t,
                            c = n ? "primary" : "default";
                        return o.createElement("div", {
                            className: r()(S.colorPickerWrap, S["intent-" + c], S["border-thin"], S["size-medium"], n && S.highlight, n && S.focused, a && S.disabled),
                            "data-role": "button",
                            "data-name": s ? "color-with-thickness-select" : "color-select"
                        }, o.createElement("div", {
                            className: r()(S.colorPicker, a && S.disabled)
                        }, i && "mixed" !== i ? function() {
                            const e = N(i, l),
                                t = l >= .95 && T(i);
                            return o.createElement("div", {
                                className: S.opacitySwatch
                            }, o.createElement("div", {
                                style: {
                                    backgroundColor: e
                                },
                                className: r()(S.swatch, t && S.white)
                            }))
                        }() : o.createElement("div", {
                            className: S.placeholderContainer
                        }, o.createElement("div", {
                            className: "mixed" === i ? S.mixedColor : S.placeholder
                        })), s && function() {
                            const e = i && "mixed" !== i ? N(i, l) : void 0;
                            if ("mixed" === s) return o.createElement("div", {
                                className: S.multiWidth
                            }, o.createElement("div", {
                                style: {
                                    backgroundColor: e
                                },
                                className: S.line
                            }), o.createElement("div", {
                                style: {
                                    backgroundColor: e
                                },
                                className: S.line
                            }), o.createElement("div", {
                                style: {
                                    backgroundColor: e
                                },
                                className: S.line
                            }));
                            return o.createElement("span", {
                                className: r()(S.colorLine, T(i) && S.white),
                                style: {
                                    height: s,
                                    backgroundColor: e
                                }
                            })
                        }()), n && o.createElement("span", {
                            className: S.shadow
                        }))
                    },
                    onPopupClose: g
                }, s && m && o.createElement(E, {
                    value: s,
                    items: m,
                    onChange: function(e) {
                        d && d(e)
                    }
                }))
            }

            function N(e, t) {
                return e ? (0, m.generateColor)(e, (0, m.alphaToTransparency)(t)) : "#000000"
            }

            function T(e) {
                return !!e && e.toLowerCase() === g.white
            }
        },
        93315: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolInputsButton: () => x
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(25177),
                a = n(88537),
                l = n(53327),
                c = n(10549),
                u = n(82527),
                d = n(2406),
                p = n(40641),
                h = n(58323),
                m = n(27950),
                g = n(55261),
                f = n(20911),
                b = n(7002),
                v = n(32012),
                C = n(26800),
                y = n(83998);

            function _(e) {
                const {
                    symbol: t,
                    onSymbolChanged: n,
                    disabled: s,
                    className: a
                } = e, [d, g] = (0, o.useState)(t), f = (0, o.useContext)(l.SlotContext), _ = (0, o.useContext)(c.PopupContext);
                return o.createElement(m.EditButton, {
                    value: d,
                    onClick: function() {
                        const e = function(e) {
                                const t = (0, b.tokenize)(e);
                                return (0, v.isSpread)(t)
                            }(d) ? d : (0, C.safeShortName)(d),
                            t = (0,
                                p.getSymbolSearchCompleteOverrideFunction)();
                        (0, h.showSymbolSearchItemsDialog)({
                            onSearchComplete: e => {
                                t(e[0].symbol).then(e => {
                                    n(e), g(e)
                                })
                            },
                            dialogTitle: (0, i.t)("Change symbol"),
                            defaultValue: e,
                            manager: f,
                            onClose: () => {
                                _ && _.focus()
                            },
                            showSpreadActions: u.enabled("show_spread_operators") && u.enabled("studies_symbol_search_spread_operators")
                        })
                    },
                    disabled: s,
                    className: r()(a, u.enabled("uppercase_instrument_names") && y.uppercase)
                })
            }

            function x(e) {
                if ("definition" in e) {
                    const {
                        propType: t,
                        properties: n,
                        id: s,
                        title: r = ""
                    } = e.definition, i = n[t], l = i.value() || "", c = e => {
                        i.setValue(e)
                    };
                    return o.createElement(g.CommonSection, {
                        id: s,
                        title: r
                    }, o.createElement(f.CellWrap, null, o.createElement(_, {
                        symbol: (0, a.ensureDefined)(l),
                        onSymbolChanged: c
                    })))
                } {
                    const {
                        study: t,
                        value: n,
                        input: {
                            id: s,
                            name: i
                        },
                        onChange: l,
                        disabled: c,
                        hasTooltip: u
                    } = e, p = e => {
                        const n = (0, d.getSymbolName)(e, t);
                        l(n, s, i)
                    };
                    return o.createElement(_, {
                        symbol: (0, a.ensureDefined)(n),
                        onSymbolChanged: p,
                        disabled: c,
                        className: r()(u && y.hasTooltip)
                    })
                }
            }
        },
        55640: (e, t, n) => {
            "use strict";
            n.d(t, {
                createAdapter: () => r
            });
            var o = n(5796),
                s = n(93065);

            function r(e) {
                if ((0, o.isLineTool)(e)) return {
                    isPine: () => !1,
                    isStandardPine: () => !1,
                    canOverrideMinTick: () => !1,
                    resolvedSymbolInfoBySymbol: () => {
                        throw new TypeError("Only study is supported.")
                    },
                    symbolsResolved: () => {
                        throw new TypeError("Only study is supported.")
                    },
                    parentSource: () => {
                        throw new TypeError("Only study is supported.")
                    },
                    getAllChildren: () => [],
                    sourceId: () => {
                        throw new TypeError("Only study is supported.")
                    }
                };
                if ((0, s.isStudy)(e)) return e;
                if ("isInputsStudy" in e) return e;
                throw new TypeError("Unsupported source type.")
            }
        },
        71586: (e, t, n) => {
            "use strict";
            n.d(t, {
                useDefinitionProperty: () => r
            });
            var o = n(59496),
                s = n(53898);
            const r = e => {
                const t = "property" in e ? e.property : void 0,
                    n = "defaultValue" in e ? e.defaultValue : e.property.value(),
                    [r, i] = (0, o.useState)(t ? t.value() : n);
                (0, o.useEffect)(() => {
                    if (t) {
                        const n = {};
                        return i(t.value()), t.subscribe(n, t => {
                            const n = t.value();
                            e.handler && e.handler(n), i(n)
                        }), () => t.unsubscribeAll(n)
                    }
                    return () => {}
                }, [t]);
                return [r, e => {
                    if (void 0 !== t) {
                        const n = t.value();
                        s.logger.logNormal(`Changing property value from "${n}" to "${e}"`), t.setValue(e)
                    }
                }]
            }
        },
        20911: (e, t, n) => {
            "use strict";
            n.d(t, {
                CellWrap: () => a
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(26527);

            function a(e) {
                return o.createElement("div", {
                    className: r()(i.wrap, e.className)
                }, e.children)
            }
        },
        76882: (e, t, n) => {
            "use strict";
            n.d(t, {
                CheckableTitle: () => c
            });
            var o = n(59496),
                s = n(2946),
                r = n(71586);

            function i(e) {
                const {
                    property: t,
                    ...n
                } = e, [i, a] = (0, r.useDefinitionProperty)({
                    property: t
                }), l = "mixed" === i;
                return o.createElement(s.Checkbox, { ...n,
                    name: "toggle-enabled",
                    checked: l || i,
                    indeterminate: l,
                    onChange: function() {
                        a("mixed" === i || !i)
                    }
                })
            }
            var a = n(20911),
                l = n(27345);

            function c(e) {
                const {
                    property: t,
                    disabled: n,
                    title: s,
                    className: r,
                    name: c
                } = e, u = o.createElement("span", {
                    className: l.title
                }, s);
                return o.createElement(a.CellWrap, {
                    className: r
                }, t ? o.createElement(i, {
                    name: c,
                    className: l.checkbox,
                    property: t,
                    disabled: n,
                    label: u,
                    labelAlignBaseline: !0
                }) : u)
            }
        },
        55261: (e, t, n) => {
            "use strict";
            n.d(t, {
                CommonSection: () => i
            });
            var o = n(59496),
                s = n(13143),
                r = n(76882);

            function i(e) {
                const {
                    id: t,
                    offset: n,
                    disabled: i,
                    checked: a,
                    title: l,
                    children: c
                } = e;
                return o.createElement(s.PropertyTable.Row, null, o.createElement(s.PropertyTable.Cell, {
                    placement: "first",
                    verticalAlign: "adaptive",
                    offset: n,
                    "data-section-name": t,
                    colSpan: Boolean(c) ? void 0 : 2,
                    checkableTitle: !0
                }, o.createElement(r.CheckableTitle, {
                    name: "is-enabled-" + t,
                    title: l,
                    disabled: i,
                    property: a
                })), Boolean(c) && o.createElement(s.PropertyTable.Cell, {
                    placement: "last",
                    "data-section-name": t
                }, c))
            }
        },
        52830: (e, t, n) => {
            "use strict";
            n.d(t, {
                GroupTitleSection: () => a
            });
            var o = n(59496),
                s = n(13143),
                r = n(76882),
                i = n(51842);

            function a(e) {
                return o.createElement(s.PropertyTable.Row, null, o.createElement(s.PropertyTable.Cell, {
                    className: i.titleWrap,
                    placement: "first",
                    verticalAlign: "adaptive",
                    colSpan: 2,
                    "data-section-name": e.name,
                    checkableTitle: !0
                }, o.createElement(r.CheckableTitle, {
                    title: e.title,
                    name: "is-enabled-" + e.name,
                    className: i.title
                })))
            }
        },
        53898: (e, t, n) => {
            "use strict";
            n.d(t, {
                logger: () => o
            });
            const o = (0, n(51951).getLogger)("Platform.GUI.PropertyDefinitionTrace")
        },
        86176: (e, t, n) => {
            "use strict";
            n.d(t, {
                getTimezoneName: () => o
            });
            n(93540);

            function o(e) {
                const t = e.model().timezone();
                if ("exchange" !== t) return t;
                const n = e.model().mainSeries().symbolInfo();
                return null == n ? void 0 : n.timezone
            }
        },
        57630: (e, t, n) => {
            "use strict";
            n.d(t, {
                ColorPicker: () => B
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(25177),
                a = n(24377),
                l = n(88537),
                c = n(1227),
                u = n(44377),
                d = n(92063);
            const p = o.createContext(void 0);
            var h = n(60184),
                m = n(86312),
                g = n(24590);

            function f(e) {
                const {
                    index: t,
                    color: n,
                    selected: r,
                    onSelect: a
                } = e, [f, b] = (0, o.useState)(!1), v = (0, o.useContext)(p), C = (0, o.useRef)(null), y = Boolean(v) && !c.CheckMobile.any();
                return o.createElement(o.Fragment, null, o.createElement("div", {
                    ref: C,
                    style: n ? {
                        color: n
                    } : void 0,
                    className: s(g.swatch, f && g.hover, r && g.selected, !n && g.empty, String(n).toLowerCase() === h.white && g.white),
                    onClick: function() {
                        a(n)
                    },
                    onContextMenu: y ? _ : void 0
                }), y && o.createElement(u.PopupMenu, {
                    isOpened: f,
                    onClose: _,
                    position: function() {
                        const e = (0, l.ensureNotNull)(C.current).getBoundingClientRect();
                        return {
                            x: e.left,
                            y: e.top + e.height + 4
                        }
                    },
                    onClickOutside: _
                }, o.createElement(d.PopupMenuItem, {
                    className: g.contextItem,
                    label: (0, i.t)("Remove color"),
                    icon: m,
                    onClick: function() {
                        _(), (0, l.ensureDefined)(v)(t)
                    },
                    dontClosePopup: !0
                })));

                function _() {
                    b(!f)
                }
            }
            class b extends o.PureComponent {
                constructor() {
                    super(...arguments), this._onSelect = e => {
                        const {
                            onSelect: t
                        } = this.props;
                        t && t(e)
                    }
                }
                render() {
                    const {
                        colors: e,
                        color: t,
                        children: n
                    } = this.props;
                    if (!e) return null;
                    const s = t ? (0, a.parseRgb)(String(t)) : void 0;
                    return o.createElement("div", {
                        className: g.swatches
                    }, e.map((e, t) => o.createElement(f, {
                        key: String(e) + t,
                        index: t,
                        color: e,
                        selected: s && (0, a.areEqualRgb)(s, (0, a.parseRgb)(String(e))),
                        onSelect: this._onSelect
                    })), n)
                }
            }
            var v = n(39075),
                C = n(28599);

            function y(e) {
                const t = "Invalid RGB color: " + e;
                if (null === e) throw new Error(t);
                const n = e.match(/^#?([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})$/i);
                if (null === n) throw new Error(t);
                const [, o, s, r] = n;
                if (!o || !s || !r) throw new Error(t);
                const i = parseInt(o, 16) / 255,
                    a = parseInt(s, 16) / 255,
                    l = parseInt(r, 16) / 255,
                    c = Math.max(i, a, l),
                    u = Math.min(i, a, l);
                let d;
                const p = c,
                    h = c - u,
                    m = 0 === c ? 0 : h / c;
                if (c === u) d = 0;
                else {
                    switch (c) {
                        case i:
                            d = (a - l) / h + (a < l ? 6 : 0);
                            break;
                        case a:
                            d = (l - i) / h + 2;
                            break;
                        case l:
                            d = (i - a) / h + 4;
                            break;
                        default:
                            d = 0
                    }
                    d /= 6
                }
                return {
                    h: d,
                    s: m,
                    v: p
                }
            }
            var _ = n(43370),
                x = n(88440);
            class E extends o.PureComponent {
                constructor() {
                    super(...arguments), this._container = null, this._refContainer = e => {
                        this._container = e
                    }, this._handlePosition = e => {
                        const {
                            hsv: {
                                h: t
                            },
                            onChange: n
                        } = this.props;
                        if (!n) return;
                        const o = (0, l.ensureNotNull)(this._container).getBoundingClientRect(),
                            s = e.clientX - o.left,
                            r = e.clientY - o.top;
                        let i = s / o.width;
                        i < 0 ? i = 0 : i > 1 && (i = 1);
                        let a = 1 - r / o.height;
                        a < 0 ? a = 0 : a > 1 && (a = 1), n({
                            h: t,
                            s: i,
                            v: a
                        })
                    }, this._mouseDown = e => {
                        window.addEventListener("mouseup", this._mouseUp), window.addEventListener("mousemove", this._mouseMove)
                    }, this._mouseUp = e => {
                        window.removeEventListener("mousemove", this._mouseMove), window.removeEventListener("mouseup", this._mouseUp), this._handlePosition(e)
                    }, this._mouseMove = (0, _.default)(this._handlePosition, 100), this._handleTouch = e => {
                        this._handlePosition(e.nativeEvent.touches[0])
                    }
                }
                render() {
                    const {
                        className: e,
                        hsv: {
                            h: t,
                            s: n,
                            v: s
                        }
                    } = this.props, i = `hsl(${360*t}, 100%, 50%)`;
                    return o.createElement("div", {
                        className: r()(x.saturation, e),
                        style: {
                            backgroundColor: i
                        },
                        ref: this._refContainer,
                        onMouseDown: this._mouseDown,
                        onTouchStart: this._handleTouch,
                        onTouchMove: this._handleTouch
                    }, o.createElement("div", {
                        className: x.pointer,
                        style: {
                            left: 100 * n + "%",
                            top: 100 * (1 - s) + "%"
                        }
                    }))
                }
            }
            var S = n(24429);
            class w extends o.PureComponent {
                constructor() {
                    super(...arguments), this._container = null, this._refContainer = e => {
                        this._container = e
                    }, this._handlePosition = e => {
                        const {
                            hsv: {
                                s: t,
                                v: n
                            },
                            onChange: o
                        } = this.props;
                        if (!o) return;
                        const s = (0, l.ensureNotNull)(this._container).getBoundingClientRect();
                        let r = (e.clientY - s.top) / s.height;
                        r < 0 ? r = 0 : r > 1 && (r = 1), o({
                            h: r,
                            s: t,
                            v: n
                        })
                    }, this._mouseDown = e => {
                        window.addEventListener("mouseup", this._mouseUp), window.addEventListener("mousemove", this._mouseMove)
                    }, this._mouseUp = e => {
                        window.removeEventListener("mousemove", this._mouseMove), window.removeEventListener("mouseup", this._mouseUp), this._handlePosition(e)
                    }, this._mouseMove = (0, _.default)(this._handlePosition, 100), this._handleTouch = e => {
                        this._handlePosition(e.nativeEvent.touches[0])
                    }
                }
                render() {
                    const {
                        className: e,
                        hsv: {
                            h: t
                        }
                    } = this.props;
                    return o.createElement("div", {
                        className: r()(S.hue, e)
                    }, o.createElement("div", {
                        className: S.pointerContainer,
                        ref: this._refContainer,
                        onMouseDown: this._mouseDown,
                        onTouchStart: this._handleTouch,
                        onTouchMove: this._handleTouch
                    }, o.createElement("div", {
                        className: S.pointer,
                        style: {
                            top: 100 * t + "%"
                        }
                    })))
                }
            }
            var N = n(99565);
            const T = (0, i.t)("Add", {
                context: "Color Picker"
            });
            class k extends o.PureComponent {
                constructor(e) {
                    super(e), this._handleHSV = e => {
                        const t = function(e) {
                            const {
                                h: t,
                                s: n,
                                v: o
                            } = e;
                            let s, r, i;
                            const a = Math.floor(6 * t),
                                l = 6 * t - a,
                                c = o * (1 - n),
                                u = o * (1 - l * n),
                                d = o * (1 - (1 - l) * n);
                            switch (a % 6) {
                                case 0:
                                    s = o, r = d, i = c;
                                    break;
                                case 1:
                                    s = u, r = o, i = c;
                                    break;
                                case 2:
                                    s = c, r = o, i = d;
                                    break;
                                case 3:
                                    s = c, r = u, i = o;
                                    break;
                                case 4:
                                    s = d, r = c, i = o;
                                    break;
                                case 5:
                                    s = o, r = c, i = u;
                                    break;
                                default:
                                    s = 0, r = 0, i = 0
                            }
                            return "#" + [255 * s, 255 * r, 255 * i].map(e => ("0" + Math.round(e).toString(16)).replace(/.+?([a-f0-9]{2})$/i, "$1")).join("")
                        }(e) || "#000000";
                        this.setState({
                            color: t,
                            inputColor: t.replace(/^#/, ""),
                            hsv: e
                        }), this.props.onSelect(t)
                    }, this._handleInput = e => {
                        const t = e.currentTarget.value;
                        try {
                            const e = y(t),
                                n = "#" + t;
                            this.setState({
                                color: n,
                                inputColor: t,
                                hsv: e
                            }), this.props.onSelect(n)
                        } catch (e) {
                            this.setState({
                                inputColor: t
                            })
                        }
                    }, this._handleAddColor = () => this.props.onAdd(this.state.color);
                    const t = e.color || "#000000";
                    this.state = {
                        color: t,
                        inputColor: t.replace(/^#/, ""),
                        hsv: y(t)
                    }
                }
                render() {
                    const {
                        color: e,
                        hsv: t,
                        inputColor: n
                    } = this.state;
                    return o.createElement("div", {
                        className: N.container
                    }, o.createElement("div", {
                        className: N.form
                    }, o.createElement("div", {
                        className: N.swatch,
                        style: {
                            backgroundColor: e
                        }
                    }), o.createElement("div", {
                        className: N.inputWrap
                    }, o.createElement("span", {
                        className: N.inputHash
                    }, "#"), o.createElement("input", {
                        type: "text",
                        className: N.input,
                        value: n,
                        onChange: this._handleInput
                    })), o.createElement("div", {
                        className: N.buttonWrap
                    }, o.createElement(C.Button, {
                        size: "s",
                        onClick: this._handleAddColor
                    }, T))), o.createElement("div", {
                        className: N.hueSaturationWrap
                    }, o.createElement(E, {
                        className: N.saturation,
                        hsv: t,
                        onChange: this._handleHSV
                    }), o.createElement(w, {
                        className: N.hue,
                        hsv: t,
                        onChange: this._handleHSV
                    })))
                }
            }
            var P = n(10667);
            const I = (0, i.t)("Add custom color", {
                    context: "Color Picker"
                }),
                R = (0, i.t)("Opacity", {
                    context: "Color Picker"
                });
            class B extends o.PureComponent {
                constructor(e) {
                    super(e), this._handleAddColor = e => {
                        this.setState({
                            isCustom: !1
                        }), this._onToggleCustom(!1);
                        const {
                            onAddColor: t
                        } = this.props;
                        t && t(e)
                    }, this._handleSelectColor = e => {
                        const {
                            onColorChange: t
                        } = this.props, {
                            isCustom: n
                        } = this.state;
                        t && t(e, n)
                    }, this._handleCustomClick = () => {
                        this.setState({
                            isCustom: !0
                        }), this._onToggleCustom(!0)
                    }, this._handleOpacity = e => {
                        const {
                            onOpacityChange: t
                        } = this.props;
                        t && t(e)
                    }, this.state = {
                        isCustom: !1
                    }
                }
                componentDidUpdate(e, t) {
                    e.selectOpacity !== this.props.selectOpacity && this.props.menu && this.props.menu.update()
                }
                render() {
                    const {
                        color: e,
                        opacity: t,
                        selectCustom: n,
                        selectOpacity: s,
                        customColors: i,
                        onRemoveCustomColor: a
                    } = this.props, {
                        isCustom: l
                    } = this.state, c = "number" == typeof t ? t : 1;
                    return l ? o.createElement(k, {
                        color: e,
                        onSelect: this._handleSelectColor,
                        onAdd: this._handleAddColor
                    }) : o.createElement("div", {
                        className: P.container
                    }, o.createElement(b, {
                        colors: h.basic,
                        color: e,
                        onSelect: this._handleSelectColor
                    }), o.createElement(b, {
                        colors: h.extended,
                        color: e,
                        onSelect: this._handleSelectColor
                    }), o.createElement("div", {
                        className: P.separator
                    }), o.createElement(p.Provider, {
                        value: a
                    }, o.createElement(b, {
                        colors: i,
                        color: e,
                        onSelect: this._handleSelectColor
                    }, n && o.createElement("div", {
                        className: r()(P.customButton, "apply-common-tooltip"),
                        onClick: this._handleCustomClick,
                        title: I
                    }))), s && o.createElement(o.Fragment, null, o.createElement("div", {
                        className: P.sectionTitle
                    }, R), o.createElement(v.Opacity, {
                        color: e,
                        opacity: c,
                        onChange: this._handleOpacity
                    })))
                }
                _onToggleCustom(e) {
                    const {
                        onToggleCustom: t
                    } = this.props;
                    t && t(e)
                }
            }
        },
        39075: (e, t, n) => {
            "use strict";
            n.d(t, {
                Opacity: () => l
            });
            var o = n(59496),
                s = n(97754),
                r = n(88537),
                i = n(97280),
                a = n(15381);
            class l extends o.PureComponent {
                constructor(e) {
                    super(e), this._container = null, this._pointer = null, this._raf = null, this._refContainer = e => {
                        this._container = e
                    }, this._refPointer = e => {
                        this._pointer = e
                    }, this._handlePosition = e => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            const t = (0, r.ensureNotNull)(this._container),
                                n = (0, r.ensureNotNull)(this._pointer),
                                o = t.getBoundingClientRect(),
                                s = n.offsetWidth,
                                a = e.clientX - s / 2 - o.left,
                                l = (0, i.clamp)(a / (o.width - s), 0, 1);
                            this.setState({
                                inputOpacity: Math.round(100 * l).toString()
                            }), this.props.onChange(l), this._raf = null
                        }))
                    }, this._onSliderClick = e => {
                        this._handlePosition(e.nativeEvent), this._dragSubscribe()
                    }, this._mouseUp = e => {
                        this.setState({
                            isPointerDragged: !1
                        }), this._dragUnsubscribe(), this._handlePosition(e)
                    }, this._mouseMove = e => {
                        this.setState({
                            isPointerDragged: !0
                        }), this._handlePosition(e)
                    }, this._onTouchStart = e => {
                        this._handlePosition(e.nativeEvent.touches[0])
                    }, this._handleTouch = e => {
                        this.setState({
                            isPointerDragged: !0
                        }), this._handlePosition(e.nativeEvent.touches[0])
                    }, this._handleTouchEnd = () => {
                        this.setState({
                            isPointerDragged: !1
                        })
                    }, this._handleInput = e => {
                        const t = e.currentTarget.value,
                            n = Number(t) / 100;
                        this.setState({
                            inputOpacity: t
                        }), Number.isNaN(n) || n > 1 || this.props.onChange(n)
                    }, this.state = {
                        inputOpacity: Math.round(100 * e.opacity).toString(),
                        isPointerDragged: !1
                    }
                }
                componentWillUnmount() {
                    null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), this._dragUnsubscribe()
                }
                render() {
                    const {
                        color: e,
                        opacity: t,
                        hideInput: n
                    } = this.props, {
                        inputOpacity: r,
                        isPointerDragged: i
                    } = this.state, l = {
                        color: e || void 0
                    };
                    return o.createElement("div", {
                        className: a.opacity
                    }, o.createElement("div", {
                        className: a.opacitySlider,
                        style: l,
                        ref: this._refContainer,
                        onMouseDown: this._onSliderClick,
                        onTouchStart: this._onTouchStart,
                        onTouchMove: this._handleTouch,
                        onTouchEnd: this._handleTouchEnd
                    }, o.createElement("div", {
                        className: a.opacitySliderGradient,
                        style: {
                            backgroundImage: `linear-gradient(90deg, transparent, ${e})`
                        }
                    }), o.createElement("div", {
                        className: a.opacityPointerWrap
                    }, o.createElement("div", {
                        className: s(a.pointer, i && a.dragged),
                        style: {
                            left: 100 * t + "%"
                        },
                        ref: this._refPointer
                    }))), !n && o.createElement("div", {
                        className: a.opacityInputWrap
                    }, o.createElement("input", {
                        type: "text",
                        className: a.opacityInput,
                        value: r,
                        onChange: this._handleInput
                    }), o.createElement("span", {
                        className: a.opacityInputPercent
                    }, "%")))
                }
                _dragSubscribe() {
                    const e = (0, r.ensureNotNull)(this._container).ownerDocument;
                    e && (e.addEventListener("mouseup", this._mouseUp), e.addEventListener("mousemove", this._mouseMove))
                }
                _dragUnsubscribe() {
                    const e = (0, r.ensureNotNull)(this._container).ownerDocument;
                    e && (e.removeEventListener("mousemove", this._mouseMove), e.removeEventListener("mouseup", this._mouseUp))
                }
            }
        },
        60184: (e, t, n) => {
            "use strict";
            n.d(t, {
                white: () => s,
                basic: () => a,
                extended: () => c
            });
            var o = n(2996);
            const s = o.colorsPalette["color-white"],
                r = ["ripe-red", "tan-orange", "banana-yellow", "iguana-green", "minty-green", "sky-blue", "tv-blue", "deep-blue", "grapes-purple", "berry-pink"],
                i = [200, 300, 400, 500, 600, 700, 800, 900].map(e => "color-cold-gray-" + e);
            i.unshift("color-white"), i.push("color-black"), r.forEach(e => {
                i.push(`color-${e}-500`)
            });
            const a = i.map(e => o.colorsPalette[e]),
                l = [];
            [100, 200, 300, 400, 700, 900].forEach(e => {
                r.forEach(t => {
                    l.push(`color-${t}-${e}`)
                })
            });
            const c = l.map(e => o.colorsPalette[e])
        },
        31537: (e, t, n) => {
            "use strict";
            n.d(t, {
                Dialog: () => c
            });
            var o = n(59496),
                s = n(97754),
                r = n(53327),
                i = n(63212),
                a = n(417),
                l = n(17683);
            class c extends o.PureComponent {
                constructor() {
                    super(...arguments), this._manager = new i.OverlapManager, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }
                }
                render() {
                    const {
                        rounded: e = !0,
                        shadowed: t = !0,
                        fullscreen: n = !1,
                        darker: i = !1,
                        className: c,
                        backdrop: u
                    } = this.props, d = s(c, l.dialog, e && l.rounded, t && l.shadowed, n && l.fullscreen, i && l.darker), p = (0, a.filterDataProps)(this.props), h = this.props.style ? { ...this._createStyles(),
                        ...this.props.style
                    } : this._createStyles();
                    return o.createElement(o.Fragment, null, o.createElement(r.SlotContext.Provider, {
                        value: this._manager
                    }, u && o.createElement("div", {
                        onClick: this.props.onClickBackdrop,
                        className: l.backdrop
                    }), o.createElement("div", { ...p,
                        className: d,
                        style: h,
                        ref: this.props.reference,
                        onFocus: this.props.onFocus,
                        onMouseDown: this.props.onMouseDown,
                        onMouseUp: this.props.onMouseUp,
                        onClick: this.props.onClick,
                        onKeyDown: this.props.onKeyDown,
                        tabIndex: -1
                    }, this.props.children)), o.createElement(r.Slot, {
                        reference: this._handleSlot
                    }))
                }
                _createStyles() {
                    const {
                        bottom: e,
                        left: t,
                        width: n,
                        right: o,
                        top: s,
                        zIndex: r,
                        height: i
                    } = this.props;
                    return {
                        bottom: e,
                        left: t,
                        right: o,
                        top: s,
                        zIndex: r,
                        maxWidth: n,
                        height: i
                    }
                }
            }
        },
        10549: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        40766: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupDialog: () => x
            });
            var o = n(59496),
                s = n(97754),
                r = n(88537),
                i = n(31537),
                a = n(74485),
                l = n(23235),
                c = n(97280);

            function u(e, t, n, o) {
                return e + t > o && (e = o - t), e < n && (e = n), e
            }

            function d(e) {
                return {
                    x: (0, c.clamp)(e.x, 20, document.documentElement.clientWidth - 20),
                    y: (0, c.clamp)(e.y, 20, window.innerHeight - 20)
                }
            }

            function p(e) {
                return {
                    x: e.clientX,
                    y: e.clientY
                }
            }

            function h(e) {
                return {
                    x: e.touches[0].clientX,
                    y: e.touches[0].clientY
                }
            }
            class m {
                constructor(e, t, n = {
                    boundByScreen: !0
                }) {
                    this._drag = null, this._canBeTouchClick = !1, this._frame = null, this._onMouseDragStart = e => {
                        if (0 !== e.button || this._isTargetNoDraggable(e)) return;
                        e.preventDefault(), document.addEventListener("mousemove", this._onMouseDragMove), document.addEventListener("mouseup", this._onMouseDragEnd);
                        const t = d(p(e));
                        this._dragStart(t)
                    }, this._onTouchDragStart = e => {
                        if (this._isTargetNoDraggable(e)) return;
                        this._canBeTouchClick = !0, e.preventDefault(), this._header.addEventListener("touchmove", this._onTouchDragMove, {
                            passive: !1
                        });
                        const t = d(h(e));
                        this._dragStart(t)
                    }, this._onMouseDragEnd = e => {
                        e.target instanceof Node && this._header.contains(e.target) && e.preventDefault(), document.removeEventListener("mousemove", this._onMouseDragMove), document.removeEventListener("mouseup", this._onMouseDragEnd), this._onDragStop()
                    }, this._onTouchDragEnd = e => {
                        this._header.removeEventListener("touchmove", this._onTouchDragMove), this._onDragStop(), this._canBeTouchClick && (this._canBeTouchClick = !1, function(e) {
                            if (e instanceof SVGElement) {
                                const t = document.createEvent("SVGEvents");
                                t.initEvent("click", !0, !0), e.dispatchEvent(t)
                            }
                            e instanceof HTMLElement && e.click()
                        }(e.target))
                    }, this._onMouseDragMove = e => {
                        const t = d(p(e));
                        this._dragMove(t)
                    }, this._onTouchDragMove = e => {
                        this._canBeTouchClick = !1, e.preventDefault();
                        const t = d(h(e));
                        this._dragMove(t)
                    }, this._onDragStop = () => {
                        this._drag = null, this._header.classList.remove("dragging")
                    }, this._dialog = e, this._header = t, this._options = n, this._header.addEventListener("mousedown", this._onMouseDragStart), this._header.addEventListener("touchstart", this._onTouchDragStart), this._header.addEventListener("touchend", this._onTouchDragEnd)
                }
                destroy() {
                    null !== this._frame && cancelAnimationFrame(this._frame), this._header.removeEventListener("mousedown", this._onMouseDragStart), document.removeEventListener("mouseup", this._onMouseDragEnd), this._header.removeEventListener("touchstart", this._onTouchDragStart), this._header.removeEventListener("touchend", this._onTouchDragEnd), document.removeEventListener("mouseleave", this._onMouseDragEnd)
                }
                updateOptions(e) {
                    this._options = e
                }
                _dragStart(e) {
                    const t = this._dialog.getBoundingClientRect();
                    this._drag = {
                        startX: e.x,
                        startY: e.y,
                        finishX: e.x,
                        finishY: e.y,
                        dialogX: t.left,
                        dialogY: t.top
                    };
                    const n = Math.round(t.left),
                        o = Math.round(t.top);
                    this._dialog.style.transform = `translate(${n}px, ${o}px)`, this._header.classList.add("dragging"), this._options.onDragStart && this._options.onDragStart()
                }
                _dragMove(e) {
                    if (this._drag) {
                        if (this._drag.finishX = e.x, this._drag.finishY = e.y, null !== this._frame) return;
                        this._frame = requestAnimationFrame(() => {
                            if (this._drag) {
                                const t = e.x - this._drag.startX,
                                    n = e.y - this._drag.startY;
                                this._moveDialog(this._drag.dialogX + t, this._drag.dialogY + n)
                            }
                            this._frame = null
                        })
                    }
                }
                _moveDialog(e, t) {
                    const n = this._dialog.getBoundingClientRect(),
                        {
                            boundByScreen: o
                        } = this._options,
                        s = u(e, n.width, o ? 0 : -1 / 0, o ? window.innerWidth : 1 / 0),
                        r = u(t, n.height, o ? 0 : -1 / 0, o ? window.innerHeight : 1 / 0);
                    this._dialog.style.transform = `translate(${Math.round(s)}px, ${Math.round(r)}px)`
                }
                _isTargetNoDraggable(e) {
                    return e.target instanceof Element && null !== e.target.closest("[data-disable-drag]")
                }
            }
            const g = {
                vertical: 0
            };
            class f {
                constructor(e, t) {
                    this._frame = null, this._isFullscreen = !1, this._handleResize = () => {
                        null === this._frame && (this._frame = requestAnimationFrame(() => {
                            this.recalculateBounds(), this._frame = null
                        }))
                    }, this._dialog = e, this._guard = t.guard || g, this._calculateDialogPosition = t.calculateDialogPosition, this._initialHeight = e.style.height, window.addEventListener("resize", this._handleResize)
                }
                updateOptions(e) {
                    this._guard = e.guard || g, this._calculateDialogPosition = e.calculateDialogPosition
                }
                setFullscreen(e) {
                    this._isFullscreen !== e && (this._isFullscreen = e, this.recalculateBounds())
                }
                centerAndFit() {
                    const {
                        x: e,
                        y: t
                    } = this.getDialogsTopLeftCoordinates(), n = this._calcAvailableHeight(), o = this._calcDialogHeight();
                    if (n === o)
                        if (this._calculateDialogPosition) {
                            const {
                                left: e,
                                top: t
                            } = this._calculateDialogPosition(this._dialog, document.documentElement, this._guard);
                            this._dialog.style.transform = `translate(${Math.round(e)}px, ${Math.round(t)}px)`
                        } else this._dialog.style.height = o + "px";
                    this._dialog.style.top = "0px", this._dialog.style.left = "0px", this._dialog.style.transform = `translate(${e}px, ${t}px)`
                }
                getDialogsTopLeftCoordinates() {
                    const {
                        clientHeight: e,
                        clientWidth: t
                    } = document.documentElement, n = this._calcDialogHeight(), o = t / 2 - this._dialog.clientWidth / 2, s = e / 2 - n / 2;
                    return {
                        x: Math.round(o),
                        y: Math.round(s)
                    }
                }
                recalculateBounds() {
                    const {
                        clientHeight: e,
                        clientWidth: t
                    } = document.documentElement;
                    if (this._isFullscreen) this._dialog.style.top = "0px", this._dialog.style.left = "0px", this._dialog.style.width = "100%", this._dialog.style.height = "100%", this._dialog.style.transform = "none";
                    else {
                        const {
                            vertical: n
                        } = this._guard;
                        if (this._calculateDialogPosition) {
                            const o = this._calculateDialogPosition(this._dialog, {
                                    clientWidth: t,
                                    clientHeight: e
                                }, {
                                    vertical: n
                                }),
                                {
                                    left: s,
                                    top: r
                                } = o;
                            this._dialog.style.transform = `translate(${Math.round(s)}px, ${Math.round(r)}px)`
                        } else {
                            this._dialog.style.width = "", this._dialog.style.height = "";
                            const o = this._dialog.getBoundingClientRect(),
                                s = e - 2 * n,
                                r = u(o.left, o.width, 0, t),
                                i = u(o.top, o.height, n, e);
                            this._dialog.style.top = "0px", this._dialog.style.left = "0px", this._dialog.style.transform = `translate(${Math.round(r)}px, ${Math.round(i)}px)`, this._dialog.style.height = s < o.height ? s + "px" : this._initialHeight
                        }
                    }
                }
                destroy() {
                    window.removeEventListener("resize", this._handleResize), null !== this._frame && (cancelAnimationFrame(this._frame), this._frame = null)
                }
                _calcDialogHeight() {
                    const e = this._calcAvailableHeight();
                    return e < this._dialog.clientHeight ? e : this._dialog.clientHeight
                }
                _calcAvailableHeight() {
                    return document.documentElement.clientHeight - 2 * this._guard.vertical
                }
            }
            var b = n(8361),
                v = n(10549),
                C = n(85089),
                y = n(12114);
            y["tooltip-offset"];
            class _ extends o.PureComponent {
                constructor(e) {
                    super(e), this._dialog = null, this._handleDialogRef = e => {
                        const {
                            reference: t
                        } = this.props;
                        this._dialog = e, "function" == typeof t && t(e)
                    }, this._handleFocus = e => {
                        this._moveToTop()
                    }, this._handleMouseDown = e => {
                        this._moveToTop()
                    }, this._handleTouchStart = e => {
                        this._moveToTop()
                    }, this.state = {
                        canFitTooltip: !1
                    }
                }
                render() {
                    return o.createElement(v.PopupContext.Provider, {
                        value: this
                    }, o.createElement(l.OutsideEvent, {
                        mouseDown: !0,
                        touchStart: !0,
                        handler: this.props.onClickOutside
                    }, e => o.createElement("div", {
                        ref: e,
                        "data-outside-boundary-for": this.props.name,
                        onFocus: this._handleFocus,
                        onMouseDown: this._handleMouseDown,
                        onTouchStart: this._handleTouchStart,
                        "data-dialog-name": this.props["data-dialog-name"]
                    }, o.createElement(i.Dialog, {
                        style: this._applyAnimationCSSVariables(),
                        ...this.props,
                        reference: this._handleDialogRef,
                        className: s(y.dialog, this.props.className)
                    }, !1, this.props.children))))
                }
                componentDidMount() {
                    const {
                        draggable: e,
                        boundByScreen: t,
                        onDragStart: n
                    } = this.props, o = (0, r.ensureNotNull)(this._dialog);
                    if (e) {
                        const e = o.querySelector("[data-dragg-area]");
                        e && e instanceof HTMLElement && (this._drag = new m(o, e, {
                            boundByScreen: Boolean(t),
                            onDragStart: n
                        }))
                    }
                    this.props.autofocus && !o.contains(document.activeElement) && o.focus(), (this._isFullScreen() || this.props.fixedBody) && (0, C.setFixedBodyState)(!0);
                    const {
                        guard: s,
                        calculateDialogPosition: i
                    } = this.props;
                    this._resize = new f(o, {
                        guard: s,
                        calculateDialogPosition: i
                    }), this.props.isAnimationEnabled && this.props.growPoint && this._applyAppearanceAnimation(this.props.growPoint), this.props.centeredOnMount && this._resize.centerAndFit(), this._resize.setFullscreen(this._isFullScreen()), this.props.shouldForceFocus && o.focus()
                }
                componentDidUpdate() {
                    if (this._resize) {
                        const {
                            guard: e,
                            calculateDialogPosition: t
                        } = this.props;
                        this._resize.updateOptions({
                            guard: e,
                            calculateDialogPosition: t
                        }), this._resize.setFullscreen(this._isFullScreen())
                    }
                    this._drag && this._drag.updateOptions({
                        boundByScreen: Boolean(this.props.boundByScreen),
                        onDragStart: this.props.onDragStart
                    })
                }
                componentWillUnmount() {
                    this._drag && this._drag.destroy(), this._resize && this._resize.destroy(), (this._isFullScreen() || this.props.fixedBody) && (0, C.setFixedBodyState)(!1)
                }
                focus() {
                    this._dialog && this._dialog.focus()
                }
                centerAndFit() {
                    this._resize && this._resize.centerAndFit()
                }
                recalculateBounds() {
                    this._resize && this._resize.recalculateBounds()
                }
                _moveToTop() {
                    null !== this.context && this.context.moveToTop()
                }
                _applyAnimationCSSVariables() {
                    return {
                        "--animationTranslateStartX": null,
                        "--animationTranslateStartY": null,
                        "--animationTranslateEndX": null,
                        "--animationTranslateEndY": null
                    }
                }
                _applyAppearanceAnimation(e) {
                    if (this._resize && this._dialog) {
                        const {
                            x: t,
                            y: n
                        } = e, {
                            x: o,
                            y: s
                        } = this._resize.getDialogsTopLeftCoordinates();
                        this._dialog.style.setProperty("--animationTranslateStartX", t + "px"), this._dialog.style.setProperty("--animationTranslateStartY", n + "px"), this._dialog.style.setProperty("--animationTranslateEndX", o + "px"), this._dialog.style.setProperty("--animationTranslateEndY", s + "px"), this._dialog.classList.add(y.dialogAnimatedAppearance)
                    }
                }
                _handleTooltipFit() {
                    0
                }
                _isFullScreen() {
                    return Boolean(this.props.fullscreen)
                }
            }
            _.contextType = b.PortalContext, _.defaultProps = {
                boundByScreen: !0,
                draggable: !0,
                centeredOnMount: !0
            };
            const x = (0, a.makeOverlapable)(_)
        },
        95426: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlDisclosureView: () => b
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(28606),
                a = n(34735),
                l = n(2691),
                c = n(44377),
                u = n(88537);

            function d(e, t) {
                return (0, o.useCallback)(() => function(e, t) {
                    const n = (0, u.ensureNotNull)(e).getBoundingClientRect(),
                        o = {
                            x: n.left,
                            y: n.top + n.height
                        };
                    return t && (o.overrideWidth = n.width), o
                }(e.current, t), [e, t])
            }
            var p = n(86240);
            const h = parseInt(p["size-header-height"]);

            function m(e) {
                const {
                    button: t,
                    popupChildren: n,
                    buttonRef: s,
                    listboxId: r,
                    listboxClassName: i,
                    listboxTabIndex: a,
                    matchButtonAndListboxWidths: l,
                    isOpened: u,
                    scrollWrapReference: p,
                    listboxReference: m,
                    onClose: g,
                    onOpen: f,
                    onListboxFocus: b,
                    onListboxBlur: v,
                    onListboxKeyDown: C,
                    listboxAria: y,
                    repositionOnScroll: _ = !0,
                    closeOnHeaderOverlap: x = !1
                } = e, E = d(s, l), S = x ? h : 0;
                return o.createElement(o.Fragment, null, t, o.createElement(c.PopupMenu, { ...y,
                    id: r,
                    className: i,
                    tabIndex: a,
                    isOpened: u,
                    position: E,
                    repositionOnScroll: _,
                    onClose: g,
                    onOpen: f,
                    doNotCloseOn: s.current,
                    reference: m,
                    scrollWrapReference: p,
                    onFocus: b,
                    onBlur: v,
                    onKeyDown: C,
                    closeOnScrollOutsideOffset: S
                }, n))
            }
            var g = n(63802),
                f = n(66230);
            const b = o.forwardRef((e, t) => {
                const {
                    listboxId: n,
                    className: s,
                    listboxClassName: c,
                    listboxTabIndex: u,
                    hideArrowButton: d,
                    matchButtonAndListboxWidths: p,
                    disabled: h,
                    isOpened: b,
                    scrollWrapReference: v,
                    repositionOnScroll: C,
                    closeOnHeaderOverlap: y,
                    listboxReference: _,
                    size: x = "medium",
                    onClose: E,
                    onOpen: S,
                    onListboxFocus: w,
                    onListboxBlur: N,
                    onListboxKeyDown: T,
                    buttonChildren: k,
                    children: P,
                    caretClassName: I,
                    listboxAria: R,
                    ...B
                } = e, D = (0, o.useRef)(null), M = !d && o.createElement(l.EndSlot, null, o.createElement(g.Caret, {
                    isDropped: b,
                    disabled: h,
                    className: I
                }));
                return o.createElement(m, {
                    buttonRef: D,
                    listboxId: n,
                    listboxClassName: c,
                    listboxTabIndex: u,
                    isOpened: b,
                    onClose: E,
                    onOpen: S,
                    listboxReference: _,
                    scrollWrapReference: v,
                    onListboxFocus: w,
                    onListboxBlur: N,
                    onListboxKeyDown: T,
                    listboxAria: R,
                    matchButtonAndListboxWidths: p,
                    button: o.createElement(a.ControlSkeleton, { ...B,
                        "data-role": "listbox",
                        disabled: h,
                        className: r()(f.button, s),
                        size: x,
                        ref: (0, i.useMergedRefs)([D, t]),
                        middleSlot: o.createElement(l.MiddleSlot, null, o.createElement("span", {
                            className: r()(f["button-children"], d && f.hiddenArrow)
                        }, k)),
                        endSlot: M
                    }),
                    popupChildren: P,
                    repositionOnScroll: C,
                    closeOnHeaderOverlap: y
                })
            });
            b.displayName = "ControlDisclosureView"
        },
        79827: (e, t, n) => {
            "use strict";
            n.d(t, {
                useControlDisclosure: () => c
            });
            var o = n(59496),
                s = n(88537),
                r = n(83836),
                i = n(69842),
                a = n(14823),
                l = n(98043);

            function c(e) {
                const {
                    intent: t,
                    highlight: n,
                    ...c
                } = e, {
                    isFocused: u,
                    ...d
                } = function(e) {
                    const {
                        id: t,
                        disabled: n,
                        buttonTabIndex: c = 0,
                        onFocus: u,
                        onBlur: d,
                        onClick: p
                    } = e, [h, m] = (0, o.useState)(!1), [g, f] = (0, r.useFocus)(), b = g || h, v = void 0 !== t ? (0, a.createDomId)(t, "listbox") : void 0, C = (0, o.useRef)(null), y = (0, o.useCallback)(e => (0, s.ensureNotNull)(C.current).focus(e), [C]), _ = (0, o.useRef)(null), x = (0, o.useCallback)(() => (0, s.ensureNotNull)(_.current).focus(), [_]), E = (0, o.useCallback)(() => m(!0), [m]), S = (0, o.useCallback)((e = !1) => {
                        m(!1);
                        const {
                            activeElement: t
                        } = document;
                        t && (0, l.isTextEditingField)(t) || y({
                            preventScroll: e
                        })
                    }, [m, y]), w = (0, o.useCallback)(() => {
                        h ? S() : E()
                    }, [h, S, E]), N = n ? [] : [u, f.onFocus], T = n ? [] : [d, f.onBlur], k = n ? [] : [p, w], P = (0, i.createSafeMulticastEventHandler)(...N), I = (0, i.createSafeMulticastEventHandler)(...T), R = (0, i.createSafeMulticastEventHandler)(...k);
                    return {
                        listboxId: v,
                        isOpened: h,
                        isFocused: b,
                        buttonTabIndex: n ? -1 : c,
                        listboxTabIndex: -1,
                        open: E,
                        close: S,
                        toggle: w,
                        onOpen: x,
                        buttonFocusBindings: {
                            onFocus: P,
                            onBlur: I
                        },
                        onButtonClick: R,
                        buttonRef: C,
                        listboxRef: _,
                        buttonAria: {
                            "aria-controls": h ? v : void 0,
                            "aria-expanded": h,
                            "aria-disabled": n
                        }
                    }
                }(c);
                return { ...d,
                    isFocused: u,
                    highlight: null != n ? n : u,
                    intent: null != t ? t : u ? "primary" : "default"
                }
            }
        },
        53517: (e, t, n) => {
            "use strict";
            n.d(t, {
                useKeyboardActionHandler: () => i,
                useComposedKeyboardActionHandlers: () => a,
                useKeyboardEventHandler: () => l,
                useKeyboardToggle: () => c,
                useKeyboardClose: () => u,
                useKeyboardOpen: () => d
            });
            var o = n(59496),
                s = n(80185);
            const r = () => !0;

            function i(e, t, n = r) {
                return (0, o.useCallback)(o => {
                    const s = e.map(e => "function" == typeof e ? e() : e);
                    return !(!n() || !s.includes(o)) && (t(), !0)
                }, [...e, t, n])
            }

            function a(...e) {
                return (0, o.useCallback)(t => {
                    for (const n of e)
                        if (n(t)) return !0;
                    return !1
                }, [...e])
            }

            function l(...e) {
                const t = a(...e);
                return (0, o.useCallback)(e => {
                    t((0, s.hashFromEvent)(e)) && e.preventDefault()
                }, [t])
            }

            function c(e) {
                return i([13, 32], e)
            }

            function u(e, t) {
                return i([9, (0, o.useCallback)(() => s.Modifiers.Shift + 9, []), 27], t, (0, o.useCallback)(() => e, [e]))
            }

            function d(e, t) {
                return i([40, 38], t, (0, o.useCallback)(() => !e, [e]))
            }
        },
        6397: (e, t, n) => {
            "use strict";
            n.d(t, {
                useCustomColors: () => l
            });
            var o = n(59496),
                s = n(70122),
                r = n(59410);

            function i(e, t) {
                (0, o.useEffect)(() => (r.subscribe(e, t, null), () => {
                    r.unsubscribe(e, t, null)
                }), [e, t])
            }
            var a = n(24377);

            function l() {
                const [e, t] = (0, o.useState)((0,
                    s.getJSON)("pickerCustomColors", []));
                i("add_new_custom_color", n => t(c(n, e))), i("remove_custom_color", n => t(u(n, e)));
                const n = (0, o.useCallback)(t => {
                        const n = t ? (0, a.parseRgb)(t) : null;
                        e.some(e => null !== e && null !== n && (0, a.areEqualRgb)((0, a.parseRgb)(e), n)) || (r.emit("add_new_custom_color", t), (0, s.setJSON)("pickerCustomColors", c(t, e)))
                    }, [e]),
                    l = (0, o.useCallback)(t => {
                        (t >= 0 || t < e.length) && (r.emit("remove_custom_color", t), (0, s.setJSON)("pickerCustomColors", u(t, e)))
                    }, [e]);
                return [e, n, l]
            }

            function c(e, t) {
                const n = t.slice();
                return n.push(e), n.length > 29 && n.shift(), n
            }

            function u(e, t) {
                return t.filter((t, n) => e !== n)
            }
        },
        63802: (e, t, n) => {
            "use strict";
            n.d(t, {
                Caret: () => u,
                CaretButton: () => d
            });
            var o = n(59496),
                s = n(97754),
                r = n.n(s),
                i = n(72571),
                a = n(76758),
                l = n(99171);

            function c(e) {
                const {
                    isDropped: t
                } = e;
                return o.createElement(i.Icon, {
                    className: r()(l.icon, t && l.dropped),
                    icon: a
                })
            }

            function u(e) {
                const {
                    className: t,
                    disabled: n,
                    isDropped: s
                } = e;
                return o.createElement("span", {
                    className: r()(l.button, n && l.disabled, t)
                }, o.createElement(c, {
                    isDropped: s
                }))
            }

            function d(e) {
                const {
                    className: t,
                    tabIndex: n = -1,
                    disabled: s,
                    isDropped: i,
                    ...a
                } = e;
                return o.createElement("button", { ...a,
                    type: "button",
                    tabIndex: n,
                    disabled: s,
                    className: r()(l.button, s && l.disabled, t)
                }, o.createElement(c, {
                    isDropped: i
                }))
            }
        },
        36118: (e, t, n) => {
            "use strict";
            n.d(t, {
                Select: () => T
            });
            var o = n(59496),
                s = n(14823),
                r = n(28606),
                i = n(88537),
                a = n(49423);
            const l = {
                    duration: 200,
                    additionalScroll: 0
                },
                c = {
                    vertical: {
                        scrollSize: "scrollHeight",
                        clientSize: "clientHeight",
                        start: "top",
                        end: "bottom",
                        size: "height"
                    },
                    horizontal: {
                        scrollSize: "scrollWidth",
                        clientSize: "clientWidth",
                        start: "left",
                        end: "right",
                        size: "width"
                    }
                };

            function u(e, t) {
                const n = c[e];
                return t[n.scrollSize] > t[n.clientSize]
            }

            function d(e, t, n, o, s, r) {
                const i = function(e, t, n, o = 0) {
                    const s = c[e];
                    return {
                        start: -1 * o,
                        middle: -1 * (Math.floor(n[s.size] / 2) - Math.floor(t[s.size] / 2)),
                        end: -1 * (n[s.size] - t[s.size]) + o
                    }
                }(e, o, s, r.additionalScroll);
                let l = 0;
                if (function(e, t, n) {
                        const o = c[e];
                        return t[o.start] < n[o.start] - n[o.size] / 2 || t[o.end] > n[o.end] + n[o.size] / 2
                    }(e, o, s)) l = i.middle;
                else {
                    const t = function(e) {
                        const {
                            start: t,
                            middle: n,
                            end: o
                        } = e, s = new Map([
                            [Math.abs(t), {
                                key: "start",
                                value: Math.sign(t)
                            }],
                            [Math.abs(n), {
                                key: "middle",
                                value: Math.sign(n)
                            }],
                            [Math.abs(o), {
                                key: "end",
                                value: Math.sign(o)
                            }]
                        ]), r = Math.min(...s.keys());
                        return s.get(r)
                    }(function(e, t, n, o = 0) {
                        const s = c[e],
                            r = t[s.start] + Math.floor(t[s.size] / 2),
                            i = n[s.start] + Math.floor(n[s.size] / 2);
                        return {
                            start: t[s.start] - n[s.start] - o,
                            middle: r - i,
                            end: t[s.end] - n[s.end] + o
                        }
                    }(e, o, s, r.additionalScroll));
                    l = void 0 !== t ? i[t.key] : 0
                }
                return function(e) {
                    const {
                        additionalScroll: t = 0,
                        duration: n = a.dur,
                        func: o = a.easingFunc.easeInOutCubic,
                        onScrollEnd: s,
                        target: r,
                        wrap: i,
                        direction: l = "vertical"
                    } = e;
                    let {
                        targetRect: c,
                        wrapRect: u
                    } = e;
                    c = null != c ? c : r.getBoundingClientRect(), u = null != u ? u : i.getBoundingClientRect();
                    const d = ("vertical" === l ? c.top - u.top : c.left - u.left) + t,
                        p = "vertical" === l ? "scrollTop" : "scrollLeft",
                        h = i ? i[p] : 0;
                    let m, g = 0;
                    return g = window.requestAnimationFrame((function e(t) {
                            let r;
                            if (m ? r = t - m : (r = 0, m = t), r >= n) return i[p] = h + d, void(s && s());
                            const a = h + d * o(r / n);
                            i[p] = Math.floor(a), g = window.requestAnimationFrame(e)
                        })),
                        function() {
                            window.cancelAnimationFrame(g), s && s()
                        }
                }({ ...r,
                    target: t,
                    targetRect: o,
                    wrap: n,
                    wrapRect: s,
                    additionalScroll: l,
                    direction: e
                })
            }
            class p {
                constructor(e = null) {
                    this._container = null, this._lastScrolledElement = null, this._stopVerticalScroll = null, this._stopHorizontalScroll = null, this._container = e
                }
                scrollTo(e, t = l) {
                    if (null !== this._container && null !== e && ! function(e, t) {
                            const n = e.getBoundingClientRect(),
                                o = t.getBoundingClientRect();
                            return n.top >= o.top && n.bottom <= o.bottom && n.left >= o.left && n.right <= o.right
                        }(e, this._container)) {
                        const n = e.getBoundingClientRect(),
                            o = this._container.getBoundingClientRect();
                        this.stopScroll(), u("vertical", this._container) && (this._stopVerticalScroll = d("vertical", e, this._container, n, o, this._modifyOptions("vertical", t))), u("horizontal", this._container) && (this._stopHorizontalScroll = d("horizontal", e, this._container, n, o, this._modifyOptions("horizontal", t)))
                    }
                    this._lastScrolledElement = e
                }
                scrollToLastElement(e) {
                    this.scrollTo(this._lastScrolledElement, e)
                }
                stopScroll() {
                    null !== this._stopVerticalScroll && this._stopVerticalScroll(), null !== this._stopHorizontalScroll && this._stopHorizontalScroll()
                }
                getContainer() {
                    return this._container
                }
                setContainer(e) {
                    var t;
                    this._container = e, (null === (t = this._container) || void 0 === t ? void 0 : t.contains(this._lastScrolledElement)) || (this._lastScrolledElement = null)
                }
                destroy() {
                    this.stopScroll(), this._container = null, this._lastScrolledElement = null
                }
                _handleScrollEnd(e) {
                    "vertical" === e ? this._stopVerticalScroll = null : this._stopHorizontalScroll = null
                }
                _modifyOptions(e, t) {
                    return Object.assign({}, t, {
                        onScrollEnd: () => {
                            this._handleScrollEnd(e), void 0 !== t.onScrollEnd && t.onScrollEnd()
                        }
                    })
                }
            }

            function h(e, t) {
                const n = (0, o.useRef)(null),
                    s = (0, o.useRef)(new WeakMap),
                    r = function(e) {
                        const t = (0, o.useRef)(null);
                        return (0, o.useEffect)(() => (t.current = new p(e), () => (0, i.ensureNotNull)(t.current).destroy()), []), t
                    }(n.current),
                    a = (0, o.useCallback)(() => {
                        null !== r.current && null !== n.current && r.current.getContainer() !== n.current && r.current.setContainer(n.current)
                    }, [r, n]),
                    l = (0, o.useCallback)(e => {
                        n.current = e
                    }, [n]),
                    c = (0, o.useCallback)((e, t) => {
                        s.current.set(e, t)
                    }, [s]),
                    u = (0, o.useCallback)((e, t) => {
                        if (!e) return;
                        const n = s.current.get(e);
                        n && (a(), (0, i.ensureNotNull)(r.current).scrollTo(n, t))
                    }, [s, r]);
                return (0, o.useEffect)(() => u(e, t), [u, e]), [l, c, u]
            }
            var m = n(92063),
                g = n(4889),
                f = n(43370);
            var b = n(34581),
                v = n(53517);

            function C(e, t) {
                return e >= 0 ? e % t : (t - Math.abs(e) % t) % t
            }
            const y = {
                next: [40, () => (0, b.isRtl)() ? 37 : 39],
                previous: [38, () => (0, b.isRtl)() ? 39 : 37],
                first: [33, 36],
                last: [34, 35]
            };
            var _ = n(95426),
                x = n(79827),
                E = n(79756);

            function S(e) {
                return !e.readonly
            }

            function w(e, t) {
                var n;
                return null !== (n = null == t ? void 0 : t.id) && void 0 !== n ? n : (0, s.createDomId)(e, "item", null == t ? void 0 : t.value)
            }

            function N(e) {
                var t, n;
                const {
                    selectedItem: s,
                    placeholder: r
                } = e;
                if (!s) return o.createElement("span", {
                    className: E.placeholder
                }, r);
                const i = null !== (n = null !== (t = s.selectedContent) && void 0 !== t ? t : s.content) && void 0 !== n ? n : s.value;
                return o.createElement("span", null, i)
            }
            const T = o.forwardRef((e, t) => {
                const {
                    id: n,
                    menuClassName: i,
                    menuItemClassName: a,
                    tabIndex: l,
                    disabled: c,
                    highlight: u,
                    intent: d,
                    hideArrowButton: p,
                    placeholder: b,
                    addPlaceholderToItems: E = !0,
                    value: T,
                    "aria-labelledby": k,
                    onFocus: P,
                    onBlur: I,
                    onClick: R,
                    onChange: B,
                    repositionOnScroll: D = !0,
                    ...M
                } = e;
                let {
                    items: O
                } = e;
                if (b && E) {
                    O = [{
                        value: void 0,
                        content: b,
                        id: (0, s.createDomId)(n, "placeholder")
                    }, ...O]
                }
                const {
                    listboxId: A,
                    isOpened: z,
                    isFocused: L,
                    buttonTabIndex: F,
                    listboxTabIndex: G,
                    highlight: W,
                    intent: H,
                    open: V,
                    onOpen: j,
                    close: X,
                    toggle: U,
                    buttonFocusBindings: K,
                    onButtonClick: Y,
                    buttonRef: $,
                    listboxRef: q,
                    buttonAria: Q
                } = (0, x.useControlDisclosure)({
                    id: n,
                    disabled: c,
                    buttonTabIndex: l,
                    intent: d,
                    highlight: u,
                    onFocus: P,
                    onBlur: I,
                    onClick: R
                }), Z = O.filter(S), J = Z.find(e => e.value === T), [ee, te, ne] = h(J), oe = (0, s.joinDomIds)(k, n), se = oe.length > 0 ? oe : void 0, re = (0, o.useMemo)(() => ({
                    role: "listbox",
                    "aria-labelledby": k,
                    "aria-activedescendant": w(n, J)
                }), [k, J]), ie = (0, o.useCallback)(e => e.value === T, [T]), ae = (0, o.useCallback)(e => B && B(e.value), [B]), le = function(e, t, n, s = !0, r = {}) {
                    const i = (0, o.useCallback)(() => {
                            const o = e.findIndex(t);
                            if (o === e.length - 1 && !s) return;
                            const r = C(o + 1, e.length);
                            n && n(e[r])
                        }, [e, t, n, s]),
                        a = (0, o.useCallback)(() => {
                            const o = e.findIndex(t);
                            if (0 === o && !s) return;
                            const r = C(o - 1, e.length);
                            n && n(e[r])
                        }, [e, t, n, s]),
                        l = (0, o.useCallback)(() => {
                            n && n(e[0])
                        }, [n, e]),
                        c = (0, o.useCallback)(() => {
                            n && n(e[e.length - 1])
                        }, [n, e]),
                        {
                            next: u = y.next,
                            previous: d = y.previous,
                            first: p = y.first,
                            last: h = y.last
                        } = r;
                    return (0, v.useComposedKeyboardActionHandlers)((0, v.useKeyboardActionHandler)(u, i), (0, v.useKeyboardActionHandler)(d, a), (0, v.useKeyboardActionHandler)(p, l), (0, v.useKeyboardActionHandler)(h, c))
                }(Z, ie, ae, !1, {
                    next: [40],
                    previous: [38]
                }), ce = (0, v.useKeyboardToggle)(U), ue = (0, v.useKeyboardClose)(z, X), de = (0, v.useKeyboardOpen)(z, V), pe = (0, v.useKeyboardEventHandler)(ce, ue, de), he = (0, v.useKeyboardEventHandler)(le, ce, ue), me = function(e) {
                    const t = (0, o.useRef)(""),
                        n = (0, o.useMemo)(() => (0, g.default)(() => {
                            t.current = ""
                        }, 500), []),
                        s = (0, o.useMemo)(() => (0, f.default)(e, 200), [e]);
                    return (0, o.useCallback)(e => {
                        e.key.length > 0 && e.key.length < 3 && (t.current += e.key, s(t.current, e), n())
                    }, [n, s])
                }((e, t) => {
                    const n = function(e, t) {
                        return e.find(e => {
                            var n;
                            const o = t.toLowerCase();
                            return !e.readonly && (!e.readonly && ("string" == typeof e.content && e.content.toLowerCase().startsWith(o) || String(null !== (n = e.value) && void 0 !== n ? n : "").toLowerCase().startsWith(o)))
                        })
                    }(Z, e);
                    void 0 !== n && B && (t.stopPropagation(), z || V(), B(n.value))
                });
                return o.createElement(_.ControlDisclosureView, { ...M,
                    ...Q,
                    ...K,
                    id: n,
                    role: "button",
                    tabIndex: F,
                    "aria-owns": Q["aria-controls"],
                    "aria-haspopup": "listbox",
                    "aria-labelledby": se,
                    disabled: c,
                    hideArrowButton: p,
                    isFocused: L,
                    isOpened: z,
                    highlight: W,
                    intent: H,
                    ref: (0, r.useMergedRefs)([$, t]),
                    onClick: Y,
                    onOpen: function() {
                        ne(J, {
                            duration: 0
                        }), j()
                    },
                    onClose: X,
                    onKeyDown: function(e) {
                        pe(e), e.defaultPrevented || me(e)
                    },
                    listboxId: A,
                    listboxTabIndex: G,
                    listboxClassName: i,
                    listboxAria: re,
                    listboxReference: q,
                    scrollWrapReference: ee,
                    onListboxKeyDown: function(e) {
                        he(e), e.defaultPrevented || me(e)
                    },
                    buttonChildren: o.createElement(N, {
                        selectedItem: J,
                        placeholder: b
                    }),
                    repositionOnScroll: D
                }, O.map((e, t) => {
                    var s;
                    if (e.readonly) return o.createElement(o.Fragment, {
                        key: "readonly_item_" + t
                    }, e.content);
                    const r = w(n, e);
                    return o.createElement(m.PopupMenuItem, {
                        key: r,
                        id: r,
                        className: a,
                        role: "option",
                        "aria-selected": T === e.value,
                        isActive: T === e.value,
                        label: null !== (s = e.content) && void 0 !== s ? s : e.value,
                        onClick: ge,
                        onClickArg: e.value,
                        isDisabled: e.disabled,
                        reference: t => te(e, t)
                    })
                }));

                function ge(e) {
                    B && B(e)
                }
            });
            T.displayName = "Select"
        },
        23235: (e, t, n) => {
            "use strict";
            n.d(t, {
                OutsideEvent: () => s
            });
            var o = n(61174);

            function s(e) {
                const {
                    children: t,
                    ...n
                } = e;
                return t((0, o.useOutsideEvent)(n))
            }
        },
        74485: (e, t, n) => {
            "use strict";
            n.d(t, {
                makeOverlapable: () => r
            });
            var o = n(59496),
                s = n(8361);

            function r(e) {
                return class extends o.PureComponent {
                    render() {
                        const {
                            isOpened: t,
                            root: n
                        } = this.props;
                        if (!t) return null;
                        const r = o.createElement(e, { ...this.props,
                            zIndex: 150
                        });
                        return "parent" === n ? r : o.createElement(s.Portal, null, r)
                    }
                }
            }
        },
        42554: (e, t, n) => {
            "use strict";
            n.d(t, {
                TouchScrollContainer: () => a
            });
            var o = n(59496),
                s = n(59142),
                r = n(88537),
                i = n(1227);

            function a(e) {
                const {
                    reference: t,
                    children: n,
                    ...r
                } = e, a = (0, o.useRef)(null), c = (0, o.useCallback)(e => {
                    t && (t.current = e), i.CheckMobile.iOS() && (null !== a.current && (0, s.enableBodyScroll)(a.current), a.current = e, null !== a.current && (0, s.disableBodyScroll)(a.current, {
                        allowTouchMove: l(a)
                    }))
                }, [t]);
                return o.createElement("div", {
                    ref: c,
                    ...r
                }, n)
            }

            function l(e) {
                return t => {
                    const n = (0, r.ensureNotNull)(e.current),
                        o = document.activeElement;
                    return !n.contains(t) || null !== o && n.contains(o) && o.contains(t)
                }
            }
        },
        57369: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 9" width="11" height="9" fill="none"><path stroke-width="2" d="M0.999878 4L3.99988 7L9.99988 1"/></svg>'
        },
        76758: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 7" width="11" height="7" fill="none"><path stroke="currentColor" stroke-width="1.3" d="M.5 1.5l5 4 5-4"/></svg>'
        },
        17354: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M13.5 7l1.65-1.65a.5.5 0 0 0 0-.7l-1.8-1.8a.5.5 0 0 0-.7 0L11 4.5M13.5 7L11 4.5M13.5 7l-8.35 8.35a.5.5 0 0 1-.36.15H2.5v-2.3a.5.5 0 0 1 .15-.35L11 4.5"/></svg>'
        },
        47189: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M8 8.5h1.5V14"/><circle fill="currentColor" cx="9" cy="5" r="1"/><path stroke="currentColor" d="M16.5 9a7.5 7.5 0 1 1-15 0 7.5 7.5 0 0 1 15 0z"/></svg>'
        },
        86240: e => {
            "use strict";
            e.exports = JSON.parse('{"size-header-height":"64px","media-phone-vertical":"screen and (max-width: 479px)","media-mf-phone-landscape":"screen and (min-width: 568px)"}')
        }
    }
]);
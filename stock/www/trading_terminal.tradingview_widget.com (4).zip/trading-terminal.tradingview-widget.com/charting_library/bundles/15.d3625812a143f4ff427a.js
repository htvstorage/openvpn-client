(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [15, 9195, 9079, 8930, 6043], {
        59142: function(e, t) {
            var n, r, o;
            r = [t], void 0 === (o = "function" == typeof(n = function(e) {
                "use strict";

                function t(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                        return n
                    }
                    return Array.from(e)
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var n = !1;
                if ("undefined" != typeof window) {
                    var r = {
                        get passive() {
                            n = !0
                        }
                    };
                    window.addEventListener("testPassive", null, r), window.removeEventListener("testPassive", null, r)
                }
                var o = "undefined" != typeof window && window.navigator && window.navigator.platform && /iP(ad|hone|od)/.test(window.navigator.platform),
                    i = [],
                    u = !1,
                    a = -1,
                    s = void 0,
                    c = void 0,
                    l = function(e) {
                        return i.some((function(t) {
                            return !(!t.options.allowTouchMove || !t.options.allowTouchMove(e))
                        }))
                    },
                    f = function(e) {
                        var t = e || window.event;
                        return !!l(t.target) || 1 < t.touches.length || (t.preventDefault && t.preventDefault(), !1)
                    },
                    p = function() {
                        setTimeout((function() {
                            void 0 !== c && (document.body.style.paddingRight = c, c = void 0), void 0 !== s && (document.body.style.overflow = s, s = void 0)
                        }))
                    };
                e.disableBodyScroll = function(e, r) {
                    if (o) {
                        if (!e) return void console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.");
                        if (e && !i.some((function(t) {
                                return t.targetElement === e
                            }))) {
                            var p = {
                                targetElement: e,
                                options: r || {}
                            };
                            i = [].concat(t(i), [p]), e.ontouchstart = function(e) {
                                1 === e.targetTouches.length && (a = e.targetTouches[0].clientY)
                            }, e.ontouchmove = function(t) {
                                var n, r, o, i;
                                1 === t.targetTouches.length && (r = e, i = (n = t).targetTouches[0].clientY - a, !l(n.target) && (r && 0 === r.scrollTop && 0 < i || (o = r) && o.scrollHeight - o.scrollTop <= o.clientHeight && i < 0 ? f(n) : n.stopPropagation()))
                            }, u || (document.addEventListener("touchmove", f, n ? {
                                passive: !1
                            } : void 0), u = !0)
                        }
                    } else {
                        y = r, setTimeout((function() {
                            if (void 0 === c) {
                                var e = !!y && !0 === y.reserveScrollBarGap,
                                    t = window.innerWidth - document.documentElement.clientWidth;
                                e && 0 < t && (c = document.body.style.paddingRight, document.body.style.paddingRight = t + "px")
                            }
                            void 0 === s && (s = document.body.style.overflow, document.body.style.overflow = "hidden")
                        }));
                        var d = {
                            targetElement: e,
                            options: r || {}
                        };
                        i = [].concat(t(i), [d])
                    }
                    var y
                }, e.clearAllBodyScrollLocks = function() {
                    o ? (i.forEach((function(e) {
                        e.targetElement.ontouchstart = null, e.targetElement.ontouchmove = null
                    })), u && (document.removeEventListener("touchmove", f, n ? {
                        passive: !1
                    } : void 0), u = !1), i = [], a = -1) : (p(), i = [])
                }, e.enableBodyScroll = function(e) {
                    if (o) {
                        if (!e) return void console.error("enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices.");
                        e.ontouchstart = null, e.ontouchmove = null, i = i.filter((function(t) {
                            return t.targetElement !== e
                        })), u && 0 === i.length && (document.removeEventListener("touchmove", f, n ? {
                            passive: !1
                        } : void 0), u = !1)
                    } else 1 === i.length && i[0].targetElement === e ? (p(), i = []) : i = i.filter((function(t) {
                        return t.targetElement !== e
                    }))
                }
            }) ? n.apply(t, r) : n) || (e.exports = o)
        },
        66783: e => {
            "use strict";
            var t = Object.prototype.hasOwnProperty;

            function n(e, t) {
                return e === t ? 0 !== e || 0 !== t || 1 / e == 1 / t : e != e && t != t
            }
            e.exports = function(e, r) {
                if (n(e, r)) return !0;
                if ("object" != typeof e || null === e || "object" != typeof r || null === r) return !1;
                var o = Object.keys(e),
                    i = Object.keys(r);
                if (o.length !== i.length) return !1;
                for (var u = 0; u < o.length; u++)
                    if (!t.call(r, o[u]) || !n(e[o[u]], r[o[u]])) return !1;
                return !0
            }
        },
        7270: function(e, t, n) {
            var r, o, i;
            e.exports = (r = n(59496), o = n(87995), i = n(59255), function(e) {
                function t(r) {
                    if (n[r]) return n[r].exports;
                    var o = n[r] = {
                        exports: {},
                        id: r,
                        loaded: !1
                    };
                    return e[r].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports
                }
                var n = {};
                return t.m = e, t.c = n, t.p = "dist/", t(0)
            }([function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(1));
                t.default = r.default, e.exports = t.default
            }, function(e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var o = function() {
                        function e(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                            }
                        }
                        return function(t, n, r) {
                            return n && e(t.prototype, n), r && e(t, r), t
                        }
                    }(),
                    i = n(2),
                    u = (r(i), n(3)),
                    a = r(u),
                    s = r(n(13)),
                    c = r(n(14)),
                    l = r(n(15)),
                    f = function(e) {
                        function t(e) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, t);
                            var n = function(e, t) {
                                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !t || "object" != typeof t && "function" != typeof t ? e : t
                            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                            return n.measure = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.props.includeMargin;
                                if (n.props.shouldMeasure) {
                                    n._node.parentNode || n._setDOMNode();
                                    var t = n.getDimensions(n._node, e),
                                        r = "function" == typeof n.props.children;
                                    n._propsToMeasure.some((function(e) {
                                        if (t[e] !== n._lastDimensions[e]) return n.props.onMeasure(t), r && void 0 !== n && n.setState({
                                            dimensions: t
                                        }), n._lastDimensions = t, !0
                                    }))
                                }
                            }, n.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, n._node = null, n._propsToMeasure = n._getPropsToMeasure(e), n._lastDimensions = {}, n
                        }
                        return function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                        }(t, e), o(t, [{
                            key: "componentDidMount",
                            value: function() {
                                var e = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new c.default((function() {
                                    return e.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(e) {
                                var t = (e.config, e.whitelist),
                                    n = e.blacklist;
                                this.props.whitelist === t && this.props.blacklist === n || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: t,
                                    blacklist: n
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = s.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, l.default)(e, {
                                    margin: t
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(e) {
                                var t = e.whitelist,
                                    n = e.blacklist;
                                return t.filter((function(e) {
                                    return n.indexOf(e) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.props.children;
                                return i.Children.only("function" == typeof e ? e(this.state.dimensions) : e)
                            }
                        }]), t
                    }(i.Component);
                f.propTypes = {
                    whitelist: a.default.array,
                    blacklist: a.default.array,
                    includeMargin: a.default.bool,
                    useClone: a.default.bool,
                    cloneOptions: a.default.object,
                    shouldMeasure: a.default.bool,
                    onMeasure: a.default.func
                }, f.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, t.default = f, e.exports = t.default
            }, function(e, t) {
                e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) {
                        var o = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        e.exports = n(5)((function(e) {
                            return "object" === (void 0 === e ? "undefined" : r(e)) && null !== e && e.$$typeof === o
                        }), !0)
                    } else e.exports = n(12)()
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n() {
                    throw new Error("setTimeout has not been defined")
                }

                function r() {
                    throw new Error("clearTimeout has not been defined")
                }

                function o(e) {
                    if (c === setTimeout) return setTimeout(e, 0);
                    if ((c === n || !c) && setTimeout) return c = setTimeout, setTimeout(e, 0);
                    try {
                        return c(e, 0)
                    } catch (t) {
                        try {
                            return c.call(null, e, 0)
                        } catch (t) {
                            return c.call(this, e, 0)
                        }
                    }
                }

                function i() {
                    y && p && (y = !1, p.length ? d = p.concat(d) : v = -1, d.length && u())
                }

                function u() {
                    if (!y) {
                        var e = o(i);
                        y = !0;
                        for (var t = d.length; t;) {
                            for (p = d, d = []; ++v < t;) p && p[v].run();
                            v = -1, t = d.length
                        }
                        p = null, y = !1,
                            function(e) {
                                if (l === clearTimeout) return clearTimeout(e);
                                if ((l === r || !l) && clearTimeout) return l = clearTimeout, clearTimeout(e);
                                try {
                                    l(e)
                                } catch (t) {
                                    try {
                                        return l.call(null, e)
                                    } catch (t) {
                                        return l.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function a(e, t) {
                    this.fun = e, this.array = t
                }

                function s() {}
                var c, l, f = e.exports = {};
                ! function() {
                    try {
                        c = "function" == typeof setTimeout ? setTimeout : n
                    } catch (e) {
                        c = n
                    }
                    try {
                        l = "function" == typeof clearTimeout ? clearTimeout : r
                    } catch (e) {
                        l = r
                    }
                }();
                var p, d = [],
                    y = !1,
                    v = -1;
                f.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    d.push(new a(e, t)), 1 !== d.length || y || o(u)
                }, a.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, f.title = "browser", f.browser = !0, f.env = {}, f.argv = [], f.version = "", f.versions = {}, f.on = s, f.addListener = s, f.once = s, f.off = s, f.removeListener = s, f.removeAllListeners = s, f.emit = s, f.prependListener = s, f.prependOnceListener = s, f.listeners = function(e) {
                    return []
                }, f.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, f.cwd = function() {
                    return "/"
                }, f.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, f.umask = function() {
                    return 0
                }
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        },
                        o = n(6),
                        i = n(7),
                        u = n(8),
                        a = n(9),
                        s = n(10),
                        c = n(11);
                    e.exports = function(e, n) {
                        function l(e, t) {
                            return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
                        }

                        function f(e) {
                            this.message = e, this.stack = ""
                        }

                        function p(e) {
                            function r(r, c, l, p, d, y, v) {
                                if (p = p || w, y = y || l, v !== s)
                                    if (n) i(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== t.env.NODE_ENV && "undefined" != typeof console) {
                                    var h = p + ":" + l;
                                    !o[h] && a < 3 && (u(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", y, p), o[h] = !0, a++)
                                }
                                return null == c[l] ? r ? new f(null === c[l] ? "The " + d + " `" + y + "` is marked as required in `" + p + "`, but its value is `null`." : "The " + d + " `" + y + "` is marked as required in `" + p + "`, but its value is `undefined`.") : null : e(c, l, p, d, y)
                            }
                            if ("production" !== t.env.NODE_ENV) var o = {},
                                a = 0;
                            var c = r.bind(null, !1);
                            return c.isRequired = r.bind(null, !0), c
                        }

                        function d(e) {
                            return p((function(t, n, r, o, i, u) {
                                var a = t[n];
                                return v(a) !== e ? new f("Invalid " + o + " `" + i + "` of type `" + h(a) + "` supplied to `" + r + "`, expected `" + e + "`.") : null
                            }))
                        }

                        function y(t) {
                            switch (void 0 === t ? "undefined" : r(t)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !t;
                                case "object":
                                    if (Array.isArray(t)) return t.every(y);
                                    if (null === t || e(t)) return !0;
                                    var n = function(e) {
                                        var t = e && (b && e[b] || e[g]);
                                        if ("function" == typeof t) return t
                                    }(t);
                                    if (!n) return !1;
                                    var o, i = n.call(t);
                                    if (n !== t.entries) {
                                        for (; !(o = i.next()).done;)
                                            if (!y(o.value)) return !1
                                    } else
                                        for (; !(o = i.next()).done;) {
                                            var u = o.value;
                                            if (u && !y(u[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function v(e) {
                            var t = void 0 === e ? "undefined" : r(e);
                            return Array.isArray(e) ? "array" : e instanceof RegExp ? "object" : function(e, t) {
                                return "symbol" === e || "Symbol" === t["@@toStringTag"] || "function" == typeof Symbol && t instanceof Symbol
                            }(t, e) ? "symbol" : t
                        }

                        function h(e) {
                            if (null == e) return "" + e;
                            var t = v(e);
                            if ("object" === t) {
                                if (e instanceof Date) return "date";
                                if (e instanceof RegExp) return "regexp"
                            }
                            return t
                        }

                        function m(e) {
                            var t = h(e);
                            switch (t) {
                                case "array":
                                case "object":
                                    return "an " + t;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + t;
                                default:
                                    return t
                            }
                        }
                        var b = "function" == typeof Symbol && Symbol.iterator,
                            g = "@@iterator",
                            w = "<<anonymous>>",
                            O = {
                                array: d("array"),
                                bool: d("boolean"),
                                func: d("function"),
                                number: d("number"),
                                object: d("object"),
                                string: d("string"),
                                symbol: d("symbol"),
                                any: p(o.thatReturnsNull),
                                arrayOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new f("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside arrayOf.");
                                        var u = t[n];
                                        if (!Array.isArray(u)) return new f("Invalid " + o + " `" + i + "` of type `" + v(u) + "` supplied to `" + r + "`, expected an array.");
                                        for (var a = 0; a < u.length; a++) {
                                            var c = e(u, a, r, o, i + "[" + a + "]", s);
                                            if (c instanceof Error) return c
                                        }
                                        return null
                                    }))
                                },
                                element: p((function(t, n, r, o, i) {
                                    var u = t[n];
                                    return e(u) ? null : new f("Invalid " + o + " `" + i + "` of type `" + v(u) + "` supplied to `" + r + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if (!(t[n] instanceof e)) {
                                            var u = e.name || w;
                                            return new f("Invalid " + o + " `" + i + "` of type `" + function(e) {
                                                return e.constructor && e.constructor.name ? e.constructor.name : w
                                            }(t[n]) + "` supplied to `" + r + "`, expected instance of `" + u + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: p((function(e, t, n, r, o) {
                                    return y(e[t]) ? null : new f("Invalid " + r + " `" + o + "` supplied to `" + n + "`, expected a ReactNode.")
                                })),
                                objectOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new f("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside objectOf.");
                                        var u = t[n],
                                            a = v(u);
                                        if ("object" !== a) return new f("Invalid " + o + " `" + i + "` of type `" + a + "` supplied to `" + r + "`, expected an object.");
                                        for (var c in u)
                                            if (u.hasOwnProperty(c)) {
                                                var l = e(u, c, r, o, i + "." + c, s);
                                                if (l instanceof Error) return l
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(e) {
                                    return Array.isArray(e) ? p((function(t, n, r, o, i) {
                                        for (var u = t[n], a = 0; a < e.length; a++)
                                            if (l(u, e[a])) return null;
                                        return new f("Invalid " + o + " `" + i + "` of value `" + u + "` supplied to `" + r + "`, expected one of " + JSON.stringify(e) + ".")
                                    })) : ("production" !== t.env.NODE_ENV && u(!1, "Invalid argument supplied to oneOf, expected an instance of array."), o.thatReturnsNull)
                                },
                                oneOfType: function(e) {
                                    if (!Array.isArray(e)) return "production" !== t.env.NODE_ENV && u(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), o.thatReturnsNull;
                                    for (var n = 0; n < e.length; n++) {
                                        var r = e[n];
                                        if ("function" != typeof r) return u(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", m(r), n), o.thatReturnsNull
                                    }
                                    return p((function(t, n, r, o, i) {
                                        for (var u = 0; u < e.length; u++)
                                            if (null == (0, e[u])(t, n, r, o, i, s)) return null;
                                        return new f("Invalid " + o + " `" + i + "` supplied to `" + r + "`.")
                                    }))
                                },
                                shape: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var u = t[n],
                                            a = v(u);
                                        if ("object" !== a) return new f("Invalid " + o + " `" + i + "` of type `" + a + "` supplied to `" + r + "`, expected `object`.");
                                        for (var c in e) {
                                            var l = e[c];
                                            if (l) {
                                                var p = l(u, c, r, o, i + "." + c, s);
                                                if (p) return p
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var u = t[n],
                                            c = v(u);
                                        if ("object" !== c) return new f("Invalid " + o + " `" + i + "` of type `" + c + "` supplied to `" + r + "`, expected `object`.");
                                        var l = a({}, t[n], e);
                                        for (var p in l) {
                                            var d = e[p];
                                            if (!d) return new f("Invalid " + o + " `" + i + "` key `" + p + "` supplied to `" + r + "`.\nBad object: " + JSON.stringify(t[n], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(e), null, "  "));
                                            var y = d(u, p, r, o, i + "." + p, s);
                                            if (y) return y
                                        }
                                        return null
                                    }))
                                }
                            };
                        return f.prototype = Error.prototype, O.checkPropTypes = c,
                            O.PropTypes = O, O
                    }
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    return function() {
                        return e
                    }
                }
                var r = function() {};
                r.thatReturns = n, r.thatReturnsFalse = n(!1), r.thatReturnsTrue = n(!0), r.thatReturnsNull = n(null), r.thatReturnsThis = function() {
                    return this
                }, r.thatReturnsArgument = function(e) {
                    return e
                }, e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var n = function(e) {};
                    "production" !== t.env.NODE_ENV && (n = function(e) {
                        if (void 0 === e) throw new Error("invariant requires an error message argument")
                    }), e.exports = function(e, t, r, o, i, u, a, s) {
                        if (n(t), !e) {
                            var c;
                            if (void 0 === t) c = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var l = [r, o, i, u, a, s],
                                    f = 0;
                                (c = new Error(t.replace(/%s/g, (function() {
                                    return l[f++]
                                })))).name = "Invariant Violation"
                            }
                            throw c.framesToPop = 1, c
                        }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = n(6);
                    if ("production" !== t.env.NODE_ENV) {
                        var o = function(e) {
                            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            var o = 0,
                                i = "Warning: " + e.replace(/%s/g, (function() {
                                    return n[o++]
                                }));
                            "undefined" != typeof console && console.error(i);
                            try {
                                throw new Error(i)
                            } catch (e) {}
                        };
                        r = function(e, t) {
                            if (void 0 === t) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== t.indexOf("Failed Composite propType: ") && !e) {
                                for (var n = arguments.length, r = Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                                o.apply(void 0, [t].concat(r))
                            }
                        }
                    }
                    e.exports = r
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }
                var r = Object.getOwnPropertySymbols,
                    o = Object.prototype.hasOwnProperty,
                    i = Object.prototype.propertyIsEnumerable;
                e.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var e = new String("abc");
                        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
                        if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                                return t[e]
                            })).join("")) return !1;
                        var r = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                            r[e] = e
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
                    } catch (e) {
                        return !1
                    }
                }() ? Object.assign : function(e, t) {
                    for (var u, a, s = n(e), c = 1; c < arguments.length; c++) {
                        for (var l in u = Object(arguments[c])) o.call(u, l) && (s[l] = u[l]);
                        if (r) {
                            a = r(u);
                            for (var f = 0; f < a.length; f++) i.call(u, a[f]) && (s[a[f]] = u[a[f]])
                        }
                    }
                    return s
                }
            }, function(e, t) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) var o = n(7),
                        i = n(8),
                        u = n(10),
                        a = {};
                    e.exports = function(e, n, s, c, l) {
                        if ("production" !== t.env.NODE_ENV)
                            for (var f in e)
                                if (e.hasOwnProperty(f)) {
                                    var p;
                                    try {
                                        o("function" == typeof e[f], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", c || "React class", s, f, r(e[f])), p = e[f](n, f, c, s, null, u)
                                    } catch (e) {
                                        p = e
                                    }
                                    if (i(!p || p instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", c || "React class", s, f, void 0 === p ? "undefined" : r(p)), p instanceof Error && !(p.message in a)) {
                                        a[p.message] = !0;
                                        var d = l ? l() : "";
                                        i(!1, "Failed %s type: %s%s", s, p.message, null != d ? d : "")
                                    }
                                }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                "use strict";
                var r = n(6),
                    o = n(7),
                    i = n(10);
                e.exports = function() {
                    function e(e, t, n, r, u, a) {
                        a !== i && o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function t() {
                        return e
                    }
                    e.isRequired = e;
                    var n = {
                        array: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: t,
                        element: e,
                        instanceOf: t,
                        node: e,
                        objectOf: t,
                        oneOf: t,
                        oneOfType: t,
                        shape: t,
                        exact: t
                    };
                    return n.checkPropTypes = r, n.PropTypes = n, n
                }
            }, function(e, t) {
                e.exports = o
            }, function(e, t) {
                e.exports = i
            }, function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = e.getBoundingClientRect(),
                        o = void 0,
                        i = void 0,
                        u = void 0;
                    return t.margin && (u = (0, r.default)(getComputedStyle(e))), t.margin ? (o = u.left + n.width + u.right, i = u.top + n.height + u.bottom) : (o = n.width, i = n.height), {
                        width: o,
                        height: i,
                        top: n.top,
                        right: n.right,
                        bottom: n.bottom,
                        left: n.left
                    }
                };
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(16));
                e.exports = t.default
            }, function(e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    return {
                        top: n((e = e || {}).marginTop),
                        right: n(e.marginRight),
                        bottom: n(e.marginBottom),
                        left: n(e.marginLeft)
                    }
                };
                var n = function(e) {
                    return parseInt(e) || 0
                };
                e.exports = t.default
            }]))
        }
    }
]);
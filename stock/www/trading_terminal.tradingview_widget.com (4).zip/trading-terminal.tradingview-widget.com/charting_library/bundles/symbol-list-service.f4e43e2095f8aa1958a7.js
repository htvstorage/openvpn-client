"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [1026], {
        5011: (e, t, n) => {
            n.r(t), n.d(t, {
                activeSymbolListNavigator: () => u
            });
            var o = n(54773),
                s = n(36349),
                i = n(82027),
                l = n(1373),
                r = n(88401),
                c = n(6474);

            function* u() {
                const e = (0, o.eventChannel)(e => {
                    const t = (t, n) => {
                            t.target === document.body && e(n)
                        },
                        n = i.createGroup({
                            desc: "Active Symbol List Navigation"
                        });
                    return n.add({
                        desc: "Select previous symbol",
                        hotkey: 38,
                        handler: e => t(e, "previous")
                    }), n.add({
                        desc: "Select previous symbol",
                        hotkey: i.Modifiers.Shift + 32,
                        handler: e => t(e, "previous")
                    }), n.add({
                        desc: "Select next symbol",
                        hotkey: 32,
                        handler: e => t(e, "next")
                    }), n.add({
                        desc: "Select next symbol",
                        hotkey: 40,
                        handler: e => t(e, "next")
                    }), () => n.destroy()
                });
                try {
                    for (;;) {
                        const t = yield(0, s.take)(e), n = (0, l.getGlobalActiveSymbolList)(yield(0, s.select)());
                        if (null === n) continue;
                        const {
                            symbols: o
                        } = n;
                        if (0 === o.length) continue;
                        const i = (0, c.getSymbolFromList)(r.linking.symbol.value(), o),
                            u = o.indexOf(i || "");
                        switch (t) {
                            case "previous":
                                {
                                    const e = -1 === u ? o.length - 1 : (u + o.length - 1) % o.length;
                                    if ((0, c.isValidSeparatorItem)(o[e])) {
                                        const t = (0, c.findNextAvailableSymbol)(e, o, "previous");
                                        t && r.linking.symbol.setValue(t);
                                        break
                                    }
                                    r.linking.symbol.setValue(o[e]);
                                    break
                                }
                            case "next":
                                {
                                    const e = -1 === u ? 0 : (u + o.length + 1) % o.length;
                                    if ((0, c.isValidSeparatorItem)(o[e])) {
                                        const t = (0, c.findNextAvailableSymbol)(e, o, "next");
                                        t && r.linking.symbol.setValue(t);
                                        break
                                    }
                                    r.linking.symbol.setValue(o[e]);
                                    break
                                }
                        }
                    }
                } finally {
                    e.close()
                }
            }
        },
        2595: (e, t, n) => {
            n.r(t), n.d(t, {
                configureStore: () => y
            });
            var o = n(93921),
                s = n(54773),
                i = n(83243),
                l = n(44e3),
                r = n(70644);

            function c(e, t, n, o) {
                return {
                    id: e,
                    tickerType: t,
                    columns: n,
                    options: o,
                    selectedSymbols: [],
                    sorting: null,
                    highlightedSymbols: null,
                    listId: null,
                    isLoading: !1,
                    symbolsBeforeSorting: null,
                    scrollToId: null
                }
            }

            function u(e, t) {
                return { ...e,
                    [t]: { ...e[t],
                        sorting: null,
                        symbolsBeforeSorting: null
                    }
                }
            }
            var a = n(6474);
            const d = (0, i.combineReducers)({
                positions: function(e = {}, t) {
                    switch (t.type) {
                        case r.UPDATE_POSITIONS:
                            {
                                const {
                                    symbol: n,
                                    position: o
                                } = t;
                                return (0, a.isEqualRecords)(e[n], o) ? e : { ...e,
                                    [n]: o
                                }
                            }
                        case r.UPDATE_BULK_POSITIONS:
                            {
                                const {
                                    map: n
                                } = t,
                                o = { ...e
                                };
                                let s = !1;
                                for (const [t, i] of Object.entries(n))(0, a.isEqualRecords)(e[t], i) || (s = !0, o[t] = i);
                                return s ? o : e
                            }
                        default:
                            return e
                    }
                },
                customLists: l.reducer,
                hotLists: (e, t) => null,
                markedLists: (e, t) => null,
                widgets: function(e = {}, t) {
                    if (l.setup.match(t) || l.insert.match(t) || l.exclude.match(t) || l.exact.match(t) || l.replace.match(t)) {
                        let t = e;
                        for (const n of Object.values(e)) {
                            const {
                                listId: o
                            } = n;
                            null !== o && (t = u(e, n.id))
                        }
                        return t
                    }
                    return function(e = {}, t) {
                        var n;
                        switch (t.type) {
                            case r.INIT_WIDGET:
                                {
                                    const {
                                        id: n,
                                        tickerType: o,
                                        columns: s,
                                        options: i
                                    } = t;
                                    return { ...e,
                                        [n]: c(n, o, s, i)
                                    }
                                }
                            case r.UPDATE_WIDGET:
                                {
                                    const {
                                        widgetId: o,
                                        widget: s
                                    } = t,
                                    i = { ...e,
                                        [o]: { ...e[o],
                                            ...s
                                        }
                                    },
                                    l = e[o].tickerType,
                                    r = s.tickerType,
                                    c = "short_name" === (null === (n = e[o].sorting) || void 0 === n ? void 0 : n.column);
                                    return l !== r && c ? u(i, o) : i
                                }
                            case r.UPDATE_WIDGET_OPTIONS:
                                {
                                    const {
                                        widgetId: n,
                                        options: o
                                    } = t;
                                    return { ...e,
                                        [n]: { ...e[n],
                                            options: { ...e[n].options,
                                                ...o
                                            }
                                        }
                                    }
                                }
                            default:
                                return e
                        }
                    }(e, t)
                },
                isAuthenticated: () => !1,
                activeSymbolList: function(e = null, t) {
                    switch (t.type) {
                        case r.UPDATE_ACTIVE_LIST:
                            return t.id;
                        default:
                            return e
                    }
                }
            });

            function y() {
                const e = (0, s.default)();
                return {
                    store: (0, o.configureStore)({
                        reducer: d,
                        middleware: t => [...t(), e, null, null].filter(e => null !== e)
                    }),
                    runner: e
                }
            }
        },
        15078: (e, t, n) => {
            function o(e) {
                return t => e + "__" + t
            }
            n.d(t, {
                createActionTypeFactory: () => o
            })
        }
    }
]);
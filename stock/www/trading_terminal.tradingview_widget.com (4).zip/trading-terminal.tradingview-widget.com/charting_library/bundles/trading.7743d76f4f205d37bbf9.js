(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [5142, 8890], {
        86782: (e, t, i) => {
            e.exports = i.p + "alarm_clock.48d3df0afe4d4981523b8a12e4e25f92.mp3"
        },
        82406: e => {
            e.exports = {
                button: "button-jdoBnXUp"
            }
        },
        58248: e => {
            e.exports = {
                "trading-panel-content": "trading-panel-content-G1Lpivae",
                "trading-panel-spinner": "trading-panel-spinner-G1Lpivae",
                "trading-panel-handle": "trading-panel-handle-G1Lpivae"
            }
        },
        14660: e => {
            e.exports = {
                loader: "loader-bnNqbPQ6",
                "loader-animation": "loader-animation-bnNqbPQ6",
                loaderCircle: "loaderCircle-bnNqbPQ6"
            }
        },
        40541: e => {
            e.exports = {
                loader: "loader-nO79xRI2",
                loaderItem: "loaderItem-nO79xRI2",
                "loader-animation": "loader-animation-nO79xRI2",
                touchMode: "touchMode-nO79xRI2"
            }
        },
        6968: e => {
            e.exports = {
                blockHidden: "blockHidden-cdtqi65y",
                "pane-button": "pane-button-cdtqi65y"
            }
        },
        88603: e => {
            e.exports = {
                "css-value-padding": "4px"
            }
        },
        69234: e => {
            e.exports = {
                "css-value-padding": "4px",
                wrapper: "wrapper-LlcFLhWF",
                notAvailableOnMobile: "notAvailableOnMobile-LlcFLhWF",
                column: "column-LlcFLhWF",
                button: "button-LlcFLhWF",
                sellButton: "sellButton-LlcFLhWF",
                buyButton: "buyButton-LlcFLhWF",
                brokerButton: "brokerButton-LlcFLhWF",
                highButtons: "highButtons-LlcFLhWF",
                withoutBg: "withoutBg-LlcFLhWF",
                lastCharSup: "lastCharSup-LlcFLhWF",
                spreadQtyWrapper: "spreadQtyWrapper-LlcFLhWF",
                spread: "spread-LlcFLhWF",
                withoutQty: "withoutQty-LlcFLhWF",
                qty: "qty-LlcFLhWF",
                loader: "loader-LlcFLhWF",
                circleLoader: "circleLoader-LlcFLhWF",
                loading: "loading-LlcFLhWF",
                buttonText: "buttonText-LlcFLhWF",
                brokerButtonIconWrap: "brokerButtonIconWrap-LlcFLhWF",
                brokerButtonDefault: "brokerButtonDefault-LlcFLhWF",
                touchMode: "touchMode-LlcFLhWF",
                buttons: "buttons-LlcFLhWF"
            }
        },
        52521: e => {
            e.exports = {
                popupWrapper: "popupWrapper-JbzOgGY4"
            }
        },
        96746: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        67179: e => {
            e.exports = {
                dialog: "dialog-HExheUfY",
                wrapper: "wrapper-HExheUfY",
                separator: "separator-HExheUfY"
            }
        },
        91441: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                container: "container-tuOy5zvD",
                unsetAlign: "unsetAlign-tuOy5zvD",
                title: "title-tuOy5zvD",
                subtitle: "subtitle-tuOy5zvD",
                ellipsis: "ellipsis-tuOy5zvD",
                close: "close-tuOy5zvD"
            }
        },
        91626: e => {
            e.exports = {
                separator: "separator-jtAq6E4V"
            }
        },
        72571: (e, t, i) => {
            "use strict";
            i.d(t, {
                Icon: () => r
            });
            var s = i(59496);
            const r = s.forwardRef((e, t) => {
                const {
                    icon: i = "",
                    ...r
                } = e;
                return s.createElement("span", { ...r,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: i
                    }
                })
            })
        },
        417: (e, t, i) => {
            "use strict";

            function s(e) {
                return o(e, n)
            }

            function r(e) {
                return o(e, a)
            }

            function o(e, t) {
                const i = Object.entries(e).filter(t),
                    s = {};
                for (const [e, t] of i) s[e] = t;
                return s
            }

            function n(e) {
                const [t, i] = e;
                return 0 === t.indexOf("data-") && "string" == typeof i
            }

            function a(e) {
                return 0 === e[0].indexOf("aria-")
            }
            i.d(t, {
                filterDataProps: () => s,
                filterAriaProps: () => r,
                filterProps: () => o,
                isDataAttribute: () => n,
                isAriaAttribute: () => a
            })
        },
        36376: (e, t, i) => {
            "use strict";
            i.d(t, {
                filterDurationsByOrderType: () => m,
                formatDateTime: () => _,
                formatTime: () => p,
                getTimestamp: () => l,
                makeInitialOrderDuration: () => a,
                makeOrderDuration: () => b
            });
            var s = i(88537);
            const r = JSON.parse('{"ar_AE":{"language":"ar","language_name":"العربية","flag":"ae","geoip_code":"ae","countries_with_this_language":["ae","bh","dj","dz","eg","er","iq","jo","km","kw","lb","ly","ma","mr","om","qa","sa","sd","so","sy","td","tn","ye"],"priority":500,"is_site_locale":true,"dir":"rtl","iso":"ar","iso_639_3":"arb","show_on_widgets":true,"name_on_widgets":"العَرَبِيَّة‎‎","global_name":"Arabic"},"br":{"language":"pt","language_name":"Português","flag":"br","geoip_code":"br","priority":650,"is_site_locale":true,"iso":"pt","iso_639_3":"por","show_on_widgets":true,"name_on_widgets":"Português","global_name":"Portuguese"},"cs":{"language":"cs","language_name":"Czech","flag":"cz","geoip_code":"cz","priority":718,"is_site_locale":true,"iso":"cs","iso_639_3":"ces","show_on_widgets":true,"name_on_widgets":"Česky","global_name":"Czech","is_in_european_union":true,"isBattle":true},"de_DE":{"language":"de","language_name":"Deutsch","flag":"de","geoip_code":"de","countries_with_this_language":["at","ch"],"priority":756,"is_site_locale":true,"iso":"de","iso_639_3":"de","show_on_widgets":true,"name_on_widgets":"Deutsch","global_name":"German","is_in_european_union":true},"en":{"language":"en","language_name":"English","flag":"us","geoip_code":"us","priority":1000,"is_site_locale":true,"iso":"en","iso_639_3":"eng","show_on_widgets":true,"name_on_widgets":"English","global_name":"English","is_only_recommended_tw_autorepost":true},"es":{"language":"es","language_name":"Español","flag":"es","geoip_code":"es","countries_with_this_language":["mx","ar","ve","cl","co","pe","uy","py","cr","gt","c","bo","pa","pr"],"priority":744,"is_site_locale":true,"iso":"es","iso_639_3":"spa","show_on_widgets":true,"name_on_widgets":"Español","global_name":"Spanish","is_in_european_union":true},"fa_IR":{"language":"fa","language_name":"فارسى","flag":"ir","geoip_code":"ir","priority":480,"is_site_locale":true,"dir":"rtl","iso":"fa","iso_639_3":"fas","show_on_widgets":true,"name_on_widgets":"فارسی","global_name":"Iranian"},"fr":{"language":"fr","language_name":"Français","flag":"fr","geoip_code":"fr","priority":750,"is_site_locale":true,"iso":"fr","iso_639_3":"fra","show_on_widgets":true,"name_on_widgets":"French","global_name":"French","is_in_european_union":true},"he_IL":{"language":"he_IL","language_name":"עברית","flag":"il","geoip_code":"il","priority":490,"is_site_locale":true,"dir":"rtl","iso":"he","iso_639_3":"heb","show_on_widgets":true,"name_on_widgets":"‏עברית‏","global_name":"Israeli"},"hu_HU":{"language":"hu_HU","language_name":"Magyar","flag":"hu","geoip_code":"hu","priority":724,"is_site_locale":true,"iso":"hu","iso_639_3":"hun","show_on_widgets":true,"name_on_widgets":"Magyar","global_name":"Hungarian","is_in_european_union":true},"id":{"language":"id_ID","language_name":"Bahasa Indonesia","flag":"id","geoip_code":"id","priority":648,"is_site_locale":true,"iso":"id","iso_639_3":"ind","show_on_widgets":true,"name_on_widgets":"Indonesia","global_name":"Indonesian"},"in":{"language":"en","language_name":"English ‎(India)‎","flag":"in","geoip_code":"in","priority":800,"is_site_locale":true,"iso":"en","iso_639_3":"eng","show_on_widgets":true,"name_on_widgets":"India","global_name":"Indian"},"it":{"language":"it","language_name":"Italiano","flag":"it","geoip_code":"it","priority":737,"is_site_locale":true,"iso":"it","iso_639_3":"ita","show_on_widgets":true,"name_on_widgets":"Italiano","global_name":"Italian","is_in_european_union":true},"ja":{"language":"ja","language_name":"日本語","flag":"jp","geoip_code":"jp","priority":600,"is_site_locale":true,"iso":"ja","iso_639_3":"jpn","show_on_widgets":true,"name_on_widgets":"日本語","global_name":"Japanese"},"kr":{"language":"ko","language_name":"한국어","flag":"kr","geoip_code":"kr","priority":550,"is_site_locale":true,"iso":"ko","iso_639_3":"kor","show_on_widgets":true,"name_on_widgets":"한국어","global_name":"Korean"},"ms_MY":{"language":"ms_MY","language_name":"Bahasa Melayu","flag":"my","geoip_code":"my","priority":647,"is_site_locale":true,"iso":"ms","iso_639_3":"zlm","show_on_widgets":true,"name_on_widgets":"Malay [Malaysia]","global_name":"Malaysian"},"pl":{"language":"pl","language_name":"Polski","flag":"pl","geoip_code":"pl","priority":725,"is_site_locale":true,"iso":"pl","iso_639_3":"pol","show_on_widgets":true,"name_on_widgets":"Polski","global_name":"Polish","is_in_european_union":true},"ru":{"language":"ru","language_name":"Русский","flag":"ru","geoip_code":"ru","countries_with_this_language":["am","by","kg","kz","md","tj","tm","uz"],"priority":700,"is_site_locale":true,"iso":"ru","iso_639_3":"rus","show_on_widgets":true,"name_on_widgets":"Русский","global_name":"Russian","is_only_recommended_tw_autorepost":true},"sv_SE":{"language":"sv","language_name":"Svenska","flag":"se","geoip_code":"se","priority":723,"is_site_locale":true,"iso":"sv","iso_639_3":"swe","show_on_widgets":true,"name_on_widgets":"Swedish","global_name":"Swedish","is_in_european_union":true},"th_TH":{"language":"th","language_name":"ภาษาไทย","flag":"th","geoip_code":"th","priority":646,"is_site_locale":true,"iso":"th","iso_639_3":"tha","show_on_widgets":true,"name_on_widgets":"ภาษาไทย","global_name":"Thai"},"tr":{"language":"tr","language_name":"Türkçe","flag":"tr","geoip_code":"tr","priority":713,"is_site_locale":true,"iso":"tr","iso_639_3":"tur","show_on_widgets":true,"name_on_widgets":"Türkçe","global_name":"Turkish","is_only_recommended_tw_autorepost":true},"vi_VN":{"language":"vi","language_name":"Tiếng Việt","flag":"vn","geoip_code":"vn","priority":645,"is_site_locale":true,"iso":"vi","iso_639_3":"vie","show_on_widgets":true,"name_on_widgets":"Tiếng Việt","global_name":"Vietnamese"},"zh_CN":{"language":"zh","language_name":"简体中文","flag":"cn","geoip_code":"cn","countries_with_this_language":["zh"],"priority":537,"is_site_locale":true,"iso":"zh-Hans","iso_639_3":"cmn","show_on_widgets":true,"name_on_widgets":"简体中文","global_name":"Chinese"},"zh_TW":{"language":"zh_TW","language_name":"繁體中文","flag":"tw","geoip_code":"tw","countries_with_this_language":["hk"],"priority":536,"is_site_locale":true,"iso":"zh-Hant","iso_639_3":"cmn","show_on_widgets":true,"name_on_widgets":"繁體中文","global_name":"Taiwanese"},"el":{"language":"el","language_name":"Greek","flag":"gr","geoip_code":"gr","priority":625,"is_site_locale":true,"iso":"el","iso_639_3":"ell","global_name":"Greek","is_in_european_union":true,"isBattle":true},"nl_NL":{"language":"nl_NL","language_name":"Dutch","flag":"nl","geoip_code":"nl","priority":731,"is_site_locale":true,"iso":"nl","iso_639_3":"nld","global_name":"Dutch","is_in_european_union":true,"isBattle":true},"ro":{"language":"ro","language_name":"Romanian","flag":"ro","geoip_code":"ro","priority":707,"is_site_locale":true,"iso":"ro","iso_639_3":"nld","global_name":"Romanian","is_in_european_union":true,"isBattle":true}}'),
                o = function() {
                    const e = document.querySelectorAll("link[rel~=link-locale][data-locale]");
                    if (0 === e.length) return r;
                    const t = {};
                    return e.forEach(e => {
                        const i = (0, s.ensureNotNull)(e.getAttribute("data-locale"));
                        t[i] = { ...r[i],
                            href: e.href
                        }
                    }), t
                }();
            var n = i(50681);

            function a(e, t) {
                var i;
                const s = m(e, t);
                if (0 === s.length) return null;
                return b(null !== (i = s.find(e => e.default)) && void 0 !== i ? i : s[0])
            }

            function l(e) {
                return e.valueOf()
            }
            const c = (d = d || window.locale, null === (u = o[d]) || void 0 === u ? void 0 : u.iso);
            var d, u;
            const h = new Intl.DateTimeFormat(c, {
                hour: "2-digit",
                minute: "2-digit"
            });

            function p(e) {
                return h.format(e)
            }

            function _(e, t) {
                return (t.hasDatePicker ? function(e) {
                    const t = e.toLocaleString(c, {
                            day: "2-digit"
                        }),
                        i = e.toLocaleString(c, {
                            month: "2-digit"
                        });
                    return `${e.toLocaleString(c,{year:"numeric"})}-${i}-${t}`
                }(e) : "") + (t.hasTimePicker ? ", " + p(e) : "")
            }
            const g = [1, 3, 4];

            function m(e, t) {
                return t.filter(t => {
                    var i;
                    const s = null !== (i = t.supportedOrderTypes) && void 0 !== i ? i : g;
                    return null === e || s.includes(e)
                })
            }

            function b(e) {
                const t = {
                    type: e.value
                };
                var i;
                return i = e, Boolean(i.hasTimePicker || i.hasDatePicker) && (t.datetime = l((0, n.makeDatePlus24UTCHours)())), t
            }
        },
        297: (e, t, i) => {
            "use strict";
            i.d(t, {
                ButtonType: () => s,
                Button: () => n
            });
            var s, r = i(59496),
                o = i(82406);
            ! function(e) {
                e[e.PlusValue = 0] = "PlusValue", e[e.IncDec = 1] = "IncDec", e[e.Clear = 2] = "Clear", e[e.Default = 3] = "Default"
            }(s || (s = {}));
            class n extends r.PureComponent {
                constructor(e) {
                    super(e), this._createClickHandler = (e, t = s.Default) => () => {
                        this.props.onClick(e, t)
                    }
                }
                render() {
                    let e;
                    switch (this.props.type) {
                        case s.PlusValue:
                        case s.IncDec:
                            e = this.props.value;
                            break;
                        case s.Clear:
                            e = "clear";
                            break;
                        case s.Default:
                            e = "default"
                    }
                    return r.createElement("div", {
                        className: o.button,
                        "data-value": e,
                        "data-name": "qtyButtonCalculator-" + e,
                        onClick: this._createClickHandler(this.props.value, this.props.type)
                    }, this.props.icon || this.props.value)
                }
            }
        },
        6313: (e, t, i) => {
            "use strict";
            i.d(t, {
                LoaderBaseRenderer: () => r
            });
            var s = i(6968);
            class r {
                constructor(e, t = {}) {
                    this._loadingEl = document.createElement("span"), this._renderLoading(t), this.toggleVisibility(!1), e.appendChild(this._loadingEl)
                }
                toggleVisibility(e) {
                    this._loadingEl.classList.toggle(s.blockHidden, !e)
                }
                _renderLoading(e) {
                    const {
                        className: t
                    } = e;
                    t && this._loadingEl.classList.add(t)
                }
            }
        },
        33480: (e, t, i) => {
            "use strict";
            i.d(t, {
                LoaderPointsRenderer: () => o
            });
            var s = i(6313),
                r = i(40541);
            class o extends s.LoaderBaseRenderer {
                _renderLoading(e) {
                    super._renderLoading(e), this._loadingEl.innerHTML = `\n\t\t\t<span class="${r.loaderItem}"></span>\n\t\t\t<span class="${r.loaderItem}"></span>\n\t\t\t<span class="${r.loaderItem}"></span>\n\t\t`, this._loadingEl.classList.add(r.loader)
                }
            }
        },
        37969: (e, t, i) => {
            "use strict";
            i.d(t, {
                trackingModeIsAvailable: () => s
            });
            const s = i(1227).CheckMobile.any()
        },
        38186: (e, t, i) => {
            "use strict";
            i.d(t, {
                makeAccountManagerHeaderDropdownsProps: () => h
            });
            var s = i(88537),
                r = i(50681),
                o = i(80802),
                n = i(52275),
                a = i(51951),
                l = i(50317);
            const c = (0, a.getLogger)("Trading.DataExport");
            class d {
                constructor(e, t) {
                    this._prefix = t, this._getDataExporters = e
                }
                tabs() {
                    return [...this._getDataExporters()].map(([e, t]) => ({
                        value: e,
                        content: t.title
                    }))
                }
                async exportData(e) {
                    const {
                        exporters: t,
                        title: i
                    } = (0,
                        s.ensureDefined)(this._getDataExporters().get(e), "data exporter");
                    try {
                        const e = await Promise.all(t.map(({
                            exportData: e
                        }) => e()));
                        e.forEach((s, r) => {
                            const a = t[r].name,
                                l = void 0 === a || "" === a ? `${(0,o.default)(i)}${e.length>1?"-"+(r+1):""}` : (0, o.default)(a);
                            let c = "";
                            if (0 !== s.length) {
                                const e = [u(Object.keys(s[0]))];
                                for (const t of s) e.push(u(Object.values(t)));
                                c = e.join("\n")
                            }(0, n.saveTextFile)(`${(0,o.default)(this._prefix)}-${l}-${(new Date).toISOString()}.csv`, c, "text/csv")
                        })
                    } catch (e) {
                        c.logError((0, l.getLoggerMessage)(e))
                    }
                }
            }

            function u(e) {
                return e.map(n.escapeCSVValue).join(",")
            }
            async function h(e, t, i) {
                const o = e.brokersList().filter(e => !e.configFlags.isSuspended),
                    n = Promise.resolve(void 0),
                    a = (0, s.ensureNotNull)(e.activeBroker()),
                    l = await n,
                    c = await a.accountsMetainfo(),
                    u = a.accountManagerInfo();
                if (0 === c.length) return;
                const h = c.map(e => {
                        var t;
                        return {
                            id: e.id,
                            name: e.name,
                            callBack: async () => {
                                e.id !== a.currentAccount() && a.setCurrentAccount(e.id)
                            },
                            currency: "" === e.currency ? void 0 : null !== (t = e.currency) && void 0 !== t ? t : void 0
                        }
                    }),
                    p = h.find(e => e.id === a.currentAccount()),
                    _ = a.metainfo(),
                    g = void 0 !== l ? (0, r.brokersListFromPlans)(o, l) : void 0;
                return {
                    brokerDropdownProps: void 0 === g ? void 0 : {
                        title: u.accountTitle,
                        brokerName: _.title,
                        logo: _.logoMiniUrl,
                        logoBlack: _.logoMiniBlackUrl,
                        actions: a.buttonDropdownActions(),
                        dataExportController: void 0 !== i ? new d(i, _.title) : void 0,
                        trading: e,
                        brokers: g,
                        initialSummaryFieldsVisibilityInfo: t.fieldsVisibilityInfo(),
                        summaryFieldsVisibilityInfo$: t.fieldsVisibilityInfo$,
                        summaryFieldToggler: t.toggleField
                    },
                    accountDropdownProps: {
                        currentAccount: (0, s.ensureDefined)(p),
                        accountsList: h,
                        currentAccountUpdate: a.currentAccountUpdate
                    }
                }
            }
        },
        56656: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                SummaryFieldsVisibilityManager: () => r
            });
            var s = i(47488);
            class r {
                constructor(e, t) {
                    var i;
                    this.toggleField = e => {
                        var t;
                        const i = this._fieldsVisibilityInfo$.getValue(),
                            s = new Map(i),
                            r = s.get(e);
                        void 0 !== r && (r.visible = !r.visible, this._fieldsVisibilityInfo$.next(s), null === (t = this._settingsGetter()) || void 0 === t || t.setSummaryFieldsVisibilityInfo(s))
                    }, this._settingsGetter = t;
                    const r = null === (i = this._settingsGetter()) || void 0 === i ? void 0 : i.summaryFieldsVisibilityInfo();
                    this._fieldsVisibilityInfo$ = new s.BehaviorSubject(new Map(e.map(({
                        text: e,
                        isDefault: t
                    }) => {
                        var i, s, o;
                        return [e, {
                            id: e,
                            visible: null === (o = null !== (s = null === (i = null == r ? void 0 : r.get(e)) || void 0 === i ? void 0 : i.visible) && void 0 !== s ? s : t) || void 0 === o || o
                        }]
                    }))), this.fieldsVisibilityInfo$ = this._fieldsVisibilityInfo$.asObservable()
                }
                fieldsVisibilityInfo() {
                    return this._fieldsVisibilityInfo$.getValue()
                }
            }
        },
        7053: (e, t, i) => {
            "use strict";
            i.d(t, {
                BrokerService: () => r
            });
            var s = i(88537);
            class r {
                constructor(e) {
                    this._activeBroker = null, this._trading = e, this._trading.onConnectionStatusChange.subscribe(this, this._onStatusChange), this._onStatusChange(this._trading.connectStatus())
                }
                activeBroker() {
                    return this._activeBroker
                }
                trading() {
                    return this._trading
                }
                _stopService() {
                    this.stopService(), (0, s.ensureNotNull)(this._activeBroker).currentAccountUpdate.unsubscribeAll(this)
                }
                _startService() {
                    this.startService(), (0,
                        s.ensureNotNull)(this._activeBroker).currentAccountUpdate.subscribe(this, this._onCurrentAccountUpdate)
                }
                _onStatusChange(e) {
                    const t = this._trading.activeBroker();
                    this._activeBroker === t && 1 === e || (null !== this._activeBroker && (this._stopService(), this._activeBroker = null), null !== t && 1 === e && (this._activeBroker = t, this._startService(), this._lastAccountId = t.currentAccount()))
                }
                _onCurrentAccountUpdate() {
                    const e = (0, s.ensureNotNull)(this._activeBroker);
                    this._lastAccountId !== e.currentAccount() && (this.stopService(), this.startService(), this._lastAccountId = e.currentAccount())
                }
            }
        },
        71476: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                addBroker: () => le,
                brokersList: () => ce,
                createBrokerConnection: () => ue
            });
            var s = i(25177),
                r = i(16193),
                o = i(82527),
                n = i(2683),
                a = i(97496),
                l = i.n(a),
                c = i(88537);
            class d {
                constructor(e) {
                    this._objects = {}, this._started = !1, this._isObjectsRequestActual = !1, this._ordersPromise = null, this._getter = e, this.updateDelegate = new(l()), this.partialUpdateDelegate = new(l())
                }
                start() {
                    this._started || (this._started = !0, this._ordersPromise = this._requestObjects())
                }
                stop() {
                    this._objects = {}, this._started = !1, this._ordersPromise = null, this._isObjectsRequestActual = !1
                }
                update(e, t) {
                    this._started && (this._isObjectsRequestActual ? this._isObjectsRequestActual = !1 : (this._objects[e.id] = e, this._onObjectUpdated(e, t)))
                }
                partialUpdate(e, t) {
                    if (!this._started) return;
                    if (this._isObjectsRequestActual) return void(this._isObjectsRequestActual = !1);
                    let i, s;
                    (0, n.isObject)(e) ? (i = e.id, s = e) : (i = e, s = (0, c.ensure)(t));
                    const r = this._objects[i];
                    r && (Object.assign(r, s), this.partialUpdateDelegate.fire(r, s))
                }
                fullUpdate() {
                    this._started && (this._isObjectsRequestActual ? this._isObjectsRequestActual = !1 : this._ordersPromise = this._requestObjects())
                }
                getObjects() {
                    return this._ordersPromise || Promise.resolve(Object.values(this._objects))
                }
                _onObjectUpdated(e, t) {
                    this.updateDelegate.fire(e, t)
                }
                _onAllObjectsUpdated() {
                    this._objectsCache().forEach(e => this.updateDelegate.fire(e, !0))
                }
                _objectsCache() {
                    return Object.values(this._objects)
                }
                async _requestObjects() {
                    let e = [];
                    do {
                        this._isObjectsRequestActual = !0, e = await this._getter()
                    } while (!this._isObjectsRequestActual);
                    var t;
                    return this._objects = (t = "id", e.reduce((e, i) => (e[i[t]] = i, e), {})), this._ordersPromise = null, this._isObjectsRequestActual = !1, this._onAllObjectsUpdated(), e
                }
            }
            var u = i(51951),
                h = i(91371);
            class p extends d {
                constructor(e, t) {
                    super(e), this._brokerConfigGetter = t
                }
                _onObjectUpdated(e, t) {
                    this._patchTrades(this._objectsCache().filter(t => t.symbol === e.symbol && 0 !== t.qty), e, t), super._onObjectUpdated(e, t)
                }
                _onAllObjectsUpdated() {
                    this._patchTrades(this._objectsCache().filter(e => 0 !== e.qty)), super._onAllObjectsUpdated()
                }
                _patchTrades(e, t, i) {
                    const s = this._brokerConfigGetter();
                    let r;
                    r = s.requiresFIFOCloseTrades ? s.fifoOnlyForSameQty ? m : g : _;
                    const o = r(e);
                    for (const e of o) t !== e && super._onObjectUpdated(e, i)
                }
            }

            function _(e) {
                const t = [];
                for (const i of e) i.canBeClosed || (i.canBeClosed = !0, t.push(i));
                return t
            }

            function g(e) {
                const t = {};
                for (const i of e) {
                    let e = t[i.symbol];
                    void 0 === e && (e = {
                        oldest: null,
                        all: []
                    }, t[i.symbol] = e), (null === e.oldest || e.oldest.date > i.date) && (e.oldest = i), e.all.push(i)
                }
                const i = [];
                for (const e of Object.keys(t)) {
                    const s = (0, c.ensureDefined)(t[e]);
                    for (const e of s.all) {
                        const t = s.oldest === e,
                            r = t !== e.canBeClosed;
                        e.canBeClosed = t, r && i.push(e)
                    }
                }
                return i
            }

            function m(e) {
                const t = {};
                for (const i of e) {
                    let e = t[i.symbol];
                    void 0 === e && (e = {}, t[i.symbol] = e);
                    let s = e[i.qty];
                    void 0 === s && (s = {
                        oldest: null,
                        all: []
                    }, e[i.qty] = s), (null === s.oldest || s.oldest.date > i.date) && (s.oldest = i), s.all.push(i)
                }
                const i = [];
                for (const e of Object.keys(t)) {
                    const s = (0, c.ensureDefined)(t[e]);
                    for (const e of Object.keys(s)) {
                        const t = (0, c.ensureDefined)(s[e]);
                        for (const e of t.all) {
                            const s = t.oldest === e,
                                r = s !== e.canBeClosed;
                            e.canBeClosed = s, r && i.push(e)
                        }
                    }
                }
                return i
            }
            var b, y, v = i(47001),
                f = i(50317),
                k = i(96796),
                w = i(76775),
                S = i(16345),
                C = i(50681);

            function P(e, t) {
                return {
                    symbol: t.symbol,
                    type: 2,
                    side: 1 === t.side ? -1 : 1,
                    qty: Math.abs(e),
                    seenPrice: null,
                    isClose: !0
                }
            }! function(e) {
                e[e.Undefined = 0] = "Undefined", e[e.Loading = 1] = "Loading", e[e.Error = 2] = "Error"
            }(b || (b = {})),
            function(e) {
                e[e.PlaceOrder = 0] = "PlaceOrder", e[e.EditOrder = 1] = "EditOrder", e[e.EditPosition = 2] = "EditPosition", e[e.EditTrade = 3] = "EditTrade"
            }(y || (y = {}));
            class B {
                constructor(e, t) {
                    this._status = b.Undefined, this._onStatusChange = new(l()), this._createInitialPreOrder = t.createInitialPreOrder, this._placeOrder = t.placeOrder, this._previewOrder = t.previewOrder, this._onReady = this._setData(e)
                }
                data() {
                    return this._orderData
                }
                status() {
                    return this._status
                }
                errors() {
                    return []
                }
                onStatusChange() {
                    return this._onStatusChange
                }
                async send(e) {
                    if (this._status !== b.Undefined) return !1;
                    await this._onReady;
                    const t = await this._placeOrder(this._orderData, e),
                        i = t ? b.Undefined : b.Error;
                    return this._setStatus(i), t
                }
                async preview() {
                    return this._status === b.Error ? {
                        sections: []
                    } : this._previewOrder(this._orderData)
                }
                externalContext() {
                    return {
                        type: y.PlaceOrder,
                        data: () => this.data(),
                        send: () => this.send(),
                        status: () => this.status(),
                        errors: () => this.errors()
                    }
                }
                async _setData(e) {
                    this._orderData = await this._createInitialPreOrder(e), this._assertOrderIsValid()
                }
                _assertOrderIsValid() {}
                _setStatus(e) {
                    this._status !== e && (this._status = e, this._onStatusChange.fire())
                }
            }
            var T = i(47152),
                E = i(50420);
            const L = (0, u.getLogger)("Trading.BrokerConnectionAdapter"),
                O = (0, s.t)("Failed to close position"),
                D = (0, s.t)("Failed to reverse position");

            function I(e) {
                (0, c.assert)("object" != typeof e, "Expected not an object")
            }

            function N(e, t) {
                return e.type === t.type && e.qty === t.qty && e.limitPrice === t.limitPrice && e.stopPrice === t.stopPrice && e.takeProfit === t.takeProfit && e.stopLoss === t.stopLoss && e.trailingStopPips === t.trailingStopPips
            }
            class A {
                constructor({
                    brokerMetainfo: e,
                    brokerConnection: t,
                    host: i,
                    brokerRealtimeAdapter: r,
                    tradingStat: o,
                    tradingSettingsStorageGetter: n,
                    brokerPlan: a
                }) {
                    this.connectionStatusUpdate = new(l()), this.executionUpdate = new(l()), this.tradingOperationFinished = new(l()), this.currentAccountUpdate = new(l()), this._brokerPlan = null, this._subscriptions = {}, this._lastFireResult = {}, this._fakeDomeSubscriptions = {}, this._formattersCache = {}, this._spreadFormattersCache = {}, this._quantityFormattersCache = {}, this._tradesCache = null, this._fakePositionUpdateDelegate = null, this._realtimeSubscriptionState = [], this._loggedInManually = !1,
                        this._pendingSubscriptions = [], this._sessionId = (0, S.guid)(), this.leverageInfo = e => {
                            if (this.config.supportLeverage && this._brokerConnection.leverageInfo) return this._brokerConnection.leverageInfo(e);
                            throw new Error("Method leverage is not implemented")
                        }, this.setLeverage = e => {
                            if (this.config.supportLeverage && this._brokerConnection.setLeverage) return this._brokerConnection.setLeverage(e);
                            throw new Error("Method setLeverage is not implemented")
                        }, this.previewLeverage = e => {
                            if (this.config.supportLeverage && this._brokerConnection.previewLeverage) return this._brokerConnection.previewLeverage(e);
                            throw new Error("Method previewLeverage is not implemented")
                        }, this.maintenanceStatus = async () => {
                            try {
                                return void 0 !== this._brokerConnection.maintenanceStatus ? await this._brokerConnection.maintenanceStatus() : {
                                    isMaintenance: !1
                                }
                            } catch (e) {
                                return this._brokerLogger.logError("Failed to fetch maintenance status: " + (0, f.getLoggerMessage)(e)), {
                                    isMaintenance: !0,
                                    message: (0, s.t)("We were unable to check {brokerName} side maintenance status. Please, proceed at your own risk", {
                                        replace: {
                                            brokerName: this._brokerMetainfo.title
                                        }
                                    })
                                }
                            }
                        }, this.config = Object.assign({}, e.configFlags), this._brokerMetainfo = this._patchMetainfo(e), this._brokerPlan = a || null, this._brokerConnection = t, this._host = i, this._tradingStat = o, this._getTradingSettingsStorage = n, this._brokerLogger = (0, u.getLogger)("Trading." + this._brokerMetainfo.id + ".Connection"), i.setBrokerConnectionAdapter(this), this._initializeConnectProtection(), this._positionsCache = t.positions ? new d(() => t.positions ? t.positions() : Promise.resolve([])) : null, this._tradesCache = t.trades ? new p(() => t.trades ? t.trades() : Promise.resolve([]), () => this.config) : null, this._ordersCache = new d(() => t.orders());
                    const c = e => {
                        1 === e ? (null !== this._positionsCache && this._positionsCache.start(), this._ordersCache.start(), this._tradesCache && this._tradesCache.start()) : (null !== this._positionsCache && this._positionsCache.stop(), this._ordersCache.stop(), this._tradesCache && this._tradesCache.stop())
                    };
                    this.connectionStatusUpdate.subscribe(null, c), c(this.connectionStatus()), this._originalDOMESubscriptionMethods = {
                        subscribeDOME: t.subscribeDOME,
                        unsubscribeDOME: t.unsubscribeDOME
                    }, this._patchBrokerSubscribeUnsubscribeDOMEMethods(), this.connectionStatusUpdate.subscribe(null, e => {
                        1 === e && this._patchBrokerSubscribeUnsubscribeDOMEMethods()
                    }), e.configFlags.supportPositions || (this._fakePositionUpdateDelegate = new(l())), this._brokerRealtimeAdapter = r
                }
                tryRestoreSession() {
                    if (this._brokerConnection.tryRestoreSession) return this._brokerConnection.tryRestoreSession()
                }
                get orderUpdate() {
                    return this._ordersCache.updateDelegate
                }
                get positionUpdate() {
                    return null === this._fakePositionUpdateDelegate ? (0, c.ensure)(this._positionsCache).updateDelegate : this._fakePositionUpdateDelegate
                }
                get tradeUpdate() {
                    return (0, c.ensure)(this._tradesCache).updateDelegate
                }
                get orderPartialUpdate() {
                    return this._ordersCache.partialUpdateDelegate
                }
                get positionPartialUpdate() {
                    return null === this._fakePositionUpdateDelegate ? (0, c.ensure)(this._positionsCache).partialUpdateDelegate : this._fakePositionUpdateDelegate
                }
                get tradePartialUpdate() {
                    return (0, c.ensure)(this._tradesCache).partialUpdateDelegate
                }
                onOrderUpdate(e) {
                    this._ordersCache.update(e)
                }
                onOrderPartialUpdate(e, t) {
                    this._ordersCache.partialUpdate(e, t)
                }
                onPositionUpdate(e, t) {
                    if ((0, c.assert)(!!this.config.supportPositions, "Broker doesn`t support positions"), 0 === e.qty) {
                        const t = this._lastFireResult[e.id];
                        t && delete t.PL
                    }(0, c.ensure)(this._positionsCache).update(e, t)
                }
                onPositionPartialUpdate(e, t) {
                    (0, c.assert)(!!this.config.supportPositions, "Broker doesn`t support positions"), (0, c.ensure)(this._positionsCache).partialUpdate(e, t)
                }
                onTradeUpdate(e, t) {
                    if ((0, c.assert)(!!this.config.supportTrades, "Broker doesn`t support trades"), 0 === e.qty) {
                        const t = this._lastFireResult[e.symbol];
                        t && delete t.TradePL
                    }(0, c.ensure)(this._tradesCache).update(e, t)
                }
                onTradePartialUpdate(e, t) {
                    (0, c.ensure)(this._tradesCache).partialUpdate(e, t)
                }
                onCurrentAccountChanged() {
                    null !== this._positionsCache && this._positionsCache.fullUpdate(), this._ordersCache.fullUpdate(), this._tradesCache && this._tradesCache.fullUpdate();
                    const e = this.currentAccount();
                    this.currentAccountUpdate.fire(e)
                }
                patchConfig(e) {
                    (0, v.migrateConfigFlags)(e), Object.assign(this.config, e), Object.assign(this._brokerMetainfo.configFlags, e), this._brokerMetainfo = this._patchMetainfo(this._brokerMetainfo)
                }
                async getOrderDialogOptions(e) {
                    return void 0 !== this._brokerConnection.getOrderDialogOptions ? this._brokerConnection.getOrderDialogOptions(e) : void 0
                }
                getPositionDialogOptions() {
                    return void 0 !== this._brokerConnection.getPositionDialogOptions ? this._brokerConnection.getPositionDialogOptions() : void 0
                }
                getValidationRules(e) {
                    return void 0 !== this._brokerConnection.getValidationRules ? this._brokerConnection.getValidationRules(e) : void 0
                }
                chartContextMenuActions(e, t) {
                    return this._brokerConnection.chartContextMenuActions(e, t)
                }
                buttonDropdownActions() {
                    return this._host.buttonDropdownActions()
                }
                connectionStatus() {
                    return this._brokerConnection.connectionStatus()
                }
                isConnected() {
                    return 1 === this._brokerConnection.connectionStatus()
                }
                signIn(e, t, i, s) {
                    return this._brokerLogger.logNormal("Try to login with username: " + e), this._loggedInManually = !0, this._brokerConnection.signIn(e, t, i, s)
                }
                loggedInManually() {
                    return this._loggedInManually
                }
                disconnect(e = !1) {
                    try {
                        return this._brokerConnection.disconnect(e)
                    } catch (e) {
                        L.logWarn("Failed to disconnect")
                    }
                }
                currentAccount() {
                    return this._brokerConnection.currentAccount ? this._brokerConnection.currentAccount() : ""
                }
                currentAccountType() {
                    return this._brokerConnection.currentAccountType ? this._brokerConnection.currentAccountType() : void 0
                }
                metainfo() {
                    return this._brokerMetainfo
                }
                brokerPlan() {
                    return this._brokerPlan
                }
                bro() {
                    return this._brokerConnection
                }
                fireSubscription(e, t, i, s) {
                    if (void 0 === this._lastFireResult[t] && (this._lastFireResult[t] = {
                            Realtime: null,
                            PL: null,
                            Equity: null,
                            DOME: null,
                            TradePL: null,
                            PipValue: null,
                            MarginAvailable: null,
                            CryptoBalance: null
                        }), (0, c.ensure)(this._lastFireResult[t])[e] = {
                            data: i,
                            time: Date.now()
                        }, void 0 === this._subscriptions[t]) return;
                    const r = (0, c.ensure)(this._subscriptions[t]);
                    (0, c.ensure)(r[e]).forEach(e => e(t, i, s))
                }
                positions(e) {
                    return this.config.supportPositions ? (this._makeSureBrokerIsConnected(), this._positions().then(t => t.filter(t => void 0 === e || t.symbol === e))) : Promise.resolve([])
                }
                disconnectWarningMessage() {
                    return this._brokerConnection.disconnectWarningMessage ? this._brokerConnection.disconnectWarningMessage() : null
                }
                connectWarningMessage() {
                    return this._brokerConnection.connectWarningMessage ? this._brokerConnection.connectWarningMessage() : null
                }
                trades(e) {
                    return this._makeSureBrokerIsConnected(), (0, c.assert)(!!this.config.supportTrades, "Broker doesn`t support trades"), this._trades().then(t => t.filter(t => void 0 === e || t.symbol === e))
                }
                positionById(e) {
                    return this._brokerConnection.positionById ? this._brokerConnection.positionById(e) : this.positions().then(t => t.find(t => t.id === e))
                }
                tradeById(e) {
                    return (0, c.assert)(!!this.config.supportTrades, "Broker doesn`t support trades"), this.trades().then(t => t.find(t => t.id === e))
                }
                orders(e) {
                    return this._makeSureBrokerIsConnected(), this._orders().then(t => t.filter(t => void 0 === e || t.symbol === e))
                }
                ordersHistory() {
                    return this._makeSureBrokerIsConnected(), this.config.supportOrdersHistory && this._brokerConnection.ordersHistory ? this._brokerConnection.ordersHistory() : Promise.resolve([])
                }
                async executions(e) {
                    return this.config.supportExecutions ? (this._makeSureBrokerIsConnected(), this._brokerConnection.executions(e)) : []
                }
                orderById(e) {
                    return this._makeSureBrokerIsConnected(), this._brokerConnection.orders().then(t => t.find(t => t.id === e))
                }
                accountManagerInfo() {
                    return this._brokerConnection.accountManagerInfo()
                }
                isTradable(e) {
                    return this._makeSureBrokerIsConnected(), this._brokerConnection.isTradable(e).then(t => ("object" != typeof t && (t = {
                        tradable: t
                    }), t.tradable || void 0 !== t.reason || (t.reason = (0, f.makeNonTradableSymbolText)((0, k.htmlEscape)(e), this._brokerMetainfo.title)), t))
                }
                formatter(e, t = !0) {
                    return this._makeSureBrokerIsConnected(), this._formattersCache[e] || (this._formattersCache[e] = this._brokerConnection.formatter && this._brokerConnection.formatter(e, t) || this._host.defaultFormatter(e, t)), (0, h.makeTimeLimited)(this._formattersCache[e], 1e4, "formatter not received")
                }
                spreadFormatter(e) {
                    return this._makeSureBrokerIsConnected(), this._spreadFormattersCache[e] || (this._spreadFormattersCache[e] = this._brokerConnection.spreadFormatter && this._brokerConnection.spreadFormatter(e) || this._host.defaultFormatter(e, !1)), (0, h.makeTimeLimited)(this._spreadFormattersCache[e], 1e4, "spreadFormatter not received")
                }
                quantityFormatter(e) {
                    return this._makeSureBrokerIsConnected(), this._quantityFormattersCache[e] || (this._quantityFormattersCache[e] = this._brokerConnection.quantityFormatter && this._brokerConnection.quantityFormatter(e) || this._host.quantityFormatter()), (0, h.makeTimeLimited)(this._quantityFormattersCache[e], 1e4, "quantityFormatter not received")
                }
                async createInitialPreOrder(e) {
                    return this._createInitialPreOrder(e)
                }
                createPlaceOrderContext(e) {
                    return new B(e, {
                        createInitialPreOrder: e => this._createInitialPreOrder(e),
                        placeOrder: (e, t) => this._placeOrder(e, t),
                        previewOrder: e => this._previewOrder(e)
                    })
                }
                placeOrder(e, t) {
                    return this._placeOrder(e, t)
                }
                previewOrder(e) {
                    return this._previewOrder(e)
                }
                async modifyOrder(e, t) {
                    this._makeSureBrokerIsConnected();
                    const i = new Set((await this._orders()).map(({
                        id: e
                    }) => e));
                    i.delete(e.id);
                    return await this.processErrors(this._brokerConnection.modifyOrder(e, t), !0, (0, s.t)("Failed to modify order")) && this._waitForOrderModification(e, i)
                }
                cancelOrder(e) {
                    return I(e), this._makeSureBrokerIsConnected(), this.processErrors(this._brokerConnection.cancelOrder(e), !0, (0, s.t)("Failed to cancel order"))
                }
                cancelOrders(e, t, i) {
                    return this._makeSureBrokerIsConnected(), this.processErrors(this._brokerConnection.cancelOrders(e, t, i), !0, (0, s.t)("Failed to cancel one or more orders"))
                }
                async closePosition(e, t) {
                    let i;
                    I(e), this._makeSureBrokerIsConnected(), (0, c.assert)(void 0 === t || !!this.config.supportPartialClosePosition, "Broker doesn`t support partial position closing");
                    const s = new Promise(async (s, r) => {
                        try {
                            const r = await this._positionCopyById(e);
                            i = e => {
                                void 0 !== r && e.id === r.id && e.symbol === r.symbol && e.qty !== r.qty && (this.positionUpdate.unsubscribe(this, i), s(!0))
                            }, this.positionUpdate.subscribe(this, i), await this._closePosition(e, t)
                        } catch (e) {
                            r(e)
                        }
                    });
                    return (0, h.makeTimeLimited)(s, 3e4, "Position closing timeout").catch(e => (this._brokerLogger.logError(`${O}: ${(0,f.getLoggerMessage)(e)}`), this.positionUpdate.unsubscribe(this, i), !1))
                }
                async closeTrade(e, t) {
                    var i;
                    I(e), this._makeSureBrokerIsConnected(), (0, c.assert)(!!this.config.supportTrades, "Broker doesn`t support trades"), (0, c.assert)(void 0 === t || null !== (i = this.config.supportPartialCloseTrade) && void 0 !== i && i, "Broker doesn`t support partial position closing");
                    const r = (0, c.ensureDefined)(await this.tradeById(e));
                    if (0 === r.qty) return this._host.showNotification((0, s.t)("Failed to close the position"), (0, s.t)("The position you are trying to close has been already closed."), 0), !1;
                    if (void 0 === t || t <= Math.abs(r.qty)) {
                        if (this._brokerConnection.closeTrade) {
                            const i = P(null != t ? t : Math.abs(r.qty), r);
                            return this.processErrors(this._brokerConnection.closeTrade(e, t), !0, O, () => (0, c.ensureNotNull)(this._tradingStat).trackOrderPlaced(i))
                        }
                        throw new Error("Method closeTrade is not implemented")
                    }
                    return this._host.showNotification((0, s.t)("Failed to close the position"), (0, s.t)("The position you are trying to close has been changed."), 0), !1
                }
                reversePosition(e) {
                    if (I(e), this._makeSureBrokerIsConnected(), this.config.supportMultiposition && !this.config.supportNativeReversePosition) throw new Error("Cannot reverse position on multiposition account");
                    let t;
                    const i = new Promise(async (i, s) => {
                        try {
                            const s = await this._positionCopyById(e);
                            t = e => {
                                void 0 !== s && e.symbol === s.symbol && e.side !== s.side && (this.positionUpdate.unsubscribe(this, t), i(!0))
                            }, this.positionUpdate.subscribe(this, t), await this._reversePosition(e)
                        } catch (e) {
                            s(e)
                        }
                    });
                    return (0, h.makeTimeLimited)(i, 3e4, "Position reversing timeout").catch(e => (this._brokerLogger.logError(`${D}: ${(0,f.getLoggerMessage)(e)}`), this.positionUpdate.unsubscribe(this, t), !1))
                }
                editPositionBrackets(e, t, i) {
                    if (this._makeSureBrokerIsConnected(),
                        this._brokerConnection.editPositionBrackets) return this.processErrors(this._brokerConnection.editPositionBrackets(e, t, i), !0, (0, s.t)("Failed to modify Stop Loss / Take Profit"));
                    throw new Error("Method editPositionBrackets is not implemented")
                }
                editTradeBrackets(e, t) {
                    if (this._makeSureBrokerIsConnected(), (0, c.assert)(!!this.config.supportTradeBrackets, "Broker doesn`t support brackets on trades"), this._brokerConnection.editTradeBrackets) return this.processErrors(this._brokerConnection.editTradeBrackets(e, t), !0, (0, s.t)("Failed to modify Stop Loss / Take Profit"));
                    throw new Error("Method editTradeBrackets is not implemented")
                }
                async subscribeRealtime(e, t) {
                    this._makeSureBrokerIsConnected();
                    const i = {
                        symbol: e,
                        listener: t,
                        provider: 0
                    };
                    this._realtimeSubscriptionState.push(i);
                    const s = await this.symbolInfo(e),
                        r = this._realtimeSubscriptionState.findIndex(i => i.symbol === e && i.listener === t);
                    if (-1 !== r) return void 0 !== s.hasQuotes && !1 === s.hasQuotes ? (this._realtimeSubscriptionState[r].provider = 1, (0, c.ensure)(this._brokerRealtimeAdapter).subscribeRealtime(e, t)) : (this._realtimeSubscriptionState[r].provider = 2, this._addSubscription("Realtime", e, t))
                }
                async quotesSnapshot(e) {
                    let t, i;
                    const s = (e, r) => {
                            i = r, (r.ask || r.bid) && (this.unsubscribeRealtime(e, s), null == t || t(r))
                        },
                        r = new Promise(i => {
                            t = i, this.subscribeRealtime(e, s)
                        });
                    try {
                        return await (0, h.makeTimeLimited)(r, 1e4, "quotesSnapshot not received")
                    } catch (t) {
                        if (this.unsubscribeRealtime(e, s), void 0 !== i) return i;
                        throw t
                    }
                }
                subscribeDOME(e, t) {
                    return this._makeSureBrokerIsConnected(), this._addSubscription("DOME", e, t)
                }
                subscribePipValue(e, t) {
                    return this._makeSureBrokerIsConnected(), this._addSubscription("PipValue", e, t)
                }
                subscribePL(e, t) {
                    this._makeSureBrokerIsConnected(), this._addSubscription("PL", e, t)
                }
                subscribeTradePL(e, t) {
                    return this._makeSureBrokerIsConnected(), this._addSubscription("TradePL", e, t)
                }
                subscribeCryptoBalance(e, t) {
                    return this._makeSureBrokerIsConnected(), this._addSubscription("CryptoBalance", e, t)
                }
                subscribeEquity(e) {
                    return this._makeSureBrokerIsConnected(), this._addSubscription("Equity", "Equity", e)
                }
                subscribeMarginAvailable(e) {
                    return this._makeSureBrokerIsConnected(), this._addSubscription("MarginAvailable", "MarginAvailable", e)
                }
                unsubscribeRealtime(e, t) {
                    const i = this._realtimeSubscriptionState.findIndex(i => i.symbol === e && i.listener === t); - 1 !== i && (1 === this._realtimeSubscriptionState[i].provider ? (0, c.ensure)(this._brokerRealtimeAdapter).unsubscribeRealtime(e, t) : this._removeSubscription("Realtime", e, t), this._realtimeSubscriptionState.splice(i, 1))
                }
                unsubscribeDOME(e, t) {
                    this._removeSubscription("DOME", e, t)
                }
                unsubscribePipValue(e, t) {
                    this._removeSubscription("PipValue", e, t)
                }
                unsubscribePL(e, t) {
                    this._removeSubscription("PL", e, t)
                }
                unsubscribeTradePL(e, t) {
                    this._removeSubscription("TradePL", e, t)
                }
                unsubscribeCryptoBalance(e, t) {
                    this._removeSubscription("CryptoBalance", e, t)
                }
                unsubscribeEquity(e) {
                    this._removeSubscription("Equity", "Equity", e)
                }
                unsubscribeMarginAvailable(e) {
                    this._removeSubscription("MarginAvailable", "MarginAvailable", e)
                }
                async accountMetainfo() {
                    const e = await this.accountsMetainfo(),
                        t = this.currentAccount(),
                        i = e.find(e => e.id === t);
                    if (void 0 === i) throw new Error("accountMetainfo not received");
                    return i
                }
                accountsMetainfo() {
                    return (0, h.makeTimeLimited)(this._brokerConnection.accountsMetainfo(), 1e4, "accountsMetainfo not received")
                }
                setCurrentAccount(e) {
                    if (void 0 === this._brokerConnection.setCurrentAccount) throw new Error(this._brokerMetainfo.title + " doesn't support sub-accounts");
                    this._brokerConnection.setCurrentAccount(e)
                }
                symbolInfo(e) {
                    return (0, h.makeTimeLimited)(this._brokerConnection.symbolInfo(e), 1e4, "symbolInfo not received")
                }
                async getPositionCurrency(e) {
                    try {
                        const t = await this._brokerConnection.symbolInfo(e);
                        if (this._brokerMetainfo.configFlags.positionPLInInstrumentCurrency && void 0 !== t.currency) return t.currency;
                        const i = await this.accountMetainfo();
                        return (0, C.getCurrency)(i, !0)
                    } catch (e) {
                        return void L.logError(e)
                    }
                }
                sessionId() {
                    return this._sessionId
                }
                bugReportInfo() {
                    function e(e) {
                        return JSON.parse(JSON.stringify(e))
                    }

                    function t(e) {
                        if ("object" != typeof e) return e;
                        if ((0, n.isArray)(e)) return e.map(t);
                        const i = {};
                        for (const t in e) "object" != typeof e[t] && (i[t] = e[t]);
                        return i
                    }
                    return Promise.all([this.orders(), this.positions(), this.config.supportTrades ? this.trades() : Promise.resolve([])]).then(i => ({
                        activeBroker: this.metainfo().title,
                        orders: t(e(i[0])),
                        positions: t(e(i[1])),
                        trades: t(e(i[2])),
                        silentOrdersPlacement: this._host.silentOrdersPlacement().value(),
                        floatingPanel: (0, c.ensureNotNull)(this._host.sellBuyButtonsVisibility()).value(),
                        account: this.currentAccount(),
                        accountType: this.currentAccountType(),
                        lastUpdates: this._lastFireResult,
                        time: Date.now(),
                        brokerSpecific: this._brokerConnection.bugReportInfo ? this._brokerConnection.bugReportInfo() : null,
                        sessionId: this._sessionId
                    }))
                }
                processErrors(e, t, i, r) {
                    if (!(0, n.isPromise)(e)) throw new Error("Broker incorrectly implements API, should return Promise");
                    return e.then(e => r && r(e)).then(e => "boolean" != typeof e || e).catch(e => {
                        if ((0, E.isUserFriendlyError)(e) && "originalError" in e && (0, T.isAbortError)(e.originalError)) return Promise.resolve(!1);
                        let r = "";
                        return "string" == typeof e ? r = e : "object" == typeof e && "string" == typeof e.message && (r = (0, k.removeTags)(e.message)), t && o.enabled("trading_notifications") ? (0 !== r.length && ("." !== r.slice(-1) && (r += "."), r += " "), r += (0, s.t)("To learn more, please contact your broker."), this._host.showNotification(i || "", r, 0)) : L.logWarn(e), Promise.resolve(!1)
                    }).then(e => (this.tradingOperationFinished.fire(e), e))
                }
                setDurations(e) {
                    this._brokerMetainfo.durations = e.slice()
                }
                setSymbolSearchId(e) {
                    this._brokerMetainfo.backendBrokerName = e
                }
                getRealtimeDataCheckParams() {
                    return this._brokerConnection.getRealtimeDataCheckParams ? this._brokerConnection.getRealtimeDataCheckParams() : {}
                }
                getVerifyLiveAccountParams() {
                    if (void 0 === this._brokerConnection.getVerifyLiveAccountParams) throw new Error(`Method getVerifyLiveAccountParams for broker ${this._brokerMetainfo.id} is not implemented`);
                    return this._brokerConnection.getVerifyLiveAccountParams()
                }
                unhideSymbolSearchGroups() {
                    return this._brokerConnection.unhideSymbolSearchGroups ? this._brokerConnection.unhideSymbolSearchGroups() : []
                }
                destroy() {
                    void 0 !== this._brokerConnection.destroy && this._brokerConnection.destroy()
                }
                currentBroker() {
                    return this._brokerMetainfo.id
                }
                async _createInitialPreOrder(e) {
                    var t, i, s, r, o, n, a;
                    if (void 0 === e.duration) {
                        const {
                            allowedDurations: r
                        } = await this.symbolInfo(e.symbol), {
                            durations: o
                        } = this.metainfo(), n = (0, C.getOrderDuration)({
                            orderDuration: void 0,
                            orderType: e.type,
                            savedDuration: null !== (s = null === (i = null === (t = this._getTradingSettingsStorage) || void 0 === t ? void 0 : t.call(this)) || void 0 === i ? void 0 : i.duration(e.symbol)) && void 0 !== s ? s : null,
                            orderDurations: o,
                            symbolDurations: r
                        });
                        null !== n && (e.duration = n)
                    }
                    if (void 0 === e.customFields) {
                        const t = await this.getOrderDialogOptions(e.symbol),
                            i = null === (r = null == t ? void 0 : t.customFields) || void 0 === r ? void 0 : r.map(e => e.id),
                            s = null !== (a = null === (n = null === (o = this._getTradingSettingsStorage) || void 0 === o ? void 0 : o.call(this)) || void 0 === n ? void 0 : n.customFields(e.symbol, null != i ? i : [])) && void 0 !== a ? a : null,
                            l = (0, C.getCustomFieldsWithoutForceUserEnterInitialValueFlag)(e, s, t);
                        0 !== Object.keys(l).length && (e.customFields = l)
                    }
                    return e
                }
                _placeOrder(e, t) {
                    return this._makeSureBrokerIsConnected(), this.processErrors(this._brokerConnection.placeOrder(e, t), !0, (0, s.t)("Order rejected"), t => {
                        (0, c.ensureNotNull)(this._tradingStat).trackOrderPlaced({ ...e,
                            id: t.orderId
                        }), this._host.trackEvent("", "SilentMode", this._host.silentOrdersPlacement().value() ? "On" : "Off")
                    })
                }
                _previewOrder(e) {
                    if (!this._brokerConnection.previewOrder) throw new Error("Order preview is not supported");
                    return this._brokerConnection.previewOrder(e)
                }
                _initializeConnectProtection() {
                    let e = null;
                    this.connectionStatusUpdate.subscribe(null, t => {
                        if (e && (clearTimeout(e), e = null), 2 === t) {
                            const t = (0, C.isOAuthAuthType)(this.config.authorizationType) ? 3e5 : 6e4;
                            e = setTimeout(() => {
                                this._host.selectBroker(), this._host.showNotification((0, s.t)("Authorization Error"), (0, s.t)("The connection attempt failed. Please try again later."))
                            }, t)
                        }
                    })
                }
                _fakeSubscribeDOME(e) {
                    this._fakeDomeSubscriptions[e] = (e, t) => {
                        const i = t.ask || t.trade,
                            s = t.bid || t.trade,
                            r = {
                                snapshot: !0,
                                asks: i ? [{
                                    price: i,
                                    volume: t.ask_size || 1 / 0
                                }] : [],
                                bids: s ? [{
                                    price: s,
                                    volume: t.bid_size || 1 / 0
                                }] : []
                            };
                        this._host.domeUpdate(e, r)
                    }, this.subscribeRealtime(e, this._fakeDomeSubscriptions[e])
                }
                _fakeUnsubscribeDOME(e) {
                    this.unsubscribeRealtime(e, this._fakeDomeSubscriptions[e])
                }
                _isMaintenance() {
                    return isFeatureEnabled((0, C.makeMaintananceFeatureToggleName)(this._brokerMetainfo.id))
                }
                _isBrokerSideMaintenance() {
                    return isFeatureEnabled((0, C.makeBrokerSideMaintananceFeatureToggleName)(this._brokerMetainfo.id))
                }
                async _positionCopyById(e) {
                    const t = await this.positionById(e);
                    return void 0 !== t ? (0, r.default)(t) : void 0
                }
                _patchBrokerSubscribeUnsubscribeDOMEMethods() {
                    const e = !this._brokerMetainfo.configFlags.supportLevel2Data;
                    this._brokerConnection.subscribeDOME = e ? e => {
                        this._fakeSubscribeDOME(e)
                    } : this._originalDOMESubscriptionMethods.subscribeDOME, this._brokerConnection.unsubscribeDOME = e ? e => {
                        this._fakeUnsubscribeDOME(e)
                    } : this._originalDOMESubscriptionMethods.unsubscribeDOME
                }
                _patchMetainfo(e) {
                    const t = (0, w.deepCopy)(e);
                    return t.configFlags.supportNativeReversePosition = !this.config.supportMultiposition || this.config.supportNativeReversePosition, t.configFlags.supportClosePosition = !0, t.configFlags.supportPLUpdate = !0, t
                }
                _addSubscription(e, t, i) {
                    this._pendingSubscriptions.push({
                        brokerMethodName: e,
                        symbol: t,
                        listener: i
                    });
                    const s = this._lastFireResult[t];
                    if (void 0 !== s && void 0 !== s[e] && null !== s[e] && i(t, s[e].data), !this._removePendingSubscription({
                            brokerMethodName: e,
                            symbol: t,
                            listener: i
                        })) return;
                    void 0 === this._subscriptions[t] && (this._subscriptions[t] = {
                        Realtime: [],
                        PL: [],
                        Equity: [],
                        DOME: [],
                        TradePL: [],
                        PipValue: [],
                        MarginAvailable: [],
                        CryptoBalance: []
                    });
                    const r = (0, c.ensure)(this._subscriptions[t]),
                        o = r[e].length > 0;
                    if (r[e].push(i), !o && (r[e].length > 0 || "CryptoBalance" === e)) {
                        const i = "subscribe" + e;
                        this._brokerConnection[i] && this._brokerConnection[i](t)
                    }
                }
                _removePendingSubscription(e) {
                    const t = this._pendingSubscriptions.findIndex(t => t.symbol === e.symbol && t.brokerMethodName === e.brokerMethodName && t.listener === e.listener);
                    return -1 !== t && (this._pendingSubscriptions.splice(t, 1), !0)
                }
                _removeSubscription(e, t, i) {
                    if (this._removePendingSubscription({
                            brokerMethodName: e,
                            symbol: t,
                            listener: i
                        })) return;
                    if (void 0 === this._subscriptions[t]) return;
                    const s = (0, c.ensure)(this._subscriptions[t]),
                        r = s[e].indexOf(i);
                    if (r > -1 && s[e].splice(r, 1), 0 === s[e].length) {
                        const i = "unsubscribe" + e;
                        this._brokerConnection[i] && this._brokerConnection[i](t)
                    }
                }
                _positions() {
                    return this._positionsCache ? this._positionsCache.getObjects() : Promise.resolve([])
                }
                _trades() {
                    return this._tradesCache ? this._tradesCache.getObjects() : Promise.resolve([])
                }
                _orders() {
                    return this._ordersCache.getObjects()
                }
                _makeSureBrokerIsConnected() {
                    (0, c.assert)(1 === this.connectionStatus(), "Broker is not connected")
                }
                _placeReversePositionOrder(e) {
                    const t = P(2 * e.qty, e);
                    return this._placeOrder(t)
                }
                async _closePosition(e, t) {
                    const i = (0, c.ensureDefined)(await this.positionById(e));
                    if (0 === i.qty) {
                        const e = (0, s.t)("The position you are trying to close has been already closed.");
                        throw this._host.showNotification(O, e, 0), new Error(e)
                    }
                    if (void 0 === t || t <= Math.abs(i.qty)) {
                        const s = P(null != t ? t : Math.abs(i.qty), i);
                        return this.config.supportClosePosition && this._brokerConnection.closePosition ? void await this.processErrors(this._brokerConnection.closePosition(e, t), !0, O, () => (0, c.ensureNotNull)(this._tradingStat).trackOrderPlaced(s)) : void await this.processErrors(this._brokerConnection.placeOrder(s), !0, O, () => (0, c.ensureNotNull)(this._tradingStat).trackOrderPlaced(s))
                    } {
                        const e = (0, s.t)("The position you are trying to close has been changed.");
                        throw this._host.showNotification(O, e, 0), new Error(e)
                    }
                }
                async _reversePosition(e) {
                    const t = (0, c.ensureDefined)(await this.positionById(e));
                    if (0 === t.qty) {
                        const e = (0, s.t)("The position you are trying to reverse no longer exists.");
                        throw this._host.showNotification(D, e, 0), new Error(e)
                    }
                    this.config.supportNativeReversePosition && this._brokerConnection.reversePosition ? await this.processErrors(this._brokerConnection.reversePosition(e), !0, D) : await this.processErrors(this._placeReversePositionOrder(t), !0, D, () => (0, c.ensureNotNull)(this._tradingStat).trackOrderPlaced())
                }
                async _waitForOrderModification(e, t) {
                    return new Promise(async i => {
                        const s = () => {
                                i(!0), o(), clearTimeout(n)
                            },
                            r = t => {
                                N(t, e) && s()
                            },
                            o = () => this.orderUpdate.unsubscribe(this, r),
                            n = setTimeout(() => {
                                i(!1), this._brokerLogger.logError("Failed to modify order: timeout waiting for new order"), o()
                            }, 3e4);
                        this.orderUpdate.subscribe(this, r);
                        for (const i of await this._orders())
                            if (!t.has(i.id) && N(e, i)) return void s()
                    })
                }
            }
            var M = i(60521),
                V = i(70122),
                x = i.n(V),
                F = i(94489),
                R = i.n(F),
                q = i(93540),
                U = i(8329),
                W = i(54620),
                Q = i(21162),
                j = i(1397),
                H = i(53055),
                z = i(27818),
                $ = i(71763),
                G = i(74891),
                K = i(39319),
                Z = i(63891);
            class J {
                constructor(e, t, i, s) {
                    this._lastPL = 0, this._isActive = !1, this._realtimeUpdate = (e, t) => {
                        this._realtimeData = t, this._updatePL()
                    }, this._symbol = e.symbol, this._adapter = i, this._onPlUpdate = t, this._side = e.side, this._qty = e.qty, this._avgPrice = e.avgPrice, this._instrumentInfo = s, this.positionUpdate(e)
                }
                positionUpdate(e) {
                    this._avgPrice = e.avgPrice, this._qty = e.qty, this._side = e.side, this._updatePL()
                }
                lastPL() {
                    return this._lastPL
                }
                start() {
                    this._isActive || (this._adapter.subscribeRealtime(this._symbol, this._realtimeUpdate), this._isActive = !0)
                }
                stop() {
                    this._isActive && (this._adapter.unsubscribeRealtime(this._symbol, this._realtimeUpdate), this._isActive = !1)
                }
                _updatePL() {
                    var e;
                    if (!this._realtimeData || void 0 === this._realtimeData.bid || void 0 === this._realtimeData.ask) return;
                    const t = Number(new M.Big(1 === this._side ? this._realtimeData.bid : this._realtimeData.ask).minus(Math.abs(this._avgPrice)).mul(1 === this._side ? 1 : -1).mul(this._qty).mul(null !== (e = this._instrumentInfo.lotSize) && void 0 !== e ? e : 1).div(this._instrumentInfo.pipSize).mul(this._instrumentInfo.pipValue));
                    this._lastPL = t, this._onPlUpdate(t)
                }
            }
            class Y {
                constructor(e, t, i, s) {
                    var r;
                    this._setDefaultDropdownActionsBound = this._setDefaultDropdownActions.bind(this), this.createMapperSync = (e, t) => {
                        let i = null; {
                            const e = Promise.resolve();
                            i = {
                                ready: () => e,
                                tvToBroker: e => e,
                                brokerToTv: e => e
                            }
                        }
                        return i
                    }, this._trading = e, this._metainfo = t, this._serverLogger = null !== i ? this._makeServerLoggerWithFilledInfo(i) : null, this._setDefaultDropdownActionsBound = this._setDefaultDropdownActions.bind(this), this._defaultDropdownActions = !0, this._credentialsStorage = s, this._setDefaultDropdownActions(), null !== this._trading && (null === (r = this.sellBuyButtonsVisibility()) || void 0 === r || r.subscribe(this._setDefaultDropdownActionsBound), (0, c.ensureNotNull)(this.orderPanelVisibility()).subscribe(this._setDefaultDropdownActionsBound), (0, c.ensureNotNull)(this.domPanelVisibility()).subscribe(this._setDefaultDropdownActionsBound))
                }
                createPLEmitter(e, t, i) {
                    return new J(e, t, this._adapter, i)
                }
                getLogger() {
                    return (0, u.getLogger)("Trading." + this._metainfo.id)
                }
                serverLogger() {
                    return this._serverLogger
                }
                translate(e) {
                    return e
                }
                setBrokerConnectionAdapter(e) {
                    this._adapter = e
                }
                patchConfig(e) {
                    this._adapter.patchConfig(e)
                }
                showOrderDialog(e, t) {
                    return (0, c.ensureNotNull)(this._trading).orderViewController().showOrderView({
                        order: e,
                        focus: t
                    })
                }
                showPositionBracketsDialog(e, t, i) {
                    return (0, c.ensureNotNull)(this._trading).orderViewController().showPositionView(e, t, i)
                }
                showCancelOrderDialog(e, t) {
                    return G.ConfirmOrderCancelDialog.get().open(e).then(e => {
                        e && this._adapter.processErrors(t(), !0, (0, s.t)("Failed to cancel order"))
                    })
                }
                showCancelMultipleOrdersDialog(e, t, i, r) {
                    return G.ConfirmOrderCancelDialog.get().multiple(e, t, i).then(e => {
                        e && this._adapter.processErrors(r(), !0, (0, s.t)("Failed to cancel one or more orders"))
                    })
                }
                showCancelBracketsDialog(e, t) {
                    return K.ConfirmBracketsCancelDialog.get().open(e).then(e => {
                        e && this._adapter.processErrors(t(), !0, (0, s.t)("Failed to cancel brackets"))
                    })
                }
                showCancelMultipleBracketsDialog(e, t) {
                    return K.ConfirmBracketsCancelDialog.get().multiple(e).then(e => {
                        e && this._adapter.processErrors(t(), !0, (0, s.t)("Failed to cancel brackets"))
                    })
                }
                showReversePositionDialog(e, t) {
                    return (0, Z.reversePositionDialog)(e, (0, c.ensureNotNull)(this._trading).showErrorNotification, t)
                }
                showMessageDialog(e, t, i = !1) {
                    i ? (0, H.showWarning)({
                        title: e,
                        html: t
                    }) : (0, H.showWarning)({
                        title: e,
                        text: t
                    })
                }
                showConfirmDialog(e, t, i, s, r) {
                    return (0, z.showConfirmDialog)({
                        title: e,
                        content: t,
                        mainButtonText: i,
                        cancelButtonText: s,
                        showDisableConfirmationsCheckbox: r
                    })
                }
                showSimpleConfirmDialog(e, t, i, s, r) {
                    return (0, $.showSimpleConfirmDialog)({
                        title: e,
                        text: Array.isArray(t) ? t.join(" ") : t,
                        mainButtonText: i,
                        mainButtonIntent: "primary",
                        cancelButtonText: s,
                        showDisableConfirmationsCheckbox: r
                    })
                }
                setDurations(e) {
                    this._adapter.setDurations(e)
                }
                setSymbolSearchId(e) {
                    this._adapter.setSymbolSearchId(e)
                }
                activateBottomWidget() {
                    return null !== this._trading ? this._trading.toggleTradingWidget() : Promise.reject("Activate bottom widget failed: trading is not defined")
                }
                trackEvent(e, t, i) {
                    null !== this._trading && this._trading.trackEvent(e, t, i)
                }
                defaultFormatter(e, t) {
                    return (0, Q.getQuoteSessionInstance)("simple").formatter(e, t)
                }
                numericFormatter(e) {
                    return Promise.resolve(new U.NumericFormatter(e))
                }
                quantityFormatter(e) {
                    return Promise.resolve(new W.QuantityFormatter(e))
                }
                selectBroker() {
                    null !== this._trading && this._trading.selectBroker(null, this._metainfo.configFlags.keepCredentialsAfterFailedSessionRestore)
                }
                showTradingProperties() {
                    null !== this._trading && this._trading.showTradingProperties()
                }
                async getSymbolType(e) {
                    return (await X(e)).type
                }
                async getSymbolMinTick(e) {
                    const t = await X(e);
                    return (0, M.Big)(t.minmov).div(t.pricescale).toNumber()
                }
                silentOrdersPlacement() {
                    return (0, c.ensureNotNull)(this._trading).noConfirmEnabled
                }
                sellBuyButtonsVisibility() {
                    return null !== this._trading && o.enabled("buy_sell_buttons") ? this._trading.showSellBuyButtons : null
                }
                domPanelVisibility() {
                    return null !== this._trading ? this._trading.domPanelVisibility() : null
                }
                orderPanelVisibility() {
                    return null !== this._trading ? this._trading.orderPanelVisibility() : null
                }
                showPricesWithZeroVolume() {
                    return (0, c.ensureNotNull)(this._trading).showPricesWith().zeroVolume
                }
                showNotification(e, t, i = 0) {
                    null !== this._trading && (0 === i ? this._trading.showErrorNotification(e, t) : this._trading.showSuccessNotification(e, t))
                }
                connectionStatusUpdate(e, t) {
                    this._adapter.connectionStatusUpdate.fire(e, t), 1 === e && this._setDefaultDropdownActions()
                }
                orderUpdate(e) {
                    this._adapter.onOrderUpdate(e)
                }
                positionUpdate(e, t) {
                    this._adapter.onPositionUpdate(e, t)
                }
                tradeUpdate(e, t) {
                    this._adapter.onTradeUpdate(e, t)
                }
                orderPartialUpdate(e, t) {
                    this._adapter.onOrderPartialUpdate(e, t)
                }
                positionPartialUpdate(e, t) {
                    this._adapter.onPositionPartialUpdate(e, t)
                }
                tradePartialUpdate(e, t) {
                    this._adapter.onTradePartialUpdate(e, t)
                }
                executionUpdate(e) {
                    this._adapter.executionUpdate.fire(e)
                }
                currentAccountUpdate() {
                    this._adapter.onCurrentAccountChanged()
                }
                realtimeUpdate(e, t) {
                    this._adapter.fireSubscription("Realtime", e, t)
                }
                domeUpdate(e, t) {
                    this._adapter.fireSubscription("DOME", e, t)
                }
                pipValueUpdate(e, t) {
                    this._adapter.fireSubscription("PipValue", e, t)
                }
                plUpdate(e, t) {
                    this._adapter.fireSubscription("PL", e, t)
                }
                tradePLUpdate(e, t) {
                    this._adapter.fireSubscription("TradePL", e, t)
                }
                equityUpdate(e) {
                    this._adapter.fireSubscription("Equity", "Equity", e)
                }
                marginAvailableUpdate(e) {
                    this._adapter.fireSubscription("MarginAvailable", "MarginAvailable", e)
                }
                cryptoBalanceUpdate(e, t) {
                    this._adapter.fireSubscription("CryptoBalance", e, t)
                }
                setButtonDropdownActions(e) {
                    var t;
                    null !== this._trading && this._defaultDropdownActions && (this._defaultDropdownActions = !1, null === (t = this.sellBuyButtonsVisibility()) || void 0 === t || t.unsubscribe(this._setDefaultDropdownActionsBound), (0, c.ensureNotNull)(this.orderPanelVisibility()).unsubscribe(this._setDefaultDropdownActionsBound), (0, c.ensureNotNull)(this.domPanelVisibility()).unsubscribe(this._setDefaultDropdownActionsBound)), this._buttonDropdownActions = e
                }
                buttonDropdownActions() {
                    return this._buttonDropdownActions
                }
                defaultContextMenuActions(...e) {
                    return null !== this._trading ? this._trading.defaultContextMenuActions(...e) : Promise.resolve([])
                }
                defaultDropdownMenuActions(e) {
                    return null !== this._trading ? this._trading.defaultDropdownMenuActions(e) : []
                }
                get factory() {
                    return {
                        createDelegate: () => new(l()),
                        createWatchedValue: e => new(R())(e),
                        createPriceFormatter: (e, t, i, s) => new j.PriceFormatter(e, t, i, s)
                    }
                }
                get settings() {
                    return {
                        save: (e, t) => x().setJSON(`${this._metainfo.id}.${e}`, t),
                        load: (e, t) => x().getJSON(`${this._metainfo.id}.${e}`, t),
                        clear: (e, t) => x().remove(`${this._metainfo.id}.${e}`, t)
                    }
                }
                get credentialsStorage() {
                    return this._credentialsStorage
                }
                createMapperAsync(e) {
                    return {
                        tvToBroker: async e => e,
                        brokerToTv: async e => e
                    }
                }
                convertTimezone(e, t, i) {
                    const s = q.get_timezone(t),
                        r = q.get_timezone(i),
                        o = q.cal_to_utc(s, e);
                    return q.utc_to_cal(r, o)
                }
                language() {
                    return window.language
                }
                getUserSpecificHash() {
                    return window.user.private_channel || ""
                }
                activateFXCMCFD() {
                    x().setValue("fxcm_cfd", !0)
                }
                async isFractional(e) {
                    return (await X(e)).fractional
                }
                _makeServerLoggerWithFilledInfo(e) {
                    return {
                        log: t => e.log({ ...this._makeServerLoggerEventAdditionalInfo(),
                            ...t
                        }),
                        debounceLog: (t, i, s) => e.debounceLog({ ...this._makeServerLoggerEventAdditionalInfo(),
                            ...t
                        }, i, s)
                    }
                }
                _makeServerLoggerEventAdditionalInfo() {
                    return {
                        accountType: this._adapter.currentAccountType(),
                        brokerId: this._adapter.metainfo().id,
                        sessionId: this._adapter.sessionId(),
                        tvUsername: window.user.username,
                        ref: location.href,
                        online: navigator.onLine
                    }
                }
                _setDefaultDropdownActions() {
                    null !== this._trading && this._defaultDropdownActions && (this._buttonDropdownActions = this.defaultDropdownMenuActions())
                }
            }

            function X(e) {
                return (0, Q.getQuoteSessionInstance)("full").snapshot(e)
            }
            var ee = i(63329);
            const te = (0, u.getLogger)("Trading.CredentialsEncryptedWebStorage");
            class ie {
                constructor(e, t) {
                    this._key = "credentials-storage", this._transientStorage = {}, this._handleStorageStateChange = e => {
                        const {
                            key: t,
                            storageArea: i
                        } = e;
                        i === this._persistentStorage && this._key === t && this._decryptStorage()
                    }, this._persistentStorage = e, this._cryptographer = t, this._decryptStorage = (0, ee.sequentialize)(this._decryptStorage), window.addEventListener("storage", this._handleStorageStateChange)
                }
                async setItem(e, t) {
                    this._transientStorage[e] = JSON.stringify(t);
                    try {
                        await this._encryptStorageAndSave()
                    } catch (t) {
                        te.logError(`Unable to save credentials using key ${e}: ${t.message}`)
                    }
                }
                getItem(e, t = null) {
                    this._persistentStorage.removeItem(e);
                    const i = this._transientStorage[e];
                    if (void 0 === i) return t;
                    if ("string" != typeof i) return i;
                    try {
                        return JSON.parse(i)
                    } catch (e) {
                        return i
                    }
                }
                async removeItem(e) {
                    delete this._transientStorage[e], await this._encryptStorageAndSave()
                }
                destroy() {
                    window.removeEventListener("storage", this._handleStorageStateChange)
                }
                static async create(e, t) {
                    const i = new ie(e, t);
                    return await i._decryptStorage(), i
                }
                async _decryptStorage() {
                    const e = this._persistentStorage.getItem(this._key);
                    if (null === e) return void(this._transientStorage = {});
                    const t = await this._cryptographer.decrypt(e);
                    if (null === t) return this._persistentStorage.removeItem(this._key), void(this._transientStorage = {});
                    try {
                        this._transientStorage = JSON.parse(t)
                    } catch (e) {
                        this._transientStorage = {}
                    }
                }
                async _encryptStorageAndSave() {
                    const e = await this._cryptographer.encrypt(JSON.stringify(this._transientStorage));
                    this._persistentStorage.setItem(this._key, e)
                }
            }
            class se {
                constructor(e, t, i, s) {
                    this._brokerId = e.toLowerCase(), this._rememberCredentials = t, this._localStorageProvider = i, this._sessionStorageProvider = s
                }
                async save(e, t) {
                    this._currentStorageProvider().setItem(`${this._brokerId}.${e}`, t)
                }
                load(e, t) {
                    return this._currentStorageProvider().getItem(`${this._brokerId}.${e}`, t)
                }
                async clear(e) {
                    this._currentStorageProvider().removeItem(`${this._brokerId}.${e}`)
                }
                destroy() {
                    this._localStorageProvider.destroy(), this._sessionStorageProvider.destroy()
                }
                static async create(e, t, i) {
                    const s = await ie.create(localStorage, i),
                        r = await ie.create(sessionStorage, i);
                    return new se(e, t, s, r)
                }
                _currentStorageProvider() {
                    return this._rememberCredentials.value() ? this._localStorageProvider : this._sessionStorageProvider
                }
            }
            var re = i(97387),
                oe = i(69731);
            class ne {
                constructor(e) {
                    this._settingsKey = `trading.${e}.rememberCredentials`
                }
                value() {
                    return x().getBool(this._settingsKey, !0)
                }
                setValue(e) {
                    x().setValue(this._settingsKey, e)
                }
            }
            const ae = [];

            function le(e, t) {
                e.configFlags = (0, oe.applyDefaultsToConfigFlags)(e.configFlags), ae.push({
                    metainfo: e,
                    createBrokerFunction: t
                })
            }

            function ce() {
                return ae.map(e => e.metainfo)
            }
            let de;
            async function ue(e, t, i, s, r) {
                const o = ae.filter(e => e.metainfo.id === t)[0];
                let n;
                if (null === s) {
                    const i = await se.create(t, new ne(t), de),
                        s = r => {
                            (null == r ? void 0 : r.metainfo().id) !== t && (null == e || e.onBrokerChange.unsubscribe(null, s), i.destroy())
                        };
                    null == e || e.onBrokerChange.subscribe(null, s), n = i
                } else n = s;
                const a = new Y(e, o.metainfo, i, n);
                try {
                    const t = await o.createBrokerFunction(a, null == e ? void 0 : e.brokerTelemetry),
                        i = new re.BrokerRealtimeAdapter(o.metainfo.id);
                    return new A({
                        brokerMetainfo: o.metainfo,
                        brokerConnection: t,
                        host: a,
                        brokerRealtimeAdapter: i,
                        tradingStat: e && e.tradingStat(),
                        tradingSettingsStorageGetter: e && e.getBrokerTradingSettingsStorage,
                        brokerPlan: r
                    })
                } catch (e) {
                    return Promise.reject(`${t} broker creation error: ${(0,f.getLoggerMessage)(e)}`)
                }
            }
            de = {
                encrypt: async e => e,
                decrypt: async e => e
            }
        },
        69731: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                defaultConfigFlags: () => s,
                applyDefaultsToConfigFlags: () => r
            });
            const s = {
                isSuspended: !1,
                supportDemoLiveSwitcher: !0,
                supportModifyOrderPrice: !0,
                supportEditAmount: !0,
                supportModifyBrackets: !0,
                supportMarketBrackets: !0,
                supportMarketOrders: !0,
                supportStopOrders: !0,
                supportLimitOrders: !0,
                supportStopLimitOrders: !1,
                supportPositions: !0,
                supportDOM: !0,
                supportModifyTrailingStop: !0,
                supportAddBracketsToExistingOrder: !0,
                supportVerifyLiveAccount: !0,
                supportReversePosition: !0,
                showNotificationsLog: !0,
                supportPLUpdate: !0,
                supportTwoFactorAuthorization: !1,
                supportDisplayBrokerNameInSymbolSearch: !0,
                supportCurrencyInOrderPreview: !0,
                supportRiskControls: !0
            };

            function r(e) {
                return Object.assign({}, s, e)
            }
        },
        15180: (e, t, i) => {
            "use strict";
            i.d(t, {
                DialogVisibility: () => o
            });
            var s = i(47488),
                r = i(18286);
            class o {
                constructor() {
                    this._value$ = new s.BehaviorSubject({
                        isVisible: !1
                    }), this.value$ = this._value$.asObservable().pipe((0, r.distinctUntilChanged)((e, t) => e.isVisible === t.isVisible && e.isFullScreen === t.isFullScreen))
                }
                getValue() {
                    return this._value$.getValue()
                }
                setValue(e) {
                    this._value$.next(e)
                }
            }
        },
        70595: (e, t, i) => {
            "use strict";
            i.d(t, {
                DisabledConfirmations: () => u
            });
            var s = i(70122),
                r = i.n(s),
                o = i(55385),
                n = i.n(o),
                a = i(74617);
            const l = /[0-9]+([\.,][0-9]+)*([\.,][0-9]+)?|\.[0-9]+/gm,
                c = /[A-Z]+/gm,
                d = a.settingsKeys.DISABLED_CONFIRMATIONS;
            class u {
                add(e) {
                    const t = this._getAll(),
                        i = this._makeMessageHash(e);
                    t.add(i), r().setJSON(d, Array.from(t))
                }
                has(e) {
                    const t = this._getAll(),
                        i = this._makeMessageHash(e);
                    return t.has(i)
                }
                clear() {
                    r().remove(d)
                }
                _getAll() {
                    return new Set(r().getJSON(d))
                }
                _makeMessageHash(e) {
                    const t = e.replace(l, "").replace(c, "");
                    return i = n()(t), btoa(String.fromCharCode.apply(null, new Uint8Array(i)));
                    var i
                }
            }
        },
        96709: (e, t, i) => {
            "use strict";

            function s(e) {
                return "string" == typeof e ? e : Array.isArray(e) ? e.join("") : void 0
            }
            i.d(t, {
                makeConfirmation: () => s
            })
        },
        27818: (e, t, i) => {
            "use strict";
            i.d(t, {
                showConfirmDialog: () => n
            });
            var s = i(25177),
                r = i(96709),
                o = i(70595);
            async function n(e) {
                const {
                    title: t,
                    content: n,
                    mainButtonText: a,
                    cancelButtonText: l,
                    showDisableConfirmationsCheckbox: c,
                    onOpen: d,
                    onClose: u
                } = e, h = new o.DisabledConfirmations, p = (0, r.makeConfirmation)(n);
                if (c && void 0 !== p && h.has(p)) return !0;
                const {
                    ConfirmDialogRenderer: _
                } = await Promise.all([i.e(5514), i.e(9289), i.e(7427), i.e(8463), i.e(7552), i.e(5998), i.e(7345), i.e(9309), i.e(7819), i.e(994), i.e(3566)]).then(i.bind(i, 97097)), g = new _(h), m = {
                    title: t,
                    message: n,
                    closeButton: null != l ? l : (0, s.t)("No"),
                    confirmButton: null != a ? a : (0, s.t)("Yes"),
                    showDisableConfirmationsCheckbox: c,
                    onOpen: d,
                    onClose: u
                };
                return (await g.open(m)).status
            }
        },
        71763: (e, t, i) => {
            "use strict";
            i.d(t, {
                showSimpleConfirmDialog: () => r
            });
            var s = i(70595);
            async function r(e) {
                const t = new s.DisabledConfirmations;
                if (e.showDisableConfirmationsCheckbox && t.has(e.text)) return !0;
                const [{
                    showSimpleDialog: r
                }, {
                    SimpleConfirmDialog: o
                }] = await Promise.all([Promise.all([i.e(5514), i.e(9289), i.e(7427), i.e(8463), i.e(7552), i.e(5998), i.e(7345), i.e(9309), i.e(7819), i.e(994), i.e(3566)]).then(i.bind(i, 80994)), Promise.all([i.e(5514), i.e(9289), i.e(7427), i.e(8463), i.e(7552), i.e(5998), i.e(7345), i.e(9309), i.e(7819), i.e(994), i.e(3566)]).then(i.bind(i, 26286))]);
                return new Promise(i => {
                    r({ ...e,
                        disabledConfirmations: t,
                        onConfirm: t => {
                            i(!0), void 0 !== e.onConfirm && e.onConfirm(), t.dialogClose()
                        },
                        onClose: () => {
                            i(!1), void 0 !== e.onClose && e.onClose()
                        },
                        onCancel: t => {
                            i(!1), void 0 !== e.onCancel && e.onCancel(t), t.dialogClose()
                        }
                    }, o)
                })
            }
        },
        39319: (e, t, i) => {
            "use strict";
            i.d(t, {
                ConfirmBracketsCancelDialog: () => o
            });
            var s = i(25177),
                r = i(71763);
            const o = {
                get() {
                    return this
                },
                open: e => (0, r.showSimpleConfirmDialog)({
                    title: (0, s.t)("Cancel bracket"),
                    text: (0, s.t)("Are you sure you want to cancel {orderId}bracket?").replace("{orderId}", "" !== e ? e + " " : ""),
                    mainButtonIntent: "primary"
                }),
                multiple: e => (0, r.showSimpleConfirmDialog)({
                    title: (0, s.t)("Cancel bracket"),
                    text: (0, s.t)("Are you sure you want to cancel {orderId}brackets?").replace("{orderId}", "" !== e ? e + " " : ""),
                    mainButtonIntent: "primary"
                })
            }
        },
        74891: (e, t, i) => {
            "use strict";
            i.d(t, {
                ConfirmOrderCancelDialog: () => o
            });
            i(35897);
            var s = i(25177),
                r = i(71763);
            const o = {
                get() {
                    return this
                },
                open: e => (0, r.showSimpleConfirmDialog)({
                    title: (0, s.t)("Cancel order"),
                    text: (0, s.t)("Are you sure you want to cancel order {orderId}?").replace("{orderId}", e),
                    mainButtonIntent: "primary"
                }),
                multiple(e, t, i) {
                    let o = e;
                    if (void 0 !== t) {
                        o = `${o} ${1===t?(0,s.t)("BUY"):(0,s.t)("SELL")}`
                    }
                    return (0, r.showSimpleConfirmDialog)({
                        title: (0, s.t)("Cancel order"),
                        text: (0, s.t)("Are you sure you want to cancel {qty} {side} orders?").replace("{qty}", String(i)).replace("{side}", o),
                        mainButtonIntent: "primary"
                    })
                }
            }
        },
        63891: (e, t, i) => {
            "use strict";
            i.d(t, {
                reversePositionDialog: () => o
            });
            var s = i(25177),
                r = i(71763);
            async function o(e, t, i, o) {
                if (!await (0, r.showSimpleConfirmDialog)({
                        title: (0, s.t)("Reverse {positionId} position?").replace("{positionId}", e),
                        text: (0, s.t)("Are you sure you want to reverse {positionId} position?").replace("{positionId}", e) + (o ? " " + (0, s.t)("This will also close all active orders.") : ""),
                        mainButtonText: (0, s.t)("Reverse position"),
                        mainButtonIntent: "primary",
                        cancelButtonText: (0, s.t)("Cancel"),
                        showBackdrop: !0
                    })) return !1;
                try {
                    return await i()
                } catch (e) {
                    return t((0, s.t)("Failed to reverse position"), function(e) {
                        let t = "";
                        null !== e && "object" == typeof e && e.message ? t = e.message : "string" == typeof e && (t = e);
                        return t
                    }(e)), !1
                }
            }
        },
        47898: (e, t, i) => {
            "use strict";
            i.d(t, {
                makeSubjectFromWatchedValue: () => g,
                comparator: () => m,
                shouldShowTotal: () => b,
                displayedLeverage: () => y,
                calculatePipValue: () => v,
                calculateTradeValue: () => f,
                calculateTradeValueByBigPointValue: () => k,
                calculateUsedMargin: () => w,
                calculatedMarginRatio: () => S,
                formatInfoValue: () => C,
                formatRiskReward: () => B,
                alignQuotesToMinTick: () => T,
                isMintickMultiple: () => E,
                getAsk: () => L,
                getBid: () => O,
                getLast: () => D,
                getQuotePrice: () => I,
                isNoQuotes: () => N,
                checkPriceByOrderType: () => A,
                prepareCalculatorEventText: () => M,
                i18nOrderResultText: () => V,
                createCustomFieldModels: () => x,
                prepareTradableSolution: () => F,
                convertToBaseMonetaryUnit: () => R
            });
            var s = i(25177),
                r = i(88401),
                o = i(47488),
                n = i(60521),
                a = i(94489),
                l = i.n(a),
                c = i(2683),
                d = i(72249),
                u = i(35687),
                h = i(297),
                p = i(97496),
                _ = i.n(p);

            function g(e) {
                const t = new o.BehaviorSubject(e.value()),
                    i = e => {
                        t.next(e)
                    };
                return e.subscribe(i), {
                    subject: t,
                    unsubscribe: () => e.unsubscribe(i)
                }
            }

            function m(e, t) {
                return (0, c.deepEquals)(e, t)[0]
            }

            function b(e) {
                return void 0 !== e && Boolean(e.showTotal)
            }

            function y(e, t) {
                if (void 0 !== e) return e;
                if (void 0 !== t) {
                    const e = Math.round(1 / t);
                    return String(e) + ":1"
                }
                return null
            }

            function v(e, t, i) {
                return null !== e ? (void 0 !== i ? e * i : e) * t : 0
            }

            function f(e, t, i, s, r) {
                return k(e, t, i / s, r)
            }

            function k(e, t, i, s) {
                return e * t * i * (s || 1)
            }

            function w(e, t) {
                return void 0 !== t ? e * t : 0
            }

            function S(e, t) {
                const i = 0 !== t ? 100 * e / t : 0;
                return i > 100 ? 100 : i
            }

            function C(e) {
                if ("number" == typeof e) {
                    const t = (0, d.splitThousands)((e || 0).toFixed(2), " ");
                    return Number.isInteger(e) || e >= 1 ? t : function(e) {
                        if (Number.isInteger(e)) return e + "";
                        return e < 1 ? function(e) {
                            const t = (e + "").split(".")[1] || "";
                            let i = t.length;
                            for (let e = 0; e < t.length; e++)
                                if ("0" !== t[e]) {
                                    i = e + 1;
                                    break
                                }
                            return e.toFixed(i)
                        }(e) : e.toFixed(2)
                    }(e)
                }
                return (0, d.splitThousands)(e, " ")
            }
            const P = new u.VolumeFormatter(2);

            function B(e, t) {
                return null !== e && null !== t && e / t > 0 ? P.format(e / t) : ""
            }

            function T(e, t) {
                const i = Object.assign({}, e);
                return ["trade", "ask", "bid"].forEach(e => {
                    const s = i[e];
                    void 0 !== s && (i[e] = function(e, t) {
                        return t > 1 ? e : (0, n.Big)(e).div(t).round(0, 1).mul(t).toNumber()
                    }(s, t))
                }), i
            }

            function E(e, t) {
                if (0 === t) return !1;
                const i = Math.round(1e12 * t) / 1e12,
                    s = new n.Big(e),
                    r = new n.Big(i);
                return s.mod(r).eq(0)
            }

            function L(e) {
                return (0, c.isNumber)(e.ask) ? e.ask : (0, c.isNumber)(e.trade) ? e.trade : 0
            }

            function O(e) {
                return (0, c.isNumber)(e.bid) ? e.bid : (0, c.isNumber)(e.trade) ? e.trade : 0
            }

            function D(e) {
                return (0, c.isNumber)(e.trade) ? e.trade : 0
            }

            function I(e, t) {
                return 1 === e ? L(t) : O(t)
            }

            function N(e) {
                return null === e || void 0 === e.ask || void 0 === e.bid
            }

            function A(e, t, i) {
                return 4 === e ? null === t || null === i : 3 === e ? null === i : null === t
            }

            function M(e, t) {
                switch (t) {
                    case h.ButtonType.IncDec:
                        return e < 0 ? "-" : "+";
                    case h.ButtonType.PlusValue:
                        return String(e);
                    case h.ButtonType.Clear:
                        return "Clear";
                    default:
                        return "Default"
                }
            }
            const V = {
                buy: {
                    market: (e, t) => (0, s.t)("Buy {qty} {symbol}{whitespaceNoBreak}MKT").format({
                        qty: e,
                        symbol: t,
                        whitespaceNoBreak: " "
                    }),
                    stop: (e, t, i) => (0, s.t)("Buy {qty} {symbol}{whitespaceNoBreak}@ {stopPrice}{whitespaceNoBreak}STP").format({
                        qty: e,
                        symbol: t,
                        stopPrice: i,
                        whitespaceNoBreak: " "
                    }),
                    limit: (e, t, i) => (0,
                        s.t)("Buy {qty} {symbol}{whitespaceNoBreak}@ {limitPrice}{whitespaceNoBreak}LMT").format({
                        qty: e,
                        symbol: t,
                        limitPrice: i,
                        whitespaceNoBreak: " "
                    }),
                    stopLimit: (e, t, i, r) => (0, s.t)("Buy {qty} {symbol}{whitespaceNoBreak}@ {stopPrice}{whitespaceNoBreak}STP {limitPrice}{whitespaceNoBreak}LMT").format({
                        qty: e,
                        symbol: t,
                        stopPrice: i,
                        limitPrice: r,
                        whitespaceNoBreak: " "
                    })
                },
                sell: {
                    market: (e, t) => (0, s.t)("Sell {qty} {symbol}{whitespaceNoBreak}MKT").format({
                        qty: e,
                        symbol: t,
                        whitespaceNoBreak: " "
                    }),
                    stop: (e, t, i) => (0, s.t)("Sell {qty} {symbol}{whitespaceNoBreak}@ {stopPrice}{whitespaceNoBreak}STP").format({
                        qty: e,
                        symbol: t,
                        stopPrice: i,
                        whitespaceNoBreak: " "
                    }),
                    limit: (e, t, i) => (0, s.t)("Sell {qty} {symbol}{whitespaceNoBreak}@ {limitPrice}{whitespaceNoBreak}LMT").format({
                        qty: e,
                        symbol: t,
                        limitPrice: i,
                        whitespaceNoBreak: " "
                    }),
                    stopLimit: (e, t, i, r) => (0, s.t)("Sell {qty} {symbol}{whitespaceNoBreak}@ {stopPrice}{whitespaceNoBreak}STP {limitPrice}{whitespaceNoBreak}LMT").format({
                        qty: e,
                        symbol: t,
                        stopPrice: i,
                        limitPrice: r,
                        whitespaceNoBreak: " "
                    })
                }
            };

            function x(e, t, i, s, r) {
                const o = [];
                return void 0 !== s && Array.isArray(s.customFields) && s.customFields.forEach(s => {
                    if ("TextWithCheckBox" === s.inputType && o.push({
                            id: s.id,
                            type: s.inputType,
                            inputType: s.customInfo.asterix ? "password" : "text",
                            placeholder: s.placeHolder || "",
                            title: s.title || "",
                            checkboxTitle: s.customInfo.checkboxTitle,
                            text: new(l())(s.value.text),
                            checked: new(l())(s.value.checked),
                            status: t,
                            onControlFocused: new(_())
                        }), "Checkbox" === s.inputType) {
                        let i;
                        const n = null == r ? void 0 : r[s.id];
                        try {
                            i = JSON.parse(n)
                        } catch (e) {
                            i = n
                        }
                        o.push({
                            id: s.id,
                            type: s.inputType,
                            title: s.title,
                            help: s.help,
                            checked: new(l())(null != i ? i : s.value),
                            status: t,
                            onControlFocused: new(_()),
                            disabled: e && !s.supportModify,
                            saveToSettings: s.saveToSettings
                        })
                    }
                    if ("ComboBox" === s.inputType && Array.isArray(s.items)) {
                        let t = s.items[0];
                        if (r && s.id in r) {
                            const e = r[s.id],
                                i = s.items.find(t => t.value === e);
                            void 0 !== i && (t = i)
                        } else s.forceUserEnterInitialValue && !e && (t = void 0);
                        o.push({
                            id: s.id,
                            type: s.inputType,
                            title: s.title,
                            items: s.preventModify && e && t ? [t] : s.items,
                            selectedItem: new(l())(null == t ? void 0 : t.value),
                            onControlFocused: new(_()),
                            saveToSettings: s.saveToSettings,
                            isRequired: Boolean(s.forceUserEnterInitialValue),
                            alwaysShowAttachedErrors: i
                        })
                    }
                }), o
            }
            async function F(e, t) {
                if (void 0 !== e.solutions) {
                    let i, o;
                    if ("changeSymbol" in e.solutions) {
                        const t = e.solutions.changeSymbol;
                        i = (0, s.t)("Switch the symbol"), o = () => r.linking.symbol.setValue(t)
                    } else {
                        const r = e.solutions.changeAccount,
                            n = (await t.accountsMetainfo()).filter(e => e.id === r)[0].name;
                        i = (0, s.t)("Switch to {accountName}").replace("{accountName}", n), o = () => t.setCurrentAccount(r)
                    }
                    return {
                        title: i,
                        apply: o
                    }
                }
            }

            function R(e, t) {
                return void 0 === t ? e : (0, n.Big)(e).div(t).toNumber()
            }
        },
        84039: (e, t, i) => {
            "use strict";
            i.d(t, {
                qtyErrors: () => n,
                checkQtyError: () => a
            });
            var s = i(25177),
                r = i(60521),
                o = i.n(r);
            const n = {
                min: (0, s.t)("Specified amount is less than the instrument minimum of {min}."),
                max: (0, s.t)("Specified amount is more than the instrument maximum of {max}."),
                step: (0, s.t)("Specified amount is not a multiple of the instrument quantity step of {step}."),
                balance: (0,
                    s.t)("Your value exceeds the acceptable balance level.")
            };

            function a(e, t, i = !1) {
                if (null === t) return {
                    res: !0
                };
                const s = e.step,
                    r = e.min,
                    a = e.max;
                if (t < r) return {
                    res: !0,
                    msg: n.min.format({
                        min: r.toString()
                    })
                };
                if (t > a) return {
                    res: !0,
                    msg: n.max.format({
                        max: a.toString()
                    })
                };
                const l = new(o())(t).minus(r).mod(s);
                return i && !l.eq(0) ? {
                    res: !0,
                    msg: n.step.format({
                        step: s.toString()
                    })
                } : {
                    res: !1
                }
            }
        },
        18423: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                Trading: () => ui,
                showSellBuyButtonsDefault: () => di
            });
            var s = i(25177),
                r = i(88401),
                o = i(70122),
                n = i(82027),
                a = i(88537),
                l = i(23002),
                c = i(97345),
                d = i(24818),
                u = i(50681),
                h = i(76641),
                p = i(60521),
                _ = i.n(p),
                g = i(2683);
            var m = i(50317),
                b = i(51951),
                y = i(18833),
                v = i(63329),
                f = i(82527),
                k = i(49984),
                w = i(55563),
                S = i(94489),
                C = i.n(S),
                P = i(97496),
                B = i.n(P),
                T = i(18431);
            i(53055);
            var E = i(15180),
                L = i(71476),
                O = i(74617),
                D = i(97387),
                I = i(91371);
            const N = (0, b.getLogger)("Trading.RealtimeProvider");
            class A {
                constructor(e) {
                    this._results = {}, this._getter = e
                }
                get(e) {
                    return this._results[e] || (this._results[e] = this._getter(e)), this._results[e]
                }
            }
            class M {
                constructor(e, t, i, s, r) {
                    this._stopped = !1, this._subscribed = !1, this._provider = null, this._formatters = null, this._symbol = e, this._type = r, this._callback = t, this._providersCache = i, this._formattersCache = s, "Realtime" === this._type ? this._handler = (e, i) => {
                        this._stopped || t(e, i, this._formatters)
                    } : this._handler = (e, i) => {
                        this._stopped || t(e, i)
                    }, this._start().catch(e => {})
                }
                symbol() {
                    return this._symbol
                }
                type() {
                    return this._type
                }
                callback() {
                    return this._callback
                }
                destroy() {
                    this._ensureNotStopped(), this._subscribed && ("Realtime" === this._type ? (0, a.ensureNotNull)(this._provider).unsubscribeRealtime(this._symbol, this._handler) : (0, a.ensureNotNull)(this._provider).unsubscribeDOME(this._symbol, this._handler)), this._stopped = !0
                }
                async _start() {
                    this._provider = await this._providersCache.get(this._symbol), this._ensureNotStopped(), this._formatters = await this._formattersCache.get(this._symbol), (0, a.ensure)(this._formatters), this._ensureNotStopped(), this._subscribed = !0, "Realtime" === this._type ? this._provider.subscribeRealtime(this._symbol, this._handler) : this._provider.subscribeDOME(this._symbol, this._handler)
                }
                _ensureNotStopped() {
                    (0, a.assert)(!this._stopped, "Should not be stopped")
                }
            }
            class V {
                constructor(e, t, i) {
                    this.onStatusChanged = new(B()), this._subscriptions = [], this._currentBroker = null, this._activeBrokerGetter = e, t.subscribe(this, this._connectionStatusChanged), i.subscribe(this, this._connectionStatusChanged), this._tvProvider = new D.BrokerRealtimeAdapter("RealtimeProvider"), this._connectionStatusChanged()
                }
                isTradable(e) {
                    return this._tradableCache.get(e)
                }
                subscribeRealtime(e, t) {
                    this._subscriptions.some(i => i.symbol() === e && i.callback() === t && "Realtime" === i.type()) || this._subscriptions.push(new M(e, t, this._providersCache, this._formattersCache, "Realtime"))
                }
                unsubscribeRealtime(e, t) {
                    const i = this._subscriptions.findIndex(i => i.symbol() === e && i.callback() === t && "Realtime" === i.type());
                    if (-1 === i) return;
                    this._subscriptions[i].destroy(), this._subscriptions.splice(i, 1)
                }
                subscribeDOME(e, t) {
                    this._subscriptions.some(i => i.symbol() === e && i.callback() === t && "Dome" === i.type()) || this._subscriptions.push(new M(e, t, this._providersCache, this._formattersCache, "Dome"))
                }
                unsubscribeDOME(e, t) {
                    const i = this._subscriptions.findIndex(i => i.symbol() === e && i.callback() === t && "Dome" === i.type());
                    if (-1 === i) return void N.logWarn("Subscription not found");
                    this._subscriptions[i].destroy(), this._subscriptions.splice(i, 1)
                }
                formatter(e) {
                    return this._formattersCache.get(e).then(e => e.formatter)
                }
                spreadFormatter(e) {
                    return this._formattersCache.get(e).then(e => e.spreadFormatter)
                }
                quantityFormatter(e) {
                    return this._formattersCache.get(e).then(e => e.quantityFormatter)
                }
                symbolInfo(e) {
                    if (!e) {
                        const e = {
                            minTick: NaN,
                            qty: {
                                min: NaN,
                                max: NaN,
                                step: NaN
                            },
                            pipValue: NaN,
                            pipSize: NaN,
                            description: "no symbol"
                        };
                        return Promise.resolve(e)
                    }
                    return this._providersCache.get(e).then(t => t !== this._tvProvider ? t.symbolInfo(e).then(t => t || this._tvProvider.symbolInfo(e)).catch(t => this._tvProvider.symbolInfo(e)) : this._tvProvider.symbolInfo(e))
                }
                quotesSnapshot(e) {
                    return this._providersCache.get(e).then(t => t.quotesSnapshot(e))
                }
                activeBroker() {
                    return null !== this._currentBroker && this._currentBroker !== this._tvProvider ? this._currentBroker : null
                }
                _isTradable(e) {
                    if (null === this._currentBroker || this._currentBroker === this._tvProvider) return Promise.resolve({
                        tradable: !1
                    });
                    try {
                        return (0, I.makeTimeLimited)(this._currentBroker.isTradable(e), 6e4, "isTradable Promise Timeout").catch(() => Promise.resolve({
                            tradable: !1
                        }))
                    } catch (e) {
                        return Promise.resolve({
                            tradable: !1
                        })
                    }
                }
                _haveRealtime(e) {
                    return this._tradableCache.get(e) || Promise.resolve(null === this._currentBroker)
                }
                _connectionStatusChanged() {
                    const e = this._activeBrokerGetter(),
                        t = this._currentBroker,
                        i = e && 1 === e.connectionStatus() ? e : null;
                    if (this._createCaches(), t !== i) {
                        const e = this._subscriptions.map(e => ({
                            symbol: e.symbol(),
                            callback: e.callback(),
                            type: e.type()
                        }));
                        this._unsubscribeAll(), this._currentBroker = i, this._subscribeAll(e), this.onStatusChanged.fire()
                    }
                }
                _createCaches() {
                    this._providersCache = new A(e => this._provider(e)), this._tradableCache = new A(e => this._isTradable(e)), this._formattersCache = new A(e => this._providersCache.get(e).then(t => Promise.all([t.formatter(e, !1), t.spreadFormatter(e), t.quantityFormatter(e)])).then(([e, t, i]) => ({
                        formatter: e,
                        spreadFormatter: t,
                        quantityFormatter: i
                    })))
                }
                _provider(e) {
                    return this._haveRealtime(e).then(e => e.tradable && this._currentBroker && 1 === this._currentBroker.connectionStatus() ? this._currentBroker : this._tvProvider)
                }
                _unsubscribeAll() {
                    this._subscriptions.forEach(e => {
                        e.destroy()
                    }), this._subscriptions = []
                }
                _subscribeAll(e) {
                    e.forEach(e => {
                        this._subscriptions.push(new M(e.symbol, e.callback, this._providersCache, this._formattersCache, e.type))
                    })
                }
            }
            var x = i(7053);
            class F extends x.BrokerService {
                constructor(e) {
                    super(e), this._userId = (window.user.id || "").toString(), window.loginStateChange && window.loginStateChange.subscribe(this, this._onLoginStateChange)
                }
                trackOrderPlaced(e) {
                    this._trackOrderEvent("Placed", e)
                }
                startService() {
                    (0, a.ensure)(this.activeBroker()).orderUpdate.subscribe(this, this._orderUpdate), this._trackTradingBrokerConnnected()
                }
                stopService() {
                    (0,
                        a.ensure)(this.activeBroker()).orderUpdate.unsubscribe(this, this._orderUpdate)
                }
                _orderUpdate(e, t) {
                    t || (5 === e.status ? this._trackOrderEvent("Rejected", e) : 2 === e.status ? this._trackOrderEvent("Executed", e) : 1 === e.status && this._trackOrderEvent("Canceled", e))
                }
                _trackOrderEvent(e, t) {
                    const i = this.activeBroker();
                    if (t && i) {
                        const s = t.id || null;
                        i.symbolInfo(t.symbol).then(i => {
                            const r = {
                                amount: t.qty * (i.lotSize || 1),
                                orderId: s,
                                instrumentType: i.type,
                                eventName: "Order " + e,
                                userId: this._userId,
                                symbol: t.symbol
                            };
                            this._trackTradingOrder(r)
                        })
                    }
                }
                _trackTradingOrder(e) {
                    const t = this.activeBroker();
                    if (!t) throw new Error("no active broker")
                }
                _trackTradingBrokerConnnected() {
                    const e = this.activeBroker();
                    null !== e && e.metainfo().id;
                    if (!e) throw new Error("no active broker")
                }
                _onLoginStateChange() {
                    this._userId = (window.user.id || "").toString()
                }
            }
            var R = i(32133),
                q = i(63697),
                U = i(6056);

            function W(e = "default") {
                switch (e) {
                    case "danger":
                        return q.ToastIntent.Danger;
                    case "attention":
                        return q.ToastIntent.Warning;
                    case "success":
                        return q.ToastIntent.Success;
                    default:
                        return q.ToastIntent.Default
                }
            }
            class Q {
                constructor(e) {
                    this._chartWidgetCollection = e
                }
                proSymbol() {
                    return r.linking.proSymbol.value()
                }
                showTradingProperties() {
                    this._chartWidgetCollection.activeChartWidget.value().showGeneralChartProperties(T.TabNames.trading)
                }
                async closeAllNotifications() {
                    const e = await this._chartWidgetCollection.getToasts();
                    null !== e && e.reset()
                }
                async showNotification(e, t, i, s) {
                    const r = await this._chartWidgetCollection.getToasts();
                    if (null === r) return;
                    let o = "";
                    "string" == typeof t && (o = t), r.showSimpleToast({
                        text: o,
                        time: s,
                        title: e,
                        intent: W(i),
                        priority: U.ToastPriority.Low
                    })
                }
                showMaintenance(e) {
                    0
                }
                showBrokerSideMaintenance(e) {
                    0
                }
                trackEvent(e, t, i) {
                    (0, R.trackEvent)(e, t, i)
                }
                showReplayConfirmationDialog() {
                    return Promise.resolve()
                }
                reconnectChartApi(e) {
                    0
                }
                setBroker(e) {
                    const t = (null == e ? void 0 : e.metainfo().backendBrokerName) || (null == e ? void 0 : e.metainfo().id.toLowerCase()) || "";
                    this._chartWidgetCollection.setBroker(t)
                }
            }
            var j = i(44963),
                H = (i(35897), i(27818));
            async function z(e) {
                const {
                    showErrorNotification: t,
                    handler: i,
                    message: r,
                    onOpen: o,
                    onClose: n
                } = e;
                if (!await (0, H.showConfirmDialog)({
                        title: (0, s.t)("Close position"),
                        content: r,
                        mainButtonText: (0, s.t)("Close position"),
                        cancelButtonText: (0, s.t)("Cancel"),
                        onOpen: o,
                        onClose: n
                    })) return !1;
                try {
                    return await i()
                } catch (e) {
                    return t((0, s.t)("Failed to close the position"), function(e) {
                        let t = "";
                        null !== e && "object" == typeof e && e.message ? t = e.message : "string" == typeof e && (t = e);
                        return t
                    }(e)), !1
                }
            }
            var $ = i(63891),
                G = i(74891),
                K = i(39319);
            async function Z(e, t, r) {
                const o = await async function(e) {
                    const {
                        PartiallyClosingDialogRenderer: t
                    } = await i.e(3168).then(i.bind(i, 43529)), s = new t;
                    return new Promise(t => {
                        s.open({ ...e,
                            dialogActionHandler: t
                        })
                    })
                }(e);
                if (!o.status) return !1;
                try {
                    return await t(o.qty)
                } catch (e) {
                    return r((0, s.t)("Failed to close the position"), function(e) {
                        let t = "";
                        null !== e && "object" == typeof e && e.message ? t = e.message : "string" == typeof e && (t = e);
                        return t
                    }(e)), !1
                }
            }
            var J = i(59496),
                Y = i(72249);

            function X(e) {
                const {
                    symbol: t,
                    side: i,
                    qty: r,
                    price: o,
                    id: n,
                    closePositionCancelsOrders: a
                } = e, l = (0, Y.splitThousands)(r, " "), c = (0,
                    Y.splitThousands)(o, " ");
                return J.createElement(J.Fragment, null, J.createElement("div", null, void 0 !== n ? (0, s.t)("Position ID {id}").replace("{id}", n) : (0, s.t)("Position")), J.createElement("div", null, J.createElement("b", null, t)), J.createElement("div", null, J.createElement("b", null, `${i} ${l} @ ${c}`)), J.createElement("div", null, a && " " + (0, s.t)("This will also close all active orders")))
            }
            i(51049), i(2054), i(47898), i(22987), i(38212);
            var ee = i(36376);
            const te = (0, b.getLogger)("Trading.BrokerCommandsUI"),
                ie = {
                    symbol: 1,
                    qty: 1,
                    side: 1,
                    type: 1,
                    seenPrice: 1
                };
            class se {
                constructor(e, t, i, s, r, o) {
                    this._closePositionDialogVisibility = new E.DialogVisibility, this._isClosePositionDialogLoading = !1, this._isCloseTradeDialogLoading = !1, this._onClosePositionDialogOpen = e => {
                        this._closePositionDialogVisibility.setValue({
                            isVisible: !0,
                            isFullScreen: e
                        })
                    }, this._onClosePositionDialogClose = () => {
                        this._closePositionDialogVisibility.setValue({
                            isVisible: !1
                        })
                    }, this._activeBroker = e, this._guiAccessor = t, this._orderViewController = s, this._showErrorNotification = r, this._noConfirmEnabled = i, this._trackEvent = o, this.closePositionDialogVisibility = this._closePositionDialogVisibility.value$
                }
                async placeOrder(e, t, i) {
                    this._makeSureBrokerIsConnected();
                    const s = t && this._noConfirmEnabled.value(),
                        r = this._guiAccessor && s ? this._guiAccessor.showReplayConfirmationDialog() : Promise.resolve(!1);
                    try {
                        await r
                    } catch (e) {
                        Promise.resolve(!1)
                    }
                    const o = await this._activeBroker.isTradable(e.symbol);
                    if (s && o.tradable && function(e) {
                            for (const t in ie)
                                if (!(t in e)) return !1;
                            return !0
                        }(e)) {
                        if (void 0 === e.duration) {
                            const t = await this._activeBroker.symbolInfo(e.symbol),
                                i = (0, ee.makeInitialOrderDuration)(e.type, this._getDurationMetaInfoList(t));
                            null !== i && (e.duration = i)
                        }
                        return this._activeBroker.placeOrder(e)
                    } {
                        const t = this._activeBroker.metainfo();
                        if (t.customUI && void 0 !== t.customUI.showOrderDialog) return t.customUI.showOrderDialog(e)
                    }
                    return this._orderViewController().then(t => this._activeBroker ? t.showOrderView({
                        order: e,
                        focus: void 0,
                        forceOrderDialog: i
                    }) : Promise.reject("Broker connection adapter is null"))
                }
                async modifyOrder(e, t, i, r) {
                    const o = this._activeBroker.metainfo();
                    if (!o.configFlags.supportModifyTrailingStop) {
                        const t = (await this._activeBroker.orders()).find(t => t.id === e.id);
                        void 0 !== t && void 0 !== t.trailingStopPips ? e.hasTrailingStopBracket = !0 : e.hasTrailingStopBracket = !1
                    }
                    if (this._makeSureBrokerIsConnected(), e.flags && e.flags.trailingStop) return te.logError("Attempt to modify trailing stop loss order" + e.id), this._showErrorNotification((0, s.t)("Cannot Modify Order"), (0, s.t)("Trailing Stops cannot be modified")), Promise.resolve(!1);
                    const n = await this._activeBroker.symbolInfo(e.symbol);
                    e.limitPrice = void 0 !== n.limitPriceStep && void 0 !== e.limitPrice ? (0, m.roundToStepByPriceTypeAndSide)(e.limitPrice, n.limitPriceStep, 1, e.side) : e.limitPrice, e.stopPrice = void 0 !== n.stopPriceStep && void 0 !== e.stopPrice ? (0, m.roundToStepByPriceTypeAndSide)(e.stopPrice, n.stopPriceStep, 2, e.side) : e.stopPrice;
                    const a = e.limitPrice,
                        l = e.stopPrice,
                        c = e.stopType,
                        d = t && this._noConfirmEnabled.value();
                    let h = i || (1 === e.type ? 1 : 2);
                    if (e.parentId && !f.enabled("always_pass_called_order_to_modify")) {
                        let t, s = this._activeBroker.orderById.bind(this._activeBroker);
                        2 === e.parentType && (s = this._activeBroker.positionById.bind(this._activeBroker)), 3 === e.parentType && (s = this._activeBroker.tradeById.bind(this._activeBroker));
                        try {
                            t = await s(e.parentId)
                        } catch (e) {
                            t = void 0
                        }
                        if (t) {
                            h = i || (1 === e.type ? 3 : 4);
                            const s = {
                                takeProfit: a
                            };
                            if (c === j.StopType.TrailingStop ? s.trailingStopPips = e.trailingStopPips : s.stopLoss = l, d && (s.takeProfit = s.takeProfit || t.takeProfit, s.stopLoss = s.stopLoss || t.stopLoss, s.trailingStopPips = s.trailingStopPips || t.trailingStopPips), 3 === e.parentType) return d ? this._activeBroker.editTradeBrackets(t.id, s) : this._showTradeDialog(t, s, h);
                            if (2 === e.parentType && e.qty === Math.abs(t.qty)) return d ? this._activeBroker.editPositionBrackets(t.id, s) : this._showPositionDialog(t, s, h);
                            const r = t;
                            (0, u.isOrderActive)(r.status) && (e = Object.assign({}, r), a && (e.takeProfit = a), l && (c === j.StopType.TrailingStop ? e.trailingStopPips = s.trailingStopPips || e.trailingStopPips : e.stopLoss = l))
                        }
                    }
                    return d ? this._activeBroker.modifyOrder(e) : o.customUI && void 0 !== o.customUI.showOrderDialog ? o.customUI.showOrderDialog(e, h) : this._orderViewController().then(t => this._activeBroker ? t.showOrderView({
                        order: e,
                        focus: h,
                        forceOrderDialog: r
                    }) : Promise.reject("Broker connection adapter is null"))
                }
                async closePosition(e) {
                    var t, i;
                    if (this._makeSureBrokerIsConnected(), this._noConfirmEnabled.value()) return this._activeBroker.closePosition(e); {
                        if (this._isClosePositionDialogLoading) return !1;
                        const s = await this._obtainPositionClosingData(e);
                        if (void 0 === s) return !1;
                        const {
                            supportPartialClosePosition: r,
                            position: o,
                            ...n
                        } = s, a = this._activeBroker.metainfo();
                        if (void 0 !== (null === (t = a.customUI) || void 0 === t ? void 0 : t.showClosePositionDialog)) return null === (i = a.customUI) || void 0 === i ? void 0 : i.showClosePositionDialog(o);
                        if (r) {
                            const t = t => (t !== s.position.qty ? this._trackEvent("", "Close Position Dialog", "partial") : this._trackEvent("", "Close Position Dialog", "full"), this._activeBroker.closePosition(e, t));
                            return Z({ ...n,
                                positionOrTrade: o,
                                onOpen: this._onClosePositionDialogOpen,
                                onClose: this._onClosePositionDialogClose
                            }, t, this._showErrorNotification)
                        } {
                            const t = () => this._activeBroker.closePosition(e);
                            return z({
                                showErrorNotification: this._showErrorNotification,
                                handler: t,
                                message: s.message,
                                onOpen: this._onClosePositionDialogOpen,
                                onClose: this._onClosePositionDialogClose
                            })
                        }
                    }
                }
                async closeTrade(e) {
                    if (this._makeSureBrokerIsConnected(), (0, a.assert)(!!this._activeBroker.config.supportTrades, "Broker doesn`t support trades"), this._noConfirmEnabled.value()) return this._activeBroker.closeTrade(e); {
                        if (this._isCloseTradeDialogLoading) return !1;
                        const t = await this._obtainTradeClosingData(e);
                        if (void 0 === t) return !1;
                        const {
                            supportPartialCloseTrade: i,
                            trade: s,
                            ...r
                        } = t;
                        if (i) {
                            const t = async t => (t !== s.qty ? this._trackEvent("", "Close Trade Dialog", "partial") : this._trackEvent("", "Close Trade Dialog", "full"), this._activeBroker.closeTrade(e, t));
                            return Z({ ...r,
                                positionOrTrade: s,
                                onOpen: this._onClosePositionDialogOpen,
                                onClose: this._onClosePositionDialogClose
                            }, t, this._showErrorNotification)
                        }
                        return z({
                            showErrorNotification: this._showErrorNotification,
                            handler: () => this._activeBroker.closeTrade(e),
                            message: t.message,
                            onOpen: this._onClosePositionDialogOpen,
                            onClose: this._onClosePositionDialogClose
                        })
                    }
                }
                editPositionBrackets(e, t, i, s) {
                    return this._makeSureBrokerIsConnected(), (0, a.assert)(!!this._activeBroker.config.supportPositionBrackets, "Broker doesn`t support brackets on positions"), s && this._noConfirmEnabled.value() ? this._activeBroker.editPositionBrackets(e, null != t ? t : {}) : this._activeBroker.positionById(e).then(e => this._activeBroker ? this._showPositionDialog((0, a.ensureDefined)(e), t, i) : Promise.reject("Broker connection adapter is null"))
                }
                editTradeBrackets(e, t, i, s) {
                    return s && this._noConfirmEnabled.value() ? this._activeBroker.editTradeBrackets(e, null != t ? t : {}) : this._activeBroker.tradeById(e).then(e => this._activeBroker ? this._showTradeDialog((0, a.ensureDefined)(e), t, i) : Promise.reject("Broker connection adapter is null"))
                }
                reversePosition(e) {
                    return this._makeSureBrokerIsConnected(), this._activeBroker.metainfo().configFlags.supportMultiposition && !this._activeBroker.config.supportNativeReversePosition ? Promise.reject("Cannot reverse position on multiposition acount") : this._noConfirmEnabled.value() ? this._activeBroker.reversePosition(e) : this._activeBroker.positionById(e).then(t => {
                        if (!this._activeBroker) return Promise.reject("Broker connection adapter is null");
                        const i = this._activeBroker.reversePosition.bind(this._activeBroker, e);
                        return (0, $.reversePositionDialog)(e, this._showErrorNotification, i, this._activeBroker.config.closePositionCancelsOrders)
                    })
                }
                async cancelOrder(e) {
                    var t, i;
                    this._makeSureBrokerIsConnected();
                    if (this._noConfirmEnabled.value()) return this._activeBroker.cancelOrder(e); {
                        const s = await this._activeBroker.orderById(e),
                            r = this._activeBroker.cancelOrder.bind(this._activeBroker, e);
                        if (s) {
                            const e = this._activeBroker.metainfo();
                            if (void 0 !== (null === (t = e.customUI) || void 0 === t ? void 0 : t.showCancelOrderDialog)) return null === (i = e.customUI) || void 0 === i ? void 0 : i.showCancelOrderDialog(s);
                            if (s.parentId) {
                                const t = (await this._activeBroker.orders()).filter(e => e.refNumber === s.refNumber);
                                return e.configFlags.supportCancellingBothBracketsOnly && t.length > 1 ? this._showCancelMultipleBracketsDialog(s.parentId, r) : this._showCancelBracketsDialog(s.id, r)
                            }
                            return this._showCancelOrderDialog(s.id, r)
                        }
                        return Promise.reject("Failed to find order")
                    }
                }
                cancelOrders(e, t) {
                    return this._makeSureBrokerIsConnected(), this._activeBroker.orders().then(i => {
                        if (!this._activeBroker) return Promise.reject("Broker connection adapter is null");
                        const s = i.filter(i => i.symbol === e && (!t || i.side === t) && function(e) {
                            return 4 === e.status || 3 === e.status || 6 === e.status
                        }(i));
                        if (!s.length) return Promise.resolve(!1);
                        if (1 === s.length) return this.cancelOrder(s[0].id);
                        const r = s.map(e => e.id);
                        if (this._noConfirmEnabled.value()) return this._activeBroker.cancelOrders(e, t, r); {
                            const i = this._activeBroker.cancelOrders.bind(this._activeBroker);
                            return this._showCancelMultipleOrdersDialog(e, t, r, i)
                        }
                    })
                }
                _makeSureBrokerIsConnected() {
                    (0, a.assert)(1 === this._activeBroker.connectionStatus(), "Broker is not connected")
                }
                async _showPositionDialog(e, t = {}, i) {
                    const r = await this._activeBroker.isTradable(e.symbol);
                    if (!r.tradable) {
                        const t = void 0 !== r.reason ? r.reason : (0, m.makeNonTradableSymbolText)(e.symbol, this._activeBroker.metainfo().title);
                        return this._showErrorNotification((0, s.t)("Cannot protect position"), t), Promise.resolve(!1)
                    } {
                        const s = this._activeBroker.metainfo();
                        if (s.customUI && void 0 !== s.customUI.showPositionDialog) return s.customUI.showPositionDialog(e, {
                            stopLoss: t.stopLoss || e.stopLoss,
                            takeProfit: t.takeProfit || e.takeProfit
                        }, i)
                    }
                    return this._orderViewController().then(s => this._activeBroker ? s.showPositionView(e, {
                        stopLoss: t.stopLoss,
                        takeProfit: t.takeProfit,
                        trailingStopPips: t.trailingStopPips
                    }, i || e.limitPrice && 3 || e.stopPrice && 4) : Promise.reject("Broker connection adapter is null"))
                }
                _showTradeDialog(e, t = {}, i) {
                    {
                        const s = this._activeBroker.metainfo();
                        if (s.customUI && void 0 !== s.customUI.showPositionDialog) return s.customUI.showPositionDialog(e, {
                            stopLoss: t.stopLoss || e.stopLoss,
                            takeProfit: t.takeProfit || e.takeProfit
                        }, i)
                    }
                    return this._orderViewController().then(s => this._activeBroker ? s.showTradeView(e, {
                        stopLoss: t.stopLoss,
                        takeProfit: t.takeProfit,
                        trailingStopPips: t.trailingStopPips
                    }, i || e.limitPrice && 3 || e.stopPrice && 4) : Promise.reject("Broker connection adapter is null"))
                }
                _isMaintenance() {
                    return isFeatureEnabled((0, u.makeMaintananceFeatureToggleName)(this._activeBroker.metainfo().id))
                }
                _isBrokerSideMaintenance() {
                    return isFeatureEnabled((0, u.makeBrokerSideMaintananceFeatureToggleName)(this._activeBroker.metainfo().id))
                }
                _showCancelOrderDialog(e, t) {
                    return G.ConfirmOrderCancelDialog.get().open(e).then(i => i ? t(e) : Promise.resolve(!1))
                }
                _showCancelMultipleOrdersDialog(e, t, i, s) {
                    const r = i.length;
                    return G.ConfirmOrderCancelDialog.get().multiple(e, t, r).then(r => r ? s(e, t, i) : Promise.resolve(!1))
                }
                async _showCancelBracketsDialog(e, t) {
                    return K.ConfirmBracketsCancelDialog.get().open(e).then(i => i ? t(e) : Promise.resolve(!1))
                }
                _showCancelMultipleBracketsDialog(e, t) {
                    return K.ConfirmBracketsCancelDialog.get().multiple(e).then(i => i ? t(e) : Promise.resolve(!1))
                }
                async _obtainPositionClosingData(e) {
                    try {
                        this._isClosePositionDialogLoading = !0;
                        const t = (0, a.ensureDefined)(await this._activeBroker.positionById(e)),
                            {
                                supportLots: i,
                                qtyStep: r,
                                uiQtyStep: o,
                                minQty: n,
                                qtyFormatter: l,
                                priceFormatter: c
                            } = await this._obtainPositionOrTradeClosingCommonData(t),
                            d = this._activeBroker.metainfo().configFlags.supportPartialClosePosition,
                            u = X({
                                symbol: t.symbol,
                                side: 1 === t.side ? (0, s.t)("Long") : (0, s.t)("Short"),
                                qty: l.format(t.qty),
                                price: c.format(t.avgPrice),
                                closePositionCancelsOrders: this._activeBroker.config.closePositionCancelsOrders
                            });
                        return this._isClosePositionDialogLoading = !1, {
                            position: t,
                            supportLots: i,
                            qtyStep: r,
                            uiQtyStep: o,
                            minQty: n,
                            supportPartialClosePosition: d,
                            qtyFormatter: l,
                            message: u
                        }
                    } catch (e) {
                        return void(this._isClosePositionDialogLoading = !1)
                    }
                }
                async _obtainTradeClosingData(e) {
                    try {
                        this._isCloseTradeDialogLoading = !0;
                        const t = (0,
                                a.ensureDefined)(await this._activeBroker.tradeById(e)),
                            {
                                supportLots: i,
                                qtyStep: r,
                                uiQtyStep: o,
                                minQty: n,
                                qtyFormatter: l,
                                priceFormatter: c
                            } = await this._obtainPositionOrTradeClosingCommonData(t),
                            d = this._activeBroker.metainfo().configFlags.supportPartialCloseTrade,
                            u = X({
                                symbol: t.symbol,
                                side: 1 === t.side ? (0, s.t)("Long") : (0, s.t)("Short"),
                                qty: l.format(t.qty),
                                price: c.format(t.price),
                                id: e,
                                closePositionCancelsOrders: this._activeBroker.config.closePositionCancelsOrders
                            });
                        return this._isCloseTradeDialogLoading = !1, {
                            trade: t,
                            supportLots: i,
                            qtyStep: r,
                            uiQtyStep: o,
                            minQty: n,
                            supportPartialCloseTrade: d,
                            qtyFormatter: l,
                            message: u
                        }
                    } catch (e) {
                        return void(this._isCloseTradeDialogLoading = !1)
                    }
                }
                async _obtainPositionOrTradeClosingCommonData(e) {
                    const t = await this._activeBroker.symbolInfo(e.symbol);
                    return {
                        supportLots: void 0 !== t.lotSize,
                        qtyStep: t.qty.step,
                        uiQtyStep: t.qty.uiStep,
                        minQty: t.qty.min,
                        qtyFormatter: await this._activeBroker.quantityFormatter(e.symbol),
                        priceFormatter: await this._activeBroker.formatter(e.symbol, !1)
                    }
                }
                _getDurationMetaInfoList(e) {
                    var t;
                    const i = e.allowedDurations,
                        s = null !== (t = this._activeBroker.metainfo().durations) && void 0 !== t ? t : [];
                    return 0 === s.length || void 0 === i ? s : s.filter(({
                        value: e
                    }) => i.includes(e))
                }
            }
            class re {
                constructor(e, t, i, s) {
                    this._domePanel = null, this._resizerBridge = e, this._trading = i, this._qtySuggester = s, this._close = () => {
                        this.unmount(), t()
                    }
                }
                mount() {
                    return this._getDomPanel().then(e => {
                        e.setVisibility(!0)
                    })
                }
                unmount() {
                    this._getDomPanel().then(e => {
                        e.setVisibility(!1)
                    })
                }
                async _getDomPanel() {
                    if (null !== this._domePanel) return this._domePanel;
                    const {
                        DomePanel: e
                    } = await Promise.all([i.e(5514), i.e(2e3), i.e(6363), i.e(9289), i.e(3466), i.e(7836), i.e(3921), i.e(7427), i.e(8463), i.e(7552), i.e(7419), i.e(3713), i.e(2096), i.e(2385), i.e(9042), i.e(1333), i.e(3727), i.e(8068), i.e(9044), i.e(2335), i.e(9283), i.e(1590), i.e(7125), i.e(9260), i.e(2100), i.e(7638), i.e(7636)]).then(i.bind(i, 1753)), t = this._domePanel = new e(this._trading, this._resizerBridge, this._qtySuggester);
                    return t.setCloseHandler(this._close), t
                }
            }
            class oe {
                mount() {
                    return Promise.resolve()
                }
                unmount() {}
            }
            var ne = i(37076),
                ae = i(58248);
            const le = f.enabled("show_order_panel_on_start");
            class ce {
                constructor(e) {
                    this.isOpened = new(C())(!1), this.isVisible = new(C())(!1), this.activePage = new(C())(le ? ne.TradingPage.OrderPanel : ne.TradingPage.DomPanel), this.isLoading = new(C())(!1), this._pages = {}, this._width = ne.panelWidth, this.setPage = e => {
                        this.isOpened.value() && this.activePage.value() !== e && this._pages[this.activePage.value()] && this._pages[this.activePage.value()].unmount(), this.activePage.setValue(e), o.setValue(O.settingsKeys.TRADING_PANEL_ACTIVE_PAGE, e)
                    }, this.openPage = e => {
                        this.setPage(e), this.open()
                    }, this.open = () => {
                        this._pages[this.activePage.value()] && (this._togglePanel(!0), this.isOpened.setValue(!0), this._pages[this.activePage.value()].mount())
                    }, this.close = () => {
                        this.isOpened.setValue(!1), this._pages[this.activePage.value()] && this._pages[this.activePage.value()].unmount(), this._togglePanel(!1)
                    }, this._onLayoutResizeHandleMousedown = e => {
                        if (e.defaultPrevented || !e.cancelable) return;
                        e.preventDefault();
                        const t = Math.max(this._resizerBridge.width.value(), 0);
                        let i;
                        i = "touches" in e ? e.touches[0].clientX : e.clientX;
                        const s = e => {
                                let s;
                                e.preventDefault(), s = "touches" in e ? e.touches[0].clientX : e.clientX;
                                let r = t - (s - i);
                                r < ne.panelWidth ? r = ne.panelWidth : r > ne.maxPanelWidth && (r = ne.maxPanelWidth), this._requestWidth(r)
                            },
                            r = () => {
                                document.removeEventListener("mousemove", s), document.removeEventListener("touchmove", s), document.removeEventListener("mouseup", r), document.removeEventListener("touchend", r), o.setValue(O.settingsKeys.PANEL_WIDTH, this._width)
                            };
                        document.addEventListener("mousemove", s), document.addEventListener("touchmove", s, {
                            passive: !1
                        }), document.addEventListener("mouseup", r), document.addEventListener("touchend", r, {
                            passive: !1
                        })
                    }, this._resizerBridge = e, this._rootContainer = this._resizerBridge.container.value(), this.container = document.createElement("div"), this.container.classList.add(ae["trading-panel-content"], "trading-panel-content"), this._rootContainer.appendChild(this.container), this._addSpinner(), this._addResizeHandler(), this._subscribeVisibility(), this.isLoading.subscribe(this._setLoading.bind(this)), this._rootContainer.style.overflow = this.isOpened.value() ? "" : "hidden"
                }
                addPage(e, t) {
                    this._pages[e] = t
                }
                isPageOpened(e) {
                    return this.isOpened.value() && this.activePage.value() === e
                }
                _setLoading(e) {
                    e ? this._rootContainer.appendChild(this._spinnerContainer) : this._rootContainer.contains(this._spinnerContainer) && this._rootContainer.removeChild(this._spinnerContainer)
                }
                _addSpinner() {
                    this._spinnerContainer = document.createElement("div"), this._spinnerContainer.classList.add(ae["trading-panel-spinner"]), i.e(7102).then(i.bind(i, 74063)).then(e => {
                        e.render(this._spinnerContainer)
                    })
                }
                _addResizeHandler() {
                    this._handle = document.createElement("div"), this._handle.classList.add(ae["trading-panel-handle"]), this._rootContainer.appendChild(this._handle), this._handle.addEventListener("mousedown", this._onLayoutResizeHandleMousedown, {
                        passive: !1
                    }), this._handle.addEventListener("touchstart", this._onLayoutResizeHandleMousedown, {
                        passive: !1
                    }), this._width = o.getInt(O.settingsKeys.PANEL_WIDTH) || ne.panelWidth
                }
                _togglePanel(e) {
                    this._resizerBridge.negotiateWidth(e ? this._width : 0), this._resizerBridge.negotiateHeight(e ? ne.panelHeight : 0), this._rootContainer.style.overflow = e ? "" : "hidden", o.setValue(O.settingsKeys.TRADING_PANEL_OPENED, e)
                }
                _updateVisibility() {
                    this.isVisible.setValue(Boolean(this._resizerBridge.visible.value() && this._resizerBridge.availHeight.value() >= ne.panelHeight && this._resizerBridge.availWidth.value() >= ne.panelWidth))
                }
                _subscribeVisibility() {
                    this._updateVisibility(), this._resizerBridge.visible.subscribe(() => {
                        this._updateVisibility()
                    }), this._resizerBridge.availHeight.subscribe(() => {
                        this._updateVisibility()
                    }), this._resizerBridge.availWidth.subscribe(() => {
                        this._updateVisibility()
                    })
                }
                _requestWidth(e) {
                    this._canOpen(e) && this._resizerBridge.width.value() !== e && (this._resizerBridge.negotiateWidth([{
                        min: ne.panelWidth,
                        max: e
                    }]), this._width = e)
                }
                _canOpen(e) {
                    return e + 46 <= this._resizerBridge.availWidth.value()
                }
            }
            var de = i(4889),
                ue = i(76775),
                he = i(69111),
                pe = i(86782);
            const _e = (0,
                    b.getLogger)("Lib.Sound", {
                    color: "#dea433"
                }),
                ge = "notification/notification",
                me = [{
                    title: (0, s.t)("Alarm Clock"),
                    path: "alert/alarm_clock",
                    soundForAlerts: !0,
                    filePath: pe
                }];
            const be = {};

            function ye() {
                ve(me.filter(e => !!e.soundForAlerts).map(e => e.path))
            }

            function ve(e) {
                if ((0, he.isOnMobileAppPage)("any")) return;
                if (!e) return;
                if (!/iPhone|iPad|iPod|Android|BlackBerry|BB10|Silk|Mobi/i.test(window.navigator.userAgent)) return;
                if (Array.isArray(e) || (e = [e]), 0 === (e = e.filter(e => {
                        const t = fe(e);
                        return !(!t || !t.el.load || t._mobilePreloadActive) && (t._mobilePreloadActive = !0, !0)
                    })).length) return void _e.logNormal("enableForMobile no sounds passed");
                const t = () => {
                        const s = [];
                        Array.isArray(e) && e.forEach(e => {
                            const t = fe(e);
                            t.el.load();
                            const i = t.play().catch(e => {
                                if ("AbortError" !== e.name) throw _e.logError(`enableForMobile for "${t.el.src}" preload error: - ${e.message}`), e
                            });
                            t.el.pause(), s.push(i)
                        }), Promise.all(s).then(() => {
                            _e.logNormal("enableForMobile sounds initialized")
                        }), i.forEach(e => {
                            document.removeEventListener(e, t, !0)
                        })
                    },
                    i = ["click", "touchend", "keydown"];
                i.forEach(e => {
                    document.addEventListener(e, t, !0)
                })
            }
            const fe = e => {
                if (e in be) return be[e];
                _e.logNormal(`requested sound  ${e} not cached, building a new audio element`);
                const t = me.find(t => t.path === e);
                if (void 0 === t) throw new Error(`Cannot find sound "${e}"`);
                const i = new Audio(t.filePath),
                    s = {
                        el: i,
                        playing: new(C())(!1),
                        play: (t = 0) => s.playing.value() ? (_e.logNormal("sound already playing"), Promise.reject("already playing")) : (s.playing.setValue(!0), new Promise((i, r) => {
                            let o = t > 0;
                            const n = () => {
                                (function(e) {
                                    try {
                                        _e.logNormal(`"${e.el.src}" triggering html5 play method, readyState - ${e.el.readyState}; muted - ${e.el.muted}; volume - ${e.el.volume}; currentTime - ${e.el.currentTime}`);
                                        let t = e.el.play();
                                        return t || (t = Promise.resolve()), t
                                    } catch (t) {
                                        return _e.logError(`play method for "${e.el.src}" catch error - ${t.message}`), Promise.reject(t)
                                    }
                                })(s).catch(t => {
                                    _e.logNormal(`stop counting sound "${e}"; as playing due to an error: ${t.message}`), s.stop(), r(t)
                                })
                            };
                            s._onEnded = () => {
                                o ? n() : (s.stop(), i())
                            }, s.el.addEventListener("ended", s._onEnded), o && setTimeout(() => {
                                _e.logNormal(`"${e}" repeat timeout - ${t}s off`), o = !1
                            }, 1e3 * t), n()
                        })),
                        stop: () => {
                            s.el.pause(), s.playing.setValue(!1), s._onEnded && s.el.removeEventListener("ended", s._onEnded)
                        }
                    };
                be[e] = s;
                return ["canplaythrough", "error"].forEach(t => {
                    i.addEventListener(t, () => {
                        _e.logNormal(`for sound "${e}", event - ${t} is fired`)
                    }, !1)
                }), _e.logNormal("canPlayType - " + i.canPlayType("audio/mp3")), be[e]
            };
            ve(me.filter(e => !!e.common).map(e => e.path));
            var ke = i(21162);
            const we = ["qty", "stopPrice", "limitPrice", "status", "filledQty"];

            function Se(e, t) {
                return e.enabled.value() && (t.soundName = e.name), t
            }

            function Ce(e) {
                return 6 === e || 3 === e
            }
            class Pe extends x.BrokerService {
                constructor(e) {
                    super(e), this._orders = [], this._playSound = (0, de.default)(this._playSoundImpl, 50), ye()
                }
                startService() {
                    const e = (0, a.ensure)(this.activeBroker());
                    e.orders().then(e => this._orders = (0, ue.deepCopy)(e)), e.orderUpdate.subscribe(this, this._orderUpdate)
                }
                stopService() {
                    (0,
                        a.ensure)(this.activeBroker()).orderUpdate.unsubscribe(this, this._orderUpdate)
                }
                _showNotification(e, t, i) {
                    f.enabled("trading_notifications") && ("error" === i ? this.trading().showErrorNotification(e, t) : this.trading().showSuccessNotification(e, t))
                }
                _formatter(e) {
                    return (0, ke.getQuoteSessionInstance)("simple").formatter(e)
                }
                _checkOrderModified(e, t) {
                    const i = this.activeBroker(),
                        s = i && i.metainfo().customNotificationFields || [],
                        r = we.concat(s);
                    let o = !1;
                    return r.forEach(i => {
                        o || function e(t, i, s) {
                            if (void 0 === t || void 0 === i) return !1;
                            const r = s.indexOf(".");
                            if (-1 !== r) {
                                const o = s.substring(0, r);
                                return e(t[o], i[o], s.substring(r + 1))
                            }
                            return t[s] === i[s]
                        }(e, t, i) || (o = !0)
                    }), o
                }
                _generateNotificationsInfo(e, t) {
                    const i = [],
                        r = e.statusMessage ? ": " + e.statusMessage : "",
                        o = (1 === e.side ? (0, s.t)("Bought") : (0, s.t)("Sold")).toUpperCase();
                    const n = this.trading().orderExecutedSoundParams;
                    return t ? (this._checkOrderModified(e, t) && (1 === e.status ? i.push({
                        text: (0, s.t)("cancelled"),
                        notificationType: 1
                    }) : 5 === e.status ? i.push({
                        text: (0, s.t)("rejected") + r,
                        type: "error",
                        notificationType: 2
                    }) : 2 === e.status ? i.push(Se(n, {
                        side: o,
                        text: (0, s.t)("executed"),
                        notificationType: 6
                    })) : t.filledQty !== e.filledQty ? i.push(Se(n, {
                        side: o,
                        text: (0, s.t)("executed partially"),
                        notificationType: 4
                    })) : Ce(e.status) && i.push({
                        text: (0, s.t)("modified"),
                        notificationType: 5
                    })), Object.assign(t, e)) : Ce(e.status) ? (this._orders.push(e), i.push({
                        text: (0, s.t)("placed"),
                        notificationType: 0
                    }), this.trading().trackEvent("", "Order placed symbol", e.symbol)) : 1 === e.status ? i.push({
                        text: (0, s.t)("cancelled"),
                        notificationType: 1
                    }) : 5 === e.status ? (this._orders.push(e), i.push({
                        text: (0, s.t)("rejected") + r,
                        type: "error",
                        notificationType: 2
                    })) : 2 === e.status && (this._orders.push(e), i.push({
                        text: (0, s.t)("placed"),
                        notificationType: 0
                    }, Se(n, {
                        side: o,
                        text: (0, s.t)("executed"),
                        emptyOrderType: !0,
                        notificationType: 6
                    })), this.trading().trackEvent("", "Order placed symbol", e.symbol)), i
                }
                _orderUpdate(e, t) {
                    const i = (0, ue.deepCopy)(e),
                        r = this._orders.find(e => e.id === i.id);
                    if (t) return void(void 0 === r && this._orders.push(i));
                    if (r && (0, m.isFinalOrderStatus)(r.status)) return;
                    const o = this._generateNotificationsInfo(i, r);
                    0 !== o.length && this._formatter(i.symbol).then(e => {
                        const t = (0, m.sideToText)(i.side, !0),
                            r = i.qty,
                            n = void 0 !== i.filledQty && i.filledQty > 0 ? i.filledQty : void 0;
                        let a = "",
                            l = "";
                        switch (i.type) {
                            case 2:
                                a = i.avgPrice ? " (" + (0, m.orderTypeToText)(i.type) + ")" : "", l = i.avgPrice ? e.format(i.avgPrice) : (0, m.orderTypeToText)(i.type);
                                break;
                            case 4:
                                a = " " + (0, s.t)("(Limit) after {price} (Stop) crossed").format({
                                    price: e.format(i.stopPrice)
                                }), l = e.format(i.avgPrice || i.limitPrice);
                                break;
                            default:
                                a = " (" + (0, m.orderTypeToText)(i.type) + ")", l = e.format(i.avgPrice || i.limitPrice || i.stopPrice)
                        }
                        const c = void 0 !== i.message ? `${i.message.text.charAt(0).toUpperCase()}${i.message.text.substring(1)}` : "";
                        o.forEach(({
                            text: e,
                            type: o,
                            side: d,
                            emptyOrderType: u,
                            soundName: h,
                            notificationType: p
                        }) => {
                            const _ = 4 === p && void 0 !== n ? n : r,
                                g = (0, Y.splitThousands)(Math.abs(_), " ") + " " + (i.brokerSymbol || i.symbol) + " " + (0, s.t)("at") + " " + l,
                                m = `${(0,s.t)("Order")} ${i.id} ${e}`,
                                b = `${d||t} ${g} ${u?"":a}\n${c}`;
                            void 0 !== h && this._playSound(h),
                                this._showNotification(m, b, o)
                        })
                    })
                }
                _playSoundImpl(e) {
                    if (this._playingSound) {
                        if (this._playingSound === e) return;
                        ! function(e) {
                            if ((0, he.isOnMobileAppPage)("any")) return;
                            let t = [];
                            e ? t.push(fe(e)) : t = Object.values(be), t.forEach(e => {
                                e.stop()
                            })
                        }(this._playingSound)
                    }
                    this._playingSound = e,
                        function(e = ge, t) {
                            (0, he.isOnMobileAppPage)("any") ? Promise.resolve(): (_e.logNormal(`Sound play attempt for "${e}" duration-${t}s;`), fe(e).play(t))
                        }(e),
                        function(e, t) {
                            (0, he.isOnMobileAppPage)("any") || fe(e).playing.subscribe(e => {
                                e || t()
                            }, {
                                once: !0
                            })
                        }(e, () => {
                            delete this._playingSound
                        })
                }
            }
            var Be = i(71763),
                Te = i(2117);
            const Ee = (0, b.getLogger)("Chart.PointsetManager");
            let Le = 0;
            class Oe {
                constructor(e, t, i, s, r) {
                    this._currentPointsetId = null, this._onUpdate = new(B()), this._requestPoints = [], this._gateway = e, this._pointsetSuffix = t, this._isGatewayConnected = this._gateway.isConnected().spawn(), this._isGatewayConnected.subscribe(this._updateByGatewayConnection.bind(this)), this._addPoints(i, s, r)
                }
                onUpdate() {
                    return this._onUpdate
                }
                destroy() {
                    this._isGatewayConnected.value() && null !== this._currentPointsetId && this._gateway.removePointset(this._currentPointsetId), this._requestPoints = [], this._currentPointsetId = null, this._isGatewayConnected.destroy()
                }
                _updateByGatewayConnection(e) {
                    e || (this._currentPointsetId = null, this._requestPoints = [])
                }
                _addPoints(e, t, i) {
                    var s, r;
                    this._isGatewayConnected.value() && ((0, a.assert)(e.length > 0, "Can't possible create point set for empty array of time points"), this._requestPoints = e.map(e => [e.time_t, e.offset]), this._currentPointsetId = (s = this._pointsetSuffix, r = ++Le, `pointset_${s}_${r}`), this._gateway.createPointset(this._currentPointsetId, "turnaround", t, (0, Te.getServerInterval)(i), this._requestPoints, this._onMessage.bind(this)))
                }
                _onMessage(e) {
                    switch (e.method) {
                        case "pointset_error":
                            Ee.logNormal(`Pointset error with id ${e.params[0]} turnaround ${e.params[1]}`);
                            break;
                        case "data_update":
                            {
                                const t = [];
                                for (const i of e.params.plots) t.push({
                                    time_t: this._requestPoints[i.index][0],
                                    index: i.value[0],
                                    barTime: i.value[1]
                                });this._onUpdate.fire(t);
                                break
                            }
                    }
                }
            }
            var De = i(76337);

            function Ie(e) {
                const t = e.mainSeries().data().first();
                return null === t ? null : t.value[0]
            }
            async function Ne(e, t, s) {
                const [r, o, n] = await Promise.all([i.e(2650).then(i.bind(i, 80160)), i.e(2650).then(i.bind(i, 30050)), i.e(2650).then(i.bind(i, 26945))]);
                e.addCustomSource("executions", (e, i) => {
                    const a = i.mainSeries(),
                        l = a.dataEvents(),
                        c = (0, De.createPrimitivePropertyFromGetterAndSubscription)(i.isInReplay.bind(i), i.onInReplayStateChanged()),
                        d = (0, De.createPrimitivePropertyFromGetterAndSubscription)(() => a.isConvertedToOtherCurrency() || a.isConvertedToOtherUnit(), a.symbolResolved()),
                        u = {
                            arrowVisibility: (0, De.combineProperty)((e, t, i) => i && !t, c, d, i.properties().childs().tradingProperties.childs().showExecutions),
                            labelVisibility: i.properties().childs().tradingProperties.childs().showExecutionsLabels
                        },
                        h = function(e, t, i) {
                            return s => {
                                const r = i.seriesSource().symbolInstanceId(),
                                    o = i.interval();
                                return null === r ? null : new Oe(e, t, s, r, o)
                            }
                        }(i.chartApi(), "executions", a),
                        p = (0,
                            De.createWVFromGetterAndSubscription)(Ie.bind(null, i), l.barReceived()),
                        _ = new r.ExecutionsService(t, l, function(e) {
                            return () => {
                                const t = e.symbolInfo();
                                return null !== t ? t.pro_name || t.full_name : e.proSymbol()
                            }
                        }(a)),
                        g = new o.ExecutionsPointsManager(_, h, p);
                    return new n.ExecutionsSource(e, i, t, u, s, g)
                })
            }

            function Ae(e) {
                return Boolean(e.supportTrailingStop && e.supportAddBracketsToExistingOrder && e.supportModifyTrailingStop && !1)
            }
            const Me = (0, b.getLogger)("Trading.Positions");

            function Ve(e) {
                const t = null === e ? 0 : Math.round(100 * e) / 100;
                return t > 0 ? "positive" : t < 0 ? "negative" : "neutral"
            }
            class xe extends x.BrokerService {
                constructor() {
                    super(...arguments), this._positions = new Map, this._positionUpdate = new(B()), this._positionsRemoved = new(B()), this._displayMode = 1, this._updatePositionPLHandler = this._updatePositionPL.bind(this)
                }
                destroy() {
                    this.stopService()
                }
                positions() {
                    return Array.from(this._positions.values())
                }
                find(e) {
                    return this._positions.get(e) || null
                }
                async realIdFromBroker(e) {
                    const t = (0, a.ensureNotNull)(this.activeBroker());
                    if (1 === this._displayMode) {
                        const i = await t.positionById(e);
                        if (void 0 !== i) return i.id
                    } else {
                        const i = await t.tradeById(e);
                        if (void 0 !== i) return i.id
                    }
                    return null
                }
                positionUpdate() {
                    return this._positionUpdate
                }
                positionsRemoved() {
                    return this._positionsRemoved
                }
                isDisplayModeTrades() {
                    return 0 === this._displayMode
                }
                async getCurrency(e) {
                    return await (0, a.ensureNotNull)(this.activeBroker()).getPositionCurrency(e) || ""
                }
                stopService() {
                    this._clearPositions();
                    const e = (0, a.ensureNotNull)(this.activeBroker());
                    this.isDisplayModeTrades() ? e.tradeUpdate.unsubscribeAll(this) : e.positionUpdate.unsubscribeAll(this)
                }
                startService() {
                    this._clearPositions(), this._displayMode = function(e) {
                        if (null === e) return 1;
                        const t = e.metainfo().configFlags;
                        return t.supportTrades ? t.supportPositionBrackets ? 1 : t.supportCloseTrade ? 0 : 1 : 1
                    }(this.activeBroker()), this._requestPositions()
                }
                _clearPositions() {
                    const e = (0, a.ensureNotNull)(this.activeBroker()),
                        t = Array.from(this._positions.keys());
                    for (const i of t) this.isDisplayModeTrades() ? e.unsubscribeTradePL(i, this._updatePositionPLHandler) : e.unsubscribePL(i, this._updatePositionPLHandler);
                    this._positions.clear(), this._positionsRemoved.fire(t)
                }
                async _requestPositions() {
                    const e = this.activeBroker();
                    if (!e) return;
                    const t = this.isDisplayModeTrades(),
                        i = await (t ? e.trades() : e.positions());
                    for (const e of i) this._addPosition(e);
                    t ? e.tradeUpdate.subscribe(this, this._addPosition) : e.positionUpdate.subscribe(this, this._addPosition)
                }
                _addPosition(e) {
                    const t = e.id,
                        i = this._positions.has(t),
                        s = (0, a.ensureNotNull)(this.activeBroker());
                    Me.logDebug("Update position. Symbol:" + e.symbol + " , qty:" + e.qty);
                    const r = this.isDisplayModeTrades();
                    if (!e.qty) return void(i && (r ? s.unsubscribeTradePL(t, this._updatePositionPLHandler) : s.unsubscribePL(t, this._updatePositionPLHandler), this._positions.delete(t), this._positionsRemoved.fire([t])));
                    const o = this._getPositionData(e);
                    this._positions.set(t, o), this._positionUpdate.fire(o), i || (r ? s.subscribeTradePL(t, this._updatePositionPLHandler) : s.subscribePL(t, this._updatePositionPLHandler))
                }
                _updatePositionPL(e, t) {
                    const i = (0,
                        a.ensureDefined)(this._positions.get(e));
                    i.pl = (0, g.isNumber)(t) ? t : null, i.profitState = Ve(t), this._positionUpdate.fire(i)
                }
                _getPositionData(e) {
                    const t = (0, a.ensureNotNull)(this.activeBroker()).metainfo().configFlags,
                        i = this._positions.get(e.id),
                        s = this.isDisplayModeTrades();
                    let r = "neutral";
                    const o = e.pl || i && i.pl || null;
                    null !== o && (r = Ve(o));
                    const n = Boolean(s ? t.supportTradeBrackets : t.supportPositionBrackets);
                    return { ...void 0 !== i ? i : {},
                        ...e,
                        pl: o,
                        plBasedOnLast: t.calculatePLUsingLast || !1,
                        price: Math.abs(s ? e.price : e.avgPrice),
                        qtyBySide: Math.abs(e.qty) * (1 === e.side ? 1 : -1),
                        profitState: r,
                        supportClose: Boolean(s ? t.supportCloseTrade && e.canBeClosed : t.supportClosePosition),
                        supportReverse: Boolean(!s && t.supportReversePosition),
                        supportBrackets: n,
                        supportOnlyPairBrackets: Boolean(t.supportOnlyPairPositionBrackets),
                        supportTrailingStop: n && Ae(t)
                    }
                }
            }
            const Fe = (0, b.getLogger)("Trading.OrderSource");

            function Re(e) {
                return 1 === e.type ? (0, a.ensureDefined)(e.limitPrice) : (0, a.ensureDefined)(e.stopPrice)
            }
            class qe extends x.BrokerService {
                constructor() {
                    super(...arguments), this._activeOrders = new Map, this._activeOrderUpdate = new(B()), this._activeOrdersRemoved = new(B()), this._ordersRejected = new(B())
                }
                destroy() {
                    this.stopService()
                }
                orders() {
                    return (0, a.ensureNotNull)(this.activeBroker()).orders()
                }
                find(e) {
                    return this._activeOrders.get(e) || null
                }
                activeOrders() {
                    return Array.from(this._activeOrders.values())
                }
                activeOrdersUpdated() {
                    return this._activeOrderUpdate
                }
                activeOrdersRemoved() {
                    return this._activeOrdersRemoved
                }
                orderRejected() {
                    return this._ordersRejected
                }
                stopService() {
                    this._clearOrders();
                    (0, a.ensureNotNull)(this.activeBroker()).orderUpdate.unsubscribeAll(this)
                }
                startService() {
                    this._clearOrders(), this._requestOrders()
                }
                _clearOrders() {
                    const e = Array.from(this._activeOrders.keys());
                    this._activeOrders.clear(), this._activeOrdersRemoved.fire(e)
                }
                async _requestOrders() {
                    const e = this.activeBroker();
                    if (!e) return;
                    const t = await e.orders();
                    for (const e of t) this._addActiveOrder(e);
                    e.orderUpdate.unsubscribeAll(this), e.orderUpdate.subscribe(this, this._addActiveOrder)
                }
                _addActiveOrder(e) {
                    if (2 === e.type) return;
                    const t = e.id,
                        i = this._activeOrders.has(t);
                    if (6 !== e.status && 3 !== e.status) return void(i ? (this._activeOrders.delete(t), this._activeOrdersRemoved.fire([t])) : 5 === e.status && this._ordersRejected.fire(Re(e)));
                    const s = this._getOrderData(e);
                    this._activeOrders.set(t, s), this._activeOrderUpdate.fire(s)
                }
                _getOrderData(e) {
                    const t = (0, a.ensureNotNull)(this.activeBroker()).metainfo().configFlags,
                        i = Re(e);
                    (0, g.isNumber)(i) || Fe.logError("order price is not defined");
                    const s = Boolean(t.supportOrderBrackets && t.supportModifyBrackets && t.supportAddBracketsToExistingOrder);
                    return (0, g.merge)((0, g.clone)(e), {
                        price: i,
                        considerFilledQty: !0,
                        supportModify: (0, u.isModifyOrderSupported)(e, t),
                        supportMove: (0, u.isMoveOrderSupported)(e, t),
                        supportCancel: !0,
                        supportBrackets: s,
                        supportModifyOrderPrice: Boolean(t.supportModifyOrderPrice),
                        supportTrailingStop: s && Ae(t)
                    })
                }
            }
            var Ue = i(93751),
                We = i(83450),
                Qe = i(1397);
            const je = (0, s.t)("A broker is not connected"),
                He = (0, s.t)("This symbol can't be traded through this broker"),
                ze = (0, s.t)("No bids"),
                $e = (0,
                    s.t)("No asks"),
                Ge = (0, s.t)("Buy Market"),
                Ke = (0, s.t)("Sell Market"),
                Ze = (0, s.t)("Spread"),
                Je = (0, s.t)("Amount"),
                Ye = (0, s.t)("Quantity"),
                Xe = f.enabled("broker_button");
            class et {
                constructor({
                    dataEvents: e,
                    getSymbolName: t,
                    qtySuggester: i,
                    tradingCommands: s,
                    settings: r,
                    isInReplay: o
                }) {
                    this.ask = new(C())(null), this.askTooltip = new(C())(Ge), this.bid = new(C())(null), this.bidTooltip = new(C())(Ke), this.spread = new(C())(null), this.spreadTooltip = new(C())(Ze), this.qty = new(C())(null), this.qtyTooltip = new(C())(""), this.brokerIconVisible = new(C())(!1), this.brokerIconLoading = new(C())(!1), this.brokerIconUrl = new(C())(null), this.isQtyVisible = new(C())(!1), this.hasAskBidAdditionalPrecision = new(C())(!1), this.canTrade = new(C())(!0), this._globalVisibility = null, this._isSymbolTradableResult = new We.WatchedObject(null), this._formatter = null, this._spreadFormatter = null, this._symbol = null, this.setQty = e => {
                        this.qty.setValue(String(e))
                    }, this._onSuggestedQtyChange = e => {
                        this._lastSuggestedQty = e, this.setQty(e)
                    }, this._dataEvents = e, this._getSymbolName = t, this._qtySuggester = i, this._realtimeProvider = s.realtimeProvider, this._onNeedSelectBroker = s.onNeedSelectBroker, this._toggleTradingWidget = s.toggleTradingWidget, this._toggleTradingPanelPopup = s.toggleTradingPanelPopup, this._brokerCommandsUI = s.brokerCommandsUI, this._updateRealtimeDataHandler = this._updateRealtimeData.bind(this), this._isBrokerConnected = (0, De.createWVFromGetterAndSubscription)(() => null !== this._realtimeProvider.activeBroker(), this._realtimeProvider.onStatusChanged), this._isBrokerConnected.subscribe(this._updateIsSymbolTraded.bind(this), {
                        callWithLast: !0
                    }), this._isBrokerConnected.subscribe(this._updateQtyTooltip.bind(this), {
                        callWithLast: !0
                    }), this._isBrokerConnected.subscribe(this._updateBrokerIcon.bind(this)), this._isBrokerConnected.subscribe(this._resubscribeQtySuggester.bind(this)), this._isBrokerConnecting = (0, De.createWVFromGetterAndSubscription)(() => 2 === s.brokerConnectionStatus(), s.onBrokerConnectionStatusChange), this._isBrokerConnecting.subscribe(this._updateBrokerIcon.bind(this)), this.visible = new(C())(!1), this.visible.subscribe(this._toggleState.bind(this), {
                        callWithLast: !0
                    }), this._showSellBuyButtons = r.showSellBuyButtons.spawn(), this._isInReplay = o.spawn(), this._showSellBuyButtons.subscribe(this._updateVisibility.bind(this), {
                        callWithLast: !0
                    }), this._isInReplay.subscribe(this._updateVisibility.bind(this), {
                        callWithLast: !0
                    }), this._isInstantMode = r.noConfirmEnabled.spawn(), this._themeName = r.themeName.spawn(), this._themeName.subscribe(this._updateBrokerIcon.bind(this), {
                        callWithLast: !0
                    }), this._tradePossibilityComputedWV = (0, w.combine)(() => ({}), this._isBrokerConnected, this._isSymbolTradableResult, this.ask, this.bid), this._tradePossibilityComputedWV.subscribe(this._updateTradePossibilityAndTooltip.bind(this), {
                        callWithLast: !0
                    }), this._isQtyVisibleComputedWV = (0, w.combine)(() => ({}), this.canTrade, this._isInstantMode), this._isQtyVisibleComputedWV.subscribe(this._updateIsQtyVisible.bind(this), {
                        callWithLast: !0
                    })
                }
                destroy() {
                    var e;
                    this._stop(), this._isBrokerConnected.destroy(), this._showSellBuyButtons.destroy(), this._isInReplay.destroy(),
                        null === (e = this._globalVisibility) || void 0 === e || e.destroy(), this._isInstantMode.destroy(), this._tradePossibilityComputedWV.destroy(), this._isQtyVisibleComputedWV.destroy(), this._themeName.destroy()
                }
                setGlobalVisibility(e) {
                    (0, a.assert)(null === this._globalVisibility, "GlobalVisibility can be set only once"), this._globalVisibility = e.spawn(), this._globalVisibility.subscribe(this._updateVisibility.bind(this), {
                        callWithLast: !0
                    })
                }
                async tryToPlaceSellOrder() {
                    await this._tryToPlaceOrder(parseFloat((0, a.ensureNotNull)(this.bid.value())), -1)
                }
                async tryToPlaceBuyOrder() {
                    await this._tryToPlaceOrder(parseFloat((0, a.ensureNotNull)(this.ask.value())), 1)
                }
                async getQtyInfo() {
                    return null !== this._symbol && this.canTrade.value() ? (await this._realtimeProvider.symbolInfo(this._symbol)).qty : null
                }
                applyQty() {
                    if (null === this._symbol || !this.canTrade.value()) return;
                    const e = this.qty.value(),
                        t = null !== e ? Number(e) : null;
                    null !== t && this._qtySuggester.setQty(this._symbol, t), void 0 !== this._lastSuggestedQty && t !== this._lastSuggestedQty && this.qty.setValue(String(this._lastSuggestedQty))
                }
                canShowMobileTrading() {
                    var e;
                    return !(null === (e = window.TradingView.bottomWidgetBar) || void 0 === e ? void 0 : e.isVisible().value())
                }
                _updateVisibility() {
                    const e = (null === this._globalVisibility || this._globalVisibility.value()) && this._showSellBuyButtons.value() && !this._isInReplay.value();
                    this.visible.setValue(e)
                }
                async _tryToPlaceOrder(e, t) {
                    if (null === this._realtimeProvider.activeBroker()) return this.canShowMobileTrading() ? this._toggleTradingPanelPopup() : await this._toggleTradingWidget(), void this._onNeedSelectBroker.fire();
                    const i = Number(this.qty.value()) || 1,
                        s = this._isMarketOrderSupported() ? 2 : 1,
                        r = {
                            symbol: (0, a.ensureNotNull)(this._symbol),
                            qty: i,
                            side: t,
                            type: s,
                            seenPrice: null
                        };
                    1 === s && (r.limitPrice = e), await (0, a.ensureNotNull)(this._brokerCommandsUI()).placeOrder(r, !0)
                }
                _toggleState(e) {
                    e ? this._start() : this._stop()
                }
                _start() {
                    this._dataEvents.symbolResolved().subscribe(this, this._createTradedSymbol), this._dataEvents.symbolError().subscribe(this, this._createTradedSymbol), this._createTradedSymbol()
                }
                _stop() {
                    this._clearTradedSymbol(), this._symbol = null, this._dataEvents.symbolResolved().unsubscribeAll(this), this._dataEvents.symbolError().unsubscribeAll(this)
                }
                _createTradedSymbol() {
                    const e = this._getSymbolName();
                    e !== this._symbol && (this._clearTradedSymbol(), e.length > 0 && this._initTradedSymbol(e))
                }
                _initTradedSymbol(e) {
                    this._symbol = e, this._updateIsSymbolTraded(), this._realtimeProvider.subscribeRealtime(this._symbol, this._updateRealtimeDataHandler), this._resubscribeQtySuggester()
                }
                _clearTradedSymbol() {
                    var e;
                    this.ask.setValue(null), this.bid.setValue(null), this.spread.setValue(null), this.qty.setValue(null), null !== this._symbol && (this._realtimeProvider.unsubscribeRealtime(this._symbol, this._updateRealtimeDataHandler), null === (e = this._qtySuggesterSubscription) || void 0 === e || e.unsubscribe(), this._symbol = null, this._updateIsSymbolTraded())
                }
                async _resubscribeQtySuggester() {
                    var e;
                    const t = this._symbol;
                    if (null === t) return;
                    null === (e = this._qtySuggesterSubscription) || void 0 === e || e.unsubscribe();
                    const i = this._suggestedQtyPromise = this._qtySuggester.getQty(t),
                        s = await i;
                    i === this._suggestedQtyPromise && t === this._symbol && (this._lastSuggestedQty = s, this.setQty(s), this._qtySuggesterSubscription = this._qtySuggester.suggestedQtyChanged(t).subscribe(this._onSuggestedQtyChange))
                }
                _isMarketOrderSupported() {
                    const e = this._realtimeProvider.activeBroker();
                    return null === e || Boolean(e.metainfo().configFlags.supportMarketOrders)
                }
                _updateTradePossibilityAndTooltip() {
                    this._updateCanTrade(), this._updateSellBuyTooltip()
                }
                _updateCanTrade() {
                    const e = this._isSymbolTradableResult.value(),
                        t = this._isBrokerConnected.value() && null !== e && e.tradable;
                    this.canTrade.setValue(t)
                }
                _updateSellBuyTooltip() {
                    var e, t;
                    const i = this._getNonTradedTooltip();
                    this.askTooltip.setValue(null !== (e = null != i ? i : this._getAskTooltip()) && void 0 !== e ? e : Ge), this.bidTooltip.setValue(null !== (t = null != i ? i : this._getBidTooltip()) && void 0 !== t ? t : Ke)
                }
                _getNonTradedTooltip() {
                    const e = this._isSymbolTradableResult.value();
                    if (null !== e && !e.tradable) return void 0 !== e.solutions ? "" : void 0 !== e.shortReason && "" !== e.shortReason ? e.shortReason : this._isBrokerConnected.value() ? He : je
                }
                _getAskTooltip() {
                    return null === this.ask.value() ? $e : void 0
                }
                _getBidTooltip() {
                    return null === this.bid.value() ? ze : void 0
                }
                _updateRealtimeData(e, t, i) {
                    this._formatter = i.formatter, this._spreadFormatter = i.spreadFormatter;
                    const s = t.ask,
                        r = t.bid,
                        o = (0, Ue.isNumber)(s) ? this._formatter.format(s) : null,
                        n = (0, Ue.isNumber)(r) ? this._formatter.format(r) : null;
                    this.ask.setValue(o), this.bid.setValue(n);
                    const a = t.spread || (0, Ue.isNumber)(s) && (0, Ue.isNumber)(r) && s - r || 0,
                        l = (0, Ue.isNumber)(t.spread) ? this._spreadFormatter : this._formatter;
                    this.spread.setValue(l.format(a));
                    let c = !1;
                    (0, Qe.isFormatterHasForexAdditionalPrecision)(this._formatter) && (c = this._formatter.hasForexAdditionalPrecision()), this.hasAskBidAdditionalPrecision.setValue(c)
                }
                async _updateIsSymbolTraded() {
                    if (null === this._symbol) return void this._isSymbolTradableResult.setValue(null);
                    const e = await this._realtimeProvider.isTradable(this._symbol);
                    this._isSymbolTradableResult.setValue((0, g.clone)(e))
                }
                _updateIsQtyVisible() {
                    const e = this._isInstantMode.value() && this.canTrade.value();
                    this.isQtyVisible.setValue(e)
                }
                _updateQtyTooltip() {
                    this.qtyTooltip.setValue(this._getQtyTooltip())
                }
                _getQtyTooltip() {
                    const e = this._realtimeProvider.activeBroker();
                    return null !== e && e.metainfo().configFlags.showQuantityInsteadOfAmount ? Ye : Je
                }
                _updateBrokerIcon() {
                    if (!Xe) return;
                    let e;
                    const t = this._realtimeProvider.activeBroker();
                    if (null !== t) {
                        const i = t.metainfo();
                        e = "dark" === this._themeName.value() && i.logoMiniBlackUrl ? i.logoMiniBlackUrl : i.logoMiniUrl
                    }
                    this.brokerIconVisible.setValue(this._isBrokerConnected.value()), this.brokerIconLoading.setValue(this._isBrokerConnecting.value()), this.brokerIconUrl.setValue(e || null)
                }
            }
            var tt = i(59255),
                it = i(43370),
                st = i(72304),
                rt = i(33480),
                ot = i(6313),
                nt = i(14660);
            class at extends ot.LoaderBaseRenderer {
                _renderLoading(e) {
                    super._renderLoading(e), this._loadingEl.innerHTML = `\n\t\t\t<span class="${nt.loaderCircle}"></span>\n\t\t`, this._loadingEl.classList.add(nt.loader)
                }
            }
            var lt = i(37969),
                ct = i(33080);
            var dt = i(90787),
                ut = i(69234),
                ht = i(6968),
                pt = i(88603),
                _t = i(72036);
            const gt = parseInt(pt["css-value-padding"]);

            function mt(e, t, i, s) {
                let r = e.querySelector("." + s);
                if (!i) return null !== r && r.remove(), void(0, dt.updateTextNode)(e, t);
                null === r && (r = document.createElement("span"), r.classList.add(s), e.appendChild(r)), (0, dt.updateTextNode)((0, a.ensureNotNull)(r), t.slice(-1)), (0, dt.updateTextNode)(e, t.slice(0, -1))
            }
            class bt {
                constructor({
                    model: e,
                    highButtonsMode: t,
                    trackEvent: i,
                    toggleMinimizeBottomWidgetBar: s
                }) {
                    this.element = document.createElement("div"), this._sellButtonEl = document.createElement("div"), this._sellButtonTextEl = document.createElement("span"), this._buyButtonEl = document.createElement("div"), this._buyButtonTextEl = document.createElement("span"), this._spreadQtyWrapper = document.createElement("div"), this._spreadEl = document.createElement("div"), this._qtyEl = document.createElement("div"), this._qtyTextEl = document.createElement("span"), this._brokerButtonEl = document.createElement("div"), this._brokerIconWrapEl = document.createElement("div"), this._isCalcOpened = !1, this._calcContainer = document.createElement("div"), this._sellLoader = new rt.LoaderPointsRenderer(this._sellButtonEl, {
                            className: ut.loader
                        }), this._buyLoader = new rt.LoaderPointsRenderer(this._buyButtonEl, {
                            className: ut.loader
                        }), this._brokerLoader = new at(this._brokerButtonEl, {
                            className: ut.circleLoader
                        }), this._windowResizeHandlerThrottle = (0, it.default)(this._windowResizeHandler.bind(this), 100), this._isHiddenByViewport = !1, this._mode = 2, this._height = new(C())(0), this._resizeObserver = null, this._cachedBreakPoints = {}, this._parentWidth = 0, this._getCurrentQty = () => {
                            const e = this._qty.value();
                            return null !== e ? Number(e) : null
                        }, this._model = e, this._toggleMinimizeBottomWidgetBar = s, this._ask = this._model.ask.spawn(), this._ask.subscribe(this._updateBuyButton.bind(this)), this._bid = this._model.bid.spawn(), this._bid.subscribe(this._updateSellButton.bind(this)), this._spread = this._model.spread.spawn(), this._spread.subscribe(this._updateSpread.bind(this)), this._qty = this._model.qty.spawn(), this._qty.subscribe(this._updateQty.bind(this)), this._brokerIconVisible = this._model.brokerIconVisible.spawn(), this._brokerIconVisible.subscribe(this._updateBrokerIconImage.bind(this)), this._brokerIconLoading = this._model.brokerIconLoading.spawn(), this._brokerIconLoading.subscribe(this._updateBrokerIconImage.bind(this)), this._brokerIconUrl = this._model.brokerIconUrl.spawn(), this._brokerIconUrl.subscribe(this._updateBrokerIconImage.bind(this), {
                            callWithLast: !0
                        }), this._trackEvent = i, this._render(), this._askTooltip = this._model.askTooltip.spawn(), this._askTooltip.subscribe(this._updateButtonTooltip.bind(this, this._buyButtonEl), {
                            callWithLast: !0
                        }), this._bidTooltip = this._model.bidTooltip.spawn(), this._bidTooltip.subscribe(this._updateButtonTooltip.bind(this, this._sellButtonEl), {
                            callWithLast: !0
                        }), this._spreadTooltip = this._model.spreadTooltip.spawn(), this._spreadTooltip.subscribe(this._updateButtonTooltip.bind(this, this._spreadEl), {
                            callWithLast: !0
                        }), this._qtyTooltip = this._model.qtyTooltip.spawn(),
                        this._qtyTooltip.subscribe(this._updateButtonTooltip.bind(this, this._qtyEl), {
                            callWithLast: !0
                        }), this._isVisible = this._model.visible.spawn(), this._isVisible.subscribe(this._updateVisibility.bind(this), {
                            callWithLast: !0
                        }), this._isQtyVisible = this._model.isQtyVisible.spawn(), this._isQtyVisible.subscribe(this._updateQtyVisibility.bind(this), {
                            callWithLast: !0
                        }), this._isLastDigitSup = this._model.hasAskBidAdditionalPrecision.spawn(), this._isLastDigitSup.subscribe(this._updateLastDigitSup.bind(this)), this._highButtonsMode = t.spawn(), this._highButtonsMode.subscribe(this._updateHighButtonsMode.bind(this), {
                            callWithLast: !0
                        }), this._canTrade = this._model.canTrade.spawn(), this._canTrade.subscribe(this._updateBgButtonsMode.bind(this), {
                            callWithLast: !0
                        }), this._sellButtonHandler = this._onSellButton.bind(this), this._buyButtonHandler = this._onBuyButton.bind(this), this._qtyHandler = this._toggleCalcVisibility.bind(this), this._brokerButtonHandler = this._onBrokerButton.bind(this), this._sellButtonEl.addEventListener("click", this._sellButtonHandler), this._buyButtonEl.addEventListener("click", this._buyButtonHandler), this._qtyEl.addEventListener("click", this._qtyHandler), this._brokerButtonEl.addEventListener("click", this._brokerButtonHandler), window.addEventListener("resize", this._windowResizeHandlerThrottle), this._windowResizeHandler()
                }
                destroy() {
                    var e;
                    this._ask.destroy(), this._askTooltip.destroy(), this._bid.destroy(), this._bidTooltip.destroy(), this._spread.destroy(), this._spreadTooltip.destroy(), this._qty.destroy(), this._qtyTooltip.destroy(), this._isVisible.destroy(), this._isQtyVisible.destroy(), this._isLastDigitSup.destroy(), this._highButtonsMode.destroy(), this._canTrade.destroy(), this._brokerIconUrl.destroy(), this._sellButtonEl.removeEventListener("click", this._sellButtonHandler), this._buyButtonEl.removeEventListener("click", this._buyButtonHandler), this._qtyEl.removeEventListener("click", this._qtyHandler), this._brokerButtonEl.removeEventListener("click", this._brokerButtonHandler), null === (e = this._resizeObserver) || void 0 === e || e.disconnect(), this._resizeObserver = null, this.element.remove(), delete this.element, window.removeEventListener("resize", this._windowResizeHandlerThrottle)
                }
                updateModeByWidth(e) {
                    const t = this._cachedBreakPoints[0],
                        i = this._cachedBreakPoints[1];
                    this._mode = void 0 !== t && e < t ? 0 : void 0 !== i && e < i ? 1 : 2, this._parentWidth = e, this.element.classList.toggle(ut.column, 1 === this._mode), this._updateVisibility()
                }
                height() {
                    return this._height
                }
                renderTo(e, t) {
                    void 0 !== t ? e.insertBefore(this.element, t) : e.appendChild(this.element), null === this._resizeObserver && (this._resizeObserver = new tt.default(this._updateBreakPointsAndSize.bind(this))), this._resizeObserver.unobserve(this.element), this._resizeObserver.observe(this.element)
                }
                isHiddenByViewport() {
                    return this._isHiddenByViewport
                }
                _render() {
                    const e = this._bid.value() || "...";
                    this._sellButtonTextEl.appendChild(document.createTextNode(e)), this._sellButtonTextEl.classList.add(ut.buttonText), this._sellButtonEl.append(this._sellButtonTextEl), this._sellButtonEl.classList.add("apply-common-tooltip", ut.button, ut.sellButton);
                    const t = this._spread.value() || "";
                    this._spreadEl.appendChild(document.createTextNode(String(t))), this._spreadEl.classList.add("apply-common-tooltip", ut.spread);
                    const i = this._qty.value() || "";
                    this._qtyTextEl.appendChild(document.createTextNode(i)), this._qtyEl.append(this._qtyTextEl), this._qtyEl.setAttribute("data-name", "qtyEl"), this._qtyEl.classList.add("apply-common-tooltip", ut.button, ut.qty), this._spreadQtyWrapper.classList.add(ut.spreadQtyWrapper), this._spreadQtyWrapper.appendChild(this._spreadEl), this._spreadQtyWrapper.appendChild(this._qtyEl);
                    const s = this._ask.value() || "...";
                    this._buyButtonTextEl.appendChild(document.createTextNode(String(s))), this._buyButtonTextEl.classList.add(ut.buttonText), this._buyButtonEl.append(this._buyButtonTextEl), this._buyButtonEl.classList.add("apply-common-tooltip", ut.button, ut.buyButton), this._brokerButtonEl.appendChild(this._brokerIconWrapEl), this._brokerIconWrapEl.classList.add(ut.brokerButtonIconWrap), this._brokerButtonEl.classList.add(ut.brokerButton), this.element.appendChild(this._sellButtonEl), this.element.appendChild(this._spreadQtyWrapper), this.element.appendChild(this._buyButtonEl), this.element.appendChild(this._brokerButtonEl), this.element.classList.add(ut.wrapper), this.element.classList.toggle(ut.touchMode, lt.trackingModeIsAvailable), this.element.classList.toggle(ut.notAvailableOnMobile, !1)
                }
                _updateBreakPointsAndSize(e) {
                    const t = e[0],
                        i = 2 * gt;
                    2 === this._mode && (this._cachedBreakPoints[1] = Math.round(t.contentRect.width) + i), 1 === this._mode && (this._cachedBreakPoints[0] = Math.round(t.contentRect.width) + i), this.updateModeByWidth(this._parentWidth);
                    const s = t.contentRect.height > 0 ? Math.round(t.contentRect.height) + i : 0;
                    this._height.setValue(s)
                }
                _updateBrokerIconImage() {
                    const e = this._brokerIconLoading.value(),
                        t = !this._brokerIconVisible.value() && !e;
                    if (this._brokerButtonEl.classList.toggle(ht.blockHidden, t), t) return;
                    if (this._toggleLoaderVisibility(this._brokerButtonEl, this._brokerLoader, e), e) return void(this._brokerIconWrapEl.innerHTML = "");
                    const i = this._brokerIconUrl.value(),
                        s = null === i;
                    this._brokerIconWrapEl.innerHTML = s ? _t : `<image src="${i}" alt="Account Manager" />`, this._brokerButtonEl.classList.toggle(ut.brokerButtonDefault, s)
                }
                async _onSellButton() {
                    if (null === this._bid.value()) return;
                    const e = this._highButtonsMode.value();
                    this._trackEvent("Sell/Buy Buttons", "Sell", e ? "Instant" : "Not Instant"), e && this._canTrade.value() && this._toggleLoaderVisibility(this._sellButtonEl, this._sellLoader, !0), await this._model.tryToPlaceSellOrder(), e && this._canTrade.value() && setTimeout(() => this._toggleLoaderVisibility(this._sellButtonEl, this._sellLoader, !1), 300)
                }
                async _onBuyButton() {
                    if (null === this._ask.value()) return;
                    const e = this._highButtonsMode.value();
                    this._trackEvent("Sell/Buy Buttons", "Buy", e ? "Instant" : "Not Instant"), e && this._canTrade.value() && this._toggleLoaderVisibility(this._buyButtonEl, this._buyLoader, !0), await this._model.tryToPlaceBuyOrder(), e && this._canTrade.value() && setTimeout(() => this._toggleLoaderVisibility(this._buyButtonEl, this._buyLoader, !1), 300)
                }
                _onBrokerButton() {
                    this._model.canShowMobileTrading() ? async function() {
                        (await (0, ct.waitTradingService)()).tradingPanelPopup.show()
                    }() : this._toggleMinimizeBottomWidgetBar()
                }
                _toggleLoaderVisibility(e, t, i) {
                    e.classList.toggle(ut.loading, i), t.toggleVisibility(i)
                }
                _updateBuyButton(e) {
                    const t = null !== e && this._isLastDigitSup.value();
                    mt(this._buyButtonTextEl, "" + (e || "..."), t, ut.lastCharSup)
                }
                _updateSellButton(e) {
                    const t = null !== e && this._isLastDigitSup.value();
                    mt(this._sellButtonTextEl, "" + (e || "..."), t, ut.lastCharSup)
                }
                _updateSpread(e) {
                    const t = "" + (e || "");
                    (0, dt.updateTextNode)(this._spreadEl, t), this._updateVisibilityForSpreadQtyWrapper()
                }
                _updateQty(e) {
                    let t = "" + (e || "");
                    !this._isCalcOpened && t.length > 0 && (t = (0, k.abbreviatedNumber)(Number(t))), (0, dt.updateTextNode)(this._qtyTextEl, t)
                }
                _updateHighButtonsMode(e) {
                    this.element.classList.toggle(ut.highButtons, e)
                }
                _updateBgButtonsMode(e) {
                    this.element.classList.toggle(ut.withoutBg, !e)
                }
                _updateVisibilityForSpreadQtyWrapper() {
                    const e = !this._isQtyVisible.value() && null === this._spread.value();
                    this._spreadQtyWrapper.classList.toggle(ht.blockHidden, e)
                }
                _updateQtyVisibility(e) {
                    this._qtyEl.classList.toggle(ht.blockHidden, !e), this._spreadQtyWrapper.classList.toggle(ut.withoutQty, !e), this._updateVisibilityForSpreadQtyWrapper()
                }
                _updateVisibility() {
                    const e = this._isVisible.value() && 0 !== this._mode && !this._isHiddenByViewport;
                    this.element.classList.toggle(ht.blockHidden, !e)
                }
                _updateLastDigitSup() {
                    this._updateBuyButton(this._ask.value()), this._updateSellButton(this._bid.value())
                }
                _updateButtonTooltip(e, t) {
                    if ("" === t) return (0, st.setTooltipData)(e, "text", t), void e.removeAttribute("title");
                    e.setAttribute("title", t)
                }
                _toggleCalcVisibility() {
                    this._isCalcOpened = !this._isCalcOpened, this._renderCalc()
                }
                _closeCalc() {
                    this._isCalcOpened = !1, this._updateQty(this._qty.value()), this._model.applyQty(), this._renderCalc()
                }
                _renderCalc() {
                    Promise.all([i.e(2e3), i.e(9289), i.e(3713), i.e(2096), i.e(7544), i.e(7125), i.e(3809)]).then(i.bind(i, 13191)).then(async e => {
                        const t = await this._model.getQtyInfo();
                        null !== t && e.render(this._isCalcOpened, this._calcContainer, { ...t,
                            withInput: !0,
                            valueGetter: this._getCurrentQty,
                            position: this._getCalcPosition(),
                            targetEl: this._qtyEl,
                            onClose: this._closeCalc.bind(this),
                            onValueChange: this._model.setQty,
                            trackEventTarget: "Sell/Buy Buttons",
                            trackEvent: this._trackEvent
                        })
                    })
                }
                _getCalcPosition() {
                    const e = this._qtyEl.getBoundingClientRect();
                    return {
                        x: e.left,
                        y: e.bottom + 2
                    }
                }
                _windowResizeHandler() {
                    !1 !== this._isHiddenByViewport && (this._isHiddenByViewport = !1, this._updateVisibility())
                }
            }
            var yt = i(90687);
            const vt = (0, s.t)("Show Buy/Sell buttons");
            class ft {
                constructor(e, t, i, s, r, o) {
                    this._showSellBuyButtons = r.showSellBuyButtons, this._isInReplay = o, this._trackEvent = s.trackEvent, this._model = new et({
                        dataEvents: e,
                        getSymbolName: t,
                        qtySuggester: i,
                        tradingCommands: s,
                        settings: r,
                        isInReplay: o
                    }), this._renderer = new bt({
                        model: this._model,
                        highButtonsMode: r.noConfirmEnabled,
                        trackEvent: s.trackEvent,
                        toggleMinimizeBottomWidgetBar: s.toggleMinimizeBottomWidgetBar
                    })
                }
                destroy() {
                    this._model.destroy(), this._renderer.destroy()
                }
                renderTo(e, t) {
                    this._renderer.renderTo(e, t)
                }
                setGlobalVisibility(e) {
                    this._model.setGlobalVisibility(e)
                }
                visibility() {
                    return this._model.visible
                }
                updateWidgetModeBySize(e) {
                    this._renderer.updateModeByWidth(e.w)
                }
                contextMenuActions() {
                    if (this._renderer.isHiddenByViewport()) return [];
                    return [new yt.Action({
                        actionId: "Trading.SellBuyButtonsToggleVisibility",
                        checkable: !0,
                        checked: this._showSellBuyButtons.value(),
                        label: vt,
                        disabled: this._isInReplay.value(),
                        onExecute: () => {
                            const e = !this._showSellBuyButtons.value();
                            this._showSellBuyButtons.setValue(e), this._trackEvent("SellBuyButtonsWidget context menu", "Show Sell/Buy Button", e ? "Check" : "Uncheck")
                        }
                    })]
                }
                height() {
                    return this._renderer.height()
                }
            }
            var kt = i(87995),
                wt = i(89014),
                St = i(53337),
                Ct = i(52521);
            const Pt = J.forwardRef((e, t) => J.createElement("div", {
                ref: t,
                className: Ct.popupWrapper
            }, e.children));
            var Bt = i(53327);
            const Tt = (() => {
                    let e, t, s, r = null,
                        o = null;
                    return async (n, a, l, c) => {
                        const d = null == n ? void 0 : n.currentAccount();
                        if (null === r || o !== n || e !== d || s !== c) {
                            null == t || t.remove();
                            const {
                                AccountManager: u
                            } = await Promise.all([i.e(9685), i.e(5514), i.e(9129), i.e(2e3), i.e(6363), i.e(3466), i.e(7836), i.e(3921), i.e(7427), i.e(7552), i.e(7419), i.e(3727), i.e(2335), i.e(3975), i.e(3944), i.e(419), i.e(9255), i.e(2930), i.e(7664), i.e(9578), i.e(6872), i.e(8354)]).then(i.bind(i, 56718)), h = {
                                container: a,
                                visible: new(C())(!0)
                            };
                            r = a, o = n, e = d, s = c, t = await u.create({
                                broker: n,
                                bridge: h,
                                mode: 0,
                                overlapManager: l,
                                summaryFieldsVisibilityManager: c
                            })
                        } else a.appendChild(r)
                    }
                })(),
                Et = new(C())(null);

            function Lt(e) {
                const {
                    broker: t,
                    summaryFieldsVisibilityManager: i
                } = e, s = (0, J.useRef)(null), r = (0, J.useContext)(Bt.SlotContext);
                return (0, J.useEffect)(() => {
                    Et.setValue(r)
                }, [r]), (0, J.useEffect)(() => {
                    null !== s.current && Tt(t, s.current, Et.readonly(), i)
                }, []), J.createElement(Pt, {
                    ref: s
                })
            }
            var Ot = i(32455),
                Dt = i(38186),
                It = i(56656),
                Nt = i(71757);
            const At = (0, s.t)("Trading");
            class Mt extends wt.DialogRenderer {
                constructor(e) {
                    super(), this._title = At, this._isSubscribed = !1, this._showSeparator = !0, this._unsetHeaderAlign = !0, this._handleClose = () => {
                        kt.unmountComponentAtNode(this._container), this._setVisibility(!1)
                    }, this._trading = e
                }
                visible() {
                    return this._visibility.spawn().readonly()
                }
                show() {
                    this._isSubscribed || (this._isSubscribed = !0, this._onStatusChange(this._trading.connectStatus()), this._trading.onConnectionStatusChange.subscribe(this, this._onStatusChange)), this._setVisibility(!0), this._renderComponent()
                }
                hide() {
                    this._handleClose()
                }
                _onStatusChange(e, t) {
                    var i, s;
                    null === (i = this._trading.activeBroker()) || void 0 === i || i.currentAccountUpdate.unsubscribe(this, this._renderAccountManager), this._connectStatus !== e && (this._connectStatus = e, window.navigator.onLine ? 2 !== e && (null == t ? void 0 : t.disconnectType) !== d.DisconnectType.Offline && 3 !== e && 4 !== e ? 1 === e && (null === (s = this._trading.activeBroker()) || void 0 === s || s.currentAccountUpdate.subscribe(this, this._renderAccountManager), this._renderAccountManager()) : this._renderSpinner() : this._renderOfflineScreen())
                }
                _renderComponent() {
                    kt.render(J.createElement(St.AdaptivePopupDialog, {
                        dataName: "trading-dialog",
                        isOpened: this.visible().value(),
                        onClose: this._handleClose,
                        showSeparator: this._showSeparator,
                        unsetHeaderAlign: this._unsetHeaderAlign,
                        fullScreen: !0,
                        draggable: !1,
                        title: this._title,
                        render: () => this._content
                    }), this._container)
                }
                _renderSpinner() {
                    this._unsetHeaderAlign = !1, this._showSeparator = !0, this._title = At, this._changeDialogContent(J.createElement(Ot.Spinner, null))
                }
                _renderOfflineScreen() {
                    this._title = At, this._changeDialogContent(J.createElement(Nt.OfflineScreen, null))
                }
                async _renderBrokerSelectScreen() {
                    0
                }
                async _renderAccountManager() {
                    const e = (0, a.ensureNotNull)(this._trading.activeBroker()).accountManagerInfo().summary,
                        t = new It.SummaryFieldsVisibilityManager(e, this._trading.getBrokerTradingSettingsStorage),
                        s = await (0, Dt.makeAccountManagerHeaderDropdownsProps)(this._trading, t);
                    if (this._showSeparator = !1, this._unsetHeaderAlign = !0, this._title = At, void 0 !== s) {
                        const {
                            AccountManagerHeaderDropdowns: e
                        } = await Promise.all([i.e(9685), i.e(5514), i.e(9129), i.e(2e3), i.e(6363), i.e(3466), i.e(7836), i.e(3921), i.e(7427), i.e(7552), i.e(7419), i.e(3727), i.e(2335), i.e(3975), i.e(3944), i.e(419), i.e(9255), i.e(2930), i.e(7664), i.e(9578), i.e(6872), i.e(8354)]).then(i.bind(i, 73560));
                        this._title = J.createElement(e, { ...s
                        })
                    }
                    this._content = J.createElement(Lt, {
                        broker: this._trading.activeBroker(),
                        summaryFieldsVisibilityManager: t
                    }), this._renderComponent()
                }
                _changeDialogContent(e) {
                    this._content = J.createElement(Pt, null, e), this._renderComponent()
                }
            }
            var Vt, xt = i(70595),
                Ft = i(1227);
            async function Rt(e, t) {
                localStorage.setItem(e, t)
            }! function(e) {
                e.get = async function() {
                    return Ft.CheckMobile.any() || await async function() {
                        const e = o.getValue(O.settingsKeys.ACTIVE_BROKER);
                        if (o.remove(O.settingsKeys.ACTIVE_BROKER, {
                                forceFlush: !0
                            }), void 0 === e) return;
                        await Rt(O.settingsKeys.ACTIVE_BROKER, e)
                    }(), async function(e) {
                        return localStorage.getItem(e);
                        const t = localStorage.getItem(e);
                        if (null === t) return null;
                        const i = await userSpecificDecrypt(t);
                        null === i && localStorage.removeItem(e);
                        return i
                    }(O.settingsKeys.ACTIVE_BROKER)
                }, e.set = async function(e) {
                    await Rt(O.settingsKeys.ACTIVE_BROKER, e)
                }, e.clear = function() {
                    o.remove(O.settingsKeys.ACTIVE_BROKER, {
                        forceFlush: !0
                    }), localStorage.removeItem(O.settingsKeys.ACTIVE_BROKER)
                }
            }(Vt || (Vt = {}));
            var qt = i(73587),
                Ut = i(33064),
                Wt = i(57604),
                Qt = i(18286),
                jt = i(69977),
                Ht = i(12694),
                zt = i(49401),
                $t = i(65728),
                Gt = i(82165),
                Kt = i(39874),
                Zt = i(97280),
                Jt = i(84039);
            class Yt {
                constructor(e) {
                    this._rawAndFilteredQtyMap = new Map, this._qtyInfo = new Map;
                    const {
                        symbolInfoGetter: t,
                        onResetNeeded: i,
                        qtySettingsStorageGetter: s
                    } = e;
                    this._getQtySettingsStorage = s, this._getSymbolInfo = t, i.subscribe(this, this._reset)
                }
                async getQty(e) {
                    return (0, zt.firstValueFrom)(this._getRawAndFilteredQty(e).filteredQty$)
                }
                setQty(e, t) {
                    this._getRawAndFilteredQty(e).rawQty$.next(t)
                }
                suggestedQtyChanged(e) {
                    return this._getRawAndFilteredQty(e).filteredQty$.pipe((0, qt.skip)(1))
                }
                _getRawAndFilteredQty(e) {
                    var t;
                    return null !== (t = this._rawAndFilteredQtyMap.get(e)) && void 0 !== t ? t : this._makeRawAndFilteredQty(e)
                }
                _makeRawAndFilteredQty(e) {
                    const t = new $t.ReplaySubject(1),
                        i = this._getInitialQty(e).pipe((0, Ut.switchMap)(e => t.pipe((0, Wt.startWith)(e))), (0, Qt.distinctUntilChanged)(), (0, jt.filter)(t => this._isQtyCorrect(e, t)), (0, Gt.tap)(t => {
                            var i;
                            return null === (i = this._getQtySettingsStorage()) || void 0 === i ? void 0 : i.setSymbolQty(e, t)
                        }), (0, Ht.share)({
                            connector: () => new $t.ReplaySubject(1),
                            resetOnRefCountZero: !1
                        })),
                        s = {
                            rawQty$: t,
                            filteredQty$: i
                        };
                    return this._rawAndFilteredQtyMap.set(e, s), s
                }
                _isQtyCorrect(e, t) {
                    const i = (0, a.ensureDefined)(this._qtyInfo.get(e));
                    return !(0, Jt.checkQtyError)(i, t, !0).res
                }
                _getInitialQty(e) {
                    return (0, Kt.from)(this._getSymbolInfo(e)).pipe((0, c.map)(({
                        qty: t
                    }) => {
                        var i;
                        this._qtyInfo.set(e, t);
                        const s = null === (i = this._getQtySettingsStorage()) || void 0 === i ? void 0 : i.symbolQty(e),
                            r = t.default || t.min;
                        return void 0 !== s && s > 0 ? (o = (0, Zt.clamp)(s, t.min, t.max), n = t.min, a = t.step, _()(o).minus(n).div(a).round(0, 1).mul(a).plus(n).toNumber()) : r;
                        var o, n, a
                    }))
                }
                _reset() {
                    this._rawAndFilteredQtyMap.forEach(({
                        rawQty$: e
                    }) => e.complete()), this._rawAndFilteredQtyMap.clear(), this._qtyInfo.clear()
                }
            }
            var Xt = i(16230);
            class ei {
                constructor() {
                    this._context = null, this._onContextChanged = new(B()), this._contextChange = () => {
                        this._onContextChanged.fire(this.context())
                    }
                }
                context() {
                    var e, t;
                    return null !== (t = null === (e = this._context) || void 0 === e ? void 0 : e.externalContext()) && void 0 !== t ? t : null
                }
                setContext(e) {
                    var t;
                    this._isEqualContexts(e) || (this._clearSubscription(), this._context = e, null === (t = this._context) || void 0 === t || t.onStatusChange().subscribe(this, this._contextChange), this._contextChange())
                }
                onContextChanged() {
                    return this._onContextChanged
                }
                clear() {
                    this.setContext(null)
                }
                _clearSubscription() {
                    var e;
                    null === (e = this._context) || void 0 === e || e.onStatusChange().unsubscribeAll(this)
                }
                _isEqualContexts(e) {
                    return null === this._context || null === e ? this._context === e : this._context.status() === e.status() && (0, Xt.default)(this._context.errors(), e.errors()) && (0, Xt.default)(this._context.data(), e.data())
                }
            }
            class ti {
                constructor(e) {
                    this._transientStorage = {}, this._persistentStorageKey = "trading." + e;
                    const t = o.getJSON(this._persistentStorageKey, {});
                    delete t.orderTicketQuantity, this._transientStorage = t
                }
                setTakeProfitPips(e, t, i) {
                    this._setPips("takeProfit", e, t, i)
                }
                takeProfitPips(e) {
                    return this._getSectionValue("takeProfit", e)
                }
                setStopLossPips(e, t, i) {
                    this._setPips("stopLoss", e, t, i)
                }
                stopLossPips(e) {
                    return this._getSectionValue("stopLoss", e)
                }
                setDuration(e, t) {
                    const i = this.duration(e);
                    if (!(null !== t && void 0 !== i && i.type === t.type && i.datetime === t.datetime || null === t && void 0 === i)) {
                        if (null === t) return this._removeValue("duration", e), this._removeValue("durationDatetime", e), void this._syncStorage();
                        this._getOrCreateSection("duration")[e] = t.type, void 0 !== t.datetime ? this._getOrCreateSection("durationDatetime")[e] = t.datetime : this._removeValue("durationDatetime", e), this._syncStorage()
                    }
                }
                duration(e) {
                    const t = this._getSectionValue("duration", e);
                    if (void 0 === t || "" === t) return;
                    const i = {
                            type: t
                        },
                        s = this._getSectionValue("durationDatetime", e);
                    return void 0 !== s && (i.datetime = s), i
                }
                setSymbolQty(e, t) {
                    this._getOrCreateSection("qty")[e] = t, this._syncStorage()
                }
                symbolQty(e) {
                    return this._getSectionValue("qty", e)
                }
                setCustomFields(e, t) {
                    for (const [i, s] of Object.entries(t)) {
                        const t = this._getOrCreateSection("customFields"),
                            r = `${e}.${i}`;
                        "string" == typeof s && "" !== s || "boolean" == typeof s ? t[r] = s : delete t[r]
                    }
                    this._syncStorage()
                }
                customFields(e, t) {
                    const i = {},
                        s = this._transientStorage.customFields;
                    return void 0 === s || t.forEach(t => {
                        const r = s[`${e}.${t}`];
                        "" !== r && void 0 !== r && (i[t] = r)
                    }), i
                }
                setTableColumnsOrder(e, t) {
                    this._getOrCreateSection("tableColumnsOrder")[e] = t, this._syncStorage()
                }
                tableColumnsOrder(e) {
                    return this._getSectionValue("tableColumnsOrder", e)
                }
                summaryFieldsVisibilityInfo() {
                    const e = new Map,
                        t = this._transientStorage.summaryFields;
                    if (void 0 === t) return e;
                    for (const [i, s] of Object.entries(t)) e.set(i, {
                        id: i,
                        visible: s
                    });
                    return e
                }
                setSummaryFieldsVisibilityInfo(e) {
                    e.forEach(({
                        id: e,
                        visible: t
                    }) => {
                        this._getOrCreateSection("summaryFields")[e] = t
                    }), this._syncStorage()
                }
                _getOrCreateSection(e) {
                    return e in this._transientStorage || (this._transientStorage[e] = {}), this._transientStorage[e]
                }
                _getSectionValue(e, t) {
                    const i = this._transientStorage[e];
                    return void 0 !== i ? i[t] : void 0
                }
                _removeValue(e, t) {
                    const i = this._transientStorage[e];
                    void 0 !== i && (delete i[t], 0 === Object.keys(i).length && delete this._transientStorage[e])
                }
                _setPips(e, t, i, s) {
                    const r = this._getSectionValue(e, t);
                    if (!(void 0 !== r && r === i || void 0 === r && i === s)) {
                        if (void 0 !== r && i === s) this._removeValue(e, t);
                        else {
                            this._getOrCreateSection(e)[t] = i
                        }
                        this._syncStorage()
                    }
                }
                _syncStorage() {
                    o.setJSON(this._persistentStorageKey, this._transientStorage)
                }
            }
            var ii = i(70976),
                si = i(57025),
                ri = i(57047);
            const oi = (0, b.getLogger)("Trading.Core"),
                ni = {
                    1: "Connected",
                    2: "Connecting",
                    3: "Disconnected",
                    4: "Error"
                };
            var ai;
            ! function(e) {
                e[e.Paper = 43000516466] = "Paper", e[e.CQG = 43000516372] = "CQG", e[e.OANDA = 43000516375] = "OANDA", e[e.FOREXCOM = 43000516374] = "FOREXCOM"
            }(ai || (ai = {}));
            const li = {
                enabled: new(C())(!1),
                name: "alert/alarm_clock"
            };
            const ci = f.enabled("buy_sell_buttons"),
                di = !0;
            window.TRADING_SERVER_LOGGER_URL;
            class ui {
                constructor(e) {
                    this.accountType = new(C()), this.onBrokerChange = new(B()), this.onBrokerLoading = new(B()), this.onConnectionStatusChange = new(B()), this.onNewNotification = new(B()), this.onNeedSelectBroker = new(B()), this.onNotificationsChanged = new(B()), this.showTradedSources = new(C())(!0), this.showSellBuyButtons = new(C()), this.noConfirmEnabled = new(C()), this.showOnlyRejectionNotifications = new(C()), this.showPricesWithZeroVolume = new(C()), this.showSpread = new(C()), this.orderExecutedSoundParams = li, this._activeBroker = null, this._orderViewController = null, this._orderControllerPromise = null, this._brokerCommandsUI = null, this._showPricesWithZeroVolume = new(C()), this._showSpread = new(C()), this._closePositionDialogVisibility = new E.DialogVisibility, this._orderDialogVisibility = new E.DialogVisibility, this._loginDialogVisibility = new E.DialogVisibility, this._tradingPanelPopupVisibility = new E.DialogVisibility, this._tradingSettingsStorage = null, this._offlineListener = this._offlineHandler.bind(this), this._onlineListener = this._onlineHandler.bind(this), this._notifications = [], this._account = null, this._domPanelVisibility = new(C())(!1), this._orderPanelVisibility = new(C())(!1), this._pipValueType = new(C())(d.PipValueType.None), this._switchingBroker = !1, this._isReconnectNeeded = !1, this._accountVerificationPromise = null,
                        this._chartWidgetCollection = null, this._tradedItemsChartCollectionFacadePromise = null, this.getBrokerTradingSettingsStorage = () => this._tradingSettingsStorage, this.trackEvent = (e, t, i) => {
                            const s = e ? `[${e}] ${t}` : t;
                            if (this._gui()) {
                                const e = this._activeBroker ? this._activeBroker.metainfo().id + " Trading" : "Trading No Broker",
                                    t = this._activeBroker ? this._activeBroker.currentAccountType() : void 0;
                                this._gui().trackEvent(e, s, i || t)
                            }
                        }, this._tryReconnectLastBroker = async () => {
                            if (this._isReconnectNeeded) {
                                if ("hidden" === document.visibilityState) return window.addEventListener("visibilitychange", this._tryReconnectLastBroker, {
                                    once: !0
                                });
                                this._isReconnectNeeded = !1, await this._selectLastBroker()
                            }
                        }, this._onCurrentAccountUpdate = () => {
                            const e = (0, a.ensureNotNull)(this._activeBroker).currentAccount();
                            this._account !== e && (this._tradedContextLinking.clear(), this._account = e, this.onNotificationsChanged.fire(this.getNotifications()))
                        }, this._onFullScreenDialogOpen = () => {
                            this._guiAccessor.closeAllNotifications()
                        }, this._setPipValueType = async () => {
                            const e = r.linking.proSymbol.value(),
                                {
                                    type: t
                                } = await this._realtimeProvider.symbolInfo(e);
                            let i = d.PipValueType.Ticks;
                            "crypto" === t ? i = d.PipValueType.None : "forex" === t && (i = d.PipValueType.Pips), this._pipValueType.setValue(i)
                        }, this._trackNonTradableSymbol = async () => {
                            var e;
                            if (1 === (null === (e = this._activeBroker) || void 0 === e ? void 0 : e.connectionStatus())) {
                                const e = r.linking.proSymbol.value(),
                                    t = await this._activeBroker.isTradable(e);
                                t && !t.tradable && this.trackEvent("Symbol is not tradable", e)
                            }
                        }, this._onBrokerChanged = e => {
                            this._tradingSettingsStorage = null !== e ? new ti(e.metainfo().id) : null
                        }, this._onTradingPanelVisibilityChanged = e => {
                            e && (this.setOrderPanelVisibility(e), this.tradingPanel.isVisible.unsubscribe(this._onTradingPanelVisibilityChanged))
                        }, this._setPipValueType = (0, v.sequentialize)(this._setPipValueType), this._selectBrokerInternal = (0, v.sequentialize)(this._selectBrokerInternal), this._showSellBuyButtonsKey = this._makeShowSellBuyButtonsKey(), this._resizerBridge = e, this._realtimeProvider = new V(() => this.activeBroker(), this.onBrokerChange, this.onConnectionStatusChange), this._positionService = new xe(this), this._ordersService = new qe(this), this._tradingStat = new F(this), this._serverLogger = null, this._tradedContextLinking = new ei, this.onBrokerChange.subscribe(this, this._onBrokerChanged), this.tradingPanelPopup = new Mt(this), this.tradingPanelPopup.visible().subscribe(e => {
                            e ? (this._tradingPanelPopupVisibility.setValue({
                                isVisible: e,
                                isFullScreen: !0
                            }), this._onFullScreenDialogOpen()) : this._tradingPanelPopupVisibility.setValue({
                                isVisible: e
                            })
                        }), this.tradingPanel = new ce(e);
                    this._qtySuggester = new Yt({
                        onResetNeeded: this.onConnectionStatusChange,
                        symbolInfoGetter: e => this._realtimeProvider.symbolInfo(e),
                        qtySettingsStorageGetter: () => this._tradingSettingsStorage
                    });
                    const t = new re(e, () => this.tradingPanel.close(), this, this._qtySuggester);
                    this.tradingPanel.addPage(ne.TradingPage.DomPanel, t);
                    const i = new oe;
                    this.tradingPanel.addPage(ne.TradingPage.OrderPanel, i);
                    const s = o.getValue(O.settingsKeys.TRADING_PANEL_ACTIVE_PAGE),
                        n = o.getBool(O.settingsKeys.TRADING_PANEL_OPENED, f.enabled("show_order_panel_on_start"));
                    s && this.tradingPanel.activePage.setValue(s), n && this.tradingPanel.open(), this.tradingPanel.isPageOpened(ne.TradingPage.OrderPanel) && (this.tradingPanel.isVisible.value() ? this.setOrderPanelVisibility(!0) : this.tradingPanel.isVisible.subscribe(this._onTradingPanelVisibilityChanged)), (0, w.combine)(() => ({}), this.tradingPanel.activePage, this.tradingPanel.isOpened).subscribe(() => {
                        this._domPanelVisibility.setValue(this.tradingPanel.isPageOpened(ne.TradingPage.DomPanel)), this._orderPanelVisibility.setValue(this.tradingPanel.isPageOpened(ne.TradingPage.OrderPanel))
                    }), this.closePositionDialogVisibility = this._closePositionDialogVisibility.value$, this.orderDialogVisibility = this._orderDialogVisibility.value$, this.loginDialogVisibility = this._loginDialogVisibility.value$, this.possibleFullScreenDialogsVisibility = (0, l.merge)(this.closePositionDialogVisibility.pipe((0, c.map)(e => ({ ...e,
                        name: "close-position-dialog"
                    }))), this.orderDialogVisibility.pipe((0, c.map)(e => ({ ...e,
                        name: "order-dialog"
                    }))), this.loginDialogVisibility.pipe((0, c.map)(e => ({ ...e,
                        name: "login-dialog"
                    }))), this._tradingPanelPopupVisibility.value$.pipe((0, c.map)(e => ({ ...e,
                        name: "trading-panel-popup"
                    }))))
                }
                setChartWidgetCollection(e) {
                    (0, a.assert)(null === this._chartWidgetCollection, "ChartWidgetCollection can be set only once"), this._chartWidgetCollection = e, this._guiAccessor = new Q(e), new Pe(this), this._loadState(), o.onSync.subscribe(this, this._loadState);
                    const t = () => {
                        this._save()
                    };
                    this.showSellBuyButtons.subscribe(t), this.noConfirmEnabled.subscribe(t), this.showOnlyRejectionNotifications.subscribe(t), this._showPricesWithZeroVolume.subscribe(t), this._showSpread.subscribe(t), this.orderExecutedSoundParams.enabled.subscribe(t), window.addEventListener("offline", this._offlineListener), window.addEventListener("online", this._onlineListener), this.bindShortcuts(), this._tradedItemsChartCollectionFacadePromise = this._createTradedItemsChartCollectionFacade(e), this._registerCustomSources(e), this._registerCustomWidgets(e)
                }
                showPricesWith() {
                    return {
                        zeroVolume: this._showPricesWithZeroVolume,
                        spread: this._showSpread
                    }
                }
                domPanelVisibility() {
                    return this._domPanelVisibility
                }
                orderPanelVisibility() {
                    return this._orderPanelVisibility
                }
                realtimeProvider() {
                    return this._realtimeProvider
                }
                toggleTradingPanelPopup() {
                    this.tradingPanelPopup.visible().value() ? this.tradingPanelPopup.hide() : this.tradingPanelPopup.show()
                }
                toggleTradingWidget() {
                    return window.TradingView.bottomWidgetBar ? window.TradingView.bottomWidgetBar.activateTradingTab() : Promise.resolve()
                }
                toggleMinimizeBottomWidgetBar() {
                    if (window.TradingView.bottomWidgetBar) return window.TradingView.bottomWidgetBar.toggleMinimize()
                }
                tradingWizard() {
                    return this._tradingWizard
                }
                showTradingProperties() {
                    this._gui() && this._gui().showTradingProperties()
                }
                brokersList() {
                    return L.brokersList()
                }
                brokersPlans() {
                    return this._getBrokerPlans()
                }
                activeBroker() {
                    return this._activeBroker
                }
                brokerCommandsUI() {
                    return this._brokerCommandsUI
                }
                async selectBroker(e, t) {
                    await this._selectBrokerInternal({
                        brokerId: e,
                        isUserAction: !0,
                        keepSessionAlive: t
                    })
                }
                async pickDefaultBroker() {
                    if (this._activeBroker) return;
                    let e = null;
                    const t = this.brokersList().filter(e => !e.configFlags.isSuspended);
                    if (1 === t.length) e = t[0].id;
                    else {
                        const i = await Vt.get();
                        i && t.some(e => e.id === i) && (e = i)
                    }
                    e && this._selectBrokerInternal({
                        brokerId: e,
                        isUserAction: !1
                    })
                }
                async makeNewOrderContextMenuAction(e, t, i) {
                    const r = await this._qtySuggester.getQty(e);
                    return {
                        name: "trade-new-order",
                        action: () => {
                            this.trackEvent(t, "New Order"), this._checkAndOpenOrderDialog({
                                symbol: e,
                                qty: r,
                                limitPrice: i,
                                stopPrice: i
                            })
                        },
                        text: (0, y.appendEllipsis)((0, s.t)("Create new order")),
                        statName: "NewOrder"
                    }
                }
                async defaultContextMenuActions(e, {
                    onlyMainActions: t = !1,
                    gaOrigin: i = "Chart Context Menu"
                } = {}) {
                    const r = await this._qtySuggester.getQty(e.symbol),
                        o = e.value || void 0,
                        {
                            bid: n,
                            ask: a
                        } = await this.realtimeProvider().quotesSnapshot(e.symbol),
                        l = [];
                    if (null !== e.value && void 0 !== a && void 0 !== n && (e.value >= a || e.value <= n)) {
                        const t = (n + a) / 2;
                        l.push(...await this._makeSubActions(e, r, t, i))
                    }
                    return l.push(await this.makeNewOrderContextMenuAction(e.symbol, i, o)), !t && f.enabled("property_pages") && (l.push({
                        separator: !0
                    }), l.push({
                        name: "trade-properties",
                        action: () => {
                            this.trackEvent(i, "Trading Properties"), this.showTradingProperties()
                        },
                        text: (0, y.appendEllipsis)((0, s.t)("Trading settings")),
                        icon: ii,
                        statName: "Properties"
                    })), l
                }
                defaultDropdownMenuActions(e) {
                    const t = [],
                        i = this.activeBroker(),
                        r = e || {
                            tradingProperties: !0,
                            restoreConfirmations: i && i.metainfo().configFlags.supportConfirmations,
                            showHowToUse: i && i.metainfo().configFlags.supportHowToUse
                        };
                    return f.enabled("property_pages") || (r.tradingProperties = !1), r.tradingProperties && t.push({
                        action: () => {
                            this.showTradingProperties(), this.trackEvent("Bottom Panel Dropdown", "Trading Properties")
                        },
                        text: (0, y.appendEllipsis)((0, s.t)("Trading settings")),
                        icon: ii
                    }), r.restoreConfirmations && t.push({
                        action: () => {
                            this._showRestoreConfirmations(), this.trackEvent("Bottom Panel Dropdown", "Restore confirmations")
                        },
                        text: (0, y.appendEllipsis)((0, s.t)("Restore confirmations"))
                    }), t
                }
                chartContextMenuActions(e, t) {
                    return (this._activeBroker && 1 === this._activeBroker.connectionStatus() ? this._activeBroker.chartContextMenuActions(e, t) : this.defaultContextMenuActions(e, t)).then(e => (0, u.convertActionDescriptionsToActions)(e))
                }
                connectStatus() {
                    return this._activeBroker ? this._activeBroker.connectionStatus() : 3
                }
                bindShortcuts() {
                    if (this._hotkeys) return;
                    this._hotkeys = n.createGroup({
                        desc: "Trading"
                    });
                    const e = async e => {
                        const t = this._gui().proSymbol(),
                            i = await this._qtySuggester.getQty(t),
                            {
                                bid: s,
                                ask: r
                            } = await this.realtimeProvider().quotesSnapshot(t),
                            o = {
                                price: void 0 !== s && void 0 !== r ? (s + r) / 2 : NaN,
                                qty: i,
                                side: e,
                                symbol: t,
                                type: 2,
                                seenPrice: null
                            };
                        this.trackEvent("Shortcut", -1 === e ? "Sell" : "Buy"), this._checkAndPlaceOrder(o)
                    };
                    this._hotkeys.add({
                        desc: "Buy",
                        hotkey: n.Modifiers.Shift + 66,
                        handler: () => e(1)
                    }), this._hotkeys.add({
                        desc: "Sell",
                        hotkey: n.Modifiers.Shift + 83,
                        handler: () => e(-1)
                    })
                }
                formatter(e) {
                    return this.realtimeProvider().formatter(e)
                }
                showSuccessNotification(e, t, i = 1e4) {
                    this.showOnlyRejectionNotifications.value() || this._showNotification(e, t, "success", i), f.enabled("show_trading_notifications_history") && this._addNotificationRow(e, t, "success", i), this._log(e, t)
                }
                showErrorNotification(e, t, i = 25e3) {
                    this._showNotification(e, t, "danger", i), f.enabled("show_trading_notifications_history") && this._addNotificationRow(e, t, "danger", i), this._log(e, t)
                }
                getNotifications() {
                    return this._notifications.filter(e => e.account === this._account && e.broker === (this._activeBroker ? this._activeBroker.metainfo().id : null))
                }
                setDomPanelVisibility(e) {
                    e ? this.tradingPanel.openPage(ne.TradingPage.DomPanel) : this.tradingPanel.close()
                }
                setOrderPanelVisibility(e) {
                    this._getOrderViewController().then(t => {
                        e ? t.openPanel() : t.closePanel()
                    })
                }
                orderViewController() {
                    return (0, a.ensureNotNull)(this._orderViewController)
                }
                tradingStat() {
                    return this._tradingStat
                }
                async verifyBrokerLiveAccount() {
                    return this._verifyLiveAccount(), null !== this._accountVerificationPromise ? this._accountVerificationPromise : Promise.reject("Account verification is not needed")
                }
                pipValueType() {
                    return this._pipValueType
                }
                tradedItemsChartCollectionFacade() {
                    return (0, a.ensureNotNull)(this._tradedItemsChartCollectionFacadePromise)
                }
                async _getOrderViewController() {
                    return null !== this._orderViewController ? this._orderViewController : (await this._createOrderController(), this._getOrderViewController())
                }
                async _selectBrokerInternal(e) {
                    var t;
                    const {
                        brokerId: i,
                        isUserAction: r,
                        keepSessionAlive: o = !1,
                        disconnectInfo: n
                    } = e;
                    if (this._switchingBroker) return void oi.logWarn(`Broker is already selected, but a new broker id: ${i} was received.`);
                    if (i !== (this._activeBroker ? this._activeBroker.metainfo().id : null)) {
                        if (this._activeBroker) {
                            const e = this._activeBroker && this._activeBroker.disconnectWarningMessage(),
                                t = () => this._showReviewDialogIfNeeded(3, {
                                    disconnectType: d.DisconnectType.LogOut
                                });
                            if (null !== e && window.is_authenticated) {
                                if (!await (0, Be.showSimpleConfirmDialog)({
                                        title: (0, s.t)("Log Out Confirmation"),
                                        text: e,
                                        mainButtonText: (0, s.t)("Log Out"),
                                        mainButtonIntent: "danger",
                                        cancelButtonText: (0, s.t)("Cancel"),
                                        onConfirm: () => {
                                            t(), this._logOut(r, o, n)
                                        },
                                        onCancel: () => {
                                            t()
                                        }
                                    })) return
                            } else t(), this._logOut(r, o, n)
                        }
                        if (null != i) {
                            let e;
                            0, this._switchingBroker = !0;
                            try {
                                const t = await L.createBrokerConnection(this, i, this._serverLogger, null, e),
                                    {
                                        isMaintenance: s,
                                        message: r
                                    } = await t.maintenanceStatus();
                                if (s) {
                                    if (!await this._showBrokerSideMaintenanceWarning(t.metainfo().id, r)) return this._switchingBroker = !1, void t.disconnect(!0)
                                }
                                0, await this._initBroker(t, o)
                            } catch (e) {
                                this._switchingBroker = !1, oi.logError((0, m.getLoggerMessage)(e))
                            }
                        } else r && setTimeout(() => {
                            Vt.clear()
                        }), this.onBrokerChange.fire(null), null === (t = this._closePositionDialogVisibilitySubscription) || void 0 === t || t.unsubscribe(), this._brokerCommandsUI = null
                    } else oi.logWarn(i + " is already selected.")
                }
                async _initBroker(e, t) {
                    this._activeBroker = e, this._activeBroker.connectionStatusUpdate.subscribe(this, this._connectionListener), this._activeBroker.currentAccountUpdate.subscribe(this, this._onCurrentAccountUpdate), this._realtimeProvider.onStatusChanged.subscribe(null, this._setPipValueType),
                        r.linking.proSymbol.subscribe(this._setPipValueType), this._realtimeProvider.onStatusChanged.subscribe(null, this._trackNonTradableSymbol), r.linking.proSymbol.subscribe(this._trackNonTradableSymbol), this._brokerCommandsUI = new se(this._activeBroker, this._guiAccessor, this.noConfirmEnabled, this._getOrderViewController.bind(this), this.showErrorNotification.bind(this), this.trackEvent), this._closePositionDialogVisibilitySubscription = this._brokerCommandsUI.closePositionDialogVisibility.subscribe(this._makeDialogVisibilityHandler(this._closePositionDialogVisibility)), this._activeBroker.tryRestoreSession(), await Vt.set(this._activeBroker.metainfo().id), this.onBrokerChange.fire(this._activeBroker), this._getOrderViewController(), this._updateConnectionStatus(this.connectStatus()), this._switchingBroker = !1
                }
                async _showBrokerSideMaintenanceWarning(e, t) {
                    return (0, Be.showSimpleConfirmDialog)({
                        title: (0, s.t)("{brokerId} side maintenance", {
                            replace: {
                                brokerId: e
                            }
                        }),
                        text: null != t ? t : (0, s.t)("Broker currently carries out a maintenance. Please try again a little bit later or proceed at your own risk"),
                        cancelButtonText: (0, s.t)("Cancel"),
                        mainButtonIntent: "primary",
                        mainButtonText: (0, s.t)("Proceed anyway"),
                        showBackdrop: !0
                    })
                }
                _makeDialogVisibilityHandler(e) {
                    return t => {
                        e.setValue(t), t.isFullScreen && this._onFullScreenDialogOpen()
                    }
                }
                _gui() {
                    return this._guiAccessor
                }
                _addNotificationRow(e, t, i, s) {
                    const r = {
                        id: this._notifications.length,
                        account: this._account,
                        broker: this._activeBroker ? this._activeBroker.metainfo().id : null,
                        time: new Date,
                        title: e,
                        text: t,
                        type: i
                    };
                    this._notifications.push(r), this.onNewNotification.fire(r)
                }
                _offlineHandler() {
                    this._selectBrokerInternal({
                        brokerId: null,
                        isUserAction: !1,
                        keepSessionAlive: !1,
                        disconnectInfo: {
                            disconnectType: d.DisconnectType.Offline
                        }
                    }), oi.logNormal("The connection to the Internet was interrupted")
                }
                async _onlineHandler() {
                    await this._selectLastBroker() && oi.logNormal("The connection to the Internet was restored")
                }
                _showNotification(e, t, i, s) {
                    this._gui() && this._gui().showNotification(e, t, i, s)
                }
                _showReviewDialogIfNeeded(e, t) {
                    if (null === this._activeBroker) return;
                    this._activeBroker
                }
                _connectionListener(e, t) {
                    const i = this.connectStatus();
                    this._showReviewDialogIfNeeded(e, t);
                    const s = this._isReconnectNeeded = (null == t ? void 0 : t.disconnectType) === d.DisconnectType.BrokenConnection;
                    3 !== e || (null == t ? void 0 : t.disconnectType) !== d.DisconnectType.LogOut && !this._isReconnectNeeded || this._selectBrokerInternal({
                        brokerId: null,
                        isUserAction: !1,
                        keepSessionAlive: !1,
                        disconnectInfo: t
                    }).then(() => {
                        if (this._isReconnectNeeded) return this._tryReconnectLastBroker()
                    }), (null == t ? void 0 : t.disconnectType) === d.DisconnectType.CancelAuthorization && this.trackEvent("Signin", "OAuth popup closed", "By user"), (null == t ? void 0 : t.disconnectType) === d.DisconnectType.TimeOutForAuthorization && this.trackEvent("Signin", "OAuth popup closed", "By timeout"), this._updateConnectionStatus(i, !s, t)
                }
                async _selectLastBroker() {
                    const e = await Vt.get();
                    return null !== e && (await this._selectBrokerInternal({
                        brokerId: e,
                        isUserAction: !1
                    }), !0)
                }
                _updateOrderPanelSpinnerState() {
                    const e = this._orderViewController,
                        t = 2 === this.connectStatus(),
                        i = null !== e && e.stateChanging.value();
                    this.tradingPanel.isLoading.setValue(t || i)
                }
                async _updateConnectionStatus(e, t = !0, i) {
                    var s;
                    this._updateOrderPanelSpinnerState(), this.onConnectionStatusChange.fire(e, i), this._log("Connection status", ni[e]);
                    this._activeBroker;
                    if (t) {
                        const e = null === (s = this._activeBroker) || void 0 === s ? void 0 : s.metainfo().id;
                        void 0 !== e ? await Vt.set(e) : Vt.clear()
                    }
                    this._activeBroker ? 1 === e ? (this._account = this._activeBroker.currentAccount(), this._guiAccessor.setBroker(this._activeBroker)) : this._tradedContextLinking.clear() : (this._accountVerificationPromise = null, this._guiAccessor.setBroker(null), this._tradedContextLinking.clear())
                }
                _verifyLiveAccount() {
                    if (null !== this._accountVerificationPromise) return;
                    const e = (0, a.ensureNotNull)(this._activeBroker);
                    e.metainfo().configFlags.supportVerifyLiveAccount && (e.currentAccountType(), d.AccountType.Live)
                }
                _save() {
                    const e = o.getJSON(O.settingsKeys.PROPERTIES, {});
                    o.setJSON(O.settingsKeys.PROPERTIES, { ...e,
                        [this._showSellBuyButtonsKey]: +!!this.showSellBuyButtons.value(),
                        noConfirmEnabled: +!!this.noConfirmEnabled.value(),
                        qweqrq: +!!this.showOnlyRejectionNotifications.value(),
                        showPricesWithZeroVolume: +!!this._showPricesWithZeroVolume.value(),
                        showSpread: +!!this._showSpread.value(),
                        orderExecutedSoundParams: JSON.stringify({
                            enabled: +!!this.orderExecutedSoundParams.enabled.value(),
                            name: this.orderExecutedSoundParams.name
                        })
                    })
                }
                _loadState() {
                    const e = o.getJSON(O.settingsKeys.PROPERTIES, {}),
                        t = e[this._showSellBuyButtonsKey];
                    if (this.showSellBuyButtons.setValue(void 0 !== t ? !!t : di), this.noConfirmEnabled.setValue(!!e.noConfirmEnabled), this.showOnlyRejectionNotifications.setValue(!!e.qweqrq), this._showPricesWithZeroVolume.setValue(!e.hasOwnProperty("showPricesWithZeroVolume") || e.showPricesWithZeroVolume), this._showSpread.setValue(!e.hasOwnProperty("showSpread") || e.showSpread), e.hasOwnProperty("orderExecutedSoundParams")) {
                        const t = JSON.parse(e.orderExecutedSoundParams);
                        this.orderExecutedSoundParams.enabled.setValue(!!t.enabled), this.orderExecutedSoundParams.name = t.name
                    }
                }
                _makeShowSellBuyButtonsKey() {
                    return "showSellBuyButtons"
                }
                _log(e, t) {
                    oi.logNormal(`${this._activeBroker?this._activeBroker.metainfo().id+" Trading: ":""}${e} - ${t}`)
                }
                _makeSureCanTrade() {
                    const e = this.activeBroker(),
                        t = this.brokerCommandsUI();
                    return e && t ? 1 === e.connectionStatus() || (this.toggleTradingWidget(), !1) : (this.toggleTradingWidget().then(() => this.onNeedSelectBroker.fire()), !1)
                }
                _checkAndPlaceOrder(e, t = !0) {
                    this._makeSureCanTrade() && (0, a.ensureNotNull)(this.brokerCommandsUI()).placeOrder(e, t)
                }
                _checkAndOpenOrderDialog(e) {
                    this._makeSureCanTrade() && (0, a.ensureNotNull)(this.brokerCommandsUI()).placeOrder(e)
                }
                _makeSubAction(e, t, i, r, o, n) {
                    const a = 1 === t ? ri : si,
                        l = 1 === t ? "Buy" : "Sell",
                        c = 1 === i ? "Limit" : 3 === i ? "Stop" : "StopLimit",
                        d = function(e) {
                            return "altPrice" in e && "formattedAltPrice" in e
                        }(r),
                        u = l + c,
                        h = {
                            BuyLimit: (0, s.t)("Buy {qty} {symbol} @ {value} limit").format({
                                symbol: e.displaySymbol,
                                qty: (0, k.abbreviatedNumber)(o),
                                value: r.formattedPrice
                            }),
                            SellStop: (0,
                                s.t)("Sell {qty} {symbol} @ {value} stop").format({
                                symbol: e.displaySymbol,
                                qty: (0, k.abbreviatedNumber)(o),
                                value: r.formattedPrice
                            }),
                            SellLimit: (0, s.t)("Sell {qty} {symbol} @ {value} limit").format({
                                symbol: e.displaySymbol,
                                qty: (0, k.abbreviatedNumber)(o),
                                value: r.formattedPrice
                            }),
                            BuyStop: (0, s.t)("Buy {qty} {symbol} @ {value} stop").format({
                                symbol: e.displaySymbol,
                                qty: (0, k.abbreviatedNumber)(o),
                                value: r.formattedPrice
                            })
                        };
                    return d && (h.SellStopLimit = (0, s.t)("Sell {qty} {symbol} @ {value} stop {altValue} limit").format({
                        symbol: e.displaySymbol,
                        qty: (0, k.abbreviatedNumber)(o),
                        value: r.formattedPrice,
                        altValue: r.formattedAltPrice
                    }), h.BuyStopLimit = (0, s.t)("Buy {qty} {symbol} @ {value} stop {altValue} limit").format({
                        symbol: e.displaySymbol,
                        qty: (0, k.abbreviatedNumber)(o),
                        value: r.formattedPrice,
                        altValue: r.formattedAltPrice
                    })), {
                        name: `trade-${l}-${c}`.toLowerCase(),
                        action: () => {
                            this.trackEvent(n, `${l} ${c}`);
                            const s = 1 === i ? "limitPrice" : "stopPrice",
                                a = {
                                    qty: o,
                                    side: t,
                                    symbol: e.symbol,
                                    type: i,
                                    seenPrice: null
                                };
                            null !== r.price && (a[s] = r.price), 4 === i && d && (a.limitPrice = r.altPrice), this._checkAndPlaceOrder(a)
                        },
                        icon: a,
                        text: h[u],
                        statName: u
                    }
                }
                _createOrderController() {
                    return null === this._orderControllerPromise && (this._orderControllerPromise = Promise.all([i.e(2335), i.e(970), i.e(660)]).then(i.bind(i, 44785)).then(({
                        OrderViewController: e
                    }) => new e({
                        resizerBridge: this._resizerBridge,
                        onNeedSelectBroker: this.onNeedSelectBroker,
                        realtimeProvider: this.realtimeProvider(),
                        pipValueType: this.pipValueType(),
                        trackEvent: this.trackEvent,
                        toggleTradingWidget: this.toggleTradingWidget.bind(this),
                        toggleTradingPanelPopup: this.toggleTradingPanelPopup.bind(this),
                        showErrorNotification: this.showErrorNotification.bind(this),
                        getTradingSettingsStorage: () => this._tradingSettingsStorage
                    }, {
                        container: this.tradingPanel.container,
                        isOpened: this.tradingPanel.isOpened,
                        isVisible: this.tradingPanel.isVisible,
                        activePage: this.tradingPanel.activePage,
                        close: this.tradingPanel.close.bind(this.tradingPanel),
                        openPage: this.tradingPanel.openPage.bind(this.tradingPanel)
                    }, this._qtySuggester)).then(e => {
                        this._orderControllerPromise = null, this._orderViewController = e, this._orderViewController.stateChanging.subscribe(() => this._updateOrderPanelSpinnerState()), this._orderViewController.dialogVisibility.subscribe(this._makeDialogVisibilityHandler(this._orderDialogVisibility))
                    })), this._orderControllerPromise
                }
                async _registerCustomSources(e) {
                    !async function(e, t) {
                        const s = await i.e(2650).then(i.bind(i, 60818));
                        e.addCustomSource("bidask", (i, r) => new s.BidAsk(i, r, t.realtimeProvider(), () => {
                            e.activeChartWidget.value().showGeneralChartProperties(T.TabNames.symbol)
                        }))
                    }(e, this), Ne(e, this, this.showTradedSources);
                    new((await i.e(2650).then(i.bind(i, 46841))).TradedSourcesManager)(this._ordersService, this._positionService, e, {
                        showTradedSources: this.showTradedSources,
                        realtimeProvider: this._realtimeProvider,
                        brokerCommandsUI: this.brokerCommandsUI.bind(this),
                        trackEvent: this.trackEvent,
                        pipValueType: this._pipValueType
                    })
                }
                _registerCustomWidgets(e) {
                    ci && function(e, t, i) {
                        e.addCustomWidgetToLegend((e, s) => {
                            const r = e.mainSeries(),
                                o = (0,
                                    De.createWVFromGetterAndSubscription)(e.isInReplay.bind(e), e.onInReplayStateChanged());
                            return new ft(r.dataEvents(), function(e) {
                                return () => {
                                    const t = e.symbolInfo();
                                    return null !== t ? t.pro_name || t.full_name || t.name || "" : e.proSymbol()
                                }
                            }(r), i, {
                                onNeedSelectBroker: t.onNeedSelectBroker,
                                realtimeProvider: t.realtimeProvider(),
                                onBrokerConnectionStatusChange: t.onConnectionStatusChange,
                                brokerConnectionStatus: t.connectStatus.bind(t),
                                trackEvent: t.trackEvent,
                                toggleTradingWidget: t.toggleTradingWidget.bind(t),
                                toggleTradingPanelPopup: t.toggleTradingPanelPopup.bind(t),
                                brokerCommandsUI: t.brokerCommandsUI.bind(t),
                                toggleMinimizeBottomWidgetBar: () => t.toggleMinimizeBottomWidgetBar()
                            }, {
                                showSellBuyButtons: t.showSellBuyButtons,
                                noConfirmEnabled: t.noConfirmEnabled,
                                themeName: s
                            }, o)
                        }, {
                            block: 0,
                            position: 0
                        })
                    }(e, this, this._qtySuggester)
                }
                async _makeSubActions(e, t, i, s) {
                    const r = [];
                    if (null === e.value) return r;
                    const o = this.activeBroker();
                    let n, a, l, c, d, u, _, b, y, v, f, k, w, S = null === o,
                        C = null === o,
                        P = null === o,
                        B = null === o;
                    null !== o && 1 === o.connectionStatus() && (w = await o.isTradable(e.symbol));
                    const [T, E] = await Promise.all([this._realtimeProvider.symbolInfo(e.symbol), this._realtimeProvider.formatter(e.symbol)]), L = T.variableMinTick ? function(e, t) {
                        var i, s, r, o, n;
                        const a = t.split(" ").map(Number);
                        if ((0, g.isEven)(a.length) || a.some(Number.isNaN)) return [{
                            minTick: e,
                            price: 1 / 0,
                            maxIndex: 1 / 0
                        }];
                        const l = [];
                        for (let e = 0; e < a.length; e += 2) {
                            const t = null !== (i = a[e + 1]) && void 0 !== i ? i : 1 / 0,
                                c = null !== (r = null === (s = l[l.length - 1]) || void 0 === s ? void 0 : s.price) && void 0 !== r ? r : 0,
                                d = null !== (n = null === (o = l[l.length - 1]) || void 0 === o ? void 0 : o.maxIndex) && void 0 !== n ? n : 0,
                                u = t === 1 / 0 ? 1 / 0 : new p.Big(t).minus(c).div(a[e]).plus(d).toNumber();
                            l.push({
                                minTick: a[e],
                                price: t,
                                maxIndex: u
                            })
                        }
                        return l
                    }(T.minTick, T.variableMinTick) : void 0, O = e => function(e) {
                        const {
                            minTick: t,
                            price: i,
                            variableMinTickData: s,
                            shouldCheckForEquality: r
                        } = e;
                        return void 0 === s ? t : function(e, t, i = !1) {
                            for (let s = 0; s < t.length; s++) {
                                if (e < t[s].price) return t[s].minTick;
                                if (i && e === t[s].price) return t[s].minTick
                            }
                            return t[t.length - 1].minTick
                        }(i, s, r)
                    }({
                        minTick: T.minTick,
                        price: e,
                        variableMinTickData: L
                    });
                    if (null !== o && w && w.tradable) {
                        const t = o.metainfo().configFlags,
                            i = (0, h.alignToStep)(e.value, O(e.value));
                        n = i, l = i, c = i, a = i, d = c + O(c), u = a - O(a), S = Boolean(t.supportLimitOrders), C = Boolean(t.supportStopOrders), P = Boolean(t.supportStopOrdersInBothDirectionsInUI), B = Boolean(t.supportStopLimitOrders), void 0 !== T.limitPriceStep && (n = (0, m.roundToStepByPriceTypeAndSide)(e.value, T.limitPriceStep, 1, 1), l = (0, m.roundToStepByPriceTypeAndSide)(e.value, T.limitPriceStep, 1, -1), d = (0, m.roundToStepByPriceTypeAndSide)(e.value + O(e.value), T.limitPriceStep, 1, 1), u = (0, m.roundToStepByPriceTypeAndSide)(e.value - O(e.value), T.limitPriceStep, 1, -1)), void 0 !== T.stopPriceStep && (c = (0, m.roundToStepByPriceTypeAndSide)(e.value, T.stopPriceStep, 2, 1), a = (0, m.roundToStepByPriceTypeAndSide)(e.value, T.stopPriceStep, 2, -1)), _ = E.format(n), b = E.format(a), y = E.format(l), v = E.format(c), f = E.format(d), k = E.format(u)
                    } else n = l = c = a = e.value, _ = b = y = v = e.formattedValue, d = c + O(c), u = a - O(a), f = E.format(d), k = E.format(u);
                    if (e.value <= i) {
                        if (S) {
                            const i = {
                                price: n,
                                formattedPrice: _
                            };
                            r.push(this._makeSubAction(e, 1, 1, i, t, s))
                        }
                        if (P) {
                            const i = {
                                price: c,
                                formattedPrice: v
                            };
                            r.push(this._makeSubAction(e, 1, 3, i, t, s))
                        }
                        if (C || P) {
                            const i = {
                                price: a,
                                formattedPrice: b
                            };
                            r.push(this._makeSubAction(e, -1, 3, i, t, s))
                        }
                        if (B) {
                            const i = {
                                price: a,
                                formattedPrice: b,
                                altPrice: u,
                                formattedAltPrice: k
                            };
                            r.push(this._makeSubAction(e, -1, 4, i, t, s))
                        }
                    } else {
                        if (S) {
                            const i = {
                                price: l,
                                formattedPrice: y
                            };
                            r.push(this._makeSubAction(e, -1, 1, i, t, s))
                        }
                        if (P) {
                            const i = {
                                price: a,
                                formattedPrice: b
                            };
                            r.push(this._makeSubAction(e, -1, 3, i, t, s))
                        }
                        if (C || P) {
                            const i = {
                                price: c,
                                formattedPrice: v
                            };
                            r.push(this._makeSubAction(e, 1, 3, i, t, s))
                        }
                        if (B) {
                            const i = {
                                price: c,
                                formattedPrice: v,
                                altPrice: d,
                                formattedAltPrice: f
                            };
                            r.push(this._makeSubAction(e, 1, 4, i, t, s))
                        }
                    }
                    return r
                }
                _initPaidBrokersByUserRegion() {
                    this._brokersListPromise = fetch("/api/v1/brokers/trading_panel", {
                        method: "GET"
                    }).then(e => e.json()).catch(e => {
                        oi.logWarn("Failed to fetch brokers info: " + e)
                    })
                }
                async _getBrokerPlans() {
                    let e = [];
                    try {
                        if (e = await this._brokersListPromise, !Array.isArray(e)) throw new Error("Request result is not valid")
                    } catch (e) {
                        oi.logError("Failed to fetch broker list by user region: " + e.message)
                    }
                    return e
                }
                async _checkCQGCredentials(e) {}
                _showSupportDialog(e) {
                    e in ai ? showSupportDialog({
                        initialState: SolutionCategoryName.Trading,
                        solutionId: ai[e]
                    }) : showSupportDialog({
                        initialState: SolutionCategoryName.Trading
                    })
                }
                async _showRestoreConfirmations() {
                    const e = await (0, Be.showSimpleConfirmDialog)({
                        title: (0, s.t)("Restore confirmations"),
                        text: (0, s.t)("Are you confirming you'd like to restore order confirmations, which you've previously disabled?"),
                        mainButtonIntent: "primary"
                    });
                    null !== this._activeBroker && e && (new xt.DisabledConfirmations).clear()
                }
                _logOut(e, t, i) {
                    const s = (0, a.ensureNotNull)(this._activeBroker);
                    s.connectionStatusUpdate.unsubscribe(this, this._connectionListener), s.currentAccountUpdate.unsubscribe(this, this._onCurrentAccountUpdate), this._realtimeProvider.onStatusChanged.unsubscribe(null, this._setPipValueType), r.linking.proSymbol.unsubscribe(this._setPipValueType), this._realtimeProvider.onStatusChanged.unsubscribe(null, this._trackNonTradableSymbol), r.linking.proSymbol.unsubscribe(this._trackNonTradableSymbol), s.disconnect(t || !e), s.destroy(), this._activeBroker = null, this._updateConnectionStatus(3, e, i)
                }
                async _createTradedItemsChartCollectionFacade(e) {
                    return new((await i.e(2650).then(i.bind(i, 15479))).TradedItemsChartCollectionFacade)(e)
                }
            }
        },
        49984: (e, t, i) => {
            "use strict";
            i.d(t, {
                abbreviatedNumber: () => o
            });
            var s = i(8329);
            const r = ["", "K", "M", "G", "T", "Y"];

            function o(e) {
                if (e < 1) return s.NumericFormatter.formatNoE(e);
                let t = 0,
                    i = +e;
                if (isFinite(i))
                    for (; i >= 1e3 && i % 100 == 0;) t++, i /= 1e3;
                return i + (t < r.length ? r[t] : "e" + 3 * t)
            }
        },
        47152: (e, t, i) => {
            "use strict";

            function s(e) {
                let t = null;
                return (i, ...s) => (null == t || t.abort(), t = new AbortController, null == i || i.addEventListener("error", () => null == t ? void 0 : t.abort(), {
                    once: !0
                }), e(t.signal, ...s))
            }

            function r(e) {
                if (!l(e)) throw e
            }

            function o(e) {
                if (l(e)) throw e
            }

            function n(e) {
                return (null == e ? void 0 : e.aborted) ? Promise.reject(a()) : new Promise((t, i) => {
                    null == e || e.addEventListener("abort", () => i(a()), {
                        once: !0
                    })
                })
            }

            function a() {
                return new DOMException("Aborted", "AbortError")
            }

            function l(e) {
                return e instanceof Error && "AbortError" === e.name
            }

            function c(e, t) {
                return Promise.race([n(e), t])
            }
            async function d(e, t) {
                let i;
                try {
                    await c(e, new Promise(e => {
                        i = setTimeout(e, t)
                    }))
                } finally {
                    clearTimeout(i)
                }
            }
            i.d(t, {
                respectLatest: () => s,
                skipAbortError: () => r,
                rethrowAbortError: () => o,
                isAbortError: () => l,
                respectAbort: () => c,
                delay: () => d
            })
        },
        33054: (e, t, i) => {
            "use strict";
            i.d(t, {
                mediaQueryAddEventListener: () => s,
                mediaQueryRemoveEventListener: () => r
            });
            const s = (e, t) => {
                    (null == e ? void 0 : e.addEventListener) ? e.addEventListener("change", t): e.addListener(t)
                },
                r = (e, t) => {
                    (null == e ? void 0 : e.removeEventListener) ? e.removeEventListener("change", t): e.removeListener(t)
                }
        },
        63329: (e, t, i) => {
            "use strict";

            function s(e) {
                let t = Promise.resolve();
                return function(...i) {
                    const s = t.then(() => e.apply(this, i));
                    return t = s.catch(() => {}), s
                }
            }
            i.d(t, {
                sequentialize: () => s
            })
        },
        21709: (e, t, i) => {
            "use strict";

            function s(e, t, i, s, r) {
                function o(r) {
                    if (e > r.timeStamp) return;
                    const o = r.target;
                    void 0 !== i && null !== t && null !== o && o.ownerDocument === s && (t.contains(o) || i(r))
                }
                return r.click && s.addEventListener("click", o, !1), r.mouseDown && s.addEventListener("mousedown", o, !1), r.touchEnd && s.addEventListener("touchend", o, !1), r.touchStart && s.addEventListener("touchstart", o, !1), () => {
                    s.removeEventListener("click", o, !1), s.removeEventListener("mousedown", o, !1), s.removeEventListener("touchend", o, !1), s.removeEventListener("touchstart", o, !1)
                }
            }
            i.d(t, {
                addOutsideEventListener: () => s
            })
        },
        85089: (e, t, i) => {
            "use strict";
            i.d(t, {
                setFixedBodyState: () => l
            });
            var s = i(35922);
            const r = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                o = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let n = 0,
                a = !1;

            function l(e) {
                const {
                    body: t
                } = document, i = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++n) {
                    const e = (0, s.getCSSProperty)(t, "overflow"),
                        r = (0, s.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, s.setStyle)(i, "right", (0, s.getScrollbarWidth)() + "px"), t.style.paddingRight = r + (0, s.getScrollbarWidth)() + "px", a = !0), t.classList.add("i-no-scroll")
                } else if (!e && n > 0 && 0 == --n && (t.classList.remove("i-no-scroll"), a)) {
                    (0, s.setStyle)(i, "right", "0px");
                    let e = 0;
                    e = i ? (l = (0, s.getContentWidth)(i), r() ? 0 : o() ? 46 : Math.min(Math.max(l, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, s.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", a = !1
                }
                var l
            }
        },
        52275: (e, t, i) => {
            "use strict";
            i.d(t, {
                saveTextFile: () => r,
                escapeCSVValue: () => l
            });
            var s = i(1227);

            function r(e, t, i = "text/plain") {
                const r = new Blob([t], {
                    type: i
                });
                if (s.CheckMobile.iOS()) {
                    const t = new FileReader;
                    return t.onload = () => {
                        t.result && o(e, t.result.toString())
                    }, void t.readAsDataURL(r)
                }
                const n = window.URL.createObjectURL(r);
                navigator.msSaveOrOpenBlob ? navigator.msSaveOrOpenBlob(r, e) : window.navigator.msSaveBlob ? window.navigator.msSaveBlob(r, e) : (o(e, n), window.URL.revokeObjectURL(n))
            }

            function o(e, t) {
                const i = document.createElement("a");
                i.style.display = "none", document.body.appendChild(i), i.href = t, i.download = e, i.click(), document.body.removeChild(i)
            }
            const n = /[",\r\n]/,
                a = /"/g;

            function l(e) {
                return n.test(e) ? `"${e.replace(a,'""')}"` : e
            }
        },
        90787: (e, t, i) => {
            "use strict";

            function s(e, t) {
                null === e.firstChild ? e.textContent = t : e.firstChild.nodeValue = t
            }
            i.d(t, {
                updateTextNode: () => s
            })
        },
        96038: (e, t, i) => {
            "use strict";
            i.d(t, {
                DialogBreakpoints: () => r
            });
            var s = i(96746);
            const r = {
                SmallHeight: s["small-height-breakpoint"],
                TabletSmall: s["tablet-small-breakpoint"],
                TabletNormal: s["tablet-normal-breakpoint"]
            }
        },
        53337: (e, t, i) => {
            "use strict";
            i.d(t, {
                AdaptivePopupDialog: () => P
            });
            var s = i(59496),
                r = i(88537),
                o = i(33054),
                n = i(97754),
                a = i.n(n),
                l = i(80185),
                c = i(98043),
                d = i(40766),
                u = i(94707),
                h = i(96038),
                p = i(30052),
                _ = i(10549),
                g = i(6594),
                m = i(59410),
                b = i(72571),
                y = i(90410),
                v = i(35487),
                f = i(91441);

            function k(e) {
                const {
                    title: t,
                    subtitle: i,
                    showCloseIcon: r = !0,
                    onClose: o,
                    renderBefore: n,
                    renderAfter: l,
                    draggable: c,
                    className: d,
                    unsetAlign: u
                } = e, [h, p] = (0, s.useState)(!1);
                return s.createElement(y.DialogHeaderContext.Provider, {
                    value: {
                        setHideClose: p
                    }
                }, s.createElement("div", {
                    className: a()(f.container, d, (i || u) && f.unsetAlign)
                }, n, s.createElement("div", {
                    "data-dragg-area": c,
                    className: f.title
                }, s.createElement("div", {
                    className: f.ellipsis
                }, t), i && s.createElement("div", {
                    className: a()(f.ellipsis, f.subtitle)
                }, i)), l, r && !h && s.createElement(b.Icon, {
                    className: f.close,
                    icon: v,
                    onClick: o,
                    "data-name": "close",
                    "data-role": "button"
                })))
            }
            var w = i(67179);
            const S = {
                    vertical: 20
                },
                C = {
                    vertical: 0
                };
            class P extends s.PureComponent {
                constructor() {
                    super(...arguments), this._controller = null, this._reference = null, this._orientationMediaQuery = null, this._renderChildren = (e, t) => (this._controller = e, this.props.render({
                        requestResize: this._requestResize,
                        centerAndFit: this._centerAndFit,
                        isSmallWidth: t
                    })), this._handleReference = e => this._reference = e, this._handleClose = () => {
                        this.props.onClose()
                    }, this._handleOpen = () => {
                        void 0 !== this.props.onOpen && this.props.isOpened && this.props.onOpen(this.props.fullScreen || window.matchMedia(h.DialogBreakpoints.TabletSmall).matches)
                    }, this._handleKeyDown = e => {
                        var t;
                        if (!e.defaultPrevented) switch (this.props.onKeyDown && this.props.onKeyDown(e), (0, l.hashFromEvent)(e)) {
                            case 27:
                                if (e.defaultPrevented) return;
                                if (this.props.forceCloseOnEsc && this.props.forceCloseOnEsc()) return void this._handleClose();
                                const {
                                    activeElement: i
                                } = document, s = (0, r.ensureNotNull)(this._reference);
                                if (null !== i) {
                                    if (e.preventDefault(), "true" === (t = i).getAttribute("data-haspopup") && "true" !== t.getAttribute("data-expanded")) return void this._handleClose();
                                    if ((0, c.isTextEditingField)(i)) return void s.focus();
                                    if (s.contains(i)) return void this._handleClose()
                                }
                        }
                    }, this._requestResize = () => {
                        null !== this._controller && this._controller.recalculateBounds()
                    }, this._centerAndFit = () => {
                        null !== this._controller && this._controller.centerAndFit()
                    }
                }
                componentDidMount() {
                    m.subscribe(g.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), this._handleOpen(), void 0 !== this.props.onOpen && (this._orientationMediaQuery = window.matchMedia("(orientation: portrait)"), (0, o.mediaQueryAddEventListener)(this._orientationMediaQuery, this._handleOpen))
                }
                componentWillUnmount() {
                    m.unsubscribe(g.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), null !== this._orientationMediaQuery && (0,
                        o.mediaQueryRemoveEventListener)(this._orientationMediaQuery, this._handleOpen)
                }
                focus() {
                    (0, r.ensureNotNull)(this._reference).focus()
                }
                getElement() {
                    return this._reference
                }
                contains(e) {
                    var t, i;
                    return null !== (i = null === (t = this._reference) || void 0 === t ? void 0 : t.contains(e)) && void 0 !== i && i
                }
                render() {
                    const {
                        className: e,
                        wrapperClassName: t,
                        headerClassName: i,
                        isOpened: r,
                        title: o,
                        dataName: n,
                        onClickOutside: l,
                        additionalElementPos: c,
                        additionalHeaderElement: g,
                        backdrop: m,
                        shouldForceFocus: b = !0,
                        showSeparator: y,
                        subtitle: v,
                        draggable: f = !0,
                        fullScreen: P = !1,
                        showCloseIcon: B = !0,
                        rounded: T = !0,
                        isAnimationEnabled: E,
                        growPoint: L,
                        dialogTooltip: O,
                        unsetHeaderAlign: D,
                        onDragStart: I,
                        dataDialogName: N
                    } = this.props, A = "after" !== c ? g : void 0, M = "after" === c ? g : void 0, V = "string" == typeof o ? o : N || "";
                    return s.createElement(p.MatchMedia, {
                        rule: h.DialogBreakpoints.SmallHeight
                    }, c => s.createElement(p.MatchMedia, {
                        rule: h.DialogBreakpoints.TabletSmall
                    }, h => s.createElement(d.PopupDialog, {
                        rounded: !(h || P) && T,
                        className: a()(w.dialog, e),
                        isOpened: r,
                        reference: this._handleReference,
                        onKeyDown: this._handleKeyDown,
                        onClickOutside: l,
                        onClickBackdrop: l,
                        fullscreen: h || P,
                        guard: c ? C : S,
                        boundByScreen: h || P,
                        shouldForceFocus: b,
                        backdrop: m,
                        draggable: f,
                        isAnimationEnabled: E,
                        growPoint: L,
                        name: this.props.dataName,
                        dialogTooltip: O,
                        onDragStart: I
                    }, s.createElement("div", {
                        className: a()(w.wrapper, t),
                        "data-name": n,
                        "data-dialog-name": V
                    }, void 0 !== o && s.createElement(k, {
                        draggable: f && !(h || P),
                        onClose: this._handleClose,
                        renderAfter: M,
                        renderBefore: A,
                        subtitle: v,
                        title: o,
                        showCloseIcon: B,
                        className: i,
                        unsetAlign: D
                    }), y && s.createElement(u.Separator, {
                        className: w.separator
                    }), s.createElement(_.PopupContext.Consumer, null, e => this._renderChildren(e, h || P))))))
                }
            }
        },
        90410: (e, t, i) => {
            "use strict";
            i.d(t, {
                DialogHeaderContext: () => s
            });
            const s = i(59496).createContext({
                setHideClose: () => {}
            })
        },
        61174: (e, t, i) => {
            "use strict";
            i.d(t, {
                useOutsideEvent: () => o
            });
            var s = i(59496),
                r = i(21709);

            function o(e) {
                const {
                    click: t,
                    mouseDown: i,
                    touchEnd: o,
                    touchStart: n,
                    handler: a,
                    reference: l,
                    ownerDocument: c = document
                } = e, d = (0, s.useRef)(null), u = (0, s.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, s.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: i,
                            touchEnd: o,
                            touchStart: n
                        },
                        s = l ? l.current : d.current;
                    return (0, r.addOutsideEventListener)(u.current, s, a, c, e)
                }, [t, i, o, n, a]), l || d
            }
        },
        30052: (e, t, i) => {
            "use strict";
            i.d(t, {
                MatchMedia: () => r
            });
            var s = i(59496);
            class r extends s.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        94707: (e, t, i) => {
            "use strict";
            i.d(t, {
                Separator: () => n
            });
            var s = i(59496),
                r = i(97754),
                o = i(91626);

            function n(e) {
                return s.createElement("div", {
                    className: r(o.separator, e.className)
                })
            }
        },
        63212: (e, t, i) => {
            "use strict";
            i.d(t, {
                OverlapManager: () => o,
                getRootOverlapManager: () => a
            });
            var s = i(88537);
            class r {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class o {
                constructor(e = document) {
                    this._storage = new r, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        i = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, i), this._container = i
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const i = this._windows.get(e);
                    if (void 0 !== i) return i;
                    this.registerWindow(e);
                    const s = this._document.createElement("div");
                    if (s.style.position = t.position, s.style.zIndex = this._index.toString(), s.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(s);
                        else if (t.index <= 0) this._container.insertBefore(s, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(s, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(s, this._container.firstChild) : this._container.appendChild(s);
                    return this._windows.set(e, s), ++this._index, s
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const n = new WeakMap;

            function a(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, s.ensureDefined)(n.get(t)); {
                    const t = new o(e),
                        i = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return n.set(i, t), t.setContainer(i), e.body.appendChild(i), t
                }
            }
        },
        8361: (e, t, i) => {
            "use strict";
            i.d(t, {
                Portal: () => l,
                PortalContext: () => c
            });
            var s = i(59496),
                r = i(87995),
                o = i(16345),
                n = i(63212),
                a = i(53327);
            class l extends s.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, o.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", r.createPortal(s.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, n.getRootOverlapManager)() : this.context
                }
            }
            l.contextType = a.SlotContext;
            const c = s.createContext(null)
        },
        53327: (e, t, i) => {
            "use strict";
            i.d(t, {
                Slot: () => r,
                SlotContext: () => o
            });
            var s = i(59496);
            class r extends s.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return s.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const o = s.createContext(null)
        },
        32455: (e, t, i) => {
            "use strict";
            i.d(t, {
                Spinner: () => n
            });
            var s = i(59496),
                r = i(97754),
                o = i(63654);
            i(24780);

            function n(e) {
                const t = r(e.className, "tv-spinner", "tv-spinner--shown", "tv-spinner--size_" + o.spinnerSizeMap[e.size || o.DEFAULT_SIZE]);
                return s.createElement("div", {
                    className: t,
                    style: e.style,
                    role: "progressbar"
                })
            }
        },
        6056: (e, t, i) => {
            "use strict";
            var s, r;
            i.d(t, {
                    ToastAnimationStage: () => s,
                    ToastPriority: () => r
                }),
                function(e) {
                    e[e.Add = 0] = "Add", e[e.Remove = 1] = "Remove", e[e.None = 2] = "None"
                }(s || (s = {})),
                function(e) {
                    e[e.Low = 0] = "Low", e[e.Medium = 1] = "Medium", e[e.High = 2] = "High"
                }(r || (r = {}))
        },
        57047: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M19.9792 16.6205C19.7396 16.8955 19.3241 16.9285 19.044 16.6948L14.3924 12.8117L14.072 12.5442L13.7516 12.8117L9.10009 16.6947C8.82008 16.9285 8.40456 16.8955 8.16495 16.6205C7.92467 16.3447 7.94981 15.9272 8.22144 15.6822L14.0721 10.4057L19.9227 15.6822C20.1943 15.9272 20.2195 16.3447 19.9792 16.6205ZM18.4032 17.4624C19.1009 18.0448 20.1362 17.9626 20.7332 17.2774C21.3318 16.5902 21.2692 15.55 20.5924 14.9396L14.407 9.36109L14.0721 9.05908L13.7373 9.36109L7.55171 14.9396C6.87492 15.55 6.81229 16.5902 7.41096 17.2774C8.00796 17.9626 9.04326 18.0448 9.74094 17.4624L14.072 13.8468L18.4032 17.4624Z"/></svg>'
        },
        57025: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M19.9792 12.2892C19.7396 12.0142 19.3241 11.9812 19.044 12.2149L14.3924 16.098L14.072 16.3655L13.7516 16.098L9.10009 12.2149C8.82008 11.9812 8.40456 12.0142 8.16495 12.2892C7.92467 12.565 7.94981 12.9825 8.22144 13.2275L14.0721 18.504L19.9227 13.2275C20.1943 12.9825 20.2195 12.565 19.9792 12.2892ZM18.4032 11.4472C19.1009 10.8648 20.1362 10.9471 20.7332 11.6323C21.3318 12.3195 21.2692 13.3597 20.5924 13.9701L14.407 19.5486L14.0721 19.8506L13.7373 19.5486L7.55171 13.9701C6.87492 13.3597 6.81229 12.3195 7.41096 11.6323C8.00796 10.9471 9.04326 10.8648 9.74094 11.4473L14.072 15.0628L18.4032 11.4472Z"/></svg>'
        },
        35487: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        38212: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" width="72" height="72" fill="none"><g clip-path="url(#clip0)"><path fill="#363A45" fill-rule="evenodd" clip-rule="evenodd" d="M62.1259 28.2153C61.4066 28.8157 61.0001 29.7273 61.0858 30.6604C61.6716 37.0347 59.7763 44.3291 55.3181 50.8221C46.9016 63.0797 32.5383 67.839 23.2366 61.4522C13.935 55.0654 13.2174 39.9512 21.6339 27.6935C26.4984 20.6088 33.3496 16.029 40.0619 14.6585C40.9752 14.472 41.731 13.8291 42.1024 12.9741C42.485 12.0934 42.9606 11.2346 43.5313 10.4123C47.906 4.1093 56.2129 2.33004 62.0853 6.4382C67.9578 10.5464 69.172 18.9863 64.7974 25.2892C64.0194 26.4103 63.1169 27.3882 62.1259 28.2153Z"/><rect width="47.2" height="34" fill="#1E222D" stroke="#B2B5BE" stroke-width="2" rx="3.8" x="12.4004" y="16"/><path stroke="#B2B5BE" stroke-linecap="round" stroke-width="2" d="M3.59961 54H67.1996"/><path fill="#B2B5BE" fill-rule="evenodd" clip-rule="evenodd" d="M29.1178 31.1324L30.8107 32.8253L32.225 31.4111L30.5321 29.7182L32.225 28.0253L30.8107 26.6111L29.1178 28.304L27.425 26.6111L26.0107 28.0253L27.7036 29.7182L26.0107 31.4111L27.425 32.8253L29.1178 31.1324Z"/><path fill="#B2B5BE" fill-rule="evenodd" clip-rule="evenodd" d="M43.5182 31.1324L45.2111 32.8253L46.6253 31.4111L44.9325 29.7182L46.6253 28.0253L45.2111 26.6111L43.5182 28.304L41.8253 26.6111L40.4111 28.0253L42.104 29.7182L40.4111 31.4111L41.8253 32.8253L43.5182 31.1324Z"/><path stroke="#B2B5BE" stroke-width="2" d="M30.5996 38.7H40.7996"/></g></svg>'
        },
        22987: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 72" width="72" height="72" fill="none"><g clip-path="url(#clip0)"><path fill="#F0F3FA" fill-rule="evenodd" clip-rule="evenodd" d="M62.1259 28.2153C61.4066 28.8157 61.0001 29.7273 61.0858 30.6604C61.6716 37.0347 59.7763 44.3291 55.3181 50.8221C46.9016 63.0797 32.5383 67.839 23.2366 61.4522C13.935 55.0654 13.2174 39.9512 21.6339 27.6935C26.4984 20.6088 33.3496 16.029 40.0619 14.6585C40.9752 14.472 41.731 13.8291 42.1024 12.9741C42.485 12.0934 42.9606 11.2346 43.5313 10.4123C47.906 4.1093 56.2129 2.33004 62.0853 6.4382C67.9578 10.5464 69.172 18.9863 64.7974 25.2892C64.0194 26.4103 63.1169 27.3882 62.1259 28.2153Z"/><rect width="47.2" height="34" fill="#fff" stroke="#1E222D" stroke-width="2" rx="3.8" x="12.4004" y="16"/><path stroke="#1E222D" stroke-linecap="round" stroke-width="2" d="M3.59961 54H67.1996"/><path fill="#000" fill-rule="evenodd" clip-rule="evenodd" d="M29.1178 31.1324L30.8107 32.8253L32.225 31.4111L30.5321 29.7182L32.225 28.0253L30.8107 26.6111L29.1178 28.304L27.425 26.6111L26.0107 28.0253L27.7036 29.7182L26.0107 31.4111L27.425 32.8253L29.1178 31.1324Z"/><path fill="#000" fill-rule="evenodd" clip-rule="evenodd" d="M43.5182 31.1324L45.2111 32.8253L46.6253 31.4111L44.9325 29.7182L46.6253 28.0253L45.2111 26.6111L43.5182 28.304L41.8253 26.6111L40.4111 28.0253L42.104 29.7182L40.4111 31.4111L41.8253 32.8253L43.5182 31.1324Z"/><path stroke="#000" stroke-width="2" d="M30.5996 38.7H40.7996"/></g></svg>'
        },
        72036: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 16" width="20" height="16"><path fill="currentColor" fill-rule="evenodd" d="M7.5 2.5C7.5 1.67 8.17 1 9 1h2c.83 0 1.5.67 1.5 1.5v.15h-5V2.5zm6 0v.15H17a2.5 2.5 0 0 1 2.5 2.5v8.35A2.5 2.5 0 0 1 17 16H3a2.5 2.5 0 0 1-2.5-2.5V5.15A2.5 2.5 0 0 1 3 2.65h3.5V2.5A2.5 2.5 0 0 1 9 0h2a2.5 2.5 0 0 1 2.5 2.5zm-12 2.65c0-.83.67-1.5 1.5-1.5h14c.83 0 1.5.67 1.5 1.5v8.35c0 .83-.67 1.5-1.5 1.5H3a1.5 1.5 0 0 1-1.5-1.5V5.15zM9.25 6.5a1.75 1.75 0 1 0 0 3.5h1.5a.75.75 0 0 1 0 1.5h-1.5a.75.75 0 0 1-.75-.75h-1c0 .97.78 1.75 1.75 1.75h.25v1h1v-1h.25a1.75 1.75 0 1 0 0-3.5h-1.5a.75.75 0 0 1 0-1.5h1.5c.41 0 .75.34.75.75h1c0-.97-.78-1.75-1.75-1.75h-.25v-1h-1v1h-.25z"/></svg>'
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [6872], {
        71091: () => {},
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        40367: e => {
            e.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => r
            });
            var o = n(59496);
            const r = o.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...r
                } = e;
                return o.createElement("span", { ...r,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        417: (e, t, n) => {
            "use strict";

            function o(e) {
                return i(e, s)
            }

            function r(e) {
                return i(e, l)
            }

            function i(e, t) {
                const n = Object.entries(e).filter(t),
                    o = {};
                for (const [e, t] of n) o[e] = t;
                return o
            }

            function s(e) {
                const [t, n] = e;
                return 0 === t.indexOf("data-") && "string" == typeof n
            }

            function l(e) {
                return 0 === e[0].indexOf("aria-")
            }
            n.d(t, {
                filterDataProps: () => o,
                filterAriaProps: () => r,
                filterProps: () => i,
                isDataAttribute: () => s,
                isAriaAttribute: () => l
            })
        },
        85673: (e, t, n) => {
            "use strict";
            n.d(t, {
                VerticalAttachEdge: () => o,
                HorizontalAttachEdge: () => r,
                VerticalDropDirection: () => i,
                HorizontalDropDirection: () => s,
                getPopupPositioner: () => c
            });
            var o, r, i, s, l = n(88537);
            ! function(e) {
                e[e.Top = 0] = "Top", e[e.Bottom = 1] = "Bottom"
            }(o || (o = {})),
            function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(r || (r = {})),
            function(e) {
                e[e.FromTopToBottom = 0] = "FromTopToBottom", e[e.FromBottomToTop = 1] = "FromBottomToTop"
            }(i || (i = {})),
            function(e) {
                e[e.FromLeftToRight = 0] = "FromLeftToRight", e[e.FromRightToLeft = 1] = "FromRightToLeft"
            }(s || (s = {}));
            const a = {
                verticalAttachEdge: o.Bottom,
                horizontalAttachEdge: r.Left,
                verticalDropDirection: i.FromTopToBottom,
                horizontalDropDirection: s.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function c(e, t) {
                return (n, c) => {
                    const u = (0, l.ensureNotNull)(e).getBoundingClientRect(),
                        {
                            verticalAttachEdge: d = a.verticalAttachEdge,
                            verticalDropDirection: h = a.verticalDropDirection,
                            horizontalAttachEdge: p = a.horizontalAttachEdge,
                            horizontalDropDirection: m = a.horizontalDropDirection,
                            horizontalMargin: f = a.horizontalMargin,
                            verticalMargin: g = a.verticalMargin,
                            matchButtonAndListboxWidths: v = a.matchButtonAndListboxWidths
                        } = t,
                        _ = d === o.Top ? -1 * g : g,
                        x = p === r.Right ? u.right : u.left,
                        C = d === o.Top ? u.top : u.bottom,
                        w = {
                            x: x - (m === s.FromRightToLeft ? n : 0) + f,
                            y: C - (h === i.FromBottomToTop ? c : 0) + _
                        };
                    return v && (w.overrideWidth = u.width), w
                }
            }
        },
        33054: (e, t, n) => {
            "use strict";
            n.d(t, {
                mediaQueryAddEventListener: () => o,
                mediaQueryRemoveEventListener: () => r
            });
            const o = (e, t) => {
                    (null == e ? void 0 : e.addEventListener) ? e.addEventListener("change", t): e.addListener(t)
                },
                r = (e, t) => {
                    (null == e ? void 0 : e.removeEventListener) ? e.removeEventListener("change", t): e.removeListener(t)
                }
        },
        21709: (e, t, n) => {
            "use strict";

            function o(e, t, n, o, r) {
                function i(r) {
                    if (e > r.timeStamp) return;
                    const i = r.target;
                    void 0 !== n && null !== t && null !== i && i.ownerDocument === o && (t.contains(i) || n(r))
                }
                return r.click && o.addEventListener("click", i, !1), r.mouseDown && o.addEventListener("mousedown", i, !1), r.touchEnd && o.addEventListener("touchend", i, !1), r.touchStart && o.addEventListener("touchstart", i, !1), () => {
                    o.removeEventListener("click", i, !1), o.removeEventListener("mousedown", i, !1), o.removeEventListener("touchend", i, !1), o.removeEventListener("touchstart", i, !1)
                }
            }
            n.d(t, {
                addOutsideEventListener: () => o
            })
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => a
            });
            var o = n(35922);
            const r = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                i = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let s = 0,
                l = !1;

            function a(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++s) {
                    const e = (0, o.getCSSProperty)(t, "overflow"),
                        r = (0, o.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, o.setStyle)(n, "right", (0, o.getScrollbarWidth)() + "px"), t.style.paddingRight = r + (0, o.getScrollbarWidth)() + "px", l = !0), t.classList.add("i-no-scroll")
                } else if (!e && s > 0 && 0 == --s && (t.classList.remove("i-no-scroll"), l)) {
                    (0, o.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (a = (0, o.getContentWidth)(n), r() ? 0 : i() ? 46 : Math.min(Math.max(a, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, o.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", l = !1
                }
                var a
            }
        },
        72476: (e, t, n) => {
            "use strict";
            n.d(t, {
                CircleLogo: () => i
            });
            var o = n(59496),
                r = n(97754);
            n(71091);

            function i(e) {
                var t, n;
                const i = (s = e.size, l = e.className, r("tv-circle-logo", "tv-circle-logo--" + s, l));
                var s, l;
                const a = null !== (n = null !== (t = e.alt) && void 0 !== t ? t : e.title) && void 0 !== n ? n : "";
                return function(e) {
                    return "logoUrl" in e && void 0 !== e.logoUrl && 0 !== e.logoUrl.length
                }(e) ? o.createElement("img", {
                    className: i,
                    src: e.logoUrl,
                    alt: a,
                    title: e.title,
                    loading: e.loading
                }) : o.createElement("span", {
                    className: i,
                    title: e.title
                }, e.placeholderLetter)
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => i
            });
            var o = n(59496),
                r = n(21709);

            function i(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: i,
                    touchStart: s,
                    handler: l,
                    reference: a,
                    ownerDocument: c = document
                } = e, u = (0, o.useRef)(null), d = (0, o.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, o.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: i,
                            touchStart: s
                        },
                        o = a ? a.current : u.current;
                    return (0, r.addOutsideEventListener)(d.current, o, l, c, e)
                }, [t, n, i, s, l]), a || u
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => r
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        30553: (e, t, n) => {
            "use strict";
            n.d(t, {
                MenuContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        10618: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_MENU_THEME: () => g,
                Menu: () => v
            });
            var o = n(59496),
                r = n(97754),
                i = n.n(r),
                s = n(88537),
                l = n(97280),
                a = n(12777),
                c = n(53327),
                u = n(70981),
                d = n(63212),
                h = n(82027),
                p = n(94488),
                m = n(30553),
                f = n(16059);
            const g = f;
            class v extends o.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new d.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                        this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                    }, this._handleScrollWrapRef = e => {
                        this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                    }, this._handleMeasure = ({
                        callback: e,
                        forceRecalcPosition: t
                    } = {}) => {
                        var n, o, r, i;
                        if (this.state.isMeasureValid && !t) return;
                        const {
                            position: a
                        } = this.props, c = (0, s.ensureNotNull)(this._containerRef);
                        let u = c.getBoundingClientRect();
                        const d = document.documentElement.clientHeight,
                            h = document.documentElement.clientWidth,
                            p = null !== (n = this.props.closeOnScrollOutsideOffset) && void 0 !== n ? n : 0;
                        let m = d - 0 - p;
                        const f = u.height > m;
                        if (f) {
                            (0, s.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", u = c.getBoundingClientRect()
                        }
                        const {
                            width: g,
                            height: v
                        } = u, _ = "function" == typeof a ? a(g, v, d) : a, x = h - (null !== (o = _.overrideWidth) && void 0 !== o ? o : g) - 0, C = (0, l.clamp)(_.x, 0, Math.max(0, x)), w = 0 + p, y = d - (null !== (r = _.overrideHeight) && void 0 !== r ? r : v) - 0;
                        let E = (0, l.clamp)(_.y, w, Math.max(w, y));
                        if (_.forbidCorrectYCoord && E < _.y && (m -= _.y - E, E = _.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && _.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                        const M = null !== (i = _.overrideHeight) && void 0 !== i ? i : f ? m : void 0;
                        this.setState({
                            appearingMenuHeight: t ? this.state.appearingMenuHeight : M,
                            appearingMenuWidth: t ? this.state.appearingMenuWidth : _.overrideWidth,
                            appearingPosition: {
                                x: C,
                                y: E
                            },
                            isMeasureValid: !0
                        }, () => {
                            this._restoreScrollPosition(), e && e()
                        })
                    }, this._restoreScrollPosition = () => {
                        const e = document.activeElement,
                            t = (0, s.ensureNotNull)(this._containerRef);
                        if (null !== e && t.contains(e)) try {
                            e.scrollIntoView()
                        } catch (e) {} else(0, s.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                    }, this._resizeForced = () => {
                        this.setState({
                            appearingMenuHeight: void 0,
                            appearingMenuWidth: void 0,
                            appearingPosition: void 0,
                            isMeasureValid: void 0
                        })
                    }, this._resize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            }), this._raf = null
                        }))
                    }, this._handleGlobalClose = e => {
                        this.props.onClose(e)
                    }, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }, this._handleScroll = () => {
                        this._scroll = (0, s.ensureNotNull)(this._scrollWrapRef).scrollTop
                    }, this._handleScrollOutsideEnd = () => {
                        clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            })
                        }, 80)
                    }, this._handleScrollOutside = e => {
                        e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            }), this._scrollRaf = null
                        })))
                    }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = h.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        children: s,
                        minWidth: l,
                        theme: u = f,
                        className: d,
                        maxHeight: h,
                        onMouseOver: g,
                        onMouseOut: v,
                        onKeyDown: x,
                        onFocus: C,
                        onBlur: w
                    } = this.props, {
                        appearingMenuHeight: y,
                        appearingMenuWidth: E,
                        appearingPosition: M,
                        isMeasureValid: b
                    } = this.state;
                    return o.createElement(m.MenuContext.Provider, {
                        value: this
                    }, o.createElement(p.SubmenuHandler, null, o.createElement(c.SlotContext.Provider, {
                        value: this._manager
                    }, o.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        className: i()(d, u.menuWrap, !b && u.isMeasuring),
                        style: {
                            height: y,
                            left: M && M.x,
                            minWidth: l,
                            position: "fixed",
                            top: M && M.y,
                            width: E
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: a.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: g,
                        onMouseOut: v,
                        onKeyDown: x,
                        onFocus: C,
                        onBlur: w
                    }, o.createElement("div", {
                        className: i()(u.scrollWrap, !this.props.noMomentumBasedScroll && u.momentumBased),
                        style: {
                            overflowY: void 0 !== y ? "scroll" : "auto",
                            maxHeight: h
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, o.createElement(_, {
                        className: u.menuBox
                    }, s)))), o.createElement(c.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function _(e) {
                const t = (0, s.ensureNotNull)((0, o.useContext)(p.SubmenuContext)),
                    n = o.useRef(null);
                return o.createElement("div", {
                    ref: n,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (o = e.target, null === (r = n.current) || void 0 === r ? void 0 : r.contains(o)))) return;
                        var o, r;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            v.contextType = p.SubmenuContext
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => i,
                getRootOverlapManager: () => l
            });
            var o = n(88537);
            class r {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class i {
                constructor(e = document) {
                    this._storage = new r, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const o = this._document.createElement("div");
                    if (o.style.position = t.position, o.style.zIndex = this._index.toString(), o.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(o);
                        else if (t.index <= 0) this._container.insertBefore(o, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(o, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(o, this._container.firstChild) : this._container.appendChild(o);
                    return this._windows.set(e, o), ++this._index, o
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const s = new WeakMap;

            function l(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, o.ensureDefined)(s.get(t)); {
                    const t = new i(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return s.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        28466: (e, t, n) => {
            "use strict";
            n.d(t, {
                CloseDelegateContext: () => i
            });
            var o = n(59496),
                r = n(70981);
            const i = o.createContext(r.globalCloseDelegate)
        },
        44377: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenu: () => c
            });
            var o = n(59496),
                r = n(87995),
                i = n(8361),
                s = n(10618),
                l = n(28466),
                a = n(61174);

            function c(e) {
                const {
                    controller: t,
                    children: n,
                    isOpened: c,
                    closeOnClickOutside: u = !0,
                    doNotCloseOn: d,
                    onClickOutside: h,
                    onClose: p,
                    ...m
                } = e, f = (0, o.useContext)(l.CloseDelegateContext), g = (0, a.useOutsideEvent)({
                    handler: function(e) {
                        h && h(e);
                        if (!u) return;
                        if (d && e.target instanceof Node) {
                            const t = r.findDOMNode(d);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        p()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return c ? o.createElement(i.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, o.createElement("span", {
                    ref: g,
                    style: {
                        pointerEvents: "auto"
                    }
                }, o.createElement(s.Menu, { ...m,
                    onClose: p,
                    onScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    },
                    customCloseDelegate: f,
                    ref: t
                }, n))) : null
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => a,
                PortalContext: () => c
            });
            var o = n(59496),
                r = n(87995),
                i = n(16345),
                s = n(63212),
                l = n(53327);
            class a extends o.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, i.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", r.createPortal(o.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, s.getRootOverlapManager)() : this.context
                }
            }
            a.contextType = l.SlotContext;
            const c = o.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => r,
                SlotContext: () => i
            });
            var o = n(59496);
            class r extends o.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return o.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const i = o.createContext(null)
        },
        94488: (e, t, n) => {
            "use strict";
            n.d(t, {
                SubmenuContext: () => r,
                SubmenuHandler: () => i
            });
            var o = n(59496);
            const r = o.createContext(null);

            function i(e) {
                const [t, n] = (0, o.useState)(null), i = (0, o.useRef)(null), s = (0, o.useRef)(new Map);
                return (0, o.useEffect)(() => () => {
                    null !== i.current && clearTimeout(i.current)
                }, []), o.createElement(r.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== i.current && (clearTimeout(i.current), i.current = null);
                            null === t ? n(e) : i.current = setTimeout(() => {
                                i.current = null, n(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return s.current.set(e, t), () => {
                                s.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(s.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        15783: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetCaret: () => a
            });
            var o = n(59496),
                r = n(97754),
                i = n(72571),
                s = n(40367),
                l = n(21538);

            function a(e) {
                const {
                    dropped: t,
                    className: n
                } = e;
                return o.createElement(i.Icon, {
                    className: r(n, s.icon, {
                        [s.dropped]: t
                    }),
                    icon: l
                })
            }
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        }
    }
]);
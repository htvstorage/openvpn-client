(() => {
    "use strict";
    var e, a, d, c, f = {},
        b = {};

    function t(e) {
        var a = b[e];
        if (void 0 !== a) return a.exports;
        var d = b[e] = {
            id: e,
            loaded: !1,
            exports: {}
        };
        return f[e].call(d.exports, d, d.exports, t), d.loaded = !0, d.exports
    }
    t.m = f, t.c = b, e = [], t.O = (a, d, c, f) => {
        if (!d) {
            var b = 1 / 0;
            for (n = 0; n < e.length; n++) {
                for (var [d, c, f] = e[n], r = !0, o = 0; o < d.length; o++)(!1 & f || b >= f) && Object.keys(t.O).every(e => t.O[e](d[o])) ? d.splice(o--, 1) : (r = !1, f < b && (b = f));
                if (r) {
                    e.splice(n--, 1);
                    var i = c();
                    void 0 !== i && (a = i)
                }
            }
            return a
        }
        f = f || 0;
        for (var n = e.length; n > 0 && e[n - 1][2] > f; n--) e[n] = e[n - 1];
        e[n] = [d, c, f]
    }, t.n = e => {
        var a = e && e.__esModule ? () => e.default : () => e;
        return t.d(a, {
            a
        }), a
    }, d = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__, t.t = function(e, c) {
        if (1 & c && (e = this(e)), 8 & c) return e;
        if ("object" == typeof e && e) {
            if (4 & c && e.__esModule) return e;
            if (16 & c && "function" == typeof e.then) return e
        }
        var f = Object.create(null);
        t.r(f);
        var b = {};
        a = a || [null, d({}), d([]), d(d)];
        for (var r = 2 & c && e;
            "object" == typeof r && !~a.indexOf(r); r = d(r)) Object.getOwnPropertyNames(r).forEach(a => b[a] = () => e[a]);
        return b.default = () => e, t.d(f, b), f
    }, t.d = (e, a) => {
        for (var d in a) t.o(a, d) && !t.o(e, d) && Object.defineProperty(e, d, {
            enumerable: !0,
            get: a[d]
        })
    }, t.f = {}, t.e = e => Promise.all(Object.keys(t.f).reduce((a, d) => (t.f[d](e, a), a), [])), t.u = e => (({
        92: "chart-screenshot-hint",
        139: "get-error-card",
        507: "study-pane-views",
        607: "study-property-pages-with-definitions",
        660: "order-view-controller",
        731: "add-compare-dialog",
        802: "logo-urls-resolver",
        1026: "symbol-list-service",
        1196: "watchlist-widget",
        1583: "lt-pane-views",
        1584: "context-menu-renderer",
        1702: "manage-drawings-dialog",
        1754: "symbol-search-dialog",
        1859: "go-to-date-dialog-impl",
        1890: "line-tools-icons",
        2077: "change-interval-dialog",
        2183: "study-inputs-pane-views",
        2306: "floating-toolbars",
        2377: "hammerjs",
        2650: "trading-custom-sources",
        2704: "currency-label-menu",
        2878: "drawing-toolbar",
        3005: "header-toolbar",
        3030: "new-confirm-inputs-dialog",
        3088: "chart-toasts",
        3168: "partially-closing-dialog-renderer",
        3177: "line-tool-templates-list",
        3541: "rest-broker",
        3566: "create-confirm-dialog",
        3596: "general-property-page",
        3718: "series-icons-map",
        3809: "trading-custom-widgets",
        4013: "custom-intervals-add-dialog",
        4079: "series-pane-views",
        4193: "bottom-widgetbar",
        4291: "global-toasts",
        4389: "take-chart-image-impl",
        4664: "news-description-dialog",
        4665: "share-chart-to-social-utils",
        4862: "object-tree-dialog",
        4876: "widgetbar",
        5001: "partially-closing-dialog",
        5009: "load-chart-dialog",
        5031: "object-tree-panel",
        5093: "chart-widget-gui",
        5142: "trading",
        5514: "react",
        5516: "restricted-toolset",
        5551: "favorite-drawings-api",
        6112: "leverage-dialog",
        6166: "chart-event-hint",
        6265: "new-edit-object-dialog",
        6456: "study-market",
        6631: "study-template-dialog",
        6780: "source-properties-editor",
        6991: "symbol-details",
        7078: "general-chart-properties-dialog",
        7102: "spinner-renderer",
        7260: "chart-bottom-toolbar",
        7271: "compare-model",
        7502: "order-widget",
        7636: "dome-panel",
        7648: "show-theme-save-dialog",
        7707: "footer-widget",
        8179: "terminal-configset",
        8354: "trading-account-manager",
        8537: "lt-property-pages-with-definitions",
        8643: "full-tooltips-popup",
        8751: "position-widget",
        8890: "simple-dialog",
        9039: "lollipop-tooltip-renderer",
        9374: "symbol-info-dialog-impl",
        9498: "export-data",
        9685: "redux"
    }[e] || e) + "." + {
        15: "d3625812a143f4ff427a",
        92: "c425dcb6469e44e206be",
        110: "e60cec4a49fe8d658397",
        137: "70e616fa55bcc40d9349",
        139: "bc16fe33d8f756dbe55c",
        323: "ecccd7e1c64eec3b91d6",
        348: "dcf88482f40a6cfaa4d7",
        419: "dc1b3ea65328bb498774",
        507: "799820cd52382f020a57",
        510: "0102fd6bc8a16d23190e",
        561: "277188b6bfcaf16e4baf",
        607: "dce430ad0a5a830fa5dd",
        660: "fbe04d81b440dac26088",
        710: "3f8dbedb0ec488342827",
        731: "6177a1cba050e073c6b1",
        766: "f2a984480cee5651fa75",
        775: "9af72d490eb67ba9c3d7",
        802: "5a5cefd09b17e3110c91",
        880: "ca3b809337dfc638a0f4",
        932: "fa82be7e1e5f9dff5f68",
        970: "ad86304caf54d1f4ccdc",
        994: "612eac79925a538a1f55",
        1026: "f4e43e2095f8aa1958a7",
        1112: "f476c93be59b881d5771",
        1143: "dabd574ef1615c5723bf",
        1196: "df5baa7411642fb3069f",
        1224: "d3629f7f5b9aafd86c88",
        1320: "677eb727863e2a6eb930",
        1333: "26b023a34633001097fd",
        1524: "7df949534aa4654018bc",
        1553: "6b87affb7e648083ffef",
        1583: "858239c9dab9cf062163",
        1584: "fca1649d148ae8284934",
        1590: "565b92051afcdaef12b2",
        1594: "bdc6e0cee01d43f92b56",
        1702: "9810b0a2b0fec8169859",
        1754: "bc8013be44494d029a2c",
        1859: "aaf869bc7e1e69afbfb2",
        1890: "b25672918b5758ba891f",
        1902: "03708f784cd86a54c7e9",
        2e3: "b72cddb1e241cd53d957",
        2077: "da84e313c303df7ac49f",
        2096: "b91c9add70b25e038d14",
        2100: "5bc111b6af8001a7d7d3",
        2153: "e970c9d1c83724d33d9d",
        2183: "b1aad20122a31de86c82",
        2205: "60fcbd491c14c71efecd",
        2248: "42ced2b048245348ba8f",
        2306: "a7236d9e1bf5c4e86a22",
        2335: "0230b667573082a68bd4",
        2358: "4592ca9a4bf10a040d6c",
        2377: "2ca98961f464beda5211",
        2385: "8bd1988e75b528b748b5",
        2650: "f5c0d3147a2c85ce1dfa",
        2704: "6e1c9e33032bd52c5826",
        2731: "0237b0a587f2af599d21",
        2740: "3ac451d620a4f4de3727",
        2849: "a11938dbc8cdee0e66c0",
        2878: "6be9bf2c8fb66b08e2be",
        2888: "a464709527506c8c191d",
        2919: "c84aa51b5704702a4ff8",
        2930: "1e8128c4f062d7b23c5e",
        3005: "a07a8ea49bab17580762",
        3030: "8b09ae784ae2bf58a522",
        3088: "71d4551924919fc4e66c",
        3092: "f284c2e2d26d25511b4f",
        3168: "954206c65294795f3e7c",
        3171: "049f24e9bd7f1c8b073e",
        3177: "f483ca80e40e71f8ad7c",
        3187: "67526c62671e78b84c60",
        3199: "f9bb1cc19bce0ed4e13a",
        3225: "0cf81a805088475caf6b",
        3259: "e72f7c3a1218b6f89cc1",
        3402: "80214ea16dec09fffbd7",
        3407: "65f3703704364f440025",
        3466: "dccc24adfe6f1de5abb0",
        3518: "6e1861ac6fd1b1f6309d",
        3520: "348408865478fac7ab74",
        3541: "29af5df6df0e7d459841",
        3566: "577896eb92d5dc47f5c4",
        3567: "331aac25c15f0213f015",
        3584: "3fea79e3a2e7f400662e",
        3596: "5d58465f9a3acc8390ec",
        3682: "a8229944cef798066931",
        3713: "b95b2c4900f0475dfe3d",
        3718: "b16a3a6f0554c54fe693",
        3727: "531159c18d1677246282",
        3809: "e5e3c3ed1f8a97dc5422",
        3919: "53f979377868575ca2b0",
        3921: "9a1e01c5fdc6ee0f0ca6",
        3944: "8a40a36e9250534cf1fa",
        3956: "8c145ed0901043005baa",
        3975: "703cfd31e2a76d513df9",
        4013: "28db5a29aaf5cabe38de",
        4017: "417920a2e5fad078d303",
        4079: "54b953833ef3295f0814",
        4087: "6524c22e4a5794e8ecb0",
        4102: "b861355e1fab6acf6b67",
        4193: "49c051e775ccb135c024",
        4291: "ac9986e3d97e9b3c5482",
        4389: "9b23bdd03c57777e715c",
        4441: "4298dff488512e9c54ed",
        4474: "ea628e251dbcae44ecad",
        4521: "a87e64e7049d592bdfa3",
        4664: "3ba7e949e6af37f45115",
        4665: "f53e12bdd18ec9de3b32",
        4719: "d9fe027896d99219dd45",
        4763: "093701f36a1f22397937",
        4862: "09134f479b9f8f8094c1",
        4876: "6eaa340fc439db7c4010",
        4956: "807348996e7d22c32aa7",
        4976: "791e041871ed96e61be0",
        5001: "6b11a3ca2162cef7948d",
        5009: "d90918e1a5f3a59d7cff",
        5031: "3477fc13300ced4189c3",
        5069: "0800c157c988601e62e2",
        5087: "437fcea2083cbd2e38e8",
        5093: "b41aef0767c60c9eff21",
        5142: "7743d76f4f205d37bbf9",
        5175: "735bba58eb417df5f276",
        5325: "57bc584fcad20ff58020",
        5399: "83a54192bb2eedfdd124",
        5418: "e9a5bf06f6aa8e0cbe72",
        5514: "ea377878f9dd9d5c8b0f",
        5516: "5a5da71e58073099489d",
        5551: "f877f7492cffa4dc5883",
        5552: "ad4f05cd36d0ee48cd03",
        5630: "a7dd262ced8f558657a2",
        5643: "e60d5a2fcedc55bc4c05",
        5774: "6084e87dfa3b7403c64e",
        5797: "69f2b1e7f0eddc7110b5",
        5804: "9635459a9bb27efae543",
        5827: "564727f099b82054cf71",
        5998: "efb09f12cc4162f40b26",
        6043: "000c95b1f084053a6bd4",
        6058: "2c63623a2843b5825d2f",
        6112: "9c3375654fdfa7c7cb6d",
        6166: "4ac6388f1a7d495de93e",
        6168: "1786375b73dfb7b66f01",
        6262: "dc3447f4b58df78b2d70",
        6265: "bf9fa67bc909d096f1a0",
        6363: "9bc4c2079b600a3e9e5f",
        6416: "0fdddb203273d15400a4",
        6439: "53b69d5957155904c5ec",
        6456: "71e0ca428395f0d9a4e9",
        6560: "c0e5964119c0286aaeb8",
        6631: "92e333420909e393cb74",
        6767: "2e85501f065b2764ab16",
        6780: "e713e8f81638ff23f486",
        6806: "fc986d25ea35c299cffa",
        6872: "2ed2c5c0d1dec1a9a494",
        6895: "03e2bd6c2e3a4f42c9c6",
        6909: "001e6b57323d8b33ee18",
        6991: "13f1007a84879db0bc66",
        7078: "1269e64c16311a7f7f20",
        7102: "7857a178e3f50852a83b",
        7125: "db6010876dff7225774b",
        7260: "57d08e10f33591699863",
        7271: "038a96b182d5424aea82",
        7345: "25fdcd5ab611a0cae1c5",
        7419: "fd1b88773f6a4c3ba0a3",
        7427: "9095bbcd96c4c8afbded",
        7457: "7b2eb1cc1f848a80a48c",
        7459: "c7ac243e8c19ca84ef6f",
        7502: "6e38cd9bb6c62e8eaac1",
        7544: "d0bdaae22b3d648a183b",
        7552: "c7af5f2f9d956a4895d7",
        7635: "94cca27a48b51d6d0730",
        7636: "16554aef3eb3d7e66cc1",
        7638: "c55aa22f4c88862cfa87",
        7648: "e6706686b1a5916889e2",
        7664: "723a241b8c2b0a3ddada",
        7707: "ecb50d15edc0b9f63801",
        7819: "1f53985331a307eb768f",
        7836: "7b5a16c4162d195f4fa0",
        7898: "c8ec9b33a94699bc02e4",
        7945: "4c3c0d98ac578db6c7fb",
        7962: "c7449f8a140d0a2f65c6",
        8068: "5130c2500f8007dcd181",
        8090: "8b952c7d16bf27f94c34",
        8179: "34d159d7a2f9f8403d5b",
        8242: "b5feb39217cc9b316da9",
        8248: "ca13fef30ec9aa0e1381",
        8268: "799053cee91b47677d8e",
        8303: "6f2e0bbed2ef9bb1568e",
        8354: "c3ad58cbf07c9986f949",
        8433: "fefea6b2bac2c949aa0b",
        8459: "b9eadffc31028711c0e3",
        8463: "71bed1f64ec4d658c6d9",
        8537: "df4f1305e7805950dfe8",
        8617: "10dce0d1440340ed6f4a",
        8632: "48f4b5f8846261bb073e",
        8643: "84df97c5e560f7c86bf3",
        8751: "683d47ae495ed60a33c1",
        8765: "43a8dbb0a5007d8a37a5",
        8844: "ca8518ea1562ebfc36a3",
        8879: "8d71f97b906d74e9480c",
        8890: "23d2ad037e36ca7ddacf",
        8930: "9415b1137bde38defc8a",
        8942: "1aa431ae7811a8f36993",
        8986: "9466c2fa15e1e2a0cf9f",
        9039: "f09c3d1cf8c5321f34d2",
        9042: "d1420ea0738999e3d4cd",
        9044: "a150ad770dfce817a6df",
        9055: "ba2902a9c5c3dca700c1",
        9079: "b353e4521b534b447add",
        9129: "e901c0206f411793cfff",
        9195: "0fb7c4155a7d3bde16af",
        9255: "0018f47a90442dff7efa",
        9260: "6c338a6a5239b7ac10de",
        9283: "480451f47ebcfaeaf111",
        9289: "762510b2c9450f4fe85c",
        9309: "fd81d3dccd4271a42203",
        9374: "955df4b8f54b59690c88",
        9398: "215e561d787e118d5d1b",
        9498: "cc6872a7600a839d404b",
        9578: "2c9254bf5de3cceffddd",
        9626: "55ea30e85a3f2b63f25c",
        9637: "78bb8fe4f37f1cca4c25",
        9644: "9bd0147e9691b0a03385",
        9685: "93aa082bd3cbe70b9237",
        9859: "4634a87cb7eefe409370",
        9879: "2ef793a5e18b650fcc76"
    }[e] + ".js"), t.miniCssF = e => 4020 === e ? "4020.c92c038c73c036b71422.css" : e + "." + {
        110: "ebd2dc1c695674d470c0",
        137: "22c8e006552b35610f6b",
        323: "9be8a16e68975397a842",
        419: "e7201c761f356ee72013",
        510: "9b70ae954209e1c728e5",
        710: "9d0d099953f50172ea99",
        775: "5c68daa0de7f24551ffd",
        880: "20be4b9bc2682d856330",
        1112: "7d160fc0f45e3cce101b",
        1320: "5842d36462bf91f9bdee",
        1333: "66628a51e9c9fe6d23a6",
        1524: "0b434102230dc087a222",
        1590: "aac62af01519867e56a9",
        1594: "34c11d6cc8a67dec7867",
        1902: "d52fd578e75b39cc7cfa",
        2e3: "c053338877532ef25f8e",
        2096: "fce5f28fb02182f8bb93",
        2153: "e1ac3515fad66f2e8cd2",
        2205: "6db290791e83d7931fc0",
        2335: "fbb750fd312778403036",
        2358: "4aea6b2ceb2dd524ad2f",
        2385: "a7490fb24192a7cb071d",
        2731: "ee2fb0e70b811fc1b3df",
        2849: "6cff163a36f6f60d1983",
        2888: "658aee2f9aacb50e4bc9",
        2919: "9e9f73a2392e9d90af2a",
        3171: "460fa6f81dfe853e6e5d",
        3225: "c4cea1c996c7b43b8670",
        3402: "82d9d45c3fb1eae5b64d",
        3407: "f2163124847b7cac3ba0",
        3466: "6b309c19d1017468da1b",
        3520: "ad35b3adb3b2a1ac9a36",
        3567: "081a81f608d622c8a4db",
        3584: "dd3b5fb04f8202e2b965",
        3682: "13811924767b33f096fe",
        3713: "d298aa7c89e61a75e4e2",
        3727: "0216b0bb62ce2c54bcd2",
        3919: "caf2f09f31da95a642fa",
        3921: "d5182cf595ff23538303",
        3944: "23ad1935ea1ca536bbdb",
        3956: "fe5486b6d670a170b710",
        3975: "0d1fcc5f4fdd633672c7",
        4017: "0d88d48dec4b694d4517",
        4087: "7f103430587284357eb8",
        4102: "915f81c69fc5e4623606",
        4441: "e1669b0e4dd6fa4fed5c",
        4474: "73bf3a3dea54feb8ae44",
        4521: "fb1ce34b17639871bac0",
        4719: "32c1c3edff972e8aae37",
        4763: "574e022a146295a230c1",
        4956: "5be5245cef3e7dc84a04",
        4976: "534a7db06e1171da9b21",
        5069: "3451a537bfe99e8c44be",
        5087: "256cd23713d83bf85219",
        5175: "6da12b40a46c3dc1bec7",
        5325: "f73e6a1009e185976981",
        5399: "5b37bdc7d523b1c795fb",
        5418: "ec1df9d5ab3d836fe761",
        5552: "120dc3b6225fcb1253d5",
        5630: "f2ebb878311e09076af1",
        5643: "e3046972325597a71d4d",
        5774: "141a04a858b83c24fd16",
        5804: "6d5505a6271d865543a7",
        5998: "f7e5ad8f8bcc58c55639",
        6058: "0f0dafa95e7e78cdce01",
        6168: "8223a60cc143e6eb8d46",
        6262: "c1fd9b26153dfb44f831",
        6363: "455be323006da46e86ba",
        6416: "a5a589cf5a0320e1d8ef",
        6439: "2ed0fb0c2c1340301c27",
        6560: "f01881003ac6fef45147",
        6767: "4ce0a318e0eb8861d505",
        6806: "746d65200de0f0857db1",
        6895: "5f890042edec19c4b9d3",
        6909: "8cf1749a0435c38f0042",
        7345: "f2d6787a34679ca6bb6e",
        7419: "fe8ff7c7e5d60ec6a2aa",
        7427: "3632e181ea85cc112694",
        7457: "ffc8c39283b4c0a90fa3",
        7459: "2f497a853f798e6feb68",
        7544: "0fca351edfbfcd415b17",
        7552: "889d45f5aa64d5c7293b",
        7635: "68f0d52fbb176c87eb48",
        7819: "607d0763261c93d59e8e",
        7836: "e76c27a228c01ba0f51a",
        7945: "2d37a0fa10623d3390a6",
        7962: "5dc755e884297017b802",
        8068: "3c0dbac2196877930f5a",
        8090: "9f6f63205b18b2006aae",
        8268: "22931d534c7e1ef01eb1",
        8303: "d7429ccb60ab73751723",
        8433: "780a65b1965b7d3e23e7",
        8459: "ae154eae3fd1325a661f",
        8463: "eb12cff5d8de975762fb",
        8617: "560b3d77f5965765beef",
        8844: "902c220eb319c5a7b057",
        8879: "79825d729c8f4d360834",
        8942: "8994a7aa24be83d08c45",
        8986: "a6ccf711a394e8924fa1",
        9042: "5e6d175178eb40bf9d3c",
        9044: "1a5c7bbf15796930c4aa",
        9055: "3b864f08d4f696c7bf5e",
        9129: "fbb750fd312778403036",
        9283: "a2114e3bdb5fc5e930f9",
        9289: "5f9496920ea48da5931b",
        9309: "aceadf5355c94350ec2c",
        9398: "5c18b446cbcd0acac05b",
        9626: "1cf6e1a3cc4aa360093f",
        9637: "e1a8d0ef8a2a124944fd",
        9859: "3d27ce2f9b5d65b96bf0",
        9879: "721cbfb1a5d6784e3109"
    }[e] + ".css", t.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), t.hmd = e => ((e = Object.create(e)).children || (e.children = []), Object.defineProperty(e, "exports", {
        enumerable: !0,
        set: () => {
            throw new Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " + e.id)
        }
    }), e), t.o = (e, a) => Object.prototype.hasOwnProperty.call(e, a), c = {}, t.l = (e, a, d, f) => {
        if (c[e]) c[e].push(a);
        else {
            var b, r;
            if (void 0 !== d)
                for (var o = document.getElementsByTagName("script"), i = 0; i < o.length; i++) {
                    var n = o[i];
                    if (n.getAttribute("src") == e || n.getAttribute("data-webpack") == "tradingview:" + d) {
                        b = n;
                        break
                    }
                }
            b || (r = !0, (b = document.createElement("script")).charset = "utf-8", b.timeout = 120, t.nc && b.setAttribute("nonce", t.nc), b.setAttribute("data-webpack", "tradingview:" + d), b.src = e, 0 !== b.src.indexOf(window.location.origin + "/") && (b.crossOrigin = "anonymous")), c[e] = [a];
            var l = (a, d) => {
                    b.onerror = b.onload = null, clearTimeout(s);
                    var f = c[e];
                    if (delete c[e], b.parentNode && b.parentNode.removeChild(b), f && f.forEach(e => e(d)), a) return a(d)
                },
                s = setTimeout(l.bind(null, void 0, {
                    type: "timeout",
                    target: b
                }), 12e4);
            b.onerror = l.bind(null, b.onerror), b.onload = l.bind(null, b.onload), r && document.head.appendChild(b)
        }
    }, t.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, t.nmd = e => (e.paths = [], e.children || (e.children = []), e), t.p = "bundles/", t.p = window.WEBPACK_PUBLIC_PATH || t.p;
    var r, o, i = t.e,
        n = Object.create(null);
    t.e = function(e) {
        if (!n[e]) {
            n[e] = function e(a, d) {
                return i(a).catch((function() {
                    return new Promise((function(c) {
                        var f = function() {
                            window.removeEventListener("online", f, !1), !1 === navigator.onLine ? window.addEventListener("online", f, !1) : c(d < 2 ? e(a, d + 1) : i(a))
                        };
                        setTimeout(f, d * d * 1e3)
                    }))
                }))
            }(e, 0);
            var a = function() {
                delete n[e]
            };
            n[e].then(a, a)
        }
        return n[e]
    }, r = e => new Promise((a, d) => {
        var c = t.miniCssF(e),
            f = t.p + c;
        if (((e, a) => {
                for (var d = document.getElementsByTagName("link"), c = 0; c < d.length; c++) {
                    var f = (t = d[c]).getAttribute("data-href") || t.getAttribute("href");
                    if ("stylesheet" === t.rel && (f === e || f === a)) return t
                }
                var b = document.getElementsByTagName("style");
                for (c = 0; c < b.length; c++) {
                    var t;
                    if ((f = (t = b[c]).getAttribute("data-href")) === e || f === a) return t
                }
            })(c, f)) return a();
        ((e, a, d, c) => {
            var f = document.createElement("link");
            f.rel = "stylesheet", f.type = "text/css", f.onerror = f.onload = b => {
                if (f.onerror = f.onload = null, "load" === b.type) d();
                else {
                    var t = b && ("load" === b.type ? "missing" : b.type),
                        r = b && b.target && b.target.href || a,
                        o = new Error("Loading CSS chunk " + e + " failed.\n(" + r + ")");
                    o.code = "CSS_CHUNK_LOAD_FAILED", o.type = t, o.request = r, f.parentNode.removeChild(f), c(o)
                }
            }, f.href = a, 0 !== f.href.indexOf(window.location.origin + "/") && (f.crossOrigin = "anonymous"), document.head.appendChild(f)
        })(e, f, a, d)
    }), o = {
        3666: 0
    }, t.f.miniCss = (e, a) => {
        o[e] ? a.push(o[e]) : 0 !== o[e] && {
            110: 1,
            137: 1,
            323: 1,
            419: 1,
            510: 1,
            710: 1,
            775: 1,
            880: 1,
            1112: 1,
            1320: 1,
            1333: 1,
            1524: 1,
            1590: 1,
            1594: 1,
            1902: 1,
            2e3: 1,
            2096: 1,
            2153: 1,
            2205: 1,
            2335: 1,
            2358: 1,
            2385: 1,
            2731: 1,
            2849: 1,
            2888: 1,
            2919: 1,
            3171: 1,
            3225: 1,
            3402: 1,
            3407: 1,
            3466: 1,
            3520: 1,
            3567: 1,
            3584: 1,
            3682: 1,
            3713: 1,
            3727: 1,
            3919: 1,
            3921: 1,
            3944: 1,
            3956: 1,
            3975: 1,
            4017: 1,
            4087: 1,
            4102: 1,
            4441: 1,
            4474: 1,
            4521: 1,
            4719: 1,
            4763: 1,
            4956: 1,
            4976: 1,
            5069: 1,
            5087: 1,
            5175: 1,
            5325: 1,
            5399: 1,
            5418: 1,
            5552: 1,
            5630: 1,
            5643: 1,
            5774: 1,
            5804: 1,
            5998: 1,
            6058: 1,
            6168: 1,
            6262: 1,
            6363: 1,
            6416: 1,
            6439: 1,
            6560: 1,
            6767: 1,
            6806: 1,
            6895: 1,
            6909: 1,
            7345: 1,
            7419: 1,
            7427: 1,
            7457: 1,
            7459: 1,
            7544: 1,
            7552: 1,
            7635: 1,
            7819: 1,
            7836: 1,
            7945: 1,
            7962: 1,
            8068: 1,
            8090: 1,
            8268: 1,
            8303: 1,
            8433: 1,
            8459: 1,
            8463: 1,
            8617: 1,
            8844: 1,
            8879: 1,
            8942: 1,
            8986: 1,
            9042: 1,
            9044: 1,
            9055: 1,
            9129: 1,
            9283: 1,
            9289: 1,
            9309: 1,
            9398: 1,
            9626: 1,
            9637: 1,
            9859: 1,
            9879: 1
        }[e] && a.push(o[e] = r(e).then(() => {
            o[e] = 0
        }, a => {
            throw delete o[e], a
        }))
    }, (() => {
        var e = {
            3666: 0,
            4020: 0
        };
        t.f.j = (a, d) => {
            var c = t.o(e, a) ? e[a] : void 0;
            if (0 !== c)
                if (c) d.push(c[2]);
                else if (/^(1(5(|53|83|84)|8(57|59|90)|026|143|196|224|297|39|702|754)|2([03]77|(10|65|74|93)0|183|248|306|704|878)|3(0(05|30|88|92)|1(68|77|87|99)|5(18|41|66|96)|259|48|718|809)|4(66[45]|013|079|193|291|389|862|876)|5(0(01|09|31|7|93)|5(14|16|51)|142|61|797|827)|6(043|07|112|166|265|456|60|631|780|872|991)|7(6(36|38|48|6|64)|[15]02|078|125|260|271|31|707|898)|8(24[28]|02|179|354|537|632|643|751|765|890|930)|9(2(|55|60)|(37|64|9)4|039|079|195|32|498|578|685|70))$/.test(a)) {
                var f = new Promise((d, f) => c = e[a] = [d, f]);
                d.push(c[2] = f);
                var b = t.p + t.u(a),
                    r = new Error;
                t.l(b, d => {
                    if (t.o(e, a) && (0 !== (c = e[a]) && (e[a] = void 0), c)) {
                        var f = d && ("load" === d.type ? "missing" : d.type),
                            b = d && d.target && d.target.src;
                        r.message = "Loading chunk " + a + " failed.\n(" + f + ": " + b + ")", r.name = "ChunkLoadError", r.type = f, r.request = b, c[1](r)
                    }
                }, "chunk-" + a, a)
            } else e[a] = 0
        }, t.O.j = a => 0 === e[a];
        var a = (a, d) => {
                var c, f, [b, r, o] = d,
                    i = 0;
                if (b.some(a => 0 !== e[a])) {
                    for (c in r) t.o(r, c) && (t.m[c] = r[c]);
                    if (o) var n = o(t)
                }
                for (a && a(d); i < b.length; i++) f = b[i], t.o(e, f) && e[f] && e[f][0](), e[b[i]] = 0;
                return t.O(n)
            },
            d = self.webpackChunktradingview = self.webpackChunktradingview || [];
        d.forEach(a.bind(null, 0)), d.push = a.bind(null, d.push.bind(d))
    })(), (() => {
        const {
            miniCssF: e
        } = t;
        t.miniCssF = a => "rtl" === document.dir ? e(a).replace(/\.css$/, ".rtl.css") : e(a)
    })()
})();
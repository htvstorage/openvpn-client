(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [7125], {
        21103: e => {
            e.exports = {
                container: "container-pgo9gj31",
                "intent-default": "intent-default-pgo9gj31",
                focused: "focused-pgo9gj31",
                readonly: "readonly-pgo9gj31",
                disabled: "disabled-pgo9gj31",
                "with-highlight": "with-highlight-pgo9gj31",
                grouped: "grouped-pgo9gj31",
                "adjust-position": "adjust-position-pgo9gj31",
                "first-row": "first-row-pgo9gj31",
                "first-col": "first-col-pgo9gj31",
                stretch: "stretch-pgo9gj31",
                "font-size-medium": "font-size-medium-pgo9gj31",
                "font-size-large": "font-size-large-pgo9gj31",
                "size-small": "size-small-pgo9gj31",
                "size-medium": "size-medium-pgo9gj31",
                "size-large": "size-large-pgo9gj31",
                "intent-success": "intent-success-pgo9gj31",
                "intent-warning": "intent-warning-pgo9gj31",
                "intent-danger": "intent-danger-pgo9gj31",
                "intent-primary": "intent-primary-pgo9gj31",
                "border-none": "border-none-pgo9gj31",
                "border-thin": "border-thin-pgo9gj31",
                "border-thick": "border-thick-pgo9gj31",
                "no-corner-top-left": "no-corner-top-left-pgo9gj31",
                "no-corner-top-right": "no-corner-top-right-pgo9gj31",
                "no-corner-bottom-right": "no-corner-bottom-right-pgo9gj31",
                "no-corner-bottom-left": "no-corner-bottom-left-pgo9gj31",
                highlight: "highlight-pgo9gj31",
                shown: "shown-pgo9gj31"
            }
        },
        10306: e => {
            e.exports = {
                "inner-slot": "inner-slot-QpAAIiaV",
                interactive: "interactive-QpAAIiaV",
                icon: "icon-QpAAIiaV",
                "inner-middle-slot": "inner-middle-slot-QpAAIiaV",
                "before-slot": "before-slot-QpAAIiaV",
                "after-slot": "after-slot-QpAAIiaV"
            }
        },
        66579: e => {
            e.exports = {
                input: "input-uGWFLwEy",
                "with-start-slot": "with-start-slot-uGWFLwEy",
                "with-end-slot": "with-end-slot-uGWFLwEy"
            }
        },
        9198: e => {
            e.exports = {
                innerLabel: "innerLabel-MS9pjVpT"
            }
        },
        44712: e => {
            e.exports = {
                controlWrapper: "controlWrapper-y2rn9wiU",
                hidden: "hidden-y2rn9wiU",
                control: "control-y2rn9wiU",
                controlIncrease: "controlIncrease-y2rn9wiU",
                controlDecrease: "controlDecrease-y2rn9wiU",
                controlIcon: "controlIcon-y2rn9wiU",
                title: "title-y2rn9wiU"
            }
        },
        66875: e => {
            e.exports = {
                errors: "errors-Cv6NxnRZ",
                show: "show-Cv6NxnRZ",
                error: "error-Cv6NxnRZ"
            }
        },
        93314: e => {
            e.exports = {
                "error-icon": "error-icon-llFIA0b4",
                "intent-danger": "intent-danger-llFIA0b4",
                "intent-warning": "intent-warning-llFIA0b4"
            }
        },
        52965: e => {
            e.exports = {
                "static-messages": "static-messages-Yp0dNSLN",
                errors: "errors-Yp0dNSLN",
                warnings: "warnings-Yp0dNSLN",
                message: "message-Yp0dNSLN"
            }
        },
        80327: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlGroupContext: () => o
            });
            const o = n(59496).createContext({
                isGrouped: !1,
                cellState: {
                    isTop: !0,
                    isRight: !0,
                    isBottom: !0,
                    isLeft: !0
                }
            })
        },
        31774: (e, t, n) => {
            "use strict";

            function o(e) {
                let t = 0;
                return e.isTop && e.isLeft || (t += 1), e.isTop && e.isRight || (t += 2), e.isBottom && e.isLeft || (t += 8), e.isBottom && e.isRight || (t += 4), t
            }
            n.d(t, {
                getGroupCellRemoveRoundBorders: () => o
            })
        },
        34735: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlSkeleton: () => b,
                InputClasses: () => g
            });
            var o = n(59496),
                r = n(97754),
                s = n(88537),
                a = n(28606),
                i = n(417),
                l = n(80327),
                c = n(31774);
            var u = n(21103),
                h = n.n(u);

            function d(e) {
                let t = "";
                return 0 !== e && (1 & e && (t = r(t, h()["no-corner-top-left"])), 2 & e && (t = r(t, h()["no-corner-top-right"])), 4 & e && (t = r(t, h()["no-corner-bottom-right"])), 8 & e && (t = r(t, h()["no-corner-bottom-left"]))), t
            }

            function p(e, t, n, o) {
                const {
                    removeRoundBorder: s,
                    className: a,
                    intent: i = "default",
                    borderStyle: l = "thin",
                    size: u,
                    highlight: p,
                    disabled: m,
                    readonly: g,
                    stretch: f,
                    noReadonlyStyles: v,
                    isFocused: b
                } = e, w = d(null != s ? s : (0, c.getGroupCellRemoveRoundBorders)(n));
                return r(h().container, h()["intent-" + i], h()["border-" + l], u && h()["size-" + u], w, p && h()["with-highlight"], m && h().disabled, g && !v && h().readonly, b && h().focused, f && h().stretch, t && h().grouped, !o && h()["adjust-position"], n.isTop && h()["first-row"], n.isLeft && h()["first-col"], a)
            }

            function m(e, t) {
                const {
                    highlight: n,
                    highlightRemoveRoundBorder: o
                } = e;
                if (!n) return h().highlight;
                const s = d(null != o ? o : (0, c.getGroupCellRemoveRoundBorders)(t));
                return r(h().highlight, h().shown, s)
            }
            const g = {
                    FontSizeMedium: (0, s.ensureDefined)(h()["font-size-medium"]),
                    FontSizeLarge: (0, s.ensureDefined)(h()["font-size-large"])
                },
                f = {
                    passive: !1
                };

            function v(e, t) {
                const {
                    id: n,
                    role: r,
                    onFocus: s,
                    onBlur: c,
                    onMouseOver: u,
                    onMouseOut: h,
                    onMouseDown: d,
                    onMouseUp: g,
                    onKeyDown: v,
                    onClick: b,
                    tabIndex: w,
                    startSlot: S,
                    middleSlot: C,
                    endSlot: y,
                    onWheel: E,
                    onWheelNoPassive: M = null
                } = e, {
                    isGrouped: F,
                    cellState: R,
                    disablePositionAdjustment: A = !1
                } = (0, o.useContext)(l.ControlGroupContext), N = function(e, t = null, n) {
                    const r = (0, o.useRef)(null),
                        s = (0, o.useRef)(null),
                        a = (0, o.useCallback)(() => {
                            if (null === r.current || null === s.current) return;
                            const [e, t, n] = s.current;
                            null !== t && r.current.addEventListener(e, t, n)
                        }, []),
                        i = (0, o.useCallback)(() => {
                            if (null === r.current || null === s.current) return;
                            const [e, t, n] = s.current;
                            null !== t && r.current.removeEventListener(e, t, n)
                        }, []),
                        l = (0, o.useCallback)(e => {
                            i(), r.current = e, a()
                        }, []);
                    return (0, o.useEffect)(() => (s.current = [e, t, n], a(), i), [e, t, n]), l
                }("wheel", M, f);
                return o.createElement("span", {
                    id: n,
                    role: r,
                    className: p(e, F, R, A),
                    tabIndex: w,
                    ref: (0, a.useMergedRefs)([t, N]),
                    onFocus: s,
                    onBlur: c,
                    onMouseOver: u,
                    onMouseOut: h,
                    onMouseDown: d,
                    onMouseUp: g,
                    onKeyDown: v,
                    onClick: b,
                    onWheel: E,
                    ...(0, i.filterDataProps)(e),
                    ...(0, i.filterAriaProps)(e)
                }, S, C, y, o.createElement("span", {
                    className: m(e, R)
                }))
            }
            v.displayName = "ControlSkeleton";
            const b = o.forwardRef(v)
        },
        2691: (e, t, n) => {
            "use strict";
            n.d(t, {
                BeforeSlot: () => i,
                StartSlot: () => l,
                MiddleSlot: () => c,
                EndSlot: () => u,
                AfterSlot: () => h
            });
            var o = n(59496),
                r = n(97754),
                s = n(10306),
                a = n.n(s);

            function i(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(a()["before-slot"], t)
                }, n)
            }

            function l(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: s = !1,
                    children: i
                } = e;
                return o.createElement("span", {
                    className: r(a()["inner-slot"], n && a().interactive, s && a().icon, t)
                }, i)
            }

            function c(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(a()["inner-slot"], a()["inner-middle-slot"], t)
                }, n)
            }

            function u(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: s = !1,
                    children: i
                } = e;
                return o.createElement("span", {
                    className: r(a()["inner-slot"], n && a().interactive, s && a().icon, t)
                }, i)
            }

            function h(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(a()["after-slot"], t)
                }, n)
            }
        },
        54936: (e, t, n) => {
            "use strict";
            n.d(t, {
                Input: () => v,
                InputControl: () => b
            });
            var o = n(59496),
                r = n(97754),
                s = n(417),
                a = n(69842),
                i = n(1811),
                l = n(28606),
                c = n(21778),
                u = n(83836),
                h = n(3548),
                d = n(34735),
                p = n(2691),
                m = n(66579),
                g = n.n(m);

            function f(e) {
                return !(0, s.isAriaAttribute)(e) && !(0, s.isDataAttribute)(e)
            }

            function v(e) {
                const {
                    id: t,
                    title: n,
                    role: a,
                    tabIndex: i,
                    placeholder: l,
                    name: c,
                    type: u,
                    value: h,
                    defaultValue: m,
                    draggable: v,
                    autoComplete: b,
                    autoFocus: w,
                    maxLength: S,
                    min: C,
                    max: y,
                    step: E,
                    pattern: M,
                    inputMode: F,
                    onSelect: R,
                    onFocus: A,
                    onBlur: N,
                    onKeyDown: B,
                    onKeyUp: x,
                    onKeyPress: I,
                    onChange: V,
                    onDragStart: k,
                    size: z = "medium",
                    className: D,
                    inputClassName: P,
                    disabled: W,
                    readonly: _,
                    containerTabIndex: L,
                    startSlot: O,
                    endSlot: T,
                    reference: j,
                    containerReference: H,
                    onContainerFocus: K,
                    ...U
                } = e, Y = (0, s.filterProps)(U, f), G = { ...(0, s.filterAriaProps)(U),
                    ...(0, s.filterDataProps)(U),
                    id: t,
                    title: n,
                    role: a,
                    tabIndex: i,
                    placeholder: l,
                    name: c,
                    type: u,
                    value: h,
                    defaultValue: m,
                    draggable: v,
                    autoComplete: b,
                    autoFocus: w,
                    maxLength: S,
                    min: C,
                    max: y,
                    step: E,
                    pattern: M,
                    inputMode: F,
                    onSelect: R,
                    onFocus: A,
                    onBlur: N,
                    onKeyDown: B,
                    onKeyUp: x,
                    onKeyPress: I,
                    onChange: V,
                    onDragStart: k
                };
                return o.createElement(d.ControlSkeleton, { ...Y,
                    disabled: W,
                    readonly: _,
                    tabIndex: L,
                    className: r(g().container, D),
                    size: z,
                    ref: H,
                    onFocus: K,
                    startSlot: O,
                    middleSlot: o.createElement(p.MiddleSlot, null, o.createElement("input", { ...G,
                        className: r(g().input, P, O && g()["with-start-slot"], T && g()["with-end-slot"]),
                        disabled: W,
                        readOnly: _,
                        ref: j
                    })),
                    endSlot: T
                })
            }

            function b(e) {
                e = (0, c.useControl)(e);
                const {
                    disabled: t,
                    autoSelectOnFocus: n,
                    tabIndex: r = 0,
                    onFocus: s,
                    onBlur: d,
                    reference: p,
                    containerReference: m = null
                } = e, g = (0, o.useRef)(null), f = (0, o.useRef)(null), [b, w] = (0, u.useFocus)(), S = t ? void 0 : b ? -1 : r, C = t ? void 0 : b ? r : -1, {
                    isMouseDown: y,
                    handleMouseDown: E,
                    handleMouseUp: M
                } = (0, h.useIsMouseDown)(), F = (0, a.createSafeMulticastEventHandler)(w.onFocus, (function(e) {
                    n && !y.current && (0, i.selectAllContent)(e.currentTarget)
                }), s), R = (0, a.createSafeMulticastEventHandler)(w.onBlur, d), A = (0, o.useCallback)(e => {
                    g.current = e, p && ("function" == typeof p && p(e), "object" == typeof p && (p.current = e))
                }, [g, p]);
                return o.createElement(v, { ...e,
                    isFocused: b,
                    containerTabIndex: S,
                    tabIndex: C,
                    onContainerFocus: function(e) {
                        f.current === e.target && null !== g.current && g.current.focus()
                    },
                    onFocus: F,
                    onBlur: R,
                    reference: A,
                    containerReference: (0, l.useMergedRefs)([f, m]),
                    onMouseDown: E,
                    onMouseUp: M
                })
            }
        },
        21778: (e, t, n) => {
            "use strict";
            n.d(t, {
                useControl: () => s
            });
            var o = n(69842),
                r = n(83836);

            function s(e) {
                const {
                    onFocus: t,
                    onBlur: n,
                    intent: s,
                    highlight: a,
                    disabled: i
                } = e, [l, c] = (0, r.useFocus)(void 0, i), u = (0, o.createSafeMulticastEventHandler)(i ? void 0 : c.onFocus, t), h = (0, o.createSafeMulticastEventHandler)(i ? void 0 : c.onBlur, n);
                return { ...e,
                    intent: s || (l ? "primary" : "default"),
                    highlight: null != a ? a : l,
                    onFocus: u,
                    onBlur: h
                }
            }
        },
        83836: (e, t, n) => {
            "use strict";
            n.d(t, {
                useFocus: () => r
            });
            var o = n(59496);

            function r(e, t) {
                const [n, r] = (0, o.useState)(!1);
                (0, o.useEffect)(() => {
                    t && n && r(!1)
                }, [t, n]);
                const s = {
                    onFocus: (0, o.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || r(!0)
                    }), [e]),
                    onBlur: (0, o.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || r(!1)
                    }), [e])
                };
                return [n, s]
            }
        },
        3548: (e, t, n) => {
            "use strict";
            n.d(t, {
                useIsMouseDown: () => r
            });
            var o = n(59496);

            function r() {
                const e = (0, o.useRef)(!1),
                    t = (0, o.useCallback)(() => {
                        e.current = !0
                    }, [e]),
                    n = (0, o.useCallback)(() => {
                        e.current = !1
                    }, [e]);
                return {
                    isMouseDown: e,
                    handleMouseDown: t,
                    handleMouseUp: n
                }
            }
        },
        28606: (e, t, n) => {
            "use strict";
            n.d(t, {
                useMergedRefs: () => r
            });
            var o = n(59496);

            function r(e) {
                return (0, o.useCallback)(function(e) {
                    return t => {
                        e.forEach(e => {
                            "function" == typeof e ? e(t) : null != e && (e.current = t)
                        })
                    }
                }(e), e)
            }
        },
        1811: (e, t, n) => {
            "use strict";

            function o(e) {
                null !== e && e.setSelectionRange(0, e.value.length)
            }
            n.d(t, {
                selectAllContent: () => o
            })
        },
        69842: (e, t, n) => {
            "use strict";

            function o(...e) {
                return t => {
                    for (const n of e) void 0 !== n && n(t)
                }
            }
            n.d(t, {
                createSafeMulticastEventHandler: () => o
            })
        },
        94087: (e, t, n) => {
            "use strict";
            n.d(t, {
                InputWithError: () => p
            });
            var o = n(59496),
                r = n(97754),
                s = n(34735),
                a = n(2691),
                i = n(81476),
                l = n(61428),
                c = n(79184),
                u = n(9198);
            const h = {
                    large: s.InputClasses.FontSizeLarge,
                    medium: s.InputClasses.FontSizeMedium
                },
                d = {
                    attachment: c.anchors.top.attachment,
                    targetAttachment: c.anchors.top.targetAttachment,
                    attachmentOffsetY: -4
                };

            function p(e) {
                const {
                    className: t,
                    inputClassName: n,
                    stretch: s = !0,
                    errorMessage: c,
                    fontSizeStyle: p = "large",
                    endSlot: m,
                    button: g,
                    error: f,
                    warning: v,
                    innerLabel: b,
                    inputReference: w,
                    children: S,
                    ...C
                } = e, y = f && void 0 !== c ? [c] : void 0, E = v && void 0 !== c ? [c] : void 0, M = r(u.inputContainer, h[p], t), F = b ? o.createElement(a.StartSlot, {
                    className: u.innerLabel,
                    interactive: !1
                }, b) : void 0, R = m || g || S ? o.createElement(a.EndSlot, null, m, g, S) : void 0;
                return o.createElement(i.FormInput, { ...C,
                    className: M,
                    inputClassName: n,
                    errors: y,
                    warnings: E,
                    hasErrors: f,
                    hasWarnings: v,
                    messagesPosition: l.MessagesPosition.Attached,
                    customErrorsAttachment: d,
                    messagesRoot: "document",
                    inheritMessagesWidthFromTarget: !0,
                    disableMessagesRtlStyles: !0,
                    iconHidden: !0,
                    stretch: s,
                    reference: w,
                    startSlot: F,
                    endSlot: R
                })
            }
        },
        76805: (e, t, n) => {
            "use strict";
            n.d(t, {
                NumberInputView: () => b
            });
            var o = n(59496),
                r = n(72535),
                s = n(94087),
                a = n(97754),
                i = n(25177),
                l = n(72571),
                c = n(21538),
                u = n(44712);

            function h(e) {
                const t = a(u.control, u.controlIncrease),
                    n = a(u.control, u.controlDecrease);
                return o.createElement(o.Fragment, null, void 0 !== e.title && o.createElement("div", {
                    className: u.title
                }, e.title), o.createElement("div", {
                    className: u.controlWrapper
                }, (e.defaultButtonsVisible || e.title) && o.createElement(o.Fragment, null, o.createElement("button", {
                    type: "button",
                    tabIndex: -1,
                    "aria-label": (0, i.t)("Increase"),
                    className: t,
                    onClick: e.increaseValue
                }, o.createElement(l.Icon, {
                    icon: c,
                    className: u.controlIcon
                })), o.createElement("button", {
                    type: "button",
                    tabIndex: -1,
                    "aria-label": (0, i.t)("Decrease"),
                    className: n,
                    onClick: e.decreaseValue
                }, o.createElement(l.Icon, {
                    icon: c,
                    className: u.controlIcon
                })))))
            }
            var d = n(21258),
                p = n(83836),
                m = n(69842),
                g = n(80185);
            const f = [38],
                v = [40];

            function b(e) {
                const [t, n] = (0, d.useHover)(), [a, i] = (0, p.useFocus)(), l = (0, m.createSafeMulticastEventHandler)(i.onFocus, e.onFocus), c = (0, m.createSafeMulticastEventHandler)(i.onBlur, e.onBlur), u = (0, o.useCallback)(t => {
                    !e.disabled && a && (t.preventDefault(), t.deltaY < 0 ? e.onValueByStepChange(1) : e.onValueByStepChange(-1))
                }, [a, e.disabled, e.onValueByStepChange]);
                return o.createElement(s.InputWithError, { ...n,
                    id: e.id,
                    name: e.name,
                    pattern: e.pattern,
                    borderStyle: e.borderStyle,
                    fontSizeStyle: e.fontSizeStyle,
                    value: e.value,
                    className: e.className,
                    inputClassName: e.inputClassName,
                    button: function() {
                        const {
                            button: n,
                            forceShowControls: s,
                            disabled: i,
                            title: l
                        } = e, c = !i && !r.mobiletouch && (s || a || t);
                        return i ? void 0 : o.createElement(o.Fragment, null, null != n ? n : o.createElement(h, {
                            increaseValue: b,
                            decreaseValue: w,
                            defaultButtonsVisible: c,
                            title: l
                        }))
                    }(),
                    disabled: e.disabled,
                    placeholder: e.placeholder,
                    innerLabel: e.innerLabel,
                    endSlot: e.endSlot,
                    containerReference: e.containerReference,
                    inputReference: e.inputReference,
                    inputMode: e.inputMode,
                    type: e.type,
                    error: e.error,
                    errorMessage: e.errorMessage,
                    onClick: e.onClick,
                    onFocus: l,
                    onBlur: c,
                    onChange: e.onValueChange,
                    onKeyDown: function(t) {
                        if (e.disabled || 0 !== (0, g.modifiersFromEvent)(t.nativeEvent)) return;
                        let n = f,
                            o = v;
                        e.controlDecKeyCodes && (o = o.concat(e.controlDecKeyCodes));
                        e.controlIncKeyCodes && (n = n.concat(e.controlIncKeyCodes));
                        (o.includes(t.keyCode) || n.includes(t.keyCode)) && (t.preventDefault(), e.onValueByStepChange(o.includes(t.keyCode) ? -1 : 1));
                        e.onKeyDown && e.onKeyDown(t)
                    },
                    onWheelNoPassive: u,
                    stretch: e.stretch,
                    intent: e.intent,
                    highlight: e.highlight,
                    highlightRemoveRoundBorder: e.highlightRemoveRoundBorder,
                    autoSelectOnFocus: e.autoSelectOnFocus,
                    "data-property-id": e["data-name"]
                });

                function b() {
                    e.disabled || e.onValueByStepChange(1)
                }

                function w() {
                    e.disabled || e.onValueByStepChange(-1)
                }
            }
        },
        87125: (e, t, n) => {
            "use strict";
            n.d(t, {
                NumberInput: () => g
            });
            var o = n(59496),
                r = n(25177),
                s = n(60521),
                a = n(1227),
                i = n(76805),
                l = n(32207),
                c = n(8329),
                u = n(97280);
            const h = (0, r.t)("Number format is invalid."),
                d = new l.SplitThousandsFormatter,
                p = /^-?[0-9]*$/,
                m = 9e15;
            class g extends o.PureComponent {
                constructor(e) {
                    super(e), this._onFocus = e => {
                        this.setState({
                            focused: !0
                        }), this.props.onFocus && this.props.onFocus(e)
                    }, this._onBlur = e => {
                        this.setState({
                            displayValue: f(this.props, this.props.value),
                            focused: !1
                        }), this.props.errorHandler && this.props.errorHandler(!1), this.props.onBlur && this.props.onBlur(e)
                    }, this._onValueChange = e => {
                        const t = e.target.value;
                        if (void 0 !== this.props.onEmptyString && "" === t && this.props.onEmptyString(), "integer" === this.props.mode && !p.test(t)) return;
                        const n = v(t, this.props.formatter),
                            o = n.res ? this._checkValueBoundaries(n.value) : {
                                isPassed: !1,
                                msg: void 0
                            },
                            r = n.res && !o.isPassed,
                            s = n.res && n.suggest && !this.state.focused ? n.suggest : t,
                            a = r && o.msg ? o.msg : h;
                        this.setState({
                            displayValue: s,
                            errorMsg: a
                        }), n.res && o.isPassed && this.props.onValueChange(n.value, "input"), this.props.errorHandler && this.props.errorHandler(!n.res || r)
                    }, this._onValueByStepChange = e => {
                        const {
                            roundByStep: t = !0,
                            step: n = 1,
                            uiStep: o,
                            min: r = n,
                            formatter: a
                        } = this.props, i = v(this.state.displayValue, a), l = null != o ? o : n;
                        let c = n;
                        if (i.res) {
                            const o = new s.Big(i.value),
                                a = o.minus(r).mod(n);
                            let u = o.plus(e * l);
                            !a.eq(0) && t && (u = u.plus((e > 0 ? 0 : 1) * l).minus(a)), c = u.toNumber()
                        }
                        const {
                            isPassed: u,
                            clampedValue: h
                        } = this._checkValueBoundaries(c);
                        c = u ? c : h, this.setState({
                            displayValue: f(this.props, c)
                        }), this.props.onValueChange(c, "step"), this.props.errorHandler && this.props.errorHandler(!1)
                    };
                    const {
                        value: t
                    } = e;
                    this.state = {
                        value: t,
                        displayValue: f(e, t),
                        focused: !1,
                        errorMsg: h
                    }
                }
                render() {
                    var e;
                    return o.createElement(i.NumberInputView, {
                        id: this.props.id,
                        inputMode: null !== (e = this.props.inputMode) && void 0 !== e ? e : a.CheckMobile.iOS() ? void 0 : "numeric",
                        borderStyle: this.props.borderStyle,
                        fontSizeStyle: this.props.fontSizeStyle,
                        value: this.state.displayValue,
                        forceShowControls: this.props.forceShowControls,
                        className: this.props.className,
                        inputClassName: this.props.inputClassName,
                        button: this.props.button,
                        placeholder: this.props.placeholder,
                        innerLabel: this.props.innerLabel,
                        endSlot: this.props.endSlot,
                        disabled: this.props.disabled,
                        error: this.props.error,
                        errorMessage: this.props.errorMessage || this.state.errorMsg,
                        onValueChange: this._onValueChange,
                        onValueByStepChange: this._onValueByStepChange,
                        containerReference: this.props.containerReference,
                        inputReference: this.props.inputReference,
                        onClick: this.props.onClick,
                        onFocus: this._onFocus,
                        onBlur: this._onBlur,
                        onKeyDown: this.props.onKeyDown,
                        controlDecKeyCodes: this.props.controlDecKeyCodes,
                        controlIncKeyCodes: this.props.controlIncKeyCodes,
                        title: this.props.title,
                        intent: this.props.intent,
                        highlight: this.props.highlight,
                        highlightRemoveRoundBorder: this.props.highlightRemoveRoundBorder,
                        stretch: this.props.stretch,
                        autoSelectOnFocus: !a.CheckMobile.any()
                    })
                }
                getClampedValue() {
                    const {
                        min: e = -1 / 0,
                        max: t = m
                    } = this.props, n = v(this.state.displayValue, this.props.formatter);
                    return n.res ? (0, u.clamp)(n.value, e, t) : null
                }
                static getDerivedStateFromProps(e, t) {
                    const {
                        alwaysUpdateValueFromProps: n,
                        value: o
                    } = e;
                    return t.focused && !n || t.value === o ? null : {
                        value: o,
                        displayValue: f(e, o)
                    }
                }
                _checkValueBoundaries(e) {
                    var t, n, o, s;
                    const {
                        min: a = -1 / 0,
                        max: i = m
                    } = this.props, l = function(e, t, n) {
                        const o = e >= t,
                            r = e <= n;
                        return {
                            passMin: o,
                            passMax: r,
                            pass: o && r,
                            clamped: (0, u.clamp)(e, t, n)
                        }
                    }(e, a, i);
                    let c;
                    return l.passMax || (c = null !== (n = null === (t = this.props.boundariesErrorMessages) || void 0 === t ? void 0 : t.greaterThanMax) && void 0 !== n ? n : (0, r.t)("Specified value is more than the instrument maximum of {max}.", {
                        replace: {
                            max: String(i)
                        }
                    })), l.passMin || (c = null !== (s = null === (o = this.props.boundariesErrorMessages) || void 0 === o ? void 0 : o.lessThanMin) && void 0 !== s ? s : (0, r.t)("Specified value is less than the instrument minimum of {min}.", {
                        replace: {
                            min: String(a)
                        }
                    })), {
                        isPassed: l.pass,
                        msg: c,
                        clampedValue: l.clamped
                    }
                }
            }

            function f(e, t) {
                const {
                    useFormatter: n = !0,
                    formatter: o,
                    mode: r
                } = e;
                return n && "integer" !== r ? function(e, t = d) {
                    return null !== e ? t.format(e) : ""
                }(t, o) : function(e) {
                    if (null === e) return "";
                    return c.NumericFormatter.formatNoE(e)
                }(t)
            }

            function v(e, t = d) {
                return t.parse ? t.parse(e) : {
                    res: !1,
                    error: "Formatter does not support parse"
                }
            }
        },
        79184: (e, t, n) => {
            "use strict";
            n.d(t, {
                anchors: () => r,
                makeAnchorable: () => s
            });
            var o = n(59496);
            const r = {
                bottom: {
                    attachment: {
                        horizontal: "left",
                        vertical: "top"
                    },
                    targetAttachment: {
                        horizontal: "left",
                        vertical: "bottom"
                    }
                },
                top: {
                    attachment: {
                        horizontal: "left",
                        vertical: "bottom"
                    },
                    targetAttachment: {
                        horizontal: "left",
                        vertical: "top"
                    }
                },
                topRight: {
                    attachment: {
                        horizontal: "right",
                        vertical: "bottom"
                    },
                    targetAttachment: {
                        horizontal: "right",
                        vertical: "top"
                    }
                },
                bottomRight: {
                    attachment: {
                        horizontal: "right",
                        vertical: "top"
                    },
                    targetAttachment: {
                        horizontal: "right",
                        vertical: "bottom"
                    }
                }
            };

            function s(e) {
                var t;
                return (t = class extends o.PureComponent {
                    render() {
                        const {
                            anchor: t = "bottom"
                        } = this.props;
                        return o.createElement(e, { ...this.props,
                            attachment: r[t].attachment,
                            targetAttachment: r[t].targetAttachment
                        })
                    }
                }).displayName = "Anchorable Component", t
            }
        },
        41037: (e, t, n) => {
            "use strict";
            n.d(t, {
                makeAttachable: () => s
            });
            var o = n(59496),
                r = n(87995);

            function s(e) {
                var t;
                return (t = class extends o.PureComponent {
                    constructor(e) {
                        super(e), this._getComponentInstance = e => {
                            this._instance = e
                        }, this._throttleCalcProps = () => {
                            requestAnimationFrame(() => this.setState(this._calcProps(this.props)))
                        }, this.state = this._getStateFromProps()
                    }
                    componentDidMount() {
                        this._instanceElem = r.findDOMNode(this._instance), this.props.attachOnce || this._subscribe(), this.setState(this._calcProps(this.props))
                    }
                    componentDidUpdate(e) {
                        e.children === this.props.children && e.top === this.props.top && e.left === this.props.left && e.width === this.props.width || this.setState(this._getStateFromProps(), () => this.setState(this._calcProps(this.props)))
                    }
                    render() {
                        return o.createElement("div", {
                            style: {
                                position: "absolute",
                                width: "100%",
                                top: 0,
                                left: 0
                            }
                        }, o.createElement(e, { ...this.props,
                            ref: this._getComponentInstance,
                            top: this.state.top,
                            bottom: void 0 !== this.state.bottom ? this.state.bottom : "auto",
                            right: void 0 !== this.state.right ? this.state.right : "auto",
                            left: this.state.left,
                            width: this.state.width,
                            maxWidth: this.state.maxWidth
                        }, this.props.children))
                    }
                    componentWillUnmount() {
                        this._unsubsribe()
                    }
                    _getStateFromProps() {
                        return {
                            bottom: this.props.bottom,
                            left: this.props.left,
                            right: this.props.right,
                            top: void 0 !== this.props.top ? this.props.top : -1e4,
                            width: this.props.inheritWidthFromTarget ? this.props.target && this.props.target.getBoundingClientRect().width : this.props.width,
                            maxWidth: this.props.inheritMaxWidthFromTarget && this.props.target && this.props.target.getBoundingClientRect().width
                        }
                    }
                    _calcProps(e) {
                        if (e.target && e.attachment && e.targetAttachment) {
                            const t = this._calcTargetProps(e.target, e.attachment, e.targetAttachment);
                            if (null === t) return {};
                            const {
                                width: n,
                                inheritWidthFromTarget: o = !0,
                                inheritMaxWidthFromTarget: r = !1
                            } = this.props, s = {
                                width: o ? t.width : n,
                                maxWidth: r ? t.width : void 0
                            };
                            switch (e.attachment.vertical) {
                                case "bottom":
                                case "middle":
                                    s.top = t.y;
                                    break;
                                default:
                                    s[e.attachment.vertical] = t.y
                            }
                            switch (e.attachment.horizontal) {
                                case "right":
                                case "center":
                                    s.left = t.x;
                                    break;
                                default:
                                    s[e.attachment.horizontal] = t.x
                            }
                            return s
                        }
                        return {}
                    }
                    _calcTargetProps(e, t, n) {
                        const o = e.getBoundingClientRect(),
                            r = this._instanceElem.getBoundingClientRect(),
                            s = "parent" === this.props.root ? this._getCoordsRelToParentEl(e, o) : this._getCoordsRelToDocument(o);
                        if (null === s) return null;
                        const a = this._getDimensions(r),
                            i = this._getDimensions(o).width;
                        let l = 0,
                            c = 0;
                        switch (t.vertical) {
                            case "top":
                                c = s[n.vertical];
                                break;
                            case "bottom":
                                c = s[n.vertical] - a.height;
                                break;
                            case "middle":
                                c = s[n.vertical] - a.height / 2
                        }
                        switch (t.horizontal) {
                            case "left":
                                l = s[n.horizontal];
                                break;
                            case "right":
                                l = s[n.horizontal] - a.width;
                                break;
                            case "center":
                                l = s[n.horizontal] - a.width / 2
                        }
                        return "number" == typeof this.props.attachmentOffsetY && (c += this.props.attachmentOffsetY), "number" == typeof this.props.attachmentOffsetX && (l += this.props.attachmentOffsetX), {
                            x: l,
                            y: c,
                            width: i
                        }
                    }
                    _getCoordsRelToDocument(e) {
                        const t = pageYOffset,
                            n = pageXOffset,
                            o = e.top + t,
                            r = e.bottom + t,
                            s = e.left + n;
                        return {
                            top: o,
                            bottom: r,
                            left: s,
                            right: e.right + n,
                            middle: (o + e.height) / 2,
                            center: s + e.width / 2
                        }
                    }
                    _getCoordsRelToParentEl(e, t) {
                        const n = e.offsetParent;
                        if (null === n) return null;
                        const o = n.scrollTop,
                            r = n.scrollLeft,
                            s = e.offsetTop + o,
                            a = e.offsetLeft + r,
                            i = t.width + a;
                        return {
                            top: s,
                            bottom: t.height + s,
                            left: a,
                            right: i,
                            middle: (s + t.height) / 2,
                            center: (a + t.width) / 2
                        }
                    }
                    _getDimensions(e) {
                        return {
                            height: e.height,
                            width: e.width
                        }
                    }
                    _subscribe() {
                        "document" === this.props.root && (window.addEventListener("scroll", this._throttleCalcProps, !0), window.addEventListener("resize", this._throttleCalcProps))
                    }
                    _unsubsribe() {
                        window.removeEventListener("scroll", this._throttleCalcProps, !0), window.removeEventListener("resize", this._throttleCalcProps)
                    }
                }).displayName = "Attachable Component", t
            }
        },
        21258: (e, t, n) => {
            "use strict";
            n.d(t, {
                hoverMouseEventFilter: () => s,
                useAccurateHover: () => a,
                useHover: () => r
            });
            var o = n(59496);

            function r() {
                const [e, t] = (0, o.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        s(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        s(e) && t(!1)
                    }
                }]
            }

            function s(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function a(e) {
                const [t, n] = (0, o.useState)(!1);
                return (0, o.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const o = e.current.contains(t.target);
                        n(o)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        81476: (e, t, n) => {
            "use strict";
            n.d(t, {
                FormInput: () => c
            });
            var o = n(59496),
                r = n(54936),
                s = n(61428),
                a = n(2691),
                i = n(69842),
                l = n(28606);

            function c(e) {
                var t;
                const {
                    intent: n,
                    onFocus: c,
                    onBlur: u,
                    onMouseOver: h,
                    onMouseOut: d,
                    containerReference: p = null,
                    endSlot: m,
                    hasErrors: g,
                    hasWarnings: f,
                    errors: v,
                    warnings: b,
                    alwaysShowAttachedErrors: w,
                    iconHidden: S,
                    messagesPosition: C,
                    messagesAttachment: y,
                    customErrorsAttachment: E,
                    messagesRoot: M,
                    inheritMessagesWidthFromTarget: F,
                    disableMessagesRtlStyles: R,
                    ...A
                } = e, N = (0, s.useControlValidationLayout)({
                    hasErrors: g,
                    hasWarnings: f,
                    errors: v,
                    warnings: b,
                    alwaysShowAttachedErrors: w,
                    iconHidden: S,
                    messagesPosition: C,
                    messagesAttachment: y,
                    customErrorsAttachment: E,
                    messagesRoot: M,
                    inheritMessagesWidthFromTarget: F,
                    disableMessagesRtlStyles: R
                }), B = (0, i.createSafeMulticastEventHandler)(c, N.onFocus), x = (0, i.createSafeMulticastEventHandler)(u, N.onBlur), I = (0, i.createSafeMulticastEventHandler)(h, N.onMouseOver), V = (0, i.createSafeMulticastEventHandler)(d, N.onMouseOut);
                return o.createElement(o.Fragment, null, o.createElement(r.InputControl, { ...A,
                    intent: null !== (t = N.intent) && void 0 !== t ? t : n,
                    onFocus: B,
                    onBlur: x,
                    onMouseOver: I,
                    onMouseOut: V,
                    containerReference: (0, l.useMergedRefs)([p, N.containerReference]),
                    endSlot: o.createElement(o.Fragment, null, N.icon && o.createElement(a.EndSlot, {
                        icon: !0
                    }, N.icon), m)
                }), N.renderedErrors)
            }
        },
        61428: (e, t, n) => {
            "use strict";
            n.d(t, {
                MessagesPosition: () => w,
                useControlValidationLayout: () => N
            });
            var o = n(59496),
                r = n(97754),
                s = n(83836),
                a = n(21258),
                i = n(2691),
                l = n(79184),
                c = n(74485),
                u = n(41037),
                h = n(66875),
                d = n(34581);
            class p extends o.PureComponent {
                render() {
                    const {
                        children: e = [],
                        show: t = !1,
                        customErrorClass: n,
                        disableRtlStyles: s
                    } = this.props, a = r(h.errors, {
                        [h.show]: t
                    }, n), i = e.map((e, t) => o.createElement("div", {
                        className: h.error,
                        key: t
                    }, e));
                    let l = {
                        position: "absolute",
                        top: this.props.top,
                        width: this.props.width,
                        height: this.props.height,
                        bottom: void 0 !== this.props.bottom ? this.props.bottom : "100%",
                        right: void 0 !== this.props.right ? this.props.right : 0,
                        left: this.props.left,
                        zIndex: this.props.zIndex,
                        maxWidth: this.props.maxWidth
                    };
                    if ((0, d.isRtl)() && !s) {
                        const {
                            left: e,
                            right: t
                        } = l;
                        l = { ...l,
                            left: t,
                            right: e
                        }
                    }
                    return o.createElement("div", {
                        style: l,
                        className: a
                    }, i)
                }
            }
            const m = (0, c.makeOverlapable)((0, u.makeAttachable)(p));
            var g = n(72571),
                f = n(7295),
                v = n(93314);

            function b(e) {
                const {
                    intent: t = "danger"
                } = e;
                return o.createElement(g.Icon, {
                    icon: f,
                    className: r(v["error-icon"], v["intent-" + t])
                })
            }
            var w, S, C = n(52965);
            ! function(e) {
                e[e.Attached = 0] = "Attached", e[e.Static = 1] = "Static", e[e.Hidden = 2] = "Hidden"
            }(w || (w = {})),
            function(e) {
                e.Top = "top", e.Bottom = "bottom"
            }(S || (S = {}));
            const y = {
                top: {
                    attachment: l.anchors.topRight.attachment,
                    targetAttachment: l.anchors.topRight.targetAttachment,
                    attachmentOffsetY: -4
                },
                bottom: {
                    attachment: l.anchors.bottomRight.attachment,
                    targetAttachment: l.anchors.bottomRight.targetAttachment,
                    attachmentOffsetY: 4
                }
            };

            function E(e) {
                const {
                    isOpened: t,
                    target: n,
                    errorAttachment: r = S.Top,
                    customErrorsAttachment: s,
                    root: a = "parent",
                    inheritWidthFromTarget: i = !1,
                    disableRtlStyles: l,
                    children: c
                } = e, {
                    attachment: u,
                    targetAttachment: h,
                    attachmentOffsetY: d
                } = null != s ? s : y[r];
                return o.createElement(m, {
                    isOpened: t,
                    target: n,
                    root: a,
                    inheritWidthFromTarget: i,
                    attachment: u,
                    targetAttachment: h,
                    attachmentOffsetY: d,
                    disableRtlStyles: l,
                    inheritMaxWidthFromTarget: !0,
                    show: !0
                }, c)
            }

            function M(e, t) {
                return Boolean(e) && void 0 !== t && t.length > 0
            }

            function F(e, t, n) {
                return e === w.Attached && M(t, n)
            }

            function R(e, t, n) {
                return e === w.Static && M(t, n)
            }

            function A(e, t, n) {
                const {
                    hasErrors: o,
                    hasWarnings: r,
                    alwaysShowAttachedErrors: s,
                    iconHidden: a,
                    errors: i,
                    warnings: l,
                    messagesPosition: c = w.Static
                } = e, u = F(c, o, i), h = F(c, r, l), d = u && (t || n || Boolean(s)), p = !d && h && (t || n), m = R(c, o, i), g = !m && R(c, r, l), f = !a && Boolean(o);
                return {
                    hasAttachedErrorMessages: u,
                    hasAttachedWarningMessages: h,
                    showAttachedErrorMessages: d,
                    showAttachedWarningMessages: p,
                    showStaticErrorMessages: m,
                    showStaticWarningMessages: g,
                    showErrorIcon: f,
                    showWarningIcon: !a && !f && Boolean(r),
                    intent: function(e, t) {
                        return Boolean(e) ? "danger" : Boolean(t) ? "warning" : void 0
                    }(o, r)
                }
            }

            function N(e) {
                var t, n;
                const {
                    errors: l,
                    warnings: c,
                    messagesAttachment: u,
                    customErrorsAttachment: h,
                    messagesRoot: d,
                    inheritMessagesWidthFromTarget: p,
                    disableMessagesRtlStyles: m
                } = e, [g, f] = (0, s.useFocus)(), [v, w] = (0, a.useHover)(), S = (0, o.useRef)(null), {
                    hasAttachedErrorMessages: y,
                    hasAttachedWarningMessages: M,
                    showAttachedErrorMessages: F,
                    showAttachedWarningMessages: R,
                    showStaticErrorMessages: N,
                    showStaticWarningMessages: B,
                    showErrorIcon: x,
                    showWarningIcon: I,
                    intent: V
                } = A(e, g, v), k = x || I ? o.createElement(b, {
                    intent: x ? "danger" : "warning"
                }) : void 0, z = y ? o.createElement(E, {
                    errorAttachment: u,
                    customErrorsAttachment: h,
                    isOpened: F,
                    target: S.current,
                    root: d,
                    inheritWidthFromTarget: p,
                    disableRtlStyles: m,
                    children: l
                }) : void 0, D = M ? o.createElement(E, {
                    errorAttachment: u,
                    isOpened: R,
                    target: S.current,
                    root: d,
                    inheritWidthFromTarget: p,
                    disableRtlStyles: m,
                    children: c
                }) : void 0, P = N ? o.createElement(i.AfterSlot, {
                    className: r(C["static-messages"], C.errors)
                }, null == l ? void 0 : l.map((e, t) => o.createElement("p", {
                    key: t,
                    className: C.message
                }, e))) : void 0, W = B ? o.createElement(i.AfterSlot, {
                    className: r(C["static-messages"], C.warnings)
                }, null == c ? void 0 : c.map((e, t) => o.createElement("p", {
                    key: t,
                    className: C.message
                }, e))) : void 0;
                return {
                    icon: k,
                    renderedErrors: null !== (n = null !== (t = null != z ? z : D) && void 0 !== t ? t : P) && void 0 !== n ? n : W,
                    containerReference: S,
                    intent: V,
                    ...f,
                    ...w
                }
            }
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        7295: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M8 15c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm0 1c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm-1-12c0-.552.448-1 1-1s1 .448 1 1v4c0 .552-.448 1-1 1s-1-.448-1-1v-4zm1 7c-.552 0-1 .448-1 1s.448 1 1 1 1-.448 1-1-.448-1-1-1z"/></svg>'
        }
    }
]);
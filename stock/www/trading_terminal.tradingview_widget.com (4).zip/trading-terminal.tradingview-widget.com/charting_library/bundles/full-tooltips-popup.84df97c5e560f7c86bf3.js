(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [8643], {
        59142: function(e, t) {
            var n, o, r;
            o = [t], void 0 === (r = "function" == typeof(n = function(e) {
                "use strict";

                function t(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                        return n
                    }
                    return Array.from(e)
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var n = !1;
                if ("undefined" != typeof window) {
                    var o = {
                        get passive() {
                            n = !0
                        }
                    };
                    window.addEventListener("testPassive", null, o), window.removeEventListener("testPassive", null, o)
                }
                var r = "undefined" != typeof window && window.navigator && window.navigator.platform && /iP(ad|hone|od)/.test(window.navigator.platform),
                    s = [],
                    i = !1,
                    l = -1,
                    a = void 0,
                    c = void 0,
                    u = function(e) {
                        return s.some((function(t) {
                            return !(!t.options.allowTouchMove || !t.options.allowTouchMove(e))
                        }))
                    },
                    d = function(e) {
                        var t = e || window.event;
                        return !!u(t.target) || 1 < t.touches.length || (t.preventDefault && t.preventDefault(), !1)
                    },
                    h = function() {
                        setTimeout((function() {
                            void 0 !== c && (document.body.style.paddingRight = c, c = void 0), void 0 !== a && (document.body.style.overflow = a, a = void 0)
                        }))
                    };
                e.disableBodyScroll = function(e, o) {
                    if (r) {
                        if (!e) return void console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.");
                        if (e && !s.some((function(t) {
                                return t.targetElement === e
                            }))) {
                            var h = {
                                targetElement: e,
                                options: o || {}
                            };
                            s = [].concat(t(s), [h]), e.ontouchstart = function(e) {
                                1 === e.targetTouches.length && (l = e.targetTouches[0].clientY)
                            }, e.ontouchmove = function(t) {
                                var n, o, r, s;
                                1 === t.targetTouches.length && (o = e, s = (n = t).targetTouches[0].clientY - l, !u(n.target) && (o && 0 === o.scrollTop && 0 < s || (r = o) && r.scrollHeight - r.scrollTop <= r.clientHeight && s < 0 ? d(n) : n.stopPropagation()))
                            }, i || (document.addEventListener("touchmove", d, n ? {
                                passive: !1
                            } : void 0), i = !0)
                        }
                    } else {
                        m = o, setTimeout((function() {
                            if (void 0 === c) {
                                var e = !!m && !0 === m.reserveScrollBarGap,
                                    t = window.innerWidth - document.documentElement.clientWidth;
                                e && 0 < t && (c = document.body.style.paddingRight, document.body.style.paddingRight = t + "px")
                            }
                            void 0 === a && (a = document.body.style.overflow, document.body.style.overflow = "hidden")
                        }));
                        var p = {
                            targetElement: e,
                            options: o || {}
                        };
                        s = [].concat(t(s), [p])
                    }
                    var m
                }, e.clearAllBodyScrollLocks = function() {
                    r ? (s.forEach((function(e) {
                        e.targetElement.ontouchstart = null, e.targetElement.ontouchmove = null
                    })), i && (document.removeEventListener("touchmove", d, n ? {
                        passive: !1
                    } : void 0), i = !1), s = [], l = -1) : (h(), s = [])
                }, e.enableBodyScroll = function(e) {
                    if (r) {
                        if (!e) return void console.error("enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices.");
                        e.ontouchstart = null, e.ontouchmove = null, s = s.filter((function(t) {
                            return t.targetElement !== e
                        })), i && 0 === s.length && (document.removeEventListener("touchmove", d, n ? {
                            passive: !1
                        } : void 0), i = !1)
                    } else 1 === s.length && s[0].targetElement === e ? (h(), s = []) : s = s.filter((function(t) {
                        return t.targetElement !== e
                    }))
                }
            }) ? n.apply(t, o) : n) || (e.exports = r)
        },
        66273: e => {
            e.exports = {
                "css-value-small-size": "18px",
                "css-value-medium-size": "22px",
                "css-value-large-size": "28px",
                "css-value-border-radius-small-size": "9px",
                "css-value-border-radius-medium-size": "11px",
                "css-value-border-radius-large-size": "8px",
                popupWidget: "popupWidget-QCFoCG9e",
                large: "large-QCFoCG9e",
                desc: "desc-QCFoCG9e",
                icon: "icon-QCFoCG9e",
                small: "small-QCFoCG9e",
                medium: "medium-QCFoCG9e",
                title: "title-QCFoCG9e",
                text: "text-QCFoCG9e",
                item: "item-QCFoCG9e",
                boldItem: "boldItem-QCFoCG9e",
                action: "action-QCFoCG9e",
                additionalWidget: "additionalWidget-QCFoCG9e"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => r
            });
            var o = n(59496);
            const r = o.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...r
                } = e;
                return o.createElement("span", { ...r,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        36636: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                render: () => y
            });
            var o = n(59496),
                r = n(87995),
                s = (n(25177), n(44377)),
                i = n(30052),
                l = n(59339),
                a = n(63694),
                c = n(16345),
                u = n(97754),
                d = n(88537),
                h = n(72571),
                p = n(97265),
                m = n(2683),
                f = n(66273);
            const v = new WeakMap,
                g = new WeakMap;

            function _(e) {
                const t = (0, p.useWatchedValueReadonly)({
                    watchedValue: e.info
                });
                if (null === t) return null;
                const n = t.map(t => {
                    const {
                        title: n,
                        titleColor: r,
                        icon: s,
                        iconClassName: i,
                        html: l,
                        action: a,
                        size: p
                    } = t;
                    v.has(t) || v.set(t, (0, c.randomHash)());
                    let _ = [];
                    return void 0 !== e.additionalWidgets && (_ = e.additionalWidgets.map(e => (g.has(e) || g.set(e, (0, c.randomHash)()), e.renderer((0, d.ensureDefined)(g.get(e)), f.additionalWidget)))), o.createElement("div", {
                        key: v.get(t),
                        className: u(f.popupWidget, f[p])
                    }, o.createElement(h.Icon, {
                        className: u(f.icon, i, f[p]),
                        icon: s || void 0
                    }), o.createElement("div", {
                        className: f.desc
                    }, o.createElement("span", {
                        style: {
                            color: r || void 0
                        },
                        className: u(f.title, f[p])
                    }, n), l && o.createElement("p", {
                        className: u(f.text, f[p])
                    }, l.map((e, t) => {
                        let n, r;
                        return (0, m.isObject)(e) ? (n = e.text, r = e.bold) : n = e, o.createElement("span", {
                            key: "html_item_" + t,
                            className: u(f.item, r && f.boldItem),
                            dangerouslySetInnerHTML: {
                                __html: n
                            }
                        })
                    })), a && o.createElement("span", {
                        className: u(a.tooltip && "apply-common-tooltip", f.action, f[p]),
                        onClick: () => {
                            e.onClose(), null == a || a.onClick()
                        },
                        title: a.tooltip
                    }, a.text), _))
                });
                return o.createElement(o.Fragment, null, n)
            }
            const w = new WeakMap;

            function C(e) {
                const {
                    statusWidgetInfos: t
                } = e, n = t.filter(e => e.visible.value()).map(t => (w.has(t) || w.set(t, (0, c.randomHash)()), o.createElement(_, {
                    key: w.get(t),
                    info: t.model.fullInfo(),
                    onClose: e.onClose,
                    additionalWidgets: t.additionalWidgets
                })));
                return o.createElement(a.DrawerManager, null, o.createElement(i.MatchMedia, {
                    rule: "screen and (max-width: 428px)"
                }, t => t ? o.createElement(l.Drawer, {
                    onClose: e.onClose,
                    position: "Bottom"
                }, n) : o.createElement(s.PopupMenu, {
                    isOpened: !0,
                    onClose: e.onClose,
                    position: e.position,
                    doNotCloseOn: e.rendererButton
                }, n)))
            }

            function y(e, t, n, s, i, l) {
                const a = {
                    rendererButton: n,
                    position: l,
                    statusWidgetInfos: s,
                    onClose: i
                };
                e ? r.render(o.createElement(C, { ...a
                }), t) : r.unmountComponentAtNode(t)
            }
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => a
            });
            var o = n(35922);
            const r = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                s = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let i = 0,
                l = !1;

            function a(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++i) {
                    const e = (0, o.getCSSProperty)(t, "overflow"),
                        r = (0, o.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, o.setStyle)(n, "right", (0, o.getScrollbarWidth)() + "px"), t.style.paddingRight = r + (0, o.getScrollbarWidth)() + "px", l = !0), t.classList.add("i-no-scroll")
                } else if (!e && i > 0 && 0 == --i && (t.classList.remove("i-no-scroll"), l)) {
                    (0, o.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (a = (0, o.getContentWidth)(n), r() ? 0 : s() ? 46 : Math.min(Math.max(a, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, o.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", l = !1
                }
                var a
            }
        },
        63694: (e, t, n) => {
            "use strict";
            n.d(t, {
                DrawerManager: () => r,
                DrawerContext: () => s
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return o.createElement(s.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const s = o.createContext(null)
        },
        59339: (e, t, n) => {
            "use strict";
            n.d(t, {
                Drawer: () => p
            });
            var o = n(59496),
                r = n(88537),
                s = n(97754),
                i = n(59142),
                l = n(85089),
                a = n(8361),
                c = n(63694),
                u = n(1227),
                d = n(28466),
                h = n(66998);

            function p(e) {
                const {
                    position: t = "Bottom",
                    onClose: n,
                    children: p,
                    className: m,
                    theme: f = h
                } = e, v = (0, r.ensureNotNull)((0, o.useContext)(c.DrawerContext)), [g, _] = (0, o.useState)(0), w = (0, o.useRef)(null), C = (0, o.useContext)(d.CloseDelegateContext);
                return (0, o.useEffect)(() => {
                    const e = (0, r.ensureNotNull)(w.current);
                    return e.focus({
                        preventScroll: !0
                    }), C.subscribe(v, n), 0 === v.currentDrawer && (0, l.setFixedBodyState)(!0), u.CheckMobile.iOS() && (0, i.disableBodyScroll)(e), _(v.addDrawer()), () => {
                        C.unsubscribe(v, n);
                        const t = v.removeDrawer();
                        u.CheckMobile.iOS() && (0, i.enableBodyScroll)(e), 0 === t && (0, l.setFixedBodyState)(!1)
                    }
                }, []), o.createElement(a.Portal, null, o.createElement("div", {
                    className: s(h.wrap, h["position" + t])
                }, g === v.currentDrawer && o.createElement("div", {
                    className: h.backdrop,
                    onClick: n
                }), o.createElement("div", {
                    className: s(h.drawer, f.drawer, h["position" + t], m),
                    ref: w,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, p)))
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => s
            });
            var o = n(59496),
                r = n(21709);

            function s(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: s,
                    touchStart: i,
                    handler: l,
                    reference: a,
                    ownerDocument: c = document
                } = e, u = (0, o.useRef)(null), d = (0, o.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, o.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: s,
                            touchStart: i
                        },
                        o = a ? a.current : u.current;
                    return (0, r.addOutsideEventListener)(d.current, o, l, c, e)
                }, [t, n, s, i, l]), a || u
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => r
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        30553: (e, t, n) => {
            "use strict";
            n.d(t, {
                MenuContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        10618: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_MENU_THEME: () => v,
                Menu: () => g
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(88537),
                l = n(97280),
                a = n(12777),
                c = n(53327),
                u = n(70981),
                d = n(63212),
                h = n(82027),
                p = n(94488),
                m = n(30553),
                f = n(16059);
            const v = f;
            class g extends o.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new d.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                        this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                    }, this._handleScrollWrapRef = e => {
                        this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                    }, this._handleMeasure = ({
                        callback: e,
                        forceRecalcPosition: t
                    } = {}) => {
                        var n, o, r, s;
                        if (this.state.isMeasureValid && !t) return;
                        const {
                            position: a
                        } = this.props, c = (0, i.ensureNotNull)(this._containerRef);
                        let u = c.getBoundingClientRect();
                        const d = document.documentElement.clientHeight,
                            h = document.documentElement.clientWidth,
                            p = null !== (n = this.props.closeOnScrollOutsideOffset) && void 0 !== n ? n : 0;
                        let m = d - 0 - p;
                        const f = u.height > m;
                        if (f) {
                            (0, i.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", u = c.getBoundingClientRect()
                        }
                        const {
                            width: v,
                            height: g
                        } = u, _ = "function" == typeof a ? a(v, g, d) : a, w = h - (null !== (o = _.overrideWidth) && void 0 !== o ? o : v) - 0, C = (0, l.clamp)(_.x, 0, Math.max(0, w)), y = 0 + p, x = d - (null !== (r = _.overrideHeight) && void 0 !== r ? r : g) - 0;
                        let b = (0, l.clamp)(_.y, y, Math.max(y, x));
                        if (_.forbidCorrectYCoord && b < _.y && (m -= _.y - b, b = _.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && _.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                        const E = null !== (s = _.overrideHeight) && void 0 !== s ? s : f ? m : void 0;
                        this.setState({
                            appearingMenuHeight: t ? this.state.appearingMenuHeight : E,
                            appearingMenuWidth: t ? this.state.appearingMenuWidth : _.overrideWidth,
                            appearingPosition: {
                                x: C,
                                y: b
                            },
                            isMeasureValid: !0
                        }, () => {
                            this._restoreScrollPosition(), e && e()
                        })
                    }, this._restoreScrollPosition = () => {
                        const e = document.activeElement,
                            t = (0, i.ensureNotNull)(this._containerRef);
                        if (null !== e && t.contains(e)) try {
                            e.scrollIntoView()
                        } catch (e) {} else(0,
                            i.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                    }, this._resizeForced = () => {
                        this.setState({
                            appearingMenuHeight: void 0,
                            appearingMenuWidth: void 0,
                            appearingPosition: void 0,
                            isMeasureValid: void 0
                        })
                    }, this._resize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            }), this._raf = null
                        }))
                    }, this._handleGlobalClose = e => {
                        this.props.onClose(e)
                    }, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }, this._handleScroll = () => {
                        this._scroll = (0, i.ensureNotNull)(this._scrollWrapRef).scrollTop
                    }, this._handleScrollOutsideEnd = () => {
                        clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            })
                        }, 80)
                    }, this._handleScrollOutside = e => {
                        e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            }), this._scrollRaf = null
                        })))
                    }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = h.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = u.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        children: i,
                        minWidth: l,
                        theme: u = f,
                        className: d,
                        maxHeight: h,
                        onMouseOver: v,
                        onMouseOut: g,
                        onKeyDown: w,
                        onFocus: C,
                        onBlur: y
                    } = this.props, {
                        appearingMenuHeight: x,
                        appearingMenuWidth: b,
                        appearingPosition: E,
                        isMeasureValid: S
                    } = this.state;
                    return o.createElement(m.MenuContext.Provider, {
                        value: this
                    }, o.createElement(p.SubmenuHandler, null, o.createElement(c.SlotContext.Provider, {
                        value: this._manager
                    }, o.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        className: s()(d, u.menuWrap, !S && u.isMeasuring),
                        style: {
                            height: x,
                            left: E && E.x,
                            minWidth: l,
                            position: "fixed",
                            top: E && E.y,
                            width: b
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: a.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: v,
                        onMouseOut: g,
                        onKeyDown: w,
                        onFocus: C,
                        onBlur: y
                    }, o.createElement("div", {
                        className: s()(u.scrollWrap, !this.props.noMomentumBasedScroll && u.momentumBased),
                        style: {
                            overflowY: void 0 !== x ? "scroll" : "auto",
                            maxHeight: h
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, o.createElement(_, {
                        className: u.menuBox
                    }, i)))), o.createElement(c.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function _(e) {
                const t = (0, i.ensureNotNull)((0, o.useContext)(p.SubmenuContext)),
                    n = o.useRef(null);
                return o.createElement("div", {
                    ref: n,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (o = e.target, null === (r = n.current) || void 0 === r ? void 0 : r.contains(o)))) return;
                        var o, r;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            g.contextType = p.SubmenuContext
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => s,
                getRootOverlapManager: () => l
            });
            var o = n(88537);
            class r {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class s {
                constructor(e = document) {
                    this._storage = new r, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const o = this._document.createElement("div");
                    if (o.style.position = t.position, o.style.zIndex = this._index.toString(), o.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(o);
                        else if (t.index <= 0) this._container.insertBefore(o, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(o, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(o, this._container.firstChild) : this._container.appendChild(o);
                    return this._windows.set(e, o), ++this._index, o
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const i = new WeakMap;

            function l(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, o.ensureDefined)(i.get(t)); {
                    const t = new s(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return i.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        28466: (e, t, n) => {
            "use strict";
            n.d(t, {
                CloseDelegateContext: () => s
            });
            var o = n(59496),
                r = n(70981);
            const s = o.createContext(r.globalCloseDelegate)
        },
        44377: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenu: () => c
            });
            var o = n(59496),
                r = n(87995),
                s = n(8361),
                i = n(10618),
                l = n(28466),
                a = n(61174);

            function c(e) {
                const {
                    controller: t,
                    children: n,
                    isOpened: c,
                    closeOnClickOutside: u = !0,
                    doNotCloseOn: d,
                    onClickOutside: h,
                    onClose: p,
                    ...m
                } = e, f = (0, o.useContext)(l.CloseDelegateContext), v = (0, a.useOutsideEvent)({
                    handler: function(e) {
                        h && h(e);
                        if (!u) return;
                        if (d && e.target instanceof Node) {
                            const t = r.findDOMNode(d);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        p()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return c ? o.createElement(s.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, o.createElement("span", {
                    ref: v,
                    style: {
                        pointerEvents: "auto"
                    }
                }, o.createElement(i.Menu, { ...m,
                    onClose: p,
                    onScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    },
                    customCloseDelegate: f,
                    ref: t
                }, n))) : null
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => a,
                PortalContext: () => c
            });
            var o = n(59496),
                r = n(87995),
                s = n(16345),
                i = n(63212),
                l = n(53327);
            class a extends o.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, s.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", r.createPortal(o.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, i.getRootOverlapManager)() : this.context
                }
            }
            a.contextType = l.SlotContext;
            const c = o.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => r,
                SlotContext: () => s
            });
            var o = n(59496);
            class r extends o.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return o.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const s = o.createContext(null)
        },
        94488: (e, t, n) => {
            "use strict";
            n.d(t, {
                SubmenuContext: () => r,
                SubmenuHandler: () => s
            });
            var o = n(59496);
            const r = o.createContext(null);

            function s(e) {
                const [t, n] = (0, o.useState)(null), s = (0, o.useRef)(null), i = (0, o.useRef)(new Map);
                return (0, o.useEffect)(() => () => {
                    null !== s.current && clearTimeout(s.current)
                }, []), o.createElement(r.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== s.current && (clearTimeout(s.current), s.current = null);
                            null === t ? n(e) : s.current = setTimeout(() => {
                                s.current = null, n(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return i.current.set(e, t), () => {
                                i.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(i.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        }
    }
]);
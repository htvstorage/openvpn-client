(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [5031], {
        41223: e => {
            e.exports = {
                title: "title-0UFIVbgR",
                withoutIcon: "withoutIcon-0UFIVbgR",
                buttons: "buttons-0UFIVbgR",
                button: "button-0UFIVbgR",
                disabled: "disabled-0UFIVbgR"
            }
        },
        89559: e => {
            e.exports = {
                wrap: "wrap-hEebyvPo",
                dialog: "dialog-hEebyvPo",
                offset: "offset-hEebyvPo",
                title: "title-hEebyvPo",
                main: "main-hEebyvPo",
                disabled: "disabled-hEebyvPo",
                icon: "icon-hEebyvPo",
                textIcon: "textIcon-hEebyvPo",
                syncIconWrap: "syncIconWrap-hEebyvPo",
                syncIcon: "syncIcon-hEebyvPo",
                rightButtons: "rightButtons-hEebyvPo",
                hover: "hover-hEebyvPo",
                expandHandle: "expandHandle-hEebyvPo",
                button: "button-hEebyvPo",
                selected: "selected-hEebyvPo",
                childOfSelected: "childOfSelected-hEebyvPo",
                renameInput: "renameInput-hEebyvPo",
                warn: "warn-hEebyvPo",
                visible: "visible-hEebyvPo"
            }
        },
        48247: e => {
            e.exports = {
                wrap: "wrap-gUfy4kTJ",
                space: "space-gUfy4kTJ",
                tree: "tree-gUfy4kTJ"
            }
        },
        95696: (e, t, n) => {
            "use strict";
            var o;
            n.d(t, {
                    IconType: () => o
                }),
                function(e) {
                    e.Svg = "svg", e.Text = "text"
                }(o || (o = {}))
        },
        6690: (e, t, n) => {
            "use strict";
            n.d(t, {
                ObjectTreeNodeRendererContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        20779: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                NodeRenderer: () => A,
                Component: () => k
            });
            var o = n(59496),
                i = n(97754),
                s = n(88537),
                r = n(72571),
                l = n(25177),
                a = n(35842),
                c = n(93838),
                d = n(95696),
                u = n(54936),
                h = n(12777),
                _ = n(80185),
                g = n(6690),
                p = n(296),
                b = n(97265),
                f = n(17324),
                v = n(61378),
                S = n(30302),
                m = n(18431),
                C = n(72351),
                y = n(31327),
                T = n(9931),
                I = n(10668),
                w = n(71261),
                M = n(89559);

            function A(e) {
                const {
                    id: t
                } = e, n = (0, o.useContext)(c.ObjectTreeContext), {
                    viewModel: i
                } = (0, s.ensureNotNull)(n), r = i.entity(t);
                return null === r ? null : o.createElement(k, { ...e,
                    entity: r
                })
            }
            const E = {
                0: void 0,
                1: v,
                2: S
            };

            function k(e) {
                const {
                    id: t,
                    isOffset: n,
                    isDisabled: v,
                    isSelected: S,
                    isChildOfSelected: A,
                    isHovered: k,
                    parentId: L,
                    entity: O,
                    isExpanded: N
                } = e, x = (0, o.useContext)(c.ObjectTreeContext), {
                    viewModel: j
                } = (0, s.ensureNotNull)(x), B = (0, o.useContext)(g.ObjectTreeNodeRendererContext), {
                    size: P
                } = (0, o.useContext)(a.SizeContext), [z, D] = (0, o.useState)(!1), G = (0, o.useRef)(null), [V, F] = (0, o.useState)(O.title()), [R, H] = (0, o.useState)(O.isLocked()), [U, K] = (0, o.useState)(O.isVisible()), [W, Z] = (0, o.useState)(O.isActualInterval()), [J, $] = (0, o.useState)(O.getDrawingSyncState()), [q, X] = (0, o.useState)(!1), Q = (0, b.useWatchedValueReadonly)({
                    watchedValue: j.getChartLayout()
                }), [Y, ee] = (0, o.useState)(!1), te = (0, o.useRef)(null);
                (0, o.useEffect)(() => {
                    const e = {};
                    O.onLockChanged().subscribe(e, () => H(O.isLocked())), O.onVisibilityChanged().subscribe(e, () => K(O.isVisible()));
                    const t = O.onTitleChanged();
                    return t && t.subscribe(e, () => F(O.title())), O.onIsActualIntervalChange().subscribe(e, () => Z(O.isActualInterval())), O.onSyncStateChanged().subscribe(e, () => $(O.getDrawingSyncState())), () => {
                        O.onIsActualIntervalChange().unsubscribeAll(e), O.onLockChanged().unsubscribeAll(e), O.onVisibilityChanged().unsubscribeAll(e), O.onSyncStateChanged().unsubscribeAll(e), t && t.unsubscribeAll(e), te.current && clearTimeout(te.current)
                    }
                }, [O]), (0, o.useEffect)(() => {
                    z && G.current && (G.current.focus(), G.current.setSelectionRange(0, V.length))
                }, [z]), (0, o.useEffect)(() => {
                    const e = {};
                    return j.hoveredObjectChanged().subscribe(e, ge), () => {
                        j.hoveredObjectChanged().unsubscribeAll(e)
                    }
                }, [N]), (0, o.useEffect)(() => {
                    j.setHoveredObject(k ? t : null)
                }, [k]), (0, o.useEffect)(() => {
                    !S && te.current && (clearTimeout(te.current), te.current = null), D(!1)
                }, [S]);
                const ne = O.getIcon(),
                    oe = {};
                if (L) {
                    const e = j.entity(L);
                    e && (oe["data-parent-name"] = e.title()), oe["data-type"] = O.hasChildren() ? "group" : "data-source"
                }
                const ie = O.title(),
                    se = null !== J ? E[J] : void 0,
                    re = k || q,
                    le = z && S,
                    ae = !!B && B.isTouch,
                    ce = !!B && B.isDialog,
                    de = W && U ? I : w,
                    ue = O.hasChildren() ? (0, l.t)("Group is hidden on current interval") : (0, l.t)("Drawing is hidden on current interval");
                return o.createElement("span", {
                    className: i(M.wrap, v && M.disabled, S && M.selected, n && M.offset, A && M.childOfSelected, q && !v && !S && !A && M.hover, ce && !v && !S && !A && M.dialog),
                    onMouseDown: function(e) {
                        z && !(0, s.ensureNotNull)(G.current).contains(e.target) && ee(!0)
                    },
                    onClick: 1 === P ? he : function(e) {
                        if (e.defaultPrevented) return;
                        if (0 !== (0, _.modifiersFromEvent)(e)) return;
                        if (te.current) e.preventDefault(), clearTimeout(te.current), te.current = null, j.openProperties(O), ee(!1);
                        else {
                            const e = j.selection().selected();
                            te.current = setTimeout(() => {
                                te.current = null, S && !Y && 1 === e.length && j.rename(O, () => D(!0)), ee(!1)
                            }, 500)
                        }
                    },
                    onContextMenu: ae ? void 0 : he
                }, !le && o.createElement(o.Fragment, null, ne && ne.type === d.IconType.Svg && o.createElement(r.Icon, {
                    icon: ne.content || "",
                    className: M.icon
                }), ne && ne.type === d.IconType.Text && o.createElement("span", {
                    className: i(M.icon, M.textIcon)
                }, ne.content), se && (0, f.isMultipleLayout)(Q) && o.createElement("div", {
                    className: M.syncIconWrap
                }, o.createElement(r.Icon, {
                    icon: se,
                    className: M.syncIcon
                })), o.createElement("span", {
                    className: i(M.title, j.isMain(O) && M.main, (!O.isVisible() || !W) && M.disabled),
                    ...oe
                }, ie), o.createElement("span", {
                    className: M.rightButtons
                }, O.canBeLocked() && o.createElement(p.ListItemButton, {
                    icon: R ? y : T,
                    className: i(M.button, (re || R) && M.visible),
                    onClick: function(e) {
                        if (e.defaultPrevented) return;
                        e.preventDefault(), j.setIsLocked(t, !O.isLocked())
                    },
                    "data-role": "button",
                    "data-name": "lock",
                    "data-active": R
                }), o.createElement(p.ListItemButton, {
                    icon: de,
                    className: i(M.button, !W && [M.warn, "apply-common-tooltip"], (re || !U || !W) && M.visible),
                    onClick: W ? function(e) {
                        if (e.defaultPrevented) return;
                        e.preventDefault(), j.setIsVisible(t, !O.isVisible())
                    } : function(e) {
                        if (e.defaultPrevented) return;
                        e.preventDefault(), j.openProperties(O, m.TabNames.visibility)
                    },
                    title: W ? void 0 : ue,
                    "data-role": "button",
                    "data-name": "hide",
                    "data-active": !U
                }), O.canBeRemoved() && o.createElement(p.ListItemButton, {
                    icon: C,
                    className: i(M.button, (ae || re) && M.visible),
                    onClick: function(e) {
                        if (e.defaultPrevented) return;
                        e.preventDefault(), e.stopPropagation(), j.remove(t)
                    },
                    "data-role": "button",
                    "data-name": "remove"
                }))), le && o.createElement(u.InputControl, {
                    value: V,
                    onChange: function(e) {
                        F(e.currentTarget.value)
                    },
                    onClick: h.preventDefault,
                    className: M.renameInput,
                    onKeyDown: function(e) {
                        27 === (0, _.hashFromEvent)(e) ? (e.preventDefault(), F(O.title()), D(!1)) : 13 === (0, _.hashFromEvent)(e) && (e.preventDefault(), _e())
                    },
                    reference: function(e) {
                        G.current = e
                    },
                    onBlur: _e,
                    onDragStart: function(e) {
                        e.preventDefault(), e.stopPropagation()
                    },
                    draggable: !0,
                    stretch: !0
                }));

                function he(e) {
                    e.defaultPrevented || z || !O.fullyConstructed() || (e.preventDefault(), e.persist(), j.openContextMenu(O, () => D(!0), e))
                }

                function _e() {
                    "" !== V && O.setName(V), F(O.title()), D(!1)
                }

                function ge(e) {
                    if (O.hasChildren() && !N) {
                        const t = null !== e && O.childrenIds().has(e);
                        X(t)
                    } else X(t === e)
                }
            }
        },
        93321: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                ObjectTree: () => V
            });
            var o = n(59496),
                i = n(7270),
                s = n.n(i),
                r = n(36349),
                l = n(72535),
                a = n(88537),
                c = n(97754),
                d = n(25177),
                u = n(72571),
                h = n(92063),
                _ = n(34816),
                g = n(85938),
                p = n(93838),
                b = n(5710),
                f = n(56085),
                v = n(23884),
                S = n(18706),
                m = n(41223);
            n(32133);

            function C(e) {
                const {
                    viewModel: t
                } = (0, a.ensureNotNull)((0, o.useContext)(p.ObjectTreeContext)), n = (0, g.useForceUpdate)(), i = t.selection();
                (0, o.useEffect)(() => {
                    const e = {};
                    return t.onChange().subscribe(e, () => n()), () => {
                        t.onChange().unsubscribeAll(e)
                    }
                }, [t]), (0, o.useEffect)(() => {
                    const e = {};
                    return i.onChange().subscribe(e, () => n()), () => {
                        i.onChange().unsubscribeAll(e)
                    }
                }, [i]);
                const s = !t.canSelectionBeUnmerged(),
                    r = t.isSelectionCopiable(),
                    l = t.isSelectionCloneable(),
                    C = !r && !l,
                    y = t.canSelectionBeGrouped();
                return o.createElement(o.Fragment, null, o.createElement("div", {
                    className: c(m.title, m.withoutIcon)
                }, (0, d.t)("Object tree"), !1), o.createElement("div", {
                    className: m.buttons
                }, o.createElement(b.ToolWidgetIconButton, {
                    className: c(m.button, !y && m.disabled),
                    icon: S,
                    onClick: function() {
                        t.createGroupFromSelection()
                    },
                    isDisabled: !y,
                    title: (0, d.t)("Create a group of drawings"),
                    "data-name": "group-button"
                }), o.createElement(_.ToolWidgetMenu, {
                    className: c(m.button, C && m.disabled),
                    isDisabled: C,
                    content: o.createElement(u.Icon, {
                        icon: f
                    }),
                    title: (0, d.t)("Clone, Copy"),
                    arrow: !1,
                    isShowTooltip: !0,
                    "data-name": "copy-clone-button"
                }, r && o.createElement(h.PopupMenuItem, {
                    "data-name": "copy",
                    label: (0, d.t)("Copy"),
                    onClick: function() {
                        t.copySelection()
                    }
                }), l && o.createElement(h.PopupMenuItem, {
                    "data-name": "clone",
                    label: (0, d.t)("Clone"),
                    onClick: function() {
                        t.cloneSelection()
                    }
                })), o.createElement(_.ToolWidgetMenu, {
                    className: c(m.button, s && m.disabled),
                    isDisabled: s,
                    content: o.createElement(u.Icon, {
                        icon: v
                    }),
                    title: (0, d.t)("Move to"),
                    arrow: !1,
                    isShowTooltip: !0,
                    "data-name": "move-to-button"
                }, o.createElement(h.PopupMenuItem, {
                    "data-name": "new-pane-above",
                    label: (0, d.t)("New pane above"),
                    onClick: function() {
                        t.unmergeSelectionUp()
                    }
                }), o.createElement(h.PopupMenuItem, {
                    "data-name": "new-pane-below",
                    label: (0, d.t)("New pane below"),
                    onClick: function() {
                        t.unmergeSelectionDown()
                    }
                }))))
            }
            var y = n(17447),
                T = n(54773),
                I = n(49392),
                w = n(51539),
                M = n(71505),
                A = n(89789),
                E = n(29881);

            function k(e) {
                return (0, T.eventChannel)(t => {
                    const n = {};
                    return e.onChange().subscribe(n, () => t((0, I.resetTree)())), e.onGroupCreated().subscribe(n, e => t((0, I.setIsExpanded)(e, !0))), e.selection().onChange().subscribe(n, e => t((0, I.setSelectedIds)(e))), () => {
                        e.onChange().unsubscribeAll(n), e.selection().onChange().unsubscribeAll(n), e.onGroupCreated().unsubscribeAll(n)
                    }
                }, T.buffers.expanding())
            }

            function* L() {
                for (;;) yield(0, r.take)([M.SELECT_NEXT, M.SELECT_PREVIOUS]), (0, A.trackObjectTreeEvent)("Select", "Arrow")
            }

            function* O() {
                for (;;) {
                    const {
                        mode: e
                    } = yield(0, r.take)(M.SET_IS_SELECTED);
                    1 === e && (0,
                        A.trackObjectTreeEvent)("Multi select", "Ctrl"), 2 === e && (0, A.trackObjectTreeEvent)("Multi select", "Shift")
                }
            }

            function* N(e) {
                for (;;) {
                    yield(0, r.take)(M.DROP_SELECTION);
                    const {
                        node: t,
                        dropType: n
                    } = (0, E.dropTargetSelector)(yield(0, r.select)());
                    if (t) {
                        const o = (0, E.selectedNodesSelector)(yield(0, r.select)()),
                            i = o.map(t => (0, a.ensureNotNull)(e.entity(t.id)));
                        let s = "Drag";
                        1 === t.level && "inside" !== n && o.some(e => 2 === e.level) ? s = "From the group" : 2 !== t.level && "inside" !== n || !o.some(e => 1 === e.level) ? 1 === o.length && o[0].parentId !== t.parentId && (s = "Existing pane") : s = "To the group", (0, A.trackObjectTreeEvent)(s, (0, A.getGaAction)(i))
                    }
                }
            }

            function* x(e) {
                yield(0, r.fork)(L), yield(0, r.fork)(O), yield(0, r.fork)(N, e)
            }

            function* j(e) {
                yield(0, r.fork)(x, e);
                const t = yield(0, r.call)(k, e);
                w.logger.logNormal("Opened object tree data source channel");
                try {
                    for (;;) {
                        const e = yield(0, r.take)(t);
                        yield(0, r.put)(e)
                    }
                } finally {
                    w.logger.logNormal("Closed object tree data source channel"), t.close()
                }
            }
            var B = n(6690),
                P = n(12777),
                z = n(30344),
                D = n(48247);
            const G = l.mobiletouch ? "touch" : "native";

            function V(e) {
                const {
                    viewModel: t,
                    showHeader: n = !0,
                    nodeRenderer: i,
                    isDialog: a = !1
                } = e, c = (0, o.useRef)(null), d = function(e) {
                    const [t, n] = (0, o.useState)(e.getChartId()), i = (0, o.useRef)(t);
                    return i.current = t, (0, o.useEffect)(() => {
                        return e.onChange().subscribe(null, t), () => {
                            e.onChange().unsubscribe(null, t)
                        };

                        function t() {
                            const t = e.getChartId();
                            i.current !== t && n(t)
                        }
                    }, []), t
                }(t), [u, h] = (0, z.useDimensions)(), [_, g] = (0, o.useState)(null), b = (0, o.useMemo)(() => ({
                    isTouch: l.touch,
                    isDialog: a
                }), [a]);
                return o.createElement(B.ObjectTreeNodeRendererContext.Provider, {
                    value: b
                }, o.createElement(p.ObjectTreeContext.Provider, {
                    value: {
                        viewModel: t
                    }
                }, o.createElement("div", {
                    className: D.wrap,
                    onContextMenu: P.preventDefaultForContextMenu
                }, n && o.createElement(C, null), o.createElement(s(), {
                    onMeasure: u
                }, o.createElement("div", {
                    className: D.space,
                    onClick: function(e) {
                        if (e.defaultPrevented) return;
                        if (!(e.target instanceof Element) || null === c.current) return;
                        e.target === c.current && t.selection().set([])
                    }
                }, null !== h && o.createElement(y.Tree, {
                    key: d,
                    height: h.height,
                    width: h.width,
                    canBeAddedToSelection: function(e) {
                        const n = t.entity(e);
                        return t.selection().canBeAddedToSelection(n)
                    },
                    nodeRenderer: i,
                    initState: function() {
                        const {
                            nodes: e,
                            selection: n
                        } = t.getState();
                        return {
                            selectedIds: n,
                            nodes: e
                        }
                    },
                    canMove: function(e, n, o) {
                        return t.isSelectionDropable(n.id, o)
                    },
                    drag: G,
                    rowHeight: F,
                    onSelect: function(e) {
                        const n = e.map(e => t.entity(e)).filter(e => null !== e);
                        t.selection().set(n)
                    },
                    onDrop: function(e) {
                        e.preventDefault();
                        const {
                            detail: {
                                target: n,
                                type: o
                            }
                        } = e;
                        t.insertSelection(n, o)
                    },
                    scrollToId: _,
                    saga: function*() {
                        yield(0, r.fork)(j, t)
                    },
                    onKeyboardSelect: function(e) {
                        g({
                            id: e
                        })
                    },
                    outerRef: function(e) {
                        c.current = e
                    }
                }))))))
            }

            function F(e, t) {
                switch (t.type) {
                    case "node":
                        return 38;
                    case "separator":
                        return 13
                }
            }
        },
        89789: (e, t, n) => {
            "use strict";
            n.d(t, {
                trackObjectTreeEvent: () => i,
                getGaAction: () => s
            });
            var o = n(32133);

            function i(e, t) {
                (0, o.trackEvent)("Object Tree", e, t)
            }

            function s(e) {
                return e.length > 1 ? "Multi select" : e[0].gaLabel()
            }
        },
        42997: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                ObjectTree: () => be,
                logger: () => ne
            });
            var o = n(88537),
                i = n(97496),
                s = n.n(i);
            var r = n(89348);

            function l(e, t) {
                return `${e}:${t}`
            }

            function a(e) {
                const t = e.split(":");
                return {
                    persistentId: t[0],
                    instanceId: t[1]
                }
            }
            var c = n(2683);
            class d {
                constructor(e) {
                    this._onChange = new(s()), this._recalculate = () => {
                        const e = this._groupModel.groups().map(e => l(e.id, e.instanceId())),
                            t = this._selectionApi.allSources();
                        this._selected = this._selected.filter(n => e.includes(n) || t.includes(n)), this._onChange.fire(this._selected)
                    }, this._model = e, this._selectionApi = new r.SelectionApi(this._model), this._groupModel = this._model.lineToolsGroupModel(), this._selected = this._getSelectedIds(), this._selectionApi.onChanged().subscribe(this, () => {
                        this._selected = this._getSelectedIds(), this._onChange.fire(this._selected)
                    }), this._groupModel.onChanged().subscribe(this, this._recalculate)
                }
                destroy() {
                    this._selectionApi.onChanged().unsubscribeAll(this), this._groupModel.onChanged().unsubscribeAll(this)
                }
                set(e) {
                    const t = [];
                    let n = e.map(e => e.id());
                    for (const o of e)
                        if (o.hasChildren()) {
                            const e = o.childrenIds();
                            t.push(...Array.from(e.values())), n = n.filter(t => !e.has(t))
                        } else t.push(o.id());
                    this._selectionApi.set(t.map(e => a(e).persistentId)), this._selected = n, this._onChange.fire(this._selected)
                }
                canBeAddedToSelection(e) {
                    return null !== e && e.canBeAddedToSelection()
                }
                onChange() {
                    return this._onChange
                }
                selected() {
                    return this._selected
                }
                _getSelectedIds() {
                    return this._selectionApi.allSources().map(e => this._model.dataSourceForId(e)).filter(c.notNull).filter(e => e.showInObjectTree()).map(e => l(e.id(), e.instanceId()))
                }
            }
            class u {
                constructor(e, t) {
                    this._controller = e, this._facade = t, this._groupModel = e.model().lineToolsGroupModel()
                }
                buildTree() {
                    const e = {};
                    for (const t of this._controller.model().panes()) {
                        const n = t.sourcesByGroup().all().filter(e => e.showInObjectTree());
                        e[t.id()] = h(t.id(), 0);
                        for (const n of this._groupModel.groups()) {
                            const i = l(n.id, n.instanceId()),
                                s = (0, o.ensureNotNull)(this._facade.getObjectById(i));
                            if (s.pane() === t) {
                                const o = [...n.lineTools()].sort((e, t) => e.zorder() > t.zorder() ? -1 : 1).map(e => l(e.id(), e.instanceId()));
                                e[s.id()] = h(s.id(), 1, t.id(), o), e[t.id()].children.push(s.id());
                                for (const t of o) e[t] = h(t, 2, s.id())
                            }
                        }
                        for (const o of n) {
                            const n = l(o.id(), o.instanceId());
                            e[n] || (e[n] = h(n, 1, t.id()), e[t.id()].children.push(n))
                        }
                        e[t.id()].children.sort((e, t) => {
                            const n = (0, o.ensureNotNull)(this._facade.getObjectById(e)),
                                i = (0, o.ensureNotNull)(this._facade.getObjectById(t));
                            return (0, o.ensureNotNull)(i.zOrder()) - (0, o.ensureNotNull)(n.zOrder())
                        })
                    }
                    return this._facade.invalidateCache(new Set(Object.keys(e))), e
                }
            }

            function h(e, t, n, o = []) {
                return {
                    id: e,
                    level: t,
                    parentId: n,
                    children: o
                }
            }
            var _ = n(25177),
                g = n(18517),
                p = n(1227),
                b = n(5796),
                f = n(93065),
                v = n(58884),
                S = n(76403),
                m = n(59930),
                C = n(50278),
                y = n(93546),
                T = n(95696),
                I = n(49894),
                w = n(13797),
                M = n(43347),
                A = n(8123);
            const E = new g.TranslatedString("show {title}", (0, _.t)("show {title}")),
                k = new g.TranslatedString("hide {title}", (0, _.t)("hide {title}")),
                L = new g.TranslatedString("lock {title}", (0, _.t)("lock {title}")),
                O = new g.TranslatedString("unlock {title}", (0, _.t)("unlock {title}")),
                N = new g.TranslatedString("change {sourceTitle} title to {newSourceTitle}", (0,
                    _.t)("change {sourceTitle} title to {newSourceTitle}")),
                x = new g.TranslatedString("insert source(s) after", (0, _.t)("insert source(s) after"));

            function j(e, t) {
                return t.every(t => !(t.pane() !== e && !t.allowsMovingbetweenPanes()))
            }

            function B(e) {
                return e instanceof S.DataSource && e.showInObjectTree() ? l(e.id(), e.instanceId()) : null
            }

            function P(e) {
                return new g.TranslatedString(e.name(), e.title())
            }
            const z = new(s());
            class D {
                constructor(e, t) {
                    this._syncStateChanged = new(s()), this._lineToolsAffectChartInvalidation = new A.FeatureToggleWatchedValue("do_not_invalidate_chart_on_changing_line_tools", !1), this._updateSyncState = () => {
                        this._syncStateChanged.fire((0, o.ensureNotNull)(this.getDrawingSyncState()))
                    }, this._undoModel = e, this._dataSource = t, (0, b.isLineTool)(this._dataSource) && (this._dataSource.linkKey().subscribe(this._updateSyncState), this._dataSource.sharingMode().subscribe(this._updateSyncState));
                    const n = this._undoModel.lineBeingCreated();
                    null !== n && n === t && n.isSynchronizable() && y.isToolCreatingNow.subscribe(this._updateSyncState)
                }
                destroy() {
                    (0, b.isLineTool)(this._dataSource) && (this._dataSource.linkKey().unsubscribe(this._updateSyncState), this._dataSource.sharingMode().unsubscribe(this._updateSyncState)), y.isToolCreatingNow.unsubscribe(this._updateSyncState)
                }
                id() {
                    return l(this._dataSource.id(), this._dataSource.instanceId())
                }
                title() {
                    const e = this._dataSource;
                    return (0, b.isLineTool)(e) ? e.properties().title.value() || e.translatedType() : (0, m.isSeries)(e) && this._undoModel.mainSeries() === e ? e.symbolTitle(void 0, void 0, (0, p.onWidget)() ? "exchange" : "listed_exchange") : e.title()
                }
                gaLabel() {
                    return (0, f.isStudy)(this._dataSource) ? "Study" : (0, b.isLineTool)(this._dataSource) ? "Drawing" : "Symbol"
                }
                canBeLocked() {
                    return (0, b.isLineTool)(this._dataSource) && this._dataSource.userEditEnabled()
                }
                canBeRemoved() {
                    return this._undoModel.mainSeries() !== this._dataSource && this._dataSource.isUserDeletable()
                }
                canBeHidden() {
                    return this._dataSource.canBeHidden()
                }
                canBeRenamed() {
                    return (0, b.isLineTool)(this._dataSource)
                }
                fullyConstructed() {
                    return this._undoModel.lineBeingCreated() !== this._dataSource
                }
                isVisible() {
                    return this._dataSource.properties().visible.value()
                }
                isActualInterval() {
                    return !(0, b.isLineTool)(this._dataSource) && !(0, f.isStudy)(this._dataSource) || this._dataSource.isActualInterval()
                }
                onIsActualIntervalChange() {
                    return (0, b.isLineTool)(this._dataSource) || (0, f.isStudy)(this._dataSource) ? this._dataSource.onIsActualIntervalChange() : z
                }
                isLocked() {
                    return !!(0, b.isLineTool)(this._dataSource) && this._dataSource.properties().frozen.value()
                }
                onVisibilityChanged() {
                    return this._dataSource.properties().visible.listeners()
                }
                onLockChanged() {
                    return (0, b.isLineTool)(this._dataSource) ? this._dataSource.properties().frozen.listeners() : z
                }
                getIcon() {
                    const e = (0, v.getAllSourcesIcons)(),
                        t = this._dataSource.getSourceIcon(),
                        n = (0, f.isStudyStrategy)(this._dataSource);
                    let o = {
                        type: T.IconType.Svg,
                        content: n ? I : w
                    };
                    if (e && t)
                        if ("loadSvg" === t.type) {
                            const [n, i] = t.svgId.split("."), s = "linetool" === n ? e.linetool[i] : e.series[Number(i)];
                            o = {
                                type: T.IconType.Svg,
                                content: s || w
                            }
                        } else "text" === t.type && (o = {
                            type: T.IconType.Text,
                            content: t.text
                        });
                    return o
                }
                setVisible(e) {
                    const t = (e ? E : k).format({
                        title: P(this._dataSource)
                    });
                    this._undoModel.setProperty(this._dataSource.properties().visible, e, t)
                }
                setLocked(e) {
                    if ((0, b.isLineTool)(this._dataSource)) {
                        const t = (e ? L : O).format({
                            title: P(this._dataSource)
                        });
                        this._undoModel.setProperty(this._dataSource.properties().frozen, e, t)
                    }
                }
                setName(e) {
                    if ((0, b.isLineTool)(this._dataSource)) {
                        const t = N.format({
                            sourceTitle: this._dataSource.properties().title.value() || P(this._dataSource),
                            newSourceTitle: e
                        });
                        this._undoModel.setProperty(this._dataSource.properties().title, e, t, this._lineToolsAffectChartInvalidation.value())
                    }
                }
                isCopiable() {
                    return this._dataSource.copiable()
                }
                isClonable() {
                    return this._dataSource.cloneable()
                }
                zOrder() {
                    return this._dataSource.zorder()
                }
                remove() {
                    this._undoModel.removeSource(this._dataSource, !1)
                }
                canBeAddedToSelection() {
                    return this._undoModel.selection().canBeAddedToSelection(this._dataSource)
                }
                setAsSelection() {
                    this._undoModel.model().selectionMacro(e => {
                        e.clearSelection(), e.addSourceToSelection(this._dataSource)
                    })
                }
                addToSelection() {
                    this._undoModel.model().selectionMacro(e => {
                        e.addSourceToSelection(this._dataSource)
                    })
                }
                addSourcesToArray(e) {
                    return e.push(this._dataSource), e
                }
                insertSourcesBeforeThis(e) {
                    this._insertSources(e, e => this._undoModel.insertBefore(e, this._dataSource))
                }
                insertSourcesAfterThis(e) {
                    this._insertSources(e, e => this._undoModel.insertAfter(e, this._dataSource))
                }
                childrenIds() {
                    return new Set
                }
                hasChildren() {
                    return !1
                }
                pane() {
                    return (0, o.ensureNotNull)(this._undoModel.model().paneForSource(this._dataSource))
                }
                allowsMovingbetweenPanes() {
                    return !(0, b.isLineTool)(this._dataSource)
                }
                canBeAddedToGroup() {
                    return (0, b.isLineTool)(this._dataSource) && this._dataSource.boundToSymbol()
                }
                canInsertBeforeThis(e) {
                    return this._canInsertBeforeOrAfter(e)
                }
                canInsertAfterThis(e) {
                    return this._canInsertBeforeOrAfter(e)
                }
                detachFromParent() {
                    if ((0, b.isLineTool)(this._dataSource)) {
                        const e = this._undoModel.model(),
                            t = this._undoModel.lineToolsGroupController(),
                            n = e.lineToolsGroupModel().groupForLineTool(this._dataSource);
                        null !== n && t.excludeLineToolFromGroup(n, this._dataSource)
                    }
                }
                onTitleChanged() {
                    const e = this._dataSource.properties().title;
                    return e ? e.listeners() : void 0
                }
                canBeSyncedInLayout() {
                    return (0, b.isLineTool)(this._dataSource) && this._dataSource.isSynchronizable()
                }
                onSyncStateChanged() {
                    return this._syncStateChanged
                }
                setDrawingSyncState(e) {
                    if (!this.canBeSyncedInLayout() || !this.fullyConstructed()) return;
                    const t = this._dataSource;
                    switch (e) {
                        case 0:
                            if (null === t.linkKey().value()) return;
                            this._undoModel.unlinkLines([t]);
                            break;
                        case 1:
                            if (null !== t.linkKey().value()) return;
                            this._undoModel.copyToOtherCharts([t])
                    }
                }
                getDrawingSyncState() {
                    return this.canBeSyncedInLayout() ? this.fullyConstructed() && null !== this._dataSource.linkKey().value() ? 1 : 0 : null
                }
                doNotAffectChartInvalidation() {
                    return (0, b.isLineTool)(this._dataSource) && this._lineToolsAffectChartInvalidation.value()
                }
                _canInsertBeforeOrAfter(e) {
                    const t = this._undoModel.model();
                    if (!j(this.pane(), e)) return !1;
                    if ((0, b.isLineTool)(this._dataSource)) {
                        if (null !== t.lineToolsGroupModel().groupForLineTool(this._dataSource) && e.some(e => !e.canBeAddedToGroup())) return !1
                    }
                    return !0
                }
                _insertSources(e, t) {
                    const n = this._undoModel.model(),
                        i = this._undoModel.lineToolsGroupController();
                    this._undoModel.beginUndoMacro(x);
                    const s = () => {
                            e.forEach(e => e.detachFromParent())
                        },
                        r = e.reduce((e, t) => t.addSourcesToArray(e), []);
                    if ((0, b.isLineTool)(this._dataSource)) {
                        const t = n.lineToolsGroupModel().groupForLineTool(this._dataSource);
                        null !== t ? ((0, o.assert)(!e.some(e => e.hasChildren())), r.forEach(e => {
                            (0, b.isLineTool)(e) && (t.containsLineTool(e) || i.addLineToolToGroup(t, e))
                        })) : s()
                    } else s();
                    t(r), this._undoModel.endUndoMacro()
                }
            }
            class G {
                constructor(e, t) {
                    this._onTitleChanged = new(s()), this._onVisibilityChanged = new(s()), this._onLockChanged = new(s()), this._onIsActualIntervalChanged = new(s()), this._syncStateChanged = new(s()), this._linkKeyChangedBound = this._linkKeyChanged.bind(this), this._lineToolsAffectChartInvalidation = new A.FeatureToggleWatchedValue("do_not_invalidate_chart_on_changing_line_tools", !1), this._undoModel = e, this._group = t, this._lineTools = t.lineTools(), this._paneId = (0, o.ensureNotNull)(e.model().paneForSource(this._lineTools[0])).id();
                    const n = () => {
                        this._lineTools.forEach(e => {
                            e.properties().visible.listeners().subscribe(this, () => this._onVisibilityChanged.fire()), e.properties().frozen.listeners().subscribe(this, () => this._onLockChanged.fire()), e.onIsActualIntervalChange().subscribe(this, () => this._onIsActualIntervalChanged.fire()), e.linkKey().subscribe(this._linkKeyChangedBound), e.sharingMode().subscribe(this._linkKeyChangedBound)
                        })
                    };
                    this._group.onChanged().subscribe(this, e => {
                        this._unsubscribeFromAllLineTools(), this._lineTools = this._group.lineTools(), n(), e.lockedChanged && this._onLockChanged.fire(), e.visibilityChanged && this._onVisibilityChanged.fire(), e.titleChanged && this._onTitleChanged.fire(), e.isActualIntervalChanged && this._onIsActualIntervalChanged.fire();
                        const t = this.getDrawingSyncState();
                        null !== t && this._syncStateChanged.fire(t)
                    }), n(), this._lastActualZOrder = this.zOrder(), this._lastIsVisible = this.isVisible(), this._lastIsActualInterval = this.isActualInterval(), this._lastIsLocked = this.isLocked()
                }
                destroy() {
                    this._unsubscribeFromAllLineTools(), this._group.onChanged().unsubscribeAll(this)
                }
                id() {
                    return l(this._group.id, this._group.instanceId())
                }
                title() {
                    return this._group.name()
                }
                gaLabel() {
                    return "Group"
                }
                getIcon() {
                    return {
                        type: T.IconType.Svg,
                        content: M
                    }
                }
                canBeRemoved() {
                    return !0
                }
                canBeHidden() {
                    return !0
                }
                canBeLocked() {
                    return !0
                }
                canBeRenamed() {
                    return !0
                }
                fullyConstructed() {
                    return !0
                }
                isVisible() {
                    return this._group.lineTools().length > 0 && (this._lastIsVisible = "Invisible" !== this._group.visibility()), this._lastIsVisible
                }
                isActualInterval() {
                    return this._group.lineTools().length > 0 && (this._lastIsActualInterval = this._group.lineTools().some(e => e.isActualInterval())), this._lastIsActualInterval
                }
                onIsActualIntervalChange() {
                    return this._onIsActualIntervalChanged
                }
                isLocked() {
                    return this._group.lineTools().length > 0 && (this._lastIsLocked = "Locked" === this._group.locked()), this._lastIsLocked
                }
                onTitleChanged() {
                    return this._onTitleChanged
                }
                onVisibilityChanged() {
                    return this._onVisibilityChanged
                }
                onLockChanged() {
                    return this._onLockChanged
                }
                setVisible(e) {
                    this._undoModel.lineToolsGroupController().setGroupVisibility(this._group, e)
                }
                setLocked(e) {
                    this._undoModel.lineToolsGroupController().setGroupLock(this._group, e)
                }
                setName(e) {
                    this._undoModel.lineToolsGroupController().setGroupName(this._group, e)
                }
                isCopiable() {
                    return !1
                }
                isClonable() {
                    return !1
                }
                zOrder() {
                    return this._group.lineTools().length > 0 && (this._lastActualZOrder = this._group.lineTools()[0].zorder()), this._lastActualZOrder
                }
                remove() {
                    this._undoModel.lineToolsGroupController().removeGroup(this._group)
                }
                canBeAddedToSelection() {
                    const e = this._undoModel.model();
                    return this._lineTools.every(t => e.selection().canBeAddedToSelection(t))
                }
                setAsSelection() {
                    this._undoModel.model().selectionMacro(e => {
                        e.clearSelection(), this._lineTools.forEach(t => e.addSourceToSelection(t))
                    })
                }
                addToSelection() {
                    this._undoModel.model().selectionMacro(e => {
                        this._lineTools.forEach(t => e.addSourceToSelection(t))
                    })
                }
                addSourcesToArray(e) {
                    return e.push(...this._lineTools), e
                }
                detachFromParent() {}
                insertSourcesBeforeThis(e) {
                    const t = this._insertBeforeTarget();
                    this._insertSources(e, e => this._undoModel.insertBefore(e, t))
                }
                insertSourcesAfterThis(e) {
                    const t = this._insertAfterTarget();
                    this._insertSources(e, e => this._undoModel.insertAfter(e, t))
                }
                childrenIds() {
                    const e = [...this._lineTools];
                    return e.sort((e, t) => t.zorder() - e.zorder()), new Set(e.map(e => l(e.id(), e.instanceId())))
                }
                hasChildren() {
                    return !0
                }
                pane() {
                    return (0, o.ensureDefined)(this._undoModel.model().panes().find(e => e.id() === this._paneId))
                }
                allowsMovingbetweenPanes() {
                    return !1
                }
                canBeAddedToGroup() {
                    return !1
                }
                canInsertBeforeThis(e) {
                    return this._canInsertBeforeOrAfter(e)
                }
                canInsertAfterThis(e) {
                    return this._canInsertBeforeOrAfter(e)
                }
                canBeSyncedInLayout() {
                    return this._lineTools.length > 0 && this._lineTools[0].isSynchronizable()
                }
                onSyncStateChanged() {
                    return this._syncStateChanged
                }
                setDrawingSyncState(e) {
                    if (this.canBeSyncedInLayout()) switch (e) {
                        case 0:
                            const e = this._lineTools.filter(e => null !== e.linkKey().value());
                            e.length > 0 && this._undoModel.unlinkLines(e);
                            break;
                        case 1:
                            const t = this._lineTools.filter(e => null === e.linkKey().value());
                            t.length > 0 && this._undoModel.copyToOtherCharts(t)
                    }
                }
                getDrawingSyncState() {
                    return this.canBeSyncedInLayout() ? this._lineTools.every(e => null !== e.linkKey().value()) ? 1 : 0 : null
                }
                doNotAffectChartInvalidation() {
                    return this._lineToolsAffectChartInvalidation.value()
                }
                _linkKeyChanged() {
                    this._syncStateChanged.fire((0, o.ensureNotNull)(this.getDrawingSyncState()))
                }
                _canInsertBeforeOrAfter(e) {
                    return j(this.pane(), e)
                }
                _insertSources(e, t) {
                    this._undoModel.beginUndoMacro(x);
                    const n = e.reduce((e, t) => t.addSourcesToArray(e), []);
                    e.forEach(e => e.detachFromParent()), t(n), this._undoModel.endUndoMacro()
                }
                _insertBeforeTarget() {
                    return (0, o.ensureNotNull)(this._lineTools.reduce((e, t) => null === e ? t : e.zorder() < t.zorder() ? e : t, null))
                }
                _insertAfterTarget() {
                    return (0, o.ensureNotNull)(this._lineTools.reduce((e, t) => null === e ? t : e.zorder() > t.zorder() ? e : t, null))
                }
                _unsubscribeFromAllLineTools() {
                    this._lineTools.forEach(e => {
                        e.properties().visible.listeners().unsubscribeAll(this), e.properties().frozen.listeners().unsubscribeAll(this), e.onIsActualIntervalChange().unsubscribeAll(this), e.linkKey().unsubscribe(this._linkKeyChangedBound), e.sharingMode().unsubscribe(this._linkKeyChangedBound)
                    })
                }
            }
            class V {
                constructor(e) {
                    this._hoveredObjectChanged = new(s()), this._entitiesCache = new Map, this._undoModel = e, this._undoModel.model().hoveredSourceChanged().subscribe(this, this._onModelHoveredSourceChanged)
                }
                destroy() {
                    for (const e of this._entitiesCache.values()) null == e || e.destroy()
                }
                getObjectById(e) {
                    if (this._entitiesCache.has(e)) return (0, o.ensureDefined)(this._entitiesCache.get(e));
                    const t = this._createObjectById(e);
                    return this._entitiesCache.set(e, t), t
                }
                invalidateCache(e) {
                    Array.from(this._entitiesCache.keys()).forEach(t => {
                        var n;
                        e.has(t) || (null === (n = this._entitiesCache.get(t)) || void 0 === n || n.destroy(), this._entitiesCache.delete(t))
                    })
                }
                canBeGroupped(e) {
                    if (0 === e.length || 1 === e.length && e[0].hasChildren()) return !1;
                    const t = [];
                    if (e.forEach(e => e.addSourcesToArray(t)), t.some(e => !(0, b.isLineTool)(e) || !e.boundToSymbol())) return !1;
                    const n = this._undoModel.model(),
                        o = t.map(e => n.paneForSource(e));
                    return !(new Set(o).size > 1)
                }
                contextMenuActions(e, t, n) {
                    const o = new C.ActionsProvider(e, n),
                        i = [];
                    return t.forEach(e => e.addSourcesToArray(i)), o.contextMenuActionsForSources(i)
                }
                insertBefore(e, t) {
                    t.insertSourcesAfterThis(e)
                }
                insertAfter(e, t) {
                    t.insertSourcesBeforeThis(e)
                }
                setHoveredObject(e) {
                    const t = this._undoModel.model();
                    if (null === e) return void t.setHoveredSource(null, null);
                    const n = t.dataSourceForId(e);
                    null !== n && t.setHoveredSource(n, null)
                }
                hoveredObjectId() {
                    return B(this._undoModel.model().hoveredSource())
                }
                hoveredObjectChanged() {
                    return this._hoveredObjectChanged
                }
                _onModelHoveredSourceChanged(e) {
                    this._hoveredObjectChanged.fire(B(e))
                }
                _createObjectById(e) {
                    const t = a(e).persistentId,
                        n = this._undoModel.model(),
                        o = n.dataSourceForId(t);
                    if (null !== o) return new D(this._undoModel, o);
                    const i = n.lineToolsGroupModel().groupForId(t);
                    return null !== i ? new G(this._undoModel, i) : null
                }
            }
            var F = n(89789),
                R = n(64092),
                H = n(9696),
                U = n(90687),
                K = n(80185),
                W = n(51951),
                Z = n(94489),
                J = n.n(Z),
                $ = n(69264),
                q = n(801),
                X = n(26),
                Q = n(91586),
                Y = n(3922),
                ee = n(86312),
                te = n(18706);
            const ne = (0, W.getLogger)("Platform.GUI.ObjectTree");
            const oe = new g.TranslatedString("move objects", (0, _.t)("move objects")),
                ie = new g.TranslatedString("lock objects", (0, _.t)("lock objects")),
                se = new g.TranslatedString("unlock objects", (0, _.t)("unlock objects")),
                re = new g.TranslatedString("show objects", (0, _.t)("show objects")),
                le = new g.TranslatedString("hide objects", (0, _.t)("hide objects")),
                ae = new g.TranslatedString("remove objects", (0, _.t)("remove objects")),
                ce = (0, _.t)("Create a group of drawings"),
                de = (0, _.t)("Rename"),
                ue = (0, _.t)("Unlock"),
                he = (0, _.t)("Lock"),
                _e = (0, _.t)("Hide"),
                ge = (0, _.t)("Show"),
                pe = (0, _.t)("Remove");
            class be {
                constructor(e) {
                    this._nodes = {}, this._onChange = new(s()), this._onGroupCreated = new(s()), this._subscriptions = [], this._removeSourcesPromise = null, this._timeout = null, this._objects = [], this._options = {
                        general: !0,
                        mainSeries: !0,
                        mainSeriesTrade: !0,
                        esdStudies: !0,
                        fundamentals: !0,
                        studies: !0,
                        lineTools: !0,
                        publishedCharts: !0,
                        ordersAndPositions: !0,
                        alerts: !1,
                        chartEvents: !0,
                        objectTree: !1,
                        gotoLineTool: !0
                    }, this._isContextMenuOpened = new(J())(!1), this._getObjectsToModify = e => {
                        const t = this.selection().selected();
                        return t.find(t => t === e) ? t.map(this._ensuredEntity) : [this._ensuredEntity(e)]
                    }, this._onActiveChartChanged = () => {
                        this._cleanup(), this._init()
                    }, this._cleanup = () => {
                        null !== this._timeout && (clearTimeout(this._timeout), this._timeout = null), this._subscriptions.forEach(e => {
                            e.unsubscribeAll(this)
                        }), this._selection.destroy(), this._chart.unsubscribe(this._onActiveChartChanged), null !== this._removeSourcesPromise && this._removeSourcesPromise.cancel(), this._facade.destroy()
                    }, this._init = () => {
                        const e = this._chart.value();
                        e.hasModel() && (this._controller = e.model(), this._groupController = this._controller.lineToolsGroupController(), this._model = this._controller.model(), this._groupModel = this._model.lineToolsGroupModel(), this._facade = new V(this._controller), this._subscriptions = [this._model.mainSeries().onStyleChanged(), this._model.mainSeries().dataEvents().symbolResolved(), this._model.mainSeries().onIntervalChanged(), this._model.panesCollectionChanged(), this._model.dataSourceCollectionChanged(), this._groupModel.onChanged()], this._subscriptions.forEach(e => {
                            e.subscribe(this, this._update)
                        }), this._chart.subscribe(this._onActiveChartChanged), this._selection = new d(this._model), this._update())
                    }, this._update = () => {
                        null === this._timeout && (this._timeout = setTimeout(() => {
                            this._recalculateTree(), this._onChange.fire(), this._timeout = null
                        }))
                    }, this._ensuredEntity = e => (0, o.ensureNotNull)(this._getEntityById(e)), this._chart = e, this._init()
                }
                destroy() {
                    this._cleanup()
                }
                getState() {
                    return {
                        nodes: Object.values(this._nodes),
                        selection: this._selection.selected()
                    }
                }
                getChartId() {
                    return this._chart.value().id()
                }
                insertSelection(e, t) {
                    const n = this._facade,
                        o = this.selection().selected().map(this._ensuredEntity),
                        [i, s] = this._normalizeTargetAndDropType(e, t);
                    this._controller.withMacro(oe, () => {
                        switch (s) {
                            case "before":
                                n.insertBefore(o, i);
                                break;
                            case "after":
                                n.insertAfter(o, i)
                        }
                    }), this._update()
                }
                entity(e) {
                    return this._facade.getObjectById(e)
                }
                isMain(e) {
                    return a(e.id()).persistentId === this._controller.mainSeries().id()
                }
                selection() {
                    return this._selection
                }
                setIsLocked(e, t) {
                    const n = this._getObjectsToModify(e),
                        o = n.every(e => e.doNotAffectChartInvalidation()),
                        i = t ? ie : se;
                    this._controller.withMacro(i, () => {
                        for (const e of n) e.setLocked(t)
                    }, o), (0, F.trackObjectTreeEvent)("Lock", (0, F.getGaAction)(n))
                }
                setIsVisible(e, t) {
                    const n = this._getObjectsToModify(e),
                        o = n.every(e => e.doNotAffectChartInvalidation()),
                        i = t ? re : le;
                    this._controller.withMacro(i, () => {
                        for (const e of n) e.setVisible(t)
                    }, o), (0, F.trackObjectTreeEvent)("Hide", (0, F.getGaAction)(n))
                }
                remove(e) {
                    const t = () => {
                            const e = n.every(e => e.doNotAffectChartInvalidation());
                            this._controller.withMacro(ae, () => {
                                for (const e of n) e.remove()
                            }, e), (0, F.trackObjectTreeEvent)("Delete", (0, F.getGaAction)(n)), this._update()
                        },
                        n = this._getObjectsToModify(e);
                    t()
                }
                canSelectionBeGrouped() {
                    const e = this._getSelectedEntities();
                    return this._facade.canBeGroupped(e)
                }
                createGroupFromSelection() {
                    const e = this._groupController.createGroupFromSelection();
                    (0, F.trackObjectTreeEvent)("Create Group");
                    const t = l(e.id, e.instanceId());
                    this.selection().set([this._ensuredEntity(t)]), this._onGroupCreated.fire(t), this._update()
                }
                isSelectionDropable(e, t) {
                    const n = this.selection().selected().map(this._ensuredEntity),
                        [o, i] = this._normalizeTargetAndDropType(e, t);
                    switch (i) {
                        case "after":
                            return o.canInsertAfterThis(n);
                        case "before":
                            return o.canInsertBeforeThis(n)
                    }
                }
                onChange() {
                    return this._onChange
                }
                onGroupCreated() {
                    return this._onGroupCreated
                }
                isSelectionCloneable() {
                    const e = this._getSelectedEntities();
                    return e.length > 0 && e.every(e => e.isClonable())
                }
                isSelectionCopiable() {
                    const e = this._getSelectedEntities();
                    return e.length > 0 && e.every(e => e.isCopiable())
                }
                openProperties(e, t) {
                    const n = this._model.dataSourceForId(a(e.id()).persistentId);
                    this.selection().selected().length > 1 && this.selection().selected().includes(e.id()) ? this._chart.value().showSelectedSourcesProperties(t) : (this.selection().set([e]), null !== n ? this._controller.mainSeries() === n ? this._chart.value().showGeneralChartProperties() : ((0, b.isLineTool)(n) || (0, f.isStudy)(n)) && this._chart.value().showChartPropertiesForSource(n, t) : this._chart.value().showChartPropertiesForSources({
                        sources: this._chart.value().model().selection().lineDataSources(),
                        title: e.title(),
                        tabName: t,
                        renamable: !0
                    }))
                }
                canSelectionBeUnmerged() {
                    const e = this._getSelectedEntities();
                    return 1 === e.length && this.canNodeWithIdBeUnmerged(a(e[0].id()).persistentId)
                }
                canNodeWithIdBeUnmerged(e) {
                    const t = this._model.dataSourceForId(e);
                    return null !== t && (0, R.isPriceDataSource)(t) && this._model.isUnmergeAvailableForSource(t)
                }
                unmergeSelectionUp() {
                    this._unmergeSelection(0)
                }
                unmergeSelectionDown() {
                    this._unmergeSelection(1)
                }
                copySelection() {
                    const e = this._getSelectedEntities(),
                        t = e.map(e => (0, o.ensureNotNull)(this._model.dataSourceForId(a(e.id()).persistentId)));
                    this._chart.value().chartWidgetCollection().clipboard.uiRequestCopy(t), (0, F.trackObjectTreeEvent)("Copy", (0, F.getGaAction)(e))
                }
                cloneSelection() {
                    const e = this._getSelectedEntities(),
                        t = e.map(e => (0, o.ensureNotNull)(this._model.dataSourceForId(a(e.id()).persistentId)));
                    t.every(b.isLineTool) && (this._controller.cloneLineTools([...t], !1), (0, F.trackObjectTreeEvent)("Clone", (0, F.getGaAction)(e)))
                }
                rename(e, t) {
                    const n = this._getObjectsToModify(e.id());
                    1 === n.length && n.some(e => e.canBeRenamed()) && (t(), (0, F.trackObjectTreeEvent)("Rename", (0, F.getGaAction)(n)))
                }
                async openContextMenu(e, t, n) {
                    var o;
                    this._objects = this._getObjectsToModify(e.id());
                    const i = this._facade.canBeGroupped(this._objects);
                    let s;
                    if (this._objects.some(e => e.hasChildren())) s = this._getActionsForGroupItem(e, t, i);
                    else {
                        const e = await this._facade.contextMenuActions(this._chart.value(), this._objects, this._options);
                        if (s = Array.from(e).filter((e, t, n) => "separator" !== e.type || !n[t + 1] || "separator" !== n[t + 1].type), 1 === this._objects.length && this._objects[0].canBeRenamed()) {
                            const e = s.findIndex(e => "Copy" === e.id);
                            s.splice(-1 === e ? s.length : e + 1, 0, this._getRenameAction(t))
                        }
                        if (i) {
                            const e = s.findIndex(e => "Clone" === e.id);
                            s.splice(-1 === e ? 0 : e, 0, this._getGroupAction())
                        }
                    }
                    if (s.length > 0) {
                        this._chart.value().updateActions();
                        const t = a(e.id()).persistentId,
                            i = this._model.dataSourceForId(t),
                            r = i instanceof m.Series,
                            l = 0 !== e.childrenIds().size;
                        let c;
                        c = r ? {
                            menuName: "ObjectTreeContextMenu",
                            detail: {
                                type: "series",
                                id: i.instanceId()
                            }
                        } : (0, b.isLineTool)(i) ? {
                            menuName: "ObjectTreeContextMenu",
                            detail: {
                                type: "shape",
                                id: null !== (o = null == i ? void 0 : i.id()) && void 0 !== o ? o : null
                            }
                        } : l ? {
                            menuName: "ObjectTreeContextMenu",
                            detail: {
                                type: "groupOfShapes",
                                id: t || null
                            }
                        } : {
                            menuName: "ObjectTreeContextMenu",
                            detail: {
                                type: "study",
                                id: (null == i ? void 0 : i.id()) || null
                            }
                        }, H.ContextMenuManager.showMenu(s, n, {
                            takeFocus: !0,
                            returnFocus: !0
                        }, c, () => {
                            this._isContextMenuOpened.setValue(!1)
                        }).then(() => {
                            this._isContextMenuOpened.setValue(!0)
                        })
                    }
                }
                setHoveredObject(e) {
                    this._facade.setHoveredObject(e)
                }
                hoveredObjectChanged() {
                    return this._facade.hoveredObjectChanged()
                }
                getNextNodeIdAfterRemove(e) {
                    var t;
                    const {
                        nodes: n
                    } = this.getState(), i = a(e).persistentId, s = n.find(t => t.id === e), r = this.entity(e);
                    if (!(s && s.parentId && r && r.canBeRemoved())) return null;
                    if ((null === (t = r.pane().mainDataSource()) || void 0 === t ? void 0 : t.id()) === i && !this.canNodeWithIdBeUnmerged(i)) {
                        const e = n.filter(e => 0 === e.level).map(e => e.id),
                            t = this._takeNextOrPrevElement(e, s.parentId);
                        return (0, o.ensureDefined)(n.find(e => e.id === t)).children[0]
                    }
                    const l = (0, o.ensureDefined)(n.find(e => e.id === s.parentId)).children;
                    return 1 === l.length ? this.getNextNodeIdAfterRemove(s.parentId) : this._takeNextOrPrevElement(l, e)
                }
                isContextMenuOpened() {
                    return this._isContextMenuOpened.readonly()
                }
                getChartLayout() {
                    return this._chart.value().chartWidgetCollection().layout
                }
                _takeNextOrPrevElement(e, t) {
                    const n = e.indexOf(t);
                    return e[n === e.length - 1 ? n - 1 : n + 1]
                }
                _getGroupAction() {
                    return new U.Action({
                        actionId: "ObjectsTree.CreateGroup",
                        label: ce,
                        icon: te,
                        onExecute: () => {
                            this.createGroupFromSelection()
                        }
                    })
                }
                _getRenameAction(e) {
                    return new U.Action({
                        actionId: "ObjectsTree.RenameItem",
                        label: de,
                        icon: Y,
                        onExecute: () => {
                            e(), (0, F.trackObjectTreeEvent)("Context menu rename", (0, F.getGaAction)(this._objects))
                        }
                    })
                }
                _getActionsForGroupItem(e, t, n) {
                    const o = [];
                    this._objects.forEach(e => e.addSourcesToArray(o));
                    const i = [];
                    1 === this._objects.length && i.unshift(this._getRenameAction(t), new U.Separator), n && i.unshift(this._getGroupAction(), new U.Separator);
                    const s = (0, C.createSyncDrawingActions)(this._chart.value(), o.filter(b.isLineTool));
                    return s.length && (s.shift(), s.push(new U.Separator), i.push(...s)), i.push(new U.Action({
                        actionId: "ObjectsTree.ToggleItemLocked",
                        label: e.isLocked() ? ue : he,
                        icon: e.isLocked() ? $ : q,
                        onExecute: () => this.setIsLocked(e.id(), !e.isLocked())
                    }), new U.Action({
                        actionId: "ObjectsTree.ToggleItemVisibility",
                        label: e.isVisible() ? _e : ge,
                        icon: e.isVisible() ? X : Q,
                        onExecute: () => this.setIsVisible(e.id(), !e.isVisible())
                    }), new U.Action({
                        actionId: "ObjectsTree.RemoveItem",
                        label: pe,
                        icon: ee,
                        onExecute: () => this.remove(e.id()),
                        hotkeyHash: K.isMacKeyboard ? 8 : 46
                    }), new U.Separator, this._chart.value().actions().format), i
                }
                _unmergeSelection(e) {
                    const t = this._getSelectedEntities();
                    if (1 !== t.length) throw new Error("Only one object can be unmerged");
                    const n = t[0],
                        i = (0, o.ensureNotNull)(this._model.dataSourceForId(a(n.id()).persistentId));
                    if (!(0, R.isPriceDataSource)(i)) throw new Error("Entity is not IPriceDataSource");
                    (0 === e ? this._controller.unmergeSourceUp : this._controller.unmergeSourceDown).call(this._controller, i);
                    const s = 0 === e ? "New pane above" : "New pane below";
                    (0, F.trackObjectTreeEvent)(s, (0, F.getGaAction)([n]))
                }
                _recalculateTree() {
                    const e = new u(this._controller, this._facade);
                    this._nodes = e.buildTree()
                }
                _normalizeTargetAndDropType(e, t) {
                    let n = this._ensuredEntity(e);
                    return "inside" === t && (t = "before", n = (0, o.ensureNotNull)(this.entity([...n.childrenIds()].shift() || ""))), [n, t]
                }
                _getSelectedEntities() {
                    const {
                        selected: e,
                        removed: t
                    } = this._selection.selected().reduce((e, t) => {
                        const n = this._getEntityById(t);
                        return n ? (e.selected.push(n), e) : (e.removed.push(t), e)
                    }, {
                        selected: [],
                        removed: []
                    });
                    return t.length && ne.logWarn("Detected dangling sources in selection. They will be ignored: " + JSON.stringify(t)), e
                }
                _getEntityById(e) {
                    return this._facade.getObjectById(e)
                }
            }
        },
        30344: (e, t, n) => {
            "use strict";
            n.d(t, {
                useDimensions: () => i
            });
            var o = n(59496);

            function i() {
                const [e, t] = (0, o.useState)(null);
                return [(0, o.useCallback)(n => {
                    n.width === (null == e ? void 0 : e.width) && n.height === e.height || t(n)
                }, [e]), e]
            }
        },
        85938: (e, t, n) => {
            "use strict";
            n.d(t, {
                useForceUpdate: () => i
            });
            var o = n(59496);
            const i = () => {
                const [, e] = (0, o.useReducer)((e, t) => e + 1, 0);
                return e
            }
        },
        43347: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 11.5v8a1 1 0 0 0 1 1h15a1 1 0 0 0 1-1v-8m-17 0v-4a1 1 0 0 1 1-1h4l2 2h9a1 1 0 0 1 1 1v2m-17 0h17"/></svg>'
        },
        18706: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M5.5 6C4.67 6 4 6.67 4 7.5V20.5c0 .83.67 1.5 1.5 1.5H16v-1H5.5a.5.5 0 0 1-.5-.5V12h16v1h1V9.5c0-.83-.67-1.5-1.5-1.5h-8.8L9.86 6.15 9.71 6H5.5zM21 11H5V7.5c0-.28.22-.5.5-.5h3.8l1.85 1.85.14.15h9.21c.28 0 .5.22.5.5V11zm1 11v-3h3v-1h-3v-3h-1v3h-3v1h3v3h1z"/></svg>'
        },
        10668: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M2.448 10.124a10.82 10.82 0 0 1-.336-.609L2.105 9.5l.007-.015a12.159 12.159 0 0 1 1.686-2.466C5.002 5.665 6.752 4.373 9.05 4.373c2.297 0 4.047 1.292 5.25 2.646a12.166 12.166 0 0 1 1.687 2.466l.007.015-.007.015a12.163 12.163 0 0 1-1.686 2.466c-1.204 1.354-2.954 2.646-5.251 2.646-2.298 0-4.048-1.292-5.252-2.646a12.16 12.16 0 0 1-1.35-1.857zm14.558-.827l-.456.203.456.203v.002l-.003.005-.006.015-.025.052a11.813 11.813 0 0 1-.461.857 13.163 13.163 0 0 1-1.463 2.011c-1.296 1.46-3.296 2.982-5.998 2.982-2.703 0-4.703-1.522-6-2.982a13.162 13.162 0 0 1-1.83-2.677 7.883 7.883 0 0 1-.118-.243l-.007-.015-.002-.005v-.001l.456-.204-.456-.203v-.002l.002-.005.007-.015a4.66 4.66 0 0 1 .119-.243 13.158 13.158 0 0 1 1.83-2.677c1.296-1.46 3.296-2.982 5.999-2.982 2.702 0 4.702 1.522 5.998 2.981a13.158 13.158 0 0 1 1.83 2.678 8.097 8.097 0 0 1 .119.243l.006.015.003.005v.001zm-.456.203l.456-.203.09.203-.09.203-.456-.203zM1.092 9.297l.457.203-.457.203-.09-.203.09-.203zm9.958.203c0 1.164-.917 2.07-2 2.07-1.084 0-2-.906-2-2.07 0-1.164.916-2.07 2-2.07 1.083 0 2 .906 2 2.07zm1 0c0 1.695-1.344 3.07-3 3.07-1.657 0-3-1.375-3-3.07 0-1.695 1.343-3.07 3-3.07 1.656 0 3 1.375 3 3.07z"/></svg>'
        },
        31327: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M7 5.5a2.5 2.5 0 0 1 5 0V7H7V5.5zM6 7V5.5a3.5 3.5 0 1 1 7 0V7a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2zm8 2a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V9zm-3 2.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/></svg>'
        },
        23884: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M21.106 12.5H6.894a.5.5 0 0 1-.318-.886L14 5.5l7.424 6.114a.5.5 0 0 1-.318.886zM21.106 16.5H6.894a.5.5 0 0 0-.318.886L14 23.5l7.424-6.114a.5.5 0 0 0-.318-.886z"/></svg>'
        },
        91586: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M4.605 14.089A10.052 10.052 0 0 1 4.56 14l.046-.089a17.18 17.18 0 0 1 2.329-3.327C8.58 8.758 10.954 7 14 7c3.046 0 5.421 1.757 7.066 3.585A17.18 17.18 0 0 1 23.44 14l-.046.089a17.18 17.18 0 0 1-2.329 3.327C19.42 19.242 17.046 21 14 21c-3.046 0-5.421-1.757-7.066-3.584a17.18 17.18 0 0 1-2.329-3.327zm19.848-.3L24 14l.453.212-.001.002-.003.005-.009.02a16.32 16.32 0 0 1-.662 1.195c-.44.72-1.1 1.684-1.969 2.65C20.08 20.008 17.454 22 14 22c-3.454 0-6.079-1.993-7.81-3.916a18.185 18.185 0 0 1-2.469-3.528 10.636 10.636 0 0 1-.161-.318l-.01-.019-.002-.005v-.002L4 14a55.06 55.06 0 0 1-.453-.212l.001-.002.003-.005.009-.02.033-.067a16.293 16.293 0 0 1 .629-1.126c.44-.723 1.1-1.686 1.969-2.652C7.92 7.993 10.546 6 14 6c3.454 0 6.079 1.993 7.81 3.916a18.183 18.183 0 0 1 2.469 3.528 10.588 10.588 0 0 1 .161.318l.01.019.002.005v.002zM24 14l.453-.211.099.211-.099.211L24 14zm-20.453-.211L4 14l-.453.211L3.448 14l.099-.211zM11 14a3 3 0 1 1 6 0 3 3 0 0 1-6 0zm3-4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm0 5a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/></svg>'
        },
        49894: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M4.5 12.5l4.59-4.59a2 2 0 0 1 2.83 0l3.17 3.17a2 2 0 0 0 2.83 0L22.5 6.5m-8 9.5v5.5M12 19l2.5 2.5L17 19m4.5 3v-5.5M19 19l2.5-2.5L24 19"/></svg>'
        },
        13797: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M5.5 16.5l4.586-4.586a2 2 0 0 1 2.828 0l3.172 3.172a2 2 0 0 0 2.828 0L23.5 10.5"/></svg>'
        },
        30302: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12" width="12" height="12"><path fill="currentColor" fill-rule="evenodd" d="M6.18 9.99A.8.8 0 0 1 6 10a.8.8 0 0 1-.18-.01l-.02-.01c-.05-.05-.15-.2-.33-.66l-.25-.58c-.3-.72-.6-1.4-.6-2.43L4.63 6h2.74v.31c0 1.03-.28 1.7-.6 2.43l-.24.58a2.08 2.08 0 0 1-.35.67ZM7.24 5H4.76c.17-.88.47-1.71.7-2.32a2.08 2.08 0 0 1 .36-.67A.8.8 0 0 1 6 2l.18.01.02.01c.05.05.15.2.33.66.24.6.54 1.44.7 2.32Zm1.13 1v.31c0 1.26-.38 2.15-.7 2.88l-.2.5-.02.04A4 4 0 0 0 10 6H8.37Zm1.5-1H8.25a14.09 14.09 0 0 0-.78-2.68l-.02-.05A4 4 0 0 1 9.87 5ZM3.75 5c.18-1.06.53-2.03.78-2.68l.02-.05A4 4 0 0 0 2.13 5h1.62ZM2 6a4 4 0 0 0 2.55 3.73l-.02-.05-.2-.49c-.32-.73-.7-1.62-.7-2.88V6H2Zm4-5h-.02a5 5 0 0 0 0 10h.04a5 5 0 0 0 0-10H6Z"/></svg>'
        },
        61378: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 12" width="12" height="12"><path fill="currentColor" d="M5.31 2.58l.93-.94C7 .88 8.74.6 10.07 1.93c1.34 1.33 1.05 3.07.29 3.83l-.94.93-.36.36-.1.1-.03.03v.01l-.34-.33-.33-.33.04-.04.1-.1.36-.36.94-.94c.4-.39.68-1.53-.29-2.5s-2.11-.68-2.5-.29l-.94.94-.36.36-.1.1-.03.03h-.01v.01l-.33-.33-.33-.33v-.01l.03-.03.11-.1.36-.36zM3.08 4.8l.33.34.33.33-.04.04-.1.1-.36.36-.94.94c-.4.39-.68 1.53.29 2.5s2.11.68 2.5.29l.94-.94.36-.36.1-.1.03-.03h.01v-.01l.33.33.33.33v.01l-.03.03-.11.1-.36.36-.93.94c-.76.76-2.5 1.05-3.83-.29C.59 8.74.88 7 1.64 6.24l.94-.93.36-.36.1-.1.03-.03V4.8z"/><path fill="currentColor" d="M7.1 4.23L4.24 7.11l.66.66 2.88-2.88-.66-.66z"/></svg>'
        },
        9931: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M11.5 4A2.5 2.5 0 0 0 7 5.5V7h6a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2V5.5a3.5 3.5 0 0 1 6.231-2.19c-.231.19-.73.69-.73.69zM13 8H6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h7a1 1 0 0 0 1-1V9a1 1 0 0 0-1-1zm-2 3.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z"/></svg>'
        },
        71261: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M14.692 3.012l-12 12.277.715.699 12-12.277-.715-.699zM9.05 15.627a7.042 7.042 0 0 1-3.144-.741l.742-.76c.72.311 1.52.5 2.402.5 2.297 0 4.047-1.29 5.25-2.645a12.168 12.168 0 0 0 1.687-2.466l.007-.015-.007-.015A12.166 12.166 0 0 0 14.3 7.019c-.11-.124-.225-.247-.344-.37l.699-.715c.137.14.268.28.392.42a13.16 13.16 0 0 1 1.83 2.678 8.117 8.117 0 0 1 .119.243l.006.015.003.005v.001l-.456.204.456.203v.002l-.003.005-.006.015-.025.052a11.762 11.762 0 0 1-.461.857 13.158 13.158 0 0 1-1.463 2.011c-1.296 1.46-3.296 2.982-5.998 2.982zm7.5-6.127l.456-.203.09.203-.09.203-.456-.203zm-7.5 3.07c-.27 0-.53-.037-.778-.105l.879-.899c.999-.052 1.833-.872 1.895-1.938l.902-.923c.066.253.102.52.102.795 0 1.695-1.344 3.07-3 3.07zM6.15 10.294l.902-.923c.063-1.066.896-1.886 1.895-1.938l.879-.9a2.94 2.94 0 0 0-.777-.103c-1.657 0-3 1.374-3 3.069 0 .275.035.541.101.795zM9.05 4.373c.88 0 1.68.19 2.4.5l.743-.759a7.043 7.043 0 0 0-3.143-.74c-2.703 0-4.703 1.521-6 2.98a13.159 13.159 0 0 0-1.83 2.678 7.886 7.886 0 0 0-.118.243l-.007.015-.002.005v.001l.456.204-.457-.203-.09.203.09.203.457-.203-.456.203v.002l.002.005.007.015a4.5 4.5 0 0 0 .119.243 13.152 13.152 0 0 0 1.83 2.677c.124.14.255.28.392.42l.7-.715c-.12-.122-.235-.245-.345-.369a12.156 12.156 0 0 1-1.686-2.466L2.105 9.5l.007-.015a12.158 12.158 0 0 1 1.686-2.466C5.002 5.665 6.752 4.373 9.05 4.373z"/></svg>'
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [7502, 7638], {
        15746: e => {
            e.exports = {
                badge: "badge-yHuWj4ze",
                content: "content-yHuWj4ze",
                anchor: "anchor-yHuWj4ze",
                button: "button-yHuWj4ze",
                "size-xsmall": "size-xsmall-yHuWj4ze",
                "size-small": "size-small-yHuWj4ze",
                "size-medium": "size-medium-yHuWj4ze",
                "size-large": "size-large-yHuWj4ze",
                "size-xlarge": "size-xlarge-yHuWj4ze"
            }
        },
        83701: e => {
            e.exports = {
                absolutePriceControl: "absolutePriceControl-HqZGIxUn",
                priceLabel: "priceLabel-HqZGIxUn",
                openButton: "openButton-HqZGIxUn",
                iconWrapper: "iconWrapper-HqZGIxUn",
                openIcon: "openIcon-HqZGIxUn",
                wait: "wait-HqZGIxUn",
                opened: "opened-HqZGIxUn",
                list: "list-HqZGIxUn",
                item: "item-HqZGIxUn",
                selected: "selected-HqZGIxUn"
            }
        },
        32965: e => {
            e.exports = {
                absolutePriceDropdownItem: "absolutePriceDropdownItem-5TI053dN",
                price: "price-5TI053dN",
                labelsGroup: "labelsGroup-5TI053dN"
            }
        },
        93659: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                wrapper: "wrapper-3UY5VZ5u",
                select: "select-3UY5VZ5u",
                selectMenu: "selectMenu-3UY5VZ5u",
                dateTimePickerWrapper: "dateTimePickerWrapper-3UY5VZ5u",
                dateTimePickerInput: "dateTimePickerInput-3UY5VZ5u",
                focused: "focused-3UY5VZ5u",
                icon: "icon-3UY5VZ5u",
                title: "title-3UY5VZ5u"
            }
        },
        67857: e => {
            e.exports = {
                wrapper: "wrapper-yv5OuExK",
                title: "title-yv5OuExK",
                dateTimeWrapper: "dateTimeWrapper-yv5OuExK",
                mobileDateTimeWrapper: "mobileDateTimeWrapper-yv5OuExK",
                mobilePickerControl: "mobilePickerControl-yv5OuExK",
                mobileDateInputContainer: "mobileDateInputContainer-yv5OuExK",
                mobileDateInput: "mobileDateInput-yv5OuExK",
                mobileDateInputIcon: "mobileDateInputIcon-yv5OuExK",
                timeInput: "timeInput-yv5OuExK",
                buttonWrapper: "buttonWrapper-yv5OuExK",
                button: "button-yv5OuExK"
            }
        },
        12057: e => {
            e.exports = {
                container: "container-0qBdlYpI",
                leverageButton: "leverageButton-0qBdlYpI",
                disabledLeverageButton: "disabledLeverageButton-0qBdlYpI"
            }
        },
        93274: e => {
            e.exports = {
                dialog: "dialog-xQQWuB1d",
                dialogBody: "dialogBody-xQQWuB1d"
            }
        },
        63680: e => {
            e.exports = {
                orderInfo: "orderInfo-LQfiRvct",
                title: "title-LQfiRvct",
                contentWrapper: "contentWrapper-LQfiRvct",
                right: "right-LQfiRvct"
            }
        },
        57671: e => {
            e.exports = {
                panelContainer: "panelContainer-ih3u8os1",
                orderPanel: "orderPanel-ih3u8os1"
            }
        },
        29773: e => {
            e.exports = {
                content: "content-tlk1LQGV",
                separator: "separator-tlk1LQGV",
                controls: "controls-tlk1LQGV",
                button: "button-tlk1LQGV",
                warning: "warning-tlk1LQGV",
                warning__icon: "warning__icon-tlk1LQGV",
                error: "error-tlk1LQGV"
            }
        },
        86354: e => {
            e.exports = {
                controlGroup: "controlGroup-QZys9FTr",
                relativePriceControl: "relativePriceControl-QZys9FTr",
                title: "title-QZys9FTr",
                controlContainer: "controlContainer-QZys9FTr",
                control: "control-QZys9FTr",
                input: "input-QZys9FTr",
                wait: "wait-QZys9FTr"
            }
        },
        20337: e => {
            e.exports = {
                messageBlock: "messageBlock-rqX6BrCi",
                image: "image-rqX6BrCi",
                title: "title-rqX6BrCi",
                text: "text-rqX6BrCi",
                controls: "controls-rqX6BrCi"
            }
        },
        48157: e => {
            e.exports = {
                orderWidget: "orderWidget-diX6tsPJ",
                header: "header-diX6tsPJ",
                side: "side-diX6tsPJ",
                doneButton: "doneButton-diX6tsPJ",
                customField: "customField-diX6tsPJ",
                duration: "duration-diX6tsPJ",
                centerBlock: "centerBlock-diX6tsPJ",
                customFieldsWrapper: "customFieldsWrapper-diX6tsPJ",
                separator: "separator-diX6tsPJ",
                notice: "notice-diX6tsPJ",
                resizeHandler: "resizeHandler-diX6tsPJ",
                orderTicket: "orderTicket-diX6tsPJ",
                orderInfoAndSeparator: "orderInfoAndSeparator-diX6tsPJ",
                topWrapper: "topWrapper-diX6tsPJ",
                "brackets-wrapper": "brackets-wrapper-diX6tsPJ",
                brackets: "brackets-diX6tsPJ",
                quantityWrapper: "quantityWrapper-diX6tsPJ",
                title: "title-diX6tsPJ",
                leverage: "leverage-diX6tsPJ",
                button: "button-diX6tsPJ"
            }
        },
        99746: e => {
            e.exports = {
                priceLabel: "priceLabel-8QIoyppK",
                ask: "ask-8QIoyppK",
                bid: "bid-8QIoyppK",
                last: "last-8QIoyppK"
            }
        },
        20632: e => {
            e.exports = {
                progressBarContainer: "progressBarContainer-dH0Ialab",
                marginsContainer: "marginsContainer-dH0Ialab",
                usedMargin: "usedMargin-dH0Ialab",
                availableMargin: "availableMargin-dH0Ialab",
                progressBar: "progressBar-dH0Ialab",
                track: "track-dH0Ialab",
                progress: "progress-dH0Ialab",
                fullFilled: "fullFilled-dH0Ialab",
                marginOverflow: "marginOverflow-dH0Ialab",
                wait: "wait-dH0Ialab"
            }
        },
        28361: e => {
            e.exports = {
                "css-value-calculator-width": "150px"
            }
        },
        37279: e => {
            e.exports = {
                "css-value-calculator-width": "150px",
                calculator: "calculator-DDGMhaxA",
                calculator__inputBorder: "calculator__inputBorder-DDGMhaxA",
                calculator__input: "calculator__input-DDGMhaxA",
                calculator__input__innerInput: "calculator__input__innerInput-DDGMhaxA",
                calculator__btns: "calculator__btns-DDGMhaxA",
                buttonIcon: "buttonIcon-DDGMhaxA"
            }
        },
        109: e => {
            e.exports = {
                menuBox: "menuBox-MViAqvOq"
            }
        },
        79177: e => {
            e.exports = {
                wrapper: "wrapper-K7XHLhk0",
                label: "label-K7XHLhk0",
                wait: "wait-K7XHLhk0",
                title: "title-K7XHLhk0",
                popupMenuItem: "popupMenuItem-K7XHLhk0",
                value: "value-K7XHLhk0"
            }
        },
        89722: e => {
            e.exports = {
                wrapper: "wrapper-yjpPysIP",
                control: "control-yjpPysIP",
                label: "label-yjpPysIP",
                units: "units-yjpPysIP",
                single: "single-yjpPysIP",
                calculatorIcon: "calculatorIcon-yjpPysIP",
                isOpened: "isOpened-yjpPysIP",
                risk: "risk-yjpPysIP",
                wait: "wait-yjpPysIP"
            }
        },
        45299: e => {
            e.exports = {
                relativePriceControl: "relativePriceControl-10TAVhJF",
                pipsLabel: "pipsLabel-10TAVhJF",
                openButton: "openButton-10TAVhJF",
                iconWrapper: "iconWrapper-10TAVhJF",
                openIcon: "openIcon-10TAVhJF",
                wait: "wait-10TAVhJF",
                opened: "opened-10TAVhJF",
                list: "list-10TAVhJF",
                item: "item-10TAVhJF",
                selected: "selected-10TAVhJF"
            }
        },
        6276: e => {
            e.exports = {
                relativePriceDropdownItem: "relativePriceDropdownItem-uuFNxsAW",
                price: "price-uuFNxsAW"
            }
        },
        66442: e => {
            e.exports = {
                restrictions: "restrictions-KnKRfWMq",
                restriction: "restriction-KnKRfWMq",
                hardToBorrow: "hardToBorrow-KnKRfWMq",
                halted: "halted-KnKRfWMq"
            }
        },
        26263: e => {
            e.exports = {
                restrictions: "restrictions-ABjeicUL",
                sideControl: "sideControl-ABjeicUL",
                section: "section-ABjeicUL",
                active: "active-ABjeicUL",
                sell: "sell-ABjeicUL",
                buy: "buy-ABjeicUL",
                title: "title-ABjeicUL",
                typeSide: "typeSide-ABjeicUL",
                value: "value-ABjeicUL",
                valueNoData: "valueNoData-ABjeicUL",
                spread: "spread-ABjeicUL",
                isLongValue: "isLongValue-ABjeicUL",
                disable: "disable-ABjeicUL"
            }
        },
        87831: e => {
            e.exports = {
                tabsContainer: "tabsContainer-LvMG5KdQ",
                separator: "separator-LvMG5KdQ"
            }
        },
        55914: e => {
            e.exports = {
                wrap: "wrap-GsOqvniR",
                icon: "icon-GsOqvniR",
                text: "text-GsOqvniR",
                disabled: "disabled-GsOqvniR"
            }
        },
        12539: e => {
            e.exports = {
                calendar: "calendar-U9DgB4FB",
                popupStyle: "popupStyle-U9DgB4FB",
                header: "header-U9DgB4FB",
                title: "title-U9DgB4FB",
                switchBtn: "switchBtn-U9DgB4FB",
                prev: "prev-U9DgB4FB",
                month: "month-U9DgB4FB",
                weekdays: "weekdays-U9DgB4FB",
                weeks: "weeks-U9DgB4FB",
                week: "week-U9DgB4FB",
                day: "day-U9DgB4FB",
                disabled: "disabled-U9DgB4FB",
                selected: "selected-U9DgB4FB",
                currentDay: "currentDay-U9DgB4FB",
                isOnHighlightedEdge: "isOnHighlightedEdge-U9DgB4FB",
                withinSelectedRange: "withinSelectedRange-U9DgB4FB"
            }
        },
        34020: e => {
            e.exports = {
                container: "container-tZN1pb1A",
                icon: "icon-tZN1pb1A",
                tooltip: "tooltip-tZN1pb1A",
                date: "date-tZN1pb1A",
                time: "time-tZN1pb1A"
            }
        },
        554: e => {
            e.exports = {
                pickerInput: "pickerInput-sZbzL9zH",
                icon: "icon-sZbzL9zH",
                disabled: "disabled-sZbzL9zH",
                picker: "picker-sZbzL9zH",
                fixed: "fixed-sZbzL9zH",
                absolute: "absolute-sZbzL9zH",
                nativePicker: "nativePicker-sZbzL9zH"
            }
        },
        93632: e => {
            e.exports = {
                tooltip: "tooltip-QKiUU4Ng"
            }
        },
        37740: e => {
            e.exports = {
                tabs: "tabs-rKFlMYkc",
                tab: "tab-rKFlMYkc",
                noBorder: "noBorder-rKFlMYkc",
                disabled: "disabled-rKFlMYkc",
                active: "active-rKFlMYkc",
                defaultCursor: "defaultCursor-rKFlMYkc",
                slider: "slider-rKFlMYkc",
                content: "content-rKFlMYkc"
            }
        },
        52130: (e, t, s) => {
            "use strict";
            s.d(t, {
                useIsMounted: () => i
            });
            var r = s(59496);
            const i = () => {
                const e = (0, r.useRef)(!1);
                return (0, r.useEffect)(() => (e.current = !0, () => {
                    e.current = !1
                }), []), e
            }
        },
        57947: (e, t, s) => {
            "use strict";
            s.d(t, {
                DurationControl: () => O
            });
            var r = s(25177),
                i = s(59496),
                o = s(1227),
                n = s(54936),
                a = s(72571),
                l = s(2691),
                c = s(85673),
                d = s(97496),
                p = s.n(d),
                u = s(28466),
                h = s(36118),
                m = s(92063),
                v = s(34816),
                g = s(36376),
                f = s(50681),
                _ = s(28599),
                b = s(50324),
                y = s(93173),
                C = s(37294),
                k = s(44807),
                w = s(8550),
                E = s(14793),
                S = s(67857);
            const P = (0, y.mergeThemes)(b.DEFAULT_INPUT_DATE_THEME, {
                    container: S.mobileDateInputContainer,
                    date: S.mobileDateInput,
                    icon: S.mobileDateInputIcon
                }),
                D = o.CheckMobile.any(),
                M = o.CheckMobile.iOS();

            function N(e) {
                return i.createElement(b.DateInput, {
                    theme: D ? P : void 0,
                    ...e
                })
            }
            class I extends i.PureComponent {
                constructor(e) {
                    super(e), this._todayMidnight = new Date((new Date).setHours(0, 0, 0, 0)), this._onSelect = () => {
                        this.props.onSelect(this.state.date, this.state.time)
                    }, this._onDateSelect = e => {
                        null !== e && this.setState({
                            date: e
                        }, this._handleMobileSelect)
                    }, this._onTimeSelect = e => {
                        const t = function(e) {
                            const [t, s] = e.split(":"), r = new Date;
                            return r.setHours(Number(t), Number(s)), r
                        }(e);
                        this.setState({
                            time: t
                        }, this._handleMobileSelect)
                    }, this._handleMobileSelect = () => {
                        D && !M && this._onSelect()
                    }, this._onKeyDown = e => {
                        e.stopPropagation()
                    }, this.state = {
                        date: this.props.initDateTime,
                        time: this.props.initDateTime
                    }
                }
                render() {
                    const e = i.createElement(E.DatePicker, {
                            minDate: this._todayMidnight,
                            initial: this.state.date,
                            InputComponent: N,
                            withCalendar: !1,
                            onPick: this._onDateSelect,
                            revertInvalidData: !0
                        }),
                        t = i.createElement(k.TimeInput, {
                            className: !D && S.timeInput,
                            value: (s = this.state.time, (0, w.twoDigitsFormat)(s.getHours()) + ":" + (0, w.twoDigitsFormat)(s.getMinutes())),
                            onChange: this._onTimeSelect
                        });
                    var s;
                    return D ? i.createElement("div", {
                        className: S.mobileDateTimeWrapper
                    }, this.props.durationMetaInfo.hasDatePicker && i.createElement("div", {
                        className: S.mobilePickerControl
                    }, i.createElement("span", {
                        className: S.title
                    }, (0,
                        r.t)("Date")), e), this.props.durationMetaInfo.hasTimePicker && i.createElement("div", {
                        className: S.mobilePickerControl
                    }, i.createElement("span", {
                        className: S.title
                    }, (0, r.t)("Time")), t)) : i.createElement("div", {
                        className: S.wrapper,
                        onKeyDown: this._onKeyDown
                    }, i.createElement("div", {
                        className: S.dateTimeWrapper
                    }, this.props.durationMetaInfo.hasDatePicker && e, this.props.durationMetaInfo.hasTimePicker && t), this.props.durationMetaInfo.hasDatePicker && i.createElement(C.Calendar, {
                        key: this.state.date.valueOf(),
                        selectedDate: this.state.date,
                        minDate: this._todayMidnight,
                        onSelect: this._onDateSelect,
                        popupStyle: !1
                    }), i.createElement("div", {
                        className: S.buttonWrapper
                    }, i.createElement(_.Button, {
                        className: S.button,
                        type: "submit",
                        size: "l",
                        onClick: this._onSelect
                    }, this._makeButtonText())))
                }
                _makeButtonText() {
                    const e = this.state.date.getFullYear(),
                        t = this.state.date.toLocaleString("default", {
                            month: "2-digit"
                        }),
                        s = this.state.date.toLocaleString("default", {
                            day: "2-digit"
                        }),
                        i = (0, g.formatTime)(this.state.time);
                    return (0, r.t)("Set {dateTime}").replace("{dateTime}", `${e}-${t}-${s} ${i}`)
                }
            }
            var B = s(93659),
                T = s(21279);
            const x = new(p());

            function O(e) {
                const {
                    currentDuration: t,
                    durationMetaInfoList: s,
                    onDurationChanged: d,
                    onClick: p
                } = e, m = (0, f.findDurationMetaInfo)(s, t.type);
                if (void 0 === m) return null;
                const _ = m.hasDatePicker || m.hasTimePicker,
                    b = o.CheckMobile.any(),
                    y = (0, i.useMemo)(() => void 0 !== t.datetime ? new Date(t.datetime) : ["GTT", "GTD"].includes(t.type) ? (0, f.makeDatePlus24UTCHours)() : new Date, [t.datetime, t.type]),
                    C = (0, i.useMemo)(() => (0, g.formatDateTime)(y, m), [y, m]),
                    k = (0, i.useMemo)(() => s.map(e => ({
                        content: e.name,
                        value: e.value
                    })), [s]),
                    w = k.length < 2,
                    E = i.createElement(I, {
                        durationMetaInfo: m,
                        initDateTime: y,
                        onSelect: function(t, s) {
                            const r = Date.UTC(t.getFullYear(), t.getMonth(), t.getDate(), s.getUTCHours(), s.getUTCMinutes());
                            e.onDurationChanged({
                                type: e.currentDuration.type,
                                datetime: r
                            }), O()
                        }
                    }),
                    S = i.createElement(h.Select, {
                        onClick: p,
                        className: B.select,
                        menuClassName: B.selectMenu,
                        value: m.value,
                        items: k,
                        "data-name": "duration-type-selector",
                        disabled: w,
                        hideArrowButton: w,
                        onChange: N,
                        stretch: !0,
                        matchButtonAndListboxWidths: !0
                    }),
                    [P, D] = (0, i.useState)(!1),
                    M = i.createElement(n.Input, {
                        className: P && !b ? B.focused : null,
                        inputClassName: B.dateTimePickerInput,
                        value: C,
                        "data-name": "duration-datetime-selector",
                        stretch: !0,
                        readonly: !0,
                        intent: P && !b ? "primary" : "default",
                        noReadonlyStyles: !0,
                        endSlot: i.createElement(l.EndSlot, {
                            icon: !0,
                            interactive: !1
                        }, i.createElement(a.Icon, {
                            icon: T,
                            className: B.icon
                        }))
                    });
                return i.createElement("div", {
                    className: B.wrapper
                }, i.createElement("span", {
                    className: B.title
                }, (0, r.t)("Time in Force")), b ? i.createElement(v.ToolWidgetMenu, {
                    className: B.menuButton,
                    content: S,
                    arrow: !1,
                    children: i.createElement(F, {
                        menuItems: k,
                        onTypeSelect: N
                    }),
                    isDrawer: !0,
                    isDisabled: w,
                    closeOnClickOutside: !0
                }) : S, _ && (b ? E : i.createElement(u.CloseDelegateContext.Provider, {
                    value: x
                }, i.createElement(v.ToolWidgetMenu, {
                    className: B.dateTimePickerWrapper,
                    content: M,
                    arrow: !1,
                    closeOnClickOutside: !0,
                    verticalDropDirection: c.VerticalDropDirection.FromBottomToTop,
                    horizontalDropDirection: c.HorizontalDropDirection.FromRightToLeft,
                    horizontalAttachEdge: c.HorizontalAttachEdge.Right,
                    verticalAttachEdge: c.VerticalAttachEdge.Top,
                    onOpen: function() {
                        D(!0)
                    },
                    onClose: function() {
                        D(!1)
                    }
                }, E))));

                function N(e) {
                    const r = {
                            type: e
                        },
                        i = (0, f.findDurationMetaInfo)(s, e);
                    void 0 !== i && (i.hasDatePicker || i.hasTimePicker) && (r.datetime = t.datetime || (0, g.getTimestamp)((0, f.makeDatePlus24UTCHours)())), d(r), O()
                }

                function O() {
                    void 0 !== e.onClose && e.onClose(), x.fire()
                }
            }

            function F(e) {
                const {
                    menuItems: t,
                    onTypeSelect: s
                } = e;
                return i.createElement(i.Fragment, null, Object.values(t).map(e => {
                    var t;
                    return i.createElement(m.PopupMenuItem, {
                        key: e.value,
                        label: null !== (t = e.content) && void 0 !== t ? t : e.value,
                        onClick: s,
                        onClickArg: e.value
                    })
                }))
            }
        },
        29018: (e, t, s) => {
            "use strict";
            s.d(t, {
                QuantityCalculator: () => k
            });
            var r = s(59496),
                i = s(60521),
                o = s(47898),
                n = s(44377),
                a = s(10618),
                l = s(93173),
                c = s(72571),
                d = s(297),
                p = s(87125),
                u = s(84039),
                h = s(80185),
                m = s(37729),
                v = s(2739),
                g = s(94280),
                f = s(80589),
                _ = s(37279);

            function b(e) {
                const {
                    min: t,
                    max: s,
                    step: i,
                    uiStep: o,
                    reference: n,
                    withInput: a,
                    valueInput: l,
                    onChangeValueInput: b,
                    onClick: y,
                    onClose: C,
                    onFocus: k
                } = e, [w, E] = (0, r.useState)(!1), [S, P] = (0, r.useState)(void 0), [D, M] = (0, r.useState)(!1), N = r.createElement(c.Icon, {
                    className: _.buttonIcon,
                    icon: v
                }), I = r.createElement(c.Icon, {
                    className: _.buttonIcon,
                    icon: m
                }), B = r.createElement(c.Icon, {
                    className: _.buttonIcon,
                    icon: g
                }), T = r.createElement(c.Icon, {
                    className: _.buttonIcon,
                    icon: f
                }), x = (0, r.useCallback)(e => {
                    const r = {
                            min: t,
                            max: s,
                            step: i
                        },
                        o = (0, u.checkQtyError)(r, e, !0),
                        n = D || o.res,
                        a = D ? void 0 : o.msg;
                    E(n), P(a)
                }, [D, t, s, i]);
                return (0, r.useEffect)(() => {
                    x(l)
                }, [x, l]), r.createElement("div", {
                    className: _.calculator,
                    tabIndex: -1,
                    ref: n,
                    onFocus: k,
                    onKeyDown: e => {
                        l && !w && 13 === (0, h.hashFromEvent)(e) && C()
                    }
                }, a && r.createElement("div", {
                    className: _.calculator__inputBorder
                }, r.createElement(p.NumberInput, {
                    className: _.calculator__input,
                    inputClassName: _.calculator__innerInput,
                    borderStyle: "none",
                    value: l,
                    max: s,
                    min: t,
                    step: i,
                    uiStep: o,
                    mode: "float",
                    error: w,
                    errorMessage: S,
                    errorHandler: function(e) {
                        M(e)
                    },
                    onValueChange: b
                })), r.createElement("div", {
                    className: _.calculator__btns
                }, r.createElement(d.Button, {
                    value: -i,
                    type: d.ButtonType.IncDec,
                    icon: N,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: i,
                    type: d.ButtonType.IncDec,
                    icon: I,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 1,
                    type: d.ButtonType.PlusValue,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 5,
                    type: d.ButtonType.PlusValue,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 25,
                    type: d.ButtonType.PlusValue,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 100,
                    type: d.ButtonType.PlusValue,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 500,
                    type: d.ButtonType.PlusValue,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 1e3,
                    type: d.ButtonType.PlusValue,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: 0,
                    type: d.ButtonType.Clear,
                    icon: B,
                    onClick: y
                }), r.createElement(d.Button, {
                    value: t || i,
                    type: d.ButtonType.Default,
                    icon: T,
                    onClick: y
                })))
            }
            var y = s(109);
            const C = (0, l.mergeThemes)(a.DEFAULT_MENU_THEME, {
                menuBox: y.menuBox
            });
            class k extends r.PureComponent {
                constructor(e) {
                    super(e), this._setCalcRef = e => {
                        this.props.calcReference && this.props.calcReference(e)
                    }, this._calculatorStepHandler = (e, t) => {
                        const {
                            min: s,
                            max: r,
                            uiStep: n,
                            trackEventTarget: a,
                            trackEvent: l
                        } = this.props;
                        if (void 0 !== l && void 0 !== a && l(a, "Calculator Button", (0, o.prepareCalculatorEventText)(e, t)), t === d.ButtonType.Clear || t === d.ButtonType.Default) return this._updateValueByCalc(e);
                        const c = this.props.valueGetter();
                        if (null === c) return;
                        let p = Number((0, i.Big)(c).plus(e));
                        if ((p < s || r < p) && t !== d.ButtonType.IncDec) return this._updateValueByCalc(c);
                        if (t === d.ButtonType.IncDec) {
                            if (p = this._calcByStep(c, e, s, n), r < p) return this._updateValueByCalc(r);
                            if (p < s) return this._updateValueByCalc(s)
                        }
                        return this._updateValueByCalc(p)
                    }, this._updateValueByCalc = e => {
                        this._handlerValueInput(e), this.props.onValueChange(e, !0), this.props.calculatorUsedStat && this.props.calculatorUsedStat()
                    }, this.state = {
                        valueInput: e.valueGetter()
                    }, this._handlerValueInput = this._handlerValueInput.bind(this)
                }
                render() {
                    const {
                        min: e,
                        max: t,
                        step: s,
                        uiStep: i,
                        withInput: o,
                        targetEl: a,
                        position: l,
                        onFocus: c,
                        onClose: d
                    } = this.props;
                    return r.createElement(n.PopupMenu, {
                        isOpened: !0,
                        onClose: d,
                        position: l,
                        doNotCloseOn: a,
                        theme: C
                    }, r.createElement(b, {
                        min: e,
                        max: t,
                        step: s,
                        uiStep: i,
                        withInput: o,
                        reference: this._setCalcRef,
                        valueInput: this.state.valueInput,
                        onChangeValueInput: this._updateValueByCalc,
                        onClick: this._calculatorStepHandler,
                        onFocus: c,
                        onClose: d
                    }))
                }
                _calcByStep(e, t, s, r) {
                    const o = Math.sign(t),
                        n = Math.abs(null != r ? r : t),
                        a = new i.Big(e),
                        l = a.minus(s).mod(t);
                    let c = a.plus(o * n);
                    return l.eq(0) || (c = c.plus((o > 0 ? 0 : 1) * n).minus(l)), c.toNumber()
                }
                _handlerValueInput(e) {
                    this.setState({
                        valueInput: e
                    })
                }
            }
        },
        56267: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                closeOrderDialog: () => is,
                mountOrderPanel: () => ns,
                showOrderDialog: () => rs,
                unmountOrderPanel: () => as
            });
            var r, i = s(59496),
                o = s(87995),
                n = s(25177),
                a = s(97754),
                l = s.n(a),
                c = s(1227),
                d = s(88537),
                p = s(80185),
                u = s(70122),
                h = s(82527),
                m = s(51951),
                v = s(74617),
                g = s(74752),
                f = s(61851),
                _ = s(1317),
                b = s(63111);
            ! function(e) {
                e.XSmall = "xsmall", e.Small = "small", e.Medium = "medium", e.Large = "large", e.XLarge = "xlarge"
            }(r || (r = {}));
            var y = s(15746),
                C = s.n(y);

            function k(e) {
                const {
                    size: t = r.Medium,
                    className: s
                } = e;
                return l()(C().badge, t && C()["size-" + t], s)
            }

            function w(e) {
                const {
                    children: t,
                    contentClassName: s
                } = e;
                return i.createElement("span", {
                    className: l()(C().content, s)
                }, t)
            }

            function E(e) {
                const {
                    size: t,
                    children: s,
                    className: r,
                    contentClassName: o,
                    ...n
                } = e;
                return i.createElement("span", { ...n,
                    className: k({
                        size: t,
                        className: r
                    })
                }, i.createElement(w, {
                    contentClassName: o
                }, s))
            }
            var S = s(24818),
                P = s(66442);

            function D(e) {
                return e === S.RestrictionType.HardToBorrow ? P.hardToBorrow : e === S.RestrictionType.Halted ? P.halted : null
            }

            function M(e) {
                return i.createElement("div", {
                    className: P.restrictions
                }, e.restrictionTypes.map((e, t) => i.createElement(E, {
                    key: t,
                    size: r.Small,
                    className: l()(P.restriction, D(e))
                }, e)))
            }
            var N = s(26263);
            const I = (0, n.t)("Sell"),
                B = (0, n.t)("Buy"),
                T = (0, n.t)("No Data");
            class x extends i.PureComponent {
                constructor(e) {
                    super(e), this._isLongValue = !1, this._maxDigitsNumber = 7, this._createClickHandler = e => () => this.props.onSideChanged(e),
                        this._isLongValue = Boolean(this.props.quotes.spread && this.props.quotes.spread.toString().length > this._maxDigitsNumber || this.props.quotes.ask && this.props.quotes.ask.toString().length > this._maxDigitsNumber)
                }
                render() {
                    const e = a(N.sideControl, [b.OrderPanelStatus.Editing, b.OrderPanelStatus.Preview].includes(this.props.status) && N.disable),
                        t = a(N.section, N.sell, this.props.status !== b.OrderPanelStatus.Wait && -1 === this.props.side && N.active),
                        s = a(N.section, N.buy, this.props.status !== b.OrderPanelStatus.Wait && 1 === this.props.side && N.active),
                        r = this.props.quotes.bid ? i.createElement("div", null, this.props.quotes.bid) : i.createElement("div", {
                            className: N.valueNoData
                        }, T),
                        o = this.props.quotes.ask ? i.createElement("div", null, this.props.quotes.ask) : i.createElement("div", {
                            className: N.valueNoData
                        }, T);
                    return i.createElement(i.Fragment, null, 0 !== this.props.restrictionTypes.length && i.createElement("div", {
                        className: N.restrictions
                    }, i.createElement(M, {
                        restrictionTypes: this.props.restrictionTypes
                    })), i.createElement("div", {
                        className: e
                    }, i.createElement("div", {
                        className: t,
                        onClick: this._createClickHandler(-1),
                        tabIndex: -1,
                        "data-name": "side-control-sell"
                    }, i.createElement("div", {
                        className: N.title
                    }, i.createElement("span", {
                        className: this.props.currencyForCrypto && N.typeSide
                    }, I), this.props.currencyForCrypto && i.createElement("span", null, this.props.currencyForCrypto)), i.createElement("div", {
                        className: N.value
                    }, r)), i.createElement("div", {
                        className: s,
                        onClick: this._createClickHandler(1),
                        tabIndex: -1,
                        "data-name": "side-control-buy"
                    }, i.createElement("div", {
                        className: N.title
                    }, i.createElement("span", {
                        className: this.props.currencyForCrypto && N.typeSide
                    }, B), this.props.currencyForCrypto && i.createElement("span", {
                        className: N.typeSide
                    }, this.props.currencyForCrypto)), i.createElement("div", {
                        className: N.value
                    }, o)), this.props.quotes.spread && i.createElement("div", {
                        className: a(N.spread, this._isLongValue && N.isLongValue),
                        "data-name": "side-control-spread"
                    }, this.props.quotes.spread)))
                }
            }

            function O(e) {
                const {
                    model: t,
                    disabled: s
                } = e, r = (0, f.useObservable)(t.value$, t.getValue()), o = (0, f.useObservable)(t.formattedQuotes$, t.getFormattedQuotes()), n = (0, f.useObservable)(t.restrictionTypes$, t.getRestrictionTypes()), [a] = (0, _.useWatchedValue)(t.status);
                return i.createElement(x, {
                    quotes: o,
                    side: r,
                    status: a,
                    restrictionTypes: n,
                    currencyForCrypto: t.baseCurrency,
                    onSideChanged: e => {
                        s || (t.setValue(e), t.onControlFocused.fire())
                    }
                })
            }
            var F = s(28599),
                H = s(64245),
                R = s(85938),
                L = s(72571),
                V = s(29773),
                z = s(91533);
            const W = {
                cancel: (0, n.t)("Cancel"),
                sendOrder: (0, n.t)("Send Order")
            };

            function A(e) {
                const t = (0, i.useRef)(null),
                    s = (0, R.useForceUpdate)();
                (0, i.useEffect)(() => {
                    const r = () => s();
                    return (0, d.ensureNotNull)(t.current).focus(), e.loading.subscribe(r), e.model.infoTableQuotesData().subscribe(r), () => {
                        e.loading.unsubscribe(r), e.model.infoTableQuotesData().unsubscribe(r)
                    }
                });
                const r = i.createElement(H.InfoTable, {
                        rows: e.model.infoTableQuotesData().value().rows,
                        header: e.model.infoTableQuotesData().value().header
                    }),
                    o = i.createElement(H.InfoTable, {
                        rows: e.model.infoTableOrderData().rows,
                        header: e.model.infoTableOrderData().header
                    }),
                    n = e.model.infoTableCustomData().map((e, t) => i.createElement(H.InfoTable, {
                        key: "custom-" + t,
                        rows: e.rows,
                        header: e.header
                    })),
                    a = 0 !== e.model.warnings.length && i.createElement("div", {
                        className: V.warning
                    }, i.createElement(L.Icon, {
                        className: V.warning__icon,
                        icon: z
                    }), i.createElement("div", null, e.model.warnings.map(e => i.createElement("div", {
                        key: e
                    }, e)))),
                    l = 0 !== e.model.errors.length,
                    c = l && i.createElement("div", {
                        className: V.error
                    }, e.model.errors.map(e => i.createElement("div", {
                        key: e
                    }, e)));
                return i.createElement(i.Fragment, null, i.createElement("div", {
                    className: V.content
                }, r, i.createElement("div", {
                    className: V.separator
                }), o, 0 !== n.length && i.createElement("div", {
                    className: V.separator
                }), n, c, a), i.createElement("div", {
                    className: V.controls
                }, i.createElement("div", {
                    className: V.button
                }, i.createElement(F.Button, {
                    useFullWidth: !0,
                    size: "l",
                    intent: -1 === e.side ? "danger" : "primary",
                    onClick: e.model.onPlaceClick,
                    reference: t,
                    disabled: l || e.loading.value()
                }, W.sendOrder)), i.createElement("div", {
                    className: V.button
                }, i.createElement(F.Button, {
                    useFullWidth: !0,
                    size: "l",
                    intent: "default",
                    appearance: "stroke",
                    onClick: e.model.onCancelClick
                }, W.cancel))))
            }
            var U = s(68766);
            class K extends i.PureComponent {
                constructor() {
                    super(...arguments), this._createClickHandler = e => () => {
                        this.props.disabled || this.props.onSelect(e)
                    }
                }
                render() {
                    const e = this._generateTabs();
                    return i.createElement("div", null, i.createElement(U.SliderRow, null, e), i.createElement("div", null, this.props.children[this.props.activeTab || 0]))
                }
                _generateTabs() {
                    const {
                        activeTab: e,
                        disabled: t
                    } = this.props;
                    return i.Children.map(this.props.children, (s, r) => {
                        const o = void 0 !== s.props.id ? s.props.id : r;
                        return i.createElement(U.SliderItem, {
                            value: o,
                            isActive: e === o,
                            isDisabled: t,
                            shouldUseDefaultCursor: !!this.props.shouldUseDefaultCursor,
                            noBorder: !!this.props.noBorder,
                            onClick: this._createClickHandler(o)
                        }, s.props.title)
                    })
                }
            }

            function Z(e) {
                return i.createElement("div", null, e.children)
            }
            var q = s(87831);
            const G = (0, n.t)("Market"),
                Q = (0, n.t)("Limit"),
                j = (0, n.t)("Stop"),
                Y = (0, n.t)("Stop Limit");
            class X extends i.PureComponent {
                constructor(e) {
                    super(e), this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this.context.resizerWidth && this.context.resizerWidth.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.context.resizerWidth && this.context.resizerWidth.unsubscribe(this._callback)
                }
                render() {
                    const e = [];
                    return this.props.supportMarketOrders && e.push(i.createElement(Z, {
                        key: 2,
                        title: G,
                        id: 2
                    })), this.props.supportLimitOrders && e.push(i.createElement(Z, {
                        key: 1,
                        title: Q,
                        id: 1
                    })), this.props.supportStopOrders && e.push(i.createElement(Z, {
                        key: 3,
                        title: j,
                        id: 3
                    })), this.props.supportStopLimitOrders && e.push(i.createElement(Z, {
                        key: 4,
                        title: Y,
                        id: 4
                    })), i.createElement(i.Fragment, null, i.createElement("div", {
                        className: q.tabsContainer,
                        tabIndex: -1
                    }, i.createElement(K, {
                        activeTab: this.props.activeTab,
                        shouldUseDefaultCursor: !0,
                        onSelect: this.props.onSelect,
                        disabled: this.props.disabled,
                        noBorder: !0
                    }, e)), i.createElement("div", {
                        className: q.separator
                    }))
                }
            }
            X.contextType = b.Context;
            var J = s(88865),
                $ = s(80327),
                ee = s(87125),
                te = s(23235),
                se = s(29018),
                re = s(72535),
                ie = s(37253),
                oe = s(89722),
                ne = s(28361);
            const ae = parseInt(ne["css-value-calculator-width"]);
            class le extends i.PureComponent {
                constructor(e) {
                    super(e), this._control = null, this._input = null, this._calc = null, this._getCurrentValue = () => this.props.value || 0, this._getDropdownPosition = () => {
                        if (null === this._control) return {
                            x: 0,
                            y: 0
                        };
                        const e = this._control.getBoundingClientRect();
                        return {
                            x: e.left + e.width - ae,
                            y: e.bottom + 2
                        }
                    }, this._onFocus = e => {
                        const t = (0, d.ensureNotNull)(this._calc);
                        !re.mobiletouch && t.contains(e.target) && (0, d.ensureNotNull)(this._input).focus()
                    }, this._setRef = e => {
                        this._control = e
                    }, this._setCalcRef = e => {
                        this._calc = e
                    }, this._setInputRef = e => {
                        this._input = e
                    }, this._onKeyDown = e => {
                        !this.state.isOpened || 13 !== e.keyCode && 27 !== e.keyCode || (e.stopPropagation(), this.setState({
                            isOpened: !1
                        })), Object.values(b.CalculatorDecKeyCodes).includes(e.keyCode) || Object.values(b.CalculatorIncKeyCodes).includes(e.keyCode) || this.setState({
                            isOpened: !1
                        }), this.props.onKeyDown && this.props.onKeyDown(e)
                    }, this._onClickOutside = e => {
                        this._calc && !this._calc.contains(e.target) && this.setState({
                            isOpened: !1
                        })
                    }, this._updateValue = e => {
                        this.props.onValueChange(e)
                    }, this._toggle = () => {
                        this.setState(e => ({
                            isOpened: !e.isOpened
                        }))
                    }, this._setInputFocus = e => {
                        null !== e && (e.focus(), e.setSelectionRange(e.value.length, e.value.length))
                    }, this.state = {
                        isOpened: !1
                    }
                }
                componentDidMount() {
                    5 === this.props.focus && this._setInputFocus(this._input)
                }
                render() {
                    const {
                        min: e,
                        max: t,
                        step: s,
                        uiStep: r,
                        error: o,
                        errorMessage: n,
                        className: l,
                        errorHandler: c,
                        highlight: d,
                        highlightRemoveRoundBorder: p,
                        intent: u,
                        fontSizeStyle: h,
                        ...m
                    } = this.props, v = i.createElement(L.Icon, {
                        icon: ie,
                        className: a(oe.calculatorIcon, this.state.isOpened && oe.isOpened),
                        onClick: this._toggle
                    });
                    return i.createElement(te.OutsideEvent, {
                        click: !0,
                        mouseDown: !0,
                        touchStart: !0,
                        handler: this._onClickOutside
                    }, a => i.createElement("span", {
                        ref: a
                    }, i.createElement(ee.NumberInput, {
                        value: this.props.value || 0,
                        alwaysUpdateValueFromProps: this.state.isOpened,
                        formatter: this.props.formatter,
                        className: l,
                        containerReference: this._setRef,
                        inputReference: this._setInputRef,
                        button: v,
                        onValueChange: this._updateValue,
                        onFocus: this.props.onFocus,
                        onBlur: this.props.onBlur,
                        onKeyDown: this._onKeyDown,
                        error: o,
                        errorMessage: n,
                        errorHandler: c,
                        min: e,
                        max: t,
                        step: s,
                        uiStep: r,
                        controlDecKeyCodes: this.state.isOpened ? [b.CalculatorDecKeyCodes.Minus, b.CalculatorDecKeyCodes.NumMinus, b.CalculatorDecKeyCodes.FirefoxMinus] : void 0,
                        controlIncKeyCodes: this.state.isOpened ? [b.CalculatorIncKeyCodes.Plus, b.CalculatorIncKeyCodes.NumPlus, b.CalculatorIncKeyCodes.FirefoxPlus] : void 0,
                        highlight: d,
                        highlightRemoveRoundBorder: p,
                        intent: u,
                        fontSizeStyle: h
                    }), this.state.isOpened && i.createElement(se.QuantityCalculator, { ...m,
                        min: e,
                        max: t,
                        step: s,
                        uiStep: r,
                        valueGetter: this._getCurrentValue,
                        position: this._getDropdownPosition(),
                        targetEl: this._control,
                        calcReference: this._setCalcRef,
                        onClose: this._toggle,
                        onFocus: this._onFocus,
                        trackEventTarget: "Order Ticket"
                    })))
                }
            }
            class ce extends i.PureComponent {
                constructor(e) {
                    super(e), this._defaultMax = 9e15, this._onFocus = () => {
                        this.props.onFocus && this.props.onFocus(this.props.type)
                    }, this._onValueChange = e => {
                        this._onFocus(), this.props.control.value.setValue(e),
                            this.props.control.onModifiedCallback()
                    }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this.props.control.value.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.props.control.value.unsubscribe(this._callback)
                }
                render() {
                    const {
                        control: e,
                        focus: t,
                        min: s,
                        max: r,
                        step: o,
                        uiStep: n,
                        type: l,
                        error: c,
                        errorMessage: d,
                        errorHandler: p,
                        label: u,
                        formatter: h,
                        className: m,
                        status: v,
                        trackEvent: g,
                        highlight: f,
                        highlightRemoveRoundBorder: _,
                        intent: y,
                        fontSizeStyle: C
                    } = this.props, k = {
                        value: e.value.value() || 0,
                        step: o,
                        uiStep: n,
                        className: a(oe.input, v === b.OrderPanelStatus.Wait && oe.wait),
                        error: c,
                        errorMessage: d,
                        errorHandler: p,
                        onFocus: this._onFocus,
                        formatter: h,
                        onValueChange: this._onValueChange,
                        calculatorUsedStat: () => e.calculatorUsedStat(),
                        highlight: f,
                        highlightRemoveRoundBorder: _,
                        intent: y,
                        fontSizeStyle: C
                    }, w = r || this._defaultMax, E = 0 === l ? i.createElement(le, { ...k,
                        focus: t,
                        min: s || o,
                        max: w,
                        trackEvent: g
                    }) : i.createElement(ee.NumberInput, { ...k,
                        step: .01,
                        min: s,
                        max: w
                    });
                    return i.createElement("div", {
                        className: a(m, oe.control)
                    }, i.createElement("div", {
                        className: oe.label
                    }, " ", u, " "), E)
                }
            }
            var de = s(95318);
            const pe = (0, n.t)("Risk"),
                ue = (0, n.t)("Units"),
                he = (0, n.t)("Lots");
            class me extends i.PureComponent {
                constructor(e) {
                    super(e), this._onFocus = e => {
                        e !== this.props.model.focusedControl.value() && this.props.model.focusedControl.setValue(e), this.props.model.onControlFocused.fire()
                    }, this._errorHandler = e => {
                        this.props.model.setControlError(e)
                    }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model)
                }
                componentWillUnmount() {
                    this._unsubscribeFromModel(this.props.model)
                }
                render() {
                    var e;
                    const t = this.context.value,
                        {
                            model: s,
                            symbolHasLotSize: r,
                            trackEvent: o,
                            focus: n
                        } = this.props,
                        l = s.error.value(),
                        c = {
                            errorHandler: this._errorHandler,
                            error: l,
                            status: s.status.value(),
                            onFocus: this._onFocus,
                            trackEvent: o,
                            fontSizeStyle: "medium"
                        },
                        d = Boolean(l && l.res),
                        p = l && l.msg,
                        u = s.showRiskControls && s.isRiskAvailable.value() && (t.showPercentRiskInQty || t.showCurrencyRiskInQty);
                    return i.createElement(i.Fragment, null, i.createElement($.ControlGroupContext.Provider, {
                        value: this._getGroupContextValue(!0, !u)
                    }, i.createElement(ce, { ...c,
                        ...this._generateHighlightProps(0),
                        control: s.quantity,
                        min: s.qty.min,
                        max: s.qty.max,
                        step: s.qty.step,
                        uiStep: s.qty.uiStep,
                        type: 0,
                        formatter: s.formatter,
                        label: null !== (e = s.units) && void 0 !== e ? e : r ? he : ue,
                        className: a(!u && oe.single, oe.units),
                        focus: n,
                        error: d && this._isSelectedControl(0),
                        errorMessage: p
                    })), u && i.createElement("div", {
                        className: oe.risk
                    }, t.showCurrencyRiskInQty && i.createElement($.ControlGroupContext.Provider, {
                        value: this._getGroupContextValue(!1, !t.showPercentRiskInQty)
                    }, i.createElement(ce, { ...c,
                        ...this._generateHighlightProps(1),
                        control: s.riskInCurrency,
                        step: s.riskStep,
                        type: 1,
                        formatter: s.riskInCurrencyFormatter,
                        label: s.currency + " " + pe,
                        error: d && this._isSelectedControl(1),
                        errorMessage: p
                    })), t.showPercentRiskInQty && i.createElement($.ControlGroupContext.Provider, {
                        value: this._getGroupContextValue(!1, !0)
                    }, i.createElement(ce, { ...c,
                        ...this._generateHighlightProps(2),
                        control: s.riskInPercent,
                        step: s.riskStep,
                        type: 2,
                        formatter: s.riskInPercentFormatter,
                        label: "% " + pe,
                        error: d && this._isSelectedControl(2),
                        errorMessage: p
                    }))))
                }
                _generateHighlightProps(e) {
                    const t = this.props.model.error.value(),
                        s = this.props.model.isRiskAvailable.value() ? this._isSelectedControl(e) : void 0;
                    return {
                        highlight: (this.context.value.showCurrencyRiskInQty || this.context.value.showPercentRiskInQty) && (0 === e ? s : this._isSelectedControl(e)),
                        highlightRemoveRoundBorder: 0,
                        intent: Boolean(t && t.res) && this._isSelectedControl(e) ? "danger" : void 0
                    }
                }
                _isSelectedControl(e) {
                    return this.props.model.status.value() !== b.OrderPanelStatus.Wait && this.props.model.focusedControl.value() === e
                }
                _subscribeToModel(e) {
                    e.focusedControl.subscribe(this._callback), e.isRiskAvailable.subscribe(this._callback), e.error.subscribe(this._callback)
                }
                _unsubscribeFromModel(e) {
                    e.focusedControl.unsubscribe(this._callback), e.isRiskAvailable.unsubscribe(this._callback), e.error.unsubscribe(this._callback)
                }
                _getGroupContextValue(e, t) {
                    return {
                        isGrouped: !0,
                        disablePositionAdjustment: !0,
                        cellState: {
                            isTop: !0,
                            isRight: t,
                            isBottom: !0,
                            isLeft: e
                        }
                    }
                }
            }
            me.contextType = de.SettingsContext;
            var ve = s(93455),
                ge = s(60521),
                fe = s(97265),
                _e = s(44377),
                be = s(92063),
                ye = s(63802),
                Ce = s(79177);
            const ke = [1, 5, 10, 25, 50, 75, 100];

            function we(e) {
                const t = (0, i.useRef)(null),
                    [s, r] = (0, _.useWatchedValue)(e.value),
                    [o, n] = (0, _.useWatchedValue)(e.focusedControl),
                    [l, c] = (0, i.useState)(!1),
                    [u, h] = (0, i.useState)(0),
                    m = (0, fe.useWatchedValueReadonly)({
                        watchedValue: e.error
                    }),
                    v = (0, f.useObservable)(e.balanceValue$, null),
                    g = (0, f.useObservable)(e.side$, e.initialSide),
                    y = Boolean(m && m.res),
                    C = m && m.msg,
                    k = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    var t;
                    5 === e.initialFocus && null !== (t = k.current) && (t.focus(), t.setSelectionRange(t.value.length, t.value.length))
                }, []), i.createElement(i.Fragment, null, i.createElement(ee.NumberInput, { ... function(e) {
                        const t = {
                            highlightRemoveRoundBorder: 0
                        };
                        S(e) && (t.highlight = !0);
                        Boolean(m && m.res) && S(e) && (t.intent = "danger");
                        return t
                    }(e.control),
                    value: s,
                    onBlur: e.forceRoundByStep ? function() {
                        if (null !== s && void 0 !== e.step) {
                            const t = new ge.Big(s),
                                r = t.mod(e.step);
                            if (!r.eq(0)) {
                                w(t.minus(r).toNumber())
                            }
                        }
                    } : void 0,
                    onValueChange: w,
                    min: e.min,
                    step: e.step,
                    formatter: e.formatter,
                    errorMessage: C,
                    errorHandler: e.setControlError,
                    error: y && S(e.control),
                    inputReference: function(e) {
                        k.current = e
                    },
                    innerLabel: l ? void 0 : i.createElement("span", {
                        className: Ce.label
                    }, e.label),
                    onFocus: () => {
                        return t = e.control, n(t), void e.onControlFocused.fire();
                        var t
                    },
                    className: a(Ce.input, e.status.value() === b.OrderPanelStatus.Wait && Ce.wait),
                    button: E() ? i.createElement(ye.CaretButton, {
                        isDropped: l,
                        onClick: function() {
                            c(!l)
                        }
                    }) : i.createElement(i.Fragment, null),
                    containerReference: function(e) {
                        t.current = e
                    },
                    alwaysUpdateValueFromProps: e.forceRoundByStep,
                    fontSizeStyle: e.fontSizeStyle
                }), E() && null !== v && i.createElement(_e.PopupMenu, {
                    position: function() {
                        const e = (0, d.ensureNotNull)(t.current).getBoundingClientRect();
                        return h(e.width), {
                            x: e.left,
                            y: e.top + e.height + 1
                        }
                    },
                    onClose: P,
                    isOpened: l,
                    doNotCloseOn: t.current,
                    onKeyDown: function(e) {
                        switch ((0, p.hashFromEvent)(e)) {
                            case 27:
                                l && (e.preventDefault(), P())
                        }
                    },
                    minWidth: u
                }, ke.map(t => {
                    const s = function(e) {
                            return (0, ge.Big)((0,
                                d.ensureNotNull)(v)).mul(.01).mul(e).toNumber()
                        }(t),
                        o = i.createElement(i.Fragment, null, t + "%  ", i.createElement("span", {
                            className: Ce.value
                        }, "(" + e.formatter.format(s) + " " + e.label + ")"));
                    return i.createElement(be.PopupMenuItem, {
                        key: t.toString(),
                        className: Ce.popupMenuItem,
                        label: o,
                        onClick: () => r(s)
                    })
                })));

                function w(t) {
                    r(t), e.onModifiedCallback()
                }

                function E() {
                    return null !== v && v > 0 && (-1 === g ? 3 === e.control : 4 === e.control)
                }

                function S(t) {
                    return e.status.value() !== b.OrderPanelStatus.Wait && o === t
                }

                function P() {
                    c(!1), (0, d.ensureNotNull)(t.current).focus()
                }
            }

            function Ee(e) {
                const {
                    model: t,
                    className: s
                } = e, r = (0, f.useObservable)(t.quoteCurrencyUiParams$), o = {
                    side$: t.side$,
                    initialSide: t.getSide(),
                    status: t.status,
                    formatter: t.formatter,
                    error: t.error,
                    focusedControl: t.focusedControl,
                    onControlFocused: t.onControlFocused,
                    setControlError: t.setControlError,
                    fontSizeStyle: "medium"
                };
                return i.createElement(i.Fragment, null, i.createElement("div", {
                    className: Ce.title
                }, (0, n.t)("Units")), i.createElement(ve.ControlGroup, {
                    cols: 1,
                    rows: 2,
                    className: a(s, Ce.wrapper)
                }, i.createElement(we, { ...o,
                    value: t.quantity.value,
                    onModifiedCallback: t.quantity.onModifiedCallback,
                    label: t.info.baseCurrency,
                    control: 3,
                    balanceValue$: t.baseCurrencyCryptoBalanceValue$,
                    initialFocus: e.focus,
                    forceRoundByStep: !0,
                    step: t.info.qty.step,
                    min: t.info.qty.min
                }), i.createElement(we, { ...o,
                    value: t.quoteCurrencyQuantity.value,
                    onModifiedCallback: t.quoteCurrencyQuantity.onModifiedCallback,
                    label: t.info.quoteCurrency,
                    control: 4,
                    balanceValue$: t.quoteCurrencyCryptoBalanceValue$,
                    step: null == r ? void 0 : r.step,
                    min: null == r ? void 0 : r.min
                })))
            }
            var Se = s(27871),
                Pe = s(1614),
                De = s(99746);

            function Me(e) {
                const t = a(De.priceLabel, De[e.modifier.toLowerCase()]);
                return i.createElement("span", {
                    className: a(t)
                }, e.modifier)
            }
            var Ne = s(32965);

            function Ie(e) {
                const t = e.price === e.ask,
                    s = e.price === e.bid,
                    r = e.price === e.last,
                    o = (t || s) && e.ask === e.bid;
                let n, a;
                return e.displayPriceLabel && (o && 1 === e.side ? n = i.createElement(Me, {
                    modifier: "Ask"
                }) : o && -1 === e.side ? n = i.createElement(Me, {
                    modifier: "Bid"
                }) : t ? n = i.createElement(Me, {
                    modifier: "Ask"
                }) : s && (n = i.createElement(Me, {
                    modifier: "Bid"
                })), a = i.createElement("div", {
                    className: Ne.labelsGroup
                }, n, r && i.createElement(Me, {
                    modifier: "Last"
                }))), i.createElement("div", {
                    className: Ne.absolutePriceDropdownItem
                }, i.createElement("div", {
                    className: Ne.price
                }, e.price), a)
            }
            var Be = s(94087),
                Te = s(21538),
                xe = s(59636),
                Oe = s(83701);
            const Fe = (0, Se.makeKeyboardListener)(Be.InputWithError),
                He = (0, n.t)("Price"),
                Re = (0, n.t)("Price format is invalid.");
            class Le extends i.PureComponent {
                constructor(e) {
                    super(e), this._priceControl = null, this._priceInput = null, this._dropdown = null, this._setDropdownRef = e => {
                        this._dropdown = e
                    }, this._setInitialFocus = () => {
                        !re.mobiletouch && this._priceInput && (this.props.priceType === b.PriceType.Limit && 1 === this.props.focus || this.props.priceType === b.PriceType.Stop && 2 === this.props.focus) && (this._priceInput.setSelectionRange(this.state.displayPrice.length, this.state.displayPrice.length), this._priceInput.focus())
                    }, this._onFocus = e => {
                        if (this.props.onControlFocused && this.props.onControlFocused(0), this.props.errorHandler) {
                            const e = this.state.priceFormatter.parse(this.state.displayPrice);
                            this.props.errorHandler(!e.res)
                        }
                        this.props.onFocus && this.props.onFocus(e)
                    }, this._onOutsideClick = e => {
                        if (null !== this._priceControl && !this._priceControl.contains(e.target)) {
                            const e = this.state.priceFormatter.parse(this.state.displayPrice);
                            let t = this.props.displayPrice;
                            t = e.res ? this.state.priceFormatter.format(e.value >= 0 ? e.value : Math.abs(e.value)) : this.state.prices[(0, xe.getDropdownItemsForDevice)()], this.setState({
                                displayPrice: t
                            }, () => {
                                this._onPriceSelected(t)
                            }), this.props.errorHandler && this.props.errorHandler(!1)
                        }
                        this.state.isOpened && this._dropdown && !this._dropdown.contains(e.target) && this._closeDropdown()
                    }, this._onInputChange = e => {
                        const t = e.currentTarget.value,
                            s = this.state.priceFormatter.parse(t);
                        this._onModifiedCallback(), this.props.errorHandler && this.props.errorHandler(!Boolean(s.res)), this._onPriceSelected(t)
                    }, this._onTouchStart = e => {
                        e.stopPropagation(), this._swipeState.y = e.touches[0].clientY
                    }, this._onTouchMove = e => {
                        if (e.preventDefault(), e.stopPropagation(), e.changedTouches && e.changedTouches.length && null !== this._swipeState.y) {
                            const t = e.changedTouches[0].clientY - this._swipeState.y;
                            if (Math.abs(t) < 10) return;
                            this._swipeState.direction = t > 0 ? "up" : "down", "up" === this._swipeState.direction ? this._prependPriceOnTouchMove() : "down" === this._swipeState.direction && this._appendPriceOnTouchMove()
                        }
                    }, this._onTouchEnd = e => {
                        e.stopPropagation(), this._resetSwipeState()
                    }, this._onDropdownWheelNoPassiv = e => {
                        e.preventDefault(), e.stopPropagation(), e.deltaY < 0 ? this._prependPriceOnWheel() : this._appendPriceOnWheel()
                    }, this._onInputMouseWheel = e => {
                        e.preventDefault(), e.stopPropagation(), this._onModifiedCallback(), this._scrollPriceOnWheel(e.deltaY < 0 ? 1 : -1)
                    }, this._onSelect = (e, t) => {
                        const s = this.state.priceFormatter.parse(t.text);
                        this.props.errorHandler && this.props.errorHandler(!s.res), this.setState({
                            highlight: !0,
                            displayPrice: t.text,
                            selected: e,
                            isPriceSelectedByWheelOrByDropdown: !0
                        }, () => {
                            this._onModifiedCallback(), this._closeDropdown(), this._onPriceSelected(t.text), !re.mobiletouch && this._priceInput && this._priceInput.focus()
                        })
                    }, this._onNavigate = (e, t) => {
                        const s = this.state.command && "prev" === this.state.command.name,
                            r = this.state.command && "next" === this.state.command.name;
                        s ? this._prependPriceOnNavigate() : r && this._appendPriceOnNavigate()
                    }, this._onMouseOver = e => {
                        this.setState({
                            mouseOver: !0
                        })
                    }, this._onMouseOut = e => {
                        this.setState({
                            mouseOver: !1
                        })
                    }, this._onOpenBtnClick = e => {
                        e.stopPropagation(), this.state.isOpened ? this._closeDropdown() : (this._openDropdown(), !re.mobiletouch && this._priceInput && (this._priceInput.setSelectionRange(this.state.displayPrice.length, this.state.displayPrice.length), this._priceInput.focus()), this.props.onControlFocused && this.props.onControlFocused(0))
                    }, this._setPriceInput = e => {
                        this._priceInput = e
                    }, this._setPriceControl = e => {
                        this._priceControl = e
                    }, this._scrollPriceOnArrowUp = e => {
                        e.preventDefault(), this._onModifiedCallback(), this._prependPriceOnNavigate()
                    }, this._scrollPriceOnArrowDown = e => {
                        e.preventDefault(), this._onModifiedCallback(), this._appendPriceOnNavigate()
                    }, this._selectPrev = e => {
                        e.preventDefault(), this._onModifiedCallback(), this.setState({
                            command: {
                                name: "prev"
                            }
                        })
                    }, this._selectNext = e => {
                        e.preventDefault(), this._onModifiedCallback(), this.setState({
                            command: {
                                name: "next"
                            }
                        })
                    }, this._openDropdown = () => {
                        this.setState({
                            highlight: !0,
                            isOpened: !0,
                            keyboardEventHandlers: this._getKeyboardEventHandlers("open")
                        })
                    }, this._closeDropdownWithStopPropagation = e => {
                        e && (e.stopPropagation(), e.nativeEvent.stopImmediatePropagation()), this._closeDropdown()
                    }, this._closeDropdown = () => {
                        const e = {
                            isOpened: !1,
                            keyboardEventHandlers: this._getKeyboardEventHandlers("close")
                        };
                        if (this.props.error || -1 !== this.state.prices.indexOf(this.state.displayPrice) && this.state.selected === Math.floor(this.state.prices.length / 2)) this.setState(e);
                        else {
                            const t = this.state.priceFormatter.parse(this.state.displayPrice),
                                s = t.res ? (0, xe.generatePriceRangeFrom)(t.value, this.props.step, this.state.priceFormatter, (0, xe.getDropdownItemsForDevice)()) : this.state.prices;
                            this.setState(t => ({ ...e,
                                prices: s,
                                selected: s.indexOf(this.state.displayPrice)
                            }))
                        }
                    };
                    const t = (0, xe.generatePriceRangeFrom)((0, xe.parsePrice)(e.displayPrice, e.priceFormatter), e.step, e.priceFormatter, (0, xe.getDropdownItemsForDevice)());
                    this.state = {
                        displayPrice: e.displayPrice,
                        prices: t,
                        selected: t.indexOf(e.displayPrice),
                        highlight: this.props.highlight,
                        isOpened: !1,
                        mouseOver: !1,
                        keyboardEventHandlers: this._getKeyboardEventHandlers("close"),
                        priceFormatter: e.priceFormatter,
                        step: e.step,
                        isPriceSelectedByWheelOrByDropdown: !1
                    }, this._resetSwipeState()
                }
                componentDidMount() {
                    this._setInitialFocus()
                }
                render() {
                    var e;
                    const t = a(Oe.absolutePriceControl, this.props.className),
                        s = i.createElement("span", {
                            className: Oe.priceLabel
                        }, null !== (e = this.props.priceLabel) && void 0 !== e ? e : He),
                        r = a(Oe.openIcon, this.state.isOpened && Oe.opened, this.props.status === b.OrderPanelStatus.Wait && Oe.wait),
                        o = i.createElement("div", {
                            className: Oe.openButton,
                            onClick: this._onOpenBtnClick
                        }, i.createElement("div", {
                            className: Oe.iconWrapper
                        }, i.createElement(L.Icon, {
                            className: r,
                            icon: Te
                        })));
                    return i.createElement(te.OutsideEvent, {
                        click: !0,
                        mouseDown: !0,
                        touchStart: !0,
                        handler: this._onOutsideClick
                    }, e => i.createElement("span", {
                        className: t,
                        ref: e
                    }, s, i.createElement(Fe, {
                        className: this.props.inputClassName,
                        containerReference: this._setPriceControl,
                        inputReference: this._setPriceInput,
                        keyboardEventHandlers: this.state.keyboardEventHandlers,
                        value: this.state.displayPrice,
                        warning: this.props.warning,
                        error: this.props.error,
                        errorMessage: this.props.errorMessage || Re,
                        onChange: this._onInputChange,
                        onFocus: this._onFocus,
                        onBlur: this.props.onBlur,
                        onMouseOver: this._onMouseOver,
                        onMouseOut: this._onMouseOut,
                        onWheelNoPassive: this._onInputMouseWheel,
                        highlight: this.state.highlight,
                        highlightRemoveRoundBorder: this.props.highlightRemoveRoundBorder,
                        fontSizeStyle: this.props.fontSizeStyle
                    }, o), i.createElement(Pe.DropdownList, {
                        anchor: "bottom",
                        root: "document",
                        reference: this._setDropdownRef,
                        className: Oe.list,
                        command: this.state.command,
                        isOpened: this.state.isOpened,
                        items: this._makeListItems(),
                        itemsClassName: Oe.item,
                        width: this._getDropdownWidth(),
                        selected: this.state.selected,
                        selectedClassName: Oe.selected,
                        target: null !== this._priceControl ? this._priceControl : void 0,
                        attachmentOffsetY: 3,
                        inheritWidthFromTarget: !1,
                        shouldScrollIfNotVisible: !1,
                        onSelect: this._onSelect,
                        onNavigate: this._onNavigate,
                        onDropdownTouchStart: this._onTouchStart,
                        onDropdownTouchMove: this._onTouchMove,
                        onDropdownTouchEnd: this._onTouchEnd,
                        onDropdownWheelNoPassive: this._onDropdownWheelNoPassiv
                    })))
                }
                static getDerivedStateFromProps(e, t) {
                    if (e.displayPrice !== t.displayPrice || e.highlight !== t.highlight || e.priceFormatter !== t.priceFormatter || e.step !== t.step) {
                        const s = e.priceFormatter.parse(e.displayPrice),
                            r = s.res ? (0, xe.generatePriceRangeFrom)(s.value, e.step, e.priceFormatter, (0, xe.getDropdownItemsForDevice)()) : t.prices,
                            i = e.priceFormatter.format((0, xe.parsePrice)(e.displayPrice, e.priceFormatter)),
                            o = { ...t,
                                displayPrice: e.displayPrice,
                                priceFormatter: e.priceFormatter,
                                step: e.step,
                                isPriceSelectedByWheelOrByDropdown: !1,
                                highlight: e.highlight
                            };
                        return e.error || (o.selected = r.indexOf(i), o.prices = r), o
                    }
                    return null
                }
                _onPriceSelected(e) {
                    "function" == typeof this.props.onPriceSelected && this.props.onPriceSelected(e)
                }
                _resetSwipeState() {
                    this._swipeState = {
                        direction: null,
                        y: null
                    }
                }
                _getKeyboardEventHandlers(e) {
                    return "close" === e ? {
                        [Se.KeyCode.UpArrow]: this._scrollPriceOnArrowUp,
                        [Se.KeyCode.DownArrow]: this._scrollPriceOnArrowDown
                    } : {
                        [Se.KeyCode.Enter]: this._closeDropdownWithStopPropagation,
                        [Se.KeyCode.Escape]: this._closeDropdownWithStopPropagation,
                        [Se.KeyCode.UpArrow]: this._selectPrev,
                        [Se.KeyCode.DownArrow]: this._selectNext
                    }
                }
                _makeListItems(e = !0) {
                    return this.state.prices.map(t => ({
                        text: t,
                        elem: i.createElement(Ie, {
                            price: t,
                            ask: this.props.priceFormatter.format(this.props.ask),
                            bid: this.props.priceFormatter.format(this.props.bid),
                            last: this.props.priceFormatter.format(this.props.last),
                            side: this.props.side,
                            displayPriceLabel: e
                        })
                    }))
                }
                _prependPriceOnWheel() {
                    const e = this.state.priceFormatter.format((0, xe.parsePrice)(this.state.prices[0], this.state.priceFormatter) + 1 * this.props.step);
                    this.setState(t => ({
                        prices: [e].concat(t.prices.slice(0, -1)),
                        selected: 0 === t.selected ? 1 : t.selected + 1
                    }))
                }
                _appendPriceOnWheel() {
                    const e = this.state.prices.length - 1,
                        t = this.state.priceFormatter.format((0, xe.parsePrice)(this.state.prices[e], this.state.priceFormatter) + -1 * this.props.step);
                    this.setState(s => ({
                        prices: s.prices.slice(1).concat(t),
                        selected: s.selected === e ? e - 1 : s.selected - 1
                    }))
                }
                _scrollPriceOnWheel(e) {
                    const t = this.state.priceFormatter.format((0, xe.parsePrice)(this.state.prices[this.state.selected], this.state.priceFormatter) + e * this.props.step);
                    this.setState({
                        displayPrice: t
                    }, () => {
                        1 === e ? this._prependPriceOnNavigate() : this._appendPriceOnNavigate()
                    })
                }
                _prependPriceOnNavigate() {
                    const e = [this.state.priceFormatter.format((0, xe.parsePrice)(this.state.prices[0], this.state.priceFormatter) + 1 * this.props.step)].concat(this.state.prices.slice(0, -1)),
                        t = this.state.prices.length - 1;
                    let s;
                    s = this.state.selected <= 0 ? 0 : this.state.selected > t ? t : this.state.selected, this.setState({
                        prices: e,
                        displayPrice: e[s],
                        selected: s,
                        isPriceSelectedByWheelOrByDropdown: !0
                    }, () => {
                        this._onPriceSelected(e[s])
                    })
                }
                _appendPriceOnNavigate() {
                    const e = this.state.priceFormatter.format((0,
                            xe.parsePrice)(this.state.prices[this.state.prices.length - 1], this.state.priceFormatter) + -1 * this.props.step),
                        t = this.state.prices.slice(1).concat(e),
                        s = this.state.prices.length - 1;
                    let r;
                    r = this.state.selected <= 0 ? 0 : this.state.selected > s ? s : this.state.selected, this.setState({
                        prices: t,
                        displayPrice: t[r],
                        selected: r,
                        isPriceSelectedByWheelOrByDropdown: !0
                    }, () => {
                        this._onPriceSelected(t[r])
                    })
                }
                _prependPriceOnTouchMove() {
                    const e = (0, xe.parsePrice)(this.state.prices[0], this.state.priceFormatter),
                        t = (0, xe.generateSingleDirectionItems)(1, e, this.props.step, 1, this.state.priceFormatter);
                    this.setState(e => ({
                        prices: t.concat(e.prices.slice(0, this.state.prices.length - 1)),
                        selected: 0 === e.selected ? 1 : e.selected + 1
                    }))
                }
                _appendPriceOnTouchMove() {
                    const e = this.state.prices.length - 1,
                        t = (0, xe.parsePrice)(this.state.prices[e], this.state.priceFormatter),
                        s = (0, xe.generateSingleDirectionItems)(1, t, this.props.step, -1, this.state.priceFormatter);
                    this.setState(t => ({
                        prices: t.prices.slice(1).concat(s),
                        selected: t.selected === e ? e - 1 : t.selected - 1
                    }))
                }
                _getDropdownWidth() {
                    if (this.state.isOpened && null !== this._priceControl && (this.context.mode === b.OrderEditorDisplayMode.Popup || this.state.prices[0].length <= 7)) {
                        return parseFloat(window.getComputedStyle(this._priceControl, null).getPropertyValue("width")) + 2
                    }
                }
                _onModifiedCallback() {
                    this.props.onModifiedCallback && this.props.onModifiedCallback()
                }
            }
            Le.contextType = b.Context, Le.defaultProps = {
                className: "",
                inputClassName: ""
            };
            var Ve = s(6276);

            function ze(e) {
                return i.createElement("div", {
                    className: Ve.relativePriceDropdownItem
                }, i.createElement("div", {
                    className: Ve.price
                }, e.price))
            }
            var We = s(47898),
                Ae = s(58198);

            function Ue(e, t) {
                return e.findIndex(e => e.displayValue === t)
            }
            const Ke = /^[-+]?[0-9]*\.?[0-9]+$/;

            function Ze(e) {
                return Ke.test(e)
            }

            function qe(e) {
                return "ask" === e ? "Ask" : "bid" === e ? "Bid" : "Stop"
            }

            function Ge(e) {
                return void 0 !== e && e > 0 ? " + " + Math.abs(e) : void 0 !== e && e < 0 ? " - " + Math.abs(e) : ""
            }

            function Qe(e, t) {
                return qe(e) + Ge(Math.round(t || 0))
            }

            function je(e) {
                return void 0 !== e ? String(e) : "0"
            }

            function Ye(e, t) {
                const s = e.offset;
                return r = e.base, i = function(e, t) {
                    return (Math.abs(e) >= 1 ? e : 0) + (1 === t ? 1 : -1)
                }(s, t), {
                    displayValue: qe(r) + Ge(i),
                    base: r,
                    offset: i
                };
                var r, i
            }

            function Xe(e, t) {
                const s = [],
                    r = [],
                    i = {
                        displayValue: qe(e.base) + Ge(e.offset),
                        base: e.base,
                        offset: e.offset
                    };
                for (let e = 0; e < t; e++) s.unshift(Ye(0 === e ? i : s[0], 1)), r.push(Ye(0 === e ? i : r[e - 1], -1));
                return [...s, i, ...r]
            }

            function Je() {
                return "phone" !== Ae.mediaState.device && "phone-vertical" !== Ae.mediaState.device ? 6 : 4
            }
            var $e = s(45299);
            const et = (0, Se.makeKeyboardListener)(Be.InputWithError),
                tt = (0, n.t)("Ticks", {
                    context: "price"
                }),
                st = (0, n.t)("Price format is invalid.");
            class rt extends i.PureComponent {
                constructor(e) {
                    super(e), this._priceInput = null, this._priceControl = null, this._dropdown = null, this._setDropdownRef = e => {
                        this._dropdown = e
                    }, this._onMouseOver = e => {
                        this.setState({
                            mouseOver: !0
                        })
                    }, this._onMouseOut = e => {
                        this.setState({
                            mouseOver: !1
                        })
                    }, this._onOutsideClick = e => {
                        this.state.isOpened && this._dropdown && !this._dropdown.contains(e.target) && this._closeDropdown()
                    }, this._onFocus = e => {
                        this.setState({
                            isEditing: !0,
                            displayValue: je(this.state.value.offset)
                        }, () => {
                            var e, t;
                            re.mobiletouch || null === this._priceInput || (e = this._priceInput, t = this.state.displayValue.length, e.setSelectionRange && (e.focus(), e.setSelectionRange(0, t), e.select()))
                        }), this.props.onControlFocused && this.props.onControlFocused(1), this.props.onFocus && this.props.onFocus(e)
                    }, this._onBlur = e => {
                        this.props.onBlur && this.props.onBlur(e);
                        const t = this.state.prices[0].base,
                            s = Ue(this.state.prices, Qe(t, this.state.value.offset)),
                            r = 0 <= s && s <= this.state.prices.length - 1 ? s : Math.floor(this.state.prices.length / 2);
                        this.setState({
                            isEditing: !1,
                            displayValue: this.state.prices[r].displayValue,
                            selected: r
                        }, () => {
                            this._trackExitEditingModeEvent(this.state.prices[r].offset)
                        })
                    }, this._onInputChange = e => {
                        this._onModifiedCallback();
                        const t = e.currentTarget.value;
                        if (Ze(t)) {
                            const e = {
                                    base: this.state.value.base,
                                    offset: Number(t)
                                },
                                s = Xe(e, Je()),
                                r = Ue(s, Qe(e.base, e.offset));
                            this.setState({
                                displayValue: t,
                                prices: s,
                                selected: r,
                                isOpened: !1
                            }, () => {
                                this._onPriceSelected(e)
                            })
                        } else this.setState({
                            displayValue: t,
                            isOpened: !1
                        })
                    }, this._onTouchStart = e => {
                        e.stopPropagation(), this._swipeState.y = e.touches[0].clientY
                    }, this._onTouchMove = e => {
                        if (e.preventDefault(), e.stopPropagation(), e.changedTouches && e.changedTouches.length && null !== this._swipeState.y) {
                            const t = e.changedTouches[0].clientY - this._swipeState.y;
                            if (Math.abs(t) < 10) return;
                            this._swipeState.direction = t > 0 ? "up" : "down", "up" === this._swipeState.direction ? this._prependPriceOnTouchMove() : "down" === this._swipeState.direction && this._appendPriceOnTouchMove()
                        }
                    }, this._onTouchEnd = e => {
                        e.stopPropagation(), this._resetSwipeState()
                    }, this._onDropdownWheelNoPassive = e => {
                        e.preventDefault(), e.stopPropagation(), e.deltaY < 0 ? this._prependPriceOnWheel() : this._appendPriceOnWheel()
                    }, this._onInputMouseWheel = e => {
                        e.preventDefault(), e.stopPropagation(), this._onModifiedCallback(), this._scrollPriceOnWheel(e.deltaY < 0 ? 1 : -1)
                    }, this._onSelect = (e, t) => {
                        this.setState(s => ({
                            highlight: !0,
                            displayValue: this.state.isEditing ? je(t.offset) : t.text,
                            selected: e
                        }), () => {
                            this._onModifiedCallback(), this._closeDropdown(), this._onPriceSelected(), this.setState({
                                isEditing: !1
                            }, () => {
                                this._blurInput()
                            })
                        })
                    }, this._onNavigate = (e, t) => {
                        const s = this.state.command && "prev" === this.state.command.name,
                            r = this.state.command && "next" === this.state.command.name;
                        s ? this._prependPriceOnNavigate() : r && this._appendPriceOnNavigate()
                    }, this._onOpenBtnClick = e => {
                        var t, s;
                        e.preventDefault(), e.stopPropagation(), this.state.isOpened ? this._closeDropdown() : (this._openDropdown(), re.mobiletouch ? null === (s = this._priceInput) || void 0 === s || s.blur() : null === (t = this._priceInput) || void 0 === t || t.focus(), this.props.onControlFocused && this.props.onControlFocused(1), this.setState({
                            isEditing: !1,
                            displayValue: this.state.displayValue
                        }, () => {
                            !re.mobiletouch && this._priceInput && this._priceInput.setSelectionRange(this.state.displayValue.length, this.state.displayValue.length)
                        }))
                    }, this._switchEditingMode = e => {
                        e.preventDefault();
                        const t = Number(this.state.displayValue);
                        if (Number.isInteger(t)) this.setState({
                            isEditing: !1
                        }, () => {
                            this._blurInput()
                        });
                        else {
                            const e = Math.round(t),
                                s = {
                                    base: this.state.value.base,
                                    offset: e
                                },
                                r = Xe(s, Je()),
                                i = Ue(r, Qe(s.base, s.offset));
                            this.setState({
                                displayValue: String(e),
                                prices: r,
                                selected: i,
                                isEditing: !1
                            }, () => {
                                this._onPriceSelected(), this._blurInput()
                            })
                        }
                    }, this._setPriceInput = e => {
                        this._priceInput = e
                    }, this._setPriceControl = e => {
                        this._priceControl = e
                    }, this._scrollPriceOnArrowUp = e => {
                        e.preventDefault(), this._onModifiedCallback(), this._prependPriceOnNavigate()
                    }, this._scrollPriceOnArrowDown = e => {
                        e.preventDefault(), this._onModifiedCallback(), this._appendPriceOnNavigate()
                    }, this._selectPrev = e => {
                        e.preventDefault(), this._onModifiedCallback(), this.setState({
                            command: {
                                name: "prev"
                            }
                        })
                    }, this._selectNext = e => {
                        e.preventDefault(), this._onModifiedCallback(), this.setState({
                            command: {
                                name: "next"
                            }
                        })
                    }, this._openDropdown = () => {
                        this.setState({
                            highlight: !0,
                            isOpened: !0,
                            keyboardEventHandlers: this._getKeyboardEventHandlers("open")
                        })
                    }, this._closeDropdownOnKeyDown = e => {
                        e.preventDefault(), this._closeDropdown(), this.setState({
                            isEditing: !1,
                            displayValue: this.state.displayValue
                        }, () => {
                            this._blurInput()
                        })
                    }, this._closeDropdown = () => {
                        var e;
                        const t = {
                            isOpened: !1,
                            keyboardEventHandlers: this._getKeyboardEventHandlers("close")
                        };
                        if (-1 === Ue(this.state.prices, this.state.displayValue) || this.state.selected !== Math.floor(this.state.prices.length / 2)) {
                            const e = Xe({
                                    base: this.state.value.base,
                                    offset: this.state.value.offset || 0
                                }, Je()),
                                s = Ue(e, this.state.displayValue);
                            this.setState({ ...t,
                                prices: e,
                                selected: s
                            })
                        } else this.setState(t);
                        re.mobiletouch && (null === (e = this._priceInput) || void 0 === e || e.blur())
                    }, this._trackExitEditingModeEvent = e => {
                        this.props.trackEvent && this.props.trackEvent("Order Ticket", "Relative Price - Exit Editing Mode", String(e))
                    };
                    const t = Qe(e.initialValue.base, e.initialValue.offset),
                        s = Xe(this.props.initialValue, Je()),
                        r = Ue(s, t);
                    this.state = {
                        value: e.initialValue,
                        displayValue: t,
                        prices: s,
                        selected: r,
                        highlight: this.props.highlight,
                        isOpened: !1,
                        isEditing: !1,
                        mouseOver: !1,
                        keyboardEventHandlers: this._getKeyboardEventHandlers("close")
                    }, this._resetSwipeState()
                }
                render() {
                    const e = a($e.relativePriceControl, this.props.className),
                        t = i.createElement("span", {
                            className: $e.pipsLabel
                        }, tt),
                        s = a($e.openIcon, this.state.isOpened && $e.opened, this.props.status === b.OrderPanelStatus.Wait && $e.wait),
                        r = i.createElement("div", {
                            className: $e.openButton,
                            onClick: this._onOpenBtnClick
                        }, i.createElement("div", {
                            className: $e.iconWrapper
                        }, i.createElement(L.Icon, {
                            className: s,
                            icon: Te
                        }))),
                        o = this.state.isEditing && !Ze(this.state.displayValue),
                        n = o || this.props.error,
                        l = o ? st : this.props.errorMessage;
                    return i.createElement(te.OutsideEvent, {
                        click: !0,
                        mouseDown: !0,
                        touchStart: !0,
                        handler: this._onOutsideClick
                    }, s => i.createElement("span", {
                        className: e,
                        ref: s
                    }, t, i.createElement(et, {
                        className: this.props.inputClassName,
                        containerReference: this._setPriceControl,
                        inputReference: this._setPriceInput,
                        keyboardEventHandlers: this.state.keyboardEventHandlers,
                        value: this.state.displayValue,
                        readonly: this.state.isOpened,
                        warning: this.props.warning,
                        error: n,
                        errorMessage: l,
                        onFocus: this._onFocus,
                        onBlur: this._onBlur,
                        onChange: this._onInputChange,
                        onWheelNoPassive: this._onInputMouseWheel,
                        onMouseOver: this._onMouseOver,
                        onMouseOut: this._onMouseOut,
                        noReadonlyStyles: !0,
                        highlight: this.state.highlight,
                        highlightRemoveRoundBorder: this.props.highlightRemoveRoundBorder,
                        fontSizeStyle: this.props.fontSizeStyle
                    }, r), i.createElement(Pe.DropdownList, {
                        anchor: "bottom",
                        root: "document",
                        reference: this._setDropdownRef,
                        className: $e.list,
                        command: this.state.command,
                        isOpened: this.state.isOpened,
                        items: this._makeListItems(),
                        itemsClassName: $e.item,
                        selected: this.state.selected,
                        selectedClassName: $e.selected,
                        target: null !== this._priceControl ? this._priceControl : void 0,
                        attachmentOffsetY: 3,
                        inheritWidthFromTarget: !0,
                        shouldScrollIfNotVisible: !1,
                        onSelect: this._onSelect,
                        onNavigate: this._onNavigate,
                        onDropdownTouchStart: this._onTouchStart,
                        onDropdownTouchMove: this._onTouchMove,
                        onDropdownTouchEnd: this._onTouchEnd,
                        onDropdownWheelNoPassive: this._onDropdownWheelNoPassive
                    })))
                }
                static getDerivedStateFromProps(e, t) {
                    const s = Qe(e.initialValue.base, e.initialValue.offset);
                    if (!1 === (0, We.comparator)(t.value, e.initialValue) || t.highlight !== e.highlight) {
                        const r = Xe(e.initialValue, Je()),
                            i = Ue(r, s);
                        return { ...t,
                            highlight: e.highlight,
                            value: e.initialValue,
                            displayValue: t.isEditing ? je(e.initialValue.offset) : s,
                            prices: r,
                            selected: i
                        }
                    }
                    return null
                }
                _blurInput() {
                    !re.mobiletouch && this._priceInput && this._priceInput.blur()
                }
                _onPriceSelected(e) {
                    if ("function" == typeof this.props.onPriceSelected) {
                        const t = void 0 !== e ? e : this.state.prices[this.state.selected],
                            s = {
                                base: t.base,
                                offset: t.offset
                            };
                        this.props.onPriceSelected(s)
                    }
                }
                _onModifiedCallback() {
                    this.props.onModifiedCallback && this.props.onModifiedCallback()
                }
                _resetSwipeState() {
                    this._swipeState = {
                        direction: null,
                        y: null
                    }
                }
                _getKeyboardEventHandlers(e) {
                    return "close" === e ? {
                        [Se.KeyCode.UpArrow]: this._scrollPriceOnArrowUp,
                        [Se.KeyCode.DownArrow]: this._scrollPriceOnArrowDown,
                        [Se.KeyCode.Enter]: this._switchEditingMode
                    } : {
                        [Se.KeyCode.Enter]: this._closeDropdownOnKeyDown,
                        [Se.KeyCode.Escape]: this._closeDropdownOnKeyDown,
                        [Se.KeyCode.UpArrow]: this._selectPrev,
                        [Se.KeyCode.DownArrow]: this._selectNext
                    }
                }
                _makeListItems() {
                    return this.state.prices.map((e, t) => ({
                        base: e.base,
                        offset: e.offset,
                        text: e.displayValue,
                        elem: i.createElement(ze, {
                            price: e.displayValue
                        })
                    }))
                }
                _prependPriceOnWheel() {
                    const e = Ye(this.state.prices[0], 1);
                    this.setState(t => ({
                        prices: [e].concat(t.prices.slice(0, -1)),
                        selected: 0 === t.selected ? 1 : t.selected + 1
                    }))
                }
                _appendPriceOnWheel() {
                    const e = this.state.prices.length - 1,
                        t = Ye(this.state.prices[e], -1);
                    this.setState(s => ({
                        prices: s.prices.slice(1).concat(t),
                        selected: s.selected === e ? e - 1 : s.selected - 1
                    }))
                }
                _scrollPriceOnWheel(e) {
                    const t = Ye(this.state.prices[this.state.selected], e);
                    this.setState({
                        displayValue: this.state.isEditing ? je(t.offset) : t.displayValue
                    }, () => {
                        1 === e ? this._prependPriceOnNavigate() : this._appendPriceOnNavigate()
                    })
                }
                _prependPriceOnNavigate() {
                    const e = Ye(this.state.prices[0], 1);
                    this.setState(t => {
                        const s = [e].concat(t.prices.slice(0, -1)),
                            r = this.state.prices.length - 1;
                        let i;
                        return i = this.state.selected <= 0 ? 0 : this.state.selected > r ? r : t.selected, {
                            prices: s,
                            selected: i
                        }
                    }, () => {
                        this._onPriceSelected()
                    })
                }
                _appendPriceOnNavigate() {
                    const e = Ye(this.state.prices[this.state.prices.length - 1], -1);
                    this.setState(t => {
                        const s = t.prices.slice(1).concat(e),
                            r = this.state.prices.length - 1;
                        let i;
                        return i = this.state.selected <= 0 ? 0 : this.state.selected > r ? r : t.selected, {
                            prices: s,
                            selected: i
                        }
                    }, () => {
                        this._onPriceSelected()
                    })
                }
                _prependPriceOnTouchMove() {
                    const e = this.state.prices[0],
                        t = [];
                    t.unshift(Ye(e, 1)), this.setState(e => ({
                        prices: t.concat(e.prices.slice(0, this.state.prices.length - 1)),
                        selected: 0 === e.selected ? 1 : e.selected + 1
                    }))
                }
                _appendPriceOnTouchMove() {
                    const e = this.state.prices.length - 1,
                        t = this.state.prices[e],
                        s = [];
                    s.push(Ye(t, -1)), this.setState(t => ({
                        prices: t.prices.slice(1).concat(s),
                        selected: t.selected === e ? e - 1 : t.selected - 1
                    }))
                }
            }

            function it(e) {
                const t = e.relativePrice.value();
                return null !== t ? t : {
                    base: 1 === e.side.value() ? "ask" : "bid",
                    offset: 0
                }
            }

            function ot(e, t) {
                return e.status !== b.OrderPanelStatus.Wait && e.focusedControl === t
            }
            rt.defaultProps = {
                className: "",
                inputClassName: ""
            };
            var nt = s(86354);

            function at(e) {
                const t = i.useContext(de.SettingsContext),
                    s = t.value.showRelativePriceControl && !e.isRelativePriceControlHidden ? 2 : 1,
                    r = e.status !== b.OrderPanelStatus.Wait && e.error.res && "warning" === e.error.severity;
                return i.createElement("div", {
                    className: nt.controlGroup
                }, i.createElement(ve.ControlGroup, {
                    className: nt.controlContainer,
                    cols: s,
                    rows: 1,
                    disablePositionAdjustment: !0
                }, i.createElement(Le, { ...o(0),
                    className: nt.control,
                    priceType: e.priceType,
                    inputClassName: a(nt.input, e.status === b.OrderPanelStatus.Wait && nt.wait),
                    status: e.status,
                    displayPrice: e.absolutePrice,
                    step: e.step,
                    ask: e.ask,
                    bid: e.bid,
                    last: e.last,
                    side: e.side,
                    priceFormatter: e.priceFormatter,
                    warning: r,
                    error: e.error.res && "error" === e.error.severity && ot(e, 0),
                    errorMessage: e.errorMessage,
                    errorHandler: e.errorHandler,
                    onControlFocused: e.onControlFocused,
                    onPriceSelected: e.onAbsolutePriceSelected,
                    displayPriceLabel: !e.isRelativePriceControlHidden,
                    trackEvent: e.trackEvent,
                    onModifiedCallback: e.modifiedAbsolutePriceControlStat,
                    focus: e.focus,
                    fontSizeStyle: e.fontSizeStyle,
                    priceLabel: e.priceLabel
                }), t.value.showRelativePriceControl && !e.isRelativePriceControlHidden && i.createElement(rt, { ...o(1),
                    className: a(nt.control, nt.relativePriceControl),
                    inputClassName: a(nt.input, e.status === b.OrderPanelStatus.Wait && nt.wait),
                    status: e.status,
                    initialValue: e.relativePrice,
                    error: e.error.res && "error" === e.error.severity && ot(e, 1),
                    errorMessage: e.errorMessage,
                    onControlFocused: e.onControlFocused,
                    onPriceSelected: e.onRelativePriceSelected,
                    trackEvent: e.trackEvent,
                    onModifiedCallback: e.modifiedRelativePriceControlStat,
                    fontSizeStyle: e.fontSizeStyle
                })));

                function o(s) {
                    const r = {
                        highlightRemoveRoundBorder: 0
                    };
                    return ot(e, s) && t.value.showRelativePriceControl && (r.highlight = !0), r
                }
            }
            class lt extends i.PureComponent {
                constructor(e) {
                    super(e), this._errorHandler = e => {
                        this.props.model.setControlError(e)
                    }, this._updatePrice = e => {
                        null !== e && this._callback()
                    }, this._updateRelativePrice = e => {
                        null !== e && this._callback()
                    }, this._onAbsolutePriceSelected = e => {
                        this.props.model.onAbsolutePriceSelected(e)
                    }, this._onRelativePriceSelected = e => {
                        this.props.model.onRelativePriceSelected(e)
                    }, this._onControlFocused = e => {
                        this.props.model.focusedControl.setValue(e), this.props.model.onControlFocused.fire()
                    }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model)
                }
                componentWillUnmount() {
                    this._unsubscribeFromModel(this.props.model)
                }
                render() {
                    const e = this.props.model,
                        t = e.quotes.value();
                    return i.createElement(at, {
                        status: e.status.value(),
                        priceType: this.props.priceType,
                        focusedControl: e.focusedControl.value(),
                        absolutePrice: e.displayPrice.value(),
                        relativePrice: it(e),
                        errorHandler: this._errorHandler,
                        step: e.step.value(),
                        ask: t.ask,
                        bid: t.bid,
                        last: t.last,
                        side: e.side.value(),
                        priceFormatter: e.formatter,
                        error: e.error.value(),
                        errorMessage: e.error.value().msg,
                        onAbsolutePriceSelected: this._onAbsolutePriceSelected,
                        onRelativePriceSelected: this._onRelativePriceSelected,
                        modifiedAbsolutePriceControlStat: e.modifiedAbsolutePriceControlStat,
                        modifiedRelativePriceControlStat: e.modifiedRelativePriceControlStat,
                        onControlFocused: this._onControlFocused,
                        isRelativePriceControlHidden: e.isRelativePriceControlHidden,
                        trackEvent: this.props.trackEvent,
                        focus: this.props.focus,
                        fontSizeStyle: this.props.fontSizeStyle,
                        priceLabel: this.props.priceLabel
                    })
                }
                _subscribeToModel(e) {
                    e.focusedControl.subscribe(this._callback), e.displayPrice.subscribe(this._updatePrice), e.error.subscribe(this._callback), e.relativePrice.subscribe(this._updateRelativePrice), e.quotes.subscribe(this._callback), e.side.subscribe(this._callback), e.orderType.subscribe(this._callback), e.step.subscribe(this._callback)
                }
                _unsubscribeFromModel(e) {
                    e.focusedControl.unsubscribe(this._callback), e.displayPrice.unsubscribe(this._updatePrice), e.error.unsubscribe(this._callback), e.relativePrice.unsubscribe(this._updateRelativePrice), e.quotes.unsubscribe(this._callback), e.side.unsubscribe(this._callback), e.orderType.unsubscribe(this._callback), e.step.unsubscribe(this._callback)
                }
            }
            class ct extends i.PureComponent {
                constructor(e) {
                    super(e), this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this.props.model.orderType.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.props.model.orderType.unsubscribe(this._callback)
                }
                render() {
                    const {
                        model: e,
                        trackEvent: t,
                        focus: s
                    } = this.props, r = e.orderType.value(), o = 3 === r ? e.stopPriceModel : e.limitPriceModel, a = 4 === r;
                    return i.createElement(i.Fragment, null, a && i.createElement(lt, {
                        key: "stopPrice",
                        model: e.stopPriceModel,
                        priceType: b.PriceType.Stop,
                        trackEvent: t,
                        focus: s,
                        fontSizeStyle: "medium",
                        priceLabel: (0, n.t)("Stop price")
                    }), i.createElement(lt, {
                        key: o.id,
                        model: o,
                        priceType: 3 === r ? b.PriceType.Stop : b.PriceType.Limit,
                        trackEvent: t,
                        focus: s,
                        fontSizeStyle: "medium",
                        priceLabel: a ? (0, n.t)("Limit price") : void 0
                    }))
                }
            }
            var dt = s(99374),
                pt = s(57947),
                ut = s(36376);
            class ht extends i.PureComponent {
                constructor(e) {
                    super(e), this.onDurationChanged = e => {
                        this.props.model.currentDuration.setValue(e), this.props.model.onModifiedCallback()
                    }, this._onClick = () => {
                        this.props.model.onControlFocused.fire()
                    }, this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this.props.model.currentDuration.subscribe(this._callback), this.props.model.orderType.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.props.model.currentDuration.unsubscribe(this._callback), this.props.model.orderType.unsubscribe(this._callback)
                }
                render() {
                    const e = this.props.model.currentDuration.value();
                    return null === e ? null : i.createElement(pt.DurationControl, {
                        currentDuration: e,
                        durationMetaInfoList: this._getDurationMetaInfoList(),
                        onDurationChanged: this.onDurationChanged,
                        onClose: this.props.onClose,
                        onClick: this._onClick
                    })
                }
                _getDurationMetaInfoList() {
                    const e = this.props.model.orderType.value(),
                        t = this.props.model.durationMetaInfoList;
                    return (0, ut.filterDurationsByOrderType)(e, t)
                }
            }
            var mt = s(27886);
            const vt = i.lazy(async () => ({
                    default: (await Promise.all([s.e(3567), s.e(6112)]).then(s.bind(s, 15136))).LeverageDialog
                })),
                gt = (0, mt.withDialogLazyLoad)(vt);
            var ft = s(27950),
                _t = s(12057);

            function bt(e) {
                const {
                    leverage: t,
                    onClick: s,
                    onControlFocused: r,
                    blocked: o,
                    forceDisabled: a = !1,
                    onBlockedClick: c
                } = e, d = void 0 === t;
                let p = (0, n.t)("{value} leverage", {
                    replace: {
                        value: String(t)
                    }
                });
                return d && (p = (0, n.t)("No leverage")), o && (p = (0, n.t)("Select leverage")), i.createElement("div", {
                    className: _t.container,
                    onClick: function() {
                        if (o) return r.fire(), void c()
                    }
                }, i.createElement(ft.EditButton, {
                    disabled: d || a || o,
                    value: p,
                    startSlot: d || o ? void 0 : "x",
                    onClick: function() {
                        s(), r.fire()
                    },
                    className: l()(_t.leverageButton, a && _t.disabledLeverageButton)
                }))
            }

            function yt(e) {
                const {
                    model: t
                } = e, s = (0, f.useObservable)(t.leverageInfo$, t.leverageInfo()), r = (0, f.useObservable)(t.blocked$, t.getBlocked()), o = t.leveragePreviewResult(), [n, a] = (0, i.useState)(!1), [l, c] = (0, i.useState)(null == s ? void 0 : s.leverage);
                return (0, i.useEffect)(() => {
                    c(null == s ? void 0 : s.leverage)
                }, [s]), i.createElement(i.Fragment, null, i.createElement(bt, {
                    onClick: d,
                    leverage: l,
                    forceDisabled: n,
                    blocked: r,
                    onControlFocused: t.onControlFocused,
                    onBlockedClick: t.onBlockedClick
                }), null !== s && n && void 0 !== l && i.createElement(gt, {
                    symbol: t.symbol,
                    displaySymbol: t.displaySymbol,
                    leverage: l,
                    brokerName: t.brokerName,
                    orderType: t.orderType,
                    side: t.side,
                    isOpen: n,
                    onClose: d,
                    onLeverageSet: t.setLeverage,
                    onLeveragePreview: t.previewLeverage,
                    title: s.title,
                    min: s.min,
                    max: s.max,
                    step: s.step,
                    customFields: t.customFields,
                    infos: null == o ? void 0 : o.infos,
                    warnings: null == o ? void 0 : o.warnings,
                    errors: null == o ? void 0 : o.errors,
                    onSetLeverageValueInOrderWidget: function(e) {
                        c(e)
                    }
                }));

                function d() {
                    n || t.getLeverageInfo({
                        symbol: t.symbol,
                        orderType: t.orderType,
                        side: t.side,
                        customFields: t.customFields
                    }), a(e => !e)
                }
            }
            var Ct = s(20632);
            class kt extends i.PureComponent {
                constructor(e) {
                    super(e), this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this.context.resizerWidth && this.context.resizerWidth.subscribe(this._callback)
                }
                componentWillUnmount() {
                    this.context.resizerWidth && this.context.resizerWidth.unsubscribe(this._callback)
                }
                render() {
                    const e = {
                            width: this.props.progress + "%"
                        },
                        t = a(Ct.progress, 100 === this.props.progress && Ct.fullFilled, this.props.usedMargin > this.props.availableMargin && Ct.marginOverflow);
                    return i.createElement("div", {
                        className: a(Ct.progressBarContainer, this.props.wait && Ct.wait)
                    }, i.createElement("div", {
                        className: Ct.marginsContainer
                    }, i.createElement("div", {
                        className: Ct.usedMargin
                    }, i.createElement("div", null, (0, n.t)("Margin used")), i.createElement("span", null, (0, We.formatInfoValue)(this.props.usedMargin))), i.createElement("div", {
                        className: Ct.availableMargin
                    }, i.createElement("div", null, (0, n.t)("Margin available")), i.createElement("span", null, (0, We.formatInfoValue)(this.props.availableMargin)))), i.createElement("div", {
                        className: Ct.progressBar
                    }, i.createElement("div", {
                        className: Ct.track
                    }, i.createElement("div", {
                        className: t,
                        style: e
                    }))))
                }
            }
            kt.contextType = b.Context;
            var wt = s(63680);

            function Et(e) {
                const t = e.hasMarginMeter ? i.createElement(kt, {
                    usedMargin: e.usedMargin,
                    availableMargin: e.availableMargin,
                    progress: e.marginRatio,
                    wait: e.status === b.OrderPanelStatus.Wait
                }) : void 0;
                return i.createElement("div", {
                    className: wt.orderInfo
                }, i.createElement("div", {
                    className: wt.title
                }, e.title), i.createElement("div", {
                    className: wt.contentWrapper
                }, t, i.createElement(H.InfoTable, {
                    rows: e.infoTableData.rows,
                    header: e.infoTableData.header,
                    disabled: e.status === b.OrderPanelStatus.Wait,
                    rightAlignedValues: !0
                })))
            }
            class St extends i.PureComponent {
                constructor(e) {
                    super(e), this._callback = () => this.forceUpdate()
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model)
                }
                componentWillUnmount() {
                    this._unsubscribeFromModel(this.props.model)
                }
                render() {
                    const e = this.props.model,
                        t = e.usedMargin().value(),
                        s = e.availableMargin().value();
                    return i.createElement(Et, {
                        title: e.title(),
                        hasMarginMeter: e.hasMarginMeter(),
                        usedMargin: t,
                        availableMargin: s,
                        marginRatio: (0, We.calculatedMarginRatio)(t, s),
                        infoTableData: e.infoTableData().value(),
                        status: this.props.status
                    })
                }
                _subscribeToModel(e) {
                    e.availableMargin().subscribe(this._callback), e.usedMargin().subscribe(this._callback), e.infoTableData().subscribe(this._callback)
                }
                _unsubscribeFromModel(e) {
                    e.availableMargin().unsubscribe(this._callback), e.usedMargin().unsubscribe(this._callback), e.infoTableData().unsubscribe(this._callback)
                }
            }
            var Pt = s(2054),
                Dt = s(51049),
                Mt = s(20337);

            function Nt(e) {
                const {
                    imageBlack: t,
                    image: s,
                    controls: r,
                    text: o,
                    title: n
                } = e, a = (0, fe.useWatchedValueReadonly)({
                    watchedValue: Pt.watchedTheme
                });
                return i.createElement("div", {
                    className: Mt.messageBlock
                }, i.createElement("div", {
                    className: Mt.image,
                    dangerouslySetInnerHTML: {
                        __html: void 0 !== t && a === Dt.StdTheme.Dark ? t : s
                    }
                }), i.createElement("div", {
                    className: Mt.title
                }, n), i.createElement("div", {
                    className: Mt.text,
                    dangerouslySetInnerHTML: {
                        __html: o || ""
                    }
                }), r && i.createElement("div", {
                    className: Mt.controls
                }, r))
            }
            var It = s(2683),
                Bt = s(40176),
                Tt = s(81263),
                xt = s(97099),
                Ot = s(64773),
                Ft = s(48157);
            const Ht = (0, m.getLogger)("Trading.OrderPanel"),
                Rt = (0, n.t)("Non tradable symbol"),
                Lt = (0, n.t)("Log In"),
                Vt = (0, n.t)("Connect to broker"),
                zt = (0, n.t)("Log into your TradingView account to trade"),
                Wt = (0, n.t)("Log into your broker/exchange account to trade"),
                At = (0, n.t)("Sign up"),
                Ut = (0, n.t)("Connect");
            class Kt extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._orderWidgetBlock = null, this._orderTicketBlock = null, this._button = null, this._resizeHandler = null, this._focusBlock = () => {
                        null !== this._orderWidgetBlock && this._orderWidgetBlock.focus()
                    }, this._onLayoutResizeHandleMousedown = e => {
                        if (e.defaultPrevented || !e.cancelable) return;
                        e.preventDefault();
                        const t = Math.max(this._orderTicketBlock ? this._orderTicketBlock.clientHeight : 0, 0);
                        let s;
                        s = "touches" in e ? e.touches[0].clientY : e.clientY;
                        const r = e => {
                                let r;
                                e.preventDefault(), r = "touches" in e ? e.touches[0].clientY : e.clientY;
                                let i = t + (r - s);
                                i < 445 && (i = 445), this._setOrderTicketHeight(i)
                            },
                            i = () => {
                                const {
                                    orderTicketHeight: e
                                } = this.state;
                                document.removeEventListener("mousemove", r), document.removeEventListener("touchmove", r), document.removeEventListener("mouseup", i), document.removeEventListener("touchend", i), void 0 !== e && 0 !== e && (0, It.isInteger)(e) && u.setValue(v.settingsKeys.PANEL_HEIGHT, e)
                            };
                        document.addEventListener("mousemove", r), document.addEventListener("touchmove", r, {
                            passive: !1
                        }), document.addEventListener("mouseup", i), document.addEventListener("touchend", i, {
                            passive: !1
                        })
                    }, this._setOrderWidgetRef = e => {
                        this._orderWidgetBlock = e
                    }, this._setOrderTicketRef = e => {
                        this._orderTicketBlock = e
                    }, this._setButtonRef = e => {
                        this._button = e
                    }, this._setResizeHandlerRef = e => {
                        this._resizeHandler = e
                    }, this._forceUpdateAndReCalculateBounds = () => {
                        this.forceUpdate(() => this.props.popupController && this.props.popupController.recalculateBounds())
                    }, this._onSelectTab = e => {
                        this.props.model.orderType.setValue(e)
                    }, this._onStatusChange = e => {
                        var t;
                        e === b.OrderPanelStatus.Wait && (null === (t = this._orderWidgetBlock) || void 0 === t ? void 0 : t.contains(document.activeElement)) && this._blur(), this._callback()
                    }, this._onKeyDown = e => {
                        const t = (0, p.hashFromEvent)(e);
                        if (!(13 !== t && t !== p.hashShiftPlusEnter || this.props.model.disabled.value() || null === this._button)) {
                            if (c.CheckMobile.any()) return this._blur();
                            this._button.focus(), e.defaultPrevented || this._button.click()
                        }
                    }, this._blur = () => {
                        document.activeElement instanceof HTMLElement ? document.activeElement.blur() : Ht.logWarn("Failed to deselect: active element is not HTMLElement")
                    }, this._handleClickSignIn = () => {
                        showSignModal({
                            source: "Trading panel",
                            sourceMeta: "Chart"
                        })
                    }, this._handleClickSignUp = () => {
                        showSignModal({
                            mode: "signup",
                            source: "Trading panel",
                            sourceMeta: "Chart"
                        })
                    }, this._selectBroker = () => {
                        this.props.model.noBroker && this.props.model.selectBroker()
                    }, this._callback = () => {
                        this.forceUpdate()
                    };
                    const s = this._isOrderInfoShown() ? parseInt(u.getValue(v.settingsKeys.PANEL_HEIGHT, "")) : NaN;
                    this.state = {
                        orderTicketHeight: isNaN(s) ? void 0 : s,
                        orderInfoAndSeparatorHeight: void 0
                    }
                }
                componentDidMount() {
                    this._subscribeToModel(this.props.model), this.props.settings.subscribe(this._forceUpdateAndReCalculateBounds), null !== this._resizeHandler && (this._resizeHandler.addEventListener("mousedown", this._onLayoutResizeHandleMousedown, {
                        passive: !1
                    }), this._resizeHandler.addEventListener("touchstart", this._onLayoutResizeHandleMousedown, {
                        passive: !1
                    }))
                }
                componentDidUpdate() {
                    var e;
                    const {
                        orderTicketHeight: t,
                        orderInfoAndSeparatorHeight: s
                    } = this.state, r = null === (e = this._orderWidgetBlock) || void 0 === e ? void 0 : e.clientHeight;
                    if (void 0 !== r && void 0 !== t && t !== r && this._isOrderPreviewShown() && (this._setOrderInfoAndSeparatorHeight(r - t), u.setValue(v.settingsKeys.PANEL_HEIGHT, r), this._setOrderTicketHeight(r)), void 0 !== r && void 0 !== t && t === r && this._isOrderInfoShown() && void 0 !== s) {
                        const e = r - s;
                        this._setOrderTicketHeight(e), u.setValue(v.settingsKeys.PANEL_HEIGHT, e)
                    }
                }
                componentWillUnmount() {
                    var e;
                    const {
                        orderTicketHeight: t,
                        orderInfoAndSeparatorHeight: s
                    } = this.state, r = null === (e = this._orderWidgetBlock) || void 0 === e ? void 0 : e.clientHeight;
                    void 0 !== r && void 0 !== t && t === r && void 0 !== s && u.setValue(v.settingsKeys.PANEL_HEIGHT, r - s), this._unsubscribeFromModel(this.props.model), this.props.settings.unsubscribe(this._forceUpdateAndReCalculateBounds), null !== this._resizeHandler && (this._resizeHandler.removeEventListener("mousedown", this._onLayoutResizeHandleMousedown), this._resizeHandler.removeEventListener("touchstart", this._onLayoutResizeHandleMousedown))
                }
                render() {
                    const {
                        model: e,
                        settings: t,
                        trackEvent: s
                    } = this.props, {
                        orderTicketHeight: r
                    } = this.state, o = this.context.mode, n = e.status.value(), l = n === b.OrderPanelStatus.Wait || c.CheckMobile.any() ? void 0 : this.props.focus, p = this._isOrderPriceSupported(e), u = this._isBracketsSupported(e) || this._isCryptoBracketsSupported(e), h = this._isDurationSupported(e), m = this._isLeverageSupported(e), v = p || e.supportModifyQuantity || m, f = p || e.supportModifyQuantity || m || u, _ = {
                        value: t.value(),
                        setValue: t.setValue.bind(t)
                    }, y = e.limitPriceModel && e.limitPriceModel.isRelativePriceControlHidden || e.stopPriceModel && e.stopPriceModel.isRelativePriceControlHidden, C = {};
                    (e.needSignIn || e.noBroker || e.notTradableText) && (C.flexGrow = 1), o === b.OrderEditorDisplayMode.Panel && null !== e.orderInfoModel && void 0 !== r && 0 !== r && (C.height = r);
                    const k = i.createElement(i.Fragment, null, e.sideModel && i.createElement("div", {
                        className: Ft.side
                    }, i.createElement(O, {
                        model: e.sideModel,
                        disabled: e.existingOrder
                    })), e.limitPriceModel && e.stopPriceModel && i.createElement(X, {
                        activeTab: e.orderType.value(),
                        disabled: e.existingOrder,
                        supportMarketOrders: e.supportMarketOrders,
                        supportLimitOrders: e.supportLimitOrders,
                        supportStopOrders: e.supportStopOrders,
                        supportStopLimitOrders: e.supportStopLimitOrders,
                        onSelect: this._onSelectTab
                    }), e.limitPriceModel && e.stopPriceModel && e.quantityModel && i.createElement("div", {
                        className: a(Ft.centerBlock)
                    }, p && i.createElement(ct, {
                        model: e,
                        trackEvent: s,
                        focus: l
                    }), e.supportModifyQuantity && i.createElement("div", {
                        className: Ft.quantityWrapper
                    }, e.supportCryptoExchangeOrderTicket() ? i.createElement(Ee, {
                        model: e.quantityModel,
                        focus: l
                    }) : i.createElement(me, {
                        model: e.quantityModel,
                        symbolHasLotSize: e.symbolHasLotSize,
                        trackEvent: s,
                        focus: l
                    })), u && i.createElement("div", {
                        className: Ft["brackets-wrapper"]
                    }, v && i.createElement("div", {
                        className: Ft.separator
                    }), i.createElement("div", {
                        className: Ft.brackets
                    }, i.createElement(J.BracketControlGroup, {
                        model: e,
                        focus: l
                    }))), h && i.createElement("div", {
                        className: Ft.duration
                    }, i.createElement(ht, {
                        onClose: this._focusBlock,
                        model: (0, d.ensureDefined)(e.durationModel)
                    })), Array.isArray(e.customFieldModels.value()) && e.customFieldModels.value().length > 0 && i.createElement("div", {
                        className: Ft.customFieldsWrapper
                    }, f && i.createElement("div", {
                        className: Ft.separator
                    }), i.createElement(Bt.CustomFields, {
                        customFieldModels: e.customFieldModels.value(),
                        status: e.status,
                        onClose: this._focusBlock,
                        alwaysShowAttachedErrors: e.isEmptyRequiredCustomFieldsHighlighted
                    })), m && i.createElement("div", {
                        className: Ft.leverage
                    }, i.createElement(yt, {
                        model: (0, d.ensureDefined)(e.leverageModel)
                    }))), void 0 !== e.buttonModel && i.createElement("div", {
                        className: Ft.doneButton
                    }, i.createElement(dt.PlaceAndModifyButtonContainer, {
                        model: e,
                        reference: this._setButtonRef,
                        buttonModel: e.buttonModel
                    })), !1);
                    return i.createElement(de.SettingsContext.Provider, {
                        value: _
                    }, i.createElement("div", {
                        className: a(Ft.orderWidget),
                        onKeyDown: this._onKeyDown,
                        tabIndex: -1,
                        ref: this._setOrderWidgetRef
                    }, i.createElement("div", {
                        ref: this._setOrderTicketRef,
                        className: Ft.orderTicket,
                        style: C
                    }, e.headerModel && i.createElement(g.HeaderContainer, {
                        model: e.headerModel,
                        mode: o,
                        className: Ft.header,
                        showQuantityInsteadOfAmount: e.showQuantityInsteadOfAmount,
                        currency: e.currency,
                        supportBrackets: e.supportBrackets,
                        supportOrderPreview: e.supportPlaceOrderPreview || e.supportModifyOrderPreview,
                        showRiskControls: e.showRiskControls,
                        hideRelativePriceSettingsItem: y
                    }), !1, !1, e.notTradableText && this._renderNotTradableBlock(e), this._isOrderPreviewShown() ? i.createElement(A, {
                        model: (0, d.ensureNotNull)(e.orderPreviewModel),
                        side: e.side(),
                        loading: e.loading
                    }) : k), this._isOrderInfoShown() && i.createElement("div", {
                        className: Ft.orderInfoAndSeparator
                    }, i.createElement("div", {
                        className: Ft.separator
                    }), i.createElement("div", {
                        className: Ft.resizeHandler,
                        ref: this._setResizeHandlerRef
                    }), i.createElement(St, {
                        "data-name": "order-info",
                        model: (0, d.ensureNotNull)(e.orderInfoModel),
                        status: n
                    }))))
                }
                _setOrderTicketHeight(e) {
                    null !== this._orderTicketBlock && this.setState({
                        orderTicketHeight: e
                    })
                }
                _setOrderInfoAndSeparatorHeight(e) {
                    this.setState({
                        orderInfoAndSeparatorHeight: e
                    })
                }
                _subscribeToModel(e) {
                    var t;
                    e.orderType.subscribe(this._forceUpdateAndReCalculateBounds), e.status.subscribe(this._onStatusChange), e.customFieldModels.subscribe(this._callback), e.isNoQuotes.subscribe(this._callback), null === (t = e.orderInfoModel) || void 0 === t || t.infoTableData().subscribe(this._callback)
                }
                _unsubscribeFromModel(e) {
                    var t;
                    e.orderType.unsubscribe(this._forceUpdateAndReCalculateBounds), e.status.unsubscribe(this._onStatusChange), e.customFieldModels.unsubscribe(this._callback), e.isNoQuotes.unsubscribe(this._callback), null === (t = e.orderInfoModel) || void 0 === t || t.infoTableData().unsubscribe(this._callback)
                }
                _isOrderPriceSupported(e) {
                    return Boolean(2 !== e.orderType.value() && (!e.existingOrder || e.existingOrder && e.supportModifyOrderPrice))
                }
                _isBracketsSupported(e) {
                    const t = 2 !== this.props.model.orderType.value() || e.supportMarketBrackets;
                    return Boolean(e.supportBrackets && t)
                }
                _isDurationSupported(e) {
                    return Boolean(e.durationModel && (!e.existingOrder || e.existingOrder && e.supportModifyDuration) && e.durationModel.isDurationsAvailable())
                }
                _isCryptoBracketsSupported(e) {
                    return Boolean(e.supportCryptoBrackets)
                }
                _isLeverageSupported(e) {
                    return Boolean(e.supportLeverage)
                }
                _isOrderPreviewShown() {
                    const {
                        model: e
                    } = this.props;
                    return e.status.value() === b.OrderPanelStatus.Preview && null !== e.orderPreviewModel
                }
                _isOrderInfoShown() {
                    const {
                        model: e
                    } = this.props, t = e.status.value(), s = this._getCountOrderInfoTableRows();
                    return this.context.mode === b.OrderEditorDisplayMode.Panel && s > 0 && t !== b.OrderPanelStatus.Preview && h.enabled("order_info")
                }
                _getCountOrderInfoTableRows() {
                    var e, t;
                    return (null === (t = null === (e = this.props.model.orderInfoModel) || void 0 === e ? void 0 : e.infoTableData().value().rows) || void 0 === t ? void 0 : t.length) || 0
                }
                _renderSignInBlock() {
                    return i.createElement(Nt, {
                        image: Ot,
                        title: Lt,
                        text: zt,
                        controls: i.createElement(i.Fragment, null, i.createElement("div", {
                            className: Ft.button
                        }, i.createElement(F.Button, {
                            onClick: this._handleClickSignIn,
                            appearance: "stroke"
                        }, Lt)), i.createElement("div", {
                            className: Ft.button
                        }, i.createElement(F.Button, {
                            onClick: this._handleClickSignUp,
                            appearance: "stroke"
                        }, At)))
                    })
                }
                _renderNoBrokerBlock() {
                    return i.createElement(Nt, {
                        image: Ot,
                        title: Vt,
                        text: Wt,
                        controls: i.createElement(F.Button, {
                            onClick: this._selectBroker,
                            appearance: "stroke"
                        }, Ut)
                    })
                }
                _renderNotTradableBlock(e) {
                    const t = e.tradableSolution ? i.createElement(F.Button, {
                        onClick: e.tradableSolution.apply
                    }, e.tradableSolution.title) : void 0;
                    return i.createElement(Nt, {
                        image: Tt,
                        imageBlack: xt,
                        title: Rt,
                        text: e.notTradableText,
                        controls: t
                    })
                }
            }
            Kt.contextType = b.Context;
            var Zt = s(57671);
            class qt extends i.PureComponent {
                constructor(e) {
                    super(e), this._onKeyDown = e => {
                        27 === e.keyCode && this.props.onCancel && this.props.onCancel()
                    }
                }
                render() {
                    return i.createElement("div", {
                        "data-name": "order-panel",
                        className: Zt.orderPanel,
                        onKeyDown: this._onKeyDown
                    }, i.createElement(Kt, {
                        model: this.props.model,
                        settings: this.props.settings,
                        key: this.props.model.id,
                        trackEvent: this.props.trackEvent,
                        focus: this.props.focus
                    }))
                }
            }
            var Gt = s(30894),
                Qt = s(40766),
                jt = s(30052),
                Yt = s(10549),
                Xt = s(96038),
                Jt = s(74837),
                $t = s(93274);
            const es = i.memo(e => {
                const {
                    model: t,
                    isOpened: s,
                    settings: r,
                    onClose: o,
                    trackEvent: n,
                    focus: a,
                    onOpen: l
                } = e;
                return (0, Jt.useCommonDialogHandlers)({
                    isOpened: s,
                    onOpen: l,
                    onClose: o
                }), i.createElement(jt.MatchMedia, {
                    rule: Xt.DialogBreakpoints.TabletSmall
                }, e => i.createElement(Qt.PopupDialog, {
                    className: $t.dialog,
                    isOpened: s,
                    onKeyDown: p,
                    fullscreen: e,
                    rounded: !e,
                    "data-name": "order-dialog-popup"
                }, i.createElement(Gt.Body, {
                    className: $t.dialogBody
                }, t && r && i.createElement(Yt.PopupContext.Consumer, null, c))));

                function c(e) {
                    return i.createElement(Kt, {
                        settings: (0, d.ensureDefined)(r),
                        model: (0, d.ensureNotNull)(t),
                        key: (0, d.ensureNotNull)(t).id,
                        trackEvent: n,
                        focus: a,
                        popupController: e
                    })
                }

                function p(e) {
                    27 === e.keyCode && o && o()
                }
            });
            let ts = null,
                ss = !1;

            function rs(e) {
                const {
                    viewModel: t,
                    settings: s,
                    onClose: r,
                    onOpen: i,
                    focus: n,
                    trackEvent: a
                } = e;
                is();
                const l = {
                    model: t,
                    settings: s,
                    isOpened: !0,
                    onOpen: i,
                    onClose: () => {
                        is(r), t.onDoneButtonClicked.reject(), void 0 !== l.onClose && (t.headerModel.pinButtonClicked().unsubscribe(null, l.onClose), t.headerModel.closeButtonClicked().unsubscribe(null, l.onClose)), ts && (o.unmountComponentAtNode(ts), ss = !1)
                    },
                    trackEvent: a,
                    focus: n || ls(t.orderType.value())
                };
                os(l), ss = !0, void 0 !== l.onClose && (t.headerModel.pinButtonClicked().subscribe(null, l.onClose), t.headerModel.closeButtonClicked().subscribe(null, l.onClose))
            }

            function is(e) {
                ss && (os({
                    model: null,
                    isOpened: !1
                }), null == e || e())
            }

            function os(e) {
                null === ts && (ts = document.createElement("div"), document.body.appendChild(ts));
                const t = i.createElement(b.Context.Provider, {
                    value: {
                        mode: e.model && e.model.mode.value() || b.OrderEditorDisplayMode.Panel,
                        supportTrailingStop: Boolean(e.model && e.model.supportTrailingStop)
                    }
                }, i.createElement(es, { ...e
                }));
                o.render(t, ts)
            }

            function ns(e, t, s, r, n, a) {
                as(s);
                const l = {
                    model: e,
                    settings: t,
                    onClose: () => {
                        as(s), l.model.headerModel && (l.model.headerModel.pinButtonClicked().unsubscribe(null, l.onClose), l.model.headerModel.closeButtonClicked().unsubscribe(null, l.onClose))
                    },
                    onCancel: () => {
                        l.model.headerModel && l.model.headerModel.cancel()
                    },
                    trackEvent: a,
                    focus: n || ls(e.orderType.value())
                };
                l.model.headerModel && (l.model.headerModel.pinButtonClicked().subscribe(null, l.onClose), l.model.headerModel.closeButtonClicked().subscribe(null, l.onClose)),
                    function(e, t, s) {
                        const r = i.createElement(b.Context.Provider, {
                            value: {
                                resizerWidth: s || null,
                                mode: e.model.mode.value(),
                                supportTrailingStop: Boolean(e.model.supportTrailingStop)
                            }
                        }, i.createElement(qt, { ...e
                        }));
                        o.render(r, t)
                    }(l, s, r)
            }

            function as(e) {
                o.unmountComponentAtNode(e)
            }

            function ls(e) {
                let t;
                switch (e) {
                    case 2:
                        t = 5;
                        break;
                    case 1:
                    case 4:
                        t = 1;
                        break;
                    case 3:
                        t = 2;
                        break;
                    default:
                        t = void 0
                }
                return t
            }
        },
        27886: (e, t, s) => {
            "use strict";
            s.d(t, {
                withDialogLazyLoad: () => o
            });
            var r = s(59496),
                i = s(52130);

            function o(e) {
                return t => {
                    const s = (0, i.useIsMounted)();
                    return ((e => {
                        const [t, s] = (0, r.useState)(!1);
                        return (0, r.useEffect)(() => {
                            !t && e && s(!0)
                        }, [e]), t
                    })(t.isOpen) || t.isOpen) && s ? r.createElement(r.Suspense, {
                        fallback: null
                    }, r.createElement(e, { ...t
                    })) : null
                }
            }
        },
        27950: (e, t, s) => {
            "use strict";
            s.d(t, {
                EditButton: () => l
            });
            var r = s(59496),
                i = s(97754),
                o = s(72571),
                n = s(17354),
                a = s(55914);

            function l(e) {
                const {
                    value: t,
                    onClick: s,
                    className: l,
                    startSlot: c,
                    disabled: d = !1
                } = e;
                return r.createElement("div", {
                    className: i(a.wrap, d && a.disabled, l),
                    onClick: s,
                    "data-name": "edit-button"
                }, r.createElement("div", {
                    className: i(a.text, "apply-overflow-tooltip")
                }, void 0 !== c && c, r.createElement("span", null, t)), r.createElement(o.Icon, {
                    icon: n,
                    className: a.icon
                }))
            }
        },
        37294: (e, t, s) => {
            "use strict";
            s.d(t, {
                Calendar: () => v
            });
            var r = s(59496),
                i = s(97754),
                o = s(25177),
                n = s(72571),
                a = s(8550),
                l = s(52647),
                c = s(12539);
            class d extends r.PureComponent {
                constructor() {
                    super(...arguments), this._dateFormatter = new l.DateFormatter, this._onClick = () => {
                        this.props.onClick && !this.props.isDisabled && this.props.onClick(new Date(this.props.day))
                    }
                }
                render() {
                    const e = i(c.day, {
                        [c.selected]: this.props.isSelected,
                        [c.disabled]: this.props.isDisabled,
                        [c.withinSelectedRange]: this._withinSelectedRange(),
                        [c.isOnHighlightedEdge]: this._isOnHighlightedEdge(),
                        [c.currentDay]: this._isCurrentDay()
                    });
                    return r.createElement("span", {
                        className: e,
                        onClick: this._onClick,
                        "data-day": this._dateFormatter.formatLocal(this.props.day)
                    }, this.props.day.getDate())
                }
                _isOnHighlightedEdge() {
                    const {
                        day: e,
                        highlightedFrom: t,
                        highlightedTo: s
                    } = this.props;
                    return !(!t || !s) && ((0, a.isSameDay)(e, t) || (0, a.isSameDay)(e, s))
                }
                _withinSelectedRange() {
                    const {
                        day: e,
                        highlightedFrom: t,
                        highlightedTo: s
                    } = this.props;
                    return !(!t || !s) && this._isBetweenByDay(t, e, s)
                }
                _isCurrentDay() {
                    return (0, a.isSameDay)(new Date, this.props.day)
                }
                _isBetweenByDay(e, t, s) {
                    const r = (0, a.resetToDayStart)(e),
                        i = (0, a.resetToDayStart)(t),
                        o = (0, a.resetToDayStart)(s);
                    return r < i && i < o
                }
            }
            const p = [(0, o.t)("Mo", {
                context: "day_of_week"
            }), (0, o.t)("Tu", {
                context: "day_of_week"
            }), (0, o.t)("We", {
                context: "day_of_week"
            }), (0, o.t)("Th", {
                context: "day_of_week"
            }), (0, o.t)("Fr", {
                context: "day_of_week"
            }), (0, o.t)("Sa", {
                context: "day_of_week"
            }), (0, o.t)("Su", {
                context: "day_of_week"
            })];
            class u extends r.PureComponent {
                constructor() {
                    super(...arguments), this._renderWeekdays = () => p.map(e => r.createElement("span", {
                        key: e
                    }, e))
                }
                render() {
                    return r.createElement("div", {
                        className: c.month
                    }, r.createElement("div", {
                        className: c.weekdays
                    }, this._renderWeekdays()), r.createElement("div", {
                        className: c.weeks
                    }, this._renderWeeks()))
                }
                _renderWeeks() {
                    const e = [];
                    let t = (0, a.resetToWeekStart)((0, a.resetToMonthStart)(this.props.viewDate), !0);
                    for (let s = 0; s < 6; s++) e.push(this._renderWeek(t)), t = new Date((0, a.addOneWeek)(t));
                    return e
                }
                _renderWeek(e) {
                    const t = [];
                    for (let s = 0; s < 7; s++) {
                        const i = new Date(e);
                        i.setDate(i.getDate() + s), (0, a.isSameMonth)(i, this.props.viewDate) && t.push(r.createElement(d, {
                            key: s,
                            day: i,
                            isDisabled: this._isDayDisabled(i),
                            isSelected: (0, a.isSameDay)(i, this.props.selectedDate),
                            onClick: this.props.onClickDay,
                            highlightedFrom: this.props.highlightedFrom,
                            highlightedTo: this.props.highlightedTo
                        }))
                    }
                    if (0 === t.length) return null;
                    const s = (0, a.getNumberOfWeek)(e);
                    return r.createElement("div", {
                        className: c.week,
                        key: s
                    }, t)
                }
                _isDayDisabled(e) {
                    if (!(0, a.isInRange)(e, this.props.minDate, this.props.maxDate)) return !0;
                    const t = [6, 0].includes(e.getDay());
                    return !!this.props.disableWeekends && t
                }
            }
            var h = s(35555);
            const m = [(0, o.t)("January"), (0, o.t)("February"), (0, o.t)("March"), (0, o.t)("April"), (0, o.t)("May"), (0, o.t)("June"), (0, o.t)("July"), (0, o.t)("August"), (0, o.t)("September"), (0, o.t)("October"), (0, o.t)("November"), (0, o.t)("December")];
            class v extends r.PureComponent {
                constructor(e) {
                    super(e), this._prevMonth = () => {
                        const e = new Date(this.state.viewDate);
                        e.setMonth(e.getMonth() - 1), this.setState({
                            viewDate: e
                        }), this.props.onMonthSwitch && this.props.onMonthSwitch()
                    }, this._nextMonth = () => {
                        const e = new Date(this.state.viewDate);
                        e.setMonth(e.getMonth() + 1), this.setState({
                            viewDate: e
                        }), this.props.onMonthSwitch && this.props.onMonthSwitch()
                    }, this._onClickDay = e => {
                        this.setState({
                            viewDate: new Date(e)
                        }), this.props.onSelect && this.props.onSelect(new Date(e))
                    }, this.state = {
                        viewDate: e.selectedDate
                    }
                }
                render() {
                    return r.createElement("div", {
                        className: i(c.calendar, this.props.popupStyle && c.popupStyle, this.props.className),
                        tabIndex: -1
                    }, r.createElement("div", {
                        className: c.header
                    }, r.createElement(n.Icon, {
                        icon: h,
                        onClick: this._prevMonth,
                        className: i(c.switchBtn, c.prev)
                    }), r.createElement("div", {
                        className: c.title
                    }, `${m[this.state.viewDate.getMonth()]} ${this.state.viewDate.getFullYear()}`), r.createElement(n.Icon, {
                        icon: h,
                        onClick: this._nextMonth,
                        className: i(c.switchBtn, c.next)
                    })), r.createElement(u, {
                        viewDate: this.state.viewDate,
                        selectedDate: this.props.selectedDate,
                        maxDate: this.props.maxDate,
                        minDate: this.props.minDate,
                        onClickDay: this._onClickDay,
                        disableWeekends: this.props.disableWeekends,
                        highlightedFrom: this.props.highlightedFrom,
                        highlightedTo: this.props.highlightedTo
                    }))
                }
            }
            v.defaultProps = {
                popupStyle: !0
            }
        },
        14793: (e, t, s) => {
            "use strict";
            s.d(t, {
                DatePicker: () => k
            });
            var r = s(25177),
                i = s(59496),
                o = s(97754),
                n = s(72535),
                a = s(52647),
                l = s(37294),
                c = s(88537),
                d = s(72571),
                p = s(81476),
                u = s(61428),
                h = s(2691),
                m = s(23235),
                v = s(8361),
                g = s(554);
            class f extends i.PureComponent {
                constructor(e) {
                    super(e), this._input = null, this._inputContainer = null, this._handleFocus = () => {
                        this.props.showOnFocus && this.props.onShowPicker()
                    }, this._handleInputRef = e => {
                        this._input = e, this.props.inputReference && this.props.inputReference(this._input)
                    }, this._handleContainerRef = e => {
                        this._inputContainer = e
                    }, this._onShowPicker = e => {
                        if (e && this._inputContainer) {
                            const t = e.getBoundingClientRect(),
                                s = this._inputContainer.getBoundingClientRect();
                            t.width && t.width > window.innerWidth - s.left ? (e.style.right = "0", e.style.left = "auto") : (e.style.right = "auto", e.style.left = s.left + "px");
                            const r = window.innerHeight - s.bottom,
                                i = s.top;
                            if (r >= t.height) return void(e.style.top = s.bottom + "px");
                            e.style.top = "auto", e.style.bottom = i < t.height ? "0" : r + s.height + "px"
                        }
                    }, this._onChange = () => {
                        const e = (0, c.ensureNotNull)(this._input).value;
                        this.setState({
                            value: e
                        }), this.props.onType(e)
                    }, this._onKeyDown = e => {
                        this.props.onHidePicker()
                    }, this._onKeyPress = e => {
                        if (e.charCode) {
                            const t = String.fromCharCode(e.charCode);
                            this.props.inputRegex.test(t) || e.preventDefault()
                        }
                    }, this._onKeyUp = e => {
                        if (8 !== e.keyCode) {
                            const e = (0, c.ensureNotNull)(this._input).value,
                                t = this.props.fixValue(e);
                            t !== e && this.setState({
                                value: t
                            })
                        }
                    }, this.state = {
                        value: e.value
                    }
                }
                UNSAFE_componentWillReceiveProps(e) {
                    e.value !== this.props.value && this.setState({
                        value: e.value
                    })
                }
                render() {
                    const {
                        position: e = "fixed",
                        className: t,
                        size: s,
                        disabled: r,
                        readonly: n,
                        errors: a,
                        icon: l,
                        InputComponent: c = p.FormInput
                    } = this.props;
                    return i.createElement("div", {
                        className: g.pickerInput,
                        ref: this._handleContainerRef
                    }, i.createElement(c, {
                        value: this.state.value,
                        onBlur: this.props.onBlur,
                        onKeyDown: this._onKeyDown,
                        onKeyPress: this._onKeyPress,
                        onKeyUp: this._onKeyUp,
                        onChange: this._onChange,
                        onFocus: this._handleFocus,
                        onClick: this.props.onShowPicker,
                        reference: this._handleInputRef,
                        className: t,
                        size: s,
                        disabled: r,
                        errors: a,
                        messagesPosition: u.MessagesPosition.Attached,
                        hasErrors: this.props.showErrorMessages && a && a.length > 0,
                        name: this.props.name,
                        readonly: n,
                        endSlot: a && a.length ? void 0 : i.createElement(h.EndSlot, null, i.createElement(d.Icon, {
                            icon: l,
                            className: o(g.icon, r && g.disabled),
                            onClick: r || n ? void 0 : this.props.onShowPicker
                        })),
                        "data-name": this.props.name
                    }), this.props.showPicker && !n ? i.createElement(v.Portal, {
                        top: "0",
                        left: "0",
                        right: "0",
                        bottom: "0",
                        pointerEvents: "none"
                    }, i.createElement(m.OutsideEvent, {
                        mouseDown: !0,
                        handler: this.props.onHidePicker
                    }, t => i.createElement("span", {
                        ref: t,
                        style: {
                            pointerEvents: "auto"
                        }
                    }, i.createElement("div", {
                        className: o(g.picker, g[e]),
                        key: "0",
                        ref: this._onShowPicker
                    }, this.props.children)))) : null)
                }
            }
            f.defaultProps = {
                showOnFocus: !0
            };
            class _ extends i.PureComponent {
                constructor(e) {
                    super(e), this._input = null, this._nativeInputRef = i.createRef(), this._handleInputRef = e => {
                        this._input = e, this.props.inputReference && this.props.inputReference(this._input)
                    }, this._onFocus = () => {
                        this.setState({
                            isFocused: !0
                        })
                    }, this._onBlur = () => {
                        this._nativeInputRef.current && (this._nativeInputRef.current.defaultValue = this.state.value), this.setState({
                            isFocused: !1
                        })
                    }, this._onChange = e => {
                        const {
                            value: t
                        } = e.target;
                        t && (this.setState({
                            value: t
                        }), this.props.onChange(t))
                    }, this.state = {
                        value: e.value,
                        isFocused: !1
                    }
                }
                componentDidMount() {
                    this._nativeInputRef.current && (this._nativeInputRef.current.defaultValue = this.props.value)
                }
                render() {
                    const {
                        className: e,
                        disabled: t,
                        errors: s,
                        InputComponent: r = p.FormInput
                    } = this.props, n = !this.props.readonly && !t, a = this.props.showErrorMessages && s && s.length > 0;
                    return i.createElement("div", {
                        className: g.pickerInput
                    }, i.createElement(r, {
                        value: this.state.value,
                        readonly: !0,
                        noReadonlyStyles: !0,
                        endSlot: s && s.length ? void 0 : i.createElement(h.EndSlot, null, i.createElement(d.Icon, {
                            icon: this.props.icon,
                            className: o(g.icon, t && g.disabled)
                        })),
                        className: e,
                        inputClassName: g.textInput,
                        size: this.props.size,
                        disabled: t,
                        hasErrors: a,
                        errors: s,
                        alwaysShowAttachedErrors: !0,
                        messagesPosition: u.MessagesPosition.Attached,
                        name: n ? void 0 : this.props.name,
                        reference: this._handleInputRef,
                        highlight: this.state.isFocused,
                        intent: !a && this.state.isFocused ? "primary" : void 0
                    }), n && i.createElement("input", {
                        ref: this._nativeInputRef,
                        type: this.props.type,
                        className: g.nativePicker,
                        onChange: this._onChange,
                        onInput: this._onChange,
                        min: this.props.min,
                        max: this.props.max,
                        name: this.props.name,
                        onFocus: this._onFocus,
                        onBlur: this._onBlur
                    }))
                }
            }
            var b = s(8550),
                y = s(34735),
                C = s(13873);
            class k extends i.PureComponent {
                constructor(e) {
                    super(e), this._pickerInputContainerRef = i.createRef(), this._dateFormatter = new a.DateFormatter, this._fixValue = e => (e = (e = e.substring(0, 10)).replace(/-+/g, "-"), (/^\d{4}$/.test(e) || /^\d{4}-\d{2}$/.test(e)) && (e += "-"), e), this._isValid = e => {
                        if (/^[0-9]{4}(-[0-9]{2}){2}/.test(e)) {
                            const t = new Date(e.concat("T00:00"));
                            return !(0, b.isInvalidDateObj)(t) && (!!this.props.noRangeValidation || (0, b.isInRange)(t, this.props.minDate, this.props.maxDate))
                        }
                        return !1
                    }, this._onBlur = e => {
                        var t;
                        if (!this.props.revertInvalidData || (null === (t = this._pickerInputContainerRef.current) || void 0 === t ? void 0 : t.contains(e.relatedTarget))) return;
                        const {
                            value: s
                        } = e.target;
                        if (!this._isValid(s)) {
                            const t = new Date(this.state.date);
                            this.setState({
                                pickerInputKey: e.timeStamp,
                                date: t,
                                isInvalid: !1
                            }), this.props.onPick(t)
                        }
                    }, this._onType = e => {
                        const t = this._isValid(e) ? new Date(e.concat("T00:00")) : null;
                        t ? this.setState({
                            date: t,
                            isInvalid: !1
                        }) : this.setState({
                            isInvalid: !0
                        }), this.props.onPick(t)
                    }, this._onSelect = e => {
                        this.setState({
                            date: e,
                            showCalendar: !1,
                            isInvalid: !1
                        }), this.props.onPick(e)
                    }, this._showCalendar = () => {
                        this.setState({
                            showCalendar: !0
                        })
                    }, this._hideCalendar = () => {
                        this.setState({
                            showCalendar: !1
                        })
                    }, this._getErrors = () => {
                        const e = this.props.errors ? [...this.props.errors] : [];
                        return this.state.isInvalid && e.push((0, r.t)("Please enter the right date format yyyy-mm-dd")), e
                    }, this.state = {
                        pickerInputKey: 0,
                        date: e.initial,
                        showCalendar: !1,
                        isInvalid: !this._isValid(this._dateFormatter.formatLocal(e.initial))
                    }
                }
                render() {
                    return n.mobiletouch ? i.createElement(_, {
                        value: this._dateFormatter.formatLocal(this.state.date),
                        type: "date",
                        onChange: this._onType,
                        icon: C,
                        disabled: this.props.disabled,
                        size: this.props.size,
                        min: this.props.minDate && this._dateFormatter.formatLocal(this.props.minDate),
                        max: this.props.maxDate && this._dateFormatter.formatLocal(this.props.maxDate),
                        errors: this._getErrors(),
                        showErrorMessages: this.props.showErrorMessages,
                        name: this.props.name,
                        readonly: this.props.readonly,
                        className: o(this._getFontSizeClassName(this.props.size), this.props.className),
                        inputReference: this.props.inputReference,
                        InputComponent: this.props.InputComponent
                    }) : i.createElement("div", {
                        ref: this._pickerInputContainerRef
                    }, i.createElement(f, {
                        key: this.state.pickerInputKey,
                        value: this._dateFormatter.formatLocal(this.state.date),
                        inputRegex: /[0-9.]/,
                        fixValue: this._fixValue,
                        onType: this._onType,
                        onBlur: this._onBlur,
                        onShowPicker: this._showCalendar,
                        onHidePicker: this._hideCalendar,
                        showPicker: this.state.showCalendar && this.props.withCalendar,
                        showOnFocus: this.props.showOnFocus,
                        icon: C,
                        disabled: this.props.disabled,
                        size: this.props.size,
                        errors: this._getErrors(),
                        showErrorMessages: this.props.showErrorMessages,
                        name: this.props.name,
                        readonly: this.props.readonly,
                        position: this.props.position,
                        className: o(this._getFontSizeClassName(this.props.size), this.props.className),
                        inputReference: this.props.inputReference,
                        InputComponent: this.props.InputComponent
                    }, i.createElement(l.Calendar, {
                        selectedDate: this.state.date,
                        maxDate: this.props.maxDate,
                        minDate: this.props.minDate,
                        onSelect: this._onSelect
                    })))
                }
                UNSAFE_componentWillReceiveProps(e) {
                    this.props.initial !== e.initial && this.setState({
                        date: e.initial
                    })
                }
                _getFontSizeClassName(e) {
                    return e ? "large" === e ? y.InputClasses.FontSizeLarge : y.InputClasses.FontSizeMedium : void 0
                }
            }
            k.defaultProps = {
                position: "fixed",
                withCalendar: !0
            }
        },
        50324: (e, t, s) => {
            "use strict";
            s.d(t, {
                DEFAULT_INPUT_DATE_THEME: () => h,
                DateInput: () => m
            });
            var r = s(59496),
                i = s(25177),
                o = s(72571),
                n = s(2691),
                a = s(81476),
                l = s(97754),
                c = s.n(l),
                d = s(93632);

            function p(e) {
                const {
                    className: t,
                    text: s
                } = e;
                return r.createElement("span", {
                    className: c()(d.tooltip, t)
                }, s)
            }
            var u = s(21279);
            const h = s(34020);

            function m(e) {
                const {
                    hasErrors: t,
                    onClick: s,
                    errors: l,
                    className: c,
                    theme: d = h,
                    ...m
                } = e;
                return r.createElement("div", {
                    className: d.container,
                    onClick: s
                }, r.createElement(a.FormInput, { ...m,
                    className: d.date,
                    hasErrors: t,
                    errors: [],
                    endSlot: !t && r.createElement(n.EndSlot, {
                        icon: !0,
                        interactive: !1
                    }, r.createElement(o.Icon, {
                        icon: u,
                        className: d.icon
                    }))
                }), t && r.createElement(p, {
                    text: (0, i.t)("Please enter the right date"),
                    className: d.tooltip
                }))
            }
        },
        8550: (e, t, s) => {
            "use strict";

            function r(e) {
                return ("0" + e).slice(-2)
            }

            function i(e) {
                const t = new Date(e);
                return t.setMilliseconds(0), t.setSeconds(0), t.setMinutes(0), t.setHours(0), t
            }

            function o(e) {
                const t = new Date(e);
                return t.setMilliseconds(999), t.setSeconds(59), t.setMinutes(59), t.setHours(23), t
            }

            function n(e, t = !1) {
                const s = i(e),
                    r = t ? function(e) {
                        if (e > 6) throw new Error("Invalid day is provided");
                        return 0 === e ? 6 : e - 1
                    }(s.getDay()) : s.getDay();
                return s.setDate(s.getDate() - r), s
            }

            function a(e) {
                const t = i(e);
                return t.setDate(1), t
            }

            function l(e, t) {
                return Number(i(e)) === Number(i(t))
            }

            function c(e, t) {
                return Number(a(e)) === Number(a(t))
            }

            function d(e) {
                const t = new Date(e.getFullYear(), 0, 1),
                    s = (Number(e) - Number(t)) / 864e5;
                return Math.ceil((s + t.getDay() + 1) / 7)
            }

            function p(e) {
                const t = new Date(e);
                return t.setDate(t.getDate() + 7), t
            }

            function u(e, t, s) {
                const r = !t || Number(i(t)) - Number(i(e)) <= 0;
                return (!s || Number(i(s)) - Number(i(e)) >= 0) && r
            }

            function h(e) {
                return Number.isNaN(Number(e))
            }

            function m(e) {
                return new Date(e).getTimezoneOffset() / 60
            }

            function v(e) {
                const t = new Date(e);
                return t.setHours(t.getHours() + m(t)), t
            }

            function g(e) {
                const t = new Date(e);
                return t.setHours(t.getHours() - m(t)), t
            }
            s.d(t, {
                twoDigitsFormat: () => r,
                resetToDayStart: () => i,
                resetToDayEnd: () => o,
                resetToWeekStart: () => n,
                resetToMonthStart: () => a,
                isSameDay: () => l,
                isSameMonth: () => c,
                getNumberOfWeek: () => d,
                addOneWeek: () => p,
                isInRange: () => u,
                isInvalidDateObj: () => h,
                subtractLocalTime: () => v,
                addLocalTime: () => g
            })
        },
        85938: (e, t, s) => {
            "use strict";
            s.d(t, {
                useForceUpdate: () => i
            });
            var r = s(59496);
            const i = () => {
                const [, e] = (0, r.useReducer)((e, t) => e + 1, 0);
                return e
            }
        },
        27871: (e, t, s) => {
            "use strict";
            s.d(t, {
                KeyCode: () => r,
                makeKeyboardListener: () => n
            });
            var r, i = s(59496);
            ! function(e) {
                e[e.Enter = 13] = "Enter", e[e.Space = 32] = "Space", e[e.Backspace = 8] = "Backspace", e[e.DownArrow = 40] = "DownArrow", e[e.UpArrow = 38] = "UpArrow", e[e.RightArrow = 39] = "RightArrow", e[e.LeftArrow = 37] = "LeftArrow", e[e.Escape = 27] = "Escape", e[e.Tab = 9] = "Tab"
            }(r || (r = {}));
            class o {
                constructor() {
                    this._handlers = new Map
                }
                registerHandlers(e) {
                    Object.keys(e).forEach(t => {
                        const s = parseInt(t);
                        let r = e[s];
                        if (Array.isArray(r) || (r = [r]), this._handlers.has(s)) {
                            const e = this._handlers.get(s);
                            e && r.forEach(t => e.add(t))
                        } else this._handlers.set(s, new Set(r))
                    })
                }
                unregisterHandlers(e) {
                    Object.keys(e).forEach(t => {
                        const s = parseInt(t);
                        let r = e[s];
                        if (Array.isArray(r) || (r = [r]), this._handlers.has(s)) {
                            const e = this._handlers.get(s);
                            e && r.forEach(t => e.delete(t))
                        }
                    })
                }
                deleteAllHandlers() {
                    this._handlers = new Map
                }
                registerHandler(e, t) {
                    if (this._handlers.has(e)) {
                        const s = this._handlers.get(e);
                        s && s.add(t)
                    } else this._handlers.set(e, new Set([t]))
                }
                unregisterHandler(e, t) {
                    if (this._handlers.has(e)) {
                        const s = this._handlers.get(e);
                        s && s.delete(t)
                    }
                }
                listen(e) {
                    if (this._handlers.has(e.keyCode)) {
                        const t = this._handlers.get(e.keyCode);
                        t && t.forEach(t => t(e))
                    }
                }
            }

            function n(e) {
                var t, s, r;
                return (r = class extends i.PureComponent {
                    constructor(e) {
                        super(e), this._keyboardListener = new o, this._listener = this._keyboardListener.listen.bind(this._keyboardListener)
                    }
                    componentDidMount() {
                        this._registerHandlers(this.props.keyboardEventHandlers)
                    }
                    componentDidUpdate(e) {
                        e.keyboardEventHandlers !== this.props.keyboardEventHandlers && this._registerHandlers(this.props.keyboardEventHandlers)
                    }
                    render() {
                        const {
                            keyboardEventHandlers: t,
                            ...s
                        } = this.props;
                        return i.createElement(e, { ...s,
                            onKeyDown: this._listener
                        })
                    }
                    _registerHandlers(e) {
                        e && (this._keyboardListener.deleteAllHandlers(), this._keyboardListener.registerHandlers(e))
                    }
                }).displayName = `KeyboardListener(${null!==(s=null!==(t=e.displayName)&&void 0!==t?t:e.name)&&void 0!==s?s:"Component"})`, r
            }
        },
        68766: (e, t, s) => {
            "use strict";
            s.d(t, {
                DEFAULT_SLIDER_THEME: () => a,
                SliderItem: () => l,
                factory: () => c,
                SliderRow: () => d
            });
            var r = s(59496),
                i = s(97754),
                o = s(88537),
                n = s(37740);
            const a = n;

            function l(e) {
                const t = i(e.className, n.tab, {
                    [n.active]: e.isActive,
                    [n.disabled]: e.isDisabled,
                    [n.defaultCursor]: !!e.shouldUseDefaultCursor,
                    [n.noBorder]: !!e.noBorder
                });
                return r.createElement("div", {
                    className: t,
                    onClick: e.onClick,
                    ref: e.reference,
                    "data-type": "tab-item",
                    "data-value": e.value,
                    "data-name": "tab-item-" + e.value.toString().toLowerCase()
                }, e.children)
            }

            function c(e) {
                return class extends r.PureComponent {
                    constructor() {
                        super(...arguments), this.activeTab = {
                            current: null
                        }
                    }
                    componentDidUpdate() {
                        (0, o.ensureNotNull)(this._slider).style.transition = "transform 350ms", this._componentDidUpdate()
                    }
                    componentDidMount() {
                        this._componentDidUpdate()
                    }
                    render() {
                        const {
                            className: t
                        } = this.props, s = this._generateTabs();
                        return r.createElement("div", {
                            className: i(t, n.tabs),
                            "data-name": this.props["data-name"]
                        }, s, r.createElement(e, {
                            reference: e => {
                                this._slider = e
                            }
                        }))
                    }
                    _generateTabs() {
                        return this.activeTab.current = null, r.Children.map(this.props.children, e => {
                            const t = e,
                                s = Boolean(t.props.isActive),
                                i = {
                                    reference: e => {
                                        s && (this.activeTab.current = e), t.props.reference && t.props.reference(e)
                                    }
                                };
                            return r.cloneElement(t, i)
                        })
                    }
                    _componentDidUpdate() {
                        const e = (0, o.ensureNotNull)(this._slider).style;
                        if (this.activeTab.current) {
                            const t = this.activeTab.current.offsetWidth,
                                s = this.activeTab.current.offsetLeft;
                            e.transform = `translateX(${s}px)`, e.width = t + "px", e.opacity = "1"
                        } else e.opacity = "0"
                    }
                }
            }
            const d = c((function(e) {
                return r.createElement("div", {
                    className: n.slider,
                    ref: e.reference
                })
            }))
        },
        93173: (e, t, s) => {
            "use strict";

            function r(e, t, s = {}) {
                const r = Object.assign({}, t);
                for (const i of Object.keys(t)) {
                    const o = s[i] || i;
                    o in e && (r[i] = [e[o], t[i]].join(" "))
                }
                return r
            }

            function i(e, t, s = {}) {
                return Object.assign({}, e, r(e, t, s))
            }
            s.d(t, {
                weakComposeClasses: () => r,
                mergeThemes: () => i
            })
        },
        35555: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentcolor" stroke-width="1.3" d="M12 9l5 5-5 5"/></svg>'
        },
        21279: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M10 4h1v2h6V4h1v2h2.5A2.5 2.5 0 0 1 23 8.5v11a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 5 19.5v-11A2.5 2.5 0 0 1 7.5 6H10V4zm8 3H7.5C6.67 7 6 7.67 6 8.5v11c0 .83.67 1.5 1.5 1.5h13c.83 0 1.5-.67 1.5-1.5v-11c0-.83-.67-1.5-1.5-1.5H18zm-3 2h-2v2h2V9zm-7 4h2v2H8v-2zm12-4h-2v2h2V9zm-7 4h2v2h-2v-2zm-3 4H8v2h2v-2zm3 0h2v2h-2v-2zm7-4h-2v2h2v-2z"/></svg>'
        },
        37253: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><mask width="17" height="20" fill="#000" x="6" y="4" maskUnits="userSpaceOnUse" id="aayofezey"><path fill="#fff" d="M6 4h17v20H6z"/><path fill-rule="evenodd" d="M9 5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2H9Zm1 2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h9a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-9Zm2 8.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Zm2.5 1.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm5.5-1.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0ZM10.5 21a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm5.5-1.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0Zm2.5 1.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"/></mask><path fill="currentcolor" d="M8 7a1 1 0 0 1 1-1V4a3 3 0 0 0-3 3h2Zm0 14V7H6v14h2Zm1 1a1 1 0 0 1-1-1H6a3 3 0 0 0 3 3v-2Zm11 0H9v2h11v-2Zm1-1a1 1 0 0 1-1 1v2a3 3 0 0 0 3-3h-2Zm0-14v14h2V7h-2Zm-1-1a1 1 0 0 1 1 1h2a3 3 0 0 0-3-3v2ZM9 6h11V4H9v2Zm1 2V6a2 2 0 0 0-2 2h2Zm0 2V8H8v2h2Zm0 0H8c0 1.1.9 2 2 2v-2Zm9 0h-9v2h9v-2Zm0 0v2a2 2 0 0 0 2-2h-2Zm0-2v2h2V8h-2Zm0 0h2a2 2 0 0 0-2-2v2Zm-9 0h9V6h-9v2Zm.5 10a2.5 2.5 0 0 0 2.5-2.5h-2a.5.5 0 0 1-.5.5v2ZM8 15.5a2.5 2.5 0 0 0 2.5 2.5v-2a.5.5 0 0 1-.5-.5H8Zm2.5-2.5A2.5 2.5 0 0 0 8 15.5h2c0-.28.22-.5.5-.5v-2Zm2.5 2.5a2.5 2.5 0 0 0-2.5-2.5v2c.28 0 .5.22.5.5h2Zm2 0a.5.5 0 0 1-.5.5v2a2.5 2.5 0 0 0 2.5-2.5h-2Zm-.5-.5c.28 0 .5.22.5.5h2a2.5 2.5 0 0 0-2.5-2.5v2Zm-.5.5c0-.28.22-.5.5-.5v-2a2.5 2.5 0 0 0-2.5 2.5h2Zm.5.5a.5.5 0 0 1-.5-.5h-2a2.5 2.5 0 0 0 2.5 2.5v-2Zm4 2a2.5 2.5 0 0 0 2.5-2.5h-2a.5.5 0 0 1-.5.5v2ZM16 15.5a2.5 2.5 0 0 0 2.5 2.5v-2a.5.5 0 0 1-.5-.5h-2Zm2.5-2.5a2.5 2.5 0 0 0-2.5 2.5h2c0-.28.22-.5.5-.5v-2Zm2.5 2.5a2.5 2.5 0 0 0-2.5-2.5v2c.28 0 .5.22.5.5h2Zm-10 4a.5.5 0 0 1-.5.5v2a2.5 2.5 0 0 0 2.5-2.5h-2Zm-.5-.5c.28 0 .5.22.5.5h2a2.5 2.5 0 0 0-2.5-2.5v2Zm-.5.5c0-.28.22-.5.5-.5v-2A2.5 2.5 0 0 0 8 19.5h2Zm.5.5a.5.5 0 0 1-.5-.5H8a2.5 2.5 0 0 0 2.5 2.5v-2Zm4 2a2.5 2.5 0 0 0 2.5-2.5h-2a.5.5 0 0 1-.5.5v2ZM12 19.5a2.5 2.5 0 0 0 2.5 2.5v-2a.5.5 0 0 1-.5-.5h-2Zm2.5-2.5a2.5 2.5 0 0 0-2.5 2.5h2c0-.28.22-.5.5-.5v-2Zm2.5 2.5a2.5 2.5 0 0 0-2.5-2.5v2c.28 0 .5.22.5.5h2Zm2 0a.5.5 0 0 1-.5.5v2a2.5 2.5 0 0 0 2.5-2.5h-2Zm-.5-.5c.28 0 .5.22.5.5h2a2.5 2.5 0 0 0-2.5-2.5v2Zm-.5.5c0-.28.22-.5.5-.5v-2a2.5 2.5 0 0 0-2.5 2.5h2Zm.5.5a.5.5 0 0 1-.5-.5h-2a2.5 2.5 0 0 0 2.5 2.5v-2Z" mask="url(#aayofezey)"/></svg>'
        },
        13873: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16"><path d="M4 0c-.6 0-1 .4-1 1v1H1c-.6 0-1 .4-1 1v12c0 .6.4 1 1 1h14c.6 0 1-.4 1-1V3c0-.6-.4-1-1-1h-2V1c0-.6-.4-1-1-1h-1c-.6 0-1 .4-1 1v1H6V1c0-.6-.4-1-1-1H4zM2 5h12v9H2V5zm5 2v2h2V7H7zm3 0v2h2V7h-2zm-6 3v2h2v-2H4zm3 0v2h2v-2H7zm3 0v2h2v-2h-2z"/></svg>'
        },
        94280: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><path fill="none" stroke="currentColor" stroke-width="2" d="M17.09 6.5A7.5 7.5 0 1 0 11.5 19a7.481 7.481 0 0 0 5.59-2.5"/></svg>'
        },
        2739: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><path fill="currentColor" stroke="none" d="M2 10h18v2H2z"/></svg>'
        },
        37729: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><g fill="currentColor" stroke="none"><path d="M3 10h18v2H3z"/><path d="M11 2h2v18h-2z"/></g></svg>'
        },
        80589: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><g fill="none"><path stroke="currentColor" stroke-width="2" d="M4 12.5A7.5 7.5 0 1 0 11.5 5h-6"/><path fill="currentColor" d="M3 5l4-4v8z"/></g></svg>'
        },
        17354: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M13.5 7l1.65-1.65a.5.5 0 0 0 0-.7l-1.8-1.8a.5.5 0 0 0-.7 0L11 4.5M13.5 7L11 4.5M13.5 7l-8.35 8.35a.5.5 0 0 1-.36.15H2.5v-2.3a.5.5 0 0 1 .15-.35L11 4.5"/></svg>'
        },
        64773: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 132 76" width="132" height="76" fill="none"><mask fill="#fff" id="a"><path fill-rule="evenodd" clip-rule="evenodd" d="M114 76H24C10.745 76 0 65.255 0 52s10.745-24 24-24l.247.002C26.215 12.214 39.681 0 56 0c14.582 0 26.886 9.753 30.744 23.093A21.896 21.896 0 0 1 98 20c11.821 0 21.464 9.323 21.979 21.017C126.981 43.48 132 50.155 132 58c0 9.265-7 16.895-16 17.89V76h-2z"/></mask><path fill="currentColor" d="M24 28l.012-2H24v2zm.247.002l-.012 2 1.777.01.22-1.763-1.985-.247zm62.497-4.909l-1.921.556.72 2.49 2.226-1.328-1.025-1.718zm33.235 17.924l-1.999.087.06 1.35 1.274.45.665-1.887zM116 75.89l-.22-1.988-1.78.197v1.791h2zm0 .11v2h2v-2h-2zm-2-2H24v4h90v-4zm-90 0C11.85 74 2 64.15 2 52h-4c0 14.36 11.64 26 26 26v-4zM2 52c0-12.15 9.85-22 22-22v-4C9.64 26-2 37.64-2 52h4zm21.988-22l.247.001.024-4-.247-.001-.024 4zm2.244-1.751C28.077 13.45 40.702 2 56 2v-4C38.66-2 24.354 10.98 22.263 27.754l3.969.495zM56 2c13.668 0 25.206 9.142 28.823 21.649l3.842-1.111C84.567 8.365 71.497-2 56-2v4zm31.769 22.81A19.896 19.896 0 0 1 98 22v-4a23.896 23.896 0 0 0-12.28 3.376l2.049 3.435zM98 22c10.745 0 19.513 8.475 19.98 19.105l3.997-.176C121.415 28.17 110.896 18 98 18v4zm21.314 20.903C125.541 45.095 130 51.03 130 58h4c0-8.72-5.58-16.132-13.357-18.87l-1.329 3.773zM130 58c0 8.234-6.222 15.018-14.22 15.902l.44 3.976C126.222 76.772 134 68.296 134 58h-4zm-16 17.89V76h4v-.11h-4zm2-1.89h-2v4h2v-4z" mask="url(#a)"/><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M60 51.659a6 6 0 1 0-4 0V57a2 2 0 0 0 4 0v-5.341z"/></svg>'
        },
        91533: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="#FB8C00" d="M0 9a9 9 0 1 1 18 0A9 9 0 0 1 0 9z"/><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M9 4c-.79 0-1.38.7-1.25 1.48l.67 4.03a.59.59 0 0 0 1.16 0l.67-4.03A1.27 1.27 0 0 0 9 4zm0 8a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"/></svg>'
        },
        97099: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120" fill="none"><g clip-path="url(#adgm1bxe3)"><path fill="#2A2E39" fill-rule="evenodd" clip-rule="evenodd" d="M103.54 47.03a4.78 4.78 0 0 0-1.73 4.07c.98 10.62-2.18 22.78-9.61 33.6-14.03 20.43-37.97 28.36-53.47 17.72s-16.7-35.83-2.67-56.26c8.1-11.81 19.52-19.44 30.71-21.73a4.79 4.79 0 0 0 3.4-2.8c.64-1.47 1.43-2.9 2.38-4.28 7.3-10.5 21.14-13.47 30.93-6.62 9.78 6.85 11.8 20.91 4.52 31.42-1.3 1.87-2.8 3.5-4.46 4.88z"/><rect width="80" height="58" fill="#121722" stroke="#B2B5BE" stroke-width="2" rx="7" x="20" y="26"/><path stroke="#B2B5BE" stroke-linecap="round" stroke-width="2" d="M6 90h106"/><path fill="#B2B5BE" fill-rule="evenodd" clip-rule="evenodd" d="M48.53 50.6L52 54.05 53.06 53l-3.47-3.47 3.47-3.47L52 45l-3.47 3.47L45.06 45 44 46.06l3.47 3.47L44 53l1.06 1.06 3.47-3.47zM72.53 50.6L76 54.05 77.06 53l-3.47-3.47 3.47-3.47L76 45l-3.47 3.47L69.06 45 68 46.06l3.47 3.47L68 53l1.06 1.06 3.47-3.47z"/><path stroke="#B2B5BE" stroke-width="1.5" d="M51 64.5h17"/></g></svg>'
        },
        81263: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120" fill="none"><g clip-path="url(#ayusj0oi1)"><path fill="#F0F3FA" fill-rule="evenodd" clip-rule="evenodd" d="M103.54 47.03a4.78 4.78 0 0 0-1.73 4.07c.98 10.62-2.18 22.78-9.61 33.6-14.03 20.43-37.97 28.36-53.47 17.72s-16.7-35.83-2.67-56.26c8.1-11.81 19.52-19.44 30.71-21.73a4.79 4.79 0 0 0 3.4-2.8c.64-1.47 1.43-2.9 2.38-4.28 7.3-10.5 21.14-13.47 30.93-6.62 9.78 6.85 11.8 20.91 4.52 31.42-1.3 1.87-2.8 3.5-4.46 4.88z"/><rect width="80" height="58" fill="#fff" stroke="#1E222D" stroke-width="2" rx="7" x="20" y="26"/><path stroke="#1E222D" stroke-linecap="round" stroke-width="2" d="M6 90h106"/><path fill="#000" fill-rule="evenodd" clip-rule="evenodd" d="M48.53 50.6L52 54.05 53.06 53l-3.47-3.47 3.47-3.47L52 45l-3.47 3.47L45.06 45 44 46.06l3.47 3.47L44 53l1.06 1.06 3.47-3.47zm24 0L76 54.05 77.06 53l-3.47-3.47 3.47-3.47L76 45l-3.47 3.47L69.06 45 68 46.06l3.47 3.47L68 53l1.06 1.06 3.47-3.47z"/><path stroke="#000" stroke-width="1.5" d="M51 64.5h17"/></g></svg>'
        }
    }
]);
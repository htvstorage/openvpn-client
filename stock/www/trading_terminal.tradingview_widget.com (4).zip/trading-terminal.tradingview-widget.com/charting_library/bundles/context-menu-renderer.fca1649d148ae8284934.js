(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [1584], {
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        16842: e => {
            e.exports = {
                favorite: "favorite-JVQQsDQk",
                disabled: "disabled-JVQQsDQk",
                active: "active-JVQQsDQk",
                checked: "checked-JVQQsDQk"
            }
        },
        49277: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                ContextMenuRenderer: () => c
            });
            var o = r(59496),
                s = r(87995),
                n = r(75753),
                i = r(34581),
                a = r(53327);
            class c {
                constructor(e, t, r, s) {
                    this._root = document.createElement("div"), this._isShown = !1, this._manager = null, this._props = {
                        isOpened: !1,
                        items: e,
                        position: {
                            x: 0,
                            y: 0
                        },
                        menuStatName: t.statName,
                        mode: t.mode,
                        "data-name": t["data-name"]
                    }, this._onDestroy = r, this._onShow = s, this._activeElement = document.activeElement, this._returnFocus = t.returnFocus, this._takeFocus = t.takeFocus, this._menuElementRef = o.createRef(), this._doNotCloseOn = t.doNotCloseOn, t.manager && (this._manager = t.manager)
                }
                show(e) {
                    this._onShow && this._onShow(), this._isShown = !0, this._render({ ...this._props,
                        position: (t, r, o) => {
                            var s, n, a;
                            e.touches && e.touches.length > 0 && (e = {
                                clientX: e.touches[0].clientX,
                                clientY: e.touches[0].clientY
                            });
                            let c;
                            switch (null !== (s = e.attachToXBy) && void 0 !== s ? s : (0, i.isRtl)() ? "right" : "left") {
                                case "left":
                                    c = e.clientX;
                                    break;
                                case "right":
                                    c = e.clientX - t
                            }
                            let l, h = null !== (n = e.attachToYBy) && void 0 !== n ? n : "auto",
                                d = e.clientY;
                            if ("auto-strict" === h) {
                                const t = d + (null !== (a = e.boxHeight) && void 0 !== a ? a : 0);
                                o < t + r ? h = "bottom" : (h = "top", d = t)
                            }
                            switch (h) {
                                case "top":
                                    l = Math.min(r, o - d);
                                    break;
                                case "bottom":
                                    d -= Math.min(r, d), l = 0 === d ? e.clientY : void 0
                            }
                            return {
                                x: c,
                                y: d,
                                overrideHeight: l
                            }
                        },
                        isOpened: !0,
                        onClose: () => {
                            this.hide(), this._unmount()
                        },
                        doNotCloseOn: this._doNotCloseOn,
                        takeFocus: this._takeFocus,
                        menuElementReference: this._menuElementRef
                    })
                }
                hide() {
                    this._isShown = !1, this._render({ ...this._props,
                        isOpened: !1
                    })
                }
                isShown() {
                    return this._isShown
                }
                _unmount() {
                    this._isShown = !1, s.unmountComponentAtNode(this._root), this._onDestroy && this._onDestroy(), this._returnFocus && this._activeElement instanceof HTMLElement && this._activeElement.focus({
                        preventScroll: !0
                    })
                }
                _render(e) {
                    s.render(o.createElement(a.SlotContext.Provider, {
                        value: this._manager
                    }, o.createElement(n.OverlapContextMenu, { ...e
                    })), this._root)
                }
            }
        },
        63694: (e, t, r) => {
            "use strict";
            r.d(t, {
                DrawerManager: () => s,
                DrawerContext: () => n
            });
            var o = r(59496);
            class s extends o.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return o.createElement(n.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const n = o.createContext(null)
        },
        59339: (e, t, r) => {
            "use strict";
            r.d(t, {
                Drawer: () => m
            });
            var o = r(59496),
                s = r(88537),
                n = r(97754),
                i = r(59142),
                a = r(85089),
                c = r(8361),
                l = r(63694),
                h = r(1227),
                d = r(28466),
                u = r(66998);

            function m(e) {
                const {
                    position: t = "Bottom",
                    onClose: r,
                    children: m,
                    className: w,
                    theme: v = u
                } = e, p = (0,
                    s.ensureNotNull)((0, o.useContext)(l.DrawerContext)), [_, f] = (0, o.useState)(0), g = (0, o.useRef)(null), D = (0, o.useContext)(d.CloseDelegateContext);
                return (0, o.useEffect)(() => {
                    const e = (0, s.ensureNotNull)(g.current);
                    return e.focus({
                        preventScroll: !0
                    }), D.subscribe(p, r), 0 === p.currentDrawer && (0, a.setFixedBodyState)(!0), h.CheckMobile.iOS() && (0, i.disableBodyScroll)(e), f(p.addDrawer()), () => {
                        D.unsubscribe(p, r);
                        const t = p.removeDrawer();
                        h.CheckMobile.iOS() && (0, i.enableBodyScroll)(e), 0 === t && (0, a.setFixedBodyState)(!1)
                    }
                }, []), o.createElement(c.Portal, null, o.createElement("div", {
                    className: n(u.wrap, u["position" + t])
                }, _ === p.currentDrawer && o.createElement("div", {
                    className: u.backdrop,
                    onClick: r
                }), o.createElement("div", {
                    className: n(u.drawer, v.drawer, u["position" + t], w),
                    ref: g,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, m)))
            }
        },
        77687: (e, t, r) => {
            "use strict";
            r.d(t, {
                FavoriteButton: () => d
            });
            var o = r(25177),
                s = r(59496),
                n = r(97754),
                i = r(72571),
                a = r(17110),
                c = r(6639),
                l = r(16842);
            const h = {
                add: (0, o.t)("Add to favorites"),
                remove: (0, o.t)("Remove from favorites")
            };

            function d(e) {
                const {
                    className: t,
                    isFilled: r,
                    isActive: o,
                    onClick: d,
                    ...u
                } = e;
                return s.createElement(i.Icon, { ...u,
                    className: n(l.favorite, "apply-common-tooltip", r && l.checked, o && l.active, t),
                    icon: r ? a : c,
                    onClick: d,
                    title: r ? h.remove : h.add
                })
            }
        },
        96366: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 16" width="10" height="16"><path d="M.6 1.4l1.4-1.4 8 8-8 8-1.4-1.4 6.389-6.532-6.389-6.668z"/></svg>'
        },
        17110: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="currentColor" d="M9 1l2.35 4.76 5.26.77-3.8 3.7.9 5.24L9 13l-4.7 2.47.9-5.23-3.8-3.71 5.25-.77L9 1z"/></svg>'
        },
        6639: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M9 2.13l1.903 3.855.116.236.26.038 4.255.618-3.079 3.001-.188.184.044.259.727 4.237-3.805-2L9 12.434l-.233.122-3.805 2.001.727-4.237.044-.26-.188-.183-3.079-3.001 4.255-.618.26-.038.116-.236L9 2.13z"/></svg>'
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2248], {
        54157: e => {
            e.exports = {
                wrapper: "wrapper-IwJ1xL3u",
                text: "text-IwJ1xL3u"
            }
        },
        72249: (e, t, n) => {
            "use strict";
            n.d(t, {
                splitThousands: () => o
            });
            var r = n(93751);

            function o(e, t = "&nbsp;") {
                let n = e + ""; - 1 !== n.indexOf("e") && (n = function(e) {
                    return (0, r.fixComputationError)(e).toFixed(10).replace(/\.?0+$/, "")
                }(Number(e)));
                const o = n.split(".");
                return o[0].replace(/\B(?=(\d{3})+(?!\d))/g, t) + (o[1] ? "." + o[1] : "")
            }
        },
        71757: (e, t, n) => {
            "use strict";
            n.d(t, {
                OfflineScreen: () => a,
                renderOfflineScreen: () => c
            });
            var r = n(59496),
                o = n(87995),
                i = n(25177),
                s = n(54157);

            function a() {
                return r.createElement("div", {
                    className: s.wrapper
                }, r.createElement("p", {
                    className: s.text
                }, (0, i.t)("Lost internet connection")))
            }

            function c(e) {
                o.render(r.createElement(a, null), e)
            }
        },
        44963: (e, t, n) => {
            "use strict";
            var r;
            n.d(t, {
                    StopType: () => r
                }),
                function(e) {
                    e[e.StopLoss = 0] = "StopLoss", e[e.TrailingStop = 1] = "TrailingStop"
                }(r || (r = {}))
        },
        44777: (e, t, n) => {
            "use strict";
            n.d(t, {
                DisconnectError: () => s,
                extractDisconnectionInfoAndConnectionStatus: () => a
            });
            var r = n(24818),
                o = n(50317),
                i = n(50420);
            class s extends i.UserFriendlyError {
                constructor({
                    disconnectInfo: e,
                    ...t
                }) {
                    super(t), this.name = "DisconnectError", this.disconnectInfo = e
                }
            }

            function a(e) {
                const t = function(e) {
                    const t = {
                        message: (0, o.getErrorMessage)(e)
                    };
                    e instanceof s && (t.disconnectType = e.disconnectInfo.disconnectType);
                    return t
                }(e);
                let n = 4;
                return void 0 !== t.disconnectType && [r.DisconnectType.CancelAuthorization, r.DisconnectType.TimeOutForAuthorization].includes(t.disconnectType) && (n = 3), {
                    disconnectionInfo: t,
                    connectionStatus: n
                }
            }
        },
        50420: (e, t, n) => {
            "use strict";

            function r(e) {
                return e instanceof Error && "UserFriendlyError" === e.name
            }
            n.d(t, {
                isUserFriendlyError: () => r,
                UserFriendlyError: () => o
            });
            class o extends Error {
                constructor({
                    detailedErrorMessage: e,
                    userFriendlyMessage: t,
                    originalError: n
                }) {
                    super(t), this.name = "UserFriendlyError", this.detailedErrorMessage = e, this.originalError = n
                }
            }
        },
        50317: (e, t, n) => {
            "use strict";
            n.d(t, {
                orderStatusToText: () => y,
                sideToText: () => x,
                orderTypeToText: () => b,
                findArraysDifferences: () => k,
                formatNumber: () => E,
                isOrderOrPositionMessageType: () => S,
                roundToStepByPriceTypeAndSide: () => w,
                TasksWithTermination: () => F,
                numOfDecimalPlaces: () => O,
                roundDownToPowerOf10: () => _,
                isFinalOrderStatus: () => C,
                positionSideToText: () => L,
                makeNonTradableSymbolText: () => I,
                getErrorMessage: () => P,
                getLoggerMessage: () => U
            });
            var r = n(25177),
                o = n(60521),
                i = n(24818),
                s = n(72249),
                a = n(2683),
                c = n(51951),
                u = n(96796),
                d = n(50420),
                l = n(44777);
            const f = {
                    2: {},
                    1: {}
                },
                p = {},
                m = {},
                h = {};
            let g = !1;
            const T = (0, c.getLogger)("Trading.Utils");

            function y(e) {
                return v(), h[e]
            }

            function v() {
                g || (g = !0, f[2][2] = (0, r.t)("Mkt", {
                    context: "Market order"
                }), f[2][1] = (0, r.t)("Lmt", {
                    context: "Limit order"
                }), f[2][3] = (0, r.t)("Stp", {
                    context: "order"
                }), f[2][4] = (0, r.t)("Stp lmt", {
                    context: "Stop limit order"
                }), f[1][2] = (0, r.t)("Market"), f[1][1] = (0, r.t)("Limit"), f[1][3] = (0, r.t)("Stop", {
                    context: "order"
                }), f[1][4] = (0, r.t)("StopLimit"), p[1] = (0, r.t)("Buy", {
                    context: "trading"
                }), p[-1] = (0, r.t)("Sell", {
                    context: "trading"
                }), m[1] = (0, r.t)("Long", {
                    context: "trading"
                }), m[-1] = (0, r.t)("Short", {
                    context: "trading"
                }), h[2] = (0,
                    r.t)("filled"), h[1] = (0, r.t)("cancelled"), h[6] = (0, r.t)("working"), h[3] = (0, r.t)("inactive"), h[4] = (0, r.t)("placing"), h[5] = (0, r.t)("rejected"))
            }

            function x(e, t) {
                v();
                const n = p[e];
                return t ? n.toUpperCase() : n
            }

            function b(e, t, n) {
                v();
                const r = n ? 2 : 1;
                return t ? f[r][e].toUpperCase() : f[r][e]
            }

            function k(e, t, n, r, o) {
                const i = {
                        added: [],
                        modified: [],
                        removed: []
                    },
                    s = e.slice(0);
                return t.forEach(t => {
                    const c = e.findIndex(e => e[n] === t[n]);
                    if (-1 === c) return void i.added.push(t);
                    s[c] = null;
                    const u = e[c];
                    for (const e of r) {
                        let n = !0;
                        if (null === u[e] || "object" != typeof u[e] ? n = u[e] === t[e] : o && (n = (0, a.deepEquals)(u[e], t[e])[0]), !n) return void i.modified.push(t)
                    }
                }), s.forEach(e => {
                    e && i.removed.push(e)
                }), i
            }

            function E(e) {
                return Math.abs(e || 0) < .001 ? "0.00" : (0, s.splitThousands)((e || 0).toFixed(2))
            }

            function S(e) {
                return -1 !== Object.keys(i.OrderOrPositionMessageType).map(e => i.OrderOrPositionMessageType[e]).indexOf(e)
            }

            function w(e, t, n, r) {
                const i = (0, o.Big)(e).div(t);
                return 1 === n && 1 === r || 2 === n && -1 === r ? i.round(0, 0).mul(t).toNumber() : 1 === n && -1 === r || 2 === n && 1 === r ? i.round(0, 3).mul(t).toNumber() : 0
            }
            const D = (0, r.t)("Failed to login");
            class F {
                constructor(e) {
                    this._isFinished = !1, this._isTerminated = !1, this._tasks = e
                }
                execute() {
                    return this._isTerminated = !1, this._isExecuted() && !this._isFinished ? this.terminate().then(() => this._execution = this._execute()) : this._execution = this._execute()
                }
                async terminate() {
                    if (this._isExecuted() && !this._isFinished) {
                        this._isTerminated = !0;
                        try {
                            await this._execution
                        } catch (e) {
                            return void T.logWarn(e)
                        }
                    }
                }
                _isExecuted() {
                    return !!this._execution
                }
                async _execute() {
                    for (const e of this._tasks) {
                        if (this._isTerminated) throw new Error("Login tasks are terminated");
                        try {
                            await e()
                        } catch (e) {
                            this._isFinished = !0;
                            const t = {
                                detailedErrorMessage: `${D}${M(U(e))}`,
                                userFriendlyMessage: `${D}${M(P(e))}`
                            };
                            throw e instanceof l.DisconnectError ? new l.DisconnectError({ ...t,
                                disconnectInfo: e.disconnectInfo
                            }) : new d.UserFriendlyError(t)
                        }
                    }
                    this._isFinished = !0
                }
            }

            function M(e) {
                return void 0 === e || "" === e ? "" : ": " + e
            }

            function O(e) {
                return (new o.Big(e).toFixed().split(".")[1] || "").length
            }

            function _(e) {
                return (0, o.Big)(10).pow(Math.floor(Math.log10(e))).toNumber()
            }

            function C(e) {
                return -1 !== [2, 1, 5].indexOf(e)
            }

            function L(e) {
                return v(), m[e]
            }

            function I(e, t) {
                return (0, r.t)("You can't trade the symbol {symbol} at TradingView via {broker}.").replace("{symbol}", e).replace("{broker}", t)
            }

            function P(e) {
                if (void 0 === e) return (0, r.t)("Unknown error");
                let t;
                return t = e instanceof Error ? e.message : "object" == typeof e ? JSON.stringify(e) : e.toString(), (0, u.removeTags)(t)
            }

            function U(e) {
                return e instanceof d.UserFriendlyError ? (0, u.removeTags)(e.detailedErrorMessage) : P(e)
            }
        },
        50681: (e, t, n) => {
            "use strict";
            n.d(t, {
                bottomTradingTabClassName: () => a,
                orderStatusToText: () => s.orderStatusToText,
                brokersListFromPlans: () => u,
                isOAuthAuthType: () => l,
                executionText: () => f,
                convertActionDescriptionsToActions: () => p,
                isOrderActive: () => m,
                makeBrokerSideMaintananceFeatureToggleName: () => h,
                makeMaintananceFeatureToggleName: () => g,
                getCurrency: () => T,
                isModifyOrderSupported: () => v,
                isMoveOrderSupported: () => x,
                isBatsQuotes: () => b,
                isDefined: () => k,
                makeDatePlus24UTCHours: () => E,
                findDurationMetaInfo: () => S,
                getOrderDuration: () => w,
                getCustomFieldsWithoutForceUserEnterInitialValueFlag: () => M
            });
            var r = n(88537),
                o = n(44963),
                i = n(90687),
                s = n(50317);
            const a = "js-bottom-trading-tab";
            const c = ["Paper"];

            function u(e, t) {
                const n = e.map(e => e.id),
                    r = t.map(e => e.slug_name),
                    o = t.filter(e => n.includes(e.slug_name)).map(t => ({
                        metainfo: d(e, t.slug_name),
                        brokerPlan: t
                    })),
                    i = e.filter(e => !r.includes(e.id) && !c.includes(e.id)).map(e => ({
                        metainfo: e
                    })),
                    s = c.map(t => ({
                        metainfo: d(e, t)
                    }));
                return s.length > 0 && o.splice(0, 0, ...s), [...o, ...i]
            }

            function d(e, t) {
                return (0, r.ensureDefined)(e.find(e => e.id.toLowerCase() === t.toLowerCase()))
            }

            function l(e) {
                return void 0 !== e && ["oauth", "oauth2-implicit-flow", "oauth2-code-flow"].includes(e)
            }

            function f(e, t) {
                const n = (0, s.sideToText)(e.side) + " " + e.qty + " @ " + t.format(e.price);
                return n.substring(0, 1).toUpperCase() + n.substring(1).toLowerCase()
            }

            function p(e) {
                return e ? e.map(e => "-" === e.text || e.separator ? new i.Separator : new i.Action({
                    actionId: "Trading.CustomActionId",
                    name: e.name,
                    checkable: e.checkable,
                    checked: e.checked,
                    disabled: void 0 !== e.enabled && !e.enabled,
                    label: e.text,
                    statName: e.statName,
                    icon: e.icon,
                    onExecute: t => {
                        const n = t.getState();
                        e.action({
                            checkable: n.checkable,
                            checked: n.checked,
                            enabled: !n.disabled,
                            text: n.label
                        })
                    }
                })) : []
            }

            function m(e) {
                return 6 === e || 3 === e
            }

            function h(e) {
                return (e + "-brokers-side-maintenance").toLowerCase()
            }

            function g(e) {
                return (e + "-maintenance").toLowerCase()
            }

            function T(e, t) {
                return !t && e.currencySign || e.currency || ""
            }

            function y(e, t) {
                return Boolean(void 0 !== e.parentId && t.supportModifyBrackets && (t.supportTrailingStop && t.supportModifyTrailingStop || e.stopType !== o.StopType.TrailingStop))
            }

            function v(e, t) {
                const n = void 0 === e.parentId && (t.supportModifyOrderPrice || t.supportEditAmount || t.supportModifyBrackets),
                    r = y(e, t);
                return Boolean(n || r)
            }

            function x(e, t) {
                const n = void 0 === e.parentId && t.supportModifyOrderPrice,
                    r = y(e, t);
                return Boolean(n || r)
            }

            function b(e) {
                var t;
                return "BATS" === (null === (t = e.originalName) || void 0 === t ? void 0 : t.split(":")[0])
            }

            function k(e) {
                return null != e
            }

            function E() {
                const e = new Date;
                return e.setUTCHours(e.getUTCHours() + 24), e
            }

            function S(e, t) {
                return e.find(e => e.value === t)
            }

            function w(e) {
                const {
                    orderDuration: t,
                    orderType: n,
                    savedDuration: r,
                    orderDurations: o,
                    symbolDurations: i
                } = e;
                if (void 0 !== t) return t;
                const s = function(e) {
                    const {
                        duration: t,
                        orderDurations: n,
                        orderType: r,
                        symbolDurations: o
                    } = e;
                    if (null === t || void 0 === n) return null;
                    const i = D(n, o),
                        s = S(F(i, null != r ? r : null), t.type);
                    if (void 0 === s) return null;
                    if (void 0 !== t.datetime && (s.hasDatePicker || s.hasTimePicker)) {
                        const e = 864e5,
                            n = s.hasTimePicker ? t.datetime < Date.now() : Math.floor((t.datetime - Date.now()) / e) < 0;
                        t.datetime = n ? E().getTime() : t.datetime
                    }
                    return t
                }({
                    duration: r,
                    orderType: n,
                    orderDurations: o,
                    symbolDurations: i
                });
                return null !== s ? { ...s
                } : function(e, t, n) {
                    var r;
                    if (void 0 === t) return null;
                    const o = F(D(t, n), e);
                    if (0 === o.length) return null;
                    return function(e) {
                        const t = {
                            type: e.value
                        };
                        Boolean(e.hasTimePicker || e.hasDatePicker) && (t.datetime = E().valueOf());
                        return t
                    }(null !== (r = o.find(e => e.default)) && void 0 !== r ? r : o[0])
                }(n, o, i)
            }

            function D(e, t) {
                return 0 === e.length || void 0 === t || 0 === t.length ? e : e.filter(({
                    value: e
                }) => t.includes(e))
            }

            function F(e, t) {
                const n = [1, 3, 4];
                return e.filter(e => {
                    var r;
                    const o = null !== (r = e.supportedOrderTypes) && void 0 !== r ? r : n;
                    return null === t || o.includes(t)
                })
            }

            function M(e, t, n) {
                const r = {};
                return void 0 !== n && Array.isArray(n.customFields) && n.customFields.forEach(n => {
                    var o;
                    const i = null === (o = e.customFields) || void 0 === o ? void 0 : o[n.id],
                        s = null == t ? void 0 : t[n.id],
                        a = "ComboBox" === n.inputType && n.forceUserEnterInitialValue;
                    void 0 === i ? void 0 === s || a || (r[n.id] = s) : r[n.id] = i
                }), r
            }
        }
    }
]);
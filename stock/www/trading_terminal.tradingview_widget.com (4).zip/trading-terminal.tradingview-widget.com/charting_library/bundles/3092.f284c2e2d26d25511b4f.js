"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [3092], {
        66759: (e, i, o) => {
            o.d(i, {
                getSeriesStylePropertiesDefinitions: () => Ee
            });
            var t = o(88537),
                r = o(25177),
                n = o(18517),
                l = o(1272),
                s = o(10296),
                a = o(94489),
                c = o.n(a),
                d = o(82527),
                p = o(29310),
                h = o(96796);
            const y = new n.TranslatedString("change color bars based on previous close", (0, r.t)("change color bars based on previous close")),
                u = new n.TranslatedString("change HLC bars", (0, r.t)("change HLC bars")),
                g = new n.TranslatedString("change bar up color", (0, r.t)("change bar up color")),
                f = new n.TranslatedString("change bar down color", (0, r.t)("change bar down color")),
                b = new n.TranslatedString("change thin bars", (0, r.t)("change thin bars")),
                w = new n.TranslatedString("change line price source", (0, r.t)("change line price source")),
                S = new n.TranslatedString("change line type", (0, r.t)("change line type")),
                P = new n.TranslatedString("change line color", (0, r.t)("change line color")),
                T = new n.TranslatedString("change line width", (0, r.t)("change line width")),
                m = new n.TranslatedString("change area price source", (0, r.t)("change area price source")),
                v = new n.TranslatedString("change area line color", (0, r.t)("change area line color")),
                D = new n.TranslatedString("change area line width", (0, r.t)("change area line width")),
                C = new n.TranslatedString("change area fill color", (0, r.t)("change area fill color")),
                _ = new n.TranslatedString("change baseline price source", (0, r.t)("change baseline price source")),
                k = new n.TranslatedString("change baseline top line color", (0, r.t)("change baseline top line color")),
                L = new n.TranslatedString("change baseline top line width", (0, r.t)("change baseline top line width")),
                M = new n.TranslatedString("change baseline bottom line color", (0, r.t)("change baseline bottom line color")),
                B = new n.TranslatedString("change baseline bottom line width", (0, r.t)("change baseline bottom line width")),
                $ = new n.TranslatedString("change baseline fill top area color", (0, r.t)("change baseline fill top area color")),
                I = new n.TranslatedString("change baseline fill bottom area color", (0, r.t)("change baseline fill bottom area color")),
                j = new n.TranslatedString("change base level", (0, r.t)("change base level")),
                O = new n.TranslatedString("change high-low body visibility", (0, r.t)("change high-low body visibility")),
                W = new n.TranslatedString("change high-low body color", (0, r.t)("change high-low body color")),
                E = new n.TranslatedString("change high-low borders visibility", (0, r.t)("change high-low borders visibility")),
                V = new n.TranslatedString("change high-low border color", (0, r.t)("change high-low border color")),
                A = new n.TranslatedString("change high-low labels visibility", (0, r.t)("change high-low labels visibility")),
                x = new n.TranslatedString("change high-low labels color", (0, r.t)("change high-low labels color")),
                N = new n.TranslatedString("change high-low labels font size", (0, r.t)("change high-low labels font size")),
                H = (new n.TranslatedString("change renko wick visibility", (0, r.t)("change renko wick visibility")), new n.TranslatedString("change renko wick up color", (0,
                    r.t)("change renko wick up color")), new n.TranslatedString("change renko wick down color", (0, r.t)("change renko wick down color")), new n.TranslatedString("change the display of real prices on price scale (instead of Heiken-Ashi price)", (0, r.t)("change the display of real prices on price scale (instead of Heiken-Ashi price)")), new n.TranslatedString("change range thin bars", (0, r.t)("change range thin bars")), new n.TranslatedString("change {candleType} body visibility", (0, r.t)("change {candleType} body visibility"))),
                U = new n.TranslatedString("change {candleType} up color", (0, r.t)("change {candleType} up color")),
                z = new n.TranslatedString("change {candleType} down color", (0, r.t)("change {candleType} down color")),
                F = new n.TranslatedString("change {candleType} border visibility", (0, r.t)("change {candleType} border visibility")),
                R = new n.TranslatedString("change {candleType} up border color", (0, r.t)("change {candleType} up border color")),
                Y = new n.TranslatedString("change {candleType} down border color", (0, r.t)("change {candleType} down border color")),
                G = new n.TranslatedString("change {candleType} wick visibility", (0, r.t)("change {candleType} wick visibility")),
                J = new n.TranslatedString("change {candleType} wick up color", (0, r.t)("change {candleType} wick up color")),
                K = new n.TranslatedString("change {candleType} wick down color", (0, r.t)("change {candleType} wick down color")),
                q = new n.TranslatedString("change {chartType} up color", (0, r.t)("change {chartType} up color")),
                Q = new n.TranslatedString("change {chartType} down color", (0, r.t)("change {chartType} down color")),
                X = new n.TranslatedString("change {chartType} projection bar up color", (0, r.t)("change {chartType} projection bar up color")),
                Z = new n.TranslatedString("change {chartType} projection bar down color", (0, r.t)("change {chartType} projection bar down color")),
                ee = new n.TranslatedString("change {chartType} border bar up color", (0, r.t)("change {chartType} border bar up color")),
                ie = new n.TranslatedString("change {chartType} border bar down color", (0, r.t)("change {chartType} border bar down color")),
                oe = new n.TranslatedString("change {chartType} projection border bar up color", (0, r.t)("change {chartType} projection border bar up color")),
                te = new n.TranslatedString("change {chartType} projection border bar up color", (0, r.t)("change {chartType} projection border bar up color")),
                re = new n.TranslatedString("change column up color", (0, r.t)("change column up color")),
                ne = new n.TranslatedString("change column down color", (0, r.t)("change column down color")),
                le = new n.TranslatedString("change column price source", (0, r.t)("change column price source")),
                se = (0, r.t)("Color bars based on previous close"),
                ae = (0, r.t)("HLC bars"),
                ce = (0, r.t)("Up color"),
                de = (0, r.t)("Down color"),
                pe = (0, r.t)("Thin bars"),
                he = (0, r.t)("Body"),
                ye = (0, r.t)("Borders"),
                ue = (0, r.t)("Wick"),
                ge = (0, r.t)("Price source"),
                fe = (0, r.t)("Type"),
                be = (0, r.t)("Line"),
                we = (0, r.t)("Top line"),
                Se = (0, r.t)("Bottom line"),
                Pe = (0, r.t)("Fill"),
                Te = (0, r.t)("Fill top area"),
                me = (0, r.t)("Fill bottom area"),
                ve = (0, r.t)("Up bars"),
                De = (0,
                    r.t)("Down bars"),
                Ce = (0, r.t)("Projection up bars"),
                _e = (0, r.t)("Projection down bars"),
                ke = ((0, r.t)("Real prices on price scale (instead of Heikin-Ashi price)"), (0, r.t)("Base level")),
                Le = (0, r.t)("Body"),
                Me = (0, r.t)("Borders"),
                Be = (0, r.t)("Labels");

            function $e(e, i, o, t) {
                return (0, l.createCheckablePropertyDefinition)({
                    checked: (0, l.convertToDefinitionProperty)(e, i.barColorsOnPrevClose, y)
                }, {
                    id: `${o}${t}`,
                    title: se
                })
            }

            function Ie(e, i, o, t, r, n) {
                return (0, l.createOptionsPropertyDefinition)({
                    option: (0, l.convertToDefinitionProperty)(e, i.priceSource, n)
                }, {
                    id: `${t}${r}`,
                    title: ge,
                    options: new(c())(o)
                })
            }

            function je(e, i, o, t) {
                const r = (0, h.removeSpaces)(o.originalText());
                return [(0, l.createTwoColorsPropertyDefinition)({
                    checked: (0, l.convertToDefinitionProperty)(e, i.drawBody, H.format({
                        candleType: o
                    })),
                    color1: (0, l.getColorDefinitionProperty)(e, i.upColor, null, U.format({
                        candleType: o
                    })),
                    color2: (0, l.getColorDefinitionProperty)(e, i.downColor, null, z.format({
                        candleType: o
                    }))
                }, {
                    id: `${t}Symbol${r}CandlesColor`,
                    title: he
                }), (0, l.createTwoColorsPropertyDefinition)({
                    checked: (0, l.convertToDefinitionProperty)(e, i.drawBorder, F.format({
                        candleType: o
                    })),
                    color1: (0, l.getColorDefinitionProperty)(e, i.borderUpColor, null, R.format({
                        candleType: o
                    })),
                    color2: (0, l.getColorDefinitionProperty)(e, i.borderDownColor, null, Y.format({
                        candleType: o
                    }))
                }, {
                    id: `${t}Symbol${r}BordersColor`,
                    title: ye
                }), (0, l.createTwoColorsPropertyDefinition)({
                    checked: (0, l.convertToDefinitionProperty)(e, i.drawWick, G.format({
                        candleType: o
                    })),
                    color1: (0, l.getColorDefinitionProperty)(e, i.wickUpColor, null, J.format({
                        candleType: o
                    })),
                    color2: (0, l.getColorDefinitionProperty)(e, i.wickDownColor, null, K.format({
                        candleType: o
                    }))
                }, {
                    id: `${t}Symbol${r}WickColors`,
                    title: ue
                })]
            }

            function Oe(e, i, o, t) {
                const r = []; {
                    const n = (0, h.removeSpaces)(o.originalText()),
                        s = (0, l.createColorPropertyDefinition)({
                            color: (0, l.getColorDefinitionProperty)(e, i.upColor, null, q.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}UpBars`,
                            title: ve
                        }),
                        a = (0, l.createColorPropertyDefinition)({
                            color: (0, l.getColorDefinitionProperty)(e, i.downColor, null, Q.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}DownBars`,
                            title: De
                        }),
                        c = (0, l.createColorPropertyDefinition)({
                            color: (0, l.getColorDefinitionProperty)(e, i.upColorProjection, null, X.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}ProjectionUpBars`,
                            title: Ce
                        }),
                        d = (0, l.createColorPropertyDefinition)({
                            color: (0, l.getColorDefinitionProperty)(e, i.downColorProjection, null, Z.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}ProjectionDownBars`,
                            title: _e
                        });
                    r.push(s, a, c, d)
                }
                return r
            }

            function We(e, i, o, t) {
                const r = []; {
                    const n = (0, h.removeSpaces)(o.originalText()),
                        s = (0, l.createTwoColorsPropertyDefinition)({
                            color1: (0, l.getColorDefinitionProperty)(e, i.upColor, null, q.format({
                                chartType: o
                            })),
                            color2: (0, l.getColorDefinitionProperty)(e, i.borderUpColor, null, ee.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}UpBars`,
                            title: ve
                        }),
                        a = (0, l.createTwoColorsPropertyDefinition)({
                            color1: (0, l.getColorDefinitionProperty)(e, i.downColor, null, Q.format({
                                chartType: o
                            })),
                            color2: (0, l.getColorDefinitionProperty)(e, i.borderDownColor, null, ie.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}DownBars`,
                            title: De
                        }),
                        c = (0,
                            l.createTwoColorsPropertyDefinition)({
                            color1: (0, l.getColorDefinitionProperty)(e, i.upColorProjection, null, X.format({
                                chartType: o
                            })),
                            color2: (0, l.getColorDefinitionProperty)(e, i.borderUpColorProjection, null, oe.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}ProjectionUpBars`,
                            title: Ce
                        }),
                        d = (0, l.createTwoColorsPropertyDefinition)({
                            color1: (0, l.getColorDefinitionProperty)(e, i.downColorProjection, null, Z.format({
                                chartType: o
                            })),
                            color2: (0, l.getColorDefinitionProperty)(e, i.borderDownColorProjection, null, te.format({
                                chartType: o
                            }))
                        }, {
                            id: `${t}Symbol${n}ProjectionDownBars`,
                            title: _e
                        });
                    r.push(s, a, c, d)
                }
                return r
            }

            function Ee(e, i, o, a, h) {
                switch (o) {
                    case 0:
                        return function(e, i, o) {
                            return [$e(e, i, o, "SymbolBarStyleBarColorsOnPrevClose"), (0, l.createCheckablePropertyDefinition)({
                                checked: (0, l.convertToDefinitionProperty)(e, i.dontDrawOpen, u)
                            }, {
                                id: o + "SymbolDontDrawOpen",
                                title: ae
                            }), (0, l.createColorPropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.upColor, null, g)
                            }, {
                                id: o + "SymbolUpColor",
                                title: ce
                            }), (0, l.createColorPropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.downColor, null, f)
                            }, {
                                id: o + "SymbolDownColor",
                                title: de
                            }), (0, l.createCheckablePropertyDefinition)({
                                checked: (0, l.convertToDefinitionProperty)(e, i.thinBars, b)
                            }, {
                                id: o + "SymbolBarThinBars",
                                title: pe
                            })]
                        }(e, i.barStyle.childs(), h);
                    case 1:
                        return function(e, i, o) {
                            return [$e(e, i, o, "SymbolCandleStyleBarColorsOnPrevClose"), ...je(e, i, new n.TranslatedString("candle", (0, r.t)("candle")), o)]
                        }(e, i.candleStyle.childs(), h);
                    case 2:
                        return function(e, i, o, t, r) {
                            return [Ie(e, i, o, r, "SymbolLinePriceSource", w), (0, l.createOptionsPropertyDefinition)({
                                option: (0, l.convertToDefinitionProperty)(e, i.styleType, S)
                            }, {
                                id: r + "SymbolStyleType",
                                title: fe,
                                options: new(c())(t)
                            }), (0, l.createLinePropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.color, null, P),
                                width: (0, l.convertToDefinitionProperty)(e, i.linewidth, T)
                            }, {
                                id: r + "SymbolLineStyle",
                                title: be
                            })]
                        }(e, i.lineStyle.childs(), a.seriesPriceSources, a.lineStyleTypes, h);
                    case 3:
                        return function(e, i, o, t) {
                            return [Ie(e, i, o, t, "SymbolAreaPriceSource", m), (0, l.createLinePropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.linecolor, null, v),
                                width: (0, l.convertToDefinitionProperty)(e, i.linewidth, D)
                            }, {
                                id: t + "SymbolAreaLineStyle",
                                title: be
                            }), (0, l.createTwoColorsPropertyDefinition)({
                                color1: (0, l.getColorDefinitionProperty)(e, i.color1, i.transparency, C),
                                color2: (0, l.getColorDefinitionProperty)(e, i.color2, i.transparency, C)
                            }, {
                                id: t + "SymbolAreaFills",
                                title: Pe
                            })]
                        }(e, i.areaStyle.childs(), a.seriesPriceSources, h);
                    case 9:
                        return je(e, i.hollowCandleStyle.childs(), new n.TranslatedString("hollow candles", (0, r.t)("hollow candles")), h);
                    case 10:
                        return function(e, i, o, t) {
                            return [Ie(e, i, o, t, "SymbolBaseLinePriceSource", _), (0, l.createLinePropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.topLineColor, null, k),
                                width: (0, l.convertToDefinitionProperty)(e, i.topLineWidth, L)
                            }, {
                                id: t + "SymbolBaseLineTopLine",
                                title: we
                            }), (0, l.createLinePropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.bottomLineColor, null, M),
                                width: (0, l.convertToDefinitionProperty)(e, i.bottomLineWidth, B)
                            }, {
                                id: t + "SymbolBaseLineBottomLine",
                                title: Se
                            }), (0, l.createTwoColorsPropertyDefinition)({
                                color1: (0, l.getColorDefinitionProperty)(e, i.topFillColor1, null, $),
                                color2: (0, l.getColorDefinitionProperty)(e, i.topFillColor2, null, $)
                            }, {
                                id: t + "SymbolBaseLineTopFills",
                                title: Te
                            }), (0, l.createTwoColorsPropertyDefinition)({
                                color1: (0, l.getColorDefinitionProperty)(e, i.bottomFillColor1, null, I),
                                color2: (0, l.getColorDefinitionProperty)(e, i.bottomFillColor2, null, I)
                            }, {
                                id: t + "SymbolBaseLineBottomFills",
                                title: me
                            }), (0, l.createNumberPropertyDefinition)({
                                value: (0, l.convertToDefinitionProperty)(e, i.baseLevelPercentage, j, [p.floor])
                            }, {
                                id: t + "SymbolBaseLevelPercentage",
                                title: ke,
                                type: 0,
                                min: new(c())(0),
                                max: new(c())(100),
                                step: new(c())(1),
                                unit: new(c())("%")
                            })]
                        }(e, i.baselineStyle.childs(), a.seriesPriceSources, h);
                    case 13:
                        return function(e, i, o, t) {
                            return [Ie(e, i, o, t, "SymbolColumnPriceSource", le), $e(e, i, t, "SymbolColumnStyleColumnColorsOnPrevClose"), (0, l.createColorPropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.upColor, null, re)
                            }, {
                                id: t + "SymbolUpColor",
                                title: ce
                            }), (0, l.createColorPropertyDefinition)({
                                color: (0, l.getColorDefinitionProperty)(e, i.downColor, null, ne)
                            }, {
                                id: t + "SymbolDownColor",
                                title: de
                            })]
                        }(e, i.columnStyle.childs(), a.seriesPriceSources, h)
                }
                if (!i.hasOwnProperty("haStyle")) return [];
                if (a.isJapaneseChartsAvailable && 8 === o) {
                    return function(e, i, o) {
                        const t = [];
                        return t.push($e(e, i, o, "SymbolHAStyleBarColorsOnPrevClose"), ...je(e, i, new n.TranslatedString("Heikin Ashi", (0, r.t)("Heikin Ashi")), o)), t
                    }(e, i.haStyle.childs(), h)
                }
                if (a.isJapaneseChartsAvailable && d.enabled("japanese_chart_styles")) {
                    if (4 === o || 5 === o || 6 === o || 7 === o || 8 === o) switch (o) {
                        case 4:
                            return function(e, i, o) {
                                return [...We(e, i, new n.TranslatedString("renko", (0, r.t)("renko")), o)]
                            }(e, i.renkoStyle.childs(), h);
                        case 5:
                            return Oe(e, i.kagiStyle.childs(), new n.TranslatedString("kagi", (0, r.t)("kagi")), h);
                        case 6:
                            return Oe(e, i.pnfStyle.childs(), new n.TranslatedString("point & figure", (0, r.t)("point & figure")), h);
                        case 7:
                            return We(e, i.pbStyle.childs(), new n.TranslatedString("line break", (0, r.t)("line break")), h)
                    }
                    0
                }
                if (d.enabled("chart_style_hilo") && 12 === o) {
                    const o = i.hiloStyle.childs(),
                        r = (0, s.chartStyleStudyId)(12);
                    return function(e, i, o, t) {
                        const r = (0, l.createColorPropertyDefinition)({
                                checked: (0, l.convertToDefinitionProperty)(e, i.drawBody, O),
                                color: (0, l.getColorDefinitionProperty)(e, i.color, null, W)
                            }, {
                                id: t + "SymbolBodiesColor",
                                title: Le
                            }),
                            n = (0, l.createColorPropertyDefinition)({
                                checked: (0, l.convertToDefinitionProperty)(e, i.showBorders, E),
                                color: (0, l.getColorDefinitionProperty)(e, i.borderColor, null, V)
                            }, {
                                id: t + "SymbolBorderColor",
                                title: Me
                            }),
                            s = o.map(e => ({
                                title: String(e),
                                value: e
                            }));
                        return [r, n, (0, l.createTextPropertyDefinition)({
                            checked: (0, l.convertToDefinitionProperty)(e, i.showLabels, A),
                            color: (0, l.getColorDefinitionProperty)(e, i.labelColor, null, x),
                            size: (0, l.convertToDefinitionProperty)(e, i.fontSize, N)
                        }, {
                            id: t + "SymbolLabels",
                            title: Be,
                            isEditable: !1,
                            isMultiLine: !1,
                            sizeItems: s
                        })]
                    }(e, o, (0, t.ensure)(a.defaultSeriesFontSizes)[r], h)
                }
                return []
            }
        },
        83092: (e, i, o) => {
            o.d(i, {
                SeriesPropertyDefinitionsViewModel: () => ue,
                basePriceSources: () => pe,
                lineStyleTypes: () => he,
                seriesPrecisionValues: () => ye
            });
            var t = o(88537),
                r = o(25177),
                n = o(18517),
                l = o(82527),
                s = o(1272),
                a = o(9297),
                c = o(94489),
                d = o.n(c),
                p = o(10296),
                h = o(42148),
                y = o(66759),
                u = o(29310);
            const g = new n.TranslatedString("change {inputName} property", (0, r.t)("change {inputName} property"));

            function f(e) {
                return e.map(e => ({
                    value: e,
                    title: (0, r.t)(e)
                }))
            }

            function b(e, i, o, l, a, c, h) {
                const y = [];
                return o.forEach(o => {
                    if (! function(e, i) {
                            return !e.isHidden && (void 0 === e.visible || function(e, i) {
                                if (!e) return !0;
                                const o = e.split("==");
                                return !(o.length < 2) && i[o[0]].value() === o[1]
                            }(e.visible, i))
                        }(o, l)) return;
                    const b = o.id;
                    if (!l.hasOwnProperty(b)) return;
                    const w = l[b],
                        S = function(e, i) {
                            return "style" === e.id ? "Box size assignment method" : "boxSize" === e.id ? "Box size" : i.childs().name.value()
                        }(o, a[b]),
                        P = function(e) {
                            return (0, r.t)(e)
                        }(S),
                        T = new n.TranslatedString(S, P);
                    if ("options" in o) {
                        const i = (0, t.ensure)(o.options);
                        y.push((0, s.createOptionsPropertyDefinition)({
                            option: (0, s.convertToDefinitionProperty)(e, w, g.format({
                                inputName: T
                            }))
                        }, {
                            id: `${h}${o.name}`,
                            title: P,
                            options: new(d())(f(i))
                        }))
                    } else if ("integer" !== o.type) {
                        if ("float" === o.type) {
                            let t;
                            return t = function(e, i) {
                                return !((i === (0, p.chartStyleStudyId)(4) || i === (0, p.chartStyleStudyId)(6)) && "boxSize" === e || i === (0, p.chartStyleStudyId)(5) && "reversalAmount" === e)
                            }(b, i) || null === c.value() ? new(d())(o.min) : c, void y.push((0, s.createNumberPropertyDefinition)({
                                value: (0, s.convertToDefinitionProperty)(e, w, g.format({
                                    inputName: T
                                }))
                            }, {
                                id: `${h}${o.name}`,
                                title: P,
                                type: 1,
                                min: t,
                                max: new(d())(o.max),
                                defval: o.defval
                            }))
                        }
                        "text" !== o.type ? "bool" !== o.type || y.push((0, s.createCheckablePropertyDefinition)({
                            checked: (0, s.convertToDefinitionProperty)(e, w, g.format({
                                inputName: T
                            }))
                        }, {
                            id: `${h}${o.name}`,
                            title: P
                        })) : y.push((0, s.createTextPropertyDefinition)({
                            text: (0, s.convertToDefinitionProperty)(e, w, g.format({
                                inputName: T
                            }))
                        }, {
                            id: `${h}${o.name}`,
                            title: P,
                            isEditable: !0,
                            isMultiLine: !1
                        }))
                    } else y.push((0, s.createNumberPropertyDefinition)({
                        value: (0, s.convertToDefinitionProperty)(e, w, g.format({
                            inputName: T
                        }), [u.floor])
                    }, {
                        id: `${h}${o.name}`,
                        title: P,
                        type: 0,
                        min: new(d())(o.min),
                        max: new(d())(o.max),
                        defval: o.defval
                    }))
                }), y
            }
            var w = o(51951),
                S = o(37978),
                P = o(76337),
                T = o(55563);
            const m = (0, w.getLogger)("Chart.Definitions.Series"),
                v = l.enabled("show_average_close_price_line_and_label"),
                D = new n.TranslatedString("change decimal places", (0, r.t)("change decimal places")),
                C = new n.TranslatedString("change timezone", (0, r.t)("change timezone")),
                _ = (new n.TranslatedString("adjust data for dividends", (0, r.t)("adjust data for dividends")), new n.TranslatedString("use settlement as close on daily interval", (0, r.t)("use settlement as close on daily interval")), new n.TranslatedString("adjust for contract changes", (0, r.t)("adjust for contract changes")), new n.TranslatedString("change session", (0, r.t)("change session")), new n.TranslatedString("change extended hours color", (0, r.t)("change extended hours color"))),
                k = new n.TranslatedString("change pre market color", (0, r.t)("change pre market color")),
                L = new n.TranslatedString("change post market color", (0,
                    r.t)("change post market color")),
                M = new n.TranslatedString("change price line visibility", (0, r.t)("change price line visibility")),
                B = new n.TranslatedString("change price line color", (0, r.t)("change price line color")),
                $ = new n.TranslatedString("change price line width", (0, r.t)("change price line width")),
                I = new n.TranslatedString("change previous close price line visibility", (0, r.t)("change previous close price line visibility")),
                j = new n.TranslatedString("change previous close price line color", (0, r.t)("change previous close price line color")),
                O = new n.TranslatedString("change previous close price line width", (0, r.t)("change previous close price line width")),
                W = (new n.TranslatedString("change pre/post market price lines visibility", (0, r.t)("change pre/post market price lines visibility")), new n.TranslatedString("change pre market line color", (0, r.t)("change pre market line color")), new n.TranslatedString("change post market line color", (0, r.t)("change post market line color")), new n.TranslatedString("change bid and ask lines visibility", (0, r.t)("change bid and ask lines visibility"))),
                E = new n.TranslatedString("change bid line color", (0, r.t)("change bid line color")),
                V = new n.TranslatedString("change ask line color", (0, r.t)("change ask line color")),
                A = new n.TranslatedString("change high and low price lines visibility", (0, r.t)("change high and low price lines visibility")),
                x = new n.TranslatedString("change high and low price line color", (0, r.t)("change high and low price line color")),
                N = new n.TranslatedString("change high and low price line width", (0, r.t)("change high and low price line width")),
                H = new n.TranslatedString("change average close price line visibility", (0, r.t)("change average close price line visibility")),
                U = new n.TranslatedString("change average close price line color", (0, r.t)("change average close price line color")),
                z = new n.TranslatedString("change average close price line width", (0, r.t)("change average close price line width")),
                F = ((0, r.t)("Adjust data for dividends"), (0, r.t)("Session"), (0, r.t)("Adjust for contract changes"), (0, r.t)("Use settlement as close on daily interval"), (0, r.t)("Pre/post market hours background")),
                R = (0, r.t)("Last price line"),
                Y = (0, r.t)("Previous day close price line"),
                G = (0, r.t)("Bid and ask lines"),
                J = ((0, r.t)("Pre/post market price line"), (0, r.t)("Precision")),
                K = (0, r.t)("Timezone"),
                q = (0, r.t)("Open"),
                Q = (0, r.t)("High"),
                X = (0, r.t)("Low"),
                Z = (0, r.t)("Close"),
                ee = (0, r.t)("(H + L)/2"),
                ie = (0, r.t)("(H + L + C)/3"),
                oe = (0, r.t)("(O + H + L + C)/4"),
                te = (0, r.t)("Simple"),
                re = (0, r.t)("With markers"),
                ne = (0, r.t)("Step"),
                le = (0, r.t)("Default"),
                se = (0, r.t)("High and low price lines"),
                ae = (0, r.t)("Average close price line"),
                ce = {
                    [(0, p.chartStyleStudyId)(12)]: [7, 8, 9, 10, 11, 12, 14, 16, 20, 24, 28, 32, 40]
                },
                de = [{
                    priceScale: 1,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 10,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 100,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e3,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e4,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e5,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e6,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e7,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e8,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e9,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 1e10,
                    minMove: 1,
                    frac: !1
                }, {
                    priceScale: 2,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 4,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 8,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 16,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 32,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 64,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 128,
                    minMove: 1,
                    frac: !0
                }, {
                    priceScale: 320,
                    minMove: 1,
                    frac: !0
                }],
                pe = [{
                    title: q,
                    value: "open",
                    id: "price-source-open"
                }, {
                    title: Q,
                    value: "high",
                    id: "price-source-high"
                }, {
                    title: X,
                    value: "low",
                    id: "price-source-low"
                }, {
                    title: Z,
                    value: "close",
                    id: "price-source-close"
                }, {
                    title: ee,
                    value: "hl2",
                    id: "price-source-hl2"
                }, {
                    title: ie,
                    value: "hlc3",
                    id: "price-source-hlc3"
                }, {
                    title: oe,
                    value: "ohlc4",
                    id: "price-source-ohlc4"
                }],
                he = [{
                    title: te,
                    value: h.STYLE_LINE_TYPE_SIMPLE
                }, {
                    title: re,
                    value: h.STYLE_LINE_TYPE_MARKERS
                }, {
                    title: ne,
                    value: h.STYLE_LINE_TYPE_STEP
                }];

            function ye() {
                const e = [{
                    title: le,
                    value: "default"
                }];
                for (let i = 0; i < de.length; i++) e.push({
                    title: `${de[i].minMove}/${de[i].priceScale}`,
                    value: `${de[i].priceScale},${de[i].minMove},${de[i].frac}`
                });
                return e
            }
            class ue {
                constructor(e, i, o, t, r, n) {
                    this._definitions = null, this._inputsSubscriptions = null, this._isDestroyed = !1, this._propertyPages = null, this._seriesMinTickWV = null, this._sessionIdOptionsWV = new(d())([]), this._series = e, this._undoModel = i, this._model = this._undoModel.model(), this._propertyPageId = o, this._propertyPageName = t, this._propertyPageIcon = r, this._timezonePropertyObj = n, this._series.onStyleChanged().subscribe(this, this._updateDefinitions), this._series.dataEvents().symbolResolved().subscribe(this, this._updateSeriesMinTickWV), this._series.dataEvents().symbolResolved().subscribe(this, this._updateSessionIdOptionsWV), this._updateSeriesMinTickWV(), this._updateSessionIdOptionsWV()
                }
                destroy() {
                    null !== this._propertyPages && this._propertyPages.forEach(e => {
                        (0, s.destroyDefinitions)(e.definitions.value())
                    }), this._series.onStyleChanged().unsubscribe(this, this._updateDefinitions), this._series.dataEvents().symbolResolved().unsubscribeAll(this), this._unsubscribeInputsUpdate(), this._isDestroyed = !0
                }
                propertyPages() {
                    return null === this._propertyPages ? this._getDefinitions().then(e => {
                        var i;
                        if (this._isDestroyed) throw new Error("SeriesPropertyDefinitionsViewModel already destroyed");
                        return null === this._propertyPages && (this._propertyPages = [{
                            id: this._propertyPageId,
                            title: this._propertyPageName,
                            icon: this._propertyPageIcon,
                            definitions: new(d())(e.definitions),
                            visible: null !== (i = e.visible) && void 0 !== i ? i : new(d())(!0).readonly()
                        }]), this._propertyPages
                    }) : Promise.resolve(this._propertyPages)
                }
                _seriesMinTick() {
                    const e = this._series.symbolInfo();
                    return null !== e ? e.minmov / e.pricescale : null
                }
                _updateSeriesMinTickWV() {
                    null === this._seriesMinTickWV ? this._seriesMinTickWV = new(d())(this._seriesMinTick()) : this._seriesMinTickWV.setValue(this._seriesMinTick())
                }
                _updateSessionIdOptionsWV() {}
                _updateDefinitions() {
                    null !== this._definitions && (0, s.destroyDefinitions)(this._definitions.definitions), this._definitions = null, this._unsubscribeInputsUpdate(), this._createSeriesDefinitions().then(e => {
                        if (this._isDestroyed) throw new Error("SeriesPropertyDefinitionsViewModel already destroyed");
                        (0,
                            t.ensureNotNull)(this._propertyPages)[0].definitions.setValue(e.definitions)
                    })
                }
                _getDefinitions() {
                    return null === this._definitions ? this._createSeriesDefinitions() : Promise.resolve(this._definitions)
                }
                _unsubscribeInputsUpdate() {
                    null !== this._inputsSubscriptions && (this._inputsSubscriptions.forEach(e => {
                        e.unsubscribeAll(this)
                    }), this._inputsSubscriptions = null)
                }
                _subscribeInputsUpdate(e, i) {
                    const o = [];
                    e.forEach(e => {
                        if (void 0 !== e.visible) {
                            const t = e.visible.split("==");
                            if (2 === t.length) {
                                const e = i[t[0]]; - 1 === o.indexOf(e) && (e.subscribe(this, this._updateDefinitions), o.push(e))
                            }
                        }
                    }), o.length > 0 ? this._inputsSubscriptions = o : this._inputsSubscriptions = null
                }
                _createSeriesDefinitions() {
                    const e = this._series.properties().childs(),
                        i = this._series.getInputsProperties(),
                        o = this._series.getInputsInfoProperties(),
                        r = e.style.value(),
                        n = this._series.getStyleShortName();
                    return new Promise(e => {
                        const l = (0, p.chartStyleStudyId)(r);
                        null !== l ? this._model.studyMetaInfoRepository().findById({
                            type: "java",
                            studyId: l
                        }).then(r => {
                            if (this._isDestroyed) throw new Error("SeriesPropertyDefinitionsViewModel already destroyed");
                            if (null !== this._definitions) return void e(null);
                            const l = (0, t.ensureNotNull)(this._seriesMinTickWV),
                                s = b(this._undoModel, r.id, r.inputs, i, o, l, n);
                            this._subscribeInputsUpdate(r.inputs, i), e(s)
                        }).catch(i => {
                            m.logWarn("Find meta info for create series definitions with error - " + (0, S.errorToString)(i)), e(null)
                        }) : e(null)
                    }).then(i => {
                        if (this._isDestroyed) throw new Error("SeriesPropertyDefinitionsViewModel already destroyed");
                        if (null !== this._definitions) return this._definitions;
                        const o = (0, y.getSeriesStylePropertiesDefinitions)(this._undoModel, e, r, {
                            seriesPriceSources: pe,
                            lineStyleTypes: he,
                            isJapaneseChartsAvailable: !0,
                            defaultSeriesFontSizes: ce
                        }, "mainSeries");
                        null !== i && o.push(...i);
                        const t = (0, s.createOptionsPropertyDefinition)({
                                option: (0, s.convertToDefinitionProperty)(this._undoModel, e.minTick, D)
                            }, {
                                id: n + "SymbolMinTick",
                                title: J,
                                options: new(d())(ye())
                            }),
                            l = (0, s.createOptionsPropertyDefinition)({
                                option: (0, s.convertToDefinitionProperty)(this._undoModel, this._timezonePropertyObj.property, C)
                            }, {
                                id: n + "SymbolTimezone",
                                title: K,
                                options: new(d())(this._timezonePropertyObj.values)
                            });
                        return this._definitions = {
                            definitions: [(0, s.createPropertyDefinitionsGeneralGroup)(o, "generalSymbolStylesGroup"), ...this._seriesPriceLinesDefinitions(n), ...this._seriesDataDefinitions(n), t, l]
                        }, this._definitions
                    })
                }
                _seriesDataDefinitions(e) {
                    return []
                }
                _createOutOfSessionDefinition(e) {
                    const i = this._model.sessions().properties().childs().graphics.childs().backgrounds.childs().outOfSession.childs();
                    return (0, s.createColorPropertyDefinition)({
                        color: (0, s.getColorDefinitionProperty)(this._undoModel, i.color, i.transparency, _)
                    }, {
                        id: e + "SymbolExtendedHoursColors",
                        title: F
                    })
                }
                _createPrePostMarketDefinition(e) {
                    const i = (0, T.combineWithFilteredUpdate)((e, i) => !i && (0, p.symbolHasPreOrPostMarket)(this._series.symbolInfo()) && !(0, p.isRegularSessionId)(this._series.sessionIdProxyProperty().value()), (e, i) => i || !e, this._series.symbolResolvingActive(), (0,
                            P.createWVFromProperty)(this._series.isDWMProperty())),
                        o = this._model.sessions(),
                        t = o.properties().childs().graphics.childs().backgrounds.childs().preMarket.childs(),
                        r = o.properties().childs().graphics.childs().backgrounds.childs().postMarket.childs();
                    return (0, s.createTwoColorsPropertyDefinition)({
                        color1: (0, s.getColorDefinitionProperty)(this._undoModel, t.color, t.transparency, k),
                        color2: (0, s.getColorDefinitionProperty)(this._undoModel, r.color, r.transparency, L),
                        visible: (0, s.convertFromReadonlyWVToDefinitionProperty)(i)
                    }, {
                        id: e + "SymbolExtendedHoursColors",
                        title: F
                    })
                }
                _seriesPriceLinesDefinitions(e) {
                    const i = [],
                        o = this._series.properties().childs();
                    if (this._series.hasClosePrice()) {
                        const t = (0, s.createLinePropertyDefinition)({
                            checked: (0, s.convertToDefinitionProperty)(this._undoModel, o.showPriceLine, M),
                            color: (0, s.getColorDefinitionProperty)(this._undoModel, o.priceLineColor, null, B),
                            width: (0, s.convertToDefinitionProperty)(this._undoModel, o.priceLineWidth, $)
                        }, {
                            id: e + "SymbolLastValuePriceLine",
                            title: R
                        });
                        i.push(t)
                    }
                    if (this._series.hasClosePrice()) {
                        const t = (0, P.combineProperty)(e => !e, this._series.isDWMProperty()),
                            r = (0, s.createLinePropertyDefinition)({
                                visible: (0, a.makeProxyDefinitionPropertyDestroyable)(t),
                                checked: (0, s.convertToDefinitionProperty)(this._undoModel, o.showPrevClosePriceLine, I),
                                color: (0, s.getColorDefinitionProperty)(this._undoModel, o.prevClosePriceLineColor, null, j),
                                width: (0, s.convertToDefinitionProperty)(this._undoModel, o.prevClosePriceLineWidth, O)
                            }, {
                                id: e + "SymbolPrevClosePriceLine",
                                title: Y
                            });
                        i.push(r)
                    }
                    const t = o.highLowAvgPrice.childs(),
                        r = (0, s.createLinePropertyDefinition)({
                            checked: (0, s.convertToDefinitionProperty)(this._undoModel, t.highLowPriceLinesVisible, A),
                            color: (0, s.getColorDefinitionProperty)(this._undoModel, t.highLowPriceLinesColor, null, x),
                            width: (0, s.convertToDefinitionProperty)(this._undoModel, t.highLowPriceLinesWidth, N)
                        }, {
                            id: e + "SymbolHighLowPriceLines",
                            title: se
                        });
                    if (i.push(r), v) {
                        const o = (0, s.createLinePropertyDefinition)({
                            checked: (0, s.convertToDefinitionProperty)(this._undoModel, t.averageClosePriceLineVisible, H),
                            color: (0, s.getColorDefinitionProperty)(this._undoModel, t.averagePriceLineColor, null, U),
                            width: (0, s.convertToDefinitionProperty)(this._undoModel, t.averagePriceLineWidth, z)
                        }, {
                            id: e + "SymbolAverageClosePriceLine",
                            title: ae
                        });
                        i.push(o)
                    }
                    if (this._model.hasCustomSource("bidask")) {
                        const t = o.bidAsk,
                            r = (0, s.createTwoColorsPropertyDefinition)({
                                checked: (0, s.convertToDefinitionProperty)(this._undoModel, t.childs().visible, W),
                                color1: (0, s.getColorDefinitionProperty)(this._undoModel, t.childs().bidLineColor, null, E),
                                color2: (0, s.getColorDefinitionProperty)(this._undoModel, t.childs().askLineColor, null, V)
                            }, {
                                id: e + "SymbolBidAskLines",
                                title: G
                            });
                        i.push(r)
                    }
                    return i
                }
            }
        }
    }
]);
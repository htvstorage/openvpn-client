(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [994], {
        59142: function(e, t) {
            var n, o, r;
            o = [t], void 0 === (r = "function" == typeof(n = function(e) {
                "use strict";

                function t(e) {
                    if (Array.isArray(e)) {
                        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
                        return n
                    }
                    return Array.from(e)
                }
                Object.defineProperty(e, "__esModule", {
                    value: !0
                });
                var n = !1;
                if ("undefined" != typeof window) {
                    var o = {
                        get passive() {
                            n = !0
                        }
                    };
                    window.addEventListener("testPassive", null, o), window.removeEventListener("testPassive", null, o)
                }
                var r = "undefined" != typeof window && window.navigator && window.navigator.platform && /iP(ad|hone|od)/.test(window.navigator.platform),
                    l = [],
                    a = !1,
                    i = -1,
                    s = void 0,
                    c = void 0,
                    u = function(e) {
                        return l.some((function(t) {
                            return !(!t.options.allowTouchMove || !t.options.allowTouchMove(e))
                        }))
                    },
                    d = function(e) {
                        var t = e || window.event;
                        return !!u(t.target) || 1 < t.touches.length || (t.preventDefault && t.preventDefault(), !1)
                    },
                    m = function() {
                        setTimeout((function() {
                            void 0 !== c && (document.body.style.paddingRight = c, c = void 0), void 0 !== s && (document.body.style.overflow = s, s = void 0)
                        }))
                    };
                e.disableBodyScroll = function(e, o) {
                    if (r) {
                        if (!e) return void console.error("disableBodyScroll unsuccessful - targetElement must be provided when calling disableBodyScroll on IOS devices.");
                        if (e && !l.some((function(t) {
                                return t.targetElement === e
                            }))) {
                            var m = {
                                targetElement: e,
                                options: o || {}
                            };
                            l = [].concat(t(l), [m]), e.ontouchstart = function(e) {
                                1 === e.targetTouches.length && (i = e.targetTouches[0].clientY)
                            }, e.ontouchmove = function(t) {
                                var n, o, r, l;
                                1 === t.targetTouches.length && (o = e, l = (n = t).targetTouches[0].clientY - i, !u(n.target) && (o && 0 === o.scrollTop && 0 < l || (r = o) && r.scrollHeight - r.scrollTop <= r.clientHeight && l < 0 ? d(n) : n.stopPropagation()))
                            }, a || (document.addEventListener("touchmove", d, n ? {
                                passive: !1
                            } : void 0), a = !0)
                        }
                    } else {
                        g = o, setTimeout((function() {
                            if (void 0 === c) {
                                var e = !!g && !0 === g.reserveScrollBarGap,
                                    t = window.innerWidth - document.documentElement.clientWidth;
                                e && 0 < t && (c = document.body.style.paddingRight, document.body.style.paddingRight = t + "px")
                            }
                            void 0 === s && (s = document.body.style.overflow, document.body.style.overflow = "hidden")
                        }));
                        var p = {
                            targetElement: e,
                            options: o || {}
                        };
                        l = [].concat(t(l), [p])
                    }
                    var g
                }, e.clearAllBodyScrollLocks = function() {
                    r ? (l.forEach((function(e) {
                        e.targetElement.ontouchstart = null, e.targetElement.ontouchmove = null
                    })), a && (document.removeEventListener("touchmove", d, n ? {
                        passive: !1
                    } : void 0), a = !1), l = [], i = -1) : (m(), l = [])
                }, e.enableBodyScroll = function(e) {
                    if (r) {
                        if (!e) return void console.error("enableBodyScroll unsuccessful - targetElement must be provided when calling enableBodyScroll on IOS devices.");
                        e.ontouchstart = null, e.ontouchmove = null, l = l.filter((function(t) {
                            return t.targetElement !== e
                        })), a && 0 === l.length && (document.removeEventListener("touchmove", d, n ? {
                            passive: !1
                        } : void 0), a = !1)
                    } else 1 === l.length && l[0].targetElement === e ? (m(), l = []) : l = l.filter((function(t) {
                        return t.targetElement !== e
                    }))
                }
            }) ? n.apply(t, o) : n) || (e.exports = r)
        },
        6539: e => {
            e.exports = {
                button: "button-YKkCvwjV",
                content: "content-YKkCvwjV",
                "icon-only": "icon-only-YKkCvwjV",
                "color-brand": "color-brand-YKkCvwjV",
                "variant-primary": "variant-primary-YKkCvwjV",
                "variant-secondary": "variant-secondary-YKkCvwjV",
                "color-gray": "color-gray-YKkCvwjV",
                "color-green": "color-green-YKkCvwjV",
                "color-red": "color-red-YKkCvwjV",
                "size-xsmall": "size-xsmall-YKkCvwjV",
                "size-small": "size-small-YKkCvwjV",
                "size-medium": "size-medium-YKkCvwjV",
                "size-large": "size-large-YKkCvwjV",
                "size-xlarge": "size-xlarge-YKkCvwjV",
                "with-start-icon": "with-start-icon-YKkCvwjV",
                "with-end-icon": "with-end-icon-YKkCvwjV",
                "start-icon-wrap": "start-icon-wrap-YKkCvwjV",
                "end-icon-wrap": "end-icon-wrap-YKkCvwjV",
                animated: "animated-YKkCvwjV",
                stretch: "stretch-YKkCvwjV",
                grouped: "grouped-YKkCvwjV",
                "adjust-position": "adjust-position-YKkCvwjV",
                "first-row": "first-row-YKkCvwjV",
                "first-col": "first-col-YKkCvwjV",
                "no-corner-top-left": "no-corner-top-left-YKkCvwjV",
                "no-corner-top-right": "no-corner-top-right-YKkCvwjV",
                "no-corner-bottom-right": "no-corner-bottom-right-YKkCvwjV",
                "no-corner-bottom-left": "no-corner-bottom-left-YKkCvwjV"
            }
        },
        21103: e => {
            e.exports = {
                container: "container-pgo9gj31",
                "intent-default": "intent-default-pgo9gj31",
                focused: "focused-pgo9gj31",
                readonly: "readonly-pgo9gj31",
                disabled: "disabled-pgo9gj31",
                "with-highlight": "with-highlight-pgo9gj31",
                grouped: "grouped-pgo9gj31",
                "adjust-position": "adjust-position-pgo9gj31",
                "first-row": "first-row-pgo9gj31",
                "first-col": "first-col-pgo9gj31",
                stretch: "stretch-pgo9gj31",
                "font-size-medium": "font-size-medium-pgo9gj31",
                "font-size-large": "font-size-large-pgo9gj31",
                "size-small": "size-small-pgo9gj31",
                "size-medium": "size-medium-pgo9gj31",
                "size-large": "size-large-pgo9gj31",
                "intent-success": "intent-success-pgo9gj31",
                "intent-warning": "intent-warning-pgo9gj31",
                "intent-danger": "intent-danger-pgo9gj31",
                "intent-primary": "intent-primary-pgo9gj31",
                "border-none": "border-none-pgo9gj31",
                "border-thin": "border-thin-pgo9gj31",
                "border-thick": "border-thick-pgo9gj31",
                "no-corner-top-left": "no-corner-top-left-pgo9gj31",
                "no-corner-top-right": "no-corner-top-right-pgo9gj31",
                "no-corner-bottom-right": "no-corner-bottom-right-pgo9gj31",
                "no-corner-bottom-left": "no-corner-bottom-left-pgo9gj31",
                highlight: "highlight-pgo9gj31",
                shown: "shown-pgo9gj31"
            }
        },
        10306: e => {
            e.exports = {
                "inner-slot": "inner-slot-QpAAIiaV",
                interactive: "interactive-QpAAIiaV",
                icon: "icon-QpAAIiaV",
                "inner-middle-slot": "inner-middle-slot-QpAAIiaV",
                "before-slot": "before-slot-QpAAIiaV",
                "after-slot": "after-slot-QpAAIiaV"
            }
        },
        66579: e => {
            e.exports = {
                input: "input-uGWFLwEy",
                "with-start-slot": "with-start-slot-uGWFLwEy",
                "with-end-slot": "with-end-slot-uGWFLwEy"
            }
        },
        62092: e => {
            e.exports = {
                loader: "loader-MuZZSHRY",
                static: "static-MuZZSHRY",
                item: "item-MuZZSHRY",
                "tv-button-loader": "tv-button-loader-MuZZSHRY",
                medium: "medium-MuZZSHRY",
                small: "small-MuZZSHRY",
                black: "black-MuZZSHRY",
                white: "white-MuZZSHRY",
                gray: "gray-MuZZSHRY",
                primary: "primary-MuZZSHRY",
                "loader-initial": "loader-initial-MuZZSHRY",
                "loader-appear": "loader-appear-MuZZSHRY"
            }
        },
        41227: e => {
            e.exports = {
                actionButton: "actionButton-EGu7SRYD",
                small: "small-EGu7SRYD",
                hiddenTitle: "hiddenTitle-EGu7SRYD"
            }
        },
        36045: e => {
            e.exports = {
                label: "label-lgIqilXY",
                input: "input-lgIqilXY"
            }
        },
        87992: e => {
            e.exports = {
                popupDialog: "popupDialog-2AC2DTdZ",
                wrap: "wrap-2AC2DTdZ",
                main: "main-2AC2DTdZ",
                small: "small-2AC2DTdZ",
                title: "title-2AC2DTdZ",
                content: "content-2AC2DTdZ",
                html: "html-2AC2DTdZ",
                footer: "footer-2AC2DTdZ",
                close: "close-2AC2DTdZ"
            }
        },
        28599: (e, t, n) => {
            "use strict";
            n.d(t, {
                Button: () => w
            });
            var o = n(59496),
                r = n(97754),
                l = n(31774),
                a = n(72571),
                i = n(6539),
                s = n.n(i);

            function c(e) {
                const {
                    color: t = "brand",
                    size: n = "medium",
                    variant: o = "primary",
                    stretch: a = !1,
                    icon: i,
                    startIcon: c,
                    endIcon: u,
                    iconOnly: d = !1,
                    className: m,
                    isGrouped: p,
                    cellState: g,
                    disablePositionAdjustment: f = !1
                } = e, h = function(e) {
                    let t = "";
                    return 0 !== e && (1 & e && (t = r(t, s()["no-corner-top-left"])), 2 & e && (t = r(t, s()["no-corner-top-right"])), 4 & e && (t = r(t, s()["no-corner-bottom-right"])), 8 & e && (t = r(t, s()["no-corner-bottom-left"]))), t
                }((0, l.getGroupCellRemoveRoundBorders)(g));
                return r(m, s().button, s()["size-" + n], s()["color-" + t], s()["variant-" + o], a && s().stretch, (i || c) && s()["with-start-icon"], u && s()["with-end-icon"], d && s()["icon-only"], h, p && s().grouped, p && !f && s()["adjust-position"], p && g.isTop && s()["first-row"], p && g.isLeft && s()["first-col"])
            }

            function u(e) {
                const {
                    size: t,
                    startIcon: n,
                    icon: r,
                    iconOnly: l,
                    children: i,
                    endIcon: c
                } = e, u = null != n ? n : r;
                return o.createElement(o.Fragment, null, u && "xsmall" !== t && o.createElement(a.Icon, {
                    icon: u,
                    className: s()["start-icon-wrap"]
                }), i && o.createElement("span", {
                    className: s().content
                }, i), c && !l && "xsmall" !== t && o.createElement(a.Icon, {
                    icon: c,
                    className: s()["end-icon-wrap"]
                }))
            }
            var d = n(80327),
                m = n(417);

            function p(e) {
                const {
                    className: t,
                    color: n,
                    variant: o,
                    size: r,
                    stretch: l,
                    animated: a,
                    icon: i,
                    iconOnly: s,
                    startIcon: c,
                    endIcon: u,
                    ...d
                } = e;
                return { ...d,
                    ...(0, m.filterDataProps)(e),
                    ...(0, m.filterAriaProps)(e)
                }
            }

            function g(e) {
                const {
                    reference: t,
                    ...n
                } = e, {
                    isGrouped: r,
                    cellState: l,
                    disablePositionAdjustment: a
                } = (0, o.useContext)(d.ControlGroupContext), i = c({ ...n,
                    isGrouped: r,
                    cellState: l,
                    disablePositionAdjustment: a
                });
                return o.createElement("button", { ...p(n),
                    className: i,
                    ref: t
                }, o.createElement(u, { ...n
                }))
            }

            function f(e = "default") {
                switch (e) {
                    case "default":
                        return "primary";
                    case "stroke":
                        return "secondary"
                }
            }

            function h(e = "primary") {
                switch (e) {
                    case "primary":
                        return "brand";
                    case "success":
                        return "green";
                    case "default":
                        return "gray";
                    case "danger":
                        return "red"
                }
            }

            function v(e = "m") {
                switch (e) {
                    case "s":
                        return "xsmall";
                    case "m":
                        return "small";
                    case "l":
                        return "large"
                }
            }

            function C(e) {
                const {
                    intent: t,
                    size: n,
                    appearance: o,
                    useFullWidth: r,
                    icon: l,
                    ...a
                } = e;
                return { ...a,
                    color: h(t),
                    size: v(n),
                    variant: f(o),
                    stretch: r,
                    startIcon: l
                }
            }

            function w(e) {
                return o.createElement(g, { ...C(e)
                })
            }
        },
        80327: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlGroupContext: () => o
            });
            const o = n(59496).createContext({
                isGrouped: !1,
                cellState: {
                    isTop: !0,
                    isRight: !0,
                    isBottom: !0,
                    isLeft: !0
                }
            })
        },
        31774: (e, t, n) => {
            "use strict";

            function o(e) {
                let t = 0;
                return e.isTop && e.isLeft || (t += 1), e.isTop && e.isRight || (t += 2), e.isBottom && e.isLeft || (t += 8), e.isBottom && e.isRight || (t += 4), t
            }
            n.d(t, {
                getGroupCellRemoveRoundBorders: () => o
            })
        },
        34735: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlSkeleton: () => C,
                InputClasses: () => f
            });
            var o = n(59496),
                r = n(97754),
                l = n(88537),
                a = n(28606),
                i = n(417),
                s = n(80327),
                c = n(31774);
            var u = n(21103),
                d = n.n(u);

            function m(e) {
                let t = "";
                return 0 !== e && (1 & e && (t = r(t, d()["no-corner-top-left"])),
                    2 & e && (t = r(t, d()["no-corner-top-right"])), 4 & e && (t = r(t, d()["no-corner-bottom-right"])), 8 & e && (t = r(t, d()["no-corner-bottom-left"]))), t
            }

            function p(e, t, n, o) {
                const {
                    removeRoundBorder: l,
                    className: a,
                    intent: i = "default",
                    borderStyle: s = "thin",
                    size: u,
                    highlight: p,
                    disabled: g,
                    readonly: f,
                    stretch: h,
                    noReadonlyStyles: v,
                    isFocused: C
                } = e, w = m(null != l ? l : (0, c.getGroupCellRemoveRoundBorders)(n));
                return r(d().container, d()["intent-" + i], d()["border-" + s], u && d()["size-" + u], w, p && d()["with-highlight"], g && d().disabled, f && !v && d().readonly, C && d().focused, h && d().stretch, t && d().grouped, !o && d()["adjust-position"], n.isTop && d()["first-row"], n.isLeft && d()["first-col"], a)
            }

            function g(e, t) {
                const {
                    highlight: n,
                    highlightRemoveRoundBorder: o
                } = e;
                if (!n) return d().highlight;
                const l = m(null != o ? o : (0, c.getGroupCellRemoveRoundBorders)(t));
                return r(d().highlight, d().shown, l)
            }
            const f = {
                    FontSizeMedium: (0, l.ensureDefined)(d()["font-size-medium"]),
                    FontSizeLarge: (0, l.ensureDefined)(d()["font-size-large"])
                },
                h = {
                    passive: !1
                };

            function v(e, t) {
                const {
                    id: n,
                    role: r,
                    onFocus: l,
                    onBlur: c,
                    onMouseOver: u,
                    onMouseOut: d,
                    onMouseDown: m,
                    onMouseUp: f,
                    onKeyDown: v,
                    onClick: C,
                    tabIndex: w,
                    startSlot: b,
                    middleSlot: S,
                    endSlot: y,
                    onWheel: E,
                    onWheelNoPassive: k = null
                } = e, {
                    isGrouped: j,
                    cellState: M,
                    disablePositionAdjustment: D = !1
                } = (0, o.useContext)(s.ControlGroupContext), x = function(e, t = null, n) {
                    const r = (0, o.useRef)(null),
                        l = (0, o.useRef)(null),
                        a = (0, o.useCallback)(() => {
                            if (null === r.current || null === l.current) return;
                            const [e, t, n] = l.current;
                            null !== t && r.current.addEventListener(e, t, n)
                        }, []),
                        i = (0, o.useCallback)(() => {
                            if (null === r.current || null === l.current) return;
                            const [e, t, n] = l.current;
                            null !== t && r.current.removeEventListener(e, t, n)
                        }, []),
                        s = (0, o.useCallback)(e => {
                            i(), r.current = e, a()
                        }, []);
                    return (0, o.useEffect)(() => (l.current = [e, t, n], a(), i), [e, t, n]), s
                }("wheel", k, h);
                return o.createElement("span", {
                    id: n,
                    role: r,
                    className: p(e, j, M, D),
                    tabIndex: w,
                    ref: (0, a.useMergedRefs)([t, x]),
                    onFocus: l,
                    onBlur: c,
                    onMouseOver: u,
                    onMouseOut: d,
                    onMouseDown: m,
                    onMouseUp: f,
                    onKeyDown: v,
                    onClick: C,
                    onWheel: E,
                    ...(0, i.filterDataProps)(e),
                    ...(0, i.filterAriaProps)(e)
                }, b, S, y, o.createElement("span", {
                    className: g(e, M)
                }))
            }
            v.displayName = "ControlSkeleton";
            const C = o.forwardRef(v)
        },
        2691: (e, t, n) => {
            "use strict";
            n.d(t, {
                BeforeSlot: () => i,
                StartSlot: () => s,
                MiddleSlot: () => c,
                EndSlot: () => u,
                AfterSlot: () => d
            });
            var o = n(59496),
                r = n(97754),
                l = n(10306),
                a = n.n(l);

            function i(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(a()["before-slot"], t)
                }, n)
            }

            function s(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: l = !1,
                    children: i
                } = e;
                return o.createElement("span", {
                    className: r(a()["inner-slot"], n && a().interactive, l && a().icon, t)
                }, i)
            }

            function c(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(a()["inner-slot"], a()["inner-middle-slot"], t)
                }, n)
            }

            function u(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: l = !1,
                    children: i
                } = e;
                return o.createElement("span", {
                    className: r(a()["inner-slot"], n && a().interactive, l && a().icon, t)
                }, i)
            }

            function d(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(a()["after-slot"], t)
                }, n)
            }
        },
        54936: (e, t, n) => {
            "use strict";
            n.d(t, {
                Input: () => v,
                InputControl: () => C
            });
            var o = n(59496),
                r = n(97754),
                l = n(417),
                a = n(69842),
                i = n(1811),
                s = n(28606),
                c = n(21778),
                u = n(83836),
                d = n(3548),
                m = n(34735),
                p = n(2691),
                g = n(66579),
                f = n.n(g);

            function h(e) {
                return !(0, l.isAriaAttribute)(e) && !(0, l.isDataAttribute)(e)
            }

            function v(e) {
                const {
                    id: t,
                    title: n,
                    role: a,
                    tabIndex: i,
                    placeholder: s,
                    name: c,
                    type: u,
                    value: d,
                    defaultValue: g,
                    draggable: v,
                    autoComplete: C,
                    autoFocus: w,
                    maxLength: b,
                    min: S,
                    max: y,
                    step: E,
                    pattern: k,
                    inputMode: j,
                    onSelect: M,
                    onFocus: D,
                    onBlur: x,
                    onKeyDown: N,
                    onKeyUp: A,
                    onKeyPress: R,
                    onChange: T,
                    onDragStart: I,
                    size: Y = "medium",
                    className: B,
                    inputClassName: O,
                    disabled: V,
                    readonly: z,
                    containerTabIndex: K,
                    startSlot: Z,
                    endSlot: L,
                    reference: P,
                    containerReference: F,
                    onContainerFocus: _,
                    ...H
                } = e, G = (0, l.filterProps)(H, h), W = { ...(0, l.filterAriaProps)(H),
                    ...(0, l.filterDataProps)(H),
                    id: t,
                    title: n,
                    role: a,
                    tabIndex: i,
                    placeholder: s,
                    name: c,
                    type: u,
                    value: d,
                    defaultValue: g,
                    draggable: v,
                    autoComplete: C,
                    autoFocus: w,
                    maxLength: b,
                    min: S,
                    max: y,
                    step: E,
                    pattern: k,
                    inputMode: j,
                    onSelect: M,
                    onFocus: D,
                    onBlur: x,
                    onKeyDown: N,
                    onKeyUp: A,
                    onKeyPress: R,
                    onChange: T,
                    onDragStart: I
                };
                return o.createElement(m.ControlSkeleton, { ...G,
                    disabled: V,
                    readonly: z,
                    tabIndex: K,
                    className: r(f().container, B),
                    size: Y,
                    ref: F,
                    onFocus: _,
                    startSlot: Z,
                    middleSlot: o.createElement(p.MiddleSlot, null, o.createElement("input", { ...W,
                        className: r(f().input, O, Z && f()["with-start-slot"], L && f()["with-end-slot"]),
                        disabled: V,
                        readOnly: z,
                        ref: P
                    })),
                    endSlot: L
                })
            }

            function C(e) {
                e = (0, c.useControl)(e);
                const {
                    disabled: t,
                    autoSelectOnFocus: n,
                    tabIndex: r = 0,
                    onFocus: l,
                    onBlur: m,
                    reference: p,
                    containerReference: g = null
                } = e, f = (0, o.useRef)(null), h = (0, o.useRef)(null), [C, w] = (0, u.useFocus)(), b = t ? void 0 : C ? -1 : r, S = t ? void 0 : C ? r : -1, {
                    isMouseDown: y,
                    handleMouseDown: E,
                    handleMouseUp: k
                } = (0, d.useIsMouseDown)(), j = (0, a.createSafeMulticastEventHandler)(w.onFocus, (function(e) {
                    n && !y.current && (0, i.selectAllContent)(e.currentTarget)
                }), l), M = (0, a.createSafeMulticastEventHandler)(w.onBlur, m), D = (0, o.useCallback)(e => {
                    f.current = e, p && ("function" == typeof p && p(e), "object" == typeof p && (p.current = e))
                }, [f, p]);
                return o.createElement(v, { ...e,
                    isFocused: C,
                    containerTabIndex: b,
                    tabIndex: S,
                    onContainerFocus: function(e) {
                        h.current === e.target && null !== f.current && f.current.focus()
                    },
                    onFocus: j,
                    onBlur: M,
                    reference: D,
                    containerReference: (0, s.useMergedRefs)([h, g]),
                    onMouseDown: E,
                    onMouseUp: k
                })
            }
        },
        21778: (e, t, n) => {
            "use strict";
            n.d(t, {
                useControl: () => l
            });
            var o = n(69842),
                r = n(83836);

            function l(e) {
                const {
                    onFocus: t,
                    onBlur: n,
                    intent: l,
                    highlight: a,
                    disabled: i
                } = e, [s, c] = (0, r.useFocus)(void 0, i), u = (0, o.createSafeMulticastEventHandler)(i ? void 0 : c.onFocus, t), d = (0, o.createSafeMulticastEventHandler)(i ? void 0 : c.onBlur, n);
                return { ...e,
                    intent: l || (s ? "primary" : "default"),
                    highlight: null != a ? a : s,
                    onFocus: u,
                    onBlur: d
                }
            }
        },
        83836: (e, t, n) => {
            "use strict";
            n.d(t, {
                useFocus: () => r
            });
            var o = n(59496);

            function r(e, t) {
                const [n, r] = (0, o.useState)(!1);
                (0, o.useEffect)(() => {
                    t && n && r(!1)
                }, [t, n]);
                const l = {
                    onFocus: (0, o.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || r(!0)
                    }), [e]),
                    onBlur: (0, o.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || r(!1)
                    }), [e])
                };
                return [n, l]
            }
        },
        52130: (e, t, n) => {
            "use strict";
            n.d(t, {
                useIsMounted: () => r
            });
            var o = n(59496);
            const r = () => {
                const e = (0, o.useRef)(!1);
                return (0, o.useEffect)(() => (e.current = !0, () => {
                    e.current = !1
                }), []), e
            }
        },
        3548: (e, t, n) => {
            "use strict";
            n.d(t, {
                useIsMouseDown: () => r
            });
            var o = n(59496);

            function r() {
                const e = (0, o.useRef)(!1),
                    t = (0, o.useCallback)(() => {
                        e.current = !0
                    }, [e]),
                    n = (0, o.useCallback)(() => {
                        e.current = !1
                    }, [e]);
                return {
                    isMouseDown: e,
                    handleMouseDown: t,
                    handleMouseUp: n
                }
            }
        },
        28606: (e, t, n) => {
            "use strict";
            n.d(t, {
                useMergedRefs: () => r
            });
            var o = n(59496);

            function r(e) {
                return (0, o.useCallback)(function(e) {
                    return t => {
                        e.forEach(e => {
                            "function" == typeof e ? e(t) : null != e && (e.current = t)
                        })
                    }
                }(e), e)
            }
        },
        34404: (e, t, n) => {
            "use strict";
            n.d(t, {
                Loader: () => c
            });
            var o, r = n(59496),
                l = n(97754),
                a = n(49423),
                i = n(62092),
                s = n.n(i);
            ! function(e) {
                e[e.Initial = 0] = "Initial", e[e.Appear = 1] = "Appear", e[e.Active = 2] = "Active"
            }(o || (o = {}));
            class c extends r.PureComponent {
                constructor(e) {
                    super(e), this._stateChangeTimeout = null, this.state = {
                        state: o.Initial
                    }
                }
                render() {
                    const {
                        className: e,
                        color: t = "black",
                        size: n = "medium",
                        staticPosition: o
                    } = this.props, a = l(s().item, s()[t], s()[n]);
                    return r.createElement("span", {
                        className: l(s().loader, o && s().static, this._getStateClass(), e)
                    }, r.createElement("span", {
                        className: a
                    }), r.createElement("span", {
                        className: a
                    }), r.createElement("span", {
                        className: a
                    }))
                }
                componentDidMount() {
                    this.setState({
                        state: o.Appear
                    }), this._stateChangeTimeout = setTimeout(() => {
                        this.setState({
                            state: o.Active
                        })
                    }, 2 * a.dur)
                }
                componentWillUnmount() {
                    this._stateChangeTimeout && (clearTimeout(this._stateChangeTimeout), this._stateChangeTimeout = null)
                }
                _getStateClass() {
                    switch (this.state.state) {
                        case o.Initial:
                            return s()["loader-initial"];
                        case o.Appear:
                            return s()["loader-appear"];
                        default:
                            return ""
                    }
                }
            }
        },
        1811: (e, t, n) => {
            "use strict";

            function o(e) {
                null !== e && e.setSelectionRange(0, e.value.length)
            }
            n.d(t, {
                selectAllContent: () => o
            })
        },
        69842: (e, t, n) => {
            "use strict";

            function o(...e) {
                return t => {
                    for (const n of e) void 0 !== n && n(t)
                }
            }
            n.d(t, {
                createSafeMulticastEventHandler: () => o
            })
        },
        37350: (e, t, n) => {
            "use strict";
            n.d(t, {
                SimpleDialogContext: () => o
            });
            const o = n(59496).createContext({
                isSmallTablet: !1,
                dialogCloseHandler: () => {}
            })
        },
        80994: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                confirmModule: () => v,
                renameModule: () => C,
                showSimpleDialog: () => b,
                warningModule: () => w
            });
            var o = n(59496),
                r = n(25177),
                l = n(59878);

            function a(e) {
                return "html" in e ? {
                    html: e.html
                } : {
                    content: e.text
                }
            }
            var i = n(54936),
                s = n(37350),
                c = n(36045);

            function u(e) {
                const {
                    maxLength: t,
                    value: n,
                    placeholder: r,
                    onValueChange: l,
                    nameInputRef: a
                } = e, {
                    isSmallTablet: u
                } = (0, o.useContext)(s.SimpleDialogContext), d = o.useRef(null);
                return (0, o.useLayoutEffect)(() => {
                    d.current && d.current.select()
                }, []), o.createElement(o.Fragment, null, function() {
                    if ("content" in e) return o.createElement("div", {
                        className: c.label
                    }, e.content);
                    if ("html" in e) return o.createElement("div", {
                        className: c.label,
                        dangerouslySetInnerHTML: {
                            __html: e.html
                        }
                    });
                    return null
                }(), o.createElement(i.InputControl, {
                    inputClassName: c.input,
                    autoComplete: "no",
                    size: u ? "large" : void 0,
                    reference: function(e) {
                        d.current = e, a && (a.current = e)
                    },
                    value: n,
                    placeholder: r,
                    maxLength: t,
                    onChange: function(e) {
                        l(e.currentTarget.value)
                    }
                }))
            }

            function d(e) {
                return Boolean(e.trim())
            }

            function m(e) {
                const {
                    buttonText: t,
                    intentButton: n,
                    actions: o
                } = e, l = [{
                    name: "ok",
                    title: t || (0, r.t)("Ok"),
                    intent: n,
                    handler: ({
                        dialogClose: e
                    }) => {
                        e()
                    }
                }];
                return o && o.forEach(e => l.push(e)), l
            }
            var p = n(87995),
                g = n(88537),
                f = n(53327);
            const h = new(n(63192).DialogsOpenerManager);
            const v = function(e) {
                    const {
                        title: t,
                        onClose: n = (() => {}),
                        mainButtonText: i,
                        mainButtonIntent: s,
                        cancelButtonText: c,
                        closeOnOutsideClick: u,
                        onConfirm: d,
                        onCancel: m
                    } = e, p = a(e);
                    return o.createElement(l.SimpleDialog, { ...p,
                        title: t || (0, r.t)("Confirmation"),
                        onClose: n,
                        actions: [{
                            name: "yes",
                            title: i || (0, r.t)("Yes"),
                            intent: s || "success",
                            handler: d
                        }, {
                            name: "no",
                            title: c || (0, r.t)("No"),
                            appearance: "stroke",
                            intent: "default",
                            handler: e => {
                                m ? m(e) : e.dialogClose()
                            }
                        }],
                        dataName: "confirm-dialog",
                        closeOnOutsideClick: u
                    })
                },
                C = function(e) {
                    const {
                        title: t,
                        maxLength: n,
                        initValue: i,
                        placeholder: s,
                        onClose: c = (() => {}),
                        mainButtonText: m,
                        mainButtonIntent: p,
                        cancelButtonText: g,
                        validator: f = d,
                        onRename: h
                    } = e, v = (0, o.useRef)(null), [C, w] = (0, o.useState)(i || ""), [b, S] = (0, o.useState)(() => f(C)), y = a(e);
                    return o.createElement(l.SimpleDialog, {
                        title: t || (0, r.t)("Rename"),
                        content: o.createElement(u, { ...y,
                            nameInputRef: v,
                            maxLength: n,
                            placeholder: s,
                            value: C,
                            onValueChange: function(e) {
                                w(e), S(f(e))
                            }
                        }),
                        onClose: c,
                        actions: [{
                            disabled: !b,
                            name: "save",
                            title: m || (0, r.t)("Save"),
                            intent: p || "primary",
                            handler: ({
                                dialogClose: e,
                                innerManager: t
                            }) => h({
                                newValue: C,
                                focusInput: E,
                                dialogClose: e,
                                innerManager: t
                            })
                        }, {
                            name: "cancel",
                            title: g || (0, r.t)("Cancel"),
                            appearance: "stroke",
                            intent: "default",
                            handler: ({
                                dialogClose: e
                            }) => {
                                e()
                            }
                        }],
                        dataName: "rename-dialog"
                    });

                    function E() {
                        v.current && v.current.focus()
                    }
                },
                w = function(e) {
                    const {
                        title: t,
                        closeOnOutsideClick: n,
                        onClose: i = (() => {})
                    } = e, s = a(e);
                    return o.createElement(l.SimpleDialog, { ...s,
                        title: t || (0, r.t)("Warning"),
                        onClose: i,
                        actions: m(e),
                        dataName: "warning-dialog",
                        closeOnOutsideClick: n
                    })
                },
                b = function(e, t, n) {
                    const {
                        title: r
                    } = e, l = `${r}_${"text"in e?e.text:e.html}`;
                    if (h.isOpened(l)) return (0, g.ensureDefined)(h.getDialogPayload(l)).closeHandler;
                    const a = document.createElement("div"),
                        i = () => {
                            var t;
                            null === (t = e.onClose) || void 0 === t || t.call(e), p.unmountComponentAtNode(a), h.setAsClosed(l)
                        };
                    return p.render(o.createElement(f.SlotContext.Provider, {
                        value: n || null
                    }, o.createElement(t, { ...e,
                        onClose: i
                    })), a), h.setAsOpened(l, {
                        closeHandler: i
                    }), i
                }
        },
        59878: (e, t, n) => {
            "use strict";
            n.d(t, {
                SimpleDialog: () => E
            });
            var o = n(59496),
                r = n(97754),
                l = n(72571),
                a = n(59410),
                i = n(40766),
                s = n(80185),
                c = n(30052),
                u = n(6594),
                d = n(96038),
                m = n(42554),
                p = n(28599),
                g = n(34404),
                f = n(88537),
                h = n(52130),
                v = n(53327),
                C = n(37350),
                w = n(41227);

            function b(e) {
                const {
                    disabled: t,
                    name: n,
                    title: l,
                    appearance: a,
                    intent: i,
                    handler: s,
                    reference: c
                } = e, {
                    isSmallTablet: u,
                    dialogCloseHandler: d
                } = (0, o.useContext)(C.SimpleDialogContext), m = (0, f.ensureNotNull)((0, o.useContext)(v.SlotContext)), b = (0, h.useIsMounted)(), [S, y] = (0, o.useState)(!1);
                return o.createElement(p.Button, {
                    disabled: t,
                    reference: c,
                    className: r(w.actionButton, u && w.small),
                    name: n,
                    size: u ? "l" : void 0,
                    appearance: a,
                    intent: i,
                    onClick: function() {
                        if (S) return;
                        const e = s({
                            dialogClose: d,
                            innerManager: m
                        });
                        e && (y(!0), e.then(() => {
                            b.current && y(!1)
                        }))
                    }
                }, o.createElement("span", {
                    className: r(S && w.hiddenTitle)
                }, l), S && o.createElement(g.Loader, {
                    color: "white"
                }))
            }
            var S = n(35487),
                y = n(87992);

            function E(e) {
                const {
                    title: t,
                    onClose: n,
                    actions: p,
                    dataName: g,
                    popupDialogClassName: f,
                    backdrop: h,
                    closeOnOutsideClick: v = !0
                } = e;
                (0, o.useEffect)(() => (a.subscribe(u.CLOSE_POPUPS_AND_DIALOGS_COMMAND, n, null), () => {
                    a.unsubscribe(u.CLOSE_POPUPS_AND_DIALOGS_COMMAND, n, null)
                }), [n]);
                const [w, E] = (0, o.useState)(!0), k = (0, o.useRef)(null);
                return o.createElement(c.MatchMedia, {
                    rule: d.DialogBreakpoints.TabletSmall
                }, a => o.createElement(C.SimpleDialogContext.Provider, {
                    value: {
                        isSmallTablet: a,
                        dialogCloseHandler: n
                    }
                }, o.createElement(i.PopupDialog, {
                    className: r(y.popupDialog, f),
                    isOpened: w,
                    backdrop: h,
                    onClickBackdrop: M,
                    onClickOutside: v ? M : void 0,
                    onKeyDown: j,
                    autofocus: !0,
                    fixedBody: !0
                }, o.createElement("div", {
                    className: y.wrap,
                    "data-name": g
                }, o.createElement("div", {
                    className: r(y.main, a && y.small)
                }, o.createElement("div", {
                    className: r(y.title, a && y.small)
                }, t), function(t) {
                    if ("html" in e) return o.createElement(m.TouchScrollContainer, {
                        className: r(y.content, t && y.small, y.html),
                        dangerouslySetInnerHTML: {
                            __html: e.html
                        }
                    });
                    if ("content" in e) return o.createElement(m.TouchScrollContainer, {
                        className: r(y.content, t && y.small)
                    }, e.content);
                    return null
                }(a), p && p.length > 0 && o.createElement("div", {
                    className: r(y.footer, a && y.small)
                }, p.map((e, t) => o.createElement(b, { ...e,
                    key: e.name,
                    reference: 0 === t ? k : void 0
                })))), o.createElement(l.Icon, {
                    className: r(y.close, a && y.small),
                    icon: S,
                    onClick: M,
                    "data-name": "close",
                    "data-role": "button"
                })))));

                function j(e) {
                    switch ((0, s.hashFromEvent)(e)) {
                        case 27:
                            w && (e.preventDefault(), n());
                            break;
                        case 13:
                            if (w && p && p.length) {
                                e.preventDefault();
                                const t = k.current;
                                t && t.click()
                            }
                    }
                }

                function M() {
                    E(!1), n()
                }
            }
        },
        63192: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogsOpenerManager: () => o,
                dialogsOpenerManager: () => r
            });
            class o {
                constructor() {
                    this._storage = new Map
                }
                setAsOpened(e, t) {
                    this._storage.set(e, t)
                }
                setAsClosed(e) {
                    this._storage.delete(e)
                }
                isOpened(e) {
                    return this._storage.has(e)
                }
                getDialogPayload(e) {
                    return this._storage.get(e)
                }
            }
            const r = new o
        },
        42554: (e, t, n) => {
            "use strict";
            n.d(t, {
                TouchScrollContainer: () => i
            });
            var o = n(59496),
                r = n(59142),
                l = n(88537),
                a = n(1227);

            function i(e) {
                const {
                    reference: t,
                    children: n,
                    ...l
                } = e, i = (0, o.useRef)(null), c = (0, o.useCallback)(e => {
                    t && (t.current = e), a.CheckMobile.iOS() && (null !== i.current && (0, r.enableBodyScroll)(i.current), i.current = e, null !== i.current && (0, r.disableBodyScroll)(i.current, {
                        allowTouchMove: s(i)
                    }))
                }, [t]);
                return o.createElement("div", {
                    ref: c,
                    ...l
                }, n)
            }

            function s(e) {
                return t => {
                    const n = (0, l.ensureNotNull)(e.current),
                        o = document.activeElement;
                    return !n.contains(t) || null !== o && n.contains(o) && o.contains(t)
                }
            }
        }
    }
]);
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [731], {
        37593: e => {
            e.exports = {
                wrapper: "wrapper-5Xd5conM",
                input: "input-5Xd5conM",
                box: "box-5Xd5conM",
                icon: "icon-5Xd5conM",
                noOutline: "noOutline-5Xd5conM",
                "intent-danger": "intent-danger-5Xd5conM",
                check: "check-5Xd5conM",
                dot: "dot-5Xd5conM"
            }
        },
        2270: e => {
            e.exports = {
                button: "button-MtWCmkmc",
                bordersVisible: "bordersVisible-MtWCmkmc",
                selected: "selected-MtWCmkmc"
            }
        },
        72142: e => {
            e.exports = {
                footer: "footer-C0oTZgbU"
            }
        },
        86558: e => {
            e.exports = {
                wrap: "wrap-IVoYCPDG",
                header: "header-IVoYCPDG",
                item: "item-IVoYCPDG"
            }
        },
        74618: e => {
            e.exports = {
                label: "label-jkX9S6js"
            }
        },
        61257: e => {
            e.exports = {
                scrollable: "scrollable-JgZSADtd",
                spinnerWrap: "spinnerWrap-JgZSADtd",
                item: "item-JgZSADtd",
                heading: "heading-JgZSADtd",
                checkboxWrap: "checkboxWrap-JgZSADtd",
                checkbox: "checkbox-JgZSADtd",
                emptyState: "emptyState-JgZSADtd",
                image: "image-JgZSADtd",
                text: "text-JgZSADtd"
            }
        },
        20512: e => {
            e.exports = {
                dialog: "dialog-VLZxw4Dg",
                tablet: "tablet-VLZxw4Dg"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        8323: (e, t, o) => {
            "use strict";
            o.d(t, {
                CheckboxInput: () => i
            });
            var n = o(59496),
                a = o(97754),
                r = o(72571),
                l = o(57369),
                c = o(37593),
                s = o.n(c);

            function i(e) {
                const t = a(s().box, s()["intent-" + e.intent], {
                        [s().check]: !Boolean(e.indeterminate),
                        [s().dot]: Boolean(e.indeterminate),
                        [s().noOutline]: -1 === e.tabIndex
                    }),
                    o = a(s().wrapper, e.className);
                return n.createElement("span", {
                    className: o,
                    title: e.title
                }, n.createElement("input", {
                    id: e.id,
                    tabIndex: e.tabIndex,
                    className: s().input,
                    type: "checkbox",
                    name: e.name,
                    checked: e.checked,
                    disabled: e.disabled,
                    value: e.value,
                    autoFocus: e.autoFocus,
                    role: e.role,
                    onChange: function() {
                        e.onChange && e.onChange(e.value)
                    },
                    ref: e.reference
                }), n.createElement("span", {
                    className: t
                }, n.createElement(r.Icon, {
                    icon: l,
                    className: s().icon
                })))
            }
        },
        66171: (e, t, o) => {
            "use strict";
            o.d(t, {
                SymbolSearchDialogFooter: () => c
            });
            var n = o(59496),
                a = o(97754),
                r = o.n(a),
                l = o(72142);

            function c(e) {
                const {
                    className: t,
                    children: o
                } = e;
                return n.createElement("div", {
                    className: r()(l.footer, t)
                }, o)
            }
        },
        81748: (e, t, o) => {
            "use strict";
            o.r(t), o.d(t, {
                getCompareDialogRenderer: () => se
            });
            var n = o(59496),
                a = o(25177),
                r = o(72535),
                l = o(82527),
                c = o(40641),
                s = o(97754),
                i = o.n(s),
                d = o(7270),
                u = o.n(d),
                m = o(88537),
                p = o(72571),
                h = o(42554),
                v = o(97265),
                f = o(32455),
                b = o(51049),
                S = o(2054),
                g = o(44080),
                C = o(56871);
            const w = n.createContext(null);
            var x = o(21258),
                E = o(40976);
            const y = n.createContext(null);
            var I = o(92063),
                k = o(59339),
                M = o(63694),
                D = o(2270);

            function N(e) {
                const {
                    theme: t = D,
                    children: o,
                    onClick: a,
                    isSelected: r,
                    areBordersVisible: l,
                    isItemSelected: c,
                    className: s,
                    value: d,
                    name: u
                } = e;
                return n.createElement("button", {
                    type: "button",
                    className: i()(s, t.button, r && t.selected, l && !r && !c && t.bordersVisible),
                    name: u,
                    value: d,
                    onClick: a
                }, o)
            }

            function O(e) {
                const {
                    value: t,
                    onClick: o,
                    ...a
                } = e, r = (0, n.useCallback)(e => o(t, e), [t, o]);
                return n.createElement(N, { ...a,
                    value: String(t),
                    onClick: r
                })
            }
            var T = o(6519),
                A = o(86558);
            const _ = {
                sameScale: (0, a.t)("Same % scale"),
                newPriceScale: (0, a.t)("New price scale"),
                newPane: (0, a.t)("New pane")
            };

            function P(e) {
                const {
                    fullSymbolName: t,
                    isSelected: o,
                    className: r
                } = e, {
                    isMobile: l,
                    searchRef: s,
                    setMode: d
                } = (0, E.useEnsuredContext)(g.SymbolSearchItemsDialogContext), {
                    compareModel: u,
                    selectedCompareOption: m,
                    setHoveredItemId: p,
                    clearInput: h,
                    allowExtendTimeScale: v
                } = (0, E.useEnsuredContext)(w), {
                    callback: f
                } = (0, E.useEnsuredContext)(y);
                return l ? n.createElement(M.DrawerManager, null, n.createElement(k.Drawer, {
                    position: "Bottom",
                    onClose: b.bind(null, !1)
                }, n.createElement("div", {
                    className: A.header
                }, (0, a.t)("Add to")), n.createElement(I.PopupMenuItem, {
                    className: A.item,
                    onClick: S,
                    onClickArg: T.CompareOption.SameScale,
                    label: _.sameScale
                }), n.createElement(I.PopupMenuItem, {
                    className: A.item,
                    onClick: S,
                    onClickArg: T.CompareOption.NewPriceScale,
                    label: _.newPriceScale
                }), n.createElement(I.PopupMenuItem, {
                    className: A.item,
                    onClick: S,
                    onClickArg: T.CompareOption.NewPane,
                    label: _.newPane
                }))) : n.createElement("div", {
                    className: i()(A.wrap, r),
                    "data-name": "compare-buttons-group"
                }, n.createElement(O, {
                    onClick: S,
                    value: T.CompareOption.SameScale,
                    isItemSelected: Boolean(o),
                    isSelected: o && m === T.CompareOption.SameScale
                }, _.sameScale), n.createElement(O, {
                    onClick: S,
                    value: T.CompareOption.NewPriceScale,
                    isItemSelected: Boolean(o),
                    isSelected: o && m === T.CompareOption.NewPriceScale
                }, _.newPriceScale), n.createElement(O, {
                    onClick: S,
                    value: T.CompareOption.NewPane,
                    isItemSelected: Boolean(o),
                    isSelected: o && m === T.CompareOption.NewPane
                }, _.newPane));

                function b(e) {
                    l && f && f(), h && e && h(s, d)
                }

                function S(e, o) {
                    if (o.preventDefault(), u && t && void 0 !== e) {
                        (0, c.getSymbolSearchCompleteOverrideFunction)()(t).then(t => {
                            u.applyStudy(t, e, v), p(""), b(!0)
                        })
                    }
                }
            }

            function B(e) {
                const {
                    isSelected: t,
                    fullSymbolName: o,
                    onExpandClick: a,
                    actions: l,
                    id: s,
                    isOffset: i
                } = e, {
                    isMobile: d,
                    toggleExpand: u,
                    searchSpreads: m,
                    searchRef: p,
                    setMode: h,
                    mode: v
                } = (0, E.useEnsuredContext)(g.SymbolSearchItemsDialogContext), {
                    compareModel: f,
                    hoveredItemId: b,
                    setHoveredItemId: S,
                    clearInput: I,
                    allowExtendTimeScale: k
                } = (0, E.useEnsuredContext)(w), [M, D] = (0, n.useState)(!1), N = (0, n.useRef)(null), O = (0, x.useAccurateHover)(N), A = (0, n.useMemo)(() => ({
                    callback: z
                }), [z]), _ = !Boolean(a) && !Boolean(l), B = s === b;
                return n.createElement(y.Provider, {
                    value: A
                }, n.createElement(C.SymbolSearchDialogContentItem, {
                    hideMarkedListFlag: "compare" === v,
                    ...e,
                    reference: N,
                    onClick: function(t) {
                        if (Boolean(a) && s && !i) return t.preventDefault(), void u(s);
                        if (!M && d) return void D(!0);
                        if (m && e.onClick) return void e.onClick(t);
                        if ((r.mobiletouch ? B : !M) && o) {
                            (0, c.getSymbolSearchCompleteOverrideFunction)()(o).then(e => {
                                f.applyStudy(e, T.CompareOption.SameScale, k)
                            }), S(""), I && I(p, h)
                        }
                        r.mobiletouch && !d && !B && s && S(s)
                    },
                    hoverComponent: function() {
                        if (!_) return !1;
                        if (d) return M;
                        if (r.mobiletouch) return B;
                        return Boolean(O || t)
                    }() ? P : void 0
                }));

                function z() {
                    D(!1)
                }
            }
            var z = o(48768),
                H = o(57004),
                R = o(711),
                F = o(61257);

            function V(e) {
                const {
                    handleListWidth: t
                } = (0, m.ensureNotNull)((0, n.useContext)(g.SymbolSearchItemsDialogContext)), {
                    compareModel: o,
                    selectedCompareIndex: r,
                    selectedItemRef: l
                } = (0, m.ensureNotNull)((0, n.useContext)(w)), c = (0, v.useWatchedValueReadonly)({
                    watchedValue: o.isDataReady()
                }), s = (0, v.useWatchedValueReadonly)({
                    watchedValue: o.studies()
                }), d = (0, v.useWatchedValueReadonly)({
                    watchedValue: o.highlightedSymbol()
                }), x = (0, n.useMemo)(() => s.filter(e => e.checked), [s]), E = (0, n.useMemo)(() => s.filter(e => !e.checked), [s]);
                return (0, n.useEffect)(() => (o.chartModel().dataSourceCollectionChanged().subscribe(o, o.handleSourcesChange), () => o.chartModel().dataSourceCollectionChanged().unsubscribe(o, o.handleSourcesChange)), [o]), n.createElement(u(), {
                    onMeasure: function(e) {
                        t(e.width)
                    }
                }, n.createElement(h.TouchScrollContainer, {
                    className: F.scrollable
                }, function() {
                    if (!c) return n.createElement("div", {
                        className: F.spinnerWrap
                    }, n.createElement(f.Spinner, null));
                    if (!Boolean(x.length) && !Boolean(E.length)) {
                        const e = S.watchedTheme.value() === b.StdTheme.Dark ? H : z;
                        return n.createElement("div", {
                            className: F.emptyState
                        }, n.createElement(p.Icon, {
                            className: F.image,
                            icon: e
                        }), n.createElement("div", {
                            className: F.text
                        }, (0, a.t)("No symbols here yet — why not add some?")))
                    }
                    return n.createElement(n.Fragment, null, Boolean(x.length) && n.createElement(n.Fragment, null, n.createElement("div", {
                        className: F.heading
                    }, (0, a.t)("Added symbols")), x.map((e, t) => n.createElement(C.SymbolSearchDialogContentItem, {
                        "data-role": "added-symbol-item",
                        className: F.item,
                        key: e.id,
                        id: e.id,
                        shortName: e.title,
                        title: e.title,
                        logoId: e.logoId,
                        currencyLogoId: e.currencyLogoId,
                        baseCurrencyLogoId: e.baseCurrencyLogoId,
                        dangerousDescriptionHTML: e.description,
                        exchangeName: e.exchangeName,
                        marketType: e.marketType,
                        country: e.country,
                        providerId: e.providerId,
                        onClick: y.bind(null, e),
                        isHighlighted: e.id === d,
                        isSelected: I(e),
                        itemRef: I(e) ? l : void 0,
                        actions: n.createElement("div", {
                            className: F.checkboxWrap
                        }, n.createElement(N, {
                            className: F.checkbox,
                            onClick: y.bind(null, e),
                            isSelected: I(e)
                        }, n.createElement(p.Icon, {
                            icon: R
                        })))
                    }))), Boolean(E.length) && n.createElement(n.Fragment, null, n.createElement("div", {
                        className: F.heading
                    }, (0, a.t)("Recent symbols")), E.map(e => n.createElement(B, {
                        "data-role": "recent-symbol-item",
                        className: i()(F.item, e.id === d && F.highlighted),
                        key: e.id,
                        id: e.id,
                        shortName: e.title,
                        logoId: e.logoId,
                        currencyLogoId: e.currencyLogoId,
                        baseCurrencyLogoId: e.baseCurrencyLogoId,
                        title: e.title,
                        dangerousDescriptionHTML: e.description,
                        exchangeName: e.exchangeName,
                        marketType: e.marketType,
                        country: e.country,
                        providerId: e.providerId,
                        fullSymbolName: e.symbol,
                        isSelected: I(e),
                        itemRef: I(e) ? l : void 0
                    }))))
                }()));

                function y(e, t) {
                    t.preventDefault(), o.removeStudy(e)
                }

                function I(e) {
                    return s.indexOf(e) === r
                }
            }
            var L = o(70122);
            class W extends n.PureComponent {
                constructor(e) {
                    super(e), this._selectedItemRef = n.createRef(), this._getContextValue = () => {
                        const {
                            compareModel: e
                        } = this.props, {
                            selectedCompareOption: t,
                            selectedCompareIndex: o,
                            hoveredItemId: n,
                            allowExtendTimeScale: a
                        } = this.state;
                        return {
                            compareModel: e,
                            selectedCompareOption: t,
                            setSelectedCompareOption: this._setSelectedCompareOption,
                            hoveredItemId: n,
                            setHoveredItemId: this._setHoveredItemId,
                            selectedCompareIndex: o,
                            setSelectedCompareIndex: this._setSelectedCompareIndex,
                            selectedItemRef: this._selectedItemRef,
                            clearInput: this._clearInput,
                            allowExtendTimeScale: a,
                            toggleAllowExtendTimeScale: this._toggleAllowExtendTimeScale
                        }
                    }, this._clearInput = (e, t) => {
                        e && e.current && (e.current.value = "", t("compare"))
                    }, this._setSelectedCompareOption = e => {
                        this.setState({
                            selectedCompareOption: e
                        })
                    }, this._setHoveredItemId = e => {
                        this.setState({
                            hoveredItemId: e
                        })
                    }, this._setSelectedCompareIndex = (e, t) => {
                        this.setState({
                            selectedCompareIndex: e
                        }, t)
                    }, this._toggleAllowExtendTimeScale = () => {
                        const e = !this.state.allowExtendTimeScale;
                        L.setValue("showAddSymbolDialog.extendCheckboxState", e), this.setState({
                            allowExtendTimeScale: e
                        })
                    }, this.state = {
                        selectedCompareOption: 0,
                        selectedCompareIndex: -1,
                        hoveredItemId: void 0,
                        allowExtendTimeScale: Boolean(L.getBool("showAddSymbolDialog.extendCheckboxState"))
                    }
                }
                render() {
                    const {
                        children: e
                    } = this.props;
                    return n.createElement(w.Provider, {
                        value: this._getContextValue()
                    }, e)
                }
            }
            var G = o(80185),
                J = o(53337),
                Z = o(20512);
            const X = Object.keys(T.CompareOption).length / 2;

            function j(e) {
                const {
                    openedItems: t,
                    searchRef: o,
                    feedItems: a,
                    selectedIndex: r,
                    toggleExpand: l,
                    onSearchComplete: c,
                    mode: i,
                    setMode: d,
                    setSelectedIndex: u,
                    isMobile: m,
                    isTablet: p,
                    onClose: h,
                    upperCaseEnabled: f
                } = (0, E.useEnsuredContext)(g.SymbolSearchItemsDialogContext), {
                    compareModel: b,
                    hoveredItemId: S,
                    setHoveredItemId: C,
                    selectedCompareOption: x,
                    setSelectedCompareOption: y,
                    selectedCompareIndex: I,
                    setSelectedCompareIndex: k,
                    selectedItemRef: M,
                    clearInput: D,
                    allowExtendTimeScale: N
                } = (0, E.useEnsuredContext)(w), O = (0, v.useWatchedValueReadonly)({
                    watchedValue: b.studies()
                }), T = a[r], A = "compare" === i;
                return (0, n.useEffect)(() => {
                    S && C(""), I && k(-1)
                }, [i]), n.createElement(J.AdaptivePopupDialog, { ...e,
                    className: s(Z.dialog, !m && p && Z.tablet),
                    onKeyDown: function(e) {
                        var n;
                        const s = (0, G.hashFromEvent)(e),
                            i = A ? I : r,
                            u = A ? O : a;
                        switch (s) {
                            case 38:
                                if (e.preventDefault(), 0 === i) return;
                                if (-1 === i) return void _(0);
                                _(i - 1);
                                break;
                            case 40:
                                if (e.preventDefault(), i === u.length - 1) return;
                                _(i + 1);
                                break;
                            case 37:
                                {
                                    const o = B();
                                    if (o && t.has(o)) return e.preventDefault(), void l(o);
                                    if (!x || o) return;e.preventDefault(),
                                    y(x - 1);
                                    break
                                }
                            case 39:
                                {
                                    const o = B();
                                    if (o && !t.has(o)) return e.preventDefault(), void l(o);
                                    if (x === X - 1 || o) return;e.preventDefault(),
                                    y(x + 1);
                                    break
                                }
                            case 13:
                                {
                                    if (A) return void
                                    function() {
                                        if (-1 === I) return;
                                        const e = O[I];
                                        e.checked ? b.removeStudy(e) : b.applyStudy(e.symbol, x, N);
                                        k(-1)
                                    }();
                                    const t = B();
                                    if (t) return e.preventDefault(), void l(t);e.preventDefault();
                                    const a = null === (n = null == o ? void 0 : o.current) || void 0 === n ? void 0 : n.value.trim();a && D && (c([{
                                        symbol: f ? a.toUpperCase() : a,
                                        resolved: !1,
                                        compareOption: x,
                                        allowExtendTimeScale: N
                                    }]), D(o, d));
                                    break
                                }
                            case 27:
                                e.preventDefault(), h()
                        }
                    },
                    dataName: "compare-dialog",
                    draggable: !0
                });

                function _(e) {
                    A ? k(e, P) : u(e)
                }

                function P() {
                    var e;
                    null === (e = M.current) || void 0 === e || e.scrollIntoView({
                        block: "nearest"
                    })
                }

                function B() {
                    if (!T) return;
                    const {
                        id: e,
                        isOffset: t,
                        onExpandClick: o
                    } = T;
                    return !t && Boolean(o) && e ? e : void 0
                }
            }
            var Q = o(87995),
                U = o(27989),
                Y = o(155),
                K = (o(58323),
                    o(89014));
            class q extends K.DialogRenderer {
                constructor(e) {
                    super(), this._props = e
                }
                show() {
                    if (this.visible().value()) return;
                    const e = n.createElement(U.QuoteSessionContext.Provider, {
                        value: null
                    }, n.createElement(Y.SymbolSearchItemsDialog, { ...this._props,
                        initialMode: this._props.initialMode || "symbolSearch",
                        onClose: () => this.hide()
                    }));
                    Q.render(e, this._container), this._setVisibility(!0)
                }
                hide() {
                    var e, t;
                    Q.unmountComponentAtNode(this._container), this._visibility.setValue(!1), null === (t = (e = this._props).onClose) || void 0 === t || t.call(e)
                }
            }
            var $ = o(21167),
                ee = o(31862),
                te = o(59223);

            function oe(e) {
                const {
                    searchRef: t,
                    setMode: o
                } = (0, E.useEnsuredContext)(g.SymbolSearchItemsDialogContext), {
                    currentMode: a
                } = (0, E.useEnsuredContext)(te.SymbolSearchDialogBodyContext);
                return (0, n.useEffect)(() => {
                    const e = t.current;
                    if (e) return e.addEventListener("input", r), () => {
                        e && e.removeEventListener("input", r)
                    }
                }, []), n.createElement(ee.DialogSearch, { ...e
                });

                function r() {
                    var e, n, r, l;
                    t.current && a && ("compare" !== a.current || "" === (null === (n = null === (e = null == t ? void 0 : t.current) || void 0 === e ? void 0 : e.value) || void 0 === n ? void 0 : n.trim()) ? "symbolSearch" === a.current && "" === (null === (l = null === (r = null == t ? void 0 : t.current) || void 0 === r ? void 0 : r.value) || void 0 === l ? void 0 : l.trim()) && o("compare") : o("symbolSearch"))
                }
            }
            var ne = o(8323),
                ae = o(66171),
                re = o(74618);

            function le(e) {
                const {
                    allowExtendTimeScale: t,
                    toggleAllowExtendTimeScale: o
                } = (0, m.ensureNotNull)((0, n.useContext)(w));
                return n.createElement(ae.SymbolSearchDialogFooter, null, n.createElement("label", null, n.createElement(ne.CheckboxInput, {
                    checked: t,
                    value: t ? "on" : "off",
                    onChange: o
                }), n.createElement("span", {
                    className: re.label
                }, (0, a.t)("Allow extend time scale"))))
            }
            const ce = l.enabled("secondary_series_extend_time_scale");

            function se(e) {
                return new q({
                    wrapper: (t = e, e => n.createElement(W, { ...e,
                        compareModel: t
                    })),
                    dialog: j,
                    contentItem: B,
                    initialScreen: V,
                    searchInput: oe,
                    footer: ce ? n.createElement(le) : void 0,
                    initialMode: "compare",
                    dialogTitle: (0, a.t)("Compare symbol"),
                    autofocus: !r.mobiletouch,
                    dialogWidth: "fixed",
                    onSearchComplete: t => {
                        const {
                            compareOption: o,
                            allowExtendTimeScale: n
                        } = t[0];
                        if (void 0 !== o) {
                            (0, c.getSymbolSearchCompleteOverrideFunction)()(t[0].symbol).then(t => {
                                e.applyStudy(t, o, n)
                            })
                        }
                    },
                    symbolTypes: (0, $.getAvailableSymbolTypes)(),
                    showSpreadActions: l.enabled("show_spread_operators") && l.enabled("compare_symbol_search_spread_operators")
                });
                var t
            }
        },
        6519: (e, t, o) => {
            "use strict";
            var n;
            o.d(t, {
                    CompareOption: () => n
                }),
                function(e) {
                    e[e.SameScale = 0] = "SameScale", e[e.NewPriceScale = 1] = "NewPriceScale", e[e.NewPane = 2] = "NewPane"
                }(n || (n = {}))
        },
        63694: (e, t, o) => {
            "use strict";
            o.d(t, {
                DrawerManager: () => a,
                DrawerContext: () => r
            });
            var n = o(59496);
            class a extends n.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return n.createElement(r.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const r = n.createContext(null)
        },
        59339: (e, t, o) => {
            "use strict";
            o.d(t, {
                Drawer: () => p
            });
            var n = o(59496),
                a = o(88537),
                r = o(97754),
                l = o(59142),
                c = o(85089),
                s = o(8361),
                i = o(63694),
                d = o(1227),
                u = o(28466),
                m = o(66998);

            function p(e) {
                const {
                    position: t = "Bottom",
                    onClose: o,
                    children: p,
                    className: h,
                    theme: v = m
                } = e, f = (0, a.ensureNotNull)((0, n.useContext)(i.DrawerContext)), [b, S] = (0, n.useState)(0), g = (0, n.useRef)(null), C = (0, n.useContext)(u.CloseDelegateContext);
                return (0, n.useEffect)(() => {
                    const e = (0, a.ensureNotNull)(g.current);
                    return e.focus({
                        preventScroll: !0
                    }), C.subscribe(f, o), 0 === f.currentDrawer && (0, c.setFixedBodyState)(!0), d.CheckMobile.iOS() && (0, l.disableBodyScroll)(e), S(f.addDrawer()), () => {
                        C.unsubscribe(f, o);
                        const t = f.removeDrawer();
                        d.CheckMobile.iOS() && (0, l.enableBodyScroll)(e), 0 === t && (0, c.setFixedBodyState)(!1)
                    }
                }, []), n.createElement(s.Portal, null, n.createElement("div", {
                    className: r(m.wrap, m["position" + t])
                }, b === f.currentDrawer && n.createElement("div", {
                    className: m.backdrop,
                    onClick: o
                }), n.createElement("div", {
                    className: r(m.drawer, v.drawer, m["position" + t], h),
                    ref: g,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, p)))
            }
        },
        21258: (e, t, o) => {
            "use strict";
            o.d(t, {
                hoverMouseEventFilter: () => r,
                useAccurateHover: () => l,
                useHover: () => a
            });
            var n = o(59496);

            function a() {
                const [e, t] = (0, n.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        r(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        r(e) && t(!1)
                    }
                }]
            }

            function r(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function l(e) {
                const [t, o] = (0, n.useState)(!1);
                return (0, n.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const n = e.current.contains(t.target);
                        o(n)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        92063: (e, t, o) => {
            "use strict";
            o.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => i,
                PopupMenuItem: () => m
            });
            var n = o(59496),
                a = o(97754),
                r = o(70981),
                l = o(32133),
                c = o(417),
                s = o(23576);
            const i = s;

            function d(e) {
                const {
                    reference: t,
                    ...o
                } = e, a = { ...o,
                    ref: t
                };
                return n.createElement(e.href ? "a" : "div", a)
            }

            function u(e) {
                e.stopPropagation()
            }

            function m(e) {
                const {
                    id: t,
                    role: o,
                    "aria-selected": i,
                    className: m,
                    title: p,
                    labelRowClassName: h,
                    labelClassName: v,
                    shortcut: f,
                    forceShowShortcuts: b,
                    icon: S,
                    isActive: g,
                    isDisabled: C,
                    isHovered: w,
                    appearAsDisabled: x,
                    label: E,
                    link: y,
                    showToolboxOnHover: I,
                    target: k,
                    rel: M,
                    toolbox: D,
                    reference: N,
                    onMouseOut: O,
                    onMouseOver: T,
                    suppressToolboxClick: A = !0,
                    theme: _ = s
                } = e, P = (0, c.filterDataProps)(e), B = (0, n.useRef)(null);
                return n.createElement(d, { ...P,
                    id: t,
                    role: o,
                    "aria-selected": i,
                    className: a(m, _.item, S && _.withIcon, {
                        [_.isActive]: g,
                        [_.isDisabled]: C || x,
                        [_.hovered]: w
                    }),
                    title: p,
                    href: y,
                    target: k,
                    rel: M,
                    reference: function(e) {
                        B.current = e, "function" == typeof N && N(e);
                        "object" == typeof N && (N.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: o,
                            onClick: n,
                            onClickArg: a,
                            trackEventObject: c
                        } = e;
                        if (C) return;
                        c && (0, l.trackEvent)(c.category, c.event, c.label);
                        n && n(a, t);
                        o || (0, r.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: o,
                            trackRightClick: n
                        } = e;
                        o && n && (0, l.trackEvent)(o.category, o.event, o.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: o,
                            trackMouseWheelClick: n
                        } = e;
                        if (1 === t.button && y && o) {
                            let e = o.label;
                            n && (e += "_mouseWheelClick"), (0, l.trackEvent)(o.category, o.event, e)
                        }
                    },
                    onMouseOver: T,
                    onMouseOut: O
                }, void 0 !== S && n.createElement("div", {
                    className: _.icon,
                    dangerouslySetInnerHTML: {
                        __html: S
                    }
                }), n.createElement("div", {
                    className: a(_.labelRow, h)
                }, n.createElement("div", {
                    className: a(_.label, v)
                }, E)), (void 0 !== f || b) && n.createElement("div", {
                    className: _.shortcut
                }, (z = f) && z.split("+").join(" + ")), void 0 !== D && n.createElement("div", {
                    onClick: A ? u : void 0,
                    className: a(_.toolbox, {
                        [_.showOnHover]: I
                    })
                }, D));
                var z
            }
        },
        28466: (e, t, o) => {
            "use strict";
            o.d(t, {
                CloseDelegateContext: () => r
            });
            var n = o(59496),
                a = o(70981);
            const r = n.createContext(a.globalCloseDelegate)
        },
        42554: (e, t, o) => {
            "use strict";
            o.d(t, {
                TouchScrollContainer: () => c
            });
            var n = o(59496),
                a = o(59142),
                r = o(88537),
                l = o(1227);

            function c(e) {
                const {
                    reference: t,
                    children: o,
                    ...r
                } = e, c = (0, n.useRef)(null), i = (0, n.useCallback)(e => {
                    t && (t.current = e), l.CheckMobile.iOS() && (null !== c.current && (0, a.enableBodyScroll)(c.current), c.current = e, null !== c.current && (0, a.disableBodyScroll)(c.current, {
                        allowTouchMove: s(c)
                    }))
                }, [t]);
                return n.createElement("div", {
                    ref: i,
                    ...r
                }, o)
            }

            function s(e) {
                return t => {
                    const o = (0, r.ensureNotNull)(e.current),
                        n = document.activeElement;
                    return !o.contains(t) || null !== n && o.contains(n) && n.contains(t)
                }
            }
        },
        57369: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 9" width="11" height="9" fill="none"><path stroke-width="2" d="M0.999878 4L3.99988 7L9.99988 1"/></svg>'
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        711: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" stroke-linecap="round" stroke-width="1.5" d="M7 15l5 5L23 9"/></svg>'
        },
        57004: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 121 120" width="121" height="120"><path fill="#D1D4DC" d="M53.88 18.36a43.4 43.4 0 0 1 11.24 0 1 1 0 0 0 .26-1.98 45.42 45.42 0 0 0-11.76 0 1 1 0 1 0 .26 1.98zM43.04 21.26a1 1 0 0 0-.77-1.85A44.95 44.95 0 0 0 32.1 25.3a1 1 0 0 0 1.22 1.58 42.95 42.95 0 0 1 9.72-5.62zM75.42 19.96a1 1 0 0 1 1.3-.55A44.95 44.95 0 0 1 86.9 25.3a1 1 0 0 1-1.22 1.58 42.95 42.95 0 0 0-9.72-5.62 1 1 0 0 1-.54-1.3zM25.38 34.82a1 1 0 1 0-1.58-1.22 44.95 44.95 0 0 0-5.89 10.17 1 1 0 0 0 1.85.77 42.95 42.95 0 0 1 5.62-9.72zM16.86 55.38a1 1 0 0 0-1.98-.26 45.42 45.42 0 0 0 0 11.76 1 1 0 1 0 1.98-.26 43.4 43.4 0 0 1 0-11.24zM103 54.26a1 1 0 0 1 1.12.86 45.4 45.4 0 0 1 0 11.76 1 1 0 0 1-1.98-.26 43.37 43.37 0 0 0 0-11.24 1 1 0 0 1 .86-1.12zM19.76 77.46a1 1 0 0 0-1.85.77A44.95 44.95 0 0 0 23.8 88.4a1 1 0 0 0 1.58-1.22 42.95 42.95 0 0 1-5.62-9.72zM100.54 76.92a1 1 0 0 1 .54 1.3A44.95 44.95 0 0 1 95.2 88.4a1 1 0 0 1-1.58-1.22 42.95 42.95 0 0 0 5.62-9.72 1 1 0 0 1 1.3-.54zM33.32 95.12a1 1 0 1 0-1.22 1.58 44.94 44.94 0 0 0 10.17 5.88 1 1 0 0 0 .77-1.84 42.97 42.97 0 0 1-9.72-5.62zM87.08 95.3a1 1 0 0 1-.18 1.4 44.94 44.94 0 0 1-10.17 5.88 1 1 0 0 1-.77-1.84 42.98 42.98 0 0 0 9.72-5.62 1 1 0 0 1 1.4.18zM53.88 103.64a1 1 0 0 0-.26 1.98 45.4 45.4 0 0 0 11.76 0 1 1 0 0 0-.26-1.98 43.37 43.37 0 0 1-11.24 0zM62.81 53.17a1 1 0 0 0-.78 1.84 6.62 6.62 0 0 1 3.49 3.5 1 1 0 1 0 1.84-.78 8.62 8.62 0 0 0-4.55-4.56z"/><path fill="#D1D4DC" d="M45.5 61a14 14 0 1 1 24.28 9.5l7.92 7.92a1 1 0 0 1-1.42 1.42l-7.96-7.97A14 14 0 0 1 45.5 61zm14-12a12 12 0 1 0 0 24 12 12 0 0 0 0-24z"/><circle fill="#1976D2" cx="97.5" cy="39" r="13"/><path fill="#D1D4DC" d="M98.5 34a1 1 0 1 0-2 0v4h-4a1 1 0 1 0 0 2h4v4a1 1 0 1 0 2 0v-4h4a1 1 0 0 0 0-2h-4v-4z"/></svg>'
        },
        48768: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 121 120" width="121" height="120"><path fill="#1E222D" d="M53.88 18.36a43.4 43.4 0 0 1 11.24 0 1 1 0 0 0 .26-1.98 45.42 45.42 0 0 0-11.76 0 1 1 0 1 0 .26 1.98zM43.04 21.26a1 1 0 0 0-.77-1.85A44.95 44.95 0 0 0 32.1 25.3a1 1 0 0 0 1.22 1.58 42.95 42.95 0 0 1 9.72-5.62zM75.42 19.96a1 1 0 0 1 1.3-.55A44.95 44.95 0 0 1 86.9 25.3a1 1 0 0 1-1.22 1.58 42.95 42.95 0 0 0-9.72-5.62 1 1 0 0 1-.54-1.3zM25.38 34.82a1 1 0 1 0-1.58-1.22 44.95 44.95 0 0 0-5.89 10.17 1 1 0 0 0 1.85.77 42.95 42.95 0 0 1 5.62-9.72zM16.86 55.38a1 1 0 0 0-1.98-.26 45.42 45.42 0 0 0 0 11.76 1 1 0 1 0 1.98-.26 43.4 43.4 0 0 1 0-11.24zM103 54.26a1 1 0 0 1 1.12.86 45.4 45.4 0 0 1 0 11.76 1 1 0 0 1-1.98-.26 43.37 43.37 0 0 0 0-11.24 1 1 0 0 1 .86-1.12zM19.76 77.46a1 1 0 0 0-1.85.77A44.95 44.95 0 0 0 23.8 88.4a1 1 0 0 0 1.58-1.22 42.95 42.95 0 0 1-5.62-9.72zM100.54 76.92a1 1 0 0 1 .54 1.3A44.95 44.95 0 0 1 95.2 88.4a1 1 0 0 1-1.58-1.22 42.95 42.95 0 0 0 5.62-9.72 1 1 0 0 1 1.3-.54zM33.32 95.12a1 1 0 1 0-1.22 1.58 44.94 44.94 0 0 0 10.17 5.88 1 1 0 0 0 .77-1.84 42.97 42.97 0 0 1-9.72-5.62zM87.08 95.3a1 1 0 0 1-.18 1.4 44.94 44.94 0 0 1-10.17 5.88 1 1 0 0 1-.77-1.84 42.98 42.98 0 0 0 9.72-5.62 1 1 0 0 1 1.4.18zM53.88 103.64a1 1 0 0 0-.26 1.98 45.4 45.4 0 0 0 11.76 0 1 1 0 0 0-.26-1.98 43.37 43.37 0 0 1-11.24 0zM62.81 53.17a1 1 0 0 0-.78 1.84 6.62 6.62 0 0 1 3.49 3.5 1 1 0 1 0 1.84-.78 8.62 8.62 0 0 0-4.55-4.56z"/><path fill="#1E222D" d="M45.5 61a14 14 0 1 1 24.28 9.5l7.92 7.92a1 1 0 0 1-1.42 1.42l-7.96-7.97A14 14 0 0 1 45.5 61zm14-12a12 12 0 1 0 0 24 12 12 0 0 0 0-24z"/><circle fill="#2196F3" cx="97.5" cy="39" r="13"/><path fill="#fff" d="M98.5 34a1 1 0 1 0-2 0v4h-4a1 1 0 1 0 0 2h4v4a1 1 0 1 0 2 0v-4h4a1 1 0 0 0 0-2h-4v-4z"/></svg>'
        }
    }
]);
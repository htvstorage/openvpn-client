(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [1754], {
        66783: e => {
            "use strict";
            var t = Object.prototype.hasOwnProperty;

            function n(e, t) {
                return e === t ? 0 !== e || 0 !== t || 1 / e == 1 / t : e != e && t != t
            }
            e.exports = function(e, r) {
                if (n(e, r)) return !0;
                if ("object" != typeof e || null === e || "object" != typeof r || null === r) return !1;
                var o = Object.keys(e),
                    i = Object.keys(r);
                if (o.length !== i.length) return !1;
                for (var a = 0; a < o.length; a++)
                    if (!t.call(r, o[a]) || !n(e[o[a]], r[o[a]])) return !1;
                return !0
            }
        },
        75544: e => {
            e.exports = {
                dialog: "dialog-mRqoJfke",
                tabletDialog: "tabletDialog-mRqoJfke",
                desktopDialog: "desktopDialog-mRqoJfke"
            }
        },
        30608: e => {
            e.exports = {
                button: "button-IulLF4sY",
                disabled: "disabled-IulLF4sY"
            }
        },
        7270: function(e, t, n) {
            var r, o, i;
            e.exports = (r = n(59496), o = n(87995), i = n(59255), function(e) {
                function t(r) {
                    if (n[r]) return n[r].exports;
                    var o = n[r] = {
                        exports: {},
                        id: r,
                        loaded: !1
                    };
                    return e[r].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports
                }
                var n = {};
                return t.m = e, t.c = n, t.p = "dist/", t(0)
            }([function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(1));
                t.default = r.default, e.exports = t.default
            }, function(e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var o = function() {
                        function e(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                            }
                        }
                        return function(t, n, r) {
                            return n && e(t.prototype, n), r && e(t, r), t
                        }
                    }(),
                    i = n(2),
                    a = (r(i), n(3)),
                    s = r(a),
                    u = r(n(13)),
                    l = r(n(14)),
                    c = r(n(15)),
                    f = function(e) {
                        function t(e) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, t);
                            var n = function(e, t) {
                                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !t || "object" != typeof t && "function" != typeof t ? e : t
                            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                            return n.measure = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.props.includeMargin;
                                if (n.props.shouldMeasure) {
                                    n._node.parentNode || n._setDOMNode();
                                    var t = n.getDimensions(n._node, e),
                                        r = "function" == typeof n.props.children;
                                    n._propsToMeasure.some((function(e) {
                                        if (t[e] !== n._lastDimensions[e]) return n.props.onMeasure(t), r && void 0 !== n && n.setState({
                                            dimensions: t
                                        }), n._lastDimensions = t, !0
                                    }))
                                }
                            }, n.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, n._node = null, n._propsToMeasure = n._getPropsToMeasure(e), n._lastDimensions = {}, n
                        }
                        return function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                        }(t, e), o(t, [{
                            key: "componentDidMount",
                            value: function() {
                                var e = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new l.default((function() {
                                    return e.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(e) {
                                var t = (e.config, e.whitelist),
                                    n = e.blacklist;
                                this.props.whitelist === t && this.props.blacklist === n || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: t,
                                    blacklist: n
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = u.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, c.default)(e, {
                                    margin: t
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(e) {
                                var t = e.whitelist,
                                    n = e.blacklist;
                                return t.filter((function(e) {
                                    return n.indexOf(e) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.props.children;
                                return i.Children.only("function" == typeof e ? e(this.state.dimensions) : e)
                            }
                        }]), t
                    }(i.Component);
                f.propTypes = {
                    whitelist: s.default.array,
                    blacklist: s.default.array,
                    includeMargin: s.default.bool,
                    useClone: s.default.bool,
                    cloneOptions: s.default.object,
                    shouldMeasure: s.default.bool,
                    onMeasure: s.default.func
                }, f.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, t.default = f, e.exports = t.default
            }, function(e, t) {
                e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) {
                        var o = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        e.exports = n(5)((function(e) {
                            return "object" === (void 0 === e ? "undefined" : r(e)) && null !== e && e.$$typeof === o
                        }), !0)
                    } else e.exports = n(12)()
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n() {
                    throw new Error("setTimeout has not been defined")
                }

                function r() {
                    throw new Error("clearTimeout has not been defined")
                }

                function o(e) {
                    if (l === setTimeout) return setTimeout(e, 0);
                    if ((l === n || !l) && setTimeout) return l = setTimeout, setTimeout(e, 0);
                    try {
                        return l(e, 0)
                    } catch (t) {
                        try {
                            return l.call(null, e, 0)
                        } catch (t) {
                            return l.call(this, e, 0)
                        }
                    }
                }

                function i() {
                    h && p && (h = !1, p.length ? d = p.concat(d) : m = -1, d.length && a())
                }

                function a() {
                    if (!h) {
                        var e = o(i);
                        h = !0;
                        for (var t = d.length; t;) {
                            for (p = d, d = []; ++m < t;) p && p[m].run();
                            m = -1, t = d.length
                        }
                        p = null, h = !1,
                            function(e) {
                                if (c === clearTimeout) return clearTimeout(e);
                                if ((c === r || !c) && clearTimeout) return c = clearTimeout, clearTimeout(e);
                                try {
                                    c(e)
                                } catch (t) {
                                    try {
                                        return c.call(null, e)
                                    } catch (t) {
                                        return c.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function s(e, t) {
                    this.fun = e, this.array = t
                }

                function u() {}
                var l, c, f = e.exports = {};
                ! function() {
                    try {
                        l = "function" == typeof setTimeout ? setTimeout : n
                    } catch (e) {
                        l = n
                    }
                    try {
                        c = "function" == typeof clearTimeout ? clearTimeout : r
                    } catch (e) {
                        c = r
                    }
                }();
                var p, d = [],
                    h = !1,
                    m = -1;
                f.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    d.push(new s(e, t)), 1 !== d.length || h || o(a)
                }, s.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, f.title = "browser", f.browser = !0, f.env = {}, f.argv = [], f.version = "", f.versions = {}, f.on = u, f.addListener = u, f.once = u, f.off = u, f.removeListener = u, f.removeAllListeners = u, f.emit = u, f.prependListener = u, f.prependOnceListener = u, f.listeners = function(e) {
                    return []
                }, f.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, f.cwd = function() {
                    return "/"
                }, f.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, f.umask = function() {
                    return 0
                }
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        },
                        o = n(6),
                        i = n(7),
                        a = n(8),
                        s = n(9),
                        u = n(10),
                        l = n(11);
                    e.exports = function(e, n) {
                        function c(e, t) {
                            return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
                        }

                        function f(e) {
                            this.message = e, this.stack = ""
                        }

                        function p(e) {
                            function r(r, l, c, p, d, h, m) {
                                if (p = p || w, h = h || c, m !== u)
                                    if (n) i(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== t.env.NODE_ENV && "undefined" != typeof console) {
                                    var y = p + ":" + c;
                                    !o[y] && s < 3 && (a(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", h, p), o[y] = !0, s++)
                                }
                                return null == l[c] ? r ? new f(null === l[c] ? "The " + d + " `" + h + "` is marked as required in `" + p + "`, but its value is `null`." : "The " + d + " `" + h + "` is marked as required in `" + p + "`, but its value is `undefined`.") : null : e(l, c, p, d, h)
                            }
                            if ("production" !== t.env.NODE_ENV) var o = {},
                                s = 0;
                            var l = r.bind(null, !1);
                            return l.isRequired = r.bind(null, !0), l
                        }

                        function d(e) {
                            return p((function(t, n, r, o, i, a) {
                                var s = t[n];
                                return m(s) !== e ? new f("Invalid " + o + " `" + i + "` of type `" + y(s) + "` supplied to `" + r + "`, expected `" + e + "`.") : null
                            }))
                        }

                        function h(t) {
                            switch (void 0 === t ? "undefined" : r(t)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !t;
                                case "object":
                                    if (Array.isArray(t)) return t.every(h);
                                    if (null === t || e(t)) return !0;
                                    var n = function(e) {
                                        var t = e && (b && e[b] || e[g]);
                                        if ("function" == typeof t) return t
                                    }(t);
                                    if (!n) return !1;
                                    var o, i = n.call(t);
                                    if (n !== t.entries) {
                                        for (; !(o = i.next()).done;)
                                            if (!h(o.value)) return !1
                                    } else
                                        for (; !(o = i.next()).done;) {
                                            var a = o.value;
                                            if (a && !h(a[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function m(e) {
                            var t = void 0 === e ? "undefined" : r(e);
                            return Array.isArray(e) ? "array" : e instanceof RegExp ? "object" : function(e, t) {
                                return "symbol" === e || "Symbol" === t["@@toStringTag"] || "function" == typeof Symbol && t instanceof Symbol
                            }(t, e) ? "symbol" : t
                        }

                        function y(e) {
                            if (null == e) return "" + e;
                            var t = m(e);
                            if ("object" === t) {
                                if (e instanceof Date) return "date";
                                if (e instanceof RegExp) return "regexp"
                            }
                            return t
                        }

                        function v(e) {
                            var t = y(e);
                            switch (t) {
                                case "array":
                                case "object":
                                    return "an " + t;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + t;
                                default:
                                    return t
                            }
                        }
                        var b = "function" == typeof Symbol && Symbol.iterator,
                            g = "@@iterator",
                            w = "<<anonymous>>",
                            S = {
                                array: d("array"),
                                bool: d("boolean"),
                                func: d("function"),
                                number: d("number"),
                                object: d("object"),
                                string: d("string"),
                                symbol: d("symbol"),
                                any: p(o.thatReturnsNull),
                                arrayOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new f("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside arrayOf.");
                                        var a = t[n];
                                        if (!Array.isArray(a)) return new f("Invalid " + o + " `" + i + "` of type `" + m(a) + "` supplied to `" + r + "`, expected an array.");
                                        for (var s = 0; s < a.length; s++) {
                                            var l = e(a, s, r, o, i + "[" + s + "]", u);
                                            if (l instanceof Error) return l
                                        }
                                        return null
                                    }))
                                },
                                element: p((function(t, n, r, o, i) {
                                    var a = t[n];
                                    return e(a) ? null : new f("Invalid " + o + " `" + i + "` of type `" + m(a) + "` supplied to `" + r + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if (!(t[n] instanceof e)) {
                                            var a = e.name || w;
                                            return new f("Invalid " + o + " `" + i + "` of type `" + function(e) {
                                                return e.constructor && e.constructor.name ? e.constructor.name : w
                                            }(t[n]) + "` supplied to `" + r + "`, expected instance of `" + a + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: p((function(e, t, n, r, o) {
                                    return h(e[t]) ? null : new f("Invalid " + r + " `" + o + "` supplied to `" + n + "`, expected a ReactNode.")
                                })),
                                objectOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new f("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside objectOf.");
                                        var a = t[n],
                                            s = m(a);
                                        if ("object" !== s) return new f("Invalid " + o + " `" + i + "` of type `" + s + "` supplied to `" + r + "`, expected an object.");
                                        for (var l in a)
                                            if (a.hasOwnProperty(l)) {
                                                var c = e(a, l, r, o, i + "." + l, u);
                                                if (c instanceof Error) return c
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(e) {
                                    return Array.isArray(e) ? p((function(t, n, r, o, i) {
                                        for (var a = t[n], s = 0; s < e.length; s++)
                                            if (c(a, e[s])) return null;
                                        return new f("Invalid " + o + " `" + i + "` of value `" + a + "` supplied to `" + r + "`, expected one of " + JSON.stringify(e) + ".")
                                    })) : ("production" !== t.env.NODE_ENV && a(!1, "Invalid argument supplied to oneOf, expected an instance of array."), o.thatReturnsNull)
                                },
                                oneOfType: function(e) {
                                    if (!Array.isArray(e)) return "production" !== t.env.NODE_ENV && a(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), o.thatReturnsNull;
                                    for (var n = 0; n < e.length; n++) {
                                        var r = e[n];
                                        if ("function" != typeof r) return a(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", v(r), n), o.thatReturnsNull
                                    }
                                    return p((function(t, n, r, o, i) {
                                        for (var a = 0; a < e.length; a++)
                                            if (null == (0, e[a])(t, n, r, o, i, u)) return null;
                                        return new f("Invalid " + o + " `" + i + "` supplied to `" + r + "`.")
                                    }))
                                },
                                shape: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var a = t[n],
                                            s = m(a);
                                        if ("object" !== s) return new f("Invalid " + o + " `" + i + "` of type `" + s + "` supplied to `" + r + "`, expected `object`.");
                                        for (var l in e) {
                                            var c = e[l];
                                            if (c) {
                                                var p = c(a, l, r, o, i + "." + l, u);
                                                if (p) return p
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var a = t[n],
                                            l = m(a);
                                        if ("object" !== l) return new f("Invalid " + o + " `" + i + "` of type `" + l + "` supplied to `" + r + "`, expected `object`.");
                                        var c = s({}, t[n], e);
                                        for (var p in c) {
                                            var d = e[p];
                                            if (!d) return new f("Invalid " + o + " `" + i + "` key `" + p + "` supplied to `" + r + "`.\nBad object: " + JSON.stringify(t[n], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(e), null, "  "));
                                            var h = d(a, p, r, o, i + "." + p, u);
                                            if (h) return h
                                        }
                                        return null
                                    }))
                                }
                            };
                        return f.prototype = Error.prototype, S.checkPropTypes = l, S.PropTypes = S, S
                    }
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    return function() {
                        return e
                    }
                }
                var r = function() {};
                r.thatReturns = n, r.thatReturnsFalse = n(!1), r.thatReturnsTrue = n(!0), r.thatReturnsNull = n(null), r.thatReturnsThis = function() {
                    return this
                }, r.thatReturnsArgument = function(e) {
                    return e
                }, e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var n = function(e) {};
                    "production" !== t.env.NODE_ENV && (n = function(e) {
                        if (void 0 === e) throw new Error("invariant requires an error message argument")
                    }), e.exports = function(e, t, r, o, i, a, s, u) {
                        if (n(t), !e) {
                            var l;
                            if (void 0 === t) l = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var c = [r, o, i, a, s, u],
                                    f = 0;
                                (l = new Error(t.replace(/%s/g, (function() {
                                    return c[f++]
                                })))).name = "Invariant Violation"
                            }
                            throw l.framesToPop = 1, l
                        }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = n(6);
                    if ("production" !== t.env.NODE_ENV) {
                        var o = function(e) {
                            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            var o = 0,
                                i = "Warning: " + e.replace(/%s/g, (function() {
                                    return n[o++]
                                }));
                            "undefined" != typeof console && console.error(i);
                            try {
                                throw new Error(i)
                            } catch (e) {}
                        };
                        r = function(e, t) {
                            if (void 0 === t) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== t.indexOf("Failed Composite propType: ") && !e) {
                                for (var n = arguments.length, r = Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                                o.apply(void 0, [t].concat(r))
                            }
                        }
                    }
                    e.exports = r
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }
                var r = Object.getOwnPropertySymbols,
                    o = Object.prototype.hasOwnProperty,
                    i = Object.prototype.propertyIsEnumerable;
                e.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var e = new String("abc");
                        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
                        if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                                return t[e]
                            })).join("")) return !1;
                        var r = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                            r[e] = e
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
                    } catch (e) {
                        return !1
                    }
                }() ? Object.assign : function(e, t) {
                    for (var a, s, u = n(e), l = 1; l < arguments.length; l++) {
                        for (var c in a = Object(arguments[l])) o.call(a, c) && (u[c] = a[c]);
                        if (r) {
                            s = r(a);
                            for (var f = 0; f < s.length; f++) i.call(a, s[f]) && (u[s[f]] = a[s[f]])
                        }
                    }
                    return u
                }
            }, function(e, t) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) var o = n(7),
                        i = n(8),
                        a = n(10),
                        s = {};
                    e.exports = function(e, n, u, l, c) {
                        if ("production" !== t.env.NODE_ENV)
                            for (var f in e)
                                if (e.hasOwnProperty(f)) {
                                    var p;
                                    try {
                                        o("function" == typeof e[f], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", l || "React class", u, f, r(e[f])), p = e[f](n, f, l, u, null, a)
                                    } catch (e) {
                                        p = e
                                    }
                                    if (i(!p || p instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", l || "React class", u, f, void 0 === p ? "undefined" : r(p)), p instanceof Error && !(p.message in s)) {
                                        s[p.message] = !0;
                                        var d = c ? c() : "";
                                        i(!1, "Failed %s type: %s%s", u, p.message, null != d ? d : "")
                                    }
                                }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                "use strict";
                var r = n(6),
                    o = n(7),
                    i = n(10);
                e.exports = function() {
                    function e(e, t, n, r, a, s) {
                        s !== i && o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function t() {
                        return e
                    }
                    e.isRequired = e;
                    var n = {
                        array: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: t,
                        element: e,
                        instanceOf: t,
                        node: e,
                        objectOf: t,
                        oneOf: t,
                        oneOfType: t,
                        shape: t,
                        exact: t
                    };
                    return n.checkPropTypes = r, n.PropTypes = n, n
                }
            }, function(e, t) {
                e.exports = o
            }, function(e, t) {
                e.exports = i
            }, function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = e.getBoundingClientRect(),
                        o = void 0,
                        i = void 0,
                        a = void 0;
                    return t.margin && (a = (0, r.default)(getComputedStyle(e))), t.margin ? (o = a.left + n.width + a.right, i = a.top + n.height + a.bottom) : (o = n.width, i = n.height), {
                        width: o,
                        height: i,
                        top: n.top,
                        right: n.right,
                        bottom: n.bottom,
                        left: n.left
                    }
                };
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(16));
                e.exports = t.default
            }, function(e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    return {
                        top: n((e = e || {}).marginTop),
                        right: n(e.marginRight),
                        bottom: n(e.marginBottom),
                        left: n(e.marginLeft)
                    }
                };
                var n = function(e) {
                    return parseInt(e) || 0
                };
                e.exports = t.default
            }]))
        },
        12015: (e, t, n) => {
            "use strict";
            n.d(t, {
                isPlatformMobile: () => o
            });
            var r = n(69111);
            n(82527), n(1227);

            function o() {
                return !(0, r.isOnMobileAppPage)("any") && (window.matchMedia("(min-width: 602px) and (min-height: 445px)").matches, !1)
            }
        },
        23698: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                Components: () => C,
                showDefaultSearchDialog: () => D,
                showSymbolSearchItemsDialog: () => s.showSymbolSearchItemsDialog
            });
            var r = n(88401),
                o = n(72535),
                i = n(85227),
                a = n(40641),
                s = n(58323),
                u = n(59496),
                l = n(88537),
                c = n(56871),
                f = n(13060),
                p = n(44080),
                d = n(97754),
                h = n.n(d),
                m = n(25177),
                y = n(296),
                v = n(59130),
                b = n(80810),
                g = n(23889),
                w = n(82132);

            function S(e) {
                const {
                    isSelected: t,
                    existInWatchlist: n,
                    findInWatchlist: r,
                    addToWatchlist: o,
                    removeFromWatchlist: i
                } = e, {
                    selectedAction: a
                } = (0,
                    l.ensureNotNull)((0, u.useContext)(f.SymbolSearchWatchlistContext));
                return u.createElement(u.Fragment, null, n ? u.createElement(u.Fragment, null, u.createElement(y.ListItemButton, {
                    className: h()(w.action, w.removeAction, t && 2 === a && w.selected, "apply-common-tooltip"),
                    onClick: i,
                    icon: v,
                    title: (0, m.t)("Remove from Watchlist")
                }), u.createElement(y.ListItemButton, {
                    className: h()(w.action, w.targetAction, t && 1 === a && w.selected, "apply-common-tooltip"),
                    onClick: r,
                    icon: g,
                    title: (0, m.t)("Go to symbol")
                })) : u.createElement(y.ListItemButton, {
                    className: h()(w.action, w.addAction, t && 0 === a && w.selected, "apply-common-tooltip"),
                    onClick: o,
                    icon: b,
                    title: (0, m.t)("Add to Watchlist")
                }))
            }
            var O = n(80185),
                T = n(32133),
                x = n(79359),
                _ = n(90266);
            var E = n(53337),
                I = n(21167),
                k = n(75544);
            (0, n(12015).isPlatformMobile)();

            function D(e) {
                const t = (0, a.getSymbolSearchCompleteOverrideFunction)(),
                    {
                        defaultValue: n,
                        showSpreadActions: o,
                        source: u,
                        onSearchComplete: l,
                        ...c
                    } = e,
                    f = { ...c,
                        showSpreadActions: null != o ? o : (0, i.canShowSpreadActions)(),
                        onSearchComplete: e => {
                            t(e[0].symbol).then(e => {
                                r.linking.symbol.setValue(e), null == l || l(e)
                            })
                        }
                    };
                (0, s.showSymbolSearchItemsDialog)({ ...f,
                    defaultValue: n
                })
            }
            const C = {
                SymbolSearchWatchlistDialogContentItem: function(e) {
                    const {
                        addToWatchlist: t,
                        removeFromWatchlist: n,
                        findInWatchlist: r,
                        existInWatchlist: i,
                        isSelected: a,
                        fullSymbolName: s,
                        ...d
                    } = e, {
                        onClose: h,
                        searchRef: m,
                        searchSpreads: y
                    } = (0, l.ensureNotNull)((0, u.useContext)(p.SymbolSearchItemsDialogContext)), {
                        setSelectedAction: v,
                        isSpreadOrMultipleMode: b,
                        addAfter: g,
                        clearTargetSymbol: w,
                        highlighted: E,
                        highlight: I
                    } = (0, l.ensureNotNull)((0, u.useContext)(f.SymbolSearchWatchlistContext)), k = b(y, m);
                    return (0, u.useLayoutEffect)(() => {
                        a && v(void 0 !== i ? i ? 2 : 0 : null)
                    }, [a, i]), u.createElement(c.SymbolSearchDialogContentItem, { ...d,
                        fullSymbolName: s,
                        onClick: k ? e.onClick : function(r) {
                            if (void 0 === s) return;
                            if (void 0 === i) return void(0, l.ensureDefined)(e.onClick)(r);
                            i ? (n(x.WATCHLIST_WIDGET_ID, s), C("watchlist remove click", r), g === s && w()) : ((0, _.runOrSignIn)(() => {
                                t(x.WATCHLIST_WIDGET_ID, [s], g), e.id && I(e.id)
                            }, {
                                source: "add symbol to watchlist"
                            }), C("watchlist add click", r));
                            D(r)
                        },
                        isHighlighted: E === e.id,
                        isSelected: a,
                        actions: void 0 === i || k ? void 0 : u.createElement(S, {
                            isSelected: a,
                            existInWatchlist: i,
                            addToWatchlist: function(n) {
                                if (n.stopPropagation(), void 0 === s) return;
                                (0, _.runOrSignIn)(() => {
                                    t(x.WATCHLIST_WIDGET_ID, [s], g), e.id && I(e.id)
                                }, {
                                    source: "add symbol to watchlist"
                                }), D(n), C("watchlist add button", n)
                            },
                            removeFromWatchlist: function(e) {
                                if (e.stopPropagation(), void 0 === s) return;
                                n(x.WATCHLIST_WIDGET_ID, s), D(e), C("watchlist remove button", e), g === s && w()
                            },
                            findInWatchlist: function(e) {
                                if (e.stopPropagation(), void 0 === s) return;
                                r(x.WATCHLIST_WIDGET_ID, s), h(), C("watchlist goto button")
                            }
                        })
                    });

                    function D(e) {
                        var t;
                        (0, O.modifiersFromEvent)(e) === O.Modifiers.Shift ? h() : o.mobiletouch || null === (t = m.current) || void 0 === t || t.select()
                    }

                    function C(e, t) {
                        let n = e;
                        t && (0, O.modifiersFromEvent)(t) === O.Modifiers.Shift && (n += " shift"), (0, T.trackEvent)("GUI", "SS", n)
                    }
                },
                SymbolSearchWatchlistDialog: function(e) {
                    const {
                        addToWatchlist: t,
                        removeFromWatchlist: n,
                        findInWatchlist: r,
                        ...o
                    } = e, {
                        feedItems: i,
                        searchRef: a,
                        searchSpreads: s,
                        openedItems: c,
                        selectedIndex: d,
                        toggleExpand: m,
                        onSubmit: y,
                        setSelectedIndex: v,
                        onClose: b,
                        isMobile: g,
                        isTablet: w
                    } = (0, l.ensureNotNull)((0, u.useContext)(p.SymbolSearchItemsDialogContext)), {
                        selectedAction: S,
                        setSelectedAction: T,
                        isSpreadOrMultipleMode: D,
                        addAfter: C,
                        clearTargetSymbol: N,
                        highlight: j
                    } = (0, l.ensureNotNull)((0, u.useContext)(f.SymbolSearchWatchlistContext)), A = i[d];
                    return u.createElement(E.AdaptivePopupDialog, { ...o,
                        className: h()(k.dialog, !g && (w ? k.tabletDialog : k.desktopDialog)),
                        dataName: "watchlist-symbol-search-dialog",
                        onKeyDown: function(e) {
                            var t;
                            switch ((0, O.hashFromEvent)(e)) {
                                case 38:
                                    if (e.preventDefault(), 0 === d) return;
                                    if (-1 === d) return void v(0);
                                    v(d - 1);
                                    break;
                                case 40:
                                    if (e.preventDefault(), d === i.length - 1) return;
                                    v(d + 1);
                                    break;
                                case 37:
                                    {
                                        if (!A) return;
                                        const {
                                            id: t,
                                            isOffset: n,
                                            onExpandClick: r
                                        } = A;
                                        if (!I.isOpenFirstContractEnabled && !n && t && Boolean(r) && c.has(t)) return e.preventDefault(), void m(t);1 === S && (e.preventDefault(), T(2));
                                        break
                                    }
                                case 39:
                                    {
                                        if (!A) return;
                                        const {
                                            id: t,
                                            isOffset: n,
                                            onExpandClick: r
                                        } = A;
                                        if (!I.isOpenFirstContractEnabled && !n && t && Boolean(r) && !c.has(t)) return e.preventDefault(), void m(t);2 === S && (e.preventDefault(), T(1));
                                        break
                                    }
                                case 13:
                                    if (D(s, a)) return void y(!0);
                                    A ? M(!1) : y(!1), null === (t = a.current) || void 0 === t || t.select();
                                    break;
                                case 13 + O.Modifiers.Shift:
                                    if (D(s, a)) return void y(!0);
                                    A ? M(!0) : y(!0);
                                    break;
                                case 27:
                                    e.preventDefault(), b()
                            }
                        },
                        backdrop: !0,
                        draggable: !1
                    });

                    function M(e) {
                        if (!A || void 0 === A.fullSymbolName) return;
                        const {
                            isOffset: o,
                            id: i,
                            onExpandClick: a,
                            fullSymbolName: s
                        } = A;
                        if (!(!o && i && Boolean(a)) || I.isOpenFirstContractEnabled) {
                            switch (S) {
                                case 0:
                                    (0, _.runOrSignIn)(() => {
                                        t(x.WATCHLIST_WIDGET_ID, [s], C), A.id && j(A.id)
                                    }, {
                                        source: "add symbol to watchlist"
                                    });
                                    break;
                                case 1:
                                    return r(x.WATCHLIST_WIDGET_ID, s), void b();
                                case 2:
                                    n(x.WATCHLIST_WIDGET_ID, s), C === s && N()
                            }
                            e && b()
                        } else m(i)
                    }
                }
            }
        },
        13060: (e, t, n) => {
            "use strict";
            n.d(t, {
                SymbolSearchWatchlistContext: () => r
            });
            const r = n(59496).createContext(null)
        },
        90266: (e, t, n) => {
            "use strict";
            n.d(t, {
                runOrSignIn: () => r
            });

            function r(e, t) {
                e()
            }
        },
        296: (e, t, n) => {
            "use strict";
            n.d(t, {
                ListItemButton: () => u
            });
            var r = n(59496),
                o = n(97754),
                i = n.n(o),
                a = n(72571),
                s = n(30608);

            function u(e) {
                const {
                    className: t,
                    disabled: n,
                    ...o
                } = e;
                return r.createElement(a.Icon, {
                    className: i()(s.button, n && s.disabled, t),
                    ...o
                })
            }
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        59130: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" stroke-width="1.2" d="M8 8l13 13m0-13L8 21"/></svg>'
        },
        80810: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M13.9 14.1V22h1.2v-7.9H23v-1.2h-7.9V5h-1.2v7.9H6v1.2h7.9z"/></svg>'
        },
        23889: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M14 9.5a.5.5 0 0 0 1 0V7.02A6.5 6.5 0 0 1 20.98 13H18.5a.5.5 0 0 0 0 1h2.48A6.5 6.5 0 0 1 15 19.98V17.5a.5.5 0 0 0-1 0v2.48A6.5 6.5 0 0 1 8.02 14h2.48a.5.5 0 0 0 0-1H8.02A6.5 6.5 0 0 1 14 7.02V9.5zm1-3.48V4.5a.5.5 0 0 0-1 0v1.52A7.5 7.5 0 0 0 7.02 13H5.5a.5.5 0 0 0 0 1h1.52A7.5 7.5 0 0 0 14 20.98v1.52a.5.5 0 0 0 1 0v-1.52A7.5 7.5 0 0 0 21.98 14h1.52a.5.5 0 0 0 0-1h-1.52A7.5 7.5 0 0 0 15 6.02z"/></svg>'
        }
    }
]);
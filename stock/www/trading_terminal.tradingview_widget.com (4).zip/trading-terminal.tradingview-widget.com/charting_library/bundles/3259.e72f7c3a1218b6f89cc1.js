(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [3259], {
        21103: e => {
            e.exports = {
                container: "container-pgo9gj31",
                "intent-default": "intent-default-pgo9gj31",
                focused: "focused-pgo9gj31",
                readonly: "readonly-pgo9gj31",
                disabled: "disabled-pgo9gj31",
                "with-highlight": "with-highlight-pgo9gj31",
                grouped: "grouped-pgo9gj31",
                "adjust-position": "adjust-position-pgo9gj31",
                "first-row": "first-row-pgo9gj31",
                "first-col": "first-col-pgo9gj31",
                stretch: "stretch-pgo9gj31",
                "font-size-medium": "font-size-medium-pgo9gj31",
                "font-size-large": "font-size-large-pgo9gj31",
                "size-small": "size-small-pgo9gj31",
                "size-medium": "size-medium-pgo9gj31",
                "size-large": "size-large-pgo9gj31",
                "intent-success": "intent-success-pgo9gj31",
                "intent-warning": "intent-warning-pgo9gj31",
                "intent-danger": "intent-danger-pgo9gj31",
                "intent-primary": "intent-primary-pgo9gj31",
                "border-none": "border-none-pgo9gj31",
                "border-thin": "border-thin-pgo9gj31",
                "border-thick": "border-thick-pgo9gj31",
                "no-corner-top-left": "no-corner-top-left-pgo9gj31",
                "no-corner-top-right": "no-corner-top-right-pgo9gj31",
                "no-corner-bottom-right": "no-corner-bottom-right-pgo9gj31",
                "no-corner-bottom-left": "no-corner-bottom-left-pgo9gj31",
                highlight: "highlight-pgo9gj31",
                shown: "shown-pgo9gj31"
            }
        },
        10306: e => {
            e.exports = {
                "inner-slot": "inner-slot-QpAAIiaV",
                interactive: "interactive-QpAAIiaV",
                icon: "icon-QpAAIiaV",
                "inner-middle-slot": "inner-middle-slot-QpAAIiaV",
                "before-slot": "before-slot-QpAAIiaV",
                "after-slot": "after-slot-QpAAIiaV"
            }
        },
        66579: e => {
            e.exports = {
                input: "input-uGWFLwEy",
                "with-start-slot": "with-start-slot-uGWFLwEy",
                "with-end-slot": "with-end-slot-uGWFLwEy"
            }
        },
        55576: e => {
            e.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        64547: e => {
            e.exports = {
                button: "button-SS83RYhy"
            }
        },
        71123: e => {
            e.exports = {
                button: "button-khcLBZEz",
                hover: "hover-khcLBZEz",
                arrow: "arrow-khcLBZEz",
                arrowWrap: "arrowWrap-khcLBZEz",
                newStyles: "newStyles-khcLBZEz",
                isOpened: "isOpened-khcLBZEz"
            }
        },
        97623: e => {
            e.exports = {
                scrollWrap: "scrollWrap-9M00JHkT"
            }
        },
        62230: e => {
            e.exports = {
                wrap: "wrap-Shy8LdqT",
                "wrap--horizontal": "wrap--horizontal-Shy8LdqT",
                bar: "bar-Shy8LdqT",
                barInner: "barInner-Shy8LdqT",
                "barInner--horizontal": "barInner--horizontal-Shy8LdqT",
                "bar--horizontal": "bar--horizontal-Shy8LdqT"
            }
        },
        62461: e => {
            e.exports = {
                dropTargetInside: "dropTargetInside-HaSQHZAC",
                dropTarget: "dropTarget-HaSQHZAC",
                before: "before-HaSQHZAC",
                after: "after-HaSQHZAC"
            }
        },
        91069: e => {
            e.exports = {
                wrap: "wrap-XdW9S1Ib",
                selected: "selected-XdW9S1Ib",
                childOfSelected: "childOfSelected-XdW9S1Ib",
                disabled: "disabled-XdW9S1Ib",
                expandHandle: "expandHandle-XdW9S1Ib",
                expanded: "expanded-XdW9S1Ib"
            }
        },
        34244: e => {
            e.exports = {
                separator: "separator-KFALCIeR",
                tree: "tree-KFALCIeR",
                overlayScrollWrap: "overlayScrollWrap-KFALCIeR",
                listContainer: "listContainer-KFALCIeR"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        30608: e => {
            e.exports = {
                button: "button-IulLF4sY",
                disabled: "disabled-IulLF4sY"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        40367: e => {
            e.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        80327: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlGroupContext: () => o
            });
            const o = n(59496).createContext({
                isGrouped: !1,
                cellState: {
                    isTop: !0,
                    isRight: !0,
                    isBottom: !0,
                    isLeft: !0
                }
            })
        },
        31774: (e, t, n) => {
            "use strict";

            function o(e) {
                let t = 0;
                return e.isTop && e.isLeft || (t += 1), e.isTop && e.isRight || (t += 2), e.isBottom && e.isLeft || (t += 8), e.isBottom && e.isRight || (t += 4), t
            }
            n.d(t, {
                getGroupCellRemoveRoundBorders: () => o
            })
        },
        34735: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlSkeleton: () => S,
                InputClasses: () => m
            });
            var o = n(59496),
                r = n(97754),
                s = n(88537),
                i = n(28606),
                l = n(417),
                c = n(80327),
                a = n(31774);
            var d = n(21103),
                u = n.n(d);

            function p(e) {
                let t = "";
                return 0 !== e && (1 & e && (t = r(t, u()["no-corner-top-left"])), 2 & e && (t = r(t, u()["no-corner-top-right"])), 4 & e && (t = r(t, u()["no-corner-bottom-right"])), 8 & e && (t = r(t, u()["no-corner-bottom-left"]))), t
            }

            function h(e, t, n, o) {
                const {
                    removeRoundBorder: s,
                    className: i,
                    intent: l = "default",
                    borderStyle: c = "thin",
                    size: d,
                    highlight: h,
                    disabled: f,
                    readonly: m,
                    stretch: g,
                    noReadonlyStyles: E,
                    isFocused: S
                } = e, v = p(null != s ? s : (0, a.getGroupCellRemoveRoundBorders)(n));
                return r(u().container, u()["intent-" + l], u()["border-" + c], d && u()["size-" + d], v, h && u()["with-highlight"], f && u().disabled, m && !E && u().readonly, S && u().focused, g && u().stretch, t && u().grouped, !o && u()["adjust-position"], n.isTop && u()["first-row"], n.isLeft && u()["first-col"], i)
            }

            function f(e, t) {
                const {
                    highlight: n,
                    highlightRemoveRoundBorder: o
                } = e;
                if (!n) return u().highlight;
                const s = p(null != o ? o : (0, a.getGroupCellRemoveRoundBorders)(t));
                return r(u().highlight, u().shown, s)
            }
            const m = {
                    FontSizeMedium: (0, s.ensureDefined)(u()["font-size-medium"]),
                    FontSizeLarge: (0, s.ensureDefined)(u()["font-size-large"])
                },
                g = {
                    passive: !1
                };

            function E(e, t) {
                const {
                    id: n,
                    role: r,
                    onFocus: s,
                    onBlur: a,
                    onMouseOver: d,
                    onMouseOut: u,
                    onMouseDown: p,
                    onMouseUp: m,
                    onKeyDown: E,
                    onClick: S,
                    tabIndex: v,
                    startSlot: T,
                    middleSlot: _,
                    endSlot: y,
                    onWheel: D,
                    onWheelNoPassive: C = null
                } = e, {
                    isGrouped: b,
                    cellState: w,
                    disablePositionAdjustment: N = !1
                } = (0, o.useContext)(c.ControlGroupContext), x = function(e, t = null, n) {
                    const r = (0, o.useRef)(null),
                        s = (0, o.useRef)(null),
                        i = (0, o.useCallback)(() => {
                            if (null === r.current || null === s.current) return;
                            const [e, t, n] = s.current;
                            null !== t && r.current.addEventListener(e, t, n)
                        }, []),
                        l = (0, o.useCallback)(() => {
                            if (null === r.current || null === s.current) return;
                            const [e, t, n] = s.current;
                            null !== t && r.current.removeEventListener(e, t, n)
                        }, []),
                        c = (0, o.useCallback)(e => {
                            l(), r.current = e, i()
                        }, []);
                    return (0, o.useEffect)(() => (s.current = [e, t, n], i(), l), [e, t, n]), c
                }("wheel", C, g);
                return o.createElement("span", {
                    id: n,
                    role: r,
                    className: h(e, b, w, N),
                    tabIndex: v,
                    ref: (0, i.useMergedRefs)([t, x]),
                    onFocus: s,
                    onBlur: a,
                    onMouseOver: d,
                    onMouseOut: u,
                    onMouseDown: p,
                    onMouseUp: m,
                    onKeyDown: E,
                    onClick: S,
                    onWheel: D,
                    ...(0, l.filterDataProps)(e),
                    ...(0, l.filterAriaProps)(e)
                }, T, _, y, o.createElement("span", {
                    className: f(e, w)
                }))
            }
            E.displayName = "ControlSkeleton";
            const S = o.forwardRef(E)
        },
        2691: (e, t, n) => {
            "use strict";
            n.d(t, {
                BeforeSlot: () => l,
                StartSlot: () => c,
                MiddleSlot: () => a,
                EndSlot: () => d,
                AfterSlot: () => u
            });
            var o = n(59496),
                r = n(97754),
                s = n(10306),
                i = n.n(s);

            function l(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(i()["before-slot"], t)
                }, n)
            }

            function c(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: s = !1,
                    children: l
                } = e;
                return o.createElement("span", {
                    className: r(i()["inner-slot"], n && i().interactive, s && i().icon, t)
                }, l)
            }

            function a(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(i()["inner-slot"], i()["inner-middle-slot"], t)
                }, n)
            }

            function d(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: s = !1,
                    children: l
                } = e;
                return o.createElement("span", {
                    className: r(i()["inner-slot"], n && i().interactive, s && i().icon, t)
                }, l)
            }

            function u(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return o.createElement("span", {
                    className: r(i()["after-slot"], t)
                }, n)
            }
        },
        54936: (e, t, n) => {
            "use strict";
            n.d(t, {
                Input: () => E,
                InputControl: () => S
            });
            var o = n(59496),
                r = n(97754),
                s = n(417),
                i = n(69842),
                l = n(1811),
                c = n(28606),
                a = n(21778),
                d = n(83836),
                u = n(3548),
                p = n(34735),
                h = n(2691),
                f = n(66579),
                m = n.n(f);

            function g(e) {
                return !(0, s.isAriaAttribute)(e) && !(0, s.isDataAttribute)(e)
            }

            function E(e) {
                const {
                    id: t,
                    title: n,
                    role: i,
                    tabIndex: l,
                    placeholder: c,
                    name: a,
                    type: d,
                    value: u,
                    defaultValue: f,
                    draggable: E,
                    autoComplete: S,
                    autoFocus: v,
                    maxLength: T,
                    min: _,
                    max: y,
                    step: D,
                    pattern: C,
                    inputMode: b,
                    onSelect: w,
                    onFocus: N,
                    onBlur: x,
                    onKeyDown: I,
                    onKeyUp: O,
                    onKeyPress: M,
                    onChange: L,
                    onDragStart: R,
                    size: P = "medium",
                    className: A,
                    inputClassName: k,
                    disabled: F,
                    readonly: B,
                    containerTabIndex: W,
                    startSlot: H,
                    endSlot: z,
                    reference: U,
                    containerReference: j,
                    onContainerFocus: G,
                    ...V
                } = e, K = (0, s.filterProps)(V, g), X = { ...(0, s.filterAriaProps)(V),
                    ...(0, s.filterDataProps)(V),
                    id: t,
                    title: n,
                    role: i,
                    tabIndex: l,
                    placeholder: c,
                    name: a,
                    type: d,
                    value: u,
                    defaultValue: f,
                    draggable: E,
                    autoComplete: S,
                    autoFocus: v,
                    maxLength: T,
                    min: _,
                    max: y,
                    step: D,
                    pattern: C,
                    inputMode: b,
                    onSelect: w,
                    onFocus: N,
                    onBlur: x,
                    onKeyDown: I,
                    onKeyUp: O,
                    onKeyPress: M,
                    onChange: L,
                    onDragStart: R
                };
                return o.createElement(p.ControlSkeleton, { ...K,
                    disabled: F,
                    readonly: B,
                    tabIndex: W,
                    className: r(m().container, A),
                    size: P,
                    ref: j,
                    onFocus: G,
                    startSlot: H,
                    middleSlot: o.createElement(h.MiddleSlot, null, o.createElement("input", { ...X,
                        className: r(m().input, k, H && m()["with-start-slot"], z && m()["with-end-slot"]),
                        disabled: F,
                        readOnly: B,
                        ref: U
                    })),
                    endSlot: z
                })
            }

            function S(e) {
                e = (0, a.useControl)(e);
                const {
                    disabled: t,
                    autoSelectOnFocus: n,
                    tabIndex: r = 0,
                    onFocus: s,
                    onBlur: p,
                    reference: h,
                    containerReference: f = null
                } = e, m = (0, o.useRef)(null), g = (0, o.useRef)(null), [S, v] = (0,
                    d.useFocus)(), T = t ? void 0 : S ? -1 : r, _ = t ? void 0 : S ? r : -1, {
                    isMouseDown: y,
                    handleMouseDown: D,
                    handleMouseUp: C
                } = (0, u.useIsMouseDown)(), b = (0, i.createSafeMulticastEventHandler)(v.onFocus, (function(e) {
                    n && !y.current && (0, l.selectAllContent)(e.currentTarget)
                }), s), w = (0, i.createSafeMulticastEventHandler)(v.onBlur, p), N = (0, o.useCallback)(e => {
                    m.current = e, h && ("function" == typeof h && h(e), "object" == typeof h && (h.current = e))
                }, [m, h]);
                return o.createElement(E, { ...e,
                    isFocused: S,
                    containerTabIndex: T,
                    tabIndex: _,
                    onContainerFocus: function(e) {
                        g.current === e.target && null !== m.current && m.current.focus()
                    },
                    onFocus: b,
                    onBlur: w,
                    reference: N,
                    containerReference: (0, c.useMergedRefs)([g, f]),
                    onMouseDown: D,
                    onMouseUp: C
                })
            }
        },
        21778: (e, t, n) => {
            "use strict";
            n.d(t, {
                useControl: () => s
            });
            var o = n(69842),
                r = n(83836);

            function s(e) {
                const {
                    onFocus: t,
                    onBlur: n,
                    intent: s,
                    highlight: i,
                    disabled: l
                } = e, [c, a] = (0, r.useFocus)(void 0, l), d = (0, o.createSafeMulticastEventHandler)(l ? void 0 : a.onFocus, t), u = (0, o.createSafeMulticastEventHandler)(l ? void 0 : a.onBlur, n);
                return { ...e,
                    intent: s || (c ? "primary" : "default"),
                    highlight: null != i ? i : c,
                    onFocus: d,
                    onBlur: u
                }
            }
        },
        83836: (e, t, n) => {
            "use strict";
            n.d(t, {
                useFocus: () => r
            });
            var o = n(59496);

            function r(e, t) {
                const [n, r] = (0, o.useState)(!1);
                (0, o.useEffect)(() => {
                    t && n && r(!1)
                }, [t, n]);
                const s = {
                    onFocus: (0, o.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || r(!0)
                    }), [e]),
                    onBlur: (0, o.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || r(!1)
                    }), [e])
                };
                return [n, s]
            }
        },
        3548: (e, t, n) => {
            "use strict";
            n.d(t, {
                useIsMouseDown: () => r
            });
            var o = n(59496);

            function r() {
                const e = (0, o.useRef)(!1),
                    t = (0, o.useCallback)(() => {
                        e.current = !0
                    }, [e]),
                    n = (0, o.useCallback)(() => {
                        e.current = !1
                    }, [e]);
                return {
                    isMouseDown: e,
                    handleMouseDown: t,
                    handleMouseUp: n
                }
            }
        },
        28606: (e, t, n) => {
            "use strict";
            n.d(t, {
                useMergedRefs: () => r
            });
            var o = n(59496);

            function r(e) {
                return (0, o.useCallback)(function(e) {
                    return t => {
                        e.forEach(e => {
                            "function" == typeof e ? e(t) : null != e && (e.current = t)
                        })
                    }
                }(e), e)
            }
        },
        417: (e, t, n) => {
            "use strict";

            function o(e) {
                return s(e, i)
            }

            function r(e) {
                return s(e, l)
            }

            function s(e, t) {
                const n = Object.entries(e).filter(t),
                    o = {};
                for (const [e, t] of n) o[e] = t;
                return o
            }

            function i(e) {
                const [t, n] = e;
                return 0 === t.indexOf("data-") && "string" == typeof n
            }

            function l(e) {
                return 0 === e[0].indexOf("aria-")
            }
            n.d(t, {
                filterDataProps: () => o,
                filterAriaProps: () => r,
                filterProps: () => s,
                isDataAttribute: () => i,
                isAriaAttribute: () => l
            })
        },
        1811: (e, t, n) => {
            "use strict";

            function o(e) {
                null !== e && e.setSelectionRange(0, e.value.length)
            }
            n.d(t, {
                selectAllContent: () => o
            })
        },
        69842: (e, t, n) => {
            "use strict";

            function o(...e) {
                return t => {
                    for (const n of e) void 0 !== n && n(t)
                }
            }
            n.d(t, {
                createSafeMulticastEventHandler: () => o
            })
        },
        85673: (e, t, n) => {
            "use strict";
            n.d(t, {
                VerticalAttachEdge: () => o,
                HorizontalAttachEdge: () => r,
                VerticalDropDirection: () => s,
                HorizontalDropDirection: () => i,
                getPopupPositioner: () => a
            });
            var o, r, s, i, l = n(88537);
            ! function(e) {
                e[e.Top = 0] = "Top", e[e.Bottom = 1] = "Bottom"
            }(o || (o = {})),
            function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(r || (r = {})),
            function(e) {
                e[e.FromTopToBottom = 0] = "FromTopToBottom", e[e.FromBottomToTop = 1] = "FromBottomToTop"
            }(s || (s = {})),
            function(e) {
                e[e.FromLeftToRight = 0] = "FromLeftToRight",
                    e[e.FromRightToLeft = 1] = "FromRightToLeft"
            }(i || (i = {}));
            const c = {
                verticalAttachEdge: o.Bottom,
                horizontalAttachEdge: r.Left,
                verticalDropDirection: s.FromTopToBottom,
                horizontalDropDirection: i.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function a(e, t) {
                return (n, a) => {
                    const d = (0, l.ensureNotNull)(e).getBoundingClientRect(),
                        {
                            verticalAttachEdge: u = c.verticalAttachEdge,
                            verticalDropDirection: p = c.verticalDropDirection,
                            horizontalAttachEdge: h = c.horizontalAttachEdge,
                            horizontalDropDirection: f = c.horizontalDropDirection,
                            horizontalMargin: m = c.horizontalMargin,
                            verticalMargin: g = c.verticalMargin,
                            matchButtonAndListboxWidths: E = c.matchButtonAndListboxWidths
                        } = t,
                        S = u === o.Top ? -1 * g : g,
                        v = h === r.Right ? d.right : d.left,
                        T = u === o.Top ? d.top : d.bottom,
                        _ = {
                            x: v - (f === i.FromRightToLeft ? n : 0) + m,
                            y: T - (p === s.FromBottomToTop ? a : 0) + S
                        };
                    return E && (_.overrideWidth = d.width), _
                }
            }
        },
        75803: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => c,
                ToolWidgetButton: () => a
            });
            var o = n(59496),
                r = n(97754),
                s = n(72571),
                i = n(4257),
                l = n(55576);
            const c = l,
                a = o.forwardRef((e, t) => {
                    const {
                        icon: n,
                        isActive: c,
                        isOpened: a,
                        isDisabled: d,
                        isGrouped: u,
                        isHovered: p,
                        onClick: h,
                        text: f,
                        textBeforeIcon: m,
                        title: g,
                        theme: E = l,
                        className: S,
                        forceInteractive: v,
                        "data-name": T,
                        ..._
                    } = e, y = r(S, E.button, g && "apply-common-tooltip", {
                        [E.isActive]: c,
                        [E.isOpened]: a,
                        [E.isInteractive]: (v || Boolean(h)) && !d,
                        [E.isDisabled]: d,
                        [E.isGrouped]: u,
                        [E.hover]: p,
                        [E.newStyles]: i.hasNewHeaderToolbarStyles
                    }), D = n && ("string" == typeof n ? o.createElement(s.Icon, {
                        className: E.icon,
                        icon: n
                    }) : o.cloneElement(n, {
                        className: r(E.icon, n.props.className)
                    }));
                    return o.createElement("div", { ..._,
                        ref: t,
                        "data-role": "button",
                        className: y,
                        onClick: d ? void 0 : h,
                        title: g,
                        "data-name": T
                    }, m && f && o.createElement("div", {
                        className: r("js-button-text", E.text)
                    }, f), D, !m && f && o.createElement("div", {
                        className: r("js-button-text", E.text)
                    }, f))
                })
        },
        5710: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetIconButton: () => l
            });
            var o = n(59496),
                r = n(97754),
                s = n(75803),
                i = n(64547);
            const l = o.forwardRef((e, t) => {
                const {
                    className: n,
                    id: l,
                    ...c
                } = e;
                return o.createElement(s.ToolWidgetButton, {
                    "data-name": l,
                    ...c,
                    ref: t,
                    className: r(n, i.button)
                })
            })
        },
        34816: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_TOOL_WIDGET_MENU_THEME: () => f,
                ToolWidgetMenu: () => m
            });
            var o = n(59496),
                r = n(97754),
                s = n(44377),
                i = n(15783),
                l = n(417),
                c = n(63694),
                a = n(59339),
                d = n(85673),
                u = n(30052),
                p = n(4257),
                h = n(71123);
            const f = h;
            class m extends o.PureComponent {
                constructor(e) {
                    super(e), this._wrapperRef = null, this._controller = o.createRef(), this._handleWrapperRef = e => {
                        this._wrapperRef = e, this.props.reference && this.props.reference(e)
                    }, this._handleClick = e => {
                        e.target instanceof Node && e.currentTarget.contains(e.target) && (this._handleToggleDropdown(), this.props.onClick && this.props.onClick(e, !this.state.isOpened))
                    }, this._handleToggleDropdown = e => {
                        const {
                            onClose: t,
                            onOpen: n
                        } = this.props, {
                            isOpened: o
                        } = this.state, r = "boolean" == typeof e ? e : !o;
                        this.setState({
                            isOpened: r
                        }), r && n && n(), !r && t && t()
                    }, this._handleClose = () => {
                        this.close()
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        arrow: t,
                        content: n,
                        isDisabled: s,
                        isDrawer: c,
                        isShowTooltip: a,
                        title: d,
                        className: h,
                        hotKey: f,
                        theme: m,
                        drawerBreakpoint: g
                    } = this.props, {
                        isOpened: E
                    } = this.state, S = r(h, m.button, {
                        "apply-common-tooltip": a || !s,
                        [m.isDisabled]: s,
                        [m.isOpened]: E,
                        [m.newStyles]: p.hasNewHeaderToolbarStyles
                    });
                    return o.createElement("div", {
                        id: e,
                        className: S,
                        onClick: s ? void 0 : this._handleClick,
                        title: d,
                        "data-tooltip-hotkey": f,
                        ref: this._handleWrapperRef,
                        "data-role": "button",
                        ...(0, l.filterDataProps)(this.props)
                    }, n, t && o.createElement("div", {
                        className: m.arrow
                    }, o.createElement("div", {
                        className: m.arrowWrap
                    }, o.createElement(i.ToolWidgetCaret, {
                        dropped: E
                    }))), this.state.isOpened && (g ? o.createElement(u.MatchMedia, {
                        rule: g
                    }, e => this._renderContent(e)) : this._renderContent(c)))
                }
                close() {
                    this._handleToggleDropdown(!1)
                }
                update() {
                    null !== this._controller.current && this._controller.current.update()
                }
                _renderContent(e) {
                    const {
                        menuDataName: t,
                        minWidth: n,
                        menuClassName: r,
                        maxHeight: i,
                        drawerPosition: l = "Bottom",
                        children: u
                    } = this.props, {
                        isOpened: p
                    } = this.state, h = {
                        horizontalMargin: this.props.horizontalMargin || 0,
                        verticalMargin: this.props.verticalMargin || 2,
                        verticalAttachEdge: this.props.verticalAttachEdge,
                        horizontalAttachEdge: this.props.horizontalAttachEdge,
                        verticalDropDirection: this.props.verticalDropDirection,
                        horizontalDropDirection: this.props.horizontalDropDirection,
                        matchButtonAndListboxWidths: this.props.matchButtonAndListboxWidths
                    }, f = Boolean(p && e && l), m = function(e) {
                        return "function" == typeof e
                    }(u) ? u({
                        isDrawer: f
                    }) : u;
                    return f ? o.createElement(c.DrawerManager, null, o.createElement(a.Drawer, {
                        onClose: this._handleClose,
                        position: l,
                        "data-name": t
                    }, m)) : o.createElement(s.PopupMenu, {
                        controller: this._controller,
                        closeOnClickOutside: this.props.closeOnClickOutside,
                        doNotCloseOn: this,
                        isOpened: p,
                        minWidth: n,
                        onClose: this._handleClose,
                        position: (0, d.getPopupPositioner)(this._wrapperRef, h),
                        className: r,
                        maxHeight: i,
                        "data-name": t
                    }, m)
                }
            }
            m.defaultProps = {
                arrow: !0,
                closeOnClickOutside: !0,
                theme: h
            }
        },
        4257: (e, t, n) => {
            "use strict";
            n.d(t, {
                hasNewHeaderToolbarStyles: () => o
            });
            n(82527);
            const o = !1
        },
        21709: (e, t, n) => {
            "use strict";

            function o(e, t, n, o, r) {
                function s(r) {
                    if (e > r.timeStamp) return;
                    const s = r.target;
                    void 0 !== n && null !== t && null !== s && s.ownerDocument === o && (t.contains(s) || n(r))
                }
                return r.click && o.addEventListener("click", s, !1), r.mouseDown && o.addEventListener("mousedown", s, !1), r.touchEnd && o.addEventListener("touchend", s, !1), r.touchStart && o.addEventListener("touchstart", s, !1), () => {
                    o.removeEventListener("click", s, !1), o.removeEventListener("mousedown", s, !1), o.removeEventListener("touchend", s, !1), o.removeEventListener("touchstart", s, !1)
                }
            }
            n.d(t, {
                addOutsideEventListener: () => o
            })
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => c
            });
            var o = n(35922);
            const r = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                s = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let i = 0,
                l = !1;

            function c(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++i) {
                    const e = (0, o.getCSSProperty)(t, "overflow"),
                        r = (0, o.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0,
                        o.setStyle)(n, "right", (0, o.getScrollbarWidth)() + "px"), t.style.paddingRight = r + (0, o.getScrollbarWidth)() + "px", l = !0), t.classList.add("i-no-scroll")
                } else if (!e && i > 0 && 0 == --i && (t.classList.remove("i-no-scroll"), l)) {
                    (0, o.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (c = (0, o.getContentWidth)(n), r() ? 0 : s() ? 46 : Math.min(Math.max(c, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, o.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", l = !1
                }
                var c
            }
        },
        73288: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlayScrollContainer: () => h
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(88537),
                l = n(97280),
                c = n(34581);
            const a = n(62230);

            function d(e) {
                const {
                    size: t,
                    scrollSize: n,
                    clientSize: r,
                    scrollProgress: d,
                    onScrollProgressChange: u,
                    horizontal: p,
                    theme: h = a,
                    onDragStart: f,
                    onDragEnd: m,
                    minBarSize: g = 40
                } = e, E = (0, o.useRef)(null), S = (0, o.useRef)(null), [v, T] = (0, o.useState)(!1), _ = (0, o.useRef)(0);
                (0, o.useEffect)(() => {
                    const e = (0, i.ensureNotNull)(E.current).ownerDocument;
                    return v ? (f && f(), e && (e.addEventListener("mousemove", N), e.addEventListener("mouseup", x))) : m && m(), () => {
                        e && (e.removeEventListener("mousemove", N), e.removeEventListener("mouseup", x))
                    }
                }, [v]);
                const y = t / n || 0,
                    D = r * y || 0,
                    C = Math.max(D, g),
                    b = (t - C) / (t - D),
                    w = function(e) {
                        if ((0, c.isRtl)() && p) return e - n + r;
                        return e
                    }((0, l.clamp)(d, 0, n - t));
                return o.createElement("div", {
                    ref: E,
                    className: s()(h.wrap, p && h["wrap--horizontal"]),
                    style: {
                        [p ? "width" : "height"]: t
                    },
                    onMouseDown: function(e) {
                        if (e.isDefaultPrevented()) return;
                        e.preventDefault();
                        const o = (0, i.ensureNotNull)(S.current).getBoundingClientRect();
                        _.current = (p ? o.width : o.height) / 2;
                        const r = n - t;
                        let s = I(e.nativeEvent, (0, i.ensureNotNull)(E.current)) - _.current;
                        s < 0 ? (s = 0, _.current = I(e.nativeEvent, (0, i.ensureNotNull)(E.current))) : s > r * y * b && (s = r * y * b, _.current = I(e.nativeEvent, (0, i.ensureNotNull)(E.current)) - s);
                        u(s / y / b), T(!0)
                    }
                }, o.createElement("div", {
                    ref: S,
                    className: s()(h.bar, p && h["bar--horizontal"]),
                    style: {
                        [p ? "minWidth" : "minHeight"]: g,
                        [p ? "width" : "height"]: C,
                        transform: `translate${p?"X":"Y"}(${w*y*b||0}px)`
                    },
                    onMouseDown: function(e) {
                        e.preventDefault(), _.current = I(e.nativeEvent, (0, i.ensureNotNull)(S.current)), T(!0)
                    }
                }, o.createElement("div", {
                    className: s()(h.barInner, p && h["barInner--horizontal"])
                })));

                function N(e) {
                    const t = I(e, (0, i.ensureNotNull)(E.current)) - _.current;
                    u(t / y / b)
                }

                function x(e) {
                    T(!1)
                }

                function I(e, t) {
                    const n = t.getBoundingClientRect();
                    return p ? e.clientX - n.left : e.clientY - n.top
                }
            }
            var u = n(21258),
                p = n(97623);

            function h(e) {
                const {
                    reference: t,
                    className: n,
                    containerHeight: s = 0,
                    containerWidth: i = 0,
                    contentHeight: l = 0,
                    contentWidth: c = 0,
                    scrollPosTop: a = 0,
                    scrollPosLeft: h = 0,
                    onVerticalChange: f,
                    onHorizontalChange: m,
                    visible: g
                } = e, [E, S] = (0, u.useHover)(), [v, T] = (0, o.useState)(!1), _ = s < l, y = i < c, D = _ && y ? 8 : 0;
                return o.createElement("div", { ...S,
                    ref: t,
                    className: r(n, p.scrollWrap),
                    style: {
                        visibility: g || E || v ? "visible" : "hidden"
                    }
                }, _ && o.createElement(d, {
                    size: s - D,
                    scrollSize: l - D,
                    clientSize: s - D,
                    scrollProgress: a,
                    onScrollProgressChange: function(e) {
                        f && f(e)
                    },
                    onDragStart: C,
                    onDragEnd: b
                }), y && o.createElement(d, {
                    size: i - D,
                    scrollSize: c - D,
                    clientSize: i - D,
                    scrollProgress: h,
                    onScrollProgressChange: function(e) {
                        m && m(e)
                    },
                    onDragStart: C,
                    onDragEnd: b,
                    horizontal: !0
                }));

                function C() {
                    T(!0)
                }

                function b() {
                    T(!1)
                }
            }
        },
        35842: (e, t, n) => {
            "use strict";
            n.d(t, {
                SizeContext: () => o
            });
            const o = n(59496).createContext({
                size: 0,
                smallSizeTreeNodeAction: 1
            })
        },
        49392: (e, t, n) => {
            "use strict";
            n.d(t, {
                resetTree: () => r,
                syncNodes: () => s,
                setNodes: () => i,
                selectPrevious: () => l,
                selectNext: () => c,
                multiSelectPrevious: () => a,
                multiSelectNext: () => d,
                processDropTarget: () => u,
                dropSelection: () => p,
                updateDropTarget: () => h,
                hideDropTarget: () => f,
                setSelectedIds: () => m,
                moveNodes: () => g,
                startMultiSelect: () => E,
                stopMultiSelect: () => S,
                setFocusedNode: () => v,
                scrollToId: () => T,
                setIsSelected: () => _,
                setIsExpanded: () => y,
                setDisabledNodes: () => D,
                endDrag: () => C
            });
            var o = n(71505);
            const r = () => ({
                    type: o.RESET_TREE
                }),
                s = e => ({
                    type: o.SYNC_NODES,
                    nodes: e
                }),
                i = e => ({
                    type: o.SET_NODES,
                    nodes: e
                }),
                l = () => ({
                    type: o.SELECT_PREVIOUS
                }),
                c = () => ({
                    type: o.SELECT_NEXT
                }),
                a = () => ({
                    type: o.MULTI_SELECT_PREVIOUS
                }),
                d = () => ({
                    type: o.MULTI_SELECT_NEXT
                }),
                u = (e, t, n, r, s) => ({
                    type: o.PROCESS_DROP_TARGET,
                    dropTarget: e,
                    dropType: t,
                    isHoveredLeft: n,
                    boundBox: r,
                    isLastChild: s
                }),
                p = () => ({
                    type: o.DROP_SELECTION
                }),
                h = (e, t, n) => ({
                    type: o.UPDATE_DROP_TARGET,
                    node: e,
                    dropType: t,
                    boundBox: n
                }),
                f = () => ({
                    type: o.HIDE_DROP_TARGET
                }),
                m = e => ({
                    type: o.SET_SELECTED_IDS,
                    ids: e
                }),
                g = (e, t, n) => ({
                    type: o.MOVE_NODES,
                    ids: e,
                    targetId: t,
                    dropType: n
                }),
                E = () => ({
                    type: o.START_MULTI_SELECT
                }),
                S = () => ({
                    type: o.STOP_MULTI_SELECT
                }),
                v = e => ({
                    type: o.SET_FOCUSED_NODE,
                    nodeId: e
                }),
                T = e => ({
                    type: o.SCROLL_TO_ID,
                    nodeId: e
                }),
                _ = (e, t, n = 0) => ({
                    type: o.SET_IS_SELECTED,
                    nodeId: e,
                    isSelected: t,
                    mode: n
                }),
                y = (e, t) => ({
                    type: o.SET_IS_EXPANDED,
                    nodeId: e,
                    isExpanded: t
                }),
                D = e => ({
                    type: o.SET_DISABLED_NODES,
                    ids: e
                }),
                C = () => ({
                    type: o.END_DRAG
                })
        },
        71505: (e, t, n) => {
            "use strict";
            n.d(t, {
                SET_NODES: () => r,
                SYNC_NODES: () => s,
                UPDATE_NODE: () => i,
                UPDATE_NODES: () => l,
                RESET_TREE: () => c,
                SET_SELECTED_IDS: () => a,
                DROP_SELECTION: () => d,
                SELECT_PREVIOUS: () => u,
                SELECT_NEXT: () => p,
                MULTI_SELECT_PREVIOUS: () => h,
                MULTI_SELECT_NEXT: () => f,
                PROCESS_DROP_TARGET: () => m,
                UPDATE_DROP_TARGET: () => g,
                HIDE_DROP_TARGET: () => E,
                START_MULTI_SELECT: () => S,
                STOP_MULTI_SELECT: () => v,
                SET_FOCUSED_NODE: () => T,
                SCROLL_TO_ID: () => _,
                SET_IS_SELECTED: () => y,
                SET_IS_EXPANDED: () => D,
                SET_DISABLED_NODES: () => C,
                MOVE_NODES: () => b,
                END_DRAG: () => w
            });
            const o = (0, n(15078).createActionTypeFactory)("OBJECT_TREE"),
                r = o("SET_NODES"),
                s = o("SYNC_NODES"),
                i = o("UPDATE_NODE"),
                l = o("UPDATE_NODES"),
                c = o("RESET_TREE"),
                a = o("SET_SELECTED_IDS"),
                d = o("DROP_SELECTION"),
                u = o("SELECT_PREVIOUS"),
                p = o("SELECT_NEXT"),
                h = o("MULTI_SELECT_PREVIOUS"),
                f = o("MULTI_SELECT_NEXT"),
                m = o("PROCESS_DROP_TARGET"),
                g = o("UPDATE_DROP_TARGET"),
                E = o("HIDE_DROP_TARGET"),
                S = o("START_MULTI_SELECT"),
                v = o("STOP_MULTI_SELECT"),
                T = (o("REMOVE_NODE"), o("SET_FOCUSED_NODE")),
                _ = o("SCROLL_TO_ID"),
                y = o("SET_IS_SELECTED"),
                D = o("SET_IS_EXPANDED"),
                C = o("SET_DISABLED_NODES"),
                b = o("MOVE_NODES"),
                w = (o("START_DRAG"), o("END_DRAG"))
        },
        29881: (e, t, n) => {
            "use strict";
            n.d(t, {
                nodesSelector: () => s,
                dropTargetSelector: () => l,
                scrollToIdSelector: () => a,
                nodeSelector: () => u,
                isSelectedSelector: () => p,
                isExpandedSelector: () => h,
                isDisabledSelector: () => f,
                nodeIdsSelector: () => m,
                selectedIdsSelector: () => g,
                lastFocusedNodeIdSelector: () => E,
                isMultiSelectingSelector: () => S,
                selectedNodesSelector: () => v,
                orderedNodesSelector: () => _,
                renderListSelector: () => D,
                renderDragListSelector: () => C
            });
            var o = n(77145),
                r = n(88537);
            const s = e => e.nodes,
                i = e => e.selection,
                l = e => e.dropTarget,
                c = e => e.expanded,
                a = e => e.scrollToId,
                d = (e, t) => t,
                u = (0, o.createSelector)([s, d], (e, t) => e[t]),
                p = (0, o.createSelector)([i, d], (e, t) => e.ids.includes(t)),
                h = (0, o.createSelector)([c, d], (e, t) => e.includes(t)),
                f = (0, o.createSelector)([e => e.disabled, i, d], (e, t, n) => !t.ids.includes(n) && e.includes(n)),
                m = (0, o.createSelector)(s, e => Object.keys(e)),
                g = (0, o.createSelector)(i, ({
                    ids: e
                }) => e),
                E = (0, o.createSelector)(i, ({
                    lastFocusedNodeId: e
                }) => e),
                S = (0, o.createSelector)(i, ({
                    isMultiSelecting: e
                }) => e),
                v = (0, o.createSelector)([s, g], (e, t) => t.map(t => e[t])),
                T = (0, o.createSelector)(s, e => Object.values(e).filter(e => 0 === e.level)),
                _ = (0, o.createSelector)([s, T], (e, t) => t.reduce((t, n) => [...t, ...y(e, (0, r.ensureDefined)(n))], []));

            function y(e, t) {
                const n = [];
                for (const o of t.children) n.push(e[o]), n.push(...y(e, e[o]));
                return n
            }
            const D = (0, o.createSelector)([s, T, c], (e, t, n) => {
                    const o = new Set(n);
                    return t.reduce((t, n) => [...t, ...b(e, (0, r.ensureDefined)(n), o)], [])
                }),
                C = (0, o.createSelector)([s, g, c], (e, t, n) => {
                    const o = new Set(n);
                    return [{
                        id: "drag-list",
                        level: -1,
                        children: t
                    }].reduce((t, n) => [...t, ...b(e, (0, r.ensureDefined)(n), o)], [])
                });

            function b(e, t, n) {
                const o = [];
                for (const r of t.children) {
                    const t = e[r];
                    void 0 !== t && (o.push(t), n.has(r) && o.push(...b(e, t, n)))
                }
                return o
            }
        },
        51539: (e, t, n) => {
            "use strict";
            n.d(t, {
                logger: () => s,
                getInsertIndex: () => i
            });
            var o = n(51951),
                r = n(88537);
            const s = (0, o.getLogger)("Platform.GUI.ObjectTree.CallApi"),
                i = (e, t, n) => {
                    switch (n) {
                        case "before":
                            return e.indexOf((0, r.ensureDefined)(t));
                        case "inside":
                            return e.length;
                        case "after":
                            return e.indexOf((0, r.ensureDefined)(t)) + 1;
                        default:
                            return 0
                    }
                }
        },
        17447: (e, t, n) => {
            "use strict";
            n.d(t, {
                Tree: () => Ne
            });
            var o = n(59496),
                r = n(54773),
                s = n(79049),
                i = n(11307),
                l = n(36028),
                c = n(86416),
                a = n(36349),
                d = n(71505),
                u = n(49392),
                p = n(29881);

            function* h(e) {
                const {
                    selectedIds: t,
                    nodes: n
                } = yield(0, a.call)(e), o = {};
                for (let e = 0; e < n.length; ++e) {
                    const t = n[e];
                    o[t.id] = t
                }
                yield(0, a.put)((0, u.setNodes)(o)), yield(0, a.put)((0, u.setSelectedIds)(t));
                !(0, p.lastFocusedNodeIdSelector)(yield(0, a.select)()) && t.length > 0 && (yield(0, a.put)((0, u.setFocusedNode)(t[0])), yield(0, a.put)((0, u.scrollToId)(t[0])))
            }
            var f = n(88537);

            function* m(e) {
                for (;;) {
                    if ((yield(0, a.take)([d.START_MULTI_SELECT, d.STOP_MULTI_SELECT])).type === d.START_MULTI_SELECT) {
                        const t = (0, p.nodeIdsSelector)(yield(0, a.select)()).filter(t => !e(t));
                        yield(0, a.put)((0, u.setDisabledNodes)(t))
                    } else yield(0, a.put)((0, u.setDisabledNodes)([]))
                }
            }

            function* g() {
                for (;;) {
                    const {
                        type: e
                    } = yield(0, a.take)([d.MULTI_SELECT_NEXT, d.MULTI_SELECT_PREVIOUS]), t = yield(0, a.select)(), n = (0, p.orderedNodesSelector)(t), o = n.length, r = (0, p.lastFocusedNodeIdSelector)(t), s = [...(0, p.selectedIdsSelector)(t)], i = 1 === s.length && s[0] !== r, l = n.findIndex(e => e.id === (i ? s[0] : r));
                    if (e === d.MULTI_SELECT_PREVIOUS && 0 === l || e === d.MULTI_SELECT_NEXT && l === o - 1) continue;
                    const c = D(t, e === d.MULTI_SELECT_NEXT ? "next" : "previous", n, l),
                        {
                            id: h
                        } = c;
                    s.includes(h) && r ? (yield(0, a.put)((0, u.setIsSelected)(r, !1, 1)), yield(0, a.put)((0, u.setFocusedNode)(h))) : yield(0, a.put)((0,
                        u.setIsSelected)(h, !0, 1)), yield(0, a.put)((0, u.scrollToId)(h))
                }
            }

            function* E(e, t) {
                for (;;) {
                    const {
                        type: n
                    } = yield(0, a.take)([d.SELECT_NEXT, d.SELECT_PREVIOUS]), o = yield(0, a.select)(), r = (0, p.orderedNodesSelector)(o), s = (0, p.selectedNodesSelector)(o), i = (0, p.lastFocusedNodeIdSelector)(o);
                    if (1 === s.length && s[0].id !== i && !i) {
                        if (n === d.SELECT_NEXT) {
                            yield(0, a.put)((0, u.setFocusedNode)(s[0].id));
                            continue
                        }
                        if (n === d.SELECT_PREVIOUS) {
                            const e = r.findIndex(e => e.id === s[0].id),
                                t = D(o, "previous", r, e);
                            yield(0, a.put)((0, u.setFocusedNode)(t.id));
                            continue
                        }
                    }
                    const l = r.findIndex(e => e.id === i),
                        c = n === d.SELECT_NEXT ? "next" : "previous",
                        h = D(o, c, r, l),
                        {
                            id: f
                        } = h;
                    e ? e([f], c) : yield(0, a.put)((0, u.setSelectedIds)([f])), t && t(f), yield(0, a.put)((0, u.setFocusedNode)(f))
                }
            }

            function* S(e, t = (() => !0)) {
                for (;;) {
                    const {
                        mode: n,
                        nodeId: o,
                        isSelected: r
                    } = yield(0, a.take)(d.SET_IS_SELECTED);
                    let s = [...(0, p.selectedIdsSelector)(yield(0, a.select)())];
                    const i = (0, p.orderedNodesSelector)(yield(0, a.select)());
                    if (1 === n) r ? s.push(o) : s.splice(s.indexOf(o), 1);
                    else if (2 === n && s.length > 0) {
                        const e = (0, p.lastFocusedNodeIdSelector)(yield(0, a.select)());
                        let n = i.findIndex(t => t.id === e); - 1 === n && (n = i.reduce((e, t, n) => s.includes(t.id) ? n : e, -1));
                        const r = i.findIndex(e => e.id === o);
                        if (n !== r)
                            for (let e = Math.min(n, r); e <= Math.max(n, r); e++) {
                                const n = i[e].id;
                                !s.includes(n) && t(n) && s.push(n)
                            }
                    } else s = o ? [o] : [];
                    const l = new Set(s);
                    s = i.reduce((e, t) => (l.has(t.id) && e.push(t.id), e), []), e ? e(s) : yield(0, a.put)((0, u.setSelectedIds)(s)), yield(0, a.put)((0, u.setFocusedNode)(o))
                }
            }

            function* v(e = (() => !0), t) {
                const {
                    dropTarget: n,
                    dropType: o,
                    isHoveredLeft: r,
                    boundBox: s,
                    isLastChild: i
                } = t, l = (0, p.dropTargetSelector)(yield(0, a.select)()), c = (0, p.nodeSelector)(yield(0, a.select)(), (0, f.ensureDefined)(n.parentId)), d = i && "after" === o, h = (0, p.selectedNodesSelector)(yield(0, a.select)()), m = !d || !r && e(h, n, o) ? n : c, g = l.node && l.node.id !== m.id || l.dropType !== o;
                h.map(e => e.id).includes(m.id) ? yield(0, a.put)((0, u.hideDropTarget)()): g && e(h, m, o) && (yield(0, a.put)((0, u.updateDropTarget)(m, o, s)))
            }

            function* T(e) {
                yield(0, a.throttle)(0, d.PROCESS_DROP_TARGET, v, e)
            }

            function* _(e) {
                for (;;) {
                    yield(0, a.take)(d.DROP_SELECTION);
                    const t = (0, p.selectedNodesSelector)(yield(0, a.select)()),
                        {
                            node: n,
                            dropType: o
                        } = (0, p.dropTargetSelector)(yield(0, a.select)());
                    if (n && o) {
                        const r = new CustomEvent("tree-node-drop", {
                            detail: {
                                nodes: t,
                                target: n.id,
                                type: o
                            }
                        });
                        if (e && e(r), !r.defaultPrevented) {
                            const e = (0, p.selectedIdsSelector)(yield(0, a.select)());
                            yield(0, a.put)((0, u.moveNodes)(e, n.id, o))
                        }
                    }
                }
            }

            function* y(e) {
                for (;;) {
                    yield(0, a.take)(d.MOVE_NODES);
                    e((0, p.nodesSelector)(yield(0, a.select)()))
                }
            }

            function D(e, t, n, o) {
                const r = n.length;
                let s; - 1 === o && "previous" === t && (o = r);
                let i = 0;
                for (; !s || Math.abs(i) < r && ((l = s).level > 1 && !(0, p.isExpandedSelector)(e, (0, f.ensureDefined)(l.parentId)));) i += "next" === t ? 1 : -1, s = n[(o + i + r) % r];
                var l;
                return s
            }

            function* C(e = {}) {
                const {
                    saga: t,
                    onDrop: n,
                    canMove: o,
                    onMove: r,
                    onSelect: s,
                    onKeyboardSelect: i,
                    initState: l,
                    canBeAddedToSelection: c
                } = e, u = [(0, a.fork)(T, o), (0, a.fork)(_, n), (0, a.fork)(S, s, c), (0, a.fork)(E, s, i), (0, a.fork)(g)];
                for (t && u.push((0, a.fork)(t)), r && u.push((0, a.fork)(y, r)), c && u.push((0, a.fork)(m, c));;) {
                    l && (yield(0,
                        a.call)(h, l));
                    const e = yield(0, a.all)(u);
                    yield(0, a.take)(d.RESET_TREE);
                    for (const t of e) yield(0, a.cancel)(t)
                }
            }
            var b = n(83243),
                w = n(2683),
                N = n(51539);
            const x = {
                ids: [],
                lastFocusedNodeId: void 0,
                isMultiSelecting: !1
            };
            const I = {
                node: void 0,
                dropType: void 0,
                boundBox: void 0
            };
            const O = (0, b.combineReducers)({
                nodes: function(e = {}, t) {
                    switch (t.type) {
                        case d.SET_NODES:
                            return t.nodes;
                        case d.SYNC_NODES:
                            {
                                const {
                                    nodes: n
                                } = t,
                                o = n.map(e => e.id),
                                r = { ...e
                                };
                                for (const t of Object.keys(e))
                                    if (!o.includes(t)) {
                                        const {
                                            parentId: e
                                        } = r[t];
                                        e && (r[e] = { ...r[e],
                                            children: r[e].children.filter(e => e !== t)
                                        }), delete r[t]
                                    }
                                for (const e of n) {
                                    const t = e.id;
                                    if (r.hasOwnProperty(t)) {
                                        !(0, w.deepEquals)(r[t].children, e.children)[0] && (r[t] = { ...r[t],
                                            children: [...e.children]
                                        })
                                    } else {
                                        r[t] = e;
                                        const {
                                            parentId: n
                                        } = e;
                                        if (n && !r[n].children.includes(t)) throw new Error("Not implemented")
                                    }
                                }
                                return r
                            }
                        case d.UPDATE_NODE:
                            {
                                const {
                                    type: n,
                                    nodeId: o,
                                    ...r
                                } = t;
                                return { ...e,
                                    [o]: { ...e[o],
                                        ...r
                                    }
                                }
                            }
                        case d.UPDATE_NODES:
                            {
                                const {
                                    nodes: n
                                } = t,
                                o = { ...e
                                };
                                return Object.keys(n).forEach(e => {
                                    o[e] = { ...o[e],
                                        ...n[e]
                                    }
                                }),
                                { ...e,
                                    ...o
                                }
                            }
                        case d.MOVE_NODES:
                            {
                                const {
                                    ids: n,
                                    targetId: o,
                                    dropType: r
                                } = t,
                                s = (0, f.ensureDefined)(e[o].parentId),
                                i = e[s],
                                l = {};
                                for (const t of n) {
                                    const n = e[t];
                                    if (n.parentId) {
                                        const o = l[n.parentId] || e[n.parentId];
                                        l[n.parentId] = { ...o,
                                            children: o.children.filter(e => e !== t)
                                        }
                                    }
                                    l[t] = { ...n,
                                        parentId: s,
                                        level: i.level + 1
                                    }
                                }
                                const c = i.children.filter(e => !n.includes(e));
                                return c.splice((0, N.getInsertIndex)(c, o, r), 0, ...n),
                                l[s] = { ...e[s],
                                    children: c,
                                    isExpanded: !0
                                },
                                { ...e,
                                    ...l
                                }
                            }
                        default:
                            return e
                    }
                },
                selection: function(e = x, t) {
                    switch (t.type) {
                        case d.SET_SELECTED_IDS:
                            {
                                const {
                                    ids: n
                                } = t;
                                return { ...e,
                                    ids: n,
                                    lastFocusedNodeId: n.length > 0 ? e.lastFocusedNodeId : void 0
                                }
                            }
                        case d.START_MULTI_SELECT:
                            return { ...e,
                                isMultiSelecting: !0
                            };
                        case d.STOP_MULTI_SELECT:
                            return { ...e,
                                isMultiSelecting: !1
                            };
                        case d.SET_FOCUSED_NODE:
                            return { ...e,
                                lastFocusedNodeId: t.nodeId
                            };
                        case d.SYNC_NODES:
                            {
                                const n = new Set(t.nodes.map(e => e.id));
                                return e.lastFocusedNodeId && !n.has(e.lastFocusedNodeId) && delete e.lastFocusedNodeId,
                                { ...e,
                                    ids: e.ids.filter(e => n.has(e))
                                }
                            }
                        default:
                            return e
                    }
                },
                dropTarget: function(e = I, t) {
                    switch (t.type) {
                        case d.UPDATE_DROP_TARGET:
                            {
                                const {
                                    node: n,
                                    dropType: o,
                                    boundBox: r
                                } = t;
                                return { ...e,
                                    node: n,
                                    dropType: o,
                                    boundBox: r
                                }
                            }
                        case d.HIDE_DROP_TARGET:
                        case d.END_DRAG:
                        case d.RESET_TREE:
                            return { ...I
                            };
                        default:
                            return e
                    }
                },
                expanded: function(e = [], t) {
                    switch (t.type) {
                        case d.SET_IS_EXPANDED:
                            {
                                const {
                                    nodeId: n,
                                    isExpanded: o
                                } = t;
                                if (o) return [...e, n];
                                const r = [...e];
                                return r.splice(e.indexOf(n), 1),
                                r
                            }
                        default:
                            return e
                    }
                },
                disabled: function(e = [], t) {
                    switch (t.type) {
                        case d.SET_DISABLED_NODES:
                            return [...t.ids];
                        default:
                            return e
                    }
                },
                scrollToId: function(e = null, t) {
                    switch (t.type) {
                        case d.SCROLL_TO_ID:
                            return null === t.nodeId ? null : {
                                id: t.nodeId
                            };
                        default:
                            return e
                    }
                }
            });
            var M = n(97754),
                L = n.n(M),
                R = n(63318),
                P = n(83199),
                A = n(1227);
            var k = n(73942),
                F = n(53408),
                B = n(72571),
                W = n(80185),
                H = n(69842),
                z = n(21258),
                U = n(35842);
            const j = {
                [W.Modifiers.Mod]: 1,
                [W.Modifiers.Shift]: 2
            };
            var G = n(34677),
                V = n(91069);
            const K = () => {};
            class X extends o.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._handleRef = e => {
                        this._ref = e;
                        const {
                            connectDragSource: t,
                            connectDropTarget: n,
                            connectDragPreview: o
                        } = this.props;
                        (0, f.ensureDefined)(n)(this._ref), (0, f.ensureDefined)(t)(this._ref), (0, f.ensureDefined)(o)((0, F.getEmptyImage)(), {
                            captureDraggingState: !0
                        })
                    }, this._handleTouchStart = e => {
                        const t = (e, t) => {
                                const n = function(e, t) {
                                    try {
                                        const n = document.createEvent("TouchEvent");
                                        return n.initTouchEvent(e, !0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, t.touches, t.targetTouches, t.changedTouches), n
                                    } catch (e) {
                                        return null
                                    }
                                }(e, t);
                                if (n) return n;
                                const o = Array.from(t.changedTouches),
                                    r = Array.from(t.touches),
                                    s = Array.from(t.targetTouches);
                                return new TouchEvent(e, {
                                    bubbles: !0,
                                    changedTouches: o,
                                    touches: r,
                                    targetTouches: s
                                })
                            },
                            n = e.target;
                        if (n instanceof Element) {
                            const e = e => {
                                    const o = e;
                                    if (!n.isConnected) {
                                        o.preventDefault();
                                        const e = t("touchmove", o);
                                        document.body.dispatchEvent(e)
                                    }
                                },
                                o = r => {
                                    const s = r;
                                    if (!n.isConnected) {
                                        s.preventDefault();
                                        const e = t("touchend", s);
                                        document.body.dispatchEvent(e)
                                    }
                                    n.removeEventListener("touchend", o), n.removeEventListener("touchmove", e)
                                };
                            n.addEventListener("touchend", o), n.addEventListener("touchmove", e)
                        }
                    }
                }
                componentDidMount() {
                    var e;
                    null === (e = this._ref) || void 0 === e || e.addEventListener("touchstart", this._handleTouchStart)
                }
                componentWillUnmount() {
                    var e;
                    null === (e = this._ref) || void 0 === e || e.removeEventListener("touchstart", this._handleTouchStart)
                }
                render() {
                    return o.createElement(q, { ...this.props,
                        reference: this._handleRef
                    })
                }
                getNode() {
                    return (0, f.ensureNotNull)(this._ref)
                }
            }
            const q = e => {
                    const {
                        id: t,
                        isSelected: n,
                        isOffset: r,
                        isExpandable: s,
                        setIsSelected: i,
                        isDisabled: l,
                        isExpanded: c,
                        onClick: a,
                        parentId: d,
                        setIsExpanded: u,
                        reference: p,
                        isFirstListItem: h,
                        isLastListItem: f,
                        nodeRenderer: m,
                        isChildOfSelected: g = !1
                    } = e, {
                        size: E,
                        smallSizeTreeNodeAction: S
                    } = (0, o.useContext)(U.SizeContext), v = (0, o.useRef)(null), T = (0, H.createSafeMulticastEventHandler)(e => v.current = e, p);
                    let [_, y] = (0, z.useHover)();
                    return (A.CheckMobile.any() || A.CheckMobile.isIPad()) && (_ = n, y = {
                        onMouseOut: K,
                        onMouseOver: K
                    }), o.createElement("div", {
                        className: M(V.wrap, n && V.selected, g && V.childOfSelected, l && V.disabled, s && V.expandable),
                        onClick: 1 === E && 0 === S ? D : function(e) {
                            if (e.defaultPrevented) return;
                            const o = j[(0, W.modifiersFromEvent)(e)] || 0;
                            !l && i && i(t, !n, o);
                            a && 0 === o && a(e, t)
                        },
                        onContextMenu: D,
                        ref: T,
                        ...y
                    }, s && o.createElement(B.Icon, {
                        icon: G,
                        className: M(V.expandHandle, c && V.expanded),
                        onClick: function(e) {
                            e.preventDefault(), s && u(t, !c)
                        },
                        onMouseDown: function(e) {
                            e.preventDefault()
                        }
                    }), m({
                        id: t,
                        isOffset: r,
                        parentId: d,
                        isDisabled: l,
                        isSelected: n,
                        isChildOfSelected: g,
                        isHovered: _,
                        isExpanded: c,
                        isFirstListItem: h,
                        isLastListItem: f
                    }));

                    function D() {
                        l || n || !i || i(t, !0)
                    }
                },
                Z = o.createContext({});

            function Q(e, t) {
                const {
                    id: n
                } = t, o = (0, p.nodeSelector)(e, n), r = (0, p.isSelectedSelector)(e, n);
                let s = !1,
                    i = o.parentId;
                for (; i && !s;) s = (0, p.isSelectedSelector)(e, i), i = (0, p.nodeSelector)(e, i).parentId;
                return { ...o,
                    isSelected: r,
                    isChildOfSelected: s,
                    isExpanded: o.children.length > 0 && (0, p.isExpandedSelector)(e, n),
                    isExpandable: o.children.length > 0,
                    isDisabled: (0, p.isDisabledSelector)(e, n)
                }
            }

            function Y(e) {
                return (0, b.bindActionCreators)({
                    setIsExpanded: u.setIsExpanded,
                    processDropTarget: u.processDropTarget,
                    dropSelection: u.dropSelection,
                    selectNext: u.selectNext,
                    selectPrevious: u.selectPrevious,
                    setIsSelected: u.setIsSelected,
                    endDrag: u.endDrag
                }, e)
            }
            const J = (0, k.DragSource)("node", {
                    beginDrag: e => {
                        const {
                            id: t,
                            isDisabled: n,
                            isSelected: o
                        } = e;
                        return n || o || e.setIsSelected(t, !0), e
                    },
                    endDrag: e => e.endDrag()
                }, e => ({
                    connectDragSource: e.dragSource(),
                    connectDragPreview: e.dragPreview()
                })),
                $ = (0, R.DropTarget)("node", {
                    hover: (e, t, n) => {
                        if (!n) return;
                        const o = n.getNode(),
                            r = o.getBoundingClientRect(),
                            s = r.bottom - r.top,
                            i = t.getClientOffset();
                        if (i) {
                            const t = i.y - r.top;
                            let n, l;
                            if (n = 0 === e.children.length ? t < s / 2 ? "before" : "after" : t < s / 3 ? "before" : e.isExpanded || t >= s / 3 && t < 2 * s / 3 ? "inside" : "after", void 0 !== e.getContainerElement) {
                                const t = e.getContainerElement().getBoundingClientRect();
                                l = {
                                    top: r.top - t.top,
                                    left: r.left - t.left,
                                    bottom: r.top - t.top + r.height,
                                    right: r.left - t.left + r.width,
                                    height: r.height,
                                    width: r.width
                                }
                            } else l = {
                                top: o.offsetTop,
                                left: o.offsetLeft,
                                bottom: o.offsetTop + o.offsetHeight,
                                right: o.offsetLeft + o.offsetWidth,
                                height: o.offsetHeight,
                                width: o.offsetWidth
                            };
                            e.processDropTarget(e, n, i.x - r.left < 48, l, e.isLastChild)
                        }
                    }
                }, e => ({
                    connectDropTarget: e.dropTarget()
                })),
                ee = (0, s.connect)(Q, Y, null, {
                    context: Z
                })(J($(X))),
                te = (0, s.connect)(Q, Y, null, {
                    context: Z
                })(q);
            var ne = n(98043),
                oe = n(53614),
                re = n(8361);

            function se(e) {
                const t = e(),
                    n = (0, o.useRef)(t);
                n.current = t;
                const [r, s] = (0, o.useState)(n.current), i = (0, o.useRef)(null);
                return (0, o.useEffect)(() => {
                    null === i.current && (i.current = requestAnimationFrame(() => {
                        i.current = null, s(n.current)
                    }))
                }), (0, o.useEffect)(() => () => {
                    i.current && cancelAnimationFrame(i.current)
                }, []), r
            }

            function ie(e) {
                const {
                    dropTargetOffset: t,
                    mousePosition: n
                } = e;
                if (!t) return {
                    display: "none"
                };
                const {
                    x: o,
                    y: r
                } = t, s = n && t ? n.y - t.y : 0, i = `translate(${o+(n&&t?n.x-t.x:0)}px, ${r+s}px)`;
                return {
                    transform: i,
                    WebkitTransform: i
                }
            }
            const le = {
                top: 0,
                left: 0,
                position: "fixed",
                pointerEvents: "none",
                zIndex: 100,
                opacity: .5,
                width: 300,
                backgroundColor: "red"
            };
            const ce = (0, oe.DragLayer)((function(e) {
                return {
                    isDragging: e.isDragging() && "node" === e.getItemType(),
                    mousePosition: e.getClientOffset(),
                    dropTargetOffset: e.getSourceClientOffset()
                }
            }))((0, s.connect)((function(e) {
                return {
                    items: (0, p.renderDragListSelector)(e)
                }
            }), null, null, {
                context: Z
            })((function(e) {
                const {
                    items: t,
                    isDragging: n,
                    nodeRenderer: r,
                    dragPreviewRenderer: s
                } = e;
                return se((function() {
                    return n ? o.createElement(re.Portal, null, o.createElement("div", {
                        style: { ...le,
                            ...ie(e)
                        }
                    }, t.map(e => {
                        if (s) {
                            const t = s;
                            return o.createElement(t, {
                                key: e.id,
                                ...e
                            })
                        }
                        return o.createElement(te, {
                            id: e.id,
                            key: e.id,
                            nodeRenderer: r,
                            isDragPreview: !0,
                            isOffset: e.level > 1
                        })
                    }))) : null
                }))
            })));
            var ae = n(93838),
                de = n(73288),
                ue = n(39043);
            const pe = o.forwardRef((e, t) => {
                    const n = (0, o.useRef)(null);
                    return e.connectDropTarget(n), (0, o.useImperativeHandle)(t, () => ({
                        getNode: () => (0, f.ensureNotNull)(n.current)
                    }), []), o.createElement("div", {
                        ref: n,
                        style: {
                            height: "100%",
                            width: "100%"
                        }
                    })
                }),
                he = (0, R.DropTarget)("node", {
                    hover: (e, t, n) => {
                        if (!n) return;
                        const o = t.getClientOffset();
                        if (null === o) return;
                        const r = e.getOrderedNodes();
                        if (0 === r.length) return;
                        const s = n.getNode().getBoundingClientRect(),
                            i = e.getContainerElement().getBoundingClientRect();
                        if ("first" === e.type) {
                            const t = {
                                top: s.top - i.top + s.height,
                                left: s.left - i.left,
                                bottom: s.top - i.top + s.height,
                                right: s.left - i.left + s.width,
                                height: 0,
                                width: s.width
                            };
                            e.processDropTarget(r[0], "before", !1, t, !1)
                        }
                        if ("last" === e.type) {
                            const t = o.x - s.left < 48,
                                n = r[r.length - 1],
                                l = t && 2 === n.level ? (0, f.ensureDefined)(r.find(e => e.id === n.parentId)) : n,
                                c = {
                                    top: s.top - i.top,
                                    left: s.left - i.left,
                                    bottom: s.top - i.top,
                                    right: s.left - i.left + s.width,
                                    height: s.height,
                                    width: s.width
                                };
                            e.processDropTarget(l, "after", t, c, !1)
                        }
                    }
                }, e => ({
                    connectDropTarget: e.dropTarget()
                }))(pe),
                fe = o.createContext({
                    isOver: !1,
                    transform: void 0
                });
            var me = n(62461);

            function ge(e) {
                const {
                    dropType: t,
                    boundBox: n
                } = e, {
                    top: o,
                    bottom: r,
                    left: s
                } = (0, f.ensureDefined)(n);
                return [s, "before" === t || "inside" === t ? o : r]
            }
            const Ee = (0, oe.DragLayer)((function(e) {
                    return {
                        isDragging: e.isDragging()
                    }
                }))((0, s.connect)((function(e) {
                    const {
                        boundBox: t,
                        dropType: n,
                        node: o
                    } = (0, p.dropTargetSelector)(e);
                    return {
                        boundBox: t,
                        dropType: n,
                        level: o ? o.level : void 0
                    }
                }), null, null, {
                    context: Z
                })((function(e) {
                    const {
                        dropType: t,
                        boundBox: n,
                        isDragging: r,
                        level: s,
                        transform: i = ge
                    } = e;
                    return se((function() {
                        if (!r || !t || !n) return null;
                        const l = {
                                [me.dropTarget]: "inside" !== t,
                                [me.dropTargetInside]: "inside" === t
                            },
                            {
                                width: c,
                                height: a
                            } = n,
                            [d, u] = i(e),
                            p = `translate(${d}px, ${u}px)`;
                        return o.createElement("div", {
                            className: M(l),
                            style: {
                                position: "absolute",
                                transform: p,
                                WebkitTransform: p,
                                top: 0,
                                left: 2 === s ? "46px" : 0,
                                width: 2 === s ? c - 46 + "px" : c,
                                height: "inside" === t ? a : "2px"
                            }
                        })
                    }))
                }))),
                Se = o.forwardRef((e, t) => {
                    const n = (0, o.useContext)(fe);
                    return o.createElement("div", { ...e,
                        ref: t
                    }, e.children, n.isOver && o.createElement(Ee, {
                        transform: n.transform
                    }))
                });
            var ve = n(34581),
                Te = n(34244);
            const _e = 38 + W.Modifiers.Shift,
                ye = 40 + W.Modifiers.Shift;
            const De = o.forwardRef((function(e, t) {
                    const {
                        navigationKeys: n,
                        renderList: r,
                        stopMultiSelect: s,
                        startMultiSelect: i,
                        isMultiSelecting: l,
                        nodeRenderer: c,
                        dragPreviewRenderer: a,
                        className: d,
                        connectDropTarget: u,
                        readOnly: p,
                        onClick: h,
                        dropLayerTransform: m,
                        setFocusedNode: g,
                        scrollToId: E,
                        rowHeight: S,
                        onMultiSelectPrevious: v,
                        onMultiSelectNext: T,
                        onMoveCursorToNext: _,
                        onMoveCursorToPrevious: y,
                        outerRef: D,
                        width: C,
                        height: b,
                        isOver: w,
                        processDropTarget: N
                    } = e, x = (0, o.useContext)(ae.ObjectTreeContext), I = (0, o.useRef)(null);
                    (0, o.useEffect)(() => {
                        const e = e => {
                                [W.Modifiers.Mod, W.Modifiers.Shift].includes((0, W.modifiersFromEvent)(e)) && i()
                            },
                            t = e => {
                                l && ![W.Modifiers.Mod, W.Modifiers.Shift].includes((0, W.modifiersFromEvent)(e)) && s()
                            };
                        return document.addEventListener("keydown", e), document.addEventListener("keyup", t), document.addEventListener("mousemove", t), () => {
                            document.removeEventListener("keydown", e), document.removeEventListener("keyup", t), document.removeEventListener("mousemove", t)
                        }
                    }, [l]),
                    function(e) {
                        (0, o.useEffect)(() => {
                            if (A.isEdge) {
                                let t = null;
                                const n = (0, f.ensureNotNull)(e.current),
                                    o = e => {
                                        if (e.target instanceof Element) {
                                            const n = (0, f.ensureNotNull)(e.target.closest("[draggable]"));
                                            n instanceof HTMLElement && (n.style.opacity = "0", t = requestAnimationFrame(() => n.style.opacity = "1"))
                                        }
                                    };
                                return n.addEventListener("dragstart", o), () => {
                                    n.removeEventListener("dragstart", o), null !== t && cancelAnimationFrame(t)
                                }
                            }
                            return () => {}
                        }, [])
                    }(I);
                    const O = (0, o.useCallback)(() => (0, f.ensureNotNull)(X.current), []),
                        M = (0, o.useCallback)(() => r, [r]),
                        R = (0, o.useMemo)(() => {
                            const e = p ? te : ee,
                                t = [];
                            let n;
                            t.push({
                                type: "padding",
                                node: o.createElement(he, {
                                    type: "first",
                                    key: "padding-top",
                                    getContainerElement: O,
                                    getOrderedNodes: M,
                                    processDropTarget: N
                                })
                            });
                            for (let s = 0; s < r.length; s++) {
                                const i = r[s];
                                1 === i.level && (void 0 !== n && n !== i.parentId && t.push({
                                    type: "separator",
                                    node: o.createElement("div", {
                                        key: n + "_separator",
                                        className: Te.separator
                                    })
                                }), n = i.parentId), t.push({
                                    type: "node",
                                    node: o.createElement(e, {
                                        id: i.id,
                                        key: i.id,
                                        isFirstListItem: 0 === s,
                                        isLastListItem: s === r.length - 1,
                                        isExpandable: i.children.length > 0,
                                        nodeRenderer: c,
                                        readOnly: p,
                                        onClick: h,
                                        isOffset: i.level > 1,
                                        getContainerElement: O
                                    })
                                })
                            }
                            return t.push({
                                type: "padding",
                                node: o.createElement(he, {
                                    type: "last",
                                    key: "padding-bottom",
                                    getContainerElement: O,
                                    getOrderedNodes: M,
                                    processDropTarget: N
                                })
                            }), t
                        }, [r]),
                        k = (0, o.useRef)([]);
                    k.current = R;
                    const F = (0, o.useCallback)(e => {
                            let {
                                style: t
                            } = e;
                            const {
                                index: n
                            } = e;
                            return n === k.current.length - 1 && (t = { ...t,
                                bottom: 0,
                                minHeight: t.height
                            }, delete t.height), o.createElement("div", {
                                style: t
                            }, k.current[n].node)
                        }, []),
                        B = (0, o.useCallback)(e => {
                            const t = k.current[e];
                            return "padding" === t.type ? 6 : "function" == typeof S ? S(e, t) : S
                        }, [S]),
                        H = (0, o.useCallback)(e => (0, f.ensure)(k.current[e].node.key), []),
                        z = (0, o.useMemo)(() => null === E ? {
                            index: -1
                        } : {
                            index: k.current.findIndex(e => e.node.key === E.id)
                        }, [E]);
                    u(I);
                    const [U, j, G, V] = (0, ue.useOverlayScroll)(), K = (0, o.useRef)(null);
                    (0, o.useEffect)(() => (0, f.ensureNotNull)(K.current).resetAfterIndex(0, !0), [R]), (0, o.useEffect)(() => (0, f.ensureNotNull)(K.current).scrollToItem(z.index), [z]);
                    const X = (0, o.useRef)(null),
                        q = (0, o.useMemo)(() => ({
                            isOver: w,
                            transform: m
                        }), [w, m]),
                        Z = (0, o.useRef)(null),
                        Q = (0, o.useRef)({
                            startScroll(e) {
                                const t = () => {
                                    null !== G.current && (Z.current = requestAnimationFrame(t), G.current.scrollBy({
                                        top: e
                                    }))
                                };
                                this.stopScroll(), t()
                            },
                            stopScroll() {
                                null !== Z.current && (cancelAnimationFrame(Z.current), Z.current = null)
                            },
                            getListElement: () => G.current
                        });
                    return (0, o.useImperativeHandle)(t, () => Q.current, []), (0, o.useEffect)(() => () => Q.current.stopScroll(), [w]), o.createElement(fe.Provider, {
                        value: q
                    }, o.createElement("div", { ...j,
                        className: L()(Te.tree, d),
                        ref: I,
                        tabIndex: -1,
                        onKeyDown: function(e) {
                            const t = (0, W.hashFromEvent)(e);
                            if (e.defaultPrevented || (0, ne.isNativeUIInteraction)(t, e.target)) return;
                            x || t !== _e || (e.preventDefault(), v());
                            x || t !== ye || (e.preventDefault(), T());
                            (38 === t || void 0 !== n && "previous" === n[t]) && (e.preventDefault(), y());
                            (40 === t || void 0 !== n && "next" === n[t]) && (e.preventDefault(), _());
                            if ((8 === t || 46 === t) && x) {
                                const {
                                    viewModel: e
                                } = x, t = e.selection(), n = t.selected();
                                if (1 !== n.length) return;
                                const o = e.getNextNodeIdAfterRemove(n[0]);
                                if (null === o) return;
                                e.onChange().subscribe(null, () => {
                                    if (t.selected().length) return;
                                    const n = e.entity(o);
                                    n && (t.set([n]), g(o))
                                }, !0)
                            }
                        }
                    }, o.createElement(de.OverlayScrollContainer, { ...U,
                        className: Te.overlayScrollWrap
                    }), o.createElement(P.VariableSizeList, {
                        ref: function(e) {
                            K.current = e
                        },
                        className: Te.listContainer,
                        width: C,
                        height: b,
                        itemCount: R.length,
                        itemSize: B,
                        children: F,
                        itemKey: H,
                        outerRef: function(e) {
                            G.current = e, D && D(e)
                        },
                        innerRef: function(e) {
                            X.current = e
                        },
                        innerElementType: Se,
                        onItemsRendered: function() {
                            V()
                        },
                        overscanCount: 20,
                        direction: (0, ve.isRtl)() ? "rtl" : "ltr"
                    }), o.createElement(ce, {
                        dragPreviewRenderer: a,
                        nodeRenderer: c
                    })))
                })),
                Ce = (0, R.DropTarget)("node", {
                    drop: (e, t, n) => {
                        ("touch" === e.drag || A.isFF) && n.stopScroll(), t.getItem().dropSelection()
                    },
                    hover: (e, t, n) => {
                        if ("touch" !== e.drag && !A.isFF) return;
                        const o = t.getClientOffset();
                        if (null === o) return;
                        const r = n.getListElement();
                        if (null === r) return;
                        const s = r.getBoundingClientRect();
                        ((t, o, r) => {
                            const s = Math.abs(t - r),
                                i = Math.abs(t - o);
                            if (i > 40 && s > 40 || s <= 40 && i <= 40) return void n.stopScroll();
                            var l, c, a, d;
                            l = i > 20 && i <= 40, a = s <= 20, d = i <= 20, (c = s > 20 && s <= 40) || l ? "touch" === e.drag ? n.startScroll(c ? -5 : 5) : n.startScroll(c ? -2 : 2) : (a || d) && ("touch" === e.drag ? n.startScroll(a ? -10 : 10) : n.startScroll(a ? -5 : 5))
                        })(o.y, s.bottom, s.top)
                    }
                }, (e, t) => ({
                    connectDropTarget: e.dropTarget(),
                    isOver: t.isOver()
                }))(De);
            const be = (0, s.connect)((function(e) {
                    return {
                        renderList: (0, p.renderListSelector)(e),
                        orderedNodes: (0, p.orderedNodesSelector)(e),
                        isMultiSelecting: (0, p.isMultiSelectingSelector)(e),
                        selectedIds: (0, p.selectedIdsSelector)(e),
                        scrollToId: (0, p.scrollToIdSelector)(e)
                    }
                }), (function(e) {
                    return (0, b.bindActionCreators)({
                        startMultiSelect: u.startMultiSelect,
                        stopMultiSelect: u.stopMultiSelect,
                        setFocusedNode: u.setFocusedNode,
                        processDropTarget: u.processDropTarget,
                        onMoveCursorToNext: u.selectNext,
                        onMoveCursorToPrevious: u.selectPrevious,
                        onMultiSelectPrevious: u.multiSelectPrevious,
                        onMultiSelectNext: u.multiSelectNext
                    }, e)
                }), null, {
                    context: Z
                })(Ce),
                we = {
                    delayTouchStart: 100
                };

            function Ne(e) {
                const {
                    canBeAddedToSelection: t,
                    initState: n,
                    onSelect: s,
                    canMove: i,
                    onDrop: l,
                    onMove: c,
                    nodes: a,
                    selectedIds: d,
                    onKeyboardSelect: p,
                    saga: h,
                    lastFocusedNodeObject: f,
                    lastSyncTimestampRef: m,
                    scrollToId: g,
                    ...E
                } = e, [S, v] = (0, o.useState)(null);
                return (0, o.useEffect)(() => {
                    const e = (0, r.default)();
                    v(function(e) {
                        const t = (0, b.applyMiddleware)(e);
                        return (0, b.createStore)(O, t)
                    }(e));
                    const o = e.run(C, {
                        initState: n,
                        onKeyboardSelect: p,
                        saga: h,
                        canMove: i,
                        onMove: c,
                        onDrop: l,
                        onSelect: s,
                        canBeAddedToSelection: t
                    });
                    return () => o.cancel()
                }, []), (0, o.useEffect)(() => (null !== S && a && (m && (m.current = performance.now()), S.dispatch((0, u.syncNodes)(a))), () => {}), [S, a]), (0, o.useEffect)(() => {
                    null !== S && d && S.dispatch((0, u.setSelectedIds)(d))
                }, [S, d]), (0, o.useEffect)(() => {
                    null !== S && (null == f ? void 0 : f.id) && S.dispatch((0, u.setFocusedNode)(f.id))
                }, [S, f]), null === S ? null : o.createElement(xe, {
                    store: S,
                    scrollToId: g,
                    ...E
                })
            }
            const xe = o.memo((function(e) {
                const {
                    store: t,
                    scrollToId: n,
                    ...r
                } = e, a = "touch" === e.drag ? l.TouchBackend : i.HTML5Backend;
                return (0, o.useEffect)(() => {
                    var e;
                    t.dispatch((0, u.scrollToId)(null !== (e = null == n ? void 0 : n.id) && void 0 !== e ? e : null))
                }, [n]), o.createElement(c.DndProvider, {
                    backend: a,
                    options: we
                }, o.createElement(s.Provider, {
                    store: t,
                    context: Z
                }, o.createElement(be, { ...r
                })))
            }))
        },
        93838: (e, t, n) => {
            "use strict";
            n.d(t, {
                ObjectTreeContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        15078: (e, t, n) => {
            "use strict";

            function o(e) {
                return t => e + "__" + t
            }
            n.d(t, {
                createActionTypeFactory: () => o
            })
        },
        63694: (e, t, n) => {
            "use strict";
            n.d(t, {
                DrawerManager: () => r,
                DrawerContext: () => s
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return o.createElement(s.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const s = o.createContext(null)
        },
        59339: (e, t, n) => {
            "use strict";
            n.d(t, {
                Drawer: () => h
            });
            var o = n(59496),
                r = n(88537),
                s = n(97754),
                i = n(59142),
                l = n(85089),
                c = n(8361),
                a = n(63694),
                d = n(1227),
                u = n(28466),
                p = n(66998);

            function h(e) {
                const {
                    position: t = "Bottom",
                    onClose: n,
                    children: h,
                    className: f,
                    theme: m = p
                } = e, g = (0, r.ensureNotNull)((0, o.useContext)(a.DrawerContext)), [E, S] = (0, o.useState)(0), v = (0, o.useRef)(null), T = (0, o.useContext)(u.CloseDelegateContext);
                return (0, o.useEffect)(() => {
                    const e = (0, r.ensureNotNull)(v.current);
                    return e.focus({
                        preventScroll: !0
                    }), T.subscribe(g, n), 0 === g.currentDrawer && (0, l.setFixedBodyState)(!0), d.CheckMobile.iOS() && (0, i.disableBodyScroll)(e), S(g.addDrawer()), () => {
                        T.unsubscribe(g, n);
                        const t = g.removeDrawer();
                        d.CheckMobile.iOS() && (0, i.enableBodyScroll)(e), 0 === t && (0, l.setFixedBodyState)(!1)
                    }
                }, []), o.createElement(c.Portal, null, o.createElement("div", {
                    className: s(p.wrap, p["position" + t])
                }, E === g.currentDrawer && o.createElement("div", {
                    className: p.backdrop,
                    onClick: n
                }), o.createElement("div", {
                    className: s(p.drawer, m.drawer, p["position" + t], f),
                    ref: v,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, h)))
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => s
            });
            var o = n(59496),
                r = n(21709);

            function s(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: s,
                    touchStart: i,
                    handler: l,
                    reference: c,
                    ownerDocument: a = document
                } = e, d = (0, o.useRef)(null), u = (0, o.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, o.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: s,
                            touchStart: i
                        },
                        o = c ? c.current : d.current;
                    return (0, r.addOutsideEventListener)(u.current, o, l, a, e)
                }, [t, n, s, i, l]), c || d
            }
        },
        39043: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOverlayScroll: () => c
            });
            var o = n(59496),
                r = n(88537),
                s = n(21258),
                i = n(1227);
            const l = {
                onMouseOver: () => {},
                onMouseOut: () => {}
            };

            function c(e, t = i.CheckMobile.any()) {
                const n = (0, o.useRef)(null),
                    c = e || (0, o.useRef)(null),
                    [a, d] = (0, s.useHover)(),
                    [u, p] = (0, o.useState)({
                        reference: n,
                        containerHeight: 0,
                        containerWidth: 0,
                        contentHeight: 0,
                        contentWidth: 0,
                        scrollPosTop: 0,
                        scrollPosLeft: 0,
                        onVerticalChange: function(e) {
                            p(t => ({ ...t,
                                scrollPosTop: e
                            })), (0, r.ensureNotNull)(c.current).scrollTop = e
                        },
                        onHorizontalChange: function(e) {
                            p(t => ({ ...t,
                                scrollPosLeft: e
                            })), (0, r.ensureNotNull)(c.current).scrollLeft = e
                        },
                        visible: a
                    }),
                    h = (0, o.useCallback)(() => {
                        if (!c.current) return;
                        const {
                            clientHeight: e,
                            scrollHeight: t,
                            scrollTop: o,
                            clientWidth: r,
                            scrollWidth: s,
                            scrollLeft: i
                        } = c.current, l = n.current ? n.current.offsetTop : 0;
                        p(n => ({ ...n,
                            containerHeight: e - l,
                            contentHeight: t - l,
                            scrollPosTop: o,
                            containerWidth: r,
                            contentWidth: s,
                            scrollPosLeft: i
                        }))
                    }, []);

                function f() {
                    p(e => ({ ...e,
                        scrollPosTop: (0,
                            r.ensureNotNull)(c.current).scrollTop,
                        scrollPosLeft: (0, r.ensureNotNull)(c.current).scrollLeft
                    }))
                }
                return (0, o.useEffect)(() => {
                    a && h(), p(e => ({ ...e,
                        visible: a
                    }))
                }, [a]), (0, o.useEffect)(() => {
                    const e = c.current;
                    return e && e.addEventListener("scroll", f), () => {
                        e && e.removeEventListener("scroll", f)
                    }
                }, [c]), [u, t ? l : d, c, h]
            }
        },
        97265: (e, t, n) => {
            "use strict";
            n.d(t, {
                useWatchedValueReadonly: () => r
            });
            var o = n(59496);
            const r = (e, t = !1) => {
                const n = "watchedValue" in e ? e.watchedValue : void 0,
                    r = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                    [s, i] = (0, o.useState)(n ? n.value() : r);
                return (t ? o.useLayoutEffect : o.useEffect)(() => {
                    if (n) {
                        i(n.value());
                        const e = e => i(e);
                        return n.subscribe(e), () => n.unsubscribe(e)
                    }
                    return () => {}
                }, [n]), s
            }
        },
        296: (e, t, n) => {
            "use strict";
            n.d(t, {
                ListItemButton: () => c
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(72571),
                l = n(30608);

            function c(e) {
                const {
                    className: t,
                    disabled: n,
                    ...r
                } = e;
                return o.createElement(i.Icon, {
                    className: s()(l.button, n && l.disabled, t),
                    ...r
                })
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => r
            });
            var o = n(59496);
            class r extends o.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        30553: (e, t, n) => {
            "use strict";
            n.d(t, {
                MenuContext: () => o
            });
            const o = n(59496).createContext(null)
        },
        10618: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_MENU_THEME: () => g,
                Menu: () => E
            });
            var o = n(59496),
                r = n(97754),
                s = n.n(r),
                i = n(88537),
                l = n(97280),
                c = n(12777),
                a = n(53327),
                d = n(70981),
                u = n(63212),
                p = n(82027),
                h = n(94488),
                f = n(30553),
                m = n(16059);
            const g = m;
            class E extends o.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new u.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                        this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                    }, this._handleScrollWrapRef = e => {
                        this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                    }, this._handleMeasure = ({
                        callback: e,
                        forceRecalcPosition: t
                    } = {}) => {
                        var n, o, r, s;
                        if (this.state.isMeasureValid && !t) return;
                        const {
                            position: c
                        } = this.props, a = (0, i.ensureNotNull)(this._containerRef);
                        let d = a.getBoundingClientRect();
                        const u = document.documentElement.clientHeight,
                            p = document.documentElement.clientWidth,
                            h = null !== (n = this.props.closeOnScrollOutsideOffset) && void 0 !== n ? n : 0;
                        let f = u - 0 - h;
                        const m = d.height > f;
                        if (m) {
                            (0, i.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", d = a.getBoundingClientRect()
                        }
                        const {
                            width: g,
                            height: E
                        } = d, S = "function" == typeof c ? c(g, E, u) : c, v = p - (null !== (o = S.overrideWidth) && void 0 !== o ? o : g) - 0, T = (0, l.clamp)(S.x, 0, Math.max(0, v)), _ = 0 + h, y = u - (null !== (r = S.overrideHeight) && void 0 !== r ? r : E) - 0;
                        let D = (0, l.clamp)(S.y, _, Math.max(_, y));
                        if (S.forbidCorrectYCoord && D < S.y && (f -= S.y - D, D = S.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && S.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                        const C = null !== (s = S.overrideHeight) && void 0 !== s ? s : m ? f : void 0;
                        this.setState({
                            appearingMenuHeight: t ? this.state.appearingMenuHeight : C,
                            appearingMenuWidth: t ? this.state.appearingMenuWidth : S.overrideWidth,
                            appearingPosition: {
                                x: T,
                                y: D
                            },
                            isMeasureValid: !0
                        }, () => {
                            this._restoreScrollPosition(), e && e()
                        })
                    }, this._restoreScrollPosition = () => {
                        const e = document.activeElement,
                            t = (0, i.ensureNotNull)(this._containerRef);
                        if (null !== e && t.contains(e)) try {
                            e.scrollIntoView()
                        } catch (e) {} else(0, i.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                    }, this._resizeForced = () => {
                        this.setState({
                            appearingMenuHeight: void 0,
                            appearingMenuWidth: void 0,
                            appearingPosition: void 0,
                            isMeasureValid: void 0
                        })
                    }, this._resize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            }), this._raf = null
                        }))
                    }, this._handleGlobalClose = e => {
                        this.props.onClose(e)
                    }, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }, this._handleScroll = () => {
                        this._scroll = (0, i.ensureNotNull)(this._scrollWrapRef).scrollTop
                    }, this._handleScrollOutsideEnd = () => {
                        clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            })
                        }, 80)
                    }, this._handleScrollOutside = e => {
                        e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            }), this._scrollRaf = null
                        })))
                    }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = d.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = p.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = d.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        children: i,
                        minWidth: l,
                        theme: d = m,
                        className: u,
                        maxHeight: p,
                        onMouseOver: g,
                        onMouseOut: E,
                        onKeyDown: v,
                        onFocus: T,
                        onBlur: _
                    } = this.props, {
                        appearingMenuHeight: y,
                        appearingMenuWidth: D,
                        appearingPosition: C,
                        isMeasureValid: b
                    } = this.state;
                    return o.createElement(f.MenuContext.Provider, {
                        value: this
                    }, o.createElement(h.SubmenuHandler, null, o.createElement(a.SlotContext.Provider, {
                        value: this._manager
                    }, o.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": n,
                        "aria-activedescendant": r,
                        className: s()(u, d.menuWrap, !b && d.isMeasuring),
                        style: {
                            height: y,
                            left: C && C.x,
                            minWidth: l,
                            position: "fixed",
                            top: C && C.y,
                            width: D
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: c.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: g,
                        onMouseOut: E,
                        onKeyDown: v,
                        onFocus: T,
                        onBlur: _
                    }, o.createElement("div", {
                        className: s()(d.scrollWrap, !this.props.noMomentumBasedScroll && d.momentumBased),
                        style: {
                            overflowY: void 0 !== y ? "scroll" : "auto",
                            maxHeight: p
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, o.createElement(S, {
                        className: d.menuBox
                    }, i)))), o.createElement(a.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function S(e) {
                const t = (0, i.ensureNotNull)((0, o.useContext)(h.SubmenuContext)),
                    n = o.useRef(null);
                return o.createElement("div", {
                    ref: n,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (o = e.target, null === (r = n.current) || void 0 === r ? void 0 : r.contains(o)))) return;
                        var o, r;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            E.contextType = h.SubmenuContext
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => s,
                getRootOverlapManager: () => l
            });
            var o = n(88537);
            class r {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class s {
                constructor(e = document) {
                    this._storage = new r, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const o = this._document.createElement("div");
                    if (o.style.position = t.position, o.style.zIndex = this._index.toString(), o.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(o);
                        else if (t.index <= 0) this._container.insertBefore(o, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(o, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(o, this._container.firstChild) : this._container.appendChild(o);
                    return this._windows.set(e, o), ++this._index, o
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const i = new WeakMap;

            function l(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, o.ensureDefined)(i.get(t)); {
                    const t = new s(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return i.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        92063: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => a,
                PopupMenuItem: () => p
            });
            var o = n(59496),
                r = n(97754),
                s = n(70981),
                i = n(32133),
                l = n(417),
                c = n(23576);
            const a = c;

            function d(e) {
                const {
                    reference: t,
                    ...n
                } = e, r = { ...n,
                    ref: t
                };
                return o.createElement(e.href ? "a" : "div", r)
            }

            function u(e) {
                e.stopPropagation()
            }

            function p(e) {
                const {
                    id: t,
                    role: n,
                    "aria-selected": a,
                    className: p,
                    title: h,
                    labelRowClassName: f,
                    labelClassName: m,
                    shortcut: g,
                    forceShowShortcuts: E,
                    icon: S,
                    isActive: v,
                    isDisabled: T,
                    isHovered: _,
                    appearAsDisabled: y,
                    label: D,
                    link: C,
                    showToolboxOnHover: b,
                    target: w,
                    rel: N,
                    toolbox: x,
                    reference: I,
                    onMouseOut: O,
                    onMouseOver: M,
                    suppressToolboxClick: L = !0,
                    theme: R = c
                } = e, P = (0, l.filterDataProps)(e), A = (0, o.useRef)(null);
                return o.createElement(d, { ...P,
                    id: t,
                    role: n,
                    "aria-selected": a,
                    className: r(p, R.item, S && R.withIcon, {
                        [R.isActive]: v,
                        [R.isDisabled]: T || y,
                        [R.hovered]: _
                    }),
                    title: h,
                    href: C,
                    target: w,
                    rel: N,
                    reference: function(e) {
                        A.current = e, "function" == typeof I && I(e);
                        "object" == typeof I && (I.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: n,
                            onClick: o,
                            onClickArg: r,
                            trackEventObject: l
                        } = e;
                        if (T) return;
                        l && (0, i.trackEvent)(l.category, l.event, l.label);
                        o && o(r, t);
                        n || (0, s.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: n,
                            trackRightClick: o
                        } = e;
                        n && o && (0, i.trackEvent)(n.category, n.event, n.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: n,
                            trackMouseWheelClick: o
                        } = e;
                        if (1 === t.button && C && n) {
                            let e = n.label;
                            o && (e += "_mouseWheelClick"), (0, i.trackEvent)(n.category, n.event, e)
                        }
                    },
                    onMouseOver: M,
                    onMouseOut: O
                }, void 0 !== S && o.createElement("div", {
                    className: R.icon,
                    dangerouslySetInnerHTML: {
                        __html: S
                    }
                }), o.createElement("div", {
                    className: r(R.labelRow, f)
                }, o.createElement("div", {
                    className: r(R.label, m)
                }, D)), (void 0 !== g || E) && o.createElement("div", {
                    className: R.shortcut
                }, (k = g) && k.split("+").join(" + ")), void 0 !== x && o.createElement("div", {
                    onClick: L ? u : void 0,
                    className: r(R.toolbox, {
                        [R.showOnHover]: b
                    })
                }, x));
                var k
            }
        },
        28466: (e, t, n) => {
            "use strict";
            n.d(t, {
                CloseDelegateContext: () => s
            });
            var o = n(59496),
                r = n(70981);
            const s = o.createContext(r.globalCloseDelegate)
        },
        44377: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopupMenu: () => a
            });
            var o = n(59496),
                r = n(87995),
                s = n(8361),
                i = n(10618),
                l = n(28466),
                c = n(61174);

            function a(e) {
                const {
                    controller: t,
                    children: n,
                    isOpened: a,
                    closeOnClickOutside: d = !0,
                    doNotCloseOn: u,
                    onClickOutside: p,
                    onClose: h,
                    ...f
                } = e, m = (0, o.useContext)(l.CloseDelegateContext), g = (0, c.useOutsideEvent)({
                    handler: function(e) {
                        p && p(e);
                        if (!d) return;
                        if (u && e.target instanceof Node) {
                            const t = r.findDOMNode(u);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        h()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return a ? o.createElement(s.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, o.createElement("span", {
                    ref: g,
                    style: {
                        pointerEvents: "auto"
                    }
                }, o.createElement(i.Menu, { ...f,
                    onClose: h,
                    onScroll: function(t) {
                        const {
                            onScroll: n
                        } = e;
                        n && n(t)
                    },
                    customCloseDelegate: m,
                    ref: t
                }, n))) : null
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => c,
                PortalContext: () => a
            });
            var o = n(59496),
                r = n(87995),
                s = n(16345),
                i = n(63212),
                l = n(53327);
            class c extends o.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, s.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", r.createPortal(o.createElement(a.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, i.getRootOverlapManager)() : this.context
                }
            }
            c.contextType = l.SlotContext;
            const a = o.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => r,
                SlotContext: () => s
            });
            var o = n(59496);
            class r extends o.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return o.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const s = o.createContext(null)
        },
        94488: (e, t, n) => {
            "use strict";
            n.d(t, {
                SubmenuContext: () => r,
                SubmenuHandler: () => s
            });
            var o = n(59496);
            const r = o.createContext(null);

            function s(e) {
                const [t, n] = (0, o.useState)(null), s = (0, o.useRef)(null), i = (0, o.useRef)(new Map);
                return (0, o.useEffect)(() => () => {
                    null !== s.current && clearTimeout(s.current)
                }, []), o.createElement(r.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== s.current && (clearTimeout(s.current), s.current = null);
                            null === t ? n(e) : s.current = setTimeout(() => {
                                s.current = null, n(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return i.current.set(e, t), () => {
                                i.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(i.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        15783: (e, t, n) => {
            "use strict";
            n.d(t, {
                ToolWidgetCaret: () => c
            });
            var o = n(59496),
                r = n(97754),
                s = n(72571),
                i = n(40367),
                l = n(21538);

            function c(e) {
                const {
                    dropped: t,
                    className: n
                } = e;
                return o.createElement(s.Icon, {
                    className: r(n, i.icon, {
                        [i.dropped]: t
                    }),
                    icon: l
                })
            }
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        72351: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"><path fill="currentColor" d="M9.707 9l4.647-4.646-.707-.708L9 8.293 4.354 3.646l-.708.708L8.293 9l-4.647 4.646.708.708L9 9.707l4.646 4.647.708-.707L9.707 9z"/></svg>'
        },
        56085: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8 9.5H6.5a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V20m-8-1.5h11a1 1 0 0 0 1-1v-11a1 1 0 0 0-1-1h-11a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1z"/></svg>'
        },
        3922: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M17.086 6.207a2 2 0 0 1 2.828 0l1.879 1.879a2 2 0 0 1 0 2.828l-.94.94-9 9-1 1-.146.146H6v-4.707l.146-.146 1-1 9-9 .94-.94zm2.121.707a1 1 0 0 0-1.414 0l-.586.586 1.647 1.646 1.646 1.647.586-.586a1 1 0 0 0 0-1.414l-1.879-1.879zm.586 4.586L18.5 10.207 10.207 18.5l1.293 1.293 8.293-8.293zm-9 9l-1.647-1.646L7.5 17.207l-.5.5V21h3.293l.5-.5zm-2.586-4L9.5 17.793 17.793 9.5 16.5 8.207 8.207 16.5z"/></svg>'
        },
        34677: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path stroke="currentColor" d="M8 5l3.5 3.5L8 12"/></svg>'
        }
    }
]);
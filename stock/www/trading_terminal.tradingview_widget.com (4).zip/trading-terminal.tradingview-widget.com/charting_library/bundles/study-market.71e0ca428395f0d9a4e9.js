(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [6456, 8890], {
        6539: e => {
            e.exports = {
                button: "button-YKkCvwjV",
                content: "content-YKkCvwjV",
                "icon-only": "icon-only-YKkCvwjV",
                "color-brand": "color-brand-YKkCvwjV",
                "variant-primary": "variant-primary-YKkCvwjV",
                "variant-secondary": "variant-secondary-YKkCvwjV",
                "color-gray": "color-gray-YKkCvwjV",
                "color-green": "color-green-YKkCvwjV",
                "color-red": "color-red-YKkCvwjV",
                "size-xsmall": "size-xsmall-YKkCvwjV",
                "size-small": "size-small-YKkCvwjV",
                "size-medium": "size-medium-YKkCvwjV",
                "size-large": "size-large-YKkCvwjV",
                "size-xlarge": "size-xlarge-YKkCvwjV",
                "with-start-icon": "with-start-icon-YKkCvwjV",
                "with-end-icon": "with-end-icon-YKkCvwjV",
                "start-icon-wrap": "start-icon-wrap-YKkCvwjV",
                "end-icon-wrap": "end-icon-wrap-YKkCvwjV",
                animated: "animated-YKkCvwjV",
                stretch: "stretch-YKkCvwjV",
                grouped: "grouped-YKkCvwjV",
                "adjust-position": "adjust-position-YKkCvwjV",
                "first-row": "first-row-YKkCvwjV",
                "first-col": "first-col-YKkCvwjV",
                "no-corner-top-left": "no-corner-top-left-YKkCvwjV",
                "no-corner-top-right": "no-corner-top-right-YKkCvwjV",
                "no-corner-bottom-right": "no-corner-bottom-right-YKkCvwjV",
                "no-corner-bottom-left": "no-corner-bottom-left-YKkCvwjV"
            }
        },
        96746: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        67179: e => {
            e.exports = {
                dialog: "dialog-HExheUfY",
                wrapper: "wrapper-HExheUfY",
                separator: "separator-HExheUfY"
            }
        },
        91441: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                container: "container-tuOy5zvD",
                unsetAlign: "unsetAlign-tuOy5zvD",
                title: "title-tuOy5zvD",
                subtitle: "subtitle-tuOy5zvD",
                ellipsis: "ellipsis-tuOy5zvD",
                close: "close-tuOy5zvD"
            }
        },
        28712: e => {
            e.exports = {
                container: "container-CcsqUMct",
                inputContainer: "inputContainer-CcsqUMct",
                withCancel: "withCancel-CcsqUMct",
                input: "input-CcsqUMct",
                icon: "icon-CcsqUMct",
                cancel: "cancel-CcsqUMct"
            }
        },
        54565: e => {
            e.exports = {
                wrapper: "wrapper-Zcmov9JL",
                container: "container-Zcmov9JL",
                tab: "tab-Zcmov9JL",
                active: "active-Zcmov9JL",
                title: "title-Zcmov9JL",
                icon: "icon-Zcmov9JL",
                titleText: "titleText-Zcmov9JL",
                nested: "nested-Zcmov9JL",
                isTablet: "isTablet-Zcmov9JL",
                isMobile: "isMobile-Zcmov9JL"
            }
        },
        23570: e => {
            e.exports = {
                title: "title-7gruJzPo",
                small: "small-7gruJzPo",
                normal: "normal-7gruJzPo",
                large: "large-7gruJzPo"
            }
        },
        14541: e => {
            e.exports = {
                container: "container-sfMizuTb"
            }
        },
        48722: e => {
            e.exports = {
                title: "title-eFiUyD3Z",
                disabled: "disabled-eFiUyD3Z",
                icon: "icon-eFiUyD3Z",
                locked: "locked-eFiUyD3Z",
                open: "open-eFiUyD3Z",
                actionIcon: "actionIcon-eFiUyD3Z",
                selected: "selected-eFiUyD3Z",
                codeIcon: "codeIcon-eFiUyD3Z"
            }
        },
        92699: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                container: "container-FkkXGK5n",
                selected: "selected-FkkXGK5n",
                disabled: "disabled-FkkXGK5n",
                favorite: "favorite-FkkXGK5n",
                actions: "actions-FkkXGK5n",
                highlighted: "highlighted-FkkXGK5n",
                light: "light-FkkXGK5n",
                "highlight-animation-theme-light": "highlight-animation-theme-light-FkkXGK5n",
                dark: "dark-FkkXGK5n",
                "highlight-animation-theme-dark": "highlight-animation-theme-dark-FkkXGK5n",
                badge: "badge-FkkXGK5n",
                main: "main-FkkXGK5n",
                paddingLeft: "paddingLeft-FkkXGK5n",
                isActive: "isActive-FkkXGK5n",
                author: "author-FkkXGK5n",
                likes: "likes-FkkXGK5n"
            }
        },
        27103: e => {
            e.exports = {
                container: "container-upe4c4Dt"
            }
        },
        6621: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                dialog: "dialog-ui35u3Zi",
                dialogLibrary: "dialogLibrary-ui35u3Zi",
                contentContainer: "contentContainer-ui35u3Zi",
                listContainer: "listContainer-ui35u3Zi",
                scroll: "scroll-ui35u3Zi",
                sidebarContainer: "sidebarContainer-ui35u3Zi",
                noContentBlock: "noContentBlock-ui35u3Zi",
                tabWithHint: "tabWithHint-ui35u3Zi",
                solution: "solution-ui35u3Zi"
            }
        },
        53608: e => {
            e.exports = {
                container: "container-ccvVd5A9",
                image: "image-ccvVd5A9",
                title: "title-ccvVd5A9",
                description: "description-ccvVd5A9",
                button: "button-ccvVd5A9"
            }
        },
        16842: e => {
            e.exports = {
                favorite: "favorite-JVQQsDQk",
                disabled: "disabled-JVQQsDQk",
                active: "active-JVQQsDQk",
                checked: "checked-JVQQsDQk"
            }
        },
        22932: e => {
            e.exports = {
                highlighted: "highlighted-YWUtZHTy"
            }
        },
        91626: e => {
            e.exports = {
                separator: "separator-jtAq6E4V"
            }
        },
        28599: (e, t, n) => {
            "use strict";
            n.d(t, {
                Button: () => w
            });
            var i = n(59496),
                r = n(97754),
                o = n(31774),
                s = n(72571),
                a = n(6539),
                l = n.n(a);

            function c(e) {
                const {
                    color: t = "brand",
                    size: n = "medium",
                    variant: i = "primary",
                    stretch: s = !1,
                    icon: a,
                    startIcon: c,
                    endIcon: d,
                    iconOnly: u = !1,
                    className: h,
                    isGrouped: m,
                    cellState: p,
                    disablePositionAdjustment: g = !1
                } = e, v = function(e) {
                    let t = "";
                    return 0 !== e && (1 & e && (t = r(t, l()["no-corner-top-left"])), 2 & e && (t = r(t, l()["no-corner-top-right"])), 4 & e && (t = r(t, l()["no-corner-bottom-right"])), 8 & e && (t = r(t, l()["no-corner-bottom-left"]))), t
                }((0, o.getGroupCellRemoveRoundBorders)(p));
                return r(h, l().button, l()["size-" + n], l()["color-" + t], l()["variant-" + i], s && l().stretch, (a || c) && l()["with-start-icon"], d && l()["with-end-icon"], u && l()["icon-only"], v, m && l().grouped, m && !g && l()["adjust-position"], m && p.isTop && l()["first-row"], m && p.isLeft && l()["first-col"])
            }

            function d(e) {
                const {
                    size: t,
                    startIcon: n,
                    icon: r,
                    iconOnly: o,
                    children: a,
                    endIcon: c
                } = e, d = null != n ? n : r;
                return i.createElement(i.Fragment, null, d && "xsmall" !== t && i.createElement(s.Icon, {
                    icon: d,
                    className: l()["start-icon-wrap"]
                }), a && i.createElement("span", {
                    className: l().content
                }, a), c && !o && "xsmall" !== t && i.createElement(s.Icon, {
                    icon: c,
                    className: l()["end-icon-wrap"]
                }))
            }
            var u = n(80327),
                h = n(417);

            function m(e) {
                const {
                    className: t,
                    color: n,
                    variant: i,
                    size: r,
                    stretch: o,
                    animated: s,
                    icon: a,
                    iconOnly: l,
                    startIcon: c,
                    endIcon: d,
                    ...u
                } = e;
                return { ...u,
                    ...(0, h.filterDataProps)(e),
                    ...(0, h.filterAriaProps)(e)
                }
            }

            function p(e) {
                const {
                    reference: t,
                    ...n
                } = e, {
                    isGrouped: r,
                    cellState: o,
                    disablePositionAdjustment: s
                } = (0, i.useContext)(u.ControlGroupContext), a = c({ ...n,
                    isGrouped: r,
                    cellState: o,
                    disablePositionAdjustment: s
                });
                return i.createElement("button", { ...m(n),
                    className: a,
                    ref: t
                }, i.createElement(d, { ...n
                }))
            }

            function g(e = "default") {
                switch (e) {
                    case "default":
                        return "primary";
                    case "stroke":
                        return "secondary"
                }
            }

            function v(e = "primary") {
                switch (e) {
                    case "primary":
                        return "brand";
                    case "success":
                        return "green";
                    case "default":
                        return "gray";
                    case "danger":
                        return "red"
                }
            }

            function f(e = "m") {
                switch (e) {
                    case "s":
                        return "xsmall";
                    case "m":
                        return "small";
                    case "l":
                        return "large"
                }
            }

            function y(e) {
                const {
                    intent: t,
                    size: n,
                    appearance: i,
                    useFullWidth: r,
                    icon: o,
                    ...s
                } = e;
                return { ...s,
                    color: v(t),
                    size: f(n),
                    variant: g(i),
                    stretch: r,
                    startIcon: o
                }
            }

            function w(e) {
                return i.createElement(p, { ...y(e)
                })
            }
        },
        80327: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlGroupContext: () => i
            });
            const i = n(59496).createContext({
                isGrouped: !1,
                cellState: {
                    isTop: !0,
                    isRight: !0,
                    isBottom: !0,
                    isLeft: !0
                }
            })
        },
        31774: (e, t, n) => {
            "use strict";

            function i(e) {
                let t = 0;
                return e.isTop && e.isLeft || (t += 1), e.isTop && e.isRight || (t += 2), e.isBottom && e.isLeft || (t += 8), e.isBottom && e.isRight || (t += 4), t
            }
            n.d(t, {
                getGroupCellRemoveRoundBorders: () => i
            })
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => r
            });
            var i = n(59496);
            const r = i.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...r
                } = e;
                return i.createElement("span", { ...r,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        417: (e, t, n) => {
            "use strict";

            function i(e) {
                return o(e, s)
            }

            function r(e) {
                return o(e, a)
            }

            function o(e, t) {
                const n = Object.entries(e).filter(t),
                    i = {};
                for (const [e, t] of n) i[e] = t;
                return i
            }

            function s(e) {
                const [t, n] = e;
                return 0 === t.indexOf("data-") && "string" == typeof n
            }

            function a(e) {
                return 0 === e[0].indexOf("aria-")
            }
            n.d(t, {
                filterDataProps: () => i,
                filterAriaProps: () => r,
                filterProps: () => o,
                isDataAttribute: () => s,
                isAriaAttribute: () => a
            })
        },
        33054: (e, t, n) => {
            "use strict";
            n.d(t, {
                mediaQueryAddEventListener: () => i,
                mediaQueryRemoveEventListener: () => r
            });
            const i = (e, t) => {
                    (null == e ? void 0 : e.addEventListener) ? e.addEventListener("change", t): e.addListener(t)
                },
                r = (e, t) => {
                    (null == e ? void 0 : e.removeEventListener) ? e.removeEventListener("change", t): e.removeListener(t)
                }
        },
        21709: (e, t, n) => {
            "use strict";

            function i(e, t, n, i, r) {
                function o(r) {
                    if (e > r.timeStamp) return;
                    const o = r.target;
                    void 0 !== n && null !== t && null !== o && o.ownerDocument === i && (t.contains(o) || n(r))
                }
                return r.click && i.addEventListener("click", o, !1), r.mouseDown && i.addEventListener("mousedown", o, !1), r.touchEnd && i.addEventListener("touchend", o, !1), r.touchStart && i.addEventListener("touchstart", o, !1), () => {
                    i.removeEventListener("click", o, !1), i.removeEventListener("mousedown", o, !1), i.removeEventListener("touchend", o, !1), i.removeEventListener("touchstart", o, !1)
                }
            }
            n.d(t, {
                addOutsideEventListener: () => i
            })
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => l
            });
            var i = n(35922);
            const r = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                o = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let s = 0,
                a = !1;

            function l(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++s) {
                    const e = (0, i.getCSSProperty)(t, "overflow"),
                        r = (0, i.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, i.setStyle)(n, "right", (0, i.getScrollbarWidth)() + "px"), t.style.paddingRight = r + (0, i.getScrollbarWidth)() + "px", a = !0), t.classList.add("i-no-scroll")
                } else if (!e && s > 0 && 0 == --s && (t.classList.remove("i-no-scroll"), a)) {
                    (0, i.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (l = (0, i.getContentWidth)(n), r() ? 0 : o() ? 46 : Math.min(Math.max(l, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, i.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", a = !1
                }
                var l
            }
        },
        96038: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogBreakpoints: () => r
            });
            var i = n(96746);
            const r = {
                SmallHeight: i["small-height-breakpoint"],
                TabletSmall: i["tablet-small-breakpoint"],
                TabletNormal: i["tablet-normal-breakpoint"]
            }
        },
        53337: (e, t, n) => {
            "use strict";
            n.d(t, {
                AdaptivePopupDialog: () => x
            });
            var i = n(59496),
                r = n(88537),
                o = n(33054),
                s = n(97754),
                a = n.n(s),
                l = n(80185),
                c = n(98043),
                d = n(40766),
                u = n(94707),
                h = n(96038),
                m = n(30052),
                p = n(10549),
                g = n(6594),
                v = n(59410),
                f = n(72571),
                y = n(90410),
                w = n(35487),
                _ = n(91441);

            function b(e) {
                const {
                    title: t,
                    subtitle: n,
                    showCloseIcon: r = !0,
                    onClose: o,
                    renderBefore: s,
                    renderAfter: l,
                    draggable: c,
                    className: d,
                    unsetAlign: u
                } = e, [h, m] = (0, i.useState)(!1);
                return i.createElement(y.DialogHeaderContext.Provider, {
                    value: {
                        setHideClose: m
                    }
                }, i.createElement("div", {
                    className: a()(_.container, d, (n || u) && _.unsetAlign)
                }, s, i.createElement("div", {
                    "data-dragg-area": c,
                    className: _.title
                }, i.createElement("div", {
                    className: _.ellipsis
                }, t), n && i.createElement("div", {
                    className: a()(_.ellipsis, _.subtitle)
                }, n)), l, r && !h && i.createElement(f.Icon, {
                    className: _.close,
                    icon: w,
                    onClick: o,
                    "data-name": "close",
                    "data-role": "button"
                })))
            }
            var C = n(67179);
            const E = {
                    vertical: 20
                },
                k = {
                    vertical: 0
                };
            class x extends i.PureComponent {
                constructor() {
                    super(...arguments), this._controller = null, this._reference = null, this._orientationMediaQuery = null, this._renderChildren = (e, t) => (this._controller = e, this.props.render({
                        requestResize: this._requestResize,
                        centerAndFit: this._centerAndFit,
                        isSmallWidth: t
                    })), this._handleReference = e => this._reference = e, this._handleClose = () => {
                        this.props.onClose()
                    }, this._handleOpen = () => {
                        void 0 !== this.props.onOpen && this.props.isOpened && this.props.onOpen(this.props.fullScreen || window.matchMedia(h.DialogBreakpoints.TabletSmall).matches)
                    }, this._handleKeyDown = e => {
                        var t;
                        if (!e.defaultPrevented) switch (this.props.onKeyDown && this.props.onKeyDown(e), (0, l.hashFromEvent)(e)) {
                            case 27:
                                if (e.defaultPrevented) return;
                                if (this.props.forceCloseOnEsc && this.props.forceCloseOnEsc()) return void this._handleClose();
                                const {
                                    activeElement: n
                                } = document, i = (0, r.ensureNotNull)(this._reference);
                                if (null !== n) {
                                    if (e.preventDefault(), "true" === (t = n).getAttribute("data-haspopup") && "true" !== t.getAttribute("data-expanded")) return void this._handleClose();
                                    if ((0, c.isTextEditingField)(n)) return void i.focus();
                                    if (i.contains(n)) return void this._handleClose()
                                }
                        }
                    }, this._requestResize = () => {
                        null !== this._controller && this._controller.recalculateBounds()
                    }, this._centerAndFit = () => {
                        null !== this._controller && this._controller.centerAndFit()
                    }
                }
                componentDidMount() {
                    v.subscribe(g.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), this._handleOpen(), void 0 !== this.props.onOpen && (this._orientationMediaQuery = window.matchMedia("(orientation: portrait)"), (0, o.mediaQueryAddEventListener)(this._orientationMediaQuery, this._handleOpen))
                }
                componentWillUnmount() {
                    v.unsubscribe(g.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), null !== this._orientationMediaQuery && (0, o.mediaQueryRemoveEventListener)(this._orientationMediaQuery, this._handleOpen)
                }
                focus() {
                    (0, r.ensureNotNull)(this._reference).focus()
                }
                getElement() {
                    return this._reference
                }
                contains(e) {
                    var t, n;
                    return null !== (n = null === (t = this._reference) || void 0 === t ? void 0 : t.contains(e)) && void 0 !== n && n
                }
                render() {
                    const {
                        className: e,
                        wrapperClassName: t,
                        headerClassName: n,
                        isOpened: r,
                        title: o,
                        dataName: s,
                        onClickOutside: l,
                        additionalElementPos: c,
                        additionalHeaderElement: g,
                        backdrop: v,
                        shouldForceFocus: f = !0,
                        showSeparator: y,
                        subtitle: w,
                        draggable: _ = !0,
                        fullScreen: x = !1,
                        showCloseIcon: S = !0,
                        rounded: N = !0,
                        isAnimationEnabled: D,
                        growPoint: I,
                        dialogTooltip: L,
                        unsetHeaderAlign: P,
                        onDragStart: F,
                        dataDialogName: M
                    } = this.props, K = "after" !== c ? g : void 0, R = "after" === c ? g : void 0, A = "string" == typeof o ? o : M || "";
                    return i.createElement(m.MatchMedia, {
                        rule: h.DialogBreakpoints.SmallHeight
                    }, c => i.createElement(m.MatchMedia, {
                        rule: h.DialogBreakpoints.TabletSmall
                    }, h => i.createElement(d.PopupDialog, {
                        rounded: !(h || x) && N,
                        className: a()(C.dialog, e),
                        isOpened: r,
                        reference: this._handleReference,
                        onKeyDown: this._handleKeyDown,
                        onClickOutside: l,
                        onClickBackdrop: l,
                        fullscreen: h || x,
                        guard: c ? k : E,
                        boundByScreen: h || x,
                        shouldForceFocus: f,
                        backdrop: v,
                        draggable: _,
                        isAnimationEnabled: D,
                        growPoint: I,
                        name: this.props.dataName,
                        dialogTooltip: L,
                        onDragStart: F
                    }, i.createElement("div", {
                        className: a()(C.wrapper, t),
                        "data-name": s,
                        "data-dialog-name": A
                    }, void 0 !== o && i.createElement(b, {
                        draggable: _ && !(h || x),
                        onClose: this._handleClose,
                        renderAfter: R,
                        renderBefore: K,
                        subtitle: w,
                        title: o,
                        showCloseIcon: S,
                        className: n,
                        unsetAlign: P
                    }), y && i.createElement(u.Separator, {
                        className: C.separator
                    }), i.createElement(p.PopupContext.Consumer, null, e => this._renderChildren(e, h || x))))))
                }
            }
        },
        90410: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogHeaderContext: () => i
            });
            const i = n(59496).createContext({
                setHideClose: () => {}
            })
        },
        31862: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogSearch: () => d
            });
            var i = n(59496),
                r = n(97754),
                o = n.n(r),
                s = n(25177),
                a = n(72571),
                l = n(80200),
                c = n(28712);

            function d(e) {
                const {
                    children: t,
                    renderInput: n,
                    onCancel: r,
                    ...d
                } = e;
                return i.createElement("div", {
                    className: c.container
                }, i.createElement("div", {
                    className: o()(c.inputContainer, r && c.withCancel)
                }, n || i.createElement(u, { ...d
                })), t, i.createElement(a.Icon, {
                    className: c.icon,
                    icon: l
                }), r && i.createElement("div", {
                    className: c.cancel,
                    onClick: r
                }, (0, s.t)("Cancel")))
            }

            function u(e) {
                const {
                    className: t,
                    reference: n,
                    value: r,
                    onChange: s,
                    onFocus: a,
                    onBlur: l,
                    onKeyDown: d,
                    onSelect: u,
                    placeholder: h,
                    ...m
                } = e;
                return i.createElement("input", { ...m,
                    ref: n,
                    type: "text",
                    className: o()(t, c.input),
                    autoComplete: "off",
                    "data-role": "search",
                    placeholder: h,
                    value: r,
                    onChange: s,
                    onFocus: a,
                    onBlur: l,
                    onSelect: u,
                    onKeyDown: d
                })
            }
        },
        82850: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogSidebarContainer: () => d,
                DialogSidebarWrapper: () => u,
                DialogSidebarItem: () => h
            });
            var i = n(59496),
                r = n(97754),
                o = n.n(r),
                s = n(72571),
                a = n(35555),
                l = n(54565);

            function c(e) {
                return {
                    isMobile: "mobile" === e,
                    isTablet: "tablet" === e
                }
            }

            function d(e) {
                const {
                    mode: t,
                    className: n,
                    ...r
                } = e, {
                    isMobile: s,
                    isTablet: a
                } = c(t), d = o()(l.container, a && l.isTablet, s && l.isMobile, n);
                return i.createElement("div", { ...r,
                    className: d,
                    "data-role": "dialog-sidebar"
                })
            }

            function u(e) {
                return i.createElement("div", {
                    className: l.wrapper,
                    ...e
                })
            }

            function h(e) {
                const {
                    mode: t,
                    title: n,
                    icon: r,
                    isActive: d,
                    onClick: u,
                    ...h
                } = e, {
                    isMobile: m,
                    isTablet: p
                } = c(t);
                return i.createElement("div", { ...h,
                    className: o()(l.tab, p && l.isTablet, m && l.isMobile, d && l.active),
                    onClick: u
                }, i.createElement(s.Icon, {
                    className: l.icon,
                    icon: r
                }), !p && i.createElement("span", {
                    className: l.title
                }, i.createElement("span", {
                    className: l.titleText
                }, n), m && i.createElement(s.Icon, {
                    className: l.nested,
                    icon: a
                })))
            }
        },
        43619: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                IndicatorsLibraryContainer: () => J
            });
            var i = n(59496),
                r = n(87995),
                o = n(25177),
                s = n(93546),
                a = n(10392),
                l = n.n(a),
                c = n(82527),
                d = n(5796);

            function u(e, t) {
                const n = e.title.toLowerCase(),
                    i = t.title.toLowerCase();
                return n < i ? -1 : n > i ? 1 : 0
            }
            const h = {
                earning: new RegExp("EPS"),
                earnings: new RegExp("EPS"),
                "trailing twelve months": new RegExp("TTM")
            };

            function m(e) {
                var t;
                const {
                    id: n,
                    description: i,
                    shortDescription: r,
                    description_localized: s,
                    is_hidden_study: a,
                    version: d,
                    extra: u
                } = e, h = c.enabled("graying_disabled_tools_enabled") && (null === (t = window.ChartApiInstance) || void 0 === t ? void 0 : t.studiesAccessController.isToolGrayed(i)), m = (null == u ? void 0 : u.isAuto) ? "auto-java" : l().getPackageName(n);
                return {
                    id: n,
                    title: s || (0, o.t)(i, {
                        context: "study"
                    }),
                    shortDescription: r,
                    shortTitle: r,
                    isStrategy: l().isScriptStrategy(e),
                    isHidden: a,
                    isNew: null == u ? void 0 : u.isNew,
                    isUpdated: null == u ? void 0 : u.isUpdated,
                    isBeta: null == u ? void 0 : u.isBeta,
                    isFundamental: !1,
                    studyData: {
                        id: n,
                        version: d,
                        descriptor: {
                            type: "java",
                            studyId: e.id
                        },
                        packageName: m
                    },
                    isGrayed: h
                }
            }
            var p = n(97754),
                g = n.n(p),
                v = n(32455),
                f = n(53337),
                y = n(1227),
                w = n(31862),
                _ = n(82850),
                b = n(27103);

            function C(e) {
                const {
                    reference: t,
                    className: n,
                    ...r
                } = e;
                return i.createElement("div", {
                    ref: t,
                    className: g()(b.container, n),
                    ...r,
                    "data-role": "dialog-content"
                })
            }
            var E = n(48722);

            function k(e) {
                const {
                    children: t,
                    className: n,
                    disabled: r
                } = e;
                return i.createElement("span", {
                    className: g()(E.title, r && E.disabled, n)
                }, t)
            }
            const x = i.createContext(null);
            var S = n(60598),
                N = n(97265),
                D = n(2054),
                I = n(51049),
                L = n(77687),
                P = n(80185),
                F = n(92699);

            function M(e) {
                const t = (0, i.useContext)(x),
                    {
                        style: n,
                        layoutMode: r,
                        item: s,
                        query: a,
                        regExpRules: l,
                        isBeta: c,
                        isNew: d,
                        isUpdated: u,
                        isSelected: h,
                        isHighlighted: m,
                        reference: p,
                        onClick: v,
                        renderActions: f
                    } = e,
                    {
                        isFavorite: y,
                        isLocked: w,
                        public: _,
                        editorsPick: b
                    } = s,
                    C = void 0 !== y,
                    E = K(v, s),
                    P = (0, i.useCallback)(e => e.stopPropagation(), []),
                    M = (null == t ? void 0 : t.toggleFavorite) ? K(t.toggleFavorite, s) : void 0,
                    R = (0, N.useWatchedValueReadonly)({
                        watchedValue: D.watchedTheme
                    }) === I.StdTheme.Dark ? F.dark : F.light,
                    A = g()(F.container, s.isGrayed && F.disabled, h && F.selected, m && F.highlighted, m && R);
                return i.createElement("div", {
                    ref: p,
                    className: A,
                    onClick: E,
                    style: n,
                    "data-role": "list-item",
                    "data-disabled": s.isGrayed,
                    "data-title": s.title,
                    "data-id": s.id
                }, i.createElement("div", {
                    className: g()(F.main, !C && F.paddingLeft)
                }, C && i.createElement(L.FavoriteButton, {
                    className: g()(F.favorite, y && F.isActive),
                    isFilled: y,
                    onClick: M
                }), i.createElement(k, {
                    disabled: s.isGrayed
                }, i.createElement(S.HighlightedText, {
                    queryString: a,
                    rules: l,
                    text: s.title
                })), !1, c && i.createElement(BadgeIndicator, {
                    type: "beta",
                    className: F.badge
                }), d && i.createElement(BadgeIndicator, {
                    type: "new",
                    className: F.badge
                }), u && i.createElement(BadgeIndicator, {
                    type: "updated",
                    className: F.badge
                }), b && i.createElement(BadgeIndicator, {
                    type: "ep",
                    className: F.badge,
                    tooltip: (0,
                        o.t)("Editors' picks")
                })), _ && i.createElement("a", {
                    href: _.authorLink,
                    className: F.author,
                    target: "_blank",
                    onClick: P
                }, _.authorName), "mobile" !== r && _ && i.createElement("span", {
                    className: F.likes
                }, _.likesCount), !1)
            }

            function K(e, t) {
                return n => {
                    const i = 0 === (0, P.modifiersFromEvent)(n) && 0 === n.button;
                    !n.defaultPrevented && e && i && (n.preventDefault(), e(t))
                }
            }
            var R = n(23570);

            function A(e) {
                const {
                    title: t,
                    type: n,
                    className: r
                } = e;
                return i.createElement("h3", {
                    className: g()(R.title, "Small" === n && R.small, "Normal" === n && R.normal, "Large" === n && R.large, r)
                }, t)
            }
            var O = n(14541);

            function z(e) {
                const {
                    style: t,
                    children: n
                } = e;
                return i.createElement("div", {
                    style: t,
                    className: O.container
                }, n)
            }
            var V = n(72571),
                T = n(28599),
                B = n(53608);

            function j(e) {
                const {
                    className: t,
                    icon: n,
                    title: r,
                    description: o,
                    buttonText: s,
                    buttonAction: a
                } = e;
                return i.createElement("div", {
                    className: g()(B.container, t)
                }, n && i.createElement(V.Icon, {
                    icon: n,
                    className: B.image
                }), r && i.createElement("h3", {
                    className: B.title
                }, r), o && i.createElement("p", {
                    className: B.description
                }, o), s && a && i.createElement(T.Button, {
                    onClick: a,
                    className: B.button
                }, s))
            }

            function W(e) {
                const [t, n] = (0, i.useState)(null);

                function r(e) {
                    return e.findIndex(e => (null == t ? void 0 : t.id) === e.id)
                }
                return [t, n, function() {
                    n(function() {
                        var n;
                        const i = r(e),
                            o = i === e.length - 1;
                        return null === t || -1 === i ? null !== (n = e[0]) && void 0 !== n ? n : null : o ? e[i] : e[i + 1]
                    }())
                }, function() {
                    n(function() {
                        var n;
                        const i = r(e);
                        return null === t || 0 === i || -1 === i ? null !== (n = e[0]) && void 0 !== n ? n : null : e[i - 1]
                    }())
                }]
            }
            var H = n(12991),
                G = n(6621);

            function Y(e) {
                const {
                    reference: t,
                    data: n,
                    isOpened: r,
                    onClose: s,
                    applyStudy: a
                } = e, [l, c] = (0, i.useState)(""), d = (0, i.useMemo)(() => (0, H.createRegExpList)(l, h), [l]), u = (0, i.useMemo)(() => l ? (0, H.rankedSearch)({
                    data: n,
                    rules: d,
                    queryString: l,
                    primaryKey: "shortDescription",
                    secondaryKey: "title",
                    optionalPrimaryKey: "shortTitle"
                }) : n, [l, d, n]), {
                    highlightedItem: m,
                    selectedItem: p,
                    selectedNodeReference: b,
                    scrollContainerRef: E,
                    searchInputRef: k,
                    onClickStudy: x,
                    handleKeyDown: S
                } = function(e, t, n, r) {
                    let o = 0;
                    const [s, a] = (0, i.useState)(null), l = (0, i.useRef)(null), c = (0, i.useRef)(null), [d, u, h, m] = W(t), p = (0, i.useRef)(null);
                    return (0, i.useEffect)(() => {
                        e ? g(0) : u(null)
                    }, [e]), (0, i.useEffect)(() => {
                        void 0 !== r && (g(0), u(null))
                    }, [r]), (0, i.useEffect)(() => (s && (o = setTimeout(() => {
                        a(null)
                    }, 1500)), () => {
                        clearInterval(o)
                    }), [s]), {
                        highlightedItem: s,
                        scrollContainerRef: l,
                        selectedNodeReference: c,
                        selectedItem: d,
                        searchInputRef: p,
                        onClickStudy: function(e) {
                            if (!n) return;
                            n(e), u(e), a(e)
                        },
                        handleKeyDown: function(e) {
                            const [t, i] = function(e, t) {
                                if (null === e.current || null === t.current) return [0, 0];
                                const n = e.current.getBoundingClientRect(),
                                    i = t.current.getBoundingClientRect(),
                                    {
                                        height: r
                                    } = n,
                                    o = n.top - i.top,
                                    s = n.bottom - i.bottom + r < 0 ? 0 : r,
                                    a = o - r > 0 ? 0 : r,
                                    {
                                        scrollTop: l
                                    } = t.current;
                                return [l - a, l + s]
                            }(c, l);
                            40 === (0, P.hashFromEvent)(e) && (e.preventDefault(), h(), g(i));
                            38 === (0, P.hashFromEvent)(e) && (e.preventDefault(), m(), g(t));
                            if (13 === (0, P.hashFromEvent)(e) && d) {
                                if (!n) return;
                                n(d), a(d)
                            }
                        }
                    };

                    function g(e) {
                        null !== l.current && l.current.scrollTo && l.current.scrollTo(0, e)
                    }
                }(r, u, a), N = "" === l && !u.length;
                return (0, i.useEffect)(() => {
                    var e;
                    r || c(""),
                        y.CheckMobile.any() || null === (e = k.current) || void 0 === e || e.focus()
                }, [r]), i.createElement(f.AdaptivePopupDialog, {
                    isOpened: r,
                    onClose: s,
                    onClickOutside: s,
                    className: g()(G.dialogLibrary),
                    render: function() {
                        return i.createElement(i.Fragment, null, i.createElement(w.DialogSearch, {
                            reference: k,
                            placeholder: (0, o.t)("Search"),
                            onChange: D,
                            onFocus: I
                        }), i.createElement(_.DialogSidebarWrapper, null, i.createElement(C, {
                            reference: E,
                            className: G.scroll
                        }, N ? i.createElement(v.Spinner, null) : u.length ? i.createElement(i.Fragment, null, i.createElement(z, null, i.createElement(A, {
                            title: (0, o.t)("Script name")
                        })), u.map(e => {
                            const t = (null == p ? void 0 : p.id) === e.id;
                            return i.createElement(M, {
                                key: e.id,
                                item: e,
                                onClick: () => x(e),
                                query: l,
                                regExpRules: d,
                                reference: t ? b : void 0,
                                isSelected: (null == p ? void 0 : p.id) === e.id,
                                isHighlighted: (null == m ? void 0 : m.id) === e.id
                            })
                        })) : i.createElement(j, {
                            className: G.noContentBlock,
                            description: (0, o.t)("No indicators matched your criteria.")
                        }))))
                    },
                    title: (0, o.t)("Indicators"),
                    dataName: "indicators-dialog",
                    onKeyDown: S,
                    ref: t
                });

                function D(e) {
                    c(e.target.value)
                }

                function I() {
                    var e;
                    l.length > 0 && (null === (e = k.current) || void 0 === e || e.select())
                }
            }
            var Z = n(59410),
                U = n(94489),
                q = n.n(U);
            class J extends class {
                constructor(e) {
                    this._searchInputRef = i.createRef(), this._dialog = i.createRef(), this._visibility = new(q())(!1), this._container = document.createElement("div"), this._isForceRender = !1, this._parentSource = null, this._isDestroyed = !1, this._symbolInfo = null, this._deepFundamentalsHistoryNotificationHasBeenShown = !1, this._showDeepFundamentalsHistoryNotification = () => {}, this._chartWidgetCollection = e
                }
                isDestroyed() {
                    return this._isDestroyed
                }
                visible() {
                    return this._visibility.readonly()
                }
                resetAllStudies() {}
                updateFavorites() {}
                open(e) {
                    this._parentSource = null != e ? e : null, this._updateSymbolInfo(), this._setProps({
                        isOpened: !0
                    }), this._visibility.setValue(!0), Z.emit("indicators_dialog")
                }
                show() {
                    this.open()
                }
                hide() {
                    this._parentSource = null, this._setProps({
                        isOpened: !1
                    }), this._visibility.setValue(!1)
                }
                destroy() {
                    this._isDestroyed = !0, r.unmountComponentAtNode(this._container)
                }
                getSymbolInfo() {
                    return this._symbolInfo
                }
                _shouldPreventRender() {
                    return this._isDestroyed || !this._isForceRender && !this._getProps().value().isOpened
                }
                _getRenderData() {
                    return {
                        props: this._getProps().value(),
                        container: this._getContainer()
                    }
                }
                _applyStudy(e, t) {
                    var n, i;
                    e.isGrayed ? Z.emit("onGrayedObjectClicked", {
                        type: "study",
                        name: e.shortDescription
                    }) : (y.CheckMobile.any() || null === (n = this._searchInputRef.current) || void 0 === n || n.select(), async function(e, t, n, i, r) {
                        const o = e.activeChartWidget.value();
                        if (!o) return null;
                        const {
                            studyData: a
                        } = t;
                        if (!a) return Promise.resolve(null);
                        const l = a.descriptor;
                        if ("java" === l.type) {
                            const e = (0, d.tryFindStudyLineToolNameByStudyId)(l.studyId);
                            if (null !== e) return s.tool.setValue(e), null
                        }
                        return o.insertStudy(a.descriptor, n, t.shortDescription)
                    }(this._chartWidgetCollection, e, null !== (i = this._parentSource) && void 0 !== i ? i : void 0, 0, this._symbol).then(() => {
                        var e;
                        y.CheckMobile.any() || (null === document.activeElement || document.activeElement === document.body || null !== this._dialog.current && this._dialog.current.contains(document.activeElement)) && (null === (e = this._searchInputRef.current) || void 0 === e || e.focus())
                    }))
                }
                _setProps(e) {
                    const t = this._getProps().value(),
                        {
                            isOpened: n
                        } = t;
                    this._isForceRender = n && "isOpened" in e && !e.isOpened;
                    const i = { ...t,
                        ...e
                    };
                    this._getProps().setValue(i)
                }
                _requestBuiltInJavaStudies() {
                    return this._chartWidgetCollection.activeChartWidget.value().metaInfoRepository().findAllJavaStudies()
                }
                _focus() {
                    var e;
                    this._getProps().value().isOpened && (null === (e = this._dialog.current) || void 0 === e || e.focus())
                }
                _getContainer() {
                    return this._container
                }
                _getDialog() {
                    return this._dialog
                }
                _updateSymbolInfo() {}
            } {
                constructor(e, t) {
                    super(e), this._studies = {}, this._options = {
                        onWidget: !1
                    }, this._getStudies = e => this._studies[e] || [], t && (this._options = t), this._props = new(q())({
                        data: [],
                        applyStudy: this._applyStudy.bind(this),
                        isOpened: !1,
                        reference: this._getDialog(),
                        onClose: this.hide.bind(this)
                    }), this._getProps().subscribe(this._render.bind(this)), this._init()
                }
                _getProps() {
                    return this._props
                }
                async _init() {
                    const e = await this._requestBuiltInJavaStudies();
                    this._studies = function(e) {
                        const t = {};
                        return e.forEach(e => {
                            const {
                                studyData: n
                            } = e;
                            if (!n) return;
                            const {
                                packageName: i
                            } = n;
                            i in t ? t[i].push(e) : t[i] = [e]
                        }), t
                    }(function(e, t = !0) {
                        return e.filter(e => {
                            const n = !!t || ! function(e) {
                                return e.isStrategy
                            }(e);
                            return !e.isHidden && n
                        })
                    }(e.map(m)));
                    const t = [...this._getStudies("tv-basicstudies"), ...this._getStudies("Script$STD"), ...this._getStudies("tv-volumebyprice")].filter(e => !e.isStrategy).sort(u);
                    this._setProps({
                        data: t
                    })
                }
                _render() {
                    if (this._shouldPreventRender()) return;
                    const {
                        props: e,
                        container: t
                    } = this._getRenderData();
                    r.render(i.createElement(Y, { ...e
                    }), t)
                }
            }
        },
        77687: (e, t, n) => {
            "use strict";
            n.d(t, {
                FavoriteButton: () => u
            });
            var i = n(25177),
                r = n(59496),
                o = n(97754),
                s = n(72571),
                a = n(17110),
                l = n(6639),
                c = n(16842);
            const d = {
                add: (0, i.t)("Add to favorites"),
                remove: (0, i.t)("Remove from favorites")
            };

            function u(e) {
                const {
                    className: t,
                    isFilled: n,
                    isActive: i,
                    onClick: u,
                    ...h
                } = e;
                return r.createElement(s.Icon, { ...h,
                    className: o(c.favorite, "apply-common-tooltip", n && c.checked, i && c.active, t),
                    icon: n ? a : l,
                    onClick: u,
                    title: n ? d.remove : d.add
                })
            }
        },
        12991: (e, t, n) => {
            "use strict";
            n.d(t, {
                rankedSearch: () => r,
                createRegExpList: () => o,
                getHighlightedChars: () => s
            });
            var i = n(2683);

            function r(e) {
                const {
                    data: t,
                    rules: n,
                    queryString: r,
                    isPreventedFromFiltering: o,
                    primaryKey: s,
                    secondaryKey: a = s,
                    optionalPrimaryKey: l
                } = e;
                return t.map(e => {
                    const t = l && e[l] ? e[l] : e[s],
                        o = e[a];
                    let c, d = 0;
                    return n.forEach(e => {
                        var n, s, a, l;
                        const {
                            re: u,
                            fullMatch: h
                        } = e;
                        return u.lastIndex = 0, t && t.toLowerCase() === r.toLowerCase() ? (d = 3, void(c = null === (n = t.match(h)) || void 0 === n ? void 0 : n.index)) : (0, i.isString)(t) && h.test(t) ? (d = 2, void(c = null === (s = t.match(h)) || void 0 === s ? void 0 : s.index)) : (0, i.isString)(o) && h.test(o) ? (d = 1, void(c = null === (a = o.match(h)) || void 0 === a ? void 0 : a.index)) : void((0, i.isString)(o) && u.test(o) && (d = 1, c = null === (l = o.match(u)) || void 0 === l ? void 0 : l.index))
                    }), {
                        matchPriority: d,
                        matchIndex: c,
                        item: e
                    }
                }).filter(e => o || e.matchPriority).sort((e, t) => {
                    if (e.matchPriority < t.matchPriority) return 1;
                    if (e.matchPriority > t.matchPriority) return -1;
                    if (e.matchPriority === t.matchPriority) {
                        if (void 0 === e.matchIndex || void 0 === t.matchIndex) return 0;
                        if (e.matchIndex > t.matchIndex) return 1;
                        if (e.matchIndex < t.matchIndex) return -1
                    }
                    return 0
                }).map(({
                    item: e
                }) => e)
            }

            function o(e, t) {
                const n = [],
                    i = e.toLowerCase(),
                    r = e.split("").map((e, t) => `(${0!==t?"[/\\s-]"+a(e):a(e)})`).join("(.*?)") + "(.*)";
                return n.push({
                    fullMatch: new RegExp(`(${a(e)})`, "i"),
                    re: new RegExp("^" + r, "i"),
                    reserveRe: new RegExp(r, "i"),
                    fuzzyHighlight: !0
                }), t && t.hasOwnProperty(i) && n.push({
                    fullMatch: t[i],
                    re: t[i],
                    fuzzyHighlight: !1
                }), n
            }

            function s(e, t, n) {
                const i = [];
                return e && n ? (n.forEach(e => {
                    const {
                        fullMatch: n,
                        re: r,
                        reserveRe: o
                    } = e;
                    n.lastIndex = 0, r.lastIndex = 0;
                    const s = n.exec(t),
                        a = s || r.exec(t) || o && o.exec(t);
                    if (e.fuzzyHighlight = !s, a)
                        if (e.fuzzyHighlight) {
                            let e = a.index;
                            for (let t = 1; t < a.length; t++) {
                                const n = a[t],
                                    r = a[t].length;
                                if (t % 2) {
                                    const t = n.startsWith(" ") || n.startsWith("/") || n.startsWith("-");
                                    i[t ? e + 1 : e] = !0
                                }
                                e += r
                            }
                        } else
                            for (let e = 0; e < a[0].length; e++) i[a.index + e] = !0
                }), i) : i
            }

            function a(e) {
                return e.replace(/[!-/[-^{-}]/g, "\\$&")
            }
        },
        60598: (e, t, n) => {
            "use strict";
            n.d(t, {
                HighlightedText: () => a
            });
            var i = n(59496),
                r = n(97754),
                o = n(12991),
                s = n(22932);

            function a(e) {
                const {
                    queryString: t,
                    rules: n,
                    text: a,
                    className: l
                } = e, c = (0, i.useMemo)(() => (0, o.getHighlightedChars)(t, a, n), [t, n, a]);
                return i.createElement(i.Fragment, null, c.length ? a.split("").map((e, t) => i.createElement(i.Fragment, {
                    key: t
                }, c[t] ? i.createElement("span", {
                    className: r(s.highlighted, l)
                }, e) : i.createElement("span", null, e))) : a)
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => o
            });
            var i = n(59496),
                r = n(21709);

            function o(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: o,
                    touchStart: s,
                    handler: a,
                    reference: l,
                    ownerDocument: c = document
                } = e, d = (0, i.useRef)(null), u = (0, i.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, i.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: o,
                            touchStart: s
                        },
                        i = l ? l.current : d.current;
                    return (0, r.addOutsideEventListener)(u.current, i, a, c, e)
                }, [t, n, o, s, a]), l || d
            }
        },
        97265: (e, t, n) => {
            "use strict";
            n.d(t, {
                useWatchedValueReadonly: () => r
            });
            var i = n(59496);
            const r = (e, t = !1) => {
                const n = "watchedValue" in e ? e.watchedValue : void 0,
                    r = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                    [o, s] = (0, i.useState)(n ? n.value() : r);
                return (t ? i.useLayoutEffect : i.useEffect)(() => {
                    if (n) {
                        s(n.value());
                        const e = e => s(e);
                        return n.subscribe(e), () => n.unsubscribe(e)
                    }
                    return () => {}
                }, [n]), o
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => r
            });
            var i = n(59496);
            class r extends i.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        94707: (e, t, n) => {
            "use strict";
            n.d(t, {
                Separator: () => s
            });
            var i = n(59496),
                r = n(97754),
                o = n(91626);

            function s(e) {
                return i.createElement("div", {
                    className: r(o.separator, e.className)
                })
            }
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => o,
                getRootOverlapManager: () => a
            });
            var i = n(88537);
            class r {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class o {
                constructor(e = document) {
                    this._storage = new r, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const i = this._document.createElement("div");
                    if (i.style.position = t.position, i.style.zIndex = this._index.toString(), i.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(i);
                        else if (t.index <= 0) this._container.insertBefore(i, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(i, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(i, this._container.firstChild) : this._container.appendChild(i);
                    return this._windows.set(e, i), ++this._index, i
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const s = new WeakMap;

            function a(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, i.ensureDefined)(s.get(t)); {
                    const t = new o(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return s.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => l,
                PortalContext: () => c
            });
            var i = n(59496),
                r = n(87995),
                o = n(16345),
                s = n(63212),
                a = n(53327);
            class l extends i.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, o.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", r.createPortal(i.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, s.getRootOverlapManager)() : this.context
                }
            }
            l.contextType = a.SlotContext;
            const c = i.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => r,
                SlotContext: () => o
            });
            var i = n(59496);
            class r extends i.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return i.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const o = i.createContext(null)
        },
        32455: (e, t, n) => {
            "use strict";
            n.d(t, {
                Spinner: () => s
            });
            var i = n(59496),
                r = n(97754),
                o = n(63654);
            n(24780);

            function s(e) {
                const t = r(e.className, "tv-spinner", "tv-spinner--shown", "tv-spinner--size_" + o.spinnerSizeMap[e.size || o.DEFAULT_SIZE]);
                return i.createElement("div", {
                    className: t,
                    style: e.style,
                    role: "progressbar"
                })
            }
        },
        35555: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentcolor" stroke-width="1.3" d="M12 9l5 5-5 5"/></svg>'
        },
        35487: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        80200: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none"><path stroke="currentColor" d="M12.4 12.5a7 7 0 1 0-4.9 2 7 7 0 0 0 4.9-2zm0 0l5.101 5"/></svg>'
        },
        17110: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="currentColor" d="M9 1l2.35 4.76 5.26.77-3.8 3.7.9 5.24L9 13l-4.7 2.47.9-5.23-3.8-3.71 5.25-.77L9 1z"/></svg>'
        },
        6639: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M9 2.13l1.903 3.855.116.236.26.038 4.255.618-3.079 3.001-.188.184.044.259.727 4.237-3.805-2L9 12.434l-.233.122-3.805 2.001.727-4.237.044-.26-.188-.183-3.079-3.001 4.255-.618.26-.038.116-.236L9 2.13z"/></svg>'
        }
    }
]);
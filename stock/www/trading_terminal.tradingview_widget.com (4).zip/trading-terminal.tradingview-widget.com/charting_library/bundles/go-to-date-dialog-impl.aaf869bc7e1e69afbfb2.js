(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [1859, 8890], {
        21103: e => {
            e.exports = {
                container: "container-pgo9gj31",
                "intent-default": "intent-default-pgo9gj31",
                focused: "focused-pgo9gj31",
                readonly: "readonly-pgo9gj31",
                disabled: "disabled-pgo9gj31",
                "with-highlight": "with-highlight-pgo9gj31",
                grouped: "grouped-pgo9gj31",
                "adjust-position": "adjust-position-pgo9gj31",
                "first-row": "first-row-pgo9gj31",
                "first-col": "first-col-pgo9gj31",
                stretch: "stretch-pgo9gj31",
                "font-size-medium": "font-size-medium-pgo9gj31",
                "font-size-large": "font-size-large-pgo9gj31",
                "size-small": "size-small-pgo9gj31",
                "size-medium": "size-medium-pgo9gj31",
                "size-large": "size-large-pgo9gj31",
                "intent-success": "intent-success-pgo9gj31",
                "intent-warning": "intent-warning-pgo9gj31",
                "intent-danger": "intent-danger-pgo9gj31",
                "intent-primary": "intent-primary-pgo9gj31",
                "border-none": "border-none-pgo9gj31",
                "border-thin": "border-thin-pgo9gj31",
                "border-thick": "border-thick-pgo9gj31",
                "no-corner-top-left": "no-corner-top-left-pgo9gj31",
                "no-corner-top-right": "no-corner-top-right-pgo9gj31",
                "no-corner-bottom-right": "no-corner-bottom-right-pgo9gj31",
                "no-corner-bottom-left": "no-corner-bottom-left-pgo9gj31",
                highlight: "highlight-pgo9gj31",
                shown: "shown-pgo9gj31"
            }
        },
        10306: e => {
            e.exports = {
                "inner-slot": "inner-slot-QpAAIiaV",
                interactive: "interactive-QpAAIiaV",
                icon: "icon-QpAAIiaV",
                "inner-middle-slot": "inner-middle-slot-QpAAIiaV",
                "before-slot": "before-slot-QpAAIiaV",
                "after-slot": "after-slot-QpAAIiaV"
            }
        },
        66579: e => {
            e.exports = {
                input: "input-uGWFLwEy",
                "with-start-slot": "with-start-slot-uGWFLwEy",
                "with-end-slot": "with-end-slot-uGWFLwEy"
            }
        },
        45228: e => {
            e.exports = {
                calendar: "calendar-wVs9kh0I"
            }
        },
        55400: e => {
            e.exports = {
                row: "row-9XF0QIKT",
                mobileRow: "mobileRow-9XF0QIKT"
            }
        },
        26074: e => {
            e.exports = {
                dialogWrapper: "dialogWrapper-70bfoXiO",
                dialogWrapperSmall: "dialogWrapperSmall-70bfoXiO",
                tabs: "tabs-70bfoXiO",
                content: "content-70bfoXiO",
                contentMobile: "contentMobile-70bfoXiO",
                bodyWrapper: "bodyWrapper-70bfoXiO"
            }
        },
        91131: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                footer: "footer-xe9kH1lJ",
                submitButton: "submitButton-xe9kH1lJ",
                buttons: "buttons-xe9kH1lJ"
            }
        },
        96746: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        67179: e => {
            e.exports = {
                dialog: "dialog-HExheUfY",
                wrapper: "wrapper-HExheUfY",
                separator: "separator-HExheUfY"
            }
        },
        91441: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                container: "container-tuOy5zvD",
                unsetAlign: "unsetAlign-tuOy5zvD",
                title: "title-tuOy5zvD",
                subtitle: "subtitle-tuOy5zvD",
                ellipsis: "ellipsis-tuOy5zvD",
                close: "close-tuOy5zvD"
            }
        },
        47922: e => {
            e.exports = {
                slider: "slider-Q7h4o6oW",
                inner: "inner-Q7h4o6oW"
            }
        },
        42545: e => {
            e.exports = {
                scrollWrap: "scrollWrap-VabV7Fn8",
                tabsWrap: "tabsWrap-VabV7Fn8",
                tabs: "tabs-VabV7Fn8",
                withoutBorder: "withoutBorder-VabV7Fn8",
                tab: "tab-VabV7Fn8",
                withHover: "withHover-VabV7Fn8",
                headerBottomSeparator: "headerBottomSeparator-VabV7Fn8",
                fadeWithoutSlider: "fadeWithoutSlider-VabV7Fn8",
                withBadge: "withBadge-VabV7Fn8"
            }
        },
        66875: e => {
            e.exports = {
                errors: "errors-Cv6NxnRZ",
                show: "show-Cv6NxnRZ",
                error: "error-Cv6NxnRZ"
            }
        },
        41814: e => {
            e.exports = {
                wrap: "wrap-sfzcrPlH",
                wrapWithArrowsOuting: "wrapWithArrowsOuting-sfzcrPlH",
                wrapOverflow: "wrapOverflow-sfzcrPlH",
                scrollWrap: "scrollWrap-sfzcrPlH",
                noScrollBar: "noScrollBar-sfzcrPlH",
                icon: "icon-sfzcrPlH",
                scrollLeft: "scrollLeft-sfzcrPlH",
                scrollRight: "scrollRight-sfzcrPlH",
                isVisible: "isVisible-sfzcrPlH",
                iconWrap: "iconWrap-sfzcrPlH",
                fadeLeft: "fadeLeft-sfzcrPlH",
                fadeRight: "fadeRight-sfzcrPlH"
            }
        },
        93314: e => {
            e.exports = {
                "error-icon": "error-icon-llFIA0b4",
                "intent-danger": "intent-danger-llFIA0b4",
                "intent-warning": "intent-warning-llFIA0b4"
            }
        },
        52965: e => {
            e.exports = {
                "static-messages": "static-messages-Yp0dNSLN",
                errors: "errors-Yp0dNSLN",
                warnings: "warnings-Yp0dNSLN",
                message: "message-Yp0dNSLN"
            }
        },
        91626: e => {
            e.exports = {
                separator: "separator-jtAq6E4V"
            }
        },
        37740: e => {
            e.exports = {
                tabs: "tabs-rKFlMYkc",
                tab: "tab-rKFlMYkc",
                noBorder: "noBorder-rKFlMYkc",
                disabled: "disabled-rKFlMYkc",
                active: "active-rKFlMYkc",
                defaultCursor: "defaultCursor-rKFlMYkc",
                slider: "slider-rKFlMYkc",
                content: "content-rKFlMYkc"
            }
        },
        80327: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlGroupContext: () => r
            });
            const r = n(59496).createContext({
                isGrouped: !1,
                cellState: {
                    isTop: !0,
                    isRight: !0,
                    isBottom: !0,
                    isLeft: !0
                }
            })
        },
        31774: (e, t, n) => {
            "use strict";

            function r(e) {
                let t = 0;
                return e.isTop && e.isLeft || (t += 1), e.isTop && e.isRight || (t += 2), e.isBottom && e.isLeft || (t += 8), e.isBottom && e.isRight || (t += 4), t
            }
            n.d(t, {
                getGroupCellRemoveRoundBorders: () => r
            })
        },
        34735: (e, t, n) => {
            "use strict";
            n.d(t, {
                ControlSkeleton: () => b,
                InputClasses: () => m
            });
            var r = n(59496),
                o = n(97754),
                s = n(88537),
                i = n(28606),
                a = n(417),
                l = n(80327),
                c = n(31774);
            var u = n(21103),
                d = n.n(u);

            function h(e) {
                let t = "";
                return 0 !== e && (1 & e && (t = o(t, d()["no-corner-top-left"])), 2 & e && (t = o(t, d()["no-corner-top-right"])), 4 & e && (t = o(t, d()["no-corner-bottom-right"])), 8 & e && (t = o(t, d()["no-corner-bottom-left"]))), t
            }

            function p(e, t, n, r) {
                const {
                    removeRoundBorder: s,
                    className: i,
                    intent: a = "default",
                    borderStyle: l = "thin",
                    size: u,
                    highlight: p,
                    disabled: f,
                    readonly: m,
                    stretch: g,
                    noReadonlyStyles: v,
                    isFocused: b
                } = e, w = h(null != s ? s : (0, c.getGroupCellRemoveRoundBorders)(n));
                return o(d().container, d()["intent-" + a], d()["border-" + l], u && d()["size-" + u], w, p && d()["with-highlight"], f && d().disabled, m && !v && d().readonly, b && d().focused, g && d().stretch, t && d().grouped, !r && d()["adjust-position"], n.isTop && d()["first-row"], n.isLeft && d()["first-col"], i)
            }

            function f(e, t) {
                const {
                    highlight: n,
                    highlightRemoveRoundBorder: r
                } = e;
                if (!n) return d().highlight;
                const s = h(null != r ? r : (0, c.getGroupCellRemoveRoundBorders)(t));
                return o(d().highlight, d().shown, s)
            }
            const m = {
                    FontSizeMedium: (0, s.ensureDefined)(d()["font-size-medium"]),
                    FontSizeLarge: (0, s.ensureDefined)(d()["font-size-large"])
                },
                g = {
                    passive: !1
                };

            function v(e, t) {
                const {
                    id: n,
                    role: o,
                    onFocus: s,
                    onBlur: c,
                    onMouseOver: u,
                    onMouseOut: d,
                    onMouseDown: h,
                    onMouseUp: m,
                    onKeyDown: v,
                    onClick: b,
                    tabIndex: w,
                    startSlot: y,
                    middleSlot: E,
                    endSlot: _,
                    onWheel: S,
                    onWheelNoPassive: C = null
                } = e, {
                    isGrouped: D,
                    cellState: O,
                    disablePositionAdjustment: M = !1
                } = (0, r.useContext)(l.ControlGroupContext), x = function(e, t = null, n) {
                    const o = (0, r.useRef)(null),
                        s = (0, r.useRef)(null),
                        i = (0, r.useCallback)(() => {
                            if (null === o.current || null === s.current) return;
                            const [e, t, n] = s.current;
                            null !== t && o.current.addEventListener(e, t, n)
                        }, []),
                        a = (0, r.useCallback)(() => {
                            if (null === o.current || null === s.current) return;
                            const [e, t, n] = s.current;
                            null !== t && o.current.removeEventListener(e, t, n)
                        }, []),
                        l = (0, r.useCallback)(e => {
                            a(), o.current = e, i()
                        }, []);
                    return (0, r.useEffect)(() => (s.current = [e, t, n], i(), a), [e, t, n]), l
                }("wheel", C, g);
                return r.createElement("span", {
                    id: n,
                    role: o,
                    className: p(e, D, O, M),
                    tabIndex: w,
                    ref: (0, i.useMergedRefs)([t, x]),
                    onFocus: s,
                    onBlur: c,
                    onMouseOver: u,
                    onMouseOut: d,
                    onMouseDown: h,
                    onMouseUp: m,
                    onKeyDown: v,
                    onClick: b,
                    onWheel: S,
                    ...(0, a.filterDataProps)(e),
                    ...(0, a.filterAriaProps)(e)
                }, y, E, _, r.createElement("span", {
                    className: f(e, O)
                }))
            }
            v.displayName = "ControlSkeleton";
            const b = r.forwardRef(v)
        },
        2691: (e, t, n) => {
            "use strict";
            n.d(t, {
                BeforeSlot: () => a,
                StartSlot: () => l,
                MiddleSlot: () => c,
                EndSlot: () => u,
                AfterSlot: () => d
            });
            var r = n(59496),
                o = n(97754),
                s = n(10306),
                i = n.n(s);

            function a(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return r.createElement("span", {
                    className: o(i()["before-slot"], t)
                }, n)
            }

            function l(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: s = !1,
                    children: a
                } = e;
                return r.createElement("span", {
                    className: o(i()["inner-slot"], n && i().interactive, s && i().icon, t)
                }, a)
            }

            function c(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return r.createElement("span", {
                    className: o(i()["inner-slot"], i()["inner-middle-slot"], t)
                }, n)
            }

            function u(e) {
                const {
                    className: t,
                    interactive: n = !0,
                    icon: s = !1,
                    children: a
                } = e;
                return r.createElement("span", {
                    className: o(i()["inner-slot"], n && i().interactive, s && i().icon, t)
                }, a)
            }

            function d(e) {
                const {
                    className: t,
                    children: n
                } = e;
                return r.createElement("span", {
                    className: o(i()["after-slot"], t)
                }, n)
            }
        },
        54936: (e, t, n) => {
            "use strict";
            n.d(t, {
                Input: () => v,
                InputControl: () => b
            });
            var r = n(59496),
                o = n(97754),
                s = n(417),
                i = n(69842),
                a = n(1811),
                l = n(28606),
                c = n(21778),
                u = n(83836),
                d = n(3548),
                h = n(34735),
                p = n(2691),
                f = n(66579),
                m = n.n(f);

            function g(e) {
                return !(0, s.isAriaAttribute)(e) && !(0, s.isDataAttribute)(e)
            }

            function v(e) {
                const {
                    id: t,
                    title: n,
                    role: i,
                    tabIndex: a,
                    placeholder: l,
                    name: c,
                    type: u,
                    value: d,
                    defaultValue: f,
                    draggable: v,
                    autoComplete: b,
                    autoFocus: w,
                    maxLength: y,
                    min: E,
                    max: _,
                    step: S,
                    pattern: C,
                    inputMode: D,
                    onSelect: O,
                    onFocus: M,
                    onBlur: x,
                    onKeyDown: N,
                    onKeyUp: T,
                    onKeyPress: R,
                    onChange: A,
                    onDragStart: k,
                    size: P = "medium",
                    className: F,
                    inputClassName: B,
                    disabled: W,
                    readonly: L,
                    containerTabIndex: I,
                    startSlot: z,
                    endSlot: j,
                    reference: V,
                    containerReference: H,
                    onContainerFocus: U,
                    ...G
                } = e, Y = (0, s.filterProps)(G, g), K = { ...(0, s.filterAriaProps)(G),
                    ...(0, s.filterDataProps)(G),
                    id: t,
                    title: n,
                    role: i,
                    tabIndex: a,
                    placeholder: l,
                    name: c,
                    type: u,
                    value: d,
                    defaultValue: f,
                    draggable: v,
                    autoComplete: b,
                    autoFocus: w,
                    maxLength: y,
                    min: E,
                    max: _,
                    step: S,
                    pattern: C,
                    inputMode: D,
                    onSelect: O,
                    onFocus: M,
                    onBlur: x,
                    onKeyDown: N,
                    onKeyUp: T,
                    onKeyPress: R,
                    onChange: A,
                    onDragStart: k
                };
                return r.createElement(h.ControlSkeleton, { ...Y,
                    disabled: W,
                    readonly: L,
                    tabIndex: I,
                    className: o(m().container, F),
                    size: P,
                    ref: H,
                    onFocus: U,
                    startSlot: z,
                    middleSlot: r.createElement(p.MiddleSlot, null, r.createElement("input", { ...K,
                        className: o(m().input, B, z && m()["with-start-slot"], j && m()["with-end-slot"]),
                        disabled: W,
                        readOnly: L,
                        ref: V
                    })),
                    endSlot: j
                })
            }

            function b(e) {
                e = (0, c.useControl)(e);
                const {
                    disabled: t,
                    autoSelectOnFocus: n,
                    tabIndex: o = 0,
                    onFocus: s,
                    onBlur: h,
                    reference: p,
                    containerReference: f = null
                } = e, m = (0, r.useRef)(null), g = (0, r.useRef)(null), [b, w] = (0, u.useFocus)(), y = t ? void 0 : b ? -1 : o, E = t ? void 0 : b ? o : -1, {
                    isMouseDown: _,
                    handleMouseDown: S,
                    handleMouseUp: C
                } = (0, d.useIsMouseDown)(), D = (0, i.createSafeMulticastEventHandler)(w.onFocus, (function(e) {
                    n && !_.current && (0, a.selectAllContent)(e.currentTarget)
                }), s), O = (0, i.createSafeMulticastEventHandler)(w.onBlur, h), M = (0, r.useCallback)(e => {
                    m.current = e, p && ("function" == typeof p && p(e), "object" == typeof p && (p.current = e))
                }, [m, p]);
                return r.createElement(v, { ...e,
                    isFocused: b,
                    containerTabIndex: y,
                    tabIndex: E,
                    onContainerFocus: function(e) {
                        g.current === e.target && null !== m.current && m.current.focus()
                    },
                    onFocus: D,
                    onBlur: O,
                    reference: M,
                    containerReference: (0, l.useMergedRefs)([g, f]),
                    onMouseDown: S,
                    onMouseUp: C
                })
            }
        },
        21778: (e, t, n) => {
            "use strict";
            n.d(t, {
                useControl: () => s
            });
            var r = n(69842),
                o = n(83836);

            function s(e) {
                const {
                    onFocus: t,
                    onBlur: n,
                    intent: s,
                    highlight: i,
                    disabled: a
                } = e, [l, c] = (0, o.useFocus)(void 0, a), u = (0, r.createSafeMulticastEventHandler)(a ? void 0 : c.onFocus, t), d = (0, r.createSafeMulticastEventHandler)(a ? void 0 : c.onBlur, n);
                return { ...e,
                    intent: s || (l ? "primary" : "default"),
                    highlight: null != i ? i : l,
                    onFocus: u,
                    onBlur: d
                }
            }
        },
        83836: (e, t, n) => {
            "use strict";
            n.d(t, {
                useFocus: () => o
            });
            var r = n(59496);

            function o(e, t) {
                const [n, o] = (0, r.useState)(!1);
                (0, r.useEffect)(() => {
                    t && n && o(!1)
                }, [t, n]);
                const s = {
                    onFocus: (0, r.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || o(!0)
                    }), [e]),
                    onBlur: (0, r.useCallback)((function(t) {
                        void 0 !== e && e.current !== t.target || o(!1)
                    }), [e])
                };
                return [n, s]
            }
        },
        3548: (e, t, n) => {
            "use strict";
            n.d(t, {
                useIsMouseDown: () => o
            });
            var r = n(59496);

            function o() {
                const e = (0, r.useRef)(!1),
                    t = (0, r.useCallback)(() => {
                        e.current = !0
                    }, [e]),
                    n = (0, r.useCallback)(() => {
                        e.current = !1
                    }, [e]);
                return {
                    isMouseDown: e,
                    handleMouseDown: t,
                    handleMouseUp: n
                }
            }
        },
        28606: (e, t, n) => {
            "use strict";
            n.d(t, {
                useMergedRefs: () => o
            });
            var r = n(59496);

            function o(e) {
                return (0, r.useCallback)(function(e) {
                    return t => {
                        e.forEach(e => {
                            "function" == typeof e ? e(t) : null != e && (e.current = t)
                        })
                    }
                }(e), e)
            }
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => o
            });
            var r = n(59496);
            const o = r.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...o
                } = e;
                return r.createElement("span", { ...o,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        417: (e, t, n) => {
            "use strict";

            function r(e) {
                return s(e, i)
            }

            function o(e) {
                return s(e, a)
            }

            function s(e, t) {
                const n = Object.entries(e).filter(t),
                    r = {};
                for (const [e, t] of n) r[e] = t;
                return r
            }

            function i(e) {
                const [t, n] = e;
                return 0 === t.indexOf("data-") && "string" == typeof n
            }

            function a(e) {
                return 0 === e[0].indexOf("aria-")
            }
            n.d(t, {
                filterDataProps: () => r,
                filterAriaProps: () => o,
                filterProps: () => s,
                isDataAttribute: () => i,
                isAriaAttribute: () => a
            })
        },
        1811: (e, t, n) => {
            "use strict";

            function r(e) {
                null !== e && e.setSelectionRange(0, e.value.length)
            }
            n.d(t, {
                selectAllContent: () => r
            })
        },
        69842: (e, t, n) => {
            "use strict";

            function r(...e) {
                return t => {
                    for (const n of e) void 0 !== n && n(t)
                }
            }
            n.d(t, {
                createSafeMulticastEventHandler: () => r
            })
        },
        7270: function(e, t, n) {
            var r, o, s;
            e.exports = (r = n(59496), o = n(87995), s = n(59255), function(e) {
                function t(r) {
                    if (n[r]) return n[r].exports;
                    var o = n[r] = {
                        exports: {},
                        id: r,
                        loaded: !1
                    };
                    return e[r].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports
                }
                var n = {};
                return t.m = e, t.c = n, t.p = "dist/", t(0)
            }([function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(1));
                t.default = r.default, e.exports = t.default
            }, function(e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var o = function() {
                        function e(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                            }
                        }
                        return function(t, n, r) {
                            return n && e(t.prototype, n), r && e(t, r), t
                        }
                    }(),
                    s = n(2),
                    i = (r(s), n(3)),
                    a = r(i),
                    l = r(n(13)),
                    c = r(n(14)),
                    u = r(n(15)),
                    d = function(e) {
                        function t(e) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, t);
                            var n = function(e, t) {
                                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !t || "object" != typeof t && "function" != typeof t ? e : t
                            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                            return n.measure = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.props.includeMargin;
                                if (n.props.shouldMeasure) {
                                    n._node.parentNode || n._setDOMNode();
                                    var t = n.getDimensions(n._node, e),
                                        r = "function" == typeof n.props.children;
                                    n._propsToMeasure.some((function(e) {
                                        if (t[e] !== n._lastDimensions[e]) return n.props.onMeasure(t), r && void 0 !== n && n.setState({
                                            dimensions: t
                                        }), n._lastDimensions = t, !0
                                    }))
                                }
                            }, n.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, n._node = null, n._propsToMeasure = n._getPropsToMeasure(e), n._lastDimensions = {}, n
                        }
                        return function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                        }(t, e), o(t, [{
                            key: "componentDidMount",
                            value: function() {
                                var e = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new c.default((function() {
                                    return e.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(e) {
                                var t = (e.config, e.whitelist),
                                    n = e.blacklist;
                                this.props.whitelist === t && this.props.blacklist === n || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: t,
                                    blacklist: n
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = l.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, u.default)(e, {
                                    margin: t
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(e) {
                                var t = e.whitelist,
                                    n = e.blacklist;
                                return t.filter((function(e) {
                                    return n.indexOf(e) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.props.children;
                                return s.Children.only("function" == typeof e ? e(this.state.dimensions) : e)
                            }
                        }]), t
                    }(s.Component);
                d.propTypes = {
                    whitelist: a.default.array,
                    blacklist: a.default.array,
                    includeMargin: a.default.bool,
                    useClone: a.default.bool,
                    cloneOptions: a.default.object,
                    shouldMeasure: a.default.bool,
                    onMeasure: a.default.func
                }, d.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, t.default = d, e.exports = t.default
            }, function(e, t) {
                e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) {
                        var o = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        e.exports = n(5)((function(e) {
                            return "object" === (void 0 === e ? "undefined" : r(e)) && null !== e && e.$$typeof === o
                        }), !0)
                    } else e.exports = n(12)()
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n() {
                    throw new Error("setTimeout has not been defined")
                }

                function r() {
                    throw new Error("clearTimeout has not been defined")
                }

                function o(e) {
                    if (c === setTimeout) return setTimeout(e, 0);
                    if ((c === n || !c) && setTimeout) return c = setTimeout, setTimeout(e, 0);
                    try {
                        return c(e, 0)
                    } catch (t) {
                        try {
                            return c.call(null, e, 0)
                        } catch (t) {
                            return c.call(this, e, 0)
                        }
                    }
                }

                function s() {
                    f && h && (f = !1, h.length ? p = h.concat(p) : m = -1, p.length && i())
                }

                function i() {
                    if (!f) {
                        var e = o(s);
                        f = !0;
                        for (var t = p.length; t;) {
                            for (h = p, p = []; ++m < t;) h && h[m].run();
                            m = -1, t = p.length
                        }
                        h = null, f = !1,
                            function(e) {
                                if (u === clearTimeout) return clearTimeout(e);
                                if ((u === r || !u) && clearTimeout) return u = clearTimeout, clearTimeout(e);
                                try {
                                    u(e)
                                } catch (t) {
                                    try {
                                        return u.call(null, e)
                                    } catch (t) {
                                        return u.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function a(e, t) {
                    this.fun = e, this.array = t
                }

                function l() {}
                var c, u, d = e.exports = {};
                ! function() {
                    try {
                        c = "function" == typeof setTimeout ? setTimeout : n
                    } catch (e) {
                        c = n
                    }
                    try {
                        u = "function" == typeof clearTimeout ? clearTimeout : r
                    } catch (e) {
                        u = r
                    }
                }();
                var h, p = [],
                    f = !1,
                    m = -1;
                d.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    p.push(new a(e, t)), 1 !== p.length || f || o(i)
                }, a.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, d.title = "browser", d.browser = !0, d.env = {}, d.argv = [], d.version = "", d.versions = {}, d.on = l, d.addListener = l, d.once = l, d.off = l, d.removeListener = l, d.removeAllListeners = l, d.emit = l, d.prependListener = l, d.prependOnceListener = l, d.listeners = function(e) {
                    return []
                }, d.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, d.cwd = function() {
                    return "/"
                }, d.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, d.umask = function() {
                    return 0
                }
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        },
                        o = n(6),
                        s = n(7),
                        i = n(8),
                        a = n(9),
                        l = n(10),
                        c = n(11);
                    e.exports = function(e, n) {
                        function u(e, t) {
                            return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
                        }

                        function d(e) {
                            this.message = e, this.stack = ""
                        }

                        function h(e) {
                            function r(r, c, u, h, p, f, m) {
                                if (h = h || y, f = f || u, m !== l)
                                    if (n) s(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== t.env.NODE_ENV && "undefined" != typeof console) {
                                    var g = h + ":" + u;
                                    !o[g] && a < 3 && (i(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", f, h), o[g] = !0, a++)
                                }
                                return null == c[u] ? r ? new d(null === c[u] ? "The " + p + " `" + f + "` is marked as required in `" + h + "`, but its value is `null`." : "The " + p + " `" + f + "` is marked as required in `" + h + "`, but its value is `undefined`.") : null : e(c, u, h, p, f)
                            }
                            if ("production" !== t.env.NODE_ENV) var o = {},
                                a = 0;
                            var c = r.bind(null, !1);
                            return c.isRequired = r.bind(null, !0), c
                        }

                        function p(e) {
                            return h((function(t, n, r, o, s, i) {
                                var a = t[n];
                                return m(a) !== e ? new d("Invalid " + o + " `" + s + "` of type `" + g(a) + "` supplied to `" + r + "`, expected `" + e + "`.") : null
                            }))
                        }

                        function f(t) {
                            switch (void 0 === t ? "undefined" : r(t)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !t;
                                case "object":
                                    if (Array.isArray(t)) return t.every(f);
                                    if (null === t || e(t)) return !0;
                                    var n = function(e) {
                                        var t = e && (b && e[b] || e[w]);
                                        if ("function" == typeof t) return t
                                    }(t);
                                    if (!n) return !1;
                                    var o, s = n.call(t);
                                    if (n !== t.entries) {
                                        for (; !(o = s.next()).done;)
                                            if (!f(o.value)) return !1
                                    } else
                                        for (; !(o = s.next()).done;) {
                                            var i = o.value;
                                            if (i && !f(i[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function m(e) {
                            var t = void 0 === e ? "undefined" : r(e);
                            return Array.isArray(e) ? "array" : e instanceof RegExp ? "object" : function(e, t) {
                                return "symbol" === e || "Symbol" === t["@@toStringTag"] || "function" == typeof Symbol && t instanceof Symbol
                            }(t, e) ? "symbol" : t
                        }

                        function g(e) {
                            if (null == e) return "" + e;
                            var t = m(e);
                            if ("object" === t) {
                                if (e instanceof Date) return "date";
                                if (e instanceof RegExp) return "regexp"
                            }
                            return t
                        }

                        function v(e) {
                            var t = g(e);
                            switch (t) {
                                case "array":
                                case "object":
                                    return "an " + t;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + t;
                                default:
                                    return t
                            }
                        }
                        var b = "function" == typeof Symbol && Symbol.iterator,
                            w = "@@iterator",
                            y = "<<anonymous>>",
                            E = {
                                array: p("array"),
                                bool: p("boolean"),
                                func: p("function"),
                                number: p("number"),
                                object: p("object"),
                                string: p("string"),
                                symbol: p("symbol"),
                                any: h(o.thatReturnsNull),
                                arrayOf: function(e) {
                                    return h((function(t, n, r, o, s) {
                                        if ("function" != typeof e) return new d("Property `" + s + "` of component `" + r + "` has invalid PropType notation inside arrayOf.");
                                        var i = t[n];
                                        if (!Array.isArray(i)) return new d("Invalid " + o + " `" + s + "` of type `" + m(i) + "` supplied to `" + r + "`, expected an array.");
                                        for (var a = 0; a < i.length; a++) {
                                            var c = e(i, a, r, o, s + "[" + a + "]", l);
                                            if (c instanceof Error) return c
                                        }
                                        return null
                                    }))
                                },
                                element: h((function(t, n, r, o, s) {
                                    var i = t[n];
                                    return e(i) ? null : new d("Invalid " + o + " `" + s + "` of type `" + m(i) + "` supplied to `" + r + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(e) {
                                    return h((function(t, n, r, o, s) {
                                        if (!(t[n] instanceof e)) {
                                            var i = e.name || y;
                                            return new d("Invalid " + o + " `" + s + "` of type `" + function(e) {
                                                return e.constructor && e.constructor.name ? e.constructor.name : y
                                            }(t[n]) + "` supplied to `" + r + "`, expected instance of `" + i + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: h((function(e, t, n, r, o) {
                                    return f(e[t]) ? null : new d("Invalid " + r + " `" + o + "` supplied to `" + n + "`, expected a ReactNode.")
                                })),
                                objectOf: function(e) {
                                    return h((function(t, n, r, o, s) {
                                        if ("function" != typeof e) return new d("Property `" + s + "` of component `" + r + "` has invalid PropType notation inside objectOf.");
                                        var i = t[n],
                                            a = m(i);
                                        if ("object" !== a) return new d("Invalid " + o + " `" + s + "` of type `" + a + "` supplied to `" + r + "`, expected an object.");
                                        for (var c in i)
                                            if (i.hasOwnProperty(c)) {
                                                var u = e(i, c, r, o, s + "." + c, l);
                                                if (u instanceof Error) return u
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(e) {
                                    return Array.isArray(e) ? h((function(t, n, r, o, s) {
                                        for (var i = t[n], a = 0; a < e.length; a++)
                                            if (u(i, e[a])) return null;
                                        return new d("Invalid " + o + " `" + s + "` of value `" + i + "` supplied to `" + r + "`, expected one of " + JSON.stringify(e) + ".")
                                    })) : ("production" !== t.env.NODE_ENV && i(!1, "Invalid argument supplied to oneOf, expected an instance of array."), o.thatReturnsNull)
                                },
                                oneOfType: function(e) {
                                    if (!Array.isArray(e)) return "production" !== t.env.NODE_ENV && i(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), o.thatReturnsNull;
                                    for (var n = 0; n < e.length; n++) {
                                        var r = e[n];
                                        if ("function" != typeof r) return i(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", v(r), n), o.thatReturnsNull
                                    }
                                    return h((function(t, n, r, o, s) {
                                        for (var i = 0; i < e.length; i++)
                                            if (null == (0, e[i])(t, n, r, o, s, l)) return null;
                                        return new d("Invalid " + o + " `" + s + "` supplied to `" + r + "`.")
                                    }))
                                },
                                shape: function(e) {
                                    return h((function(t, n, r, o, s) {
                                        var i = t[n],
                                            a = m(i);
                                        if ("object" !== a) return new d("Invalid " + o + " `" + s + "` of type `" + a + "` supplied to `" + r + "`, expected `object`.");
                                        for (var c in e) {
                                            var u = e[c];
                                            if (u) {
                                                var h = u(i, c, r, o, s + "." + c, l);
                                                if (h) return h
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(e) {
                                    return h((function(t, n, r, o, s) {
                                        var i = t[n],
                                            c = m(i);
                                        if ("object" !== c) return new d("Invalid " + o + " `" + s + "` of type `" + c + "` supplied to `" + r + "`, expected `object`.");
                                        var u = a({}, t[n], e);
                                        for (var h in u) {
                                            var p = e[h];
                                            if (!p) return new d("Invalid " + o + " `" + s + "` key `" + h + "` supplied to `" + r + "`.\nBad object: " + JSON.stringify(t[n], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(e), null, "  "));
                                            var f = p(i, h, r, o, s + "." + h, l);
                                            if (f) return f
                                        }
                                        return null
                                    }))
                                }
                            };
                        return d.prototype = Error.prototype, E.checkPropTypes = c, E.PropTypes = E, E
                    }
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    return function() {
                        return e
                    }
                }
                var r = function() {};
                r.thatReturns = n, r.thatReturnsFalse = n(!1), r.thatReturnsTrue = n(!0), r.thatReturnsNull = n(null), r.thatReturnsThis = function() {
                    return this
                }, r.thatReturnsArgument = function(e) {
                    return e
                }, e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var n = function(e) {};
                    "production" !== t.env.NODE_ENV && (n = function(e) {
                        if (void 0 === e) throw new Error("invariant requires an error message argument")
                    }), e.exports = function(e, t, r, o, s, i, a, l) {
                        if (n(t), !e) {
                            var c;
                            if (void 0 === t) c = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var u = [r, o, s, i, a, l],
                                    d = 0;
                                (c = new Error(t.replace(/%s/g, (function() {
                                    return u[d++]
                                })))).name = "Invariant Violation"
                            }
                            throw c.framesToPop = 1, c
                        }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = n(6);
                    if ("production" !== t.env.NODE_ENV) {
                        var o = function(e) {
                            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            var o = 0,
                                s = "Warning: " + e.replace(/%s/g, (function() {
                                    return n[o++]
                                }));
                            "undefined" != typeof console && console.error(s);
                            try {
                                throw new Error(s)
                            } catch (e) {}
                        };
                        r = function(e, t) {
                            if (void 0 === t) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== t.indexOf("Failed Composite propType: ") && !e) {
                                for (var n = arguments.length, r = Array(n > 2 ? n - 2 : 0), s = 2; s < n; s++) r[s - 2] = arguments[s];
                                o.apply(void 0, [t].concat(r))
                            }
                        }
                    }
                    e.exports = r
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }
                var r = Object.getOwnPropertySymbols,
                    o = Object.prototype.hasOwnProperty,
                    s = Object.prototype.propertyIsEnumerable;
                e.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var e = new String("abc");
                        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
                        if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                                return t[e]
                            })).join("")) return !1;
                        var r = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                            r[e] = e
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
                    } catch (e) {
                        return !1
                    }
                }() ? Object.assign : function(e, t) {
                    for (var i, a, l = n(e), c = 1; c < arguments.length; c++) {
                        for (var u in i = Object(arguments[c])) o.call(i, u) && (l[u] = i[u]);
                        if (r) {
                            a = r(i);
                            for (var d = 0; d < a.length; d++) s.call(i, a[d]) && (l[a[d]] = i[a[d]])
                        }
                    }
                    return l
                }
            }, function(e, t) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) var o = n(7),
                        s = n(8),
                        i = n(10),
                        a = {};
                    e.exports = function(e, n, l, c, u) {
                        if ("production" !== t.env.NODE_ENV)
                            for (var d in e)
                                if (e.hasOwnProperty(d)) {
                                    var h;
                                    try {
                                        o("function" == typeof e[d], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", c || "React class", l, d, r(e[d])), h = e[d](n, d, c, l, null, i)
                                    } catch (e) {
                                        h = e
                                    }
                                    if (s(!h || h instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", c || "React class", l, d, void 0 === h ? "undefined" : r(h)), h instanceof Error && !(h.message in a)) {
                                        a[h.message] = !0;
                                        var p = u ? u() : "";
                                        s(!1, "Failed %s type: %s%s", l, h.message, null != p ? p : "")
                                    }
                                }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                "use strict";
                var r = n(6),
                    o = n(7),
                    s = n(10);
                e.exports = function() {
                    function e(e, t, n, r, i, a) {
                        a !== s && o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function t() {
                        return e
                    }
                    e.isRequired = e;
                    var n = {
                        array: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: t,
                        element: e,
                        instanceOf: t,
                        node: e,
                        objectOf: t,
                        oneOf: t,
                        oneOfType: t,
                        shape: t,
                        exact: t
                    };
                    return n.checkPropTypes = r, n.PropTypes = n, n
                }
            }, function(e, t) {
                e.exports = o
            }, function(e, t) {
                e.exports = s
            }, function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = e.getBoundingClientRect(),
                        o = void 0,
                        s = void 0,
                        i = void 0;
                    return t.margin && (i = (0, r.default)(getComputedStyle(e))), t.margin ? (o = i.left + n.width + i.right, s = i.top + n.height + i.bottom) : (o = n.width, s = n.height), {
                        width: o,
                        height: s,
                        top: n.top,
                        right: n.right,
                        bottom: n.bottom,
                        left: n.left
                    }
                };
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(16));
                e.exports = t.default
            }, function(e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    return {
                        top: n((e = e || {}).marginTop),
                        right: n(e.marginRight),
                        bottom: n(e.marginBottom),
                        left: n(e.marginLeft)
                    }
                };
                var n = function(e) {
                    return parseInt(e) || 0
                };
                e.exports = t.default
            }]))
        },
        6138: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                showGoToDateDialog: () => te
            });
            var r = n(59496),
                o = n(87995),
                s = n(88537),
                i = n(88401),
                a = n(8550),
                l = n(63192),
                c = n(93540),
                u = n.n(c);
            const d = r.createContext(null);

            function h(e) {
                const {
                    initialGoToDate: t,
                    children: n
                } = e, [o, s] = (0, r.useState)(t), i = o.valueOf() <= (0, a.resetToDayEnd)(new Date).valueOf(), l = (0, r.useMemo)(() => ({
                    date: o,
                    setDate: s,
                    isValid: i
                }), [o, i]);
                return r.createElement(d.Provider, {
                    value: l
                }, n)
            }
            const p = r.createContext(null);

            function f(e) {
                const {
                    initialRanges: t,
                    children: n
                } = e, [o, s] = (0, r.useState)(t.from), [i, a] = (0, r.useState)(t.to), l = o.valueOf() <= i.valueOf(), c = (0, r.useMemo)(() => ({
                    dateFrom: o,
                    dateTo: i,
                    setDateFrom: s,
                    setDateTo: a,
                    isValid: l
                }), [o, i, l]);
                return r.createElement(p.Provider, {
                    value: c
                }, n)
            }
            var m = n(25177),
                g = n(97754),
                v = n.n(g),
                b = n(59410),
                w = n(70122),
                y = n.n(w),
                E = n(6594),
                _ = n(96038),
                S = n(76669),
                C = n(55400);

            function D(e) {
                const {
                    children: t
                } = e;
                return r.createElement("div", {
                    className: v()(C.row, U && C.mobileRow)
                }, t)
            }
            var O = n(14793),
                M = n(50324);
            const x = r.createContext({
                isActive: !1,
                isFocused: !1
            });

            function N(e) {
                const {
                    value: t,
                    reference: n,
                    isActive: o,
                    onPick: s,
                    onFocus: i
                } = e, [a, l] = (0, r.useState)(!1);
                return r.createElement(x.Provider, {
                    value: {
                        isActive: o,
                        isFocused: a
                    }
                }, r.createElement("div", {
                    onFocus: function() {
                        l(!0), i && i()
                    },
                    onBlur: function() {
                        l(!1)
                    }
                }, r.createElement(O.DatePicker, {
                    initial: t,
                    inputReference: n,
                    InputComponent: T,
                    withCalendar: !1,
                    onPick: function(e) {
                        if (!e) return;
                        s(new Date(e))
                    },
                    revertInvalidData: !0,
                    name: e.name
                })))
            }

            function T(e) {
                const {
                    isActive: t,
                    isFocused: n
                } = (0, r.useContext)(x);
                return r.createElement(M.DateInput, { ...e,
                    highlight: t || n
                })
            }
            var R = n(44807);

            function A(e) {
                const {
                    value: t,
                    isDisabled: n,
                    onPick: o
                } = e;
                return r.createElement(R.TimeInput, {
                    value: (s = t, (0, a.twoDigitsFormat)(s.getHours()) + ":" + (0, a.twoDigitsFormat)(s.getMinutes())),
                    onChange: o,
                    disabled: n
                });
                var s
            }
            var k = n(37294),
                P = n(45228);

            function F(e) {
                return r.createElement(k.Calendar, { ...e,
                    className: P.calendar,
                    popupStyle: !1
                })
            }

            function B(e, t) {
                const n = new Date(t);
                return n.setFullYear(e.getFullYear()), n.setMonth(e.getMonth()), n.setDate(e.getDate()), n
            }

            function W(e, t) {
                const n = new Date(t);
                return n.setHours(e.getHours()), n.setMinutes(e.getMinutes()), n
            }

            function L(e) {
                const {
                    dateOnly: t,
                    onCalendarMonthSwitch: n
                } = e, {
                    date: o,
                    setDate: i
                } = (0, s.ensureNotNull)((0, r.useContext)(d)), a = (0, r.useRef)(null), l = (0, r.useRef)(null);
                return (0, r.useEffect)(() => {
                    U || null === l.current || l.current.focus()
                }, []), r.createElement("div", {
                    ref: a,
                    tabIndex: -1
                }, r.createElement(D, null, r.createElement(N, {
                    reference: function(e) {
                        l.current = e
                    },
                    value: new Date(o),
                    onPick: function(e) {
                        const t = B(e, o);
                        i(t)
                    },
                    isActive: !U
                }), r.createElement(A, {
                    value: new Date(o),
                    isDisabled: t,
                    onPick: function(e) {
                        var t;
                        const [n, r] = e.split(":"), s = new Date;
                        s.setHours(Number(n)), s.setMinutes(Number(r));
                        const l = W(s, o);
                        i(l), U || null === (t = a.current) || void 0 === t || t.focus({
                            preventScroll: !0
                        })
                    }
                })), !U && r.createElement(F, {
                    key: `${o.getFullYear()}-${o.getMonth()}-${o.getDate()}`,
                    selectedDate: new Date(o),
                    onSelect: function(e) {
                        var t;
                        const n = B(e, o);
                        i(n), null === (t = a.current) || void 0 === t || t.focus({
                            preventScroll: !0
                        })
                    },
                    onMonthSwitch: n,
                    maxDate: new Date
                }))
            }

            function I(e) {
                const {
                    dateOnly: t,
                    onCalendarMonthSwitch: n,
                    onDateInputFocus: o
                } = e, {
                    dateFrom: i,
                    dateTo: a,
                    setDateFrom: l,
                    setDateTo: c
                } = (0, s.ensureNotNull)((0, r.useContext)(p)), [u, d] = (0, r.useState)("from"), h = (0, r.useRef)(null), f = (0, r.useRef)(null), m = (0, r.useRef)(null), g = (0, r.useMemo)(() => "from" === u ? new Date(i) : new Date(a), [u, a, i]);
                return (0, r.useEffect)(() => {
                    U || null === f.current || f.current.focus()
                }, []), r.createElement("div", {
                    ref: h,
                    tabIndex: -1
                }, r.createElement(D, null, r.createElement(N, {
                    value: i,
                    reference: function(e) {
                        f.current = e
                    },
                    isActive: !U && "from" === u,
                    onPick: function(e) {
                        const t = B(e, i);
                        l(t)
                    },
                    onFocus: function() {
                        d("from"), o()
                    },
                    name: "start-date-range"
                }), r.createElement(A, {
                    value: i,
                    isDisabled: t,
                    onPick: function(e) {
                        v(e, i, l)
                    }
                })), r.createElement(D, null, r.createElement(N, {
                    value: a,
                    reference: function(e) {
                        m.current = e
                    },
                    isActive: !U && "to" === u,
                    onPick: function(e) {
                        const t = B(e, a);
                        c(t)
                    },
                    onFocus: function() {
                        d("to"), o()
                    },
                    name: "end-date-range"
                }), r.createElement(A, {
                    value: a,
                    isDisabled: t,
                    onPick: function(e) {
                        v(e, a, c)
                    }
                })), !U && r.createElement(F, {
                    key: `${g.getFullYear()}-${g.getMonth()}-${g.getDate()}`,
                    selectedDate: new Date(g),
                    onSelect: function(e) {
                        const t = B(e, "from" === u ? i : a);
                        ({
                            from: () => {
                                var e;
                                l(t), null === (e = m.current) || void 0 === e || e.focus({
                                    preventScroll: !0
                                })
                            },
                            to: () => {
                                var e;
                                c(t), null === (e = h.current) || void 0 === e || e.focus({
                                    preventScroll: !0
                                })
                            }
                        })[u]()
                    },
                    onMonthSwitch: n,
                    highlightedFrom: new Date(i),
                    highlightedTo: new Date(a),
                    maxDate: "from" === u ? new Date(a) : void 0,
                    minDate: "to" === u ? new Date(i) : void 0
                }));

                function v(e, t, n) {
                    var r;
                    const [o, s] = e.split(":"), i = new Date;
                    i.setHours(Number(o)), i.setMinutes(Number(s));
                    n(W(i, t)), U || null === (r = h.current) || void 0 === r || r.focus({
                        preventScroll: !0
                    })
                }
            }
            var z = n(64730),
                j = n(30052),
                V = n(72535),
                H = n(26074);
            const U = V.mobiletouch,
                G = () => !0,
                Y = {
                    byId: {
                        Date: {
                            title: (0, m.t)("Date")
                        },
                        CustomRange: {
                            title: (0, m.t)("Custom range")
                        }
                    },
                    allIds: ["Date", "CustomRange"]
                };

            function K(e) {
                const {
                    dateOnly: t,
                    onClose: n,
                    onGoToDate: o,
                    onGoToRange: i
                } = e, a = (0, r.useRef)(null), [l, c] = (0, r.useState)(y().getValue("GoToDialog.activeTab", "Date")), [u, h] = (0, r.useState)(0), {
                    date: f,
                    isValid: g
                } = (0, s.ensureNotNull)((0, r.useContext)(d)), {
                    dateFrom: w,
                    dateTo: C,
                    isValid: D
                } = (0, s.ensureNotNull)((0, r.useContext)(p));
                return (0, r.useEffect)(() => (b.subscribe(E.CLOSE_POPUPS_AND_DIALOGS_COMMAND, N, null), () => {
                    b.unsubscribe(E.CLOSE_POPUPS_AND_DIALOGS_COMMAND, N, null)
                }), [n]), (0, r.useEffect)(() => {
                    null !== a.current && a.current()
                }, [u, l, f, w, C]), r.createElement(j.MatchMedia, {
                    rule: _.DialogBreakpoints.TabletSmall
                }, e => r.createElement(S.AdaptiveConfirmDialog, {
                    className: v()(H.dialogWrapper, e && H.dialogWrapperSmall),
                    title: (0, m.t)("Go to"),
                    dataName: "go-to-date-dialog",
                    render: O,
                    defaultActionOnClose: "cancel",
                    onClose: N,
                    onClickOutside: N,
                    onCancel: N,
                    onSubmit: x,
                    submitButtonDisabled: M(),
                    submitButtonText: (0, m.t)("Go to"),
                    forceCloseOnEsc: G,
                    shouldForceFocus: !1,
                    fullScreen: e,
                    isOpened: !0
                }));

                function O({
                    requestResize: e
                }) {
                    return a.current = e, r.createElement(r.Fragment, null, r.createElement("div", {
                        className: H.tabs
                    }, r.createElement(z.DialogTabs, {
                        activeTabId: l,
                        tabs: Y,
                        onSelect: T
                    })), r.createElement("div", {
                        className: v()(H.content, U && H.contentMobile)
                    }, r.createElement("div", {
                        className: H.bodyWrapper
                    }, r.createElement(q, {
                        onCalendarMonthSwitch: R,
                        onDateInputFocus: R,
                        activeTab: l,
                        dateOnly: t
                    }))))
                }

                function M() {
                    return {
                        CustomRange: !D,
                        Date: !g
                    }[l]
                }

                function x() {
                    switch (l) {
                        case "Date":
                            o(f);
                            break;
                        case "CustomRange":
                            i(w, C)
                    }
                }

                function N() {
                    n()
                }

                function T(e) {
                    c(e), y().setValue("GoToDialog.activeTab", e)
                }

                function R() {
                    h(u + 1)
                }
            }

            function q(e) {
                const {
                    activeTab: t,
                    dateOnly: n,
                    onCalendarMonthSwitch: o,
                    onDateInputFocus: s
                } = e;
                switch (t) {
                    case "Date":
                        return r.createElement(L, {
                            dateOnly: n,
                            onCalendarMonthSwitch: o
                        });
                    case "CustomRange":
                        return r.createElement(I, {
                            dateOnly: n,
                            onCalendarMonthSwitch: o,
                            onDateInputFocus: s
                        })
                }
            }

            function Q(e) {
                const {
                    dateOnly: t,
                    onClose: n,
                    onGoToDate: o,
                    onGoToRange: s,
                    initialGoToDate: i,
                    initialRanges: a
                } = e;
                return r.createElement(h, {
                    initialGoToDate: i
                }, r.createElement(f, {
                    initialRanges: a
                }, r.createElement(K, {
                    dateOnly: t,
                    onClose: n,
                    onGoToDate: o,
                    onGoToRange: s
                })))
            }
            var X = n(2117),
                $ = n(95935);
            const J = new class {
                constructor() {
                    this._hasError = !1
                }
                getItemOrDefault(e, t) {
                    return !sessionStorage || this._hasError ? t : sessionStorage.getItem(e)
                }
                setItem(e, t = "true") {
                    try {
                        sessionStorage.setItem(e, t), this._hasError = !1
                    } catch (e) {
                        this._hasError = !0
                    }
                }
            };
            var Z = n(86176);
            const ee = new l.DialogsOpenerManager;

            function te(e) {
                if (ee.isOpened("goTo")) return;
                if (!e.hasModel()) return;
                const t = e.model(),
                    n = document.createElement("div"),
                    s = r.createElement(Q, {
                        onClose: l,
                        dateOnly: t.model().mainSeries().isDWM(),
                        initialGoToDate: ne(),
                        initialRanges: re(e),
                        onGoToDate: e => {
                            ! function(e, t) {
                                J.setItem("goToDateTabLastPickedDate", String(t.valueOf()));
                                if (void 0 === e.model().timeScale().tickMarks().minIndex) return;
                                const n = (0, a.addLocalTime)(t).valueOf();
                                e.model().gotoTime(n).then(t => {
                                    const n = e.model().mainSeries();
                                    void 0 === t ? n.clearGotoDateResult() : n.setGotoDateResult(t)
                                })
                            }(t, e), l()
                        },
                        onGoToRange: (t, n) => {
                            ! function(e, t, n) {
                                const r = (0, Z.getTimezoneName)(e.model());
                                if (!r) return;
                                const o = i.linking.interval.value(),
                                    s = o && (0, X.normalizeIntervalString)(o),
                                    l = u().get_timezone(r),
                                    d = e => (0, c.cal_to_utc)(l, new Date(e)),
                                    h = (0, a.addLocalTime)(t).valueOf(),
                                    p = (0, a.addLocalTime)(n).valueOf(),
                                    f = {
                                        val: {
                                            type: "time-range",
                                            from: d(h) / 1e3,
                                            to: d(p) / 1e3
                                        },
                                        res: s
                                    };
                                e.chartWidgetCollection().setTimeFrame(f)
                            }(e, t, n), l()
                        }
                    });

                function l() {
                    o.unmountComponentAtNode(n), ee.setAsClosed("goTo")
                }
                o.render(s, n), ee.setAsOpened("goTo")
            }

            function ne() {
                const e = J.getItemOrDefault("goToDateTabLastPickedDate", null);
                return null === e ? (0, a.resetToDayStart)(new Date) : new Date(Number(e))
            }

            function re(e) {
                const t = function(e) {
                    const t = e.model().timeScale(),
                        n = t.visibleBarsStrictRange();
                    if (null === n) return;
                    const r = e.model().mainSeries(),
                        o = r.nearestIndex(n.firstBar(), $.PlotRowSearchMode.NearestRight),
                        i = r.nearestIndex(n.lastBar(), $.PlotRowSearchMode.NearestLeft);
                    if (void 0 === o || void 0 === i) return;
                    return {
                        from: (0, s.ensureNotNull)(t.indexToUserTime(o)),
                        to: (0, s.ensureNotNull)(t.indexToUserTime(i))
                    }
                }(e);
                return t ? {
                    from: (0, a.subtractLocalTime)(t.from),
                    to: (0, a.subtractLocalTime)(t.to)
                } : {
                    from: (0, a.subtractLocalTime)(new Date),
                    to: (0, a.subtractLocalTime)(new Date)
                }
            }
        },
        33054: (e, t, n) => {
            "use strict";
            n.d(t, {
                mediaQueryAddEventListener: () => r,
                mediaQueryRemoveEventListener: () => o
            });
            const r = (e, t) => {
                    (null == e ? void 0 : e.addEventListener) ? e.addEventListener("change", t): e.addListener(t)
                },
                o = (e, t) => {
                    (null == e ? void 0 : e.removeEventListener) ? e.removeEventListener("change", t): e.removeListener(t)
                }
        },
        21709: (e, t, n) => {
            "use strict";

            function r(e, t, n, r, o) {
                function s(o) {
                    if (e > o.timeStamp) return;
                    const s = o.target;
                    void 0 !== n && null !== t && null !== s && s.ownerDocument === r && (t.contains(s) || n(o))
                }
                return o.click && r.addEventListener("click", s, !1), o.mouseDown && r.addEventListener("mousedown", s, !1), o.touchEnd && r.addEventListener("touchend", s, !1), o.touchStart && r.addEventListener("touchstart", s, !1), () => {
                    r.removeEventListener("click", s, !1), r.removeEventListener("mousedown", s, !1), r.removeEventListener("touchend", s, !1), r.removeEventListener("touchstart", s, !1)
                }
            }
            n.d(t, {
                addOutsideEventListener: () => r
            })
        },
        85089: (e, t, n) => {
            "use strict";
            n.d(t, {
                setFixedBodyState: () => l
            });
            var r = n(35922);
            const o = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                s = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let i = 0,
                a = !1;

            function l(e) {
                const {
                    body: t
                } = document, n = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++i) {
                    const e = (0, r.getCSSProperty)(t, "overflow"),
                        o = (0, r.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, r.setStyle)(n, "right", (0, r.getScrollbarWidth)() + "px"), t.style.paddingRight = o + (0, r.getScrollbarWidth)() + "px", a = !0), t.classList.add("i-no-scroll")
                } else if (!e && i > 0 && 0 == --i && (t.classList.remove("i-no-scroll"), a)) {
                    (0, r.setStyle)(n, "right", "0px");
                    let e = 0;
                    e = n ? (l = (0, r.getContentWidth)(n), o() ? 0 : s() ? 46 : Math.min(Math.max(l, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, r.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", a = !1
                }
                var l
            }
        },
        76669: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                AdaptiveConfirmDialog: () => h
            });
            var r = n(59496),
                o = n(97754),
                s = n.n(o),
                i = n(28599),
                a = n(88537),
                l = n(25177),
                c = n(80185),
                u = n(53337),
                d = n(91131);
            class h extends r.PureComponent {
                constructor() {
                    super(...arguments), this._dialogRef = r.createRef(), this._handleClose = () => {
                        const {
                            defaultActionOnClose: e,
                            onSubmit: t,
                            onCancel: n,
                            onClose: r
                        } = this.props;
                        switch (e) {
                            case "submit":
                                t();
                                break;
                            case "cancel":
                                n()
                        }
                        r()
                    }, this._handleCancel = () => {
                        this.props.onCancel(), this.props.onClose()
                    }, this._handleKeyDown = e => {
                        const {
                            onSubmit: t,
                            submitButtonDisabled: n,
                            submitOnEnterKey: r
                        } = this.props;
                        13 === (0, c.hashFromEvent)(e) && r && (e.preventDefault(), n || t())
                    }
                }
                render() {
                    const {
                        render: e,
                        onClose: t,
                        onSubmit: n,
                        onCancel: o,
                        footerLeftRenderer: s,
                        submitButtonText: i,
                        submitButtonDisabled: a,
                        defaultActionOnClose: l,
                        submitOnEnterKey: c,
                        ...d
                    } = this.props;
                    return r.createElement(u.AdaptivePopupDialog, { ...d,
                        ref: this._dialogRef,
                        onKeyDown: this._handleKeyDown,
                        render: this._renderChildren(),
                        onClose: this._handleClose
                    })
                }
                focus() {
                    (0, a.ensureNotNull)(this._dialogRef.current).focus()
                }
                _renderChildren() {
                    return e => {
                        const {
                            render: t,
                            footerLeftRenderer: n,
                            additionalButtons: o,
                            submitButtonText: a,
                            submitButtonDisabled: c,
                            onSubmit: u,
                            cancelButtonText: h,
                            showCancelButton: p = !0,
                            submitButtonClassName: f,
                            cancelButtonClassName: m,
                            buttonsWrapperClassName: g
                        } = this.props;
                        return r.createElement(r.Fragment, null, t(e), r.createElement("div", {
                            className: d.footer
                        }, n && n(e.isSmallWidth), r.createElement("div", {
                            className: s()(d.buttons, g)
                        }, o, p && r.createElement(i.Button, {
                            className: m,
                            name: "cancel",
                            appearance: "stroke",
                            onClick: this._handleCancel
                        }, null != h ? h : (0, l.t)("Cancel")), r.createElement("span", {
                            className: d.submitButton
                        }, r.createElement(i.Button, {
                            className: f,
                            disabled: c,
                            name: "submit",
                            onClick: u,
                            "data-name": "submit-button"
                        }, null != a ? a : (0, l.t)("Ok"))))))
                    }
                }
            }
            h.defaultProps = {
                defaultActionOnClose: "submit",
                submitOnEnterKey: !0
            }
        },
        96038: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogBreakpoints: () => o
            });
            var r = n(96746);
            const o = {
                SmallHeight: r["small-height-breakpoint"],
                TabletSmall: r["tablet-small-breakpoint"],
                TabletNormal: r["tablet-normal-breakpoint"]
            }
        },
        53337: (e, t, n) => {
            "use strict";
            n.d(t, {
                AdaptivePopupDialog: () => D
            });
            var r = n(59496),
                o = n(88537),
                s = n(33054),
                i = n(97754),
                a = n.n(i),
                l = n(80185),
                c = n(98043),
                u = n(40766),
                d = n(94707),
                h = n(96038),
                p = n(30052),
                f = n(10549),
                m = n(6594),
                g = n(59410),
                v = n(72571),
                b = n(90410),
                w = n(35487),
                y = n(91441);

            function E(e) {
                const {
                    title: t,
                    subtitle: n,
                    showCloseIcon: o = !0,
                    onClose: s,
                    renderBefore: i,
                    renderAfter: l,
                    draggable: c,
                    className: u,
                    unsetAlign: d
                } = e, [h, p] = (0, r.useState)(!1);
                return r.createElement(b.DialogHeaderContext.Provider, {
                    value: {
                        setHideClose: p
                    }
                }, r.createElement("div", {
                    className: a()(y.container, u, (n || d) && y.unsetAlign)
                }, i, r.createElement("div", {
                    "data-dragg-area": c,
                    className: y.title
                }, r.createElement("div", {
                    className: y.ellipsis
                }, t), n && r.createElement("div", {
                    className: a()(y.ellipsis, y.subtitle)
                }, n)), l, o && !h && r.createElement(v.Icon, {
                    className: y.close,
                    icon: w,
                    onClick: s,
                    "data-name": "close",
                    "data-role": "button"
                })))
            }
            var _ = n(67179);
            const S = {
                    vertical: 20
                },
                C = {
                    vertical: 0
                };
            class D extends r.PureComponent {
                constructor() {
                    super(...arguments), this._controller = null, this._reference = null, this._orientationMediaQuery = null, this._renderChildren = (e, t) => (this._controller = e, this.props.render({
                        requestResize: this._requestResize,
                        centerAndFit: this._centerAndFit,
                        isSmallWidth: t
                    })), this._handleReference = e => this._reference = e, this._handleClose = () => {
                        this.props.onClose()
                    }, this._handleOpen = () => {
                        void 0 !== this.props.onOpen && this.props.isOpened && this.props.onOpen(this.props.fullScreen || window.matchMedia(h.DialogBreakpoints.TabletSmall).matches)
                    }, this._handleKeyDown = e => {
                        var t;
                        if (!e.defaultPrevented) switch (this.props.onKeyDown && this.props.onKeyDown(e), (0, l.hashFromEvent)(e)) {
                            case 27:
                                if (e.defaultPrevented) return;
                                if (this.props.forceCloseOnEsc && this.props.forceCloseOnEsc()) return void this._handleClose();
                                const {
                                    activeElement: n
                                } = document, r = (0, o.ensureNotNull)(this._reference);
                                if (null !== n) {
                                    if (e.preventDefault(), "true" === (t = n).getAttribute("data-haspopup") && "true" !== t.getAttribute("data-expanded")) return void this._handleClose();
                                    if ((0, c.isTextEditingField)(n)) return void r.focus();
                                    if (r.contains(n)) return void this._handleClose()
                                }
                        }
                    }, this._requestResize = () => {
                        null !== this._controller && this._controller.recalculateBounds()
                    }, this._centerAndFit = () => {
                        null !== this._controller && this._controller.centerAndFit()
                    }
                }
                componentDidMount() {
                    g.subscribe(m.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), this._handleOpen(), void 0 !== this.props.onOpen && (this._orientationMediaQuery = window.matchMedia("(orientation: portrait)"), (0, s.mediaQueryAddEventListener)(this._orientationMediaQuery, this._handleOpen))
                }
                componentWillUnmount() {
                    g.unsubscribe(m.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), null !== this._orientationMediaQuery && (0, s.mediaQueryRemoveEventListener)(this._orientationMediaQuery, this._handleOpen)
                }
                focus() {
                    (0, o.ensureNotNull)(this._reference).focus()
                }
                getElement() {
                    return this._reference
                }
                contains(e) {
                    var t, n;
                    return null !== (n = null === (t = this._reference) || void 0 === t ? void 0 : t.contains(e)) && void 0 !== n && n
                }
                render() {
                    const {
                        className: e,
                        wrapperClassName: t,
                        headerClassName: n,
                        isOpened: o,
                        title: s,
                        dataName: i,
                        onClickOutside: l,
                        additionalElementPos: c,
                        additionalHeaderElement: m,
                        backdrop: g,
                        shouldForceFocus: v = !0,
                        showSeparator: b,
                        subtitle: w,
                        draggable: y = !0,
                        fullScreen: D = !1,
                        showCloseIcon: O = !0,
                        rounded: M = !0,
                        isAnimationEnabled: x,
                        growPoint: N,
                        dialogTooltip: T,
                        unsetHeaderAlign: R,
                        onDragStart: A,
                        dataDialogName: k
                    } = this.props, P = "after" !== c ? m : void 0, F = "after" === c ? m : void 0, B = "string" == typeof s ? s : k || "";
                    return r.createElement(p.MatchMedia, {
                        rule: h.DialogBreakpoints.SmallHeight
                    }, c => r.createElement(p.MatchMedia, {
                        rule: h.DialogBreakpoints.TabletSmall
                    }, h => r.createElement(u.PopupDialog, {
                        rounded: !(h || D) && M,
                        className: a()(_.dialog, e),
                        isOpened: o,
                        reference: this._handleReference,
                        onKeyDown: this._handleKeyDown,
                        onClickOutside: l,
                        onClickBackdrop: l,
                        fullscreen: h || D,
                        guard: c ? C : S,
                        boundByScreen: h || D,
                        shouldForceFocus: v,
                        backdrop: g,
                        draggable: y,
                        isAnimationEnabled: x,
                        growPoint: N,
                        name: this.props.dataName,
                        dialogTooltip: T,
                        onDragStart: A
                    }, r.createElement("div", {
                        className: a()(_.wrapper, t),
                        "data-name": i,
                        "data-dialog-name": B
                    }, void 0 !== s && r.createElement(E, {
                        draggable: y && !(h || D),
                        onClose: this._handleClose,
                        renderAfter: F,
                        renderBefore: P,
                        subtitle: w,
                        title: s,
                        showCloseIcon: O,
                        className: n,
                        unsetAlign: R
                    }), b && r.createElement(d.Separator, {
                        className: _.separator
                    }), r.createElement(f.PopupContext.Consumer, null, e => this._renderChildren(e, h || D))))))
                }
            }
        },
        90410: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogHeaderContext: () => r
            });
            const r = n(59496).createContext({
                setHideClose: () => {}
            })
        },
        86176: (e, t, n) => {
            "use strict";
            n.d(t, {
                getTimezoneName: () => r
            });
            n(93540);

            function r(e) {
                const t = e.model().timezone();
                if ("exchange" !== t) return t;
                const n = e.model().mainSeries().symbolInfo();
                return null == n ? void 0 : n.timezone
            }
        },
        63192: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogsOpenerManager: () => r,
                dialogsOpenerManager: () => o
            });
            class r {
                constructor() {
                    this._storage = new Map
                }
                setAsOpened(e, t) {
                    this._storage.set(e, t)
                }
                setAsClosed(e) {
                    this._storage.delete(e)
                }
                isOpened(e) {
                    return this._storage.has(e)
                }
                getDialogPayload(e) {
                    return this._storage.get(e)
                }
            }
            const o = new r
        },
        79184: (e, t, n) => {
            "use strict";
            n.d(t, {
                anchors: () => o,
                makeAnchorable: () => s
            });
            var r = n(59496);
            const o = {
                bottom: {
                    attachment: {
                        horizontal: "left",
                        vertical: "top"
                    },
                    targetAttachment: {
                        horizontal: "left",
                        vertical: "bottom"
                    }
                },
                top: {
                    attachment: {
                        horizontal: "left",
                        vertical: "bottom"
                    },
                    targetAttachment: {
                        horizontal: "left",
                        vertical: "top"
                    }
                },
                topRight: {
                    attachment: {
                        horizontal: "right",
                        vertical: "bottom"
                    },
                    targetAttachment: {
                        horizontal: "right",
                        vertical: "top"
                    }
                },
                bottomRight: {
                    attachment: {
                        horizontal: "right",
                        vertical: "top"
                    },
                    targetAttachment: {
                        horizontal: "right",
                        vertical: "bottom"
                    }
                }
            };

            function s(e) {
                var t;
                return (t = class extends r.PureComponent {
                    render() {
                        const {
                            anchor: t = "bottom"
                        } = this.props;
                        return r.createElement(e, { ...this.props,
                            attachment: o[t].attachment,
                            targetAttachment: o[t].targetAttachment
                        })
                    }
                }).displayName = "Anchorable Component", t
            }
        },
        41037: (e, t, n) => {
            "use strict";
            n.d(t, {
                makeAttachable: () => s
            });
            var r = n(59496),
                o = n(87995);

            function s(e) {
                var t;
                return (t = class extends r.PureComponent {
                    constructor(e) {
                        super(e), this._getComponentInstance = e => {
                            this._instance = e
                        }, this._throttleCalcProps = () => {
                            requestAnimationFrame(() => this.setState(this._calcProps(this.props)))
                        }, this.state = this._getStateFromProps()
                    }
                    componentDidMount() {
                        this._instanceElem = o.findDOMNode(this._instance), this.props.attachOnce || this._subscribe(), this.setState(this._calcProps(this.props))
                    }
                    componentDidUpdate(e) {
                        e.children === this.props.children && e.top === this.props.top && e.left === this.props.left && e.width === this.props.width || this.setState(this._getStateFromProps(), () => this.setState(this._calcProps(this.props)))
                    }
                    render() {
                        return r.createElement("div", {
                            style: {
                                position: "absolute",
                                width: "100%",
                                top: 0,
                                left: 0
                            }
                        }, r.createElement(e, {
                            ...this.props,
                            ref: this._getComponentInstance,
                            top: this.state.top,
                            bottom: void 0 !== this.state.bottom ? this.state.bottom : "auto",
                            right: void 0 !== this.state.right ? this.state.right : "auto",
                            left: this.state.left,
                            width: this.state.width,
                            maxWidth: this.state.maxWidth
                        }, this.props.children))
                    }
                    componentWillUnmount() {
                        this._unsubsribe()
                    }
                    _getStateFromProps() {
                        return {
                            bottom: this.props.bottom,
                            left: this.props.left,
                            right: this.props.right,
                            top: void 0 !== this.props.top ? this.props.top : -1e4,
                            width: this.props.inheritWidthFromTarget ? this.props.target && this.props.target.getBoundingClientRect().width : this.props.width,
                            maxWidth: this.props.inheritMaxWidthFromTarget && this.props.target && this.props.target.getBoundingClientRect().width
                        }
                    }
                    _calcProps(e) {
                        if (e.target && e.attachment && e.targetAttachment) {
                            const t = this._calcTargetProps(e.target, e.attachment, e.targetAttachment);
                            if (null === t) return {};
                            const {
                                width: n,
                                inheritWidthFromTarget: r = !0,
                                inheritMaxWidthFromTarget: o = !1
                            } = this.props, s = {
                                width: r ? t.width : n,
                                maxWidth: o ? t.width : void 0
                            };
                            switch (e.attachment.vertical) {
                                case "bottom":
                                case "middle":
                                    s.top = t.y;
                                    break;
                                default:
                                    s[e.attachment.vertical] = t.y
                            }
                            switch (e.attachment.horizontal) {
                                case "right":
                                case "center":
                                    s.left = t.x;
                                    break;
                                default:
                                    s[e.attachment.horizontal] = t.x
                            }
                            return s
                        }
                        return {}
                    }
                    _calcTargetProps(e, t, n) {
                        const r = e.getBoundingClientRect(),
                            o = this._instanceElem.getBoundingClientRect(),
                            s = "parent" === this.props.root ? this._getCoordsRelToParentEl(e, r) : this._getCoordsRelToDocument(r);
                        if (null === s) return null;
                        const i = this._getDimensions(o),
                            a = this._getDimensions(r).width;
                        let l = 0,
                            c = 0;
                        switch (t.vertical) {
                            case "top":
                                c = s[n.vertical];
                                break;
                            case "bottom":
                                c = s[n.vertical] - i.height;
                                break;
                            case "middle":
                                c = s[n.vertical] - i.height / 2
                        }
                        switch (t.horizontal) {
                            case "left":
                                l = s[n.horizontal];
                                break;
                            case "right":
                                l = s[n.horizontal] - i.width;
                                break;
                            case "center":
                                l = s[n.horizontal] - i.width / 2
                        }
                        return "number" == typeof this.props.attachmentOffsetY && (c += this.props.attachmentOffsetY), "number" == typeof this.props.attachmentOffsetX && (l += this.props.attachmentOffsetX), {
                            x: l,
                            y: c,
                            width: a
                        }
                    }
                    _getCoordsRelToDocument(e) {
                        const t = pageYOffset,
                            n = pageXOffset,
                            r = e.top + t,
                            o = e.bottom + t,
                            s = e.left + n;
                        return {
                            top: r,
                            bottom: o,
                            left: s,
                            right: e.right + n,
                            middle: (r + e.height) / 2,
                            center: s + e.width / 2
                        }
                    }
                    _getCoordsRelToParentEl(e, t) {
                        const n = e.offsetParent;
                        if (null === n) return null;
                        const r = n.scrollTop,
                            o = n.scrollLeft,
                            s = e.offsetTop + r,
                            i = e.offsetLeft + o,
                            a = t.width + i;
                        return {
                            top: s,
                            bottom: t.height + s,
                            left: i,
                            right: a,
                            middle: (s + t.height) / 2,
                            center: (i + t.width) / 2
                        }
                    }
                    _getDimensions(e) {
                        return {
                            height: e.height,
                            width: e.width
                        }
                    }
                    _subscribe() {
                        "document" === this.props.root && (window.addEventListener("scroll", this._throttleCalcProps, !0), window.addEventListener("resize", this._throttleCalcProps))
                    }
                    _unsubsribe() {
                        window.removeEventListener("scroll", this._throttleCalcProps, !0), window.removeEventListener("resize", this._throttleCalcProps)
                    }
                }).displayName = "Attachable Component", t
            }
        },
        64730: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogTabs: () => f
            });
            var r = n(59496),
                o = n(97754),
                s = n(68766),
                i = n(93173),
                a = n(47922);
            const l = (0, i.mergeThemes)(s.DEFAULT_SLIDER_THEME, a);
            var c = n(86746),
                u = n(72535),
                d = n(42545);
            const h = d,
                p = (0, s.factory)((function(e) {
                    return r.createElement("div", {
                        className: l.slider,
                        ref: e.reference
                    }, r.createElement("div", {
                        className: l.inner
                    }))
                }));
            class f extends r.PureComponent {
                constructor() {
                    super(...arguments), this._createClickHandler = e => () => {
                        this.props.onSelect(e)
                    }
                }
                render() {
                    const {
                        theme: e = h,
                        hiddenBottomBorders: t,
                        fadedSlider: n = !0,
                        ScrollComponent: s = c.HorizontalScroll
                    } = this.props, i = this._generateDialogTabs();
                    return r.createElement("div", {
                        className: o(e.scrollWrap)
                    }, !t && r.createElement("div", {
                        className: e.headerBottomSeparator
                    }), r.createElement(s, {
                        isVisibleFade: u.mobiletouch,
                        isVisibleButtons: !u.mobiletouch,
                        isVisibleScrollbar: !1,
                        fadeClassName: o({
                            [e.fadeWithoutSlider]: !n
                        })
                    }, r.createElement("div", {
                        className: e.tabsWrap
                    }, r.createElement(p, {
                        className: o(e.tabs, t && e.withoutBorder)
                    }, i))))
                }
                _generateDialogTabs() {
                    const {
                        activeTabId: e,
                        tabs: t,
                        theme: n = h
                    } = this.props;
                    return t.allIds.map(i => {
                        const a = e === i,
                            l = t.byId[i].withNotificationsBadge;
                        return r.createElement(s.SliderItem, {
                            key: i,
                            value: i,
                            className: o(n.tab, !a && n.withHover, l && d.withBadge),
                            isActive: a,
                            onClick: this._createClickHandler(i)
                        }, t.byId[i].title)
                    })
                }
            }
        },
        21258: (e, t, n) => {
            "use strict";
            n.d(t, {
                hoverMouseEventFilter: () => s,
                useAccurateHover: () => i,
                useHover: () => o
            });
            var r = n(59496);

            function o() {
                const [e, t] = (0, r.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        s(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        s(e) && t(!1)
                    }
                }]
            }

            function s(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function i(e) {
                const [t, n] = (0, r.useState)(!1);
                return (0, r.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const r = e.current.contains(t.target);
                        n(r)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        61174: (e, t, n) => {
            "use strict";
            n.d(t, {
                useOutsideEvent: () => s
            });
            var r = n(59496),
                o = n(21709);

            function s(e) {
                const {
                    click: t,
                    mouseDown: n,
                    touchEnd: s,
                    touchStart: i,
                    handler: a,
                    reference: l,
                    ownerDocument: c = document
                } = e, u = (0, r.useRef)(null), d = (0, r.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, r.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: n,
                            touchEnd: s,
                            touchStart: i
                        },
                        r = l ? l.current : u.current;
                    return (0, o.addOutsideEventListener)(d.current, r, a, c, e)
                }, [t, n, s, i, a]), l || u
            }
        },
        86746: (e, t, n) => {
            "use strict";
            n.d(t, {
                HorizontalScroll: () => w
            });
            var r = n(59496),
                o = n(97754),
                s = n(7270),
                i = n(88537),
                a = n(72571),
                l = n(42609),
                c = n(85787),
                u = n(34581),
                d = n(86219),
                h = n(41814);
            const p = {
                isVisibleScrollbar: !0,
                shouldMeasure: !0,
                hideButtonsFrom: 1
            };

            function f(e) {
                return r.createElement("div", {
                    className: o(h.fadeLeft, e.className, {
                        [h.isVisible]: e.isVisible
                    })
                })
            }

            function m(e) {
                return r.createElement("div", {
                    className: o(h.fadeRight, e.className, {
                        [h.isVisible]: e.isVisible
                    })
                })
            }

            function g(e) {
                return r.createElement(b, { ...e,
                    className: h.scrollLeft
                })
            }

            function v(e) {
                return r.createElement(b, { ...e,
                    className: h.scrollRight
                })
            }

            function b(e) {
                return r.createElement("div", {
                    className: o(e.className, {
                        [h.isVisible]: e.isVisible
                    }),
                    onClick: e.onClick
                }, r.createElement("div", {
                    className: h.iconWrap
                }, r.createElement(a.Icon, {
                    icon: d,
                    className: h.icon
                })))
            }
            const w = function(e = g, t = v, n = f, a = m) {
                var d;
                return (d = class extends r.PureComponent {
                    constructor(e) {
                        super(e), this._scroll = r.createRef(),
                            this._wrapMeasureRef = r.createRef(), this._contentMeasureRef = r.createRef(), this._handleScrollLeft = () => {
                                if (this.props.onScrollButtonClick) return void this.props.onScrollButtonClick("left");
                                const e = this.props.scrollStepSize || this.state.widthWrap - 50;
                                this.animateTo(Math.max(0, this.currentPosition() - e))
                            }, this._handleScrollRight = () => {
                                if (this.props.onScrollButtonClick) return void this.props.onScrollButtonClick("right");
                                const e = this.props.scrollStepSize || this.state.widthWrap - 50;
                                this.animateTo(Math.min((this.state.widthContent || 0) - (this.state.widthWrap || 0), this.currentPosition() + e))
                            }, this._handleResizeWrap = e => {
                                this.props.onMeasureWrap && this.props.onMeasureWrap(e), this.setState({
                                    widthWrap: e.width
                                }), this._checkButtonsVisibility()
                            }, this._handleResizeContent = e => {
                                this.props.onMeasureContent && this.props.onMeasureContent(e);
                                const {
                                    shouldDecreaseWidthContent: t,
                                    buttonsWidthIfDecreasedWidthContent: n
                                } = this.props;
                                t && n ? this.setState({
                                    widthContent: e.width + 2 * n
                                }) : this.setState({
                                    widthContent: e.width
                                })
                            }, this._handleScroll = () => {
                                const {
                                    onScroll: e
                                } = this.props;
                                e && e(this.currentPosition(), this.isAtLeft(), this.isAtRight()), this._checkButtonsVisibility()
                            }, this._checkButtonsVisibility = () => {
                                const {
                                    isVisibleLeftButton: e,
                                    isVisibleRightButton: t
                                } = this.state, n = this.isAtLeft(), r = this.isAtRight();
                                n || e ? n && e && this.setState({
                                    isVisibleLeftButton: !1
                                }) : this.setState({
                                    isVisibleLeftButton: !0
                                }), r || t ? r && t && this.setState({
                                    isVisibleRightButton: !1
                                }) : this.setState({
                                    isVisibleRightButton: !0
                                })
                            }, this.state = {
                                widthContent: 0,
                                widthWrap: 0,
                                isVisibleRightButton: !1,
                                isVisibleLeftButton: !1
                            }
                    }
                    componentDidMount() {
                        this._checkButtonsVisibility()
                    }
                    componentDidUpdate(e, t) {
                        t.widthWrap === this.state.widthWrap && t.widthContent === this.state.widthContent || this._handleScroll(), this.props.shouldMeasure && this._wrapMeasureRef.current && this._contentMeasureRef.current && (this._wrapMeasureRef.current.measure(), this._contentMeasureRef.current.measure())
                    }
                    currentPosition() {
                        return this._scroll.current ? (0, u.isRtl)() ? (0, u.getLTRScrollLeft)(this._scroll.current) : this._scroll.current.scrollLeft : 0
                    }
                    isAtLeft() {
                        return !this._isOverflowed() || this.currentPosition() <= (0, i.ensureDefined)(this.props.hideButtonsFrom)
                    }
                    isAtRight() {
                        return !this._isOverflowed() || this.currentPosition() + this.state.widthWrap >= this.state.widthContent - (0, i.ensureDefined)(this.props.hideButtonsFrom)
                    }
                    animateTo(e, t = c.dur) {
                        const n = this._scroll.current;
                        n && ((0, u.isRtl)() && (e = (0, u.getLTRScrollLeftOffset)(n, e)), t <= 0 ? n.scrollLeft = Math.round(e) : (0, l.doAnimate)({
                            onStep(e, t) {
                                n.scrollLeft = Math.round(t)
                            },
                            from: n.scrollLeft,
                            to: Math.round(e),
                            easing: c.easingFunc.easeInOutCubic,
                            duration: t
                        }))
                    }
                    render() {
                        const {
                            children: i,
                            isVisibleScrollbar: l,
                            isVisibleFade: c,
                            isVisibleButtons: u,
                            shouldMeasure: d,
                            shouldDecreaseWidthContent: p,
                            buttonsWidthIfDecreasedWidthContent: f,
                            onMouseOver: m,
                            onMouseOut: g,
                            scrollWrapClassName: v,
                            fadeClassName: b
                        } = this.props, {
                            isVisibleRightButton: w,
                            isVisibleLeftButton: y
                        } = this.state, E = p && f;
                        return r.createElement(s, {
                            whitelist: ["width"],
                            onMeasure: this._handleResizeWrap,
                            shouldMeasure: d,
                            ref: this._wrapMeasureRef
                        }, r.createElement("div", {
                            className: h.wrapOverflow,
                            onMouseOver: m,
                            onMouseOut: g
                        }, r.createElement("div", {
                            className: o(h.wrap, E ? h.wrapWithArrowsOuting : "")
                        }, r.createElement("div", {
                            className: o(h.scrollWrap, v, {
                                [h.noScrollBar]: !l
                            }),
                            onScroll: this._handleScroll,
                            ref: this._scroll
                        }, r.createElement(s, {
                            onMeasure: this._handleResizeContent,
                            whitelist: ["width"],
                            shouldMeasure: d,
                            ref: this._contentMeasureRef
                        }, i)), c && r.createElement(n, {
                            isVisible: y,
                            className: b
                        }), c && r.createElement(a, {
                            isVisible: w,
                            className: b
                        }), u && r.createElement(e, {
                            onClick: this._handleScrollLeft,
                            isVisible: y
                        }), u && r.createElement(t, {
                            onClick: this._handleScrollRight,
                            isVisible: w
                        }))))
                    }
                    _isOverflowed() {
                        const {
                            widthContent: e,
                            widthWrap: t
                        } = this.state;
                        return e > t
                    }
                }).defaultProps = p, d
            }(g, v, f, m)
        },
        81476: (e, t, n) => {
            "use strict";
            n.d(t, {
                FormInput: () => c
            });
            var r = n(59496),
                o = n(54936),
                s = n(61428),
                i = n(2691),
                a = n(69842),
                l = n(28606);

            function c(e) {
                var t;
                const {
                    intent: n,
                    onFocus: c,
                    onBlur: u,
                    onMouseOver: d,
                    onMouseOut: h,
                    containerReference: p = null,
                    endSlot: f,
                    hasErrors: m,
                    hasWarnings: g,
                    errors: v,
                    warnings: b,
                    alwaysShowAttachedErrors: w,
                    iconHidden: y,
                    messagesPosition: E,
                    messagesAttachment: _,
                    customErrorsAttachment: S,
                    messagesRoot: C,
                    inheritMessagesWidthFromTarget: D,
                    disableMessagesRtlStyles: O,
                    ...M
                } = e, x = (0, s.useControlValidationLayout)({
                    hasErrors: m,
                    hasWarnings: g,
                    errors: v,
                    warnings: b,
                    alwaysShowAttachedErrors: w,
                    iconHidden: y,
                    messagesPosition: E,
                    messagesAttachment: _,
                    customErrorsAttachment: S,
                    messagesRoot: C,
                    inheritMessagesWidthFromTarget: D,
                    disableMessagesRtlStyles: O
                }), N = (0, a.createSafeMulticastEventHandler)(c, x.onFocus), T = (0, a.createSafeMulticastEventHandler)(u, x.onBlur), R = (0, a.createSafeMulticastEventHandler)(d, x.onMouseOver), A = (0, a.createSafeMulticastEventHandler)(h, x.onMouseOut);
                return r.createElement(r.Fragment, null, r.createElement(o.InputControl, { ...M,
                    intent: null !== (t = x.intent) && void 0 !== t ? t : n,
                    onFocus: N,
                    onBlur: T,
                    onMouseOver: R,
                    onMouseOut: A,
                    containerReference: (0, l.useMergedRefs)([p, x.containerReference]),
                    endSlot: r.createElement(r.Fragment, null, x.icon && r.createElement(i.EndSlot, {
                        icon: !0
                    }, x.icon), f)
                }), x.renderedErrors)
            }
        },
        61428: (e, t, n) => {
            "use strict";
            n.d(t, {
                MessagesPosition: () => w,
                useControlValidationLayout: () => x
            });
            var r = n(59496),
                o = n(97754),
                s = n(83836),
                i = n(21258),
                a = n(2691),
                l = n(79184),
                c = n(74485),
                u = n(41037),
                d = n(66875),
                h = n(34581);
            class p extends r.PureComponent {
                render() {
                    const {
                        children: e = [],
                        show: t = !1,
                        customErrorClass: n,
                        disableRtlStyles: s
                    } = this.props, i = o(d.errors, {
                        [d.show]: t
                    }, n), a = e.map((e, t) => r.createElement("div", {
                        className: d.error,
                        key: t
                    }, e));
                    let l = {
                        position: "absolute",
                        top: this.props.top,
                        width: this.props.width,
                        height: this.props.height,
                        bottom: void 0 !== this.props.bottom ? this.props.bottom : "100%",
                        right: void 0 !== this.props.right ? this.props.right : 0,
                        left: this.props.left,
                        zIndex: this.props.zIndex,
                        maxWidth: this.props.maxWidth
                    };
                    if ((0, h.isRtl)() && !s) {
                        const {
                            left: e,
                            right: t
                        } = l;
                        l = { ...l,
                            left: t,
                            right: e
                        }
                    }
                    return r.createElement("div", {
                        style: l,
                        className: i
                    }, a)
                }
            }
            const f = (0, c.makeOverlapable)((0, u.makeAttachable)(p));
            var m = n(72571),
                g = n(7295),
                v = n(93314);

            function b(e) {
                const {
                    intent: t = "danger"
                } = e;
                return r.createElement(m.Icon, {
                    icon: g,
                    className: o(v["error-icon"], v["intent-" + t])
                })
            }
            var w, y, E = n(52965);
            ! function(e) {
                e[e.Attached = 0] = "Attached",
                    e[e.Static = 1] = "Static", e[e.Hidden = 2] = "Hidden"
            }(w || (w = {})),
            function(e) {
                e.Top = "top", e.Bottom = "bottom"
            }(y || (y = {}));
            const _ = {
                top: {
                    attachment: l.anchors.topRight.attachment,
                    targetAttachment: l.anchors.topRight.targetAttachment,
                    attachmentOffsetY: -4
                },
                bottom: {
                    attachment: l.anchors.bottomRight.attachment,
                    targetAttachment: l.anchors.bottomRight.targetAttachment,
                    attachmentOffsetY: 4
                }
            };

            function S(e) {
                const {
                    isOpened: t,
                    target: n,
                    errorAttachment: o = y.Top,
                    customErrorsAttachment: s,
                    root: i = "parent",
                    inheritWidthFromTarget: a = !1,
                    disableRtlStyles: l,
                    children: c
                } = e, {
                    attachment: u,
                    targetAttachment: d,
                    attachmentOffsetY: h
                } = null != s ? s : _[o];
                return r.createElement(f, {
                    isOpened: t,
                    target: n,
                    root: i,
                    inheritWidthFromTarget: a,
                    attachment: u,
                    targetAttachment: d,
                    attachmentOffsetY: h,
                    disableRtlStyles: l,
                    inheritMaxWidthFromTarget: !0,
                    show: !0
                }, c)
            }

            function C(e, t) {
                return Boolean(e) && void 0 !== t && t.length > 0
            }

            function D(e, t, n) {
                return e === w.Attached && C(t, n)
            }

            function O(e, t, n) {
                return e === w.Static && C(t, n)
            }

            function M(e, t, n) {
                const {
                    hasErrors: r,
                    hasWarnings: o,
                    alwaysShowAttachedErrors: s,
                    iconHidden: i,
                    errors: a,
                    warnings: l,
                    messagesPosition: c = w.Static
                } = e, u = D(c, r, a), d = D(c, o, l), h = u && (t || n || Boolean(s)), p = !h && d && (t || n), f = O(c, r, a), m = !f && O(c, o, l), g = !i && Boolean(r);
                return {
                    hasAttachedErrorMessages: u,
                    hasAttachedWarningMessages: d,
                    showAttachedErrorMessages: h,
                    showAttachedWarningMessages: p,
                    showStaticErrorMessages: f,
                    showStaticWarningMessages: m,
                    showErrorIcon: g,
                    showWarningIcon: !i && !g && Boolean(o),
                    intent: function(e, t) {
                        return Boolean(e) ? "danger" : Boolean(t) ? "warning" : void 0
                    }(r, o)
                }
            }

            function x(e) {
                var t, n;
                const {
                    errors: l,
                    warnings: c,
                    messagesAttachment: u,
                    customErrorsAttachment: d,
                    messagesRoot: h,
                    inheritMessagesWidthFromTarget: p,
                    disableMessagesRtlStyles: f
                } = e, [m, g] = (0, s.useFocus)(), [v, w] = (0, i.useHover)(), y = (0, r.useRef)(null), {
                    hasAttachedErrorMessages: _,
                    hasAttachedWarningMessages: C,
                    showAttachedErrorMessages: D,
                    showAttachedWarningMessages: O,
                    showStaticErrorMessages: x,
                    showStaticWarningMessages: N,
                    showErrorIcon: T,
                    showWarningIcon: R,
                    intent: A
                } = M(e, m, v), k = T || R ? r.createElement(b, {
                    intent: T ? "danger" : "warning"
                }) : void 0, P = _ ? r.createElement(S, {
                    errorAttachment: u,
                    customErrorsAttachment: d,
                    isOpened: D,
                    target: y.current,
                    root: h,
                    inheritWidthFromTarget: p,
                    disableRtlStyles: f,
                    children: l
                }) : void 0, F = C ? r.createElement(S, {
                    errorAttachment: u,
                    isOpened: O,
                    target: y.current,
                    root: h,
                    inheritWidthFromTarget: p,
                    disableRtlStyles: f,
                    children: c
                }) : void 0, B = x ? r.createElement(a.AfterSlot, {
                    className: o(E["static-messages"], E.errors)
                }, null == l ? void 0 : l.map((e, t) => r.createElement("p", {
                    key: t,
                    className: E.message
                }, e))) : void 0, W = N ? r.createElement(a.AfterSlot, {
                    className: o(E["static-messages"], E.warnings)
                }, null == c ? void 0 : c.map((e, t) => r.createElement("p", {
                    key: t,
                    className: E.message
                }, e))) : void 0;
                return {
                    icon: k,
                    renderedErrors: null !== (n = null !== (t = null != P ? P : F) && void 0 !== t ? t : B) && void 0 !== n ? n : W,
                    containerReference: y,
                    intent: A,
                    ...g,
                    ...w
                }
            }
        },
        30052: (e, t, n) => {
            "use strict";
            n.d(t, {
                MatchMedia: () => o
            });
            var r = n(59496);
            class o extends r.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        94707: (e, t, n) => {
            "use strict";
            n.d(t, {
                Separator: () => i
            });
            var r = n(59496),
                o = n(97754),
                s = n(91626);

            function i(e) {
                return r.createElement("div", {
                    className: o(s.separator, e.className)
                })
            }
        },
        63212: (e, t, n) => {
            "use strict";
            n.d(t, {
                OverlapManager: () => s,
                getRootOverlapManager: () => a
            });
            var r = n(88537);
            class o {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class s {
                constructor(e = document) {
                    this._storage = new o, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        n = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, n), this._container = n
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const n = this._windows.get(e);
                    if (void 0 !== n) return n;
                    this.registerWindow(e);
                    const r = this._document.createElement("div");
                    if (r.style.position = t.position, r.style.zIndex = this._index.toString(), r.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(r);
                        else if (t.index <= 0) this._container.insertBefore(r, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(r, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(r, this._container.firstChild) : this._container.appendChild(r);
                    return this._windows.set(e, r), ++this._index, r
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const i = new WeakMap;

            function a(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, r.ensureDefined)(i.get(t)); {
                    const t = new s(e),
                        n = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return i.set(n, t), t.setContainer(n), e.body.appendChild(n), t
                }
            }
        },
        8361: (e, t, n) => {
            "use strict";
            n.d(t, {
                Portal: () => l,
                PortalContext: () => c
            });
            var r = n(59496),
                o = n(87995),
                s = n(16345),
                i = n(63212),
                a = n(53327);
            class l extends r.PureComponent {
                constructor() {
                    super(...arguments),
                        this._uuid = (0, s.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", o.createPortal(r.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, i.getRootOverlapManager)() : this.context
                }
            }
            l.contextType = a.SlotContext;
            const c = r.createContext(null)
        },
        53327: (e, t, n) => {
            "use strict";
            n.d(t, {
                Slot: () => o,
                SlotContext: () => s
            });
            var r = n(59496);
            class o extends r.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return r.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const s = r.createContext(null)
        },
        68766: (e, t, n) => {
            "use strict";
            n.d(t, {
                DEFAULT_SLIDER_THEME: () => a,
                SliderItem: () => l,
                factory: () => c,
                SliderRow: () => u
            });
            var r = n(59496),
                o = n(97754),
                s = n(88537),
                i = n(37740);
            const a = i;

            function l(e) {
                const t = o(e.className, i.tab, {
                    [i.active]: e.isActive,
                    [i.disabled]: e.isDisabled,
                    [i.defaultCursor]: !!e.shouldUseDefaultCursor,
                    [i.noBorder]: !!e.noBorder
                });
                return r.createElement("div", {
                    className: t,
                    onClick: e.onClick,
                    ref: e.reference,
                    "data-type": "tab-item",
                    "data-value": e.value,
                    "data-name": "tab-item-" + e.value.toString().toLowerCase()
                }, e.children)
            }

            function c(e) {
                return class extends r.PureComponent {
                    constructor() {
                        super(...arguments), this.activeTab = {
                            current: null
                        }
                    }
                    componentDidUpdate() {
                        (0, s.ensureNotNull)(this._slider).style.transition = "transform 350ms", this._componentDidUpdate()
                    }
                    componentDidMount() {
                        this._componentDidUpdate()
                    }
                    render() {
                        const {
                            className: t
                        } = this.props, n = this._generateTabs();
                        return r.createElement("div", {
                            className: o(t, i.tabs),
                            "data-name": this.props["data-name"]
                        }, n, r.createElement(e, {
                            reference: e => {
                                this._slider = e
                            }
                        }))
                    }
                    _generateTabs() {
                        return this.activeTab.current = null, r.Children.map(this.props.children, e => {
                            const t = e,
                                n = Boolean(t.props.isActive),
                                o = {
                                    reference: e => {
                                        n && (this.activeTab.current = e), t.props.reference && t.props.reference(e)
                                    }
                                };
                            return r.cloneElement(t, o)
                        })
                    }
                    _componentDidUpdate() {
                        const e = (0, s.ensureNotNull)(this._slider).style;
                        if (this.activeTab.current) {
                            const t = this.activeTab.current.offsetWidth,
                                n = this.activeTab.current.offsetLeft;
                            e.transform = `translateX(${n}px)`, e.width = t + "px", e.opacity = "1"
                        } else e.opacity = "0"
                    }
                }
            }
            const u = c((function(e) {
                return r.createElement("div", {
                    className: i.slider,
                    ref: e.reference
                })
            }))
        },
        86219: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 10" width="20" height="10"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 1l8 8 8-8"/></svg>'
        },
        35487: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        7295: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="16" height="16" fill="none"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M8 15c3.866 0 7-3.134 7-7s-3.134-7-7-7-7 3.134-7 7 3.134 7 7 7zm0 1c4.418 0 8-3.582 8-8s-3.582-8-8-8-8 3.582-8 8 3.582 8 8 8zm-1-12c0-.552.448-1 1-1s1 .448 1 1v4c0 .552-.448 1-1 1s-1-.448-1-1v-4zm1 7c-.552 0-1 .448-1 1s.448 1 1 1 1-.448 1-1-.448-1-1-1z"/></svg>'
        }
    }
]);
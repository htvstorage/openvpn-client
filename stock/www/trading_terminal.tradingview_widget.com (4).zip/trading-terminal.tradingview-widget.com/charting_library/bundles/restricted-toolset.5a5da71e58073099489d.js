(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [5516, 3718], {
        62092: e => {
            e.exports = {
                loader: "loader-MuZZSHRY",
                static: "static-MuZZSHRY",
                item: "item-MuZZSHRY",
                "tv-button-loader": "tv-button-loader-MuZZSHRY",
                medium: "medium-MuZZSHRY",
                small: "small-MuZZSHRY",
                black: "black-MuZZSHRY",
                white: "white-MuZZSHRY",
                gray: "gray-MuZZSHRY",
                primary: "primary-MuZZSHRY",
                "loader-initial": "loader-initial-MuZZSHRY",
                "loader-appear": "loader-appear-MuZZSHRY"
            }
        },
        54627: e => {
            e.exports = {
                switcher: "switcher-GT7Z98Io",
                "disable-cursor-pointer": "disable-cursor-pointer-GT7Z98Io",
                input: "input-GT7Z98Io",
                "thumb-wrapper": "thumb-wrapper-GT7Z98Io",
                "size-small": "size-small-GT7Z98Io",
                "size-large": "size-large-GT7Z98Io",
                "intent-default": "intent-default-GT7Z98Io",
                "disable-active-state-styles": "disable-active-state-styles-GT7Z98Io",
                "intent-select": "intent-select-GT7Z98Io",
                track: "track-GT7Z98Io",
                thumb: "thumb-GT7Z98Io"
            }
        },
        50789: e => {
            e.exports = {
                summary: "summary-hk3Mmxts",
                hovered: "hovered-hk3Mmxts",
                caret: "caret-hk3Mmxts"
            }
        },
        28857: e => {
            e.exports = {
                wrapper: "wrapper-OGmb0GMo",
                labelRow: "labelRow-OGmb0GMo",
                label: "label-OGmb0GMo",
                labelHint: "labelHint-OGmb0GMo",
                labelOn: "labelOn-OGmb0GMo"
            }
        },
        95707: e => {
            e.exports = {
                wrapper: "wrapper-IbP2mmCe",
                hovered: "hovered-IbP2mmCe",
                labelRow: "labelRow-IbP2mmCe",
                label: "label-IbP2mmCe",
                labelHint: "labelHint-IbP2mmCe",
                labelOn: "labelOn-IbP2mmCe"
            }
        },
        44923: e => {
            e.exports = {
                title: "title-YjHzjBKe"
            }
        },
        55576: e => {
            e.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        39592: e => {
            e.exports = {
                button: "button-Rsu8YfBx",
                withText: "withText-Rsu8YfBx",
                withoutText: "withoutText-Rsu8YfBx"
            }
        },
        64547: e => {
            e.exports = {
                button: "button-SS83RYhy"
            }
        },
        69698: e => {
            e.exports = {
                form: "form-obOlo718",
                interacting: "interacting-obOlo718",
                input: "input-obOlo718",
                menu: "menu-obOlo718",
                add: "add-obOlo718",
                hovered: "hovered-obOlo718",
                hover: "hover-obOlo718",
                wrap: "wrap-obOlo718"
            }
        },
        59174: e => {
            e.exports = {
                spinnerWrap: "spinnerWrap-OjdCXkZp"
            }
        },
        78966: e => {
            e.exports = {
                title: "title-mAu74Mtg"
            }
        },
        71123: e => {
            e.exports = {
                button: "button-khcLBZEz",
                hover: "hover-khcLBZEz",
                arrow: "arrow-khcLBZEz",
                arrowWrap: "arrowWrap-khcLBZEz",
                newStyles: "newStyles-khcLBZEz",
                isOpened: "isOpened-khcLBZEz"
            }
        },
        936: e => {
            e.exports = {
                button: "button-2Vex9IkU",
                first: "first-2Vex9IkU",
                last: "last-2Vex9IkU"
            }
        },
        82832: e => {
            e.exports = {
                wrap: "wrap-H6XRnLaC"
            }
        },
        91887: e => {
            e.exports = {
                hidden: "hidden-vHZuIWsw"
            }
        },
        75492: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-AFYo6gMo",
                withIcon: "withIcon-AFYo6gMo",
                shortcut: "shortcut-AFYo6gMo",
                loading: "loading-AFYo6gMo",
                icon: "icon-AFYo6gMo"
            }
        },
        19450: e => {
            e.exports = {
                button: "button-OSzyNVEZ",
                menu: "menu-OSzyNVEZ"
            }
        },
        33191: e => {
            e.exports = {
                customTradingViewStyleButton: "customTradingViewStyleButton-fjLcMxZj",
                withoutIcon: "withoutIcon-fjLcMxZj"
            }
        },
        64142: e => {
            e.exports = {
                dropdown: "dropdown-E3UQYoRD",
                label: "label-E3UQYoRD",
                smallWidthTitle: "smallWidthTitle-E3UQYoRD",
                smallWidthMenuItem: "smallWidthMenuItem-E3UQYoRD",
                smallWidthWrapper: "smallWidthWrapper-E3UQYoRD"
            }
        },
        87906: e => {
            e.exports = {
                value: "value-e0RYyFXU",
                selected: "selected-e0RYyFXU"
            }
        },
        32062: e => {
            e.exports = {
                smallWidthMenuItem: "smallWidthMenuItem-xvK6HzAF"
            }
        },
        6500: e => {
            e.exports = {
                button: "button-cXbh8Gcw",
                first: "first-cXbh8Gcw",
                last: "last-cXbh8Gcw",
                newStyles: "newStyles-cXbh8Gcw",
                menu: "menu-cXbh8Gcw",
                dropdown: "dropdown-cXbh8Gcw",
                menuContent: "menuContent-cXbh8Gcw",
                section: "section-cXbh8Gcw",
                smallTabletSectionTitle: "smallTabletSectionTitle-cXbh8Gcw",
                addCustomInterval: "addCustomInterval-cXbh8Gcw",
                hovered: "hovered-cXbh8Gcw"
            }
        },
        85693: e => {
            e.exports = {
                row: "row-zv2K45bH",
                rowInner: "rowInner-zv2K45bH",
                smallRow: "smallRow-zv2K45bH",
                rowLabel: "rowLabel-zv2K45bH",
                smallRowLabel: "smallRowLabel-zv2K45bH",
                rowButtons: "rowButtons-zv2K45bH",
                layoutButtonWrap: "layoutButtonWrap-zv2K45bH",
                smallWidth: "smallWidth-zv2K45bH",
                layoutButton: "layoutButton-zv2K45bH",
                hovered: "hovered-zv2K45bH",
                isActive: "isActive-zv2K45bH",
                smallWidthLayoutButton: "smallWidthLayoutButton-zv2K45bH",
                layoutButtons: "layoutButtons-zv2K45bH"
            }
        },
        5146: e => {
            e.exports = {
                toggler: "toggler-OnqkH3TM",
                hovered: "hovered-OnqkH3TM",
                label: "label-OnqkH3TM",
                centered: "centered-OnqkH3TM",
                checked: "checked-OnqkH3TM"
            }
        },
        56241: e => {
            e.exports = {
                button: "button-TurqB9KU",
                dropdown: "dropdown-TurqB9KU",
                layoutType: "layoutType-TurqB9KU",
                title: "title-TurqB9KU",
                tabletTitle: "tabletTitle-TurqB9KU",
                syncCharts: "syncCharts-TurqB9KU",
                tabletWrapper: "tabletWrapper-TurqB9KU",
                icon: "icon-TurqB9KU",
                syncTable: "syncTable-TurqB9KU",
                syncListWrapper: "syncListWrapper-TurqB9KU"
            }
        },
        76521: e => {
            e.exports = {
                button: "button-CiwmljCL"
            }
        },
        4050: e => {
            e.exports = {
                button: "button-mEQw2hrh",
                isDisabled: "isDisabled-mEQw2hrh",
                text: "text-mEQw2hrh"
            }
        },
        96141: e => {
            e.exports = {
                opened: "opened-SUlSleuH",
                hover: "hover-SUlSleuH",
                autoSaveWrapper: "autoSaveWrapper-SUlSleuH",
                sharingWrapper: "sharingWrapper-SUlSleuH",
                button: "button-SUlSleuH",
                buttonSmallPadding: "buttonSmallPadding-SUlSleuH",
                hintPlaceHolder: "hintPlaceHolder-SUlSleuH",
                smallHintPlaceHolder: "smallHintPlaceHolder-SUlSleuH",
                popupItemRowTabletSmall: "popupItemRowTabletSmall-SUlSleuH",
                shortcut: "shortcut-SUlSleuH"
            }
        },
        72597: e => {
            e.exports = {
                button: "button-TTaQ4aBF",
                text: "text-TTaQ4aBF",
                logo: "logo-TTaQ4aBF"
            }
        },
        67397: e => {
            e.exports = {
                button: "button-IQnsk0hp",
                largeLeftPadding: "largeLeftPadding-IQnsk0hp",
                text: "text-IQnsk0hp",
                uppercase: "uppercase-IQnsk0hp"
            }
        },
        75668: e => {
            e.exports = {
                description: "description-Q7biiIOG"
            }
        },
        52157: e => {
            e.exports = {
                item: "item-UfrwNtjY",
                round: "round-UfrwNtjY"
            }
        },
        41939: e => {
            e.exports = {
                wrap: "wrap-hoa11YwL",
                titleWrap: "titleWrap-hoa11YwL",
                indicators: "indicators-hoa11YwL",
                title: "title-hoa11YwL",
                icon: "icon-hoa11YwL",
                text: "text-hoa11YwL",
                titleTabletSmall: "titleTabletSmall-hoa11YwL",
                labelRow: "labelRow-hoa11YwL",
                label: "label-hoa11YwL"
            }
        },
        14621: e => {
            e.exports = {
                labelRow: "labelRow-qyt9pxdb",
                toolbox: "toolbox-qyt9pxdb",
                description: "description-qyt9pxdb",
                descriptionTabletSmall: "descriptionTabletSmall-qyt9pxdb",
                item: "item-qyt9pxdb",
                titleItem: "titleItem-qyt9pxdb",
                titleItemTabletSmall: "titleItemTabletSmall-qyt9pxdb",
                itemTabletSmall: "itemTabletSmall-qyt9pxdb",
                itemLabelTabletSmall: "itemLabelTabletSmall-qyt9pxdb",
                wrap: "wrap-qyt9pxdb",
                hovered: "hovered-qyt9pxdb"
            }
        },
        89227: e => {
            e.exports = {
                menu: "menu-Pi7orIC5",
                menuSmallTablet: "menuSmallTablet-Pi7orIC5",
                menuItemHeaderTabletSmall: "menuItemHeaderTabletSmall-Pi7orIC5",
                menuItemHeader: "menuItemHeader-Pi7orIC5"
            }
        },
        73887: e => {
            e.exports = {
                wrap: "wrap-mbKoosX4",
                full: "full-mbKoosX4",
                first: "first-mbKoosX4",
                last: "last-mbKoosX4",
                medium: "medium-mbKoosX4",
                buttonWithFavorites: "buttonWithFavorites-mbKoosX4"
            }
        },
        82559: e => {
            e.exports = {
                icon: "icon-0KfEd2LW"
            }
        },
        4039: e => {
            e.exports = {
                buttonUndo: "buttonUndo-6VeYguKu",
                buttonRedo: "buttonRedo-6VeYguKu"
            }
        },
        96746: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        72142: e => {
            e.exports = {
                footer: "footer-C0oTZgbU"
            }
        },
        49473: e => {
            e.exports = {
                dottedCloud: "dottedCloud-NezC5dyJ",
                check: "check-NezC5dyJ",
                spinningCloud: "spinningCloud-NezC5dyJ",
                arrow: "arrow-NezC5dyJ",
                arrowGap: "arrowGap-NezC5dyJ",
                container: "container-NezC5dyJ",
                unsaved: "unsaved-NezC5dyJ",
                hovered: "hovered-NezC5dyJ",
                saving: "saving-NezC5dyJ",
                saved: "saved-NezC5dyJ"
            }
        },
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        16842: e => {
            e.exports = {
                favorite: "favorite-JVQQsDQk",
                disabled: "disabled-JVQQsDQk",
                active: "active-JVQQsDQk",
                checked: "checked-JVQQsDQk"
            }
        },
        63095: e => {
            e.exports = {
                item: "item-UZNJ2Dq5",
                label: "label-UZNJ2Dq5",
                labelRow: "labelRow-UZNJ2Dq5",
                toolbox: "toolbox-UZNJ2Dq5"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        524: e => {
            e.exports = {
                separator: "separator-GzmeVcFo",
                small: "small-GzmeVcFo",
                normal: "normal-GzmeVcFo",
                large: "large-GzmeVcFo"
            }
        },
        40367: e => {
            e.exports = {
                icon: "icon-AL2odtws",
                dropped: "dropped-AL2odtws"
            }
        },
        52130: (e, t, a) => {
            "use strict";
            a.d(t, {
                useIsMounted: () => s
            });
            var n = a(59496);
            const s = () => {
                const e = (0, n.useRef)(!1);
                return (0, n.useEffect)(() => (e.current = !0, () => {
                    e.current = !1
                }), []), e
            }
        },
        34404: (e, t, a) => {
            "use strict";
            a.d(t, {
                Loader: () => h
            });
            var n, s = a(59496),
                o = a(97754),
                i = a(49423),
                r = a(62092),
                l = a.n(r);
            ! function(e) {
                e[e.Initial = 0] = "Initial", e[e.Appear = 1] = "Appear", e[e.Active = 2] = "Active"
            }(n || (n = {}));
            class h extends s.PureComponent {
                constructor(e) {
                    super(e), this._stateChangeTimeout = null, this.state = {
                        state: n.Initial
                    }
                }
                render() {
                    const {
                        className: e,
                        color: t = "black",
                        size: a = "medium",
                        staticPosition: n
                    } = this.props, i = o(l().item, l()[t], l()[a]);
                    return s.createElement("span", {
                        className: o(l().loader, n && l().static, this._getStateClass(), e)
                    }, s.createElement("span", {
                        className: i
                    }), s.createElement("span", {
                        className: i
                    }), s.createElement("span", {
                        className: i
                    }))
                }
                componentDidMount() {
                    this.setState({
                        state: n.Appear
                    }), this._stateChangeTimeout = setTimeout(() => {
                        this.setState({
                            state: n.Active
                        })
                    }, 2 * i.dur)
                }
                componentWillUnmount() {
                    this._stateChangeTimeout && (clearTimeout(this._stateChangeTimeout), this._stateChangeTimeout = null)
                }
                _getStateClass() {
                    switch (this.state.state) {
                        case n.Initial:
                            return l()["loader-initial"];
                        case n.Appear:
                            return l()["loader-appear"];
                        default:
                            return ""
                    }
                }
            }
        },
        417: (e, t, a) => {
            "use strict";

            function n(e) {
                return o(e, i)
            }

            function s(e) {
                return o(e, r)
            }

            function o(e, t) {
                const a = Object.entries(e).filter(t),
                    n = {};
                for (const [e, t] of a) n[e] = t;
                return n
            }

            function i(e) {
                const [t, a] = e;
                return 0 === t.indexOf("data-") && "string" == typeof a
            }

            function r(e) {
                return 0 === e[0].indexOf("aria-")
            }
            a.d(t, {
                filterDataProps: () => n,
                filterAriaProps: () => s,
                filterProps: () => o,
                isDataAttribute: () => i,
                isAriaAttribute: () => r
            })
        },
        32943: (e, t, a) => {
            "use strict";
            a.d(t, {
                CollapsibleSection: () => l
            });
            var n = a(59496),
                s = a(97754),
                o = a.n(s),
                i = a(15783),
                r = a(50789);

            function l(e) {
                return n.createElement(n.Fragment, null, n.createElement("div", {
                    className: o()(e.className, r.summary),
                    onClick: function() {
                        e.onStateChange && e.onStateChange(!e.open)
                    },
                    "data-open": e.open
                }, e.summary, n.createElement(i.ToolWidgetCaret, {
                    className: r.caret,
                    dropped: Boolean(e.open)
                })), e.open && e.children)
            }
        },
        45545: (e, t, a) => {
            "use strict";
            a.d(t, {
                DEFAULT_MENU_ITEM_SWITCHER_THEME: () => m,
                MenuItemSwitcher: () => p
            });
            var n = a(59496),
                s = a(97754),
                o = a.n(s);
            const i = (0, n.createContext)({
                enablePointerOnHover: !0,
                enableActiveStateStyles: !0
            });
            var r = a(54627),
                l = a.n(r);

            function h(e) {
                const t = (0, n.useContext)(i),
                    {
                        className: a,
                        intent: o = "default",
                        size: r = "small",
                        enablePointerOnHover: h = t.enablePointerOnHover,
                        enableActiveStateStyles: c = t.enableActiveStateStyles
                    } = e;
                return s(a, l().switcher, l()["size-" + r], l()["intent-" + o], !h && l()["disable-cursor-pointer"], !c && l()["disable-active-state-styles"])
            }

            function c(e) {
                const {
                    reference: t,
                    size: a,
                    intent: s,
                    ...o
                } = e;
                return n.createElement("div", {
                    className: h(e)
                }, n.createElement("input", { ...o,
                    type: "checkbox",
                    className: l().input,
                    ref: t
                }), n.createElement("div", {
                    className: l()["thumb-wrapper"]
                }, n.createElement("div", {
                    className: l().track
                }), n.createElement("div", {
                    className: l().thumb
                })))
            }
            var d = a(417),
                u = a(95707);
            const m = u;

            function p(e) {
                const {
                    className: t,
                    checked: a,
                    id: s,
                    label: i,
                    labelDescription: r,
                    value: l,
                    preventLabelHighlight: h,
                    reference: m,
                    switchReference: p,
                    theme: v = u,
                    disabled: g
                } = e, w = o()(v.label, a && !h && v.labelOn), b = o()(t, v.wrapper, a && v.wrapperWithOnLabel);
                return n.createElement("label", {
                    className: b,
                    htmlFor: s,
                    ref: m
                }, n.createElement("div", {
                    className: v.labelRow
                }, n.createElement("div", {
                    className: w
                }, i), r && n.createElement("div", {
                    className: v.labelHint
                }, r)), n.createElement(c, {
                    disabled: g,
                    className: v.switch,
                    reference: p,
                    checked: a,
                    onChange: function(t) {
                        const a = t.target.checked;
                        void 0 !== e.onChange && e.onChange(a)
                    },
                    value: l,
                    tabIndex: -1,
                    id: s,
                    ...(0, d.filterDataProps)(e)
                }))
            }
        },
        85673: (e, t, a) => {
            "use strict";
            a.d(t, {
                VerticalAttachEdge: () => n,
                HorizontalAttachEdge: () => s,
                VerticalDropDirection: () => o,
                HorizontalDropDirection: () => i,
                getPopupPositioner: () => h
            });
            var n, s, o, i, r = a(88537);
            ! function(e) {
                e[e.Top = 0] = "Top", e[e.Bottom = 1] = "Bottom"
            }(n || (n = {})),
            function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(s || (s = {})),
            function(e) {
                e[e.FromTopToBottom = 0] = "FromTopToBottom", e[e.FromBottomToTop = 1] = "FromBottomToTop"
            }(o || (o = {})),
            function(e) {
                e[e.FromLeftToRight = 0] = "FromLeftToRight", e[e.FromRightToLeft = 1] = "FromRightToLeft"
            }(i || (i = {}));
            const l = {
                verticalAttachEdge: n.Bottom,
                horizontalAttachEdge: s.Left,
                verticalDropDirection: o.FromTopToBottom,
                horizontalDropDirection: i.FromLeftToRight,
                verticalMargin: 0,
                horizontalMargin: 0,
                matchButtonAndListboxWidths: !1
            };

            function h(e, t) {
                return (a, h) => {
                    const c = (0, r.ensureNotNull)(e).getBoundingClientRect(),
                        {
                            verticalAttachEdge: d = l.verticalAttachEdge,
                            verticalDropDirection: u = l.verticalDropDirection,
                            horizontalAttachEdge: m = l.horizontalAttachEdge,
                            horizontalDropDirection: p = l.horizontalDropDirection,
                            horizontalMargin: v = l.horizontalMargin,
                            verticalMargin: g = l.verticalMargin,
                            matchButtonAndListboxWidths: w = l.matchButtonAndListboxWidths
                        } = t,
                        b = d === n.Top ? -1 * g : g,
                        C = m === s.Right ? c.right : c.left,
                        S = d === n.Top ? c.top : c.bottom,
                        y = {
                            x: C - (p === i.FromRightToLeft ? a : 0) + v,
                            y: S - (u === o.FromBottomToTop ? h : 0) + b
                        };
                    return w && (y.overrideWidth = c.width), y
                }
            }
        },
        75803: (e, t, a) => {
            "use strict";
            a.d(t, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => l,
                ToolWidgetButton: () => h
            });
            var n = a(59496),
                s = a(97754),
                o = a(72571),
                i = a(4257),
                r = a(55576);
            const l = r,
                h = n.forwardRef((e, t) => {
                    const {
                        icon: a,
                        isActive: l,
                        isOpened: h,
                        isDisabled: c,
                        isGrouped: d,
                        isHovered: u,
                        onClick: m,
                        text: p,
                        textBeforeIcon: v,
                        title: g,
                        theme: w = r,
                        className: b,
                        forceInteractive: C,
                        "data-name": S,
                        ...y
                    } = e, f = s(b, w.button, g && "apply-common-tooltip", {
                        [w.isActive]: l,
                        [w.isOpened]: h,
                        [w.isInteractive]: (C || Boolean(m)) && !c,
                        [w.isDisabled]: c,
                        [w.isGrouped]: d,
                        [w.hover]: u,
                        [w.newStyles]: i.hasNewHeaderToolbarStyles
                    }), _ = a && ("string" == typeof a ? n.createElement(o.Icon, {
                        className: w.icon,
                        icon: a
                    }) : n.cloneElement(a, {
                        className: s(w.icon, a.props.className)
                    }));
                    return n.createElement("div", { ...y,
                        ref: t,
                        "data-role": "button",
                        className: f,
                        onClick: c ? void 0 : m,
                        title: g,
                        "data-name": S
                    }, v && p && n.createElement("div", {
                        className: s("js-button-text", w.text)
                    }, p), _, !v && p && n.createElement("div", {
                        className: s("js-button-text", w.text)
                    }, p))
                })
        },
        5710: (e, t, a) => {
            "use strict";
            a.d(t, {
                ToolWidgetIconButton: () => r
            });
            var n = a(59496),
                s = a(97754),
                o = a(75803),
                i = a(64547);
            const r = n.forwardRef((e, t) => {
                const {
                    className: a,
                    id: r,
                    ...l
                } = e;
                return n.createElement(o.ToolWidgetButton, {
                    "data-name": r,
                    ...l,
                    ref: t,
                    className: s(a, i.button)
                })
            })
        },
        21714: (e, t, a) => {
            "use strict";
            a.d(t, {
                INTERVALS: () => s
            });
            var n = a(25177);
            const s = [{
                name: "",
                label: (0, n.t)("minutes", {
                    context: "interval"
                })
            }, {
                name: "H",
                label: (0, n.t)("hours", {
                    context: "interval"
                })
            }, {
                name: "D",
                label: (0, n.t)("days", {
                    context: "interval"
                })
            }, {
                name: "W",
                label: (0, n.t)("weeks", {
                    context: "interval"
                })
            }, {
                name: "M",
                label: (0, n.t)("months", {
                    context: "interval"
                })
            }]
        },
        21638: (e, t, a) => {
            "use strict";
            a.d(t, {
                ToolWidgetMenuSpinner: () => l
            });
            var n = a(59496),
                s = a(97754),
                o = a.n(s),
                i = a(34404),
                r = a(59174);

            function l(e) {
                const {
                    className: t
                } = e;
                return n.createElement("div", {
                    className: o()(r.spinnerWrap, t)
                }, n.createElement(i.Loader, null))
            }
        },
        46369: (e, t, a) => {
            "use strict";
            a.d(t, {
                ToolWidgetMenuSummary: () => i
            });
            var n = a(59496),
                s = a(97754),
                o = a(78966);

            function i(e) {
                return n.createElement("div", {
                    className: s(e.className, o.title)
                }, e.children)
            }
        },
        34816: (e, t, a) => {
            "use strict";
            a.d(t, {
                DEFAULT_TOOL_WIDGET_MENU_THEME: () => p,
                ToolWidgetMenu: () => v
            });
            var n = a(59496),
                s = a(97754),
                o = a(44377),
                i = a(15783),
                r = a(417),
                l = a(63694),
                h = a(59339),
                c = a(85673),
                d = a(30052),
                u = a(4257),
                m = a(71123);
            const p = m;
            class v extends n.PureComponent {
                constructor(e) {
                    super(e), this._wrapperRef = null, this._controller = n.createRef(), this._handleWrapperRef = e => {
                        this._wrapperRef = e, this.props.reference && this.props.reference(e)
                    }, this._handleClick = e => {
                        e.target instanceof Node && e.currentTarget.contains(e.target) && (this._handleToggleDropdown(), this.props.onClick && this.props.onClick(e, !this.state.isOpened))
                    }, this._handleToggleDropdown = e => {
                        const {
                            onClose: t,
                            onOpen: a
                        } = this.props, {
                            isOpened: n
                        } = this.state, s = "boolean" == typeof e ? e : !n;
                        this.setState({
                            isOpened: s
                        }), s && a && a(), !s && t && t()
                    }, this._handleClose = () => {
                        this.close()
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        arrow: t,
                        content: a,
                        isDisabled: o,
                        isDrawer: l,
                        isShowTooltip: h,
                        title: c,
                        className: m,
                        hotKey: p,
                        theme: v,
                        drawerBreakpoint: g
                    } = this.props, {
                        isOpened: w
                    } = this.state, b = s(m, v.button, {
                        "apply-common-tooltip": h || !o,
                        [v.isDisabled]: o,
                        [v.isOpened]: w,
                        [v.newStyles]: u.hasNewHeaderToolbarStyles
                    });
                    return n.createElement("div", {
                        id: e,
                        className: b,
                        onClick: o ? void 0 : this._handleClick,
                        title: c,
                        "data-tooltip-hotkey": p,
                        ref: this._handleWrapperRef,
                        "data-role": "button",
                        ...(0, r.filterDataProps)(this.props)
                    }, a, t && n.createElement("div", {
                        className: v.arrow
                    }, n.createElement("div", {
                        className: v.arrowWrap
                    }, n.createElement(i.ToolWidgetCaret, {
                        dropped: w
                    }))), this.state.isOpened && (g ? n.createElement(d.MatchMedia, {
                        rule: g
                    }, e => this._renderContent(e)) : this._renderContent(l)))
                }
                close() {
                    this._handleToggleDropdown(!1)
                }
                update() {
                    null !== this._controller.current && this._controller.current.update()
                }
                _renderContent(e) {
                    const {
                        menuDataName: t,
                        minWidth: a,
                        menuClassName: s,
                        maxHeight: i,
                        drawerPosition: r = "Bottom",
                        children: d
                    } = this.props, {
                        isOpened: u
                    } = this.state, m = {
                        horizontalMargin: this.props.horizontalMargin || 0,
                        verticalMargin: this.props.verticalMargin || 2,
                        verticalAttachEdge: this.props.verticalAttachEdge,
                        horizontalAttachEdge: this.props.horizontalAttachEdge,
                        verticalDropDirection: this.props.verticalDropDirection,
                        horizontalDropDirection: this.props.horizontalDropDirection,
                        matchButtonAndListboxWidths: this.props.matchButtonAndListboxWidths
                    }, p = Boolean(u && e && r), v = function(e) {
                        return "function" == typeof e
                    }(d) ? d({
                        isDrawer: p
                    }) : d;
                    return p ? n.createElement(l.DrawerManager, null, n.createElement(h.Drawer, {
                        onClose: this._handleClose,
                        position: r,
                        "data-name": t
                    }, v)) : n.createElement(o.PopupMenu, {
                        controller: this._controller,
                        closeOnClickOutside: this.props.closeOnClickOutside,
                        doNotCloseOn: this,
                        isOpened: u,
                        minWidth: a,
                        onClose: this._handleClose,
                        position: (0, c.getPopupPositioner)(this._wrapperRef, m),
                        className: s,
                        maxHeight: i,
                        "data-name": t
                    }, v)
                }
            }
            v.defaultProps = {
                arrow: !0,
                closeOnClickOutside: !0,
                theme: m
            }
        },
        47937: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                getRestrictedToolSet: () => _n
            });
            var n = a(82527),
                s = a(59496),
                o = a(19036),
                i = a(25177),
                r = a(88401),
                l = a(42148),
                h = a(93790),
                c = a(77687),
                d = a(72571),
                u = a(92063),
                m = a(34816),
                p = a(97754),
                v = a.n(p),
                g = a(82832);
            class w extends s.PureComponent {
                render() {
                    const {
                        children: e,
                        className: t,
                        ...a
                    } = this.props;
                    return s.createElement("div", {
                        className: p(t, g.wrap),
                        ...a
                    }, e)
                }
            }
            var b = a(75803),
                C = a(417),
                S = a(936);
            class y extends s.PureComponent {
                constructor() {
                    super(...arguments), this._handleClick = () => {
                        const {
                            onClick: e,
                            onClickArg: t
                        } = this.props;
                        e && e(t)
                    }
                }
                render() {
                    const {
                        isFirst: e,
                        isLast: t,
                        hint: a,
                        text: n,
                        icon: o,
                        isActive: i,
                        isDisabled: r,
                        className: l
                    } = this.props, h = (0, C.filterDataProps)(this.props);
                    return s.createElement(b.ToolWidgetButton, { ...h,
                        icon: o,
                        text: n,
                        title: a,
                        isDisabled: r,
                        isActive: i,
                        isGrouped: !0,
                        onClick: this._handleClick,
                        className: p(l, S.button, {
                            [S.first]: e,
                            [S.last]: t
                        })
                    })
                }
            }
            var f = a(17850),
                _ = a(30052),
                k = a(96038),
                M = a(14417),
                x = a(23404),
                E = a(45491),
                T = a(19450);
            const I = {
                0: (0, i.t)("Bars"),
                1: (0, i.t)("Candles"),
                9: (0, i.t)("Hollow candles"),
                13: (0, i.t)("Columns"),
                8: (0, i.t)("Heikin Ashi"),
                2: (0, i.t)("Line"),
                3: (0, i.t)("Area"),
                10: (0, i.t)("Baseline"),
                12: (0, i.t)("High-low")
            };
            I[4] = (0, i.t)("Renko"), I[7] = (0, i.t)("Line break"), I[5] = (0, i.t)("Kagi"), I[6] = (0, i.t)("Point & figure");
            const N = {
                    barsStyle: (0, i.t)("Bar's style"),
                    labels: I
                },
                A = (0, x.registryContextType)();

            function H(e) {
                var t;
                return !(null === (t = r.linking.supportedChartStyles.value()) || void 0 === t ? void 0 : t.includes(e))
            }
            class R extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleChangeStyle = e => {
                        const {
                            favorites: t,
                            lastSelectedNotFavorite: a,
                            activeStyle: n
                        } = this.state;
                        this.setState({
                            activeStyle: e,
                            lastSelectedNotFavorite: t.includes(n) ? a : n
                        })
                    }, this._handleSelectStyle = e => {
                        const {
                            chartWidgetCollection: t
                        } = this.context;
                        e !== t.activeChartStyle.value() && t.setChartStyleToWidget(e)
                    }, this._handleClickFavorite = e => {
                        this._isStyleFavorited(e) ? this._handleRemoveFavorite(e) : this._handleAddFavorite(e)
                    }, this._boundForceUpdate = () => {
                        this.forceUpdate()
                    }, this._handleQuickClick = e => {
                        this._handleSelectStyle(e), this._trackClick()
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired,
                        favoriteChartStylesService: o.any.isRequired
                    });
                    const {
                        chartWidgetCollection: a,
                        favoriteChartStylesService: n
                    } = t, s = a.activeChartStyle.value(), i = n.get(), r = (0, E.japaneseChartStyles)();
                    this.state = {
                        activeStyle: s,
                        favorites: i,
                        styles: (0, E.commonChartStyles)(),
                        japaneseStyles: r
                    }
                }
                componentDidMount() {
                    const {
                        chartWidgetCollection: e,
                        favoriteChartStylesService: t
                    } = this.context;
                    e.activeChartStyle.subscribe(this._handleChangeStyle), t.getOnChange().subscribe(this, this._handleChangeSettings), r.linking.supportedChartStyles.subscribe(this._boundForceUpdate)
                }
                componentWillUnmount() {
                    const {
                        chartWidgetCollection: e,
                        favoriteChartStylesService: t
                    } = this.context;
                    e.activeChartStyle.unsubscribe(this._handleChangeStyle), t.getOnChange().unsubscribe(this, this._handleChangeSettings), r.linking.supportedChartStyles.unsubscribe(this._boundForceUpdate)
                }
                render() {
                    const {
                        isShownQuicks: e,
                        displayMode: t = "full",
                        id: a
                    } = this.props, {
                        activeStyle: n,
                        favorites: o,
                        styles: i,
                        japaneseStyles: r,
                        lastSelectedNotFavorite: c
                    } = this.state, u = "small" !== t && e && 0 !== o.length, p = [...o];
                    p.includes(n) ? void 0 !== c && p.push(c) : p.push(n);
                    const v = u && p.length > 1;
                    return s.createElement(_.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, e => {
                        const t = i.map(t => this._renderPopupMenuItem(t, t === n, e)),
                            o = r.map(t => this._renderPopupMenuItem(t, t === n, e));
                        return s.createElement(w, {
                            id: a
                        }, v && p.map((e, t) => s.createElement(y, {
                            className: T.button,
                            icon: h.SERIES_ICONS[e],
                            isActive: u && n === e,
                            isDisabled: H(e),
                            key: t,
                            hint: N.labels[e],
                            isFirst: 0 === t,
                            isLast: t === p.length - 1,
                            onClick: u ? this._handleQuickClick : void 0,
                            onClickArg: e,
                            "data-value": l.STYLE_SHORT_NAMES[e]
                        })), s.createElement(m.ToolWidgetMenu, {
                            arrow: Boolean(v),
                            content: v ? void 0 : s.createElement(w, null, s.createElement(d.Icon, {
                                icon: h.SERIES_ICONS[n]
                            })),
                            title: v ? N.barsStyle : N.labels[n],
                            className: T.menu,
                            isDrawer: e,
                            onClick: this._trackClick
                        }, t, !!o.length && s.createElement(f.PopupMenuSeparator, null), o))
                    })
                }
                _renderPopupMenuItem(e, t, a) {
                    const {
                        isFavoritingAllowed: n
                    } = this.props, o = this._isStyleFavorited(e);
                    return s.createElement(u.PopupMenuItem, {
                        key: e,
                        theme: a ? M.multilineLabelWithIconAndToolboxTheme : void 0,
                        icon: h.SERIES_ICONS[e],
                        isActive: t,
                        isDisabled: H(e),
                        label: N.labels[e] || "",
                        onClick: this._handleSelectStyle,
                        onClickArg: e,
                        showToolboxOnHover: !o,
                        toolbox: n && s.createElement(c.FavoriteButton, {
                            isActive: t,
                            isFilled: o,
                            onClick: () => this._handleClickFavorite(e)
                        }),
                        "data-value": l.STYLE_SHORT_NAMES[e]
                    })
                }
                _handleChangeSettings(e) {
                    this.setState({
                        lastSelectedNotFavorite: void 0,
                        favorites: e
                    })
                }
                _isStyleFavorited(e) {
                    return -1 !== this.state.favorites.indexOf(e)
                }
                _handleAddFavorite(e) {
                    const {
                        favorites: t
                    } = this.state, {
                        favoriteChartStylesService: a
                    } = this.context;
                    a.set([...t, e])
                }
                _handleRemoveFavorite(e) {
                    const {
                        favorites: t
                    } = this.state, {
                        favoriteChartStylesService: a
                    } = this.context;
                    a.set(t.filter(t => t !== e))
                }
                _trackClick() {
                    0
                }
            }
            R.contextType = A;
            var z = a(39592);
            const L = ["medium", "small"];

            function D(e) {
                const {
                    text: t,
                    className: a,
                    displayMode: n,
                    collapseWhen: o = L,
                    ...i
                } = e, r = !o.includes(n);
                return s.createElement(b.ToolWidgetButton, { ...i,
                    text: r ? t : void 0,
                    className: p(a, z.button, r ? z.withText : z.withoutText)
                })
            }
            var W = a(32133),
                F = a(4257),
                O = a(32887);
            const P = {
                    compare: (0, i.t)("Compare"),
                    compareOrAddSymbol: (0, i.t)("Compare or Add Symbol")
                },
                B = (0, x.registryContextType)();
            class U extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._updateState = e => {
                        this.setState({
                            isActive: e
                        })
                    }, this._handleClick = () => {
                        var e;
                        (0, W.trackEvent)("GUI", "Chart Header Toolbar", "compare"), null === (e = this._compareDialogRenderer) || void 0 === e || e.show()
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired
                    }), this.state = {
                        isActive: !1
                    }, this._compareDialogRenderer = this.context.chartWidgetCollection.getCompareDialogRenderer()
                }
                componentDidMount() {
                    var e;
                    null === (e = this._compareDialogRenderer) || void 0 === e || e.visible().subscribe(this._updateState)
                }
                componentWillUnmount() {
                    var e;
                    null === (e = this._compareDialogRenderer) || void 0 === e || e.visible().unsubscribe(this._updateState)
                }
                render() {
                    const {
                        isActive: e
                    } = this.state;
                    return s.createElement(D, { ...this.props,
                        icon: O,
                        isOpened: e,
                        onClick: this._handleClick,
                        text: F.hasNewHeaderToolbarStyles ? void 0 : P.compare,
                        title: P.compareOrAddSymbol,
                        collapseWhen: F.hasNewHeaderToolbarStyles ? ["full", "medium", "small"] : void 0
                    })
                }
            }
            U.contextType = B;
            var V = a(5710),
                G = a(25784),
                K = a(80185),
                Z = a(77208),
                q = a(83522);
            const Q = {
                    hint: (0,
                        i.t)("Fullscreen mode")
                },
                Y = (0, G.hotKeySerialize)({
                    keys: [(0, K.humanReadableModifiers)(K.Modifiers.Shift, !1), "F"],
                    text: "{0} + {1}"
                }),
                j = (0, x.registryContextType)();
            class J extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidgetCollection: e
                        } = this.context;
                        e.startFullscreen()
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e,
                        id: t
                    } = this.props;
                    return s.createElement(V.ToolWidgetIconButton, {
                        id: t,
                        icon: F.hasNewHeaderToolbarStyles ? q : Z,
                        onClick: this._handleClick,
                        title: Q.hint,
                        className: p(e),
                        "data-tooltip-hotkey": Y
                    })
                }
            }
            J.contextType = j;
            var X = a(88537);
            const $ = (0, a(51951).getLogger)("FavoritesInfo");

            function ee(e, t) {
                if (0 === e.length) return Promise.resolve([]);
                $.logNormal("Requesting favorites info");
                const a = [],
                    n = new Map,
                    s = new Map,
                    o = new Map;
                return e.forEach(e => {
                    switch (e.type) {
                        case "java":
                            o.set(e.studyId, e);
                            break;
                        case "pine":
                            isPublishedPineId(e.pineId) ? n.set(e.pineId, e) : s.set(e.pineId, e);
                            break;
                        default:
                            (0, X.assert)(!1, "unknown favorite type " + JSON.stringify(e))
                    }
                }), 0 !== o.size && a.push(t.findAllJavaStudies().then(e => {
                    const t = new Map;
                    for (const a of e) !a.is_hidden_study && o.has(a.id) && t.set(a.id, {
                        name: a.description,
                        localizedName: a.description_localized,
                        studyMarketShittyObject: a
                    });
                    return t
                }).then(e => {
                    const t = function(e, t) {
                        const a = {
                            items: [],
                            notFoundItems: []
                        };
                        return e.forEach((e, n) => {
                            const s = t.get(n);
                            void 0 !== s ? a.items.push({
                                item: e,
                                info: s
                            }) : a.notFoundItems.push(e)
                        }), a
                    }(o, e);
                    if (0 !== t.notFoundItems.length) {
                        const e = t.notFoundItems.map(e => e.studyId);
                        $.logWarn("Cannot find java scripts: " + JSON.stringify(e))
                    }
                    return t.items
                })), Promise.all(a).then(e => ($.logNormal("Requesting favorites info finished"), e.reduce((e, t) => e.concat(t), [])))
            }
            var te = a(5796),
                ae = a(93546),
                ne = a(21638),
                se = a(46369),
                oe = a(59410),
                ie = a(59672),
                re = a(64142);
            const le = {
                    text: (0, i.t)("Indicators"),
                    hint: (0, i.t)("Indicators & Strategies"),
                    favorites: (0, i.t)("Favorites")
                },
                he = (0, G.hotKeySerialize)({
                    keys: ["/"],
                    text: "{0}"
                }),
                ce = (0, x.registryContextType)();
            class de extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._promise = null, this._menu = s.createRef(), this._favoriteFundamentalsModel = null, this._setActiveState = e => {
                        this.setState({
                            isActive: e
                        })
                    }, this._handleClick = () => {
                        const {
                            studyMarket: e
                        } = this.props;
                        this.setState({
                            isActive: !0
                        }, () => {
                            e.visible().value() ? e.hide() : e.show()
                        }), this._trackClick()
                    }, this._handleSelectIndicator = e => {
                        e = (0, X.ensureDefined)(e), this._trackFavoriteAction("Favorite indicator from toolbar");
                        const {
                            chartWidgetCollection: t
                        } = this.context;
                        if ("java" === e.type) {
                            const t = (0, te.tryFindStudyLineToolNameByStudyId)(e.studyId);
                            if (null !== t) return void ae.tool.setValue(t)
                        }
                        t.activeChartWidget.value().insertStudy(e)
                    }, this._handleFavoriteIndicatorsChange = () => {
                        const {
                            favoriteScriptsModel: e
                        } = this.context, t = [...(0, X.ensureDefined)(e).favorites()];
                        this.setState({
                            favorites: t
                        }), this._clearCache()
                    }, this._handleFavoriteFundamentalsChange = () => {
                        var e;
                        const t = new Set((null === (e = this._favoriteFundamentalsModel) || void 0 === e ? void 0 : e.favorites()) || []);
                        this.setState({
                            favoriteFundamentals: t
                        }), this._clearCache()
                    }, this._handleMouseEnter = () => {
                        this._prefetchFavorites()
                    }, this._handleWrapClick = () => {
                        this._prefetchFavorites()
                    }, this._handleChangeActiveWidget = () => {
                        this._clearCache()
                    }, this._clearCache = () => {
                        this._promise = null, this.setState({
                            infos: []
                        })
                    }, this._handleScriptRenamed = e => {
                        const {
                            favoriteScriptsModel: t
                        } = this.context;
                        void 0 !== t && t.isFav(e.scriptIdPart) && this._clearCache()
                    }, this._handleFavoriteMenuClick = () => {
                        this._trackClick(), this._trackFavoriteAction("Select favorite indicators dropdown")
                    }, (0, x.validateRegistry)(t, {
                        favoriteScriptsModel: o.any,
                        chartWidgetCollection: o.any.isRequired
                    });
                    const {
                        favoriteScriptsModel: a
                    } = t, n = void 0 !== a ? a.favorites() : [];
                    this.state = {
                        isActive: !1,
                        isLoading: !1,
                        favorites: n,
                        favoriteFundamentals: void 0,
                        infos: []
                    }
                }
                componentDidMount() {
                    const {
                        studyMarket: e
                    } = this.props, {
                        favoriteScriptsModel: t,
                        chartWidgetCollection: a
                    } = this.context;
                    e.visible().subscribe(this._setActiveState), void 0 !== t && (t.favoritesChanged().subscribe(this, this._handleFavoriteIndicatorsChange), a.activeChartWidget.subscribe(this._handleChangeActiveWidget)), oe.on("TVScriptRenamed", this._handleScriptRenamed, null)
                }
                componentWillUnmount() {
                    const {
                        studyMarket: e
                    } = this.props, {
                        favoriteScriptsModel: t,
                        chartWidgetCollection: a
                    } = this.context;
                    e.visible().unsubscribe(this._setActiveState), void 0 !== t && (t.favoritesChanged().unsubscribe(this, this._handleFavoriteIndicatorsChange), a.activeChartWidget.unsubscribe(this._handleChangeActiveWidget)), oe.unsubscribe("TVScriptRenamed", this._handleScriptRenamed, null), this._promise = null
                }
                render() {
                    const {
                        isActive: e,
                        favorites: t,
                        favoriteFundamentals: a,
                        isLoading: n
                    } = this.state, {
                        className: o,
                        displayMode: r,
                        id: l
                    } = this.props, {
                        chartWidgetCollection: h
                    } = this.context;
                    return s.createElement(s.Fragment, null, s.createElement(w, {
                        id: l,
                        onMouseEnter: this._handleMouseEnter,
                        onClick: this._handleWrapClick
                    }, s.createElement(D, {
                        displayMode: r,
                        className: o,
                        icon: ie,
                        isOpened: e,
                        onClick: this._handleClick,
                        text: le.text,
                        title: le.hint,
                        "data-role": "button",
                        "data-name": "open-indicators-dialog",
                        "data-tooltip-hotkey": he
                    }), Boolean(t.length > 0 || (null == a ? void 0 : a.size)) && s.createElement(_.MatchMedia, {
                        rule: "screen and (max-width: 428px)"
                    }, e => s.createElement(m.ToolWidgetMenu, {
                        key: h.activeChartWidget.value().id(),
                        arrow: !0,
                        closeOnClickOutside: !0,
                        isDrawer: e,
                        drawerPosition: "Bottom",
                        title: le.favorites,
                        ref: this._menu,
                        onClick: this._handleFavoriteMenuClick,
                        "data-name": "show-favorite-indicators"
                    }, s.createElement("div", {
                        className: v()(re.dropdown, e && re.smallWidthWrapper)
                    }, s.createElement(se.ToolWidgetMenuSummary, {
                        className: e && re.smallWidthTitle
                    }, (0, i.t)("Favorite Indicators")), n && s.createElement(ne.ToolWidgetMenuSpinner, null), !n && s.createElement(s.Fragment, null, this.state.infos.length > 0 ? this.state.infos.map(t => s.createElement(u.PopupMenuItem, {
                        className: v()(e && re.smallWidthMenuItem),
                        theme: e ? M.multilineLabelWithIconAndToolboxTheme : void 0,
                        key: "java" === t.item.type ? t.item.studyId : t.item.pineId,
                        onClick: this._handleSelectIndicator,
                        onClickArg: t.item,
                        label: s.createElement("span", {
                            className: v()(!e && re.label, e && re.smallWidthLabel, "apply-overflow-tooltip")
                        }, ue(t))
                    })) : null !== this._promise && s.createElement(u.PopupMenuItem, {
                        isDisabled: !0,
                        label: (0, i.t)("You have no Favorites Indicators yet")
                    })))))))
                }
                _prefetchFavorites() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    if (null !== this._promise || !window.is_authenticated) return;
                    const t = e.activeChartWidget.value();
                    if (!t.hasModel()) return;
                    const a = t.model().model().studyMetaInfoRepository();
                    this.setState({
                        isLoading: !0
                    });
                    const n = this._promise = Promise.all([ee(this.state.favorites, a), void 0]).then(e => {
                        if (n !== this._promise) return;
                        const [t, a] = e;
                        let s = [...t];
                        if (a) {
                            const e = a.filter(e => {
                                var t;
                                return null === (t = this.state.favoriteFundamentals) || void 0 === t ? void 0 : t.has(e.scriptIdPart)
                            }).map(this._mapFundamentalToFavoriteItemInfo);
                            s.push(...e)
                        }
                        s = [...s].sort((e, t) => ue(e).localeCompare(ue(t))), this.setState({
                            infos: s,
                            isLoading: !1
                        }, () => {
                            this._menu.current && this._menu.current.update()
                        })
                    })
                }
                _trackClick() {
                    0
                }
                _trackFavoriteAction(e) {
                    (0, W.trackEvent)("GUI", "Chart Header Toolbar", e)
                }
                _mapFundamentalToFavoriteItemInfo(e) {
                    return {
                        item: {
                            type: "pine",
                            pineId: e.scriptIdPart
                        },
                        info: {
                            name: e.scriptName,
                            localizedName: getLocalizedFundamentalsName(e),
                            studyMarketShittyObject: void 0
                        }
                    }
                }
            }

            function ue(e) {
                return e.info.localizedName || (0, i.t)(e.info.name, {
                    context: "study"
                })
            }
            de.contextType = ce;
            var me = a(2117),
                pe = a(41083),
                ve = a(87906);

            function ge(e) {
                return s.createElement("div", {
                    className: p(ve.value, {
                        [ve.selected]: e.isSelected
                    })
                }, e.value, e.metric)
            }
            var we = a(44377),
                be = a(15783),
                Ce = a(21714),
                Se = a(69698);
            class ye extends s.PureComponent {
                constructor(e) {
                    super(e), this._timeMenu = null, this._setMenuRef = e => {
                        this._timeMenu = e
                    }, this._handleChangeInput = e => {
                        const {
                            value: t
                        } = e.currentTarget;
                        /^[0-9]*$/.test(t) && this.setState({
                            inputValue: t
                        })
                    }, this._handleSelectTime = e => {
                        this.setState({
                            selectedIntervalSuffix: e
                        }), this._closeMenu()
                    }, this._handleClickAdd = () => {
                        const {
                            inputValue: e,
                            selectedIntervalSuffix: t
                        } = this.state;
                        this.props.onAdd(e, t)
                    }, this._toggleMenu = () => {
                        this.state.isOpenedMenu ? this._closeMenu() : this._openMenu()
                    }, this._closeMenu = () => {
                        this.props.onCloseMenu(), this.setState({
                            isOpenedMenu: !1
                        })
                    }, this._openMenu = () => {
                        this.props.onOpenMenu(), this.setState({
                            isOpenedMenu: !0
                        })
                    }, this._getMenuPosition = () => {
                        const e = (0, X.ensureNotNull)(this._timeMenu).getBoundingClientRect();
                        return {
                            overrideWidth: e.width,
                            x: e.left,
                            y: e.bottom + 1
                        }
                    }, this.state = {
                        inputValue: "1",
                        isOpenedMenu: !1,
                        selectedIntervalSuffix: Ce.INTERVALS[0].name
                    }
                }
                render() {
                    const {
                        inputValue: e,
                        isOpenedMenu: t,
                        menuWidth: a,
                        selectedIntervalSuffix: n
                    } = this.state;
                    return s.createElement("div", {
                        className: p(Se.form, {
                            [Se.interacting]: t
                        })
                    }, s.createElement("input", {
                        className: Se.input,
                        maxLength: 7,
                        onChange: this._handleChangeInput,
                        value: e
                    }), s.createElement("div", {
                        className: Se.menu,
                        onClick: this._toggleMenu,
                        ref: this._setMenuRef
                    }, Ce.INTERVALS.find(e => e.name === n).label, s.createElement(be.ToolWidgetCaret, {
                        dropped: t
                    })), s.createElement("div", {
                        className: Se.add,
                        onClick: this._handleClickAdd
                    }, (0, i.t)("Add")), s.createElement(we.PopupMenu, {
                        doNotCloseOn: this,
                        isOpened: t,
                        minWidth: a,
                        onClose: this._closeMenu,
                        position: this._getMenuPosition
                    }, Ce.INTERVALS.map(e => s.createElement(u.PopupMenuItem, {
                        dontClosePopup: !0,
                        key: e.name,
                        label: e.label,
                        onClick: this._handleSelectTime,
                        onClickArg: e.name
                    }))))
                }
            }
            var fe = a(72621),
                _e = a(21258),
                ke = a(72535),
                Me = a(32062);

            function xe(e) {
                const {
                    interval: t,
                    hint: a,
                    isActive: n,
                    isDisabled: o,
                    isFavorite: i,
                    isSignaling: r,
                    onClick: l,
                    onClickRemove: h,
                    onClickFavorite: d,
                    isSmallTablet: m
                } = e, p = (0, C.filterDataProps)(e), [g, w] = (0, _e.useHover)(), b = s.useCallback(() => h(t), [h, t]), S = s.useCallback(() => d(t), [d, t]), y = (0, s.useRef)(null);
                return (0, s.useEffect)(() => {
                    var e;
                    r && m && (null === (e = y.current) || void 0 === e || e.scrollIntoView())
                }, [r, m]), s.createElement("div", { ...w,
                    ref: y
                }, s.createElement(u.PopupMenuItem, { ...p,
                    className: v()(m && Me.smallWidthMenuItem),
                    theme: m ? M.multilineLabelWithIconAndToolboxTheme : void 0,
                    isActive: n,
                    isDisabled: o,
                    isHovered: r,
                    onClick: l,
                    onClickArg: t,
                    toolbox: function() {
                        const {
                            isRemovable: t,
                            isFavoritingAllowed: a
                        } = e, r = s.createElement(fe.RemoveButton, {
                            key: "remove",
                            isActive: n,
                            hidden: !ke.touch && !g,
                            onClick: b
                        }), l = s.createElement(c.FavoriteButton, {
                            key: "favorite",
                            isActive: n,
                            isFilled: i,
                            onClick: S
                        });
                        return [t && r, !o && a && l]
                    }(),
                    showToolboxOnHover: !i,
                    label: a
                }))
            }
            const Ee = {
                [pe.ResolutionKind.Ticks]: (0, i.t)("Ticks", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Seconds]: (0, i.t)("Seconds", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Minutes]: (0, i.t)("Minutes", {
                    context: "interval_group_name"
                }),
                [pe.SpecialResolutionKind.Hours]: (0, i.t)("Hours", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Days]: (0, i.t)("Days", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Weeks]: (0, i.t)("Weeks", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Months]: (0, i.t)("Months", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Range]: (0, i.t)("Ranges", {
                    context: "interval_group_name"
                }),
                [pe.ResolutionKind.Invalid]: ""
            };

            function Te(e, t = !1) {
                return {
                    id: e,
                    name: Ee[e],
                    items: [],
                    mayOmitSeparator: t
                }
            }
            var Ie = a(32943),
                Ne = a(97496),
                Ae = a.n(Ne),
                He = a(28466),
                Re = a(70981),
                ze = a(6500);
            const Le = {
                    openDialog: (0, i.t)("Open Interval Dialog"),
                    timeInterval: (0, i.t)("Time Interval")
                },
                De = (0, G.hotKeySerialize)({
                    keys: [","],
                    text: (0, i.t)("Number or {hotKey_0}")
                }),
                We = (0, x.registryContextType)(),
                Fe = new(Ae()),
                Oe = s.lazy(async () => ({
                    default: (await Promise.all([a.e(9289), a.e(2888), a.e(4956), a.e(7962), a.e(8986), a.e(8463), a.e(2385), a.e(7345), a.e(5643), a.e(766), a.e(4013)]).then(a.bind(a, 54804))).ToolWidgetIntervalsAddDialog
                }));

            function Pe(e) {
                {
                    const t = pe.Interval.parse(e);
                    if (!(0, me.isSecondsEnabled)() && t.isSeconds()) return !1;
                    if (!(0, me.isTicksEnabled)() && t.isTicks()) return !1
                }
                return !0
            }
            class Be extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._menu = s.createRef(), this._renderChildren = (e, t) => [...this._createMenuItems(e, t), ...this._createIntervalForm(t)], this._handleChangeInterval = e => {
                        const {
                            activeInterval: t,
                            lastNotQuicked: a
                        } = this.state, n = this._getQuicks();
                        this.setState({
                            activeInterval: (0, me.normalizeIntervalString)(e),
                            lastNotQuicked: void 0 === t || n.includes(t) ? a : t
                        })
                    }, this._bindedForceUpdate = () => {
                        this.forceUpdate()
                    }, this._handleCloseMenu = () => {
                        this.setState({
                            isOpenedFormMenu: !1
                        })
                    }, this._handleOpenMenu = () => {
                        this.setState({
                            isOpenedFormMenu: !0
                        })
                    }, this._handleSelectInterval = e => {
                        void 0 !== e && e !== r.linking.interval.value() && this.context.chartWidgetCollection.setResolution(e), e && (0,
                            W.trackEvent)("GUI", "Time Interval", e)
                    }, this._handleClickFavorite = e => {
                        e = (0, X.ensureDefined)(e), this._isIntervalFavorite(e) ? this._handleRemoveFavorite(e) : this._handleAddFavorite(e)
                    }, this._handleAddFavorite = e => {
                        const {
                            favorites: t
                        } = this.state;
                        this.context.favoriteIntervalsService.set([...t, e])
                    }, this._handleRemoveFavorite = e => {
                        const {
                            favorites: t
                        } = this.state;
                        this.context.favoriteIntervalsService.set(t.filter(t => t !== e))
                    }, this._handleAddInterval = (e, t) => {
                        const {
                            intervalService: a
                        } = this.context, n = a.add(e, t);
                        n && this.setState({
                            lastAddedInterval: n
                        })
                    }, this._handleRemoveInterval = e => {
                        const {
                            intervalService: t
                        } = this.context;
                        e && (t.remove(e), this._handleRemoveFavorite(e))
                    }, this._getHandleSectionStateChange = e => t => {
                        const {
                            menuViewState: a
                        } = this.state, {
                            intervalsMenuViewStateService: n
                        } = this.context;
                        n.set({ ...a,
                            [e]: !t
                        })
                    }, this._handleOpenAddIntervalDialog = () => {
                        this.setState({
                            isAddIntervalDialogOpened: !0
                        })
                    }, this._handleCloseAddIntervalDialog = () => {
                        this.setState({
                            isAddIntervalDialogOpened: !1
                        })
                    }, this._handleGlobalClose = () => {
                        const {
                            isFake: e
                        } = this.props, {
                            isAddIntervalDialogOpened: t
                        } = this.state;
                        e || t || Fe.fire()
                    }, this._handeQuickClick = e => {
                        this._handleSelectInterval(e), this._trackClick()
                    }, (0, x.validateRegistry)(t, {
                        chartApiInstance: o.any.isRequired,
                        favoriteIntervalsService: o.any.isRequired,
                        intervalService: o.any.isRequired,
                        intervalsMenuViewStateService: o.any.isRequired
                    });
                    const {
                        chartApiInstance: a,
                        favoriteIntervalsService: i,
                        intervalService: l,
                        intervalsMenuViewStateService: h
                    } = t;
                    this._customIntervals = n.enabled("custom_resolutions");
                    const c = r.linking.interval.value(),
                        d = c && (0, me.normalizeIntervalString)(c),
                        u = i.get(),
                        m = l.getCustomIntervals(),
                        p = h.get();
                    this._defaultIntervals = a.defaultResolutions().filter(Pe).map(me.normalizeIntervalString), this.state = {
                        isOpenedFormMenu: !1,
                        activeInterval: d,
                        favorites: u,
                        customs: m,
                        menuViewState: p,
                        isAddIntervalDialogOpened: !1
                    }
                }
                componentDidMount() {
                    const {
                        favoriteIntervalsService: e,
                        intervalService: t,
                        intervalsMenuViewStateService: a
                    } = this.context;
                    e.getOnChange().subscribe(this, this._handleChangeFavorites), a.getOnChange().subscribe(this, this._handleChangeMenuViewState), t.getOnChange().subscribe(this, this._handleChangeCustoms), r.linking.interval.subscribe(this._handleChangeInterval), r.linking.intraday.subscribe(this._bindedForceUpdate), r.linking.seconds.subscribe(this._bindedForceUpdate), r.linking.ticks.subscribe(this._bindedForceUpdate), r.linking.range.subscribe(this._bindedForceUpdate), r.linking.supportedResolutions.subscribe(this._bindedForceUpdate), Re.globalCloseDelegate.subscribe(this, this._handleGlobalClose)
                }
                componentWillUnmount() {
                    const {
                        favoriteIntervalsService: e,
                        intervalService: t,
                        intervalsMenuViewStateService: a
                    } = this.context;
                    e.getOnChange().unsubscribe(this, this._handleChangeFavorites), a.getOnChange().unsubscribe(this, this._handleChangeMenuViewState), t.getOnChange().unsubscribe(this, this._handleChangeCustoms), r.linking.interval.unsubscribe(this._handleChangeInterval), r.linking.intraday.unsubscribe(this._bindedForceUpdate), r.linking.seconds.unsubscribe(this._bindedForceUpdate), r.linking.ticks.unsubscribe(this._bindedForceUpdate),
                        r.linking.range.unsubscribe(this._bindedForceUpdate), r.linking.supportedResolutions.unsubscribe(this._bindedForceUpdate), Re.globalCloseDelegate.unsubscribe(this, this._handleGlobalClose)
                }
                componentDidUpdate(e, t) {
                    this.state.lastAddedInterval && setTimeout(() => this.setState({
                        lastAddedInterval: void 0
                    }), 400)
                }
                render() {
                    const {
                        isShownQuicks: e,
                        id: t
                    } = this.props, {
                        activeInterval: a,
                        customs: n,
                        lastNotQuicked: o,
                        isAddIntervalDialogOpened: i
                    } = this.state, r = this._getQuicks(), l = (0, me.sortResolutions)([...r]);
                    void 0 !== a && l.includes(a) ? void 0 !== o && l.push(o) : void 0 !== a && l.push(a);
                    const h = (!(!e || 0 === r.length) || void 0) && l.length > 1,
                        c = {},
                        d = (0, me.mergeResolutions)(this._defaultIntervals, n);
                    (void 0 !== a ? d.concat(a) : d).filter(me.isAvailable).forEach(e => c[e] = !0);
                    const u = void 0 !== a ? (0, me.getTranslatedResolutionModel)(a) : null;
                    return s.createElement(w, {
                        id: t
                    }, h && l.map((e, t) => {
                        const n = (0, me.getTranslatedResolutionModel)(e);
                        return s.createElement(y, {
                            key: t,
                            className: p(ze.button, {
                                [ze.first]: 0 === t,
                                [ze.last]: t === l.length - 1,
                                [ze.newStyles]: F.hasNewHeaderToolbarStyles
                            }),
                            text: s.createElement(ge, {
                                value: n.mayOmitMultiplier ? void 0 : n.multiplier,
                                metric: n.shortKind
                            }),
                            hint: n.hint,
                            isActive: a === e,
                            isDisabled: !c[e] && e !== o,
                            onClick: this._handeQuickClick,
                            onClickArg: e,
                            "data-value": e
                        })
                    }), s.createElement(_.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, e => s.createElement(s.Fragment, null, s.createElement(He.CloseDelegateContext.Provider, {
                        value: Fe
                    }, s.createElement(m.ToolWidgetMenu, {
                        arrow: Boolean(h),
                        closeOnClickOutside: !0,
                        content: h || null === u ? void 0 : s.createElement(w, {
                            className: ze.menuContent
                        }, s.createElement(ge, {
                            value: u.mayOmitMultiplier ? void 0 : u.multiplier,
                            metric: u.shortKind
                        })),
                        title: h || null === u ? Le.timeInterval : u.hint,
                        hotKey: h ? De : void 0,
                        className: ze.menu,
                        ref: this._menu,
                        isDrawer: e,
                        onClick: this._trackClick
                    }, s.createElement("div", {
                        className: ze.dropdown
                    }, this._renderChildren(d, e)))), e && i && s.createElement(s.Suspense, {
                        fallback: null
                    }, s.createElement(Oe, {
                        onAdd: this._handleAddInterval,
                        onClose: this._handleCloseAddIntervalDialog,
                        onUnmount: this._handleCloseAddIntervalDialog
                    })))))
                }
                _createMenuItems(e, t) {
                    const a = function(e) {
                        const t = Te(pe.ResolutionKind.Ticks),
                            a = Te(pe.ResolutionKind.Seconds),
                            n = Te(pe.ResolutionKind.Minutes),
                            s = Te(pe.SpecialResolutionKind.Hours),
                            o = Te(pe.ResolutionKind.Days),
                            i = Te(pe.ResolutionKind.Range);
                        return e.forEach(e => {
                            const r = pe.Interval.parse(e);
                            r.isMinuteHours() ? s.items.push(e) : r.isMinutes() ? (0, pe.isHour)(Number(r.multiplier())) ? s.items.push(e) : n.items.push(e) : r.isSeconds() ? a.items.push(e) : r.isDWM() ? o.items.push(e) : r.isRange() ? i.items.push(e) : r.isTicks() && t.items.push(e)
                        }), [t, a, n, s, o, i].filter(e => 0 !== e.items.length)
                    }(e).map((e, a, n) => this._renderResolutionsGroup(e, 1 === n.length, t));
                    return function(e) {
                        let t = !1;
                        return e.filter((e, a, n) => {
                            let s = !0;
                            return e.type === f.PopupMenuSeparator && (0 !== a && a !== n.length - 1 || (s = !1), t && (s = !1)), t = e.type === f.PopupMenuSeparator, s
                        })
                    }([].concat(...a))
                }
                _createIntervalForm(e) {
                    if (this._customIntervals) {
                        const t = e ? s.createElement("div", {
                            key: "add-dialog",
                            className: ze.addCustomInterval,
                            onClick: this._handleOpenAddIntervalDialog
                        }, (0,
                            i.t)("Add custom interval") + "…") : s.createElement(ye, {
                            key: "add-form",
                            onAdd: this._handleAddInterval,
                            onCloseMenu: this._handleCloseMenu,
                            onOpenMenu: this._handleOpenMenu
                        });
                        return [s.createElement(f.PopupMenuSeparator, {
                            key: "custom-interval-separator"
                        }), t]
                    }
                    return []
                }
                _renderResolutionsGroup(e, t = !1, a) {
                    const n = [],
                        o = e.items.map(e => this._renderPopupMenuItem(e, a));
                    if (t) n.push(...o);
                    else if (a) {
                        const t = s.createElement("div", {
                            key: e.id
                        }, s.createElement("div", {
                            className: ze.smallTabletSectionTitle
                        }, e.name), o);
                        n.push(t)
                    } else {
                        const {
                            intervalsMenuViewStateService: t
                        } = this.context, {
                            menuViewState: a
                        } = this.state;
                        if (!t.isAllowed(e.id)) return [];
                        const i = s.createElement(Ie.CollapsibleSection, {
                            key: e.id,
                            className: ze.section,
                            summary: e.name,
                            open: !a[e.id],
                            onStateChange: this._getHandleSectionStateChange(e.id)
                        }, o);
                        n.push(i)
                    }
                    return (!e.mayOmitSeparator || e.items.length > 1) && (n.unshift(s.createElement(f.PopupMenuSeparator, {
                        key: "begin-" + e.name
                    })), n.push(s.createElement(f.PopupMenuSeparator, {
                        key: "end-" + e.name
                    }))), n
                }
                _handleChangeFavorites(e) {
                    this.setState({
                        lastNotQuicked: void 0,
                        favorites: e
                    })
                }
                _handleChangeCustoms(e) {
                    this.setState({
                        customs: e
                    })
                }
                _handleChangeMenuViewState(e) {
                    this.setState({
                        menuViewState: e
                    }, () => {
                        this._menu.current && this._menu.current.update()
                    })
                }
                _renderPopupMenuItem(e, t) {
                    const {
                        isFavoritingAllowed: a
                    } = this.props, {
                        activeInterval: n,
                        lastAddedInterval: o
                    } = this.state, i = e === n, r = (0, me.isAvailable)(e), l = this._isIntervalFavorite(e), h = this._isIntervalDefault(e), c = (0, me.getTranslatedResolutionModel)(e);
                    return s.createElement(xe, {
                        key: e,
                        isSmallTablet: t,
                        interval: e,
                        hint: c.hint,
                        isSignaling: o === e,
                        isFavoritingAllowed: a,
                        isDisabled: !r,
                        isFavorite: l,
                        isRemovable: !h,
                        isActive: i,
                        onClick: this._handleSelectInterval,
                        onClickRemove: this._handleRemoveInterval,
                        onClickFavorite: this._handleClickFavorite,
                        "data-value": e
                    })
                }
                _isIntervalDefault(e) {
                    return this._defaultIntervals.includes(e)
                }
                _isIntervalFavorite(e) {
                    return this.state.favorites.includes(e)
                }
                _getQuicks(e) {
                    return this.props.isShownQuicks && "small" !== this.props.displayMode ? void 0 === e ? this.state.favorites : e : []
                }
                _trackClick() {
                    0
                }
            }
            Be.contextType = We;
            var Ue = a(76521),
                Ve = a(6361);
            const Ge = {
                    hint: (0, i.t)("Open chart in popup")
                },
                Ke = (0, x.registryContextType)();
            class Ze extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidgetCollection: e,
                            windowMessageService: t,
                            isFundamental: a
                        } = this.context, n = e.activeChartWidget.value();
                        n.withModel(null, () => {
                            t.post(parent, "openChartInPopup", {
                                symbol: n.model().mainSeries().actualSymbol(),
                                interval: n.model().mainSeries().interval(),
                                fundamental: a
                            })
                        })
                    }, (0, x.validateRegistry)(t, {
                        isFundamental: o.any,
                        chartWidgetCollection: o.any.isRequired,
                        windowMessageService: o.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e
                    } = this.props;
                    return s.createElement(V.ToolWidgetIconButton, {
                        className: p(e, Ue.button),
                        icon: Ve,
                        onClick: this._handleClick,
                        title: Ge.hint
                    })
                }
            }
            Ze.contextType = Ke;
            var qe = a(292);
            const Qe = {
                    hint: (0, i.t)("Chart settings")
                },
                Ye = (0, x.registryContextType)();
            class je extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidgetCollection: e
                        } = this.context, t = e.activeChartWidget.value();
                        (0,
                            W.trackEvent)("GUI", "Chart Header Toolbar", "chart properties"), t.showGeneralChartProperties()
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired
                    })
                }
                render() {
                    return s.createElement(V.ToolWidgetIconButton, { ...this.props,
                        icon: qe,
                        title: Qe.hint,
                        onClick: this._handleClick
                    })
                }
            }
            je.contextType = Ye;
            var Je = a(82027),
                Xe = a(42609),
                $e = a(85787),
                et = a(49473);
            const tt = "M21.5 21.5h-14a5 5 0 1 1 .42-9.983 7.5 7.5 0 0 1 14.57 2.106 4.002 4.002 0 0 1-.99 7.877z",
                at = 13.08991081237793,
                nt = {
                    strokeDashOffset: 49.242997817993164,
                    strokeDash: 49.866326904296876,
                    strokeGap: at,
                    strokeDashCheck: 0
                },
                st = {
                    strokeDashOffset: 62.956237716674806,
                    strokeGap: 0,
                    strokeDash: 62.956237716674806,
                    strokeDashCheck: 200
                };
            class ot extends s.PureComponent {
                constructor(e) {
                    super(e), this.state = nt
                }
                componentDidMount() {
                    "saved" === this.props.state ? this.setState(st) : this._goToNextState(this.props.state)
                }
                componentWillUnmount() {
                    this._currentAnimation = void 0
                }
                UNSAFE_componentWillReceiveProps(e) {
                    this.props.state !== e.state && this._goToNextState(e.state)
                }
                render() {
                    const {
                        strokeDashOffset: e,
                        strokeDash: t,
                        strokeGap: a,
                        strokeDashCheck: n
                    } = this.state, {
                        className: o,
                        size: i,
                        onClick: r,
                        state: l,
                        isHovered: h = !1
                    } = this.props, c = p(et.container, o, h && et.hovered, {
                        [et.unsaved]: "unsaved" === l,
                        [et.saving]: "saving" === l,
                        [et.saved]: "saved" === l
                    });
                    return s.createElement("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        className: c,
                        version: "1.1",
                        width: i,
                        height: i,
                        viewBox: "0 0 28 28",
                        onClick: r
                    }, s.createElement("g", {
                        fill: "none"
                    }, s.createElement("path", {
                        className: et.dottedCloud,
                        stroke: "currentColor",
                        strokeDasharray: "3.5,2.5",
                        d: tt
                    }), s.createElement("path", {
                        className: et.spinningCloud,
                        stroke: "currentColor",
                        strokeDasharray: `${t} ${a}`,
                        strokeDashoffset: e,
                        d: tt
                    }), s.createElement("path", {
                        className: et.arrowGap,
                        d: "M11 20h6v5h-6z"
                    }), s.createElement("g", {
                        className: et.arrow,
                        stroke: "currentColor"
                    }, s.createElement("path", {
                        strokeLinecap: "square",
                        d: "M14.5 14.5v10"
                    }), s.createElement("path", {
                        d: "M11 17l3.5-3.5L18 17"
                    })), s.createElement("g", {
                        className: et.check,
                        stroke: "currentColor"
                    }, s.createElement("path", {
                        strokeDasharray: `${n}% ${200-n}%`,
                        d: "M10 15l2.5 2.5L18 12"
                    }))))
                }
                _goToNextState(e) {
                    switch (e) {
                        case "unsaved":
                            this.setState(nt);
                            break;
                        case "saving":
                            "unsaved" !== this.props.state && this.setState(nt), this._currentAnimation = Promise.resolve(this._currentAnimation).then(() => this._createSpinAnimationWhile(() => "saving" === this.props.state));
                            break;
                        case "saved":
                            this._currentAnimation = Promise.resolve(this._currentAnimation).then(this._createFillGapAnimation.bind(this)).then(this._createCheckAnimation.bind(this))
                    }
                }
                _createSpinAnimationWhile(e) {
                    return this._createSpinAnimation().then(() => e() ? this._createSpinAnimationWhile(e) : Promise.resolve())
                }
                _createSpinAnimation() {
                    return new Promise(e => {
                        (0, Xe.doAnimate)({
                            onStep: (e, t) => {
                                void 0 !== this._currentAnimation && this.setState({
                                    strokeDashOffset: t
                                })
                            },
                            onComplete: () => e(),
                            from: 49.242997817993164,
                            to: 111.57590644836426,
                            easing: $e.easingFunc.linear,
                            duration: 1e3
                        })
                    })
                }
                _createCheckAnimation() {
                    return new Promise(e => {
                        (0, Xe.doAnimate)({
                            onStep: (e, t) => {
                                void 0 !== this._currentAnimation && this.setState({
                                    strokeDashCheck: Math.round(t)
                                })
                            },
                            onComplete: () => e(),
                            from: 0,
                            to: 200,
                            easing: $e.easingFunc.linear,
                            duration: 1e3
                        })
                    })
                }
                _createFillGapAnimation() {
                    return new Promise(e => {
                        (0, Xe.doAnimate)({
                            onStep: (e, t) => {
                                void 0 !== this._currentAnimation && this.setState({
                                    strokeDashOffset: 62.956237716674806 - t,
                                    strokeGap: t,
                                    strokeDash: 62.956237716674806 - t
                                })
                            },
                            onComplete: () => e(),
                            from: at,
                            to: 0,
                            easing: $e.easingFunc.linear,
                            duration: 200
                        })
                    })
                }
            }
            var it = a(93173),
                rt = a(45545),
                lt = a(28857);
            const ht = (0, it.mergeThemes)(rt.DEFAULT_MENU_ITEM_SWITCHER_THEME, lt);
            var ct = a(18833),
                dt = a(56085),
                ut = a(96141),
                mt = a(4050);
            a(95707);
            const pt = n.enabled("widget"),
                vt = (0, it.mergeThemes)(b.DEFAULT_TOOL_WIDGET_BUTTON_THEME, mt),
                gt = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    shortcut: ut.shortcut
                }),
                wt = {
                    copy: (0, i.t)("Copy"),
                    makeCopy: (0, i.t)("Make a Copy"),
                    newChartLayout: (0, i.t)("New Chart Layout"),
                    loadChartLayout: (0, ct.appendEllipsis)((0, i.t)("Load Chart Layout")),
                    rename: (0, ct.appendEllipsis)((0, i.t)("Rename")),
                    renameChartLayout: (0, i.t)("Rename Chart Layout"),
                    saveAs: (0, ct.appendEllipsis)((0, i.t)("Make a Copy")),
                    saveChartLayout: (0, i.t)("Save"),
                    saveChartLayoutLong: (0, i.t)("Save all charts for all symbols and intervals on your layout"),
                    manageChartLayouts: (0, i.t)("Manage Chart Layouts")
                },
                bt = [],
                Ct = (0, G.hotKeySerialize)({
                    keys: [(0, K.humanReadableModifiers)(K.Modifiers.Mod, !1), "S"],
                    text: "{0} + {1}"
                });
            class St extends s.PureComponent {
                constructor(e) {
                    super(e), this._handleSaveHoverBegin = () => {
                        this.setState({
                            iconHovered: !0
                        })
                    }, this._handleSaveHoverEnd = () => {
                        this.setState({
                            iconHovered: !1
                        })
                    }, this._handleCloneClick = () => {
                        var e, t;
                        null === (t = (e = this.props).onCloneChart) || void 0 === t || t.call(e), this._trackClick()
                    }, this._handleSaveClick = () => {
                        var e, t;
                        null === (t = (e = this.props).onSaveChart) || void 0 === t || t.call(e), this._trackClick()
                    }, this.state = {
                        iconHovered: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        isReadOnly: t,
                        displayMode: a,
                        isProcessing: n,
                        title: o,
                        chartId: i,
                        wasChanges: r,
                        hideMenu: l,
                        isTabletSmall: h,
                        dataNameSaveMenu: c
                    } = this.props, {
                        iconHovered: u
                    } = this.state, v = !t && !l;
                    let g = "saved";
                    return !r && o || (g = "unsaved"), n && (g = "saving"), s.createElement(w, null, t ? s.createElement(w, null, s.createElement(D, {
                        id: e,
                        displayMode: a,
                        icon: s.createElement(d.Icon, {
                            icon: dt
                        }),
                        isDisabled: n,
                        onClick: this._handleCloneClick,
                        text: wt.copy,
                        title: wt.makeCopy,
                        onMouseEnter: this._handleSaveHoverBegin,
                        onMouseLeave: this._handleSaveHoverEnd,
                        collapseWhen: bt
                    })) : s.createElement(w, null, s.createElement(D, {
                        id: e,
                        className: p(ut.button, v && ut.buttonSmallPadding),
                        displayMode: a,
                        icon: s.createElement(ot, {
                            size: 28,
                            state: g,
                            isHovered: u
                        }),
                        isDisabled: i && !r || n,
                        onClick: this._handleSaveClick,
                        text: o || wt.saveChartLayout,
                        title: wt.saveChartLayoutLong,
                        onMouseEnter: this._handleSaveHoverBegin,
                        onMouseLeave: this._handleSaveHoverEnd,
                        theme: vt,
                        collapseWhen: bt,
                        "data-tooltip-hotkey": pt ? "" : Ct
                    }), v && s.createElement(m.ToolWidgetMenu, {
                        "data-name": c,
                        className: "js-save-load-menu-open-button",
                        arrow: !0,
                        isDrawer: h,
                        drawerPosition: "Bottom",
                        title: wt.manageChartLayouts,
                        onClick: this._trackClick
                    }, this._renderMenuItems(Boolean(h)))))
                }
                _renderMenuItems(e) {
                    const {
                        wasChanges: t,
                        isProcessing: a,
                        chartId: n,
                        onSaveChartFromMenu: o,
                        onRenameChart: r,
                        onSaveAsChart: l,
                        onLoadChart: h,
                        onNewChart: c,
                        isAutoSaveEnabled: d,
                        autoSaveId: m,
                        sharingId: v,
                        onAutoSaveChanged: g,
                        isSharingEnabled: w,
                        onSharingChanged: b
                    } = this.props, C = e ? M.multilineLabelWithIconAndToolboxTheme : gt, S = e ? void 0 : (0, K.humanReadableHash)(K.Modifiers.Mod + 83), y = e ? void 0 : (0, i.t)("Dot", {
                        context: "hotkey"
                    }), _ = [];
                    return _.push(s.createElement(u.PopupMenuItem, {
                        key: "save",
                        isDisabled: Boolean(a || !t && n),
                        label: wt.saveChartLayout,
                        onClick: o,
                        shortcut: S,
                        labelRowClassName: p(e && ut.popupItemRowTabletSmall),
                        theme: C,
                        "data-name": "save-load-menu-item-save"
                    })), void 0 !== n && (e || _.push(s.createElement(f.PopupMenuSeparator, {
                        key: "existing-chart-section-begin"
                    })), _.push(s.createElement(u.PopupMenuItem, {
                        key: "rename",
                        label: wt.rename,
                        onClick: r,
                        labelRowClassName: p(e && ut.popupItemRowTabletSmall),
                        theme: C,
                        "data-name": "save-load-menu-item-rename"
                    }), s.createElement(u.PopupMenuItem, {
                        key: "save-as",
                        label: wt.saveAs,
                        onClick: l,
                        labelRowClassName: p(e && ut.popupItemRowTabletSmall),
                        theme: C,
                        "data-name": "save-load-menu-item-clone"
                    }))), _.push(s.createElement(f.PopupMenuSeparator, {
                        key: "platform-section-begin"
                    })), _.push(s.createElement(u.PopupMenuItem, {
                        key: "load-chart",
                        className: "js-save-load-menu-item-load-chart",
                        label: wt.loadChartLayout,
                        onClick: h,
                        labelRowClassName: p(e && ut.popupItemRowTabletSmall),
                        theme: C,
                        shortcut: y,
                        "data-name": "save-load-menu-item-load"
                    })), _
                }
                _trackClick() {
                    0
                }
            }
            const yt = (0, x.registryContextType)();
            class ft extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._syncState = e => {
                        this.setState(e)
                    }, this._onChangeHasChanges = e => {
                        this.state.wasChanges !== e && this.setState({
                            wasChanges: e
                        })
                    }, this._onChangeAutoSaveEnabled = e => {
                        0
                    }, this._onChangeSharingEnabled = e => {
                        this.setState({
                            isSharingEnabled: e
                        })
                    }, this._onChangeTitle = e => {
                        this.setState({
                            title: e
                        })
                    }, this._onChangeId = e => {
                        this.setState({
                            id: e
                        })
                    }, this._onChartAboutToBeSaved = () => {
                        this.setState({
                            isProcessing: !0
                        })
                    }, this._onChartSaved = () => {
                        this.setState({
                            isProcessing: !1
                        })
                    }, this._handleAutoSaveEnabled = e => {
                        0
                    }, this._handleSharingEnabled = e => {
                        0
                    }, this._handleClickSave = () => {
                        this.context.saveChartService.saveChartOrShowTitleDialog(), this._trackEvent("Save click")
                    }, this._handleClickSaveFromMenu = () => {
                        this.context.saveChartService.saveChartOrShowTitleDialog(), this._trackEvent("Save From Menu")
                    }, this._handleClickClone = () => {
                        this.context.saveChartService.cloneChart()
                    }, this._handleClickSaveAs = () => {
                        this.context.saveChartService.saveChartAs(), this._trackEvent("Make a copy")
                    }, this._handleClickNew = () => {
                        this._trackEvent("New chart layout")
                    }, this._handleClickLoad = () => {
                        this.context.loadChartService.showLoadDialog(), this._trackEvent("Load chart layout")
                    }, this._handleHotkey = () => {
                        this.context.loadChartService.showLoadDialog()
                    }, this._handleClickRename = () => {
                        this.context.saveChartService.renameChart(), this._trackEvent("Rename")
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired,
                        chartChangesWatcher: o.any.isRequired,
                        saveChartService: o.any.isRequired,
                        sharingChartService: o.any,
                        loadChartService: o.any.isRequired
                    });
                    const {
                        chartWidgetCollection: a,
                        chartChangesWatcher: n,
                        saveChartService: s,
                        sharingChartService: i
                    } = t;
                    this.state = {
                        isAuthenticated: window.is_authenticated,
                        isProcessing: !1,
                        id: a.metaInfo.id.value(),
                        title: a.metaInfo.name.value(),
                        wasChanges: n.hasChanges(),
                        iconHovered: !1
                    }
                }
                componentDidMount() {
                    const {
                        chartSaver: e,
                        isFake: t,
                        stateSyncEmitter: a
                    } = this.props, {
                        chartWidgetCollection: n,
                        chartChangesWatcher: s,
                        saveChartService: o,
                        sharingChartService: r
                    } = this.context;
                    t ? a.on("change", this._syncState) : (s.getOnChange().subscribe(this, this._onChangeHasChanges), n.metaInfo.name.subscribe(this._onChangeTitle), n.metaInfo.id.subscribe(this._onChangeId), this._hotkeys = (0, Je.createGroup)({
                        desc: "Save/Load"
                    }), this._hotkeys.add({
                        desc: (0, i.t)("Load Chart Layout"),
                        handler: this._handleHotkey,
                        hotkey: 190
                    }), e.chartSaved().subscribe(this, this._onChartSaved), e.chartAboutToBeSaved().subscribe(this, this._onChartAboutToBeSaved), window.loginStateChange.subscribe(this, this._onLoginStateChange))
                }
                componentDidUpdate(e, t) {
                    this.props.isFake || t !== this.state && this.props.stateSyncEmitter.emit("change", this.state)
                }
                componentWillUnmount() {
                    const {
                        chartSaver: e,
                        isFake: t,
                        stateSyncEmitter: a
                    } = this.props, {
                        chartWidgetCollection: n,
                        chartChangesWatcher: s,
                        saveChartService: o,
                        sharingChartService: i
                    } = this.context;
                    t ? a.off("change", this._syncState) : (s.getOnChange().unsubscribe(this, this._onChangeHasChanges), n.metaInfo.name.unsubscribe(this._onChangeTitle), n.metaInfo.id.unsubscribe(this._onChangeId), (0, X.ensureDefined)(this._hotkeys).destroy(), e.chartSaved().unsubscribe(this, this._onChartSaved), e.chartAboutToBeSaved().unsubscribe(this, this._onChartAboutToBeSaved), window.loginStateChange.unsubscribe(this, this._onLoginStateChange))
                }
                render() {
                    const {
                        isReadOnly: e,
                        displayMode: t,
                        id: a,
                        isFake: n
                    } = this.props, {
                        isProcessing: o,
                        isAuthenticated: i,
                        title: r,
                        id: l,
                        wasChanges: h,
                        isAutoSaveEnabled: c,
                        isSharingEnabled: d
                    } = this.state, u = {
                        displayMode: t,
                        isReadOnly: e,
                        isAuthenticated: i,
                        isProcessing: o,
                        wasChanges: h,
                        title: r,
                        id: a,
                        chartId: null !== l ? l : void 0,
                        dataNameSaveMenu: n ? void 0 : "save-load-menu",
                        onCloneChart: this._handleClickClone,
                        onSaveChart: this._handleClickSave,
                        onSaveChartFromMenu: this._handleClickSaveFromMenu,
                        onRenameChart: this._handleClickRename,
                        onSaveAsChart: this._handleClickSaveAs,
                        onLoadChart: this._handleClickLoad
                    };
                    return s.createElement(_.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, e => s.createElement(St, { ...u,
                        isTabletSmall: e
                    }))
                }
                _onLoginStateChange() {
                    this.setState({
                        isAuthenticated: window.is_authenticated
                    })
                }
                _trackEvent(e) {
                    0
                }
            }
            ft.contextType = yt;
            var _t = a(81076),
                kt = a(83887),
                Mt = a(10248);
            const xt = new kt.DateTimeFormatter({
                    dateTimeSeparator: "_",
                    timeFormat: "%h-%m-%s"
                }),
                Et = {
                    takeSnapshot: (0, i.t)("Take a snapshot")
                },
                Tt = (0, x.registryContextType)();
            const It = i.t("Loading...");

            function Nt(e, t, a) {
                return async function(e, t, a) {
                    const n = URL.createObjectURL(new Blob([`<!doctype html><html style="background-color:${getComputedStyle(document.documentElement).backgroundColor}"><head><meta charset="utf-8"><title>${It}</title></head><body style="background-color:${getComputedStyle(document.body).backgroundColor}"></body></html>`], {
                        type: "text/html"
                    }));
                    try {
                        const s = open(n, t, a);
                        if (!s) throw new Error("cound not open a new tab");
                        const o = await e.catch(() => {});
                        void 0 !== o ? s.location.replace(o) : s.close()
                    } finally {
                        URL.revokeObjectURL(n)
                    }
                }(e, t, a)
            }
            var At = a(37246),
                Ht = a(87469),
                Rt = a(34404),
                zt = a(91887);

            function Lt(e) {
                const t = p(e.isLoading && zt.hidden),
                    a = p(!e.isLoading && zt.hidden);
                return s.createElement("div", null, s.createElement("span", {
                    className: t
                }, e.children), s.createElement("span", {
                    className: a
                }, s.createElement(Rt.Loader, null)))
            }
            var Dt = a(52130),
                Wt = a(38071),
                Ft = a(58652),
                Ot = a(99923),
                Pt = a(57957),
                Bt = a(50275),
                Ut = a(75492);
            const Vt = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, Ut);

            function Gt(e) {
                const {
                    serverSnapshot: t,
                    clientSnapshot: n
                } = e, [o, r] = (0, s.useState)(!1), [l, h] = (0, s.useState)(!1), [c, d] = (0, s.useState)(!1), m = (0, Dt.useIsMounted)(), v = (0, s.useCallback)(async () => {
                    var e;
                    const t = n(),
                        a = t.then(e => new Promise(t => e.canvas.toBlob(e => {
                            null !== e && t(e)
                        })));
                    try {
                        await (0, At.writePromiseUsingApi)(a, "image/png"), oe.emit("onClientScreenshotCopiedToClipboard")
                    } catch (a) {
                        const {
                            canvas: n
                        } = await t;
                        null === (e = window.open()) || void 0 === e || e.document.write(`<img width="100%" src="${n.toDataURL()}"/>`)
                    }
                }, [n]), g = (0, s.useCallback)(async () => {
                    const e = await n();
                    (0, Ht.downloadFile)(e.name + ".png", e.canvas.toDataURL())
                }, [n]), w = e => Nt(e.then(e => e.imageUrl)), b = (0, s.useCallback)(async (e = !1) => {
                    const a = t();
                    try {
                        if (e) await w(a);
                        else {
                            const e = a.then(e => new Blob([e.imageUrl], {
                                type: "text/plain"
                            }));
                            await (0, At.writePromiseUsingApi)(e, "text/plain"), oe.emit("onServerScreenshotCopiedToClipboard")
                        }
                        return !0
                    } catch (e) {
                        return w(a), !0
                    } finally {
                        m.current && (h(!1), r(!1), (0, Re.globalCloseMenu)())
                    }
                }, [t]), C = (0, s.useCallback)(async () => {
                    d(!0);
                    const [e, n] = await Promise.all([a.e(4665).then(a.bind(a, 53885)), t()]);
                    e.Twitter.shareSnapshotInstantly(n.symbol, n.imageUrl), m.current && (d(!1), (0, Re.globalCloseMenu)())
                }, [t]);
                return s.createElement(s.Fragment, null, s.createElement(u.PopupMenuItem, {
                    "data-name": "save-chart-image",
                    label: (0, i.t)("Save chart image"),
                    icon: Ot,
                    onClick: g,
                    shortcut: (0, K.humanReadableHash)(K.Modifiers.Mod + K.Modifiers.Alt + 83),
                    theme: Vt
                }), s.createElement(u.PopupMenuItem, {
                    "data-name": "copy-chart-image",
                    label: (0, i.t)("Copy chart image"),
                    icon: Ft,
                    onClick: v,
                    shortcut: (0, K.humanReadableHash)(K.Modifiers.Mod + K.Modifiers.Shift + 83),
                    theme: Vt
                }), s.createElement(u.PopupMenuItem, {
                    "data-name": "copy-link-to-the-chart-image",
                    label: s.createElement(Lt, {
                        isLoading: o
                    }, (0, i.t)("Copy link to the chart image")),
                    icon: Pt,
                    onClick: () => {
                        r(!0), b(!1)
                    },
                    dontClosePopup: !0,
                    isDisabled: o,
                    shortcut: (0, K.humanReadableHash)(K.Modifiers.Alt + 83),
                    className: p(o && Ut.loading),
                    theme: Vt
                }), s.createElement(u.PopupMenuItem, {
                    "data-name": "open-image-in-new-tab",
                    label: s.createElement(Lt, {
                        isLoading: l
                    }, (0, i.t)("Open image in new tab")),
                    icon: Bt,
                    onClick: () => {
                        h(!0), b(!0)
                    },
                    dontClosePopup: !0,
                    isDisabled: l,
                    className: p(l && Ut.loading),
                    theme: Vt
                }), s.createElement(u.PopupMenuItem, {
                    "data-name": "tweet-chart-image",
                    label: s.createElement(Lt, {
                        isLoading: c
                    }, (0, i.t)("Tweet chart image")),
                    icon: Wt,
                    onClick: C,
                    dontClosePopup: !0,
                    isDisabled: c,
                    className: p(c && Ut.loading),
                    theme: Vt
                }))
            }
            var Kt = a(69111);

            function Zt(e) {
                const [t, a] = (0,
                    s.useState)(!1), n = (0, Dt.useIsMounted)(), o = (0, s.useCallback)(async () => {
                    a(!0), await e.serverSnapshot(), n.current && a(!1)
                }, [e.serverSnapshot]);
                return s.createElement(b.ToolWidgetButton, {
                    id: e.id,
                    className: e.className,
                    isDisabled: t,
                    onClick: o,
                    title: e.tooltip,
                    icon: e.icon
                })
            }
            var qt = a(25109);
            const Qt = (Yt = function(e) {
                return (0, Kt.isOnMobileAppPage)("any") ? s.createElement(Zt, { ...e,
                    icon: qt
                }) : s.createElement(m.ToolWidgetMenu, {
                    content: s.createElement(b.ToolWidgetButton, {
                        id: e.id,
                        className: e.className,
                        title: e.tooltip,
                        icon: qt
                    }),
                    drawerPosition: "Bottom",
                    drawerBreakpoint: k.DialogBreakpoints.TabletSmall,
                    arrow: !1,
                    onClick: function() {}
                }, s.createElement(Gt, { ...e
                }))
            }, (jt = class extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._clientSnapshot = async () => {
                        const e = this.context.chartWidgetCollection.activeChartWidget.value().model().mainSeries().actualSymbol();
                        return {
                            canvas: await this.context.chartWidgetCollection.clientSnapshot(),
                            name: `${(0,Mt.shortName)(e)}_${xt.formatLocal(new Date)}`
                        }
                    }, this._serverSnapshot = async () => {
                        const e = this.context.chartWidgetCollection.activeChartWidget.value().model().mainSeries().actualSymbol(),
                            t = await this.context.chartWidgetCollection.takeScreenshot(),
                            a = n.enabled("charting_library_base") && void 0 !== this.context.snapshotUrl ? t : (0, _t.convertImageNameToUrl)(t);
                        return {
                            symbol: (0, Mt.shortName)(e),
                            imageUrl: a
                        }
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e,
                        id: t
                    } = this.props;
                    return s.createElement(Yt, {
                        id: t,
                        className: e,
                        tooltip: Et.takeSnapshot,
                        serverSnapshot: this._serverSnapshot,
                        clientSnapshot: this._clientSnapshot
                    })
                }
            }).contextType = Tt, jt);
            var Yt, jt, Jt = a(85227),
                Xt = a(66171),
                $t = a(11411);
            class ea {
                async show(e) {
                    if (null !== ea._provider) {
                        const e = await ea._provider.getSymbol();
                        return r.linking.symbol.setValue(e.symbol), e
                    }
                    if (ea._currentShowingInstance) throw new DOMException("SymbolSearchUI is already shown", "InvalidStateError");
                    try {
                        ea._currentShowingInstance = this, ea.preload();
                        const t = await ea._implementation;
                        return (0, X.assert)(null !== t), new Promise(a => {
                            t.showDefaultSearchDialog({ ...e,
                                onSearchComplete: e => {
                                    a({
                                        symbol: e
                                    })
                                }
                            })
                        })
                    } finally {
                        ea._currentShowingInstance = null
                    }
                }
                static setProvider(e) {
                    this._provider = e
                }
                static preload() {
                    null === this._provider && null === this._implementation && (this._implementation = (0, $t.loadNewSymbolSearch)())
                }
            }
            ea._currentShowingInstance = null, ea._provider = null, ea._implementation = null;
            var ta = a(67397),
                aa = a(72597);
            const na = (0, it.mergeThemes)(b.DEFAULT_TOOL_WIDGET_BUTTON_THEME, ta);
            (0, it.mergeThemes)(na, aa);
            class sa extends s.PureComponent {
                constructor(e) {
                    super(e), this._openSymbolSearchDialog = async e => {
                        if ((0, K.modifiersFromEvent)(e) !== K.Modifiers.Alt) try {
                            (0, W.trackEvent)("GUI", "SS", "main search"), await (new ea).show({
                                defaultValue: this._isSpread(this.state.symbol) ? this.state.symbol : this.state.shortName,
                                showSpreadActions: (0, Jt.canShowSpreadActions)() && this.props.isActionsVisible,
                                source: "searchBar",
                                footer: ke.mobiletouch ? void 0 : s.createElement(Xt.SymbolSearchDialogFooter, null, (0, i.t)("Simply start typing while on the chart to pull up this search box"))
                            })
                        } catch (e) {} else navigator.clipboard.writeText(this.state.symbol)
                    }, this._isSpread = e => !1, this._onSymbolChanged = () => {
                        const e = r.linking.symbol.value();
                        this.setState({
                            symbol: e,
                            shortName: oa()
                        })
                    }, this.state = {
                        symbol: r.linking.symbol.value(),
                        shortName: oa()
                    }
                }
                componentDidMount() {
                    r.linking.symbol.subscribe(this._onSymbolChanged), r.linking.seriesShortSymbol.subscribe(this._onSymbolChanged), ea.preload()
                }
                componentWillUnmount() {
                    r.linking.symbol.unsubscribe(this._onSymbolChanged), r.linking.seriesShortSymbol.unsubscribe(this._onSymbolChanged)
                }
                render() {
                    const {
                        id: e,
                        className: t
                    } = this.props;
                    return s.createElement(b.ToolWidgetButton, {
                        id: e,
                        className: v()(t, n.enabled("uppercase_instrument_names") && ta.uppercase, ta.largeLeftPadding),
                        theme: na,
                        icon: void 0,
                        text: this.state.shortName,
                        title: (0, i.t)("Symbol Search"),
                        onClick: this._openSymbolSearchDialog
                    })
                }
                async _updateQuotes(e) {}
            }

            function oa() {
                return r.linking.seriesShortSymbol.value() || r.linking.symbol.value() || ""
            }
            var ia = a(52157);
            class ra extends s.PureComponent {
                constructor() {
                    super(...arguments), this._handleClick = e => {
                        e.stopPropagation();
                        const {
                            onApply: t,
                            item: a
                        } = this.props;
                        t(a)
                    }
                }
                render() {
                    const {
                        className: e,
                        item: t
                    } = this.props;
                    return s.createElement("div", {
                        className: p(e, ia.item, "apply-common-tooltip"),
                        onClick: this._handleClick,
                        title: t.name
                    }, s.createElement("div", {
                        className: ia.round
                    }, t.name.length > 0 ? t.name[0].toUpperCase() : " "))
                }
            }
            var la = a(64545),
                ha = a(75668);

            function ca(e) {
                return s.createElement("div", {
                    className: p(ha.description, e.className)
                }, e.children)
            }
            var da = a(14621);
            const ua = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    labelRow: da.labelRow,
                    toolbox: da.toolbox,
                    item: da.titleItem
                }),
                ma = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    labelRow: da.labelRow,
                    toolbox: da.toolbox,
                    item: da.titleItemTabletSmall
                }),
                pa = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    item: da.item
                }),
                va = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    item: da.itemTabletSmall
                });

            function ga(e) {
                const {
                    item: t,
                    onApply: a,
                    onRemove: n,
                    onFavor: o,
                    favorite: i,
                    isFavoritingAllowed: r,
                    isTabletSmall: l
                } = e, [h, d] = (0, _e.useHover)(), m = t.meta_info, p = m ? (0, la.descriptionString)(m.indicators) : void 0, g = l ? ma : ua, w = l ? va : pa, b = (0, s.useCallback)(() => a(t), [a, t]), C = (0, s.useCallback)(() => n(t), [n, t]), S = (0, s.useCallback)(() => {
                    o && o(t)
                }, [o, t]);
                return s.createElement("div", { ...d,
                    className: da.wrap,
                    "data-name": t.name,
                    "data-id": t.id,
                    "data-is-default": Boolean(t.is_default)
                }, s.createElement(u.PopupMenuItem, {
                    theme: g,
                    label: t.name,
                    labelRowClassName: v()(l && da.itemLabelTabletSmall),
                    isHovered: h,
                    showToolboxOnHover: !i && !h,
                    onClick: b,
                    toolbox: s.createElement(s.Fragment, null, !t.is_default && s.createElement(fe.RemoveButton, {
                        key: "remove",
                        hidden: !ke.touch && !h,
                        onClick: C
                    }), Boolean(o) && r && s.createElement(c.FavoriteButton, {
                        key: "favorite",
                        isFilled: Boolean(i),
                        onClick: S
                    }))
                }), p && s.createElement(u.PopupMenuItem, {
                    theme: w,
                    label: s.createElement(ca, {
                        className: v()(da.description, l && da.descriptionTabletSmall)
                    }, p),
                    onClick: b,
                    isHovered: h
                }))
            }
            var wa = a(82954),
                ba = a(41939);
            const Ca = (0, it.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, ba),
                Sa = {
                    text: (0, ct.appendEllipsis)((0, i.t)("Save Indicator template"))
                };

            function ya(e) {
                const {
                    onClick: t,
                    isTabletSmall: a
                } = e;
                return s.createElement(u.PopupMenuItem, {
                    theme: Ca,
                    className: ba.wrap,
                    label: s.createElement("div", {
                        className: ba.titleWrap
                    }, s.createElement("div", {
                        className: v()(ba.title, a && ba.titleTabletSmall)
                    }, s.createElement(d.Icon, {
                        className: ba.icon,
                        icon: wa
                    }), s.createElement("div", {
                        className: ba.text
                    }, Sa.text))),
                    onClick: t
                })
            }
            var fa = a(85938),
                _a = a(30553);
            const ka = s.createContext(null);
            var Ma = a(89227);

            function xa(e) {
                const {
                    templates: t,
                    favorites: a,
                    onTemplateSave: n,
                    onTemplateRemove: o,
                    onTemplateSelect: i,
                    onTemplateFavorite: r,
                    isTabletSmall: l,
                    isLoading: h
                } = e, c = (0, s.useMemo)(() => t.filter(e => e.is_default), [t]), d = (0, s.useMemo)(() => t.filter(e => !e.is_default), [t]), u = (0, s.useMemo)(() => new Set(a.map(e => e.name)), [a]), m = (0, s.useContext)(ka), p = (0, s.useContext)(_a.MenuContext), g = (0, fa.useForceUpdate)();
                (0, s.useEffect)(() => {
                    if (null !== m) {
                        const e = {};
                        return m.getOnChange().subscribe(e, () => {
                            g(), p && p.update()
                        }), () => m.getOnChange().unsubscribeAll(e)
                    }
                    return () => {}
                }, []);
                const w = e => s.createElement(ga, {
                    key: e.name,
                    item: e,
                    isFavoritingAllowed: Boolean(r),
                    favorite: u.has(e.name),
                    onApply: i,
                    onFavor: r,
                    onRemove: o,
                    isTabletSmall: l
                });
                return s.createElement("div", {
                    className: v()(Ma.menu, l && Ma.menuSmallTablet)
                }, s.createElement(ya, {
                    onClick: n,
                    isTabletSmall: l
                }), h && s.createElement(s.Fragment, null, s.createElement(f.PopupMenuSeparator, null), s.createElement(ne.ToolWidgetMenuSpinner, null)), !h && (l ? s.createElement(Ea, {
                    defaults: c,
                    customs: d,
                    render: w
                }) : s.createElement(Ta, {
                    defaults: c,
                    customs: d,
                    render: w,
                    state: m
                })))
            }

            function Ea(e) {
                const {
                    defaults: t,
                    customs: a,
                    render: n
                } = e;
                return s.createElement(s.Fragment, null, a.length > 0 && s.createElement(s.Fragment, null, s.createElement(f.PopupMenuSeparator, null), s.createElement(se.ToolWidgetMenuSummary, {
                    className: Ma.menuItemHeaderTabletSmall
                }, (0, i.t)("My templates")), a.map(n)), t.length > 0 && s.createElement(s.Fragment, null, s.createElement(f.PopupMenuSeparator, null), s.createElement(se.ToolWidgetMenuSummary, {
                    className: Ma.menuItemHeaderTabletSmall
                }, (0, i.t)("Default templates")), t.map(n)))
            }

            function Ta(e) {
                const {
                    defaults: t,
                    customs: a,
                    render: n,
                    state: o
                } = e;
                return s.createElement(s.Fragment, null, a.length > 0 && s.createElement(s.Fragment, null, s.createElement(f.PopupMenuSeparator, null), s.createElement(se.ToolWidgetMenuSummary, {
                    className: Ma.menuItemHeader
                }, (0, i.t)("My templates")), a.map(n)), a.length > 0 && t.length > 0 && o && s.createElement(s.Fragment, null, s.createElement(f.PopupMenuSeparator, null), s.createElement(Ie.CollapsibleSection, {
                    summary: (0, i.t)("Default templates"),
                    open: !o.get().defaultsCollapsed,
                    onStateChange: e => o.set({
                        defaultsCollapsed: !e
                    })
                }, t.map(n))), 0 === a.length && t.length > 0 && s.createElement(s.Fragment, null, s.createElement(f.PopupMenuSeparator, null), s.createElement(se.ToolWidgetMenuSummary, {
                    className: Ma.menuItemHeader
                }, (0, i.t)("Default templates")), t.map(n)))
            }
            var Ia = a(94489),
                Na = a.n(Ia);
            class Aa {
                constructor(e, t) {
                    var a, s;
                    this._isFavoriteEnabled = n.enabled("items_favoriting"), this.handleFavorTemplate = e => {
                        if (!this._isFavoriteEnabled) return;
                        const {
                            name: t
                        } = e
                        ;
                        this._isTemplateFavorite(t) ? this._removeFavoriteTemplate(t) : this._addFavoriteTemplate(t)
                    }, this.handleDropdownOpen = () => {
                        this._setState({
                            isLoading: !0
                        }), this._studyTemplates.invalidate(), this._studyTemplates.refreshStudyTemplateList(() => this._setState({
                            isLoading: !1
                        }))
                    }, this.handleApplyTemplate = e => {
                        this._studyTemplates.applyTemplate(e.name)
                    }, this.handleRemoveTemplate = e => {
                        this._studyTemplates.deleteStudyTemplate(e.name)
                    }, this.handleSaveTemplate = () => {
                        this._studyTemplates.showSaveAsDialog()
                    }, this._studyTemplates = e, this._favoriteStudyTemplatesService = t;
                    const o = (null === (a = this._favoriteStudyTemplatesService) || void 0 === a ? void 0 : a.get()) || [],
                        i = this._studyTemplates.list();
                    this._state = new(Na())({
                        isLoading: !1,
                        studyTemplatesList: i,
                        favorites: o
                    }), this._studyTemplates.getOnChange().subscribe(this, this._handleTemplatesChange), this._studyTemplates.refreshStudyTemplateList(), this._isFavoriteEnabled && (null === (s = this._favoriteStudyTemplatesService) || void 0 === s || s.getOnChange().subscribe(this, this._handleFavoritesChange))
                }
                destroy() {
                    var e;
                    this._studyTemplates.getOnChange().unsubscribe(this, this._handleTemplatesChange), this._isFavoriteEnabled && (null === (e = this._favoriteStudyTemplatesService) || void 0 === e || e.getOnChange().unsubscribe(this, this._handleFavoritesChange))
                }
                state() {
                    return this._state.readonly()
                }
                _setState(e) {
                    this._state.setValue({ ...this._state.value(),
                        ...e
                    })
                }
                _handleTemplatesChange() {
                    this._setState({
                        studyTemplatesList: this._studyTemplates.list()
                    })
                }
                _handleFavoritesChange(e) {
                    this._isFavoriteEnabled && this._setState({
                        favorites: e
                    })
                }
                _removeFavoriteTemplate(e) {
                    var t;
                    const {
                        favorites: a
                    } = this._state.value();
                    null === (t = this._favoriteStudyTemplatesService) || void 0 === t || t.set(a.filter(t => t !== e))
                }
                _addFavoriteTemplate(e) {
                    var t;
                    const {
                        favorites: a
                    } = this._state.value();
                    null === (t = this._favoriteStudyTemplatesService) || void 0 === t || t.set([...a, e])
                }
                _isTemplateFavorite(e) {
                    const {
                        favorites: t
                    } = this._state.value();
                    return t.includes(e)
                }
            }
            var Ha = a(33279),
                Ra = a(73887);
            const za = {
                    title: (0, i.t)("Templates"),
                    tooltip: (0, i.t)("Indicator Templates")
                },
                La = (0, x.registryContextType)();
            class Da extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._updateState = e => {
                        this.setState({ ...e,
                            isActive: this.state.isActive
                        })
                    }, this._handleApplyTemplate = e => {
                        this._handleClose(), this._model.handleApplyTemplate(e)
                    }, this._handleRemoveTemplate = e => {
                        this._handleClose(), this._model.handleRemoveTemplate(e)
                    }, this._handleClose = () => {
                        this._handleToggleDropdown(!1)
                    }, this._handleToggleDropdown = e => {
                        const {
                            isActive: t
                        } = this.state, a = "boolean" == typeof e ? e : !t;
                        this.setState({
                            isActive: a
                        })
                    }, (0, x.validateRegistry)(t, {
                        favoriteStudyTemplatesService: o.any,
                        studyTemplates: o.any.isRequired,
                        templatesMenuViewStateService: o.any
                    });
                    const {
                        favoriteStudyTemplatesService: a,
                        studyTemplates: n
                    } = t;
                    this._model = new Aa(n, a), this.state = { ...this._model.state().value(),
                        isActive: !1
                    }
                }
                componentDidMount() {
                    this._model.state().subscribe(this._updateState)
                }
                componentWillUnmount() {
                    this._model.state().unsubscribe(this._updateState), this._model.destroy()
                }
                render() {
                    const {
                        studyTemplatesList: e,
                        favorites: t
                    } = this.state, {
                        isShownQuicks: a,
                        className: n,
                        displayMode: o,
                        id: i
                    } = this.props;
                    return s.createElement(ka.Provider, {
                        value: this.context.templatesMenuViewStateService || null
                    }, s.createElement(Wa, {
                        id: i,
                        className: n,
                        mode: o,
                        templates: e,
                        favorites: t,
                        onMenuOpen: this._model.handleDropdownOpen,
                        onTemplateFavorite: a ? this._model.handleFavorTemplate : void 0,
                        onTemplateSelect: this._handleApplyTemplate,
                        onTemplateRemove: this._handleRemoveTemplate,
                        onTemplateSave: this._model.handleSaveTemplate
                    }))
                }
            }

            function Wa(e) {
                const {
                    id: t,
                    className: a,
                    mode: n,
                    favorites: o,
                    templates: i,
                    isMenuOpen: r,
                    onTemplateSelect: l,
                    onTemplateSave: h,
                    onTemplateFavorite: c,
                    onTemplateRemove: d
                } = e, u = v()(a, Ra.wrap, {
                    [Ra.full]: "full" === n,
                    [Ra.medium]: "medium" === n
                }), p = i.filter(e => o.includes(e.name)), g = "small" !== n && c && p.length > 0;
                return s.createElement(w, {
                    id: t,
                    className: u
                }, s.createElement(_.MatchMedia, {
                    rule: k.DialogBreakpoints.TabletSmall
                }, t => s.createElement(m.ToolWidgetMenu, {
                    onOpen: e.onMenuOpen,
                    isDrawer: t,
                    drawerPosition: "Bottom",
                    arrow: !1,
                    content: s.createElement(D, {
                        className: v()(g && Ra.buttonWithFavorites),
                        displayMode: n,
                        isOpened: r,
                        icon: Ha,
                        text: F.hasNewHeaderToolbarStyles ? void 0 : za.title,
                        title: za.tooltip,
                        forceInteractive: !0,
                        collapseWhen: F.hasNewHeaderToolbarStyles ? ["full", "medium", "small"] : void 0
                    }),
                    onClick: b
                }, s.createElement(xa, {
                    onTemplateSave: h,
                    onTemplateSelect: l,
                    onTemplateRemove: d,
                    onTemplateFavorite: c,
                    templates: i,
                    favorites: p,
                    isTabletSmall: t
                }))), g && s.createElement(Fa, {
                    favorites: p,
                    onTemplateSelect: function(e) {
                        l(e), b()
                    }
                }));

                function b() {
                    0
                }
            }

            function Fa(e) {
                return s.createElement(s.Fragment, null, e.favorites.map((t, a, n) => s.createElement(ra, {
                    key: t.name,
                    item: t,
                    onApply: e.onTemplateSelect,
                    className: v()({
                        [Ra.first]: 0 === a,
                        [Ra.last]: a === n.length - 1
                    })
                })))
            }
            Da.contextType = La;
            a(35897);
            var Oa = a(4039),
                Pa = a(82559),
                Ba = a(55576),
                Ua = a(13940),
                Va = a(70639);
            const Ga = {
                    undoHint: (0, i.t)("Undo {hint}"),
                    redoHint: (0, i.t)("Redo {hint}")
                },
                Ka = {
                    undoHotKey: (0, G.hotKeySerialize)({
                        keys: [(0, K.humanReadableModifiers)(K.Modifiers.Mod, !1), "Z"],
                        text: "{0} + {1}"
                    }),
                    redoHotKey: (0, G.hotKeySerialize)({
                        keys: [(0, K.humanReadableModifiers)(K.Modifiers.Mod, !1), "Y"],
                        text: "{0} + {1}"
                    })
                },
                Za = (0, it.weakComposeClasses)(Ba, Oa, {
                    buttonUndo: "button",
                    buttonRedo: "button"
                }),
                qa = (0, it.mergeThemes)(Ba, Pa),
                Qa = { ...Ba,
                    button: Za.buttonUndo
                },
                Ya = { ...Ba,
                    button: Za.buttonRedo
                },
                ja = (0, x.registryContextType)();
            class Ja extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._batched = null, this._handleClickUndo = () => {
                        (0, W.trackEvent)("GUI", "Undo");
                        const {
                            chartWidgetCollection: e
                        } = this.context;
                        e.undoHistory.undo()
                    }, this._handleClickRedo = () => {
                        (0, W.trackEvent)("GUI", "Redo");
                        const {
                            chartWidgetCollection: e
                        } = this.context;
                        e.undoHistory.redo()
                    }, (0, x.validateRegistry)(t, {
                        chartWidgetCollection: o.any.isRequired
                    }), this.state = this._getStateFromUndoHistory()
                }
                componentDidMount() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    e.undoHistory.redoStack().onChange().subscribe(this, this._onChangeStack), e.undoHistory.undoStack().onChange().subscribe(this, this._onChangeStack)
                }
                componentWillUnmount() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    e.undoHistory.redoStack().onChange().unsubscribe(this, this._onChangeStack), e.undoHistory.undoStack().onChange().unsubscribe(this, this._onChangeStack), this._batched = null
                }
                render() {
                    const {
                        id: e
                    } = this.props, {
                        isEnabledRedo: t,
                        isEnabledUndo: a,
                        redoStack: n,
                        undoStack: o
                    } = this.state;
                    return s.createElement(w, {
                        id: e
                    }, s.createElement(b.ToolWidgetButton, {
                        icon: Ua,
                        isDisabled: !a,
                        onClick: this._handleClickUndo,
                        title: a ? Ga.undoHint.format({
                            hint: o
                        }) : void 0,
                        "data-tooltip-hotkey": a ? Ka.undoHotKey : void 0,
                        theme: F.hasNewHeaderToolbarStyles ? qa : Qa
                    }), s.createElement(b.ToolWidgetButton, {
                        icon: Va,
                        isDisabled: !t,
                        onClick: this._handleClickRedo,
                        title: t ? Ga.redoHint.format({
                            hint: n
                        }) : void 0,
                        "data-tooltip-hotkey": t ? Ka.redoHotKey : void 0,
                        theme: F.hasNewHeaderToolbarStyles ? qa : Ya
                    }))
                }
                _onChangeStack() {
                    null === this._batched && (this._batched = Promise.resolve().then(() => {
                        if (null === this._batched) return;
                        this._batched = null;
                        const e = this._getStateFromUndoHistory();
                        this.setState(e)
                    }))
                }
                _getStateFromUndoHistory() {
                    const {
                        chartWidgetCollection: e
                    } = this.context, t = e.undoHistory.undoStack(), a = e.undoHistory.redoStack(), n = a.head(), s = t.head();
                    return {
                        isEnabledRedo: !a.isEmpty(),
                        isEnabledUndo: !t.isEmpty(),
                        redoStack: n ? n.text().translatedText() : "",
                        undoStack: s ? s.text().translatedText() : ""
                    }
                }
            }
            Ja.contextType = ja;
            var Xa = a(44923);

            function $a(e) {
                const {
                    className: t,
                    text: a
                } = e;
                return s.createElement("div", {
                    className: v()(Xa.title, t)
                }, a)
            }
            var en = a(85693);

            function tn(e) {
                const {
                    title: t,
                    children: a,
                    isSmallWidth: n,
                    separator: o
                } = e;
                return s.createElement("div", {
                    className: p(en.row, n && en.smallRow)
                }, s.createElement("div", {
                    className: en.rowInner
                }, s.createElement("div", {
                    className: p(en.rowLabel, n && en.smallRowLabel)
                }, t), s.createElement("div", {
                    className: en.rowButtons
                }, a)), o)
            }
            class an extends s.PureComponent {
                constructor() {
                    super(...arguments), this._handleClick = () => {
                        const {
                            layout: e,
                            onClick: t
                        } = this.props;
                        t(e)
                    }
                }
                render() {
                    const {
                        isActive: e,
                        icon: t,
                        isSmallWidth: a
                    } = this.props;
                    return s.createElement("div", {
                        className: p(en.layoutButtonWrap, a && en.smallWidth)
                    }, s.createElement("div", {
                        className: p(en.layoutButton, e && en.isActive, a && en.smallWidthLayoutButton),
                        onClick: this._handleClick
                    }, s.createElement(d.Icon, {
                        icon: t
                    })))
                }
            }
            const nn = {
                s: a(90503),
                "1-2": a(76660),
                "1-3": a(67856),
                "1-4": a(82517),
                "2-1": a(85341),
                "2-2": a(1413),
                "2h": a(17018),
                "2v": a(11141),
                "3h": a(84626),
                "3r": a(20814),
                "3s": a(24046),
                "3v": a(79849),
                4: a(76983),
                "4h": a(68155),
                "4s": a(44475),
                "4v": a(82991),
                "5s": a(56114),
                6: a(81805),
                "6c": a(24129),
                8: a(20321),
                "8c": a(94400)
            };
            var sn = a(5146),
                on = a(33626);

            function rn(e) {
                const {
                    onClick: t,
                    label: a,
                    hint: n,
                    isChecked: o,
                    isLabelCentered: i
                } = e;
                return s.createElement("div", {
                    className: p(sn.toggler, {
                        [sn.checked]: o
                    }),
                    onClick: t
                }, s.createElement("div", {
                    className: p(sn.label, {
                        [sn.centered]: i
                    })
                }, a), s.createElement(d.Icon, {
                    className: "apply-common-tooltip",
                    title: n,
                    icon: on
                }))
            }
            class ln extends s.PureComponent {
                constructor(e) {
                    super(e), this._onChange = () => {
                        this.setState({
                            isChecked: this.props.watchedValue.value()
                        })
                    }, this._handleClick = () => {
                        const {
                            onClick: e,
                            watchedValue: t
                        } = this.props;
                        e(t)
                    }, this.state = {
                        isChecked: this.props.watchedValue.value()
                    }
                }
                componentDidMount() {
                    this.props.watchedValue.subscribe(this._onChange)
                }
                componentWillUnmount() {
                    this.props.watchedValue.unsubscribe(this._onChange)
                }
                render() {
                    const {
                        label: e,
                        hint: t,
                        isLabelCentered: a,
                        isSwitch: n,
                        value: o
                    } = this.props, {
                        isChecked: i
                    } = this.state;
                    return n && o ? s.createElement(rt.MenuItemSwitcher, {
                        theme: ht,
                        label: e,
                        checked: i,
                        value: o,
                        onChange: this._handleClick
                    }) : s.createElement(rn, {
                        label: e,
                        hint: t,
                        isChecked: i,
                        isLabelCentered: a,
                        onClick: this._handleClick
                    })
                }
            }
            var hn = a(56241);
            const cn = [{
                    layouts: ["s"],
                    title: "1"
                }, {
                    layouts: ["2h", "2v"],
                    title: "2"
                }, {
                    layouts: ["3v", "3h", "3s", "2-1", "1-2", "3r"],
                    title: "3"
                }, {
                    layouts: ["4", "4h", "4v", "4s", "1-3", "2-2"],
                    title: "4"
                }, {
                    layouts: ["1-4", "5s"],
                    title: "5"
                }, {
                    layouts: ["6", "6c"],
                    title: "6"
                }, {
                    layouts: ["8", "8c"],
                    title: "8"
                }],
                dn = {
                    layoutType: (0, i.t)("Layout type"),
                    syncGroupTitle: (0, i.t)("Sync in layout"),
                    syncCrosshairLabel: (0, i.t)("Crosshair"),
                    syncCrosshairHint: (0, i.t)("Crosshair is synced across all charts of the layout"),
                    syncIntervalLabel: (0, i.t)("Interval"),
                    syncIntervalHint: (0, i.t)("Interval changes on all charts of the layout simultaneously"),
                    syncDateRangeLabel: (0, i.t)("Date range"),
                    syncDateRangeHint: (0, i.t)("Date range changes on all chart of the layout simultaneously"),
                    syncSymbolLabel: (0, i.t)("Symbol"),
                    syncSymbolHint: (0, i.t)("Symbol changes on all charts of the layout simultaneously"),
                    syncTrackLabel: (0, i.t)("Time"),
                    syncTrackHint: (0, i.t)("When clicked on a single chart others get scrolled to display the same point on time axis")
                };
            class un extends s.PureComponent {
                constructor(e) {
                    super(e), this._handleSyncSymbol = e => {
                        const t = !e.value();
                        this.props.chartWidgetCollection.lock.setSymbolLockWithUndo(t)
                    }, this._handleSyncInterval = e => {
                        const t = !e.value();
                        this.props.chartWidgetCollection.lock.setIntervalLockWithUndo(t)
                    }, this._handleSyncDateRange = e => {
                        const t = !e.value();
                        this.props.chartWidgetCollection.lock.setDateRangeLockWithUndo(t)
                    }, this._handleSyncCrosshair = e => {
                        const t = !e.value();
                        e.setValue(t)
                    }, this._handleSyncTrack = e => {
                        const t = !e.value();
                        this.props.chartWidgetCollection.lock.setTrackTimeWithUndo(t)
                    }, this._handleClickLayout = e => {
                        (0, Re.globalCloseMenu)(), this.props.chartWidgetCollection.layout.value() === e ? this.props.chartWidgetCollection.revertToInline() : this.props.chartWidgetCollection.setChartLayoutWithUndo(e)
                    }, this._onUpdateLayout = e => {
                        this.setState({
                            currentId: e || this.props.chartWidgetCollection.layout.value()
                        })
                    }, this.state = {
                        currentId: "s"
                    }
                }
                componentDidMount() {
                    this.props.chartWidgetCollection.layout.subscribe(this._onUpdateLayout, {
                        callWithLast: !0
                    })
                }
                componentWillUnmount() {
                    this.props.chartWidgetCollection.layout.unsubscribe(this._onUpdateLayout)
                }
                render() {
                    const {
                        isSmallWidth: e
                    } = this.props;
                    return s.createElement("div", {
                        className: hn.dropdown
                    }, s.createElement("div", null, this._renderLayoutList(e)), s.createElement("div", null, e && s.createElement(f.PopupMenuSeparator, {
                        size: "normal"
                    })), s.createElement("div", null, e ? s.createElement($a, {
                        text: dn.syncGroupTitle,
                        className: hn.syncCharts
                    }) : s.createElement("div", {
                        className: p(hn.title, e && [hn.tabletTitle, hn.syncCharts])
                    }, dn.syncGroupTitle), e ? this._renderSyncList() : this._renderSyncTable()))
                }
                _renderLayoutList(e) {
                    const {
                        currentId: t
                    } = this.state;
                    return s.createElement("div", null, e && s.createElement($a, {
                        text: dn.layoutType
                    }), cn.map((a, n) => s.createElement(tn, {
                        key: a.title,
                        isSmallWidth: e,
                        title: a.title,
                        separator: n !== cn.length - 1 && s.createElement(f.PopupMenuSeparator, null)
                    }, a.layouts.map(a => s.createElement(an, {
                        key: a,
                        layout: a,
                        icon: nn[a],
                        onClick: this._handleClickLayout,
                        isActive: a === t,
                        isSmallWidth: e
                    })))))
                }
                _renderSyncList() {
                    return s.createElement("div", {
                        className: hn.syncListWrapper
                    }, s.createElement(ln, {
                        isSwitch: !0,
                        label: dn.syncSymbolLabel,
                        onClick: this._handleSyncSymbol,
                        value: "syncSymbolLabel",
                        watchedValue: this.props.chartWidgetCollection.lock.symbol
                    }), s.createElement(ln, {
                        isSwitch: !0,
                        label: dn.syncIntervalLabel,
                        onClick: this._handleSyncInterval,
                        value: "syncIntervalLabel",
                        watchedValue: this.props.chartWidgetCollection.lock.interval
                    }), s.createElement(ln, {
                        isSwitch: !0,
                        label: dn.syncCrosshairLabel,
                        watchedValue: this.props.chartWidgetCollection.lock.crosshair,
                        value: "syncCrosshairLabel",
                        onClick: this._handleSyncCrosshair
                    }), s.createElement(ln, {
                        isSwitch: !0,
                        label: dn.syncTrackLabel,
                        watchedValue: this.props.chartWidgetCollection.lock.trackTime,
                        value: "syncTrackLabel",
                        onClick: this._handleSyncTrack
                    }), s.createElement(ln, {
                        isSwitch: !0,
                        label: dn.syncDateRangeLabel,
                        onClick: this._handleSyncDateRange,
                        value: "syncDateRangeLabel",
                        watchedValue: this.props.chartWidgetCollection.lock.dateRange
                    }))
                }
                _renderSyncTable() {
                    return s.createElement("table", {
                        className: hn.syncTable
                    }, s.createElement("tbody", null, s.createElement("tr", null, s.createElement("td", null, s.createElement(ln, {
                        label: dn.syncSymbolLabel,
                        hint: dn.syncSymbolHint,
                        watchedValue: this.props.chartWidgetCollection.lock.symbol,
                        onClick: this._handleSyncSymbol
                    })), s.createElement("td", null, s.createElement(ln, {
                        label: dn.syncIntervalLabel,
                        hint: dn.syncIntervalHint,
                        watchedValue: this.props.chartWidgetCollection.lock.interval,
                        onClick: this._handleSyncInterval
                    }))), s.createElement("tr", null, s.createElement("td", null, s.createElement(ln, {
                        label: dn.syncCrosshairLabel,
                        hint: dn.syncCrosshairHint,
                        watchedValue: this.props.chartWidgetCollection.lock.crosshair,
                        onClick: this._handleSyncCrosshair
                    })), s.createElement("td", null, s.createElement(ln, {
                        label: dn.syncTrackLabel,
                        hint: dn.syncTrackHint,
                        watchedValue: this.props.chartWidgetCollection.lock.trackTime,
                        onClick: this._handleSyncTrack
                    }))), s.createElement("tr", null, s.createElement("td", {
                        colSpan: 2
                    }, s.createElement(ln, {
                        label: dn.syncDateRangeLabel,
                        hint: dn.syncDateRangeHint,
                        watchedValue: this.props.chartWidgetCollection.lock.dateRange,
                        onClick: this._handleSyncDateRange,
                        isLabelCentered: !0
                    })))))
                }
            }
            const mn = {
                    s: a(98569),
                    "1-2": a(59604),
                    "1-3": a(37828),
                    "1-4": a(72918),
                    "2-1": a(8793),
                    "2-2": a(79264),
                    "2h": a(93263),
                    "2v": a(315),
                    "3h": a(41806),
                    "3r": a(77370),
                    "3s": a(65942),
                    "3v": a(53750),
                    4: a(74011),
                    "4h": a(25993),
                    "4s": a(18429),
                    "4v": a(48066),
                    "5s": a(62394),
                    6: a(93464),
                    "6c": a(63670),
                    8: a(1290),
                    "8c": a(99104)
                },
                pn = {
                    hint: (0, i.t)("Select Layout")
                },
                vn = (0, x.registryContextType)();
            class gn extends s.PureComponent {
                constructor(e, t) {
                    super(e, t), this._onUpdateLayout = e => {
                            const {
                                chartWidgetCollection: t
                            } = this.context;
                            this.setState({
                                currentId: e || t.layout.value()
                            })
                        },
                        this._handleOpenLayout = () => {
                            (0, W.trackEvent)("GUI", "Chart Header Toolbar", "select layout")
                        }, (0, x.validateRegistry)(t, {
                            chartWidgetCollection: o.any.isRequired
                        }), this.state = {
                            currentId: "s"
                        }
                }
                componentDidMount() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    e.layout.subscribe(this._onUpdateLayout, {
                        callWithLast: !0
                    })
                }
                componentWillUnmount() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    e.layout.unsubscribe(this._onUpdateLayout)
                }
                render() {
                    const {
                        chartWidgetCollection: e
                    } = this.context, {
                        className: t,
                        id: a
                    } = this.props, {
                        currentId: n
                    } = this.state;
                    return s.createElement(_.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, o => s.createElement(m.ToolWidgetMenu, {
                        id: a,
                        arrow: !1,
                        content: s.createElement(d.Icon, {
                            className: hn.icon,
                            icon: mn[n]
                        }),
                        title: pn.hint,
                        className: p(t, hn.button),
                        isDrawer: o,
                        drawerPosition: "Bottom",
                        onOpen: this._handleOpenLayout
                    }, s.createElement(un, {
                        chartWidgetCollection: e,
                        isSmallWidth: o
                    })))
                }
            }
            gn.contextType = vn;
            var wn = a(87995),
                bn = a(7270);
            class Cn extends s.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._update = () => {
                        this.forceUpdate()
                    }, this._setRef = e => {
                        this._ref = e
                    }, this._handleMeasure = ({
                        width: e
                    }) => {
                        this.props.width.setValue(e)
                    }
                }
                componentDidMount() {
                    const {
                        element: e,
                        isFake: t,
                        width: a
                    } = this.props;
                    if (t) a.subscribe(this._update);
                    else {
                        const t = (0, X.ensureNotNull)(this._ref);
                        wn.findDOMNode(t).appendChild(e)
                    }
                }
                componentWillUnmount() {
                    const {
                        width: e,
                        isFake: t
                    } = this.props;
                    t && e.unsubscribe(this._update)
                }
                render() {
                    const {
                        isFake: e = !1,
                        width: t
                    } = this.props;
                    return s.createElement(bn, {
                        shouldMeasure: !e,
                        whitelist: ["width"],
                        onMeasure: this._handleMeasure
                    }, s.createElement(w, {
                        ref: this._setRef,
                        style: e ? {
                            width: t.value()
                        } : void 0,
                        "data-is-custom-header-element": !0
                    }))
                }
            }

            function Sn(e) {
                const {
                    displayMode: t,
                    params: a
                } = e;
                return s.createElement(m.ToolWidgetMenu, {
                    content: s.createElement(D, {
                        collapseWhen: void 0 !== a.icon ? void 0 : [],
                        displayMode: t,
                        icon: a.icon,
                        text: a.title,
                        title: a.tooltip,
                        "data-name": "dropdown",
                        "data-is-custom-header-element": !0
                    }),
                    drawerPosition: "Bottom",
                    drawerBreakpoint: k.DialogBreakpoints.TabletSmall,
                    arrow: !1
                }, a.items.map((e, t) => s.createElement(u.PopupMenuItem, {
                    key: t,
                    label: e.title,
                    onClick: () => e.onSelect(),
                    "data-name": "dropdown-item"
                })))
            }
            var yn = a(33191);

            function fn(e) {
                const {
                    className: t,
                    ...a
                } = e;
                return s.createElement(D, { ...a,
                    className: p(t, yn.customTradingViewStyleButton, yn.withoutIcon),
                    collapseWhen: [],
                    "data-name": "custom-tradingview-styled-button"
                })
            }

            function _n() {
                let e;
                return e = n.enabled("header_layouttoggle") ? gn : void 0, {
                    Bars: n.enabled("header_chart_type") ? R : void 0,
                    Compare: n.enabled("header_compare") ? U : void 0,
                    Custom: Cn,
                    CustomTradingViewStyledButton: fn,
                    Fullscreen: n.enabled("header_fullscreen_button") ? J : void 0,
                    Indicators: n.enabled("header_indicators") ? de : void 0,
                    Intervals: n.enabled("header_resolutions") ? Be : void 0,
                    OpenPopup: Ze,
                    Properties: n.enabled("header_settings") && n.enabled("show_chart_property_page") ? je : void 0,
                    SaveLoad: n.enabled("header_saveload") ? ft : void 0,
                    Screenshot: n.enabled("header_screenshot") ? Qt : void 0,
                    SymbolSearch: n.enabled("header_symbol_search") ? sa : void 0,
                    Templates: n.enabled("study_templates") ? Da : void 0,
                    Dropdown: Sn,
                    UndoRedo: n.enabled("header_undo_redo") ? Ja : void 0,
                    Layout: e
                }
            }
        },
        64545: (e, t, a) => {
            "use strict";
            a.d(t, {
                createStudyTemplateMetaInfo: () => s,
                descriptionString: () => o
            });
            var n = a(93065);

            function s(e, t) {
                return {
                    indicators: e.orderedDataSources(!0).filter(e => (0, n.isStudy)(e) && !0).map(e => ({
                        id: e.metaInfo().id,
                        description: e.title(!0, void 0, !0)
                    })),
                    interval: t
                }
            }

            function o(e) {
                const t = new Map;
                return e.forEach(e => {
                    const [a, n] = t.get(e.id) || [e.description, 0];
                    t.set(e.id, [a, n + 1])
                }), Array.from(t.values()).map(([e, t]) => `${e}${t>1?" x "+t:""}`).join(", ")
            }
        },
        4257: (e, t, a) => {
            "use strict";
            a.d(t, {
                hasNewHeaderToolbarStyles: () => n
            });
            a(82527);
            const n = !1
        },
        23404: (e, t, a) => {
            "use strict";
            a.d(t, {
                validateRegistry: () => r,
                RegistryProvider: () => l,
                registryContextType: () => h
            });
            var n = a(59496),
                s = a(19036),
                o = a.n(s);
            const i = n.createContext({});

            function r(e, t) {
                o().checkPropTypes(t, e, "context", "RegistryContext")
            }

            function l(e) {
                const {
                    validation: t,
                    value: a
                } = e;
                return r(a, t), n.createElement(i.Provider, {
                    value: a
                }, e.children)
            }

            function h() {
                return i
            }
        },
        93790: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                SERIES_ICONS: () => g
            });
            var n = a(2200),
                s = a(5312),
                o = a(84001),
                i = a(88320),
                r = a(51410),
                l = a(97731),
                h = a(37235),
                c = a(43892),
                d = a(4733),
                u = a(62061),
                m = a(51516),
                p = a(58539),
                v = a(13472);
            const g = {
                3: r,
                0: l,
                1: h,
                8: c,
                9: d,
                2: u,
                10: m,
                12: p,
                13: v
            };
            g[4] = n, g[6] = s, g[7] = o, g[5] = i
        },
        81076: (e, t, a) => {
            "use strict";
            a.d(t, {
                convertImageNameToUrl: () => o
            });
            var n = a(82527),
                s = a(47668);

            function o(e) {
                return n.enabled("charting_library_base") || (0, s.isProd)() ? "https://www.tradingview.com/x/" + e + "/" : window.location.protocol + "//" + window.location.host + "/x/" + e + "/"
            }
        },
        87469: (e, t, a) => {
            "use strict";

            function n(e, t) {
                const a = document.createElement("a");
                a.style.display = "none", a.href = t, a.download = e, a.click()
            }
            a.d(t, {
                downloadFile: () => n
            })
        },
        96038: (e, t, a) => {
            "use strict";
            a.d(t, {
                DialogBreakpoints: () => s
            });
            var n = a(96746);
            const s = {
                SmallHeight: n["small-height-breakpoint"],
                TabletSmall: n["tablet-small-breakpoint"],
                TabletNormal: n["tablet-normal-breakpoint"]
            }
        },
        66171: (e, t, a) => {
            "use strict";
            a.d(t, {
                SymbolSearchDialogFooter: () => r
            });
            var n = a(59496),
                s = a(97754),
                o = a.n(s),
                i = a(72142);

            function r(e) {
                const {
                    className: t,
                    children: a
                } = e;
                return n.createElement("div", {
                    className: o()(i.footer, t)
                }, a)
            }
        },
        63694: (e, t, a) => {
            "use strict";
            a.d(t, {
                DrawerManager: () => s,
                DrawerContext: () => o
            });
            var n = a(59496);
            class s extends n.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return n.createElement(o.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const o = n.createContext(null)
        },
        59339: (e, t, a) => {
            "use strict";
            a.d(t, {
                Drawer: () => m
            });
            var n = a(59496),
                s = a(88537),
                o = a(97754),
                i = a(59142),
                r = a(85089),
                l = a(8361),
                h = a(63694),
                c = a(1227),
                d = a(28466),
                u = a(66998);

            function m(e) {
                const {
                    position: t = "Bottom",
                    onClose: a,
                    children: m,
                    className: p,
                    theme: v = u
                } = e, g = (0, s.ensureNotNull)((0, n.useContext)(h.DrawerContext)), [w, b] = (0, n.useState)(0), C = (0,
                    n.useRef)(null), S = (0, n.useContext)(d.CloseDelegateContext);
                return (0, n.useEffect)(() => {
                    const e = (0, s.ensureNotNull)(C.current);
                    return e.focus({
                        preventScroll: !0
                    }), S.subscribe(g, a), 0 === g.currentDrawer && (0, r.setFixedBodyState)(!0), c.CheckMobile.iOS() && (0, i.disableBodyScroll)(e), b(g.addDrawer()), () => {
                        S.unsubscribe(g, a);
                        const t = g.removeDrawer();
                        c.CheckMobile.iOS() && (0, i.enableBodyScroll)(e), 0 === t && (0, r.setFixedBodyState)(!1)
                    }
                }, []), n.createElement(l.Portal, null, n.createElement("div", {
                    className: o(u.wrap, u["position" + t])
                }, w === g.currentDrawer && n.createElement("div", {
                    className: u.backdrop,
                    onClick: a
                }), n.createElement("div", {
                    className: o(u.drawer, v.drawer, u["position" + t], p),
                    ref: C,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, m)))
            }
        },
        77687: (e, t, a) => {
            "use strict";
            a.d(t, {
                FavoriteButton: () => d
            });
            var n = a(25177),
                s = a(59496),
                o = a(97754),
                i = a(72571),
                r = a(17110),
                l = a(6639),
                h = a(16842);
            const c = {
                add: (0, n.t)("Add to favorites"),
                remove: (0, n.t)("Remove from favorites")
            };

            function d(e) {
                const {
                    className: t,
                    isFilled: a,
                    isActive: n,
                    onClick: d,
                    ...u
                } = e;
                return s.createElement(i.Icon, { ...u,
                    className: o(h.favorite, "apply-common-tooltip", a && h.checked, n && h.active, t),
                    icon: a ? r : l,
                    onClick: d,
                    title: a ? c.remove : c.add
                })
            }
        },
        85938: (e, t, a) => {
            "use strict";
            a.d(t, {
                useForceUpdate: () => s
            });
            var n = a(59496);
            const s = () => {
                const [, e] = (0, n.useReducer)((e, t) => e + 1, 0);
                return e
            }
        },
        21258: (e, t, a) => {
            "use strict";
            a.d(t, {
                hoverMouseEventFilter: () => o,
                useAccurateHover: () => i,
                useHover: () => s
            });
            var n = a(59496);

            function s() {
                const [e, t] = (0, n.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        o(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        o(e) && t(!1)
                    }
                }]
            }

            function o(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function i(e) {
                const [t, a] = (0, n.useState)(!1);
                return (0, n.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const n = e.current.contains(t.target);
                        a(n)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        92063: (e, t, a) => {
            "use strict";
            a.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => h,
                PopupMenuItem: () => u
            });
            var n = a(59496),
                s = a(97754),
                o = a(70981),
                i = a(32133),
                r = a(417),
                l = a(23576);
            const h = l;

            function c(e) {
                const {
                    reference: t,
                    ...a
                } = e, s = { ...a,
                    ref: t
                };
                return n.createElement(e.href ? "a" : "div", s)
            }

            function d(e) {
                e.stopPropagation()
            }

            function u(e) {
                const {
                    id: t,
                    role: a,
                    "aria-selected": h,
                    className: u,
                    title: m,
                    labelRowClassName: p,
                    labelClassName: v,
                    shortcut: g,
                    forceShowShortcuts: w,
                    icon: b,
                    isActive: C,
                    isDisabled: S,
                    isHovered: y,
                    appearAsDisabled: f,
                    label: _,
                    link: k,
                    showToolboxOnHover: M,
                    target: x,
                    rel: E,
                    toolbox: T,
                    reference: I,
                    onMouseOut: N,
                    onMouseOver: A,
                    suppressToolboxClick: H = !0,
                    theme: R = l
                } = e, z = (0, r.filterDataProps)(e), L = (0, n.useRef)(null);
                return n.createElement(c, { ...z,
                    id: t,
                    role: a,
                    "aria-selected": h,
                    className: s(u, R.item, b && R.withIcon, {
                        [R.isActive]: C,
                        [R.isDisabled]: S || f,
                        [R.hovered]: y
                    }),
                    title: m,
                    href: k,
                    target: x,
                    rel: E,
                    reference: function(e) {
                        L.current = e, "function" == typeof I && I(e);
                        "object" == typeof I && (I.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: a,
                            onClick: n,
                            onClickArg: s,
                            trackEventObject: r
                        } = e;
                        if (S) return;
                        r && (0, i.trackEvent)(r.category, r.event, r.label);
                        n && n(s, t);
                        a || (0, o.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: a,
                            trackRightClick: n
                        } = e;
                        a && n && (0, i.trackEvent)(a.category, a.event, a.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: a,
                            trackMouseWheelClick: n
                        } = e;
                        if (1 === t.button && k && a) {
                            let e = a.label;
                            n && (e += "_mouseWheelClick"), (0, i.trackEvent)(a.category, a.event, e)
                        }
                    },
                    onMouseOver: A,
                    onMouseOut: N
                }, void 0 !== b && n.createElement("div", {
                    className: R.icon,
                    dangerouslySetInnerHTML: {
                        __html: b
                    }
                }), n.createElement("div", {
                    className: s(R.labelRow, p)
                }, n.createElement("div", {
                    className: s(R.label, v)
                }, _)), (void 0 !== g || w) && n.createElement("div", {
                    className: R.shortcut
                }, (D = g) && D.split("+").join(" + ")), void 0 !== T && n.createElement("div", {
                    onClick: H ? d : void 0,
                    className: s(R.toolbox, {
                        [R.showOnHover]: M
                    })
                }, T));
                var D
            }
        },
        14417: (e, t, a) => {
            "use strict";
            a.d(t, {
                multilineLabelWithIconAndToolboxTheme: () => i
            });
            var n = a(93173),
                s = a(23576),
                o = a(63095);
            const i = (0, n.mergeThemes)(s, o)
        },
        17850: (e, t, a) => {
            "use strict";
            a.d(t, {
                PopupMenuSeparator: () => r
            });
            var n = a(59496),
                s = a(97754),
                o = a.n(s),
                i = a(524);

            function r(e) {
                const {
                    size: t = "normal",
                    className: a
                } = e;
                return n.createElement("div", {
                    className: o()(i.separator, "small" === t && i.small, "normal" === t && i.normal, "large" === t && i.large, a)
                })
            }
        },
        44377: (e, t, a) => {
            "use strict";
            a.d(t, {
                PopupMenu: () => h
            });
            var n = a(59496),
                s = a(87995),
                o = a(8361),
                i = a(10618),
                r = a(28466),
                l = a(61174);

            function h(e) {
                const {
                    controller: t,
                    children: a,
                    isOpened: h,
                    closeOnClickOutside: c = !0,
                    doNotCloseOn: d,
                    onClickOutside: u,
                    onClose: m,
                    ...p
                } = e, v = (0, n.useContext)(r.CloseDelegateContext), g = (0, l.useOutsideEvent)({
                    handler: function(e) {
                        u && u(e);
                        if (!c) return;
                        if (d && e.target instanceof Node) {
                            const t = s.findDOMNode(d);
                            if (t instanceof Node && t.contains(e.target)) return
                        }
                        m()
                    },
                    mouseDown: !0,
                    touchStart: !0
                });
                return h ? n.createElement(o.Portal, {
                    top: "0",
                    left: "0",
                    right: "0",
                    bottom: "0",
                    pointerEvents: "none"
                }, n.createElement("span", {
                    ref: g,
                    style: {
                        pointerEvents: "auto"
                    }
                }, n.createElement(i.Menu, { ...p,
                    onClose: m,
                    onScroll: function(t) {
                        const {
                            onScroll: a
                        } = e;
                        a && a(t)
                    },
                    customCloseDelegate: v,
                    ref: t
                }, a))) : null
            }
        },
        15783: (e, t, a) => {
            "use strict";
            a.d(t, {
                ToolWidgetCaret: () => l
            });
            var n = a(59496),
                s = a(97754),
                o = a(72571),
                i = a(40367),
                r = a(21538);

            function l(e) {
                const {
                    dropped: t,
                    className: a
                } = e;
                return n.createElement(o.Icon, {
                    className: s(a, i.icon, {
                        [i.dropped]: t
                    }),
                    icon: r
                })
            }
        },
        93173: (e, t, a) => {
            "use strict";

            function n(e, t, a = {}) {
                const n = Object.assign({}, t);
                for (const s of Object.keys(t)) {
                    const o = a[s] || s;
                    o in e && (n[s] = [e[o], t[s]].join(" "))
                }
                return n
            }

            function s(e, t, a = {}) {
                return Object.assign({}, e, n(e, t, a))
            }
            a.d(t, {
                weakComposeClasses: () => n,
                mergeThemes: () => s
            })
        },
        83522: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M8.5 6A2.5 2.5 0 0 0 6 8.5V11h1V8.5C7 7.67 7.67 7 8.5 7H11V6H8.5zM6 17v2.5A2.5 2.5 0 0 0 8.5 22H11v-1H8.5A1.5 1.5 0 0 1 7 19.5V17H6zM19.5 7H17V6h2.5A2.5 2.5 0 0 1 22 8.5V11h-1V8.5c0-.83-.67-1.5-1.5-1.5zM22 19.5V17h-1v2.5c0 .83-.67 1.5-1.5 1.5H17v1h2.5a2.5 2.5 0 0 0 2.5-2.5z"/></svg>'
        },
        50275: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M8.5 6A2.5 2.5 0 0 0 6 8.5v11A2.5 2.5 0 0 0 8.5 22h11a2.5 2.5 0 0 0 2.5-2.5v-3h-1v3c0 .83-.67 1.5-1.5 1.5h-11A1.5 1.5 0 0 1 7 19.5v-11C7 7.67 7.67 7 8.5 7h3V6h-3zm7 1h4.8l-7.49 7.48.71.7L21 7.72v4.79h1V6h-6.5v1z"/></svg>'
        },
        21538: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 8" width="16" height="8"><path fill="currentColor" d="M0 1.475l7.396 6.04.596.485.593-.49L16 1.39 14.807 0 7.393 6.122 8.58 6.12 1.186.08z"/></svg>'
        },
        51410: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M12.5 17.207L18.707 11h2l3.647-3.646-.708-.708L20.293 10h-2L12.5 15.793l-3-3-4.854 4.853.708.708L9.5 14.207z"/><path d="M9 16h1v1H9zm1 1h1v1h-1zm-1 1h1v1H9zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1H9zm2 0h1v1h-1zm-3-3h1v1H8zm-1 1h1v1H7zm-1 1h1v1H6zm2 0h1v1H8zm-1 1h1v1H7zm-2 0h1v1H5zm17-9h1v1h-1zm1-1h1v1h-1zm0 2h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-5-7h1v1h-1zm2 0h1v1h-1zm1-1h1v1h-1zm-2 2h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-2-6h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-3-3h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1z"/></svg>'
        },
        97731: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="none" stroke="currentColor" stroke-linecap="square"><path d="M10.5 7.5v15M7.5 20.5H10M13.5 11.5H11M19.5 6.5v15M16.5 9.5H19M22.5 16.5H20"/></g></svg>'
        },
        51516: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="none" stroke="currentColor"><path stroke-dasharray="1,1" d="M4 14.5h22"/><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 12.5l2-4 1 2 2-4 3 6"/><path stroke-linecap="round" d="M5.5 16.5l-1 2"/><path stroke-linecap="round" stroke-linejoin="round" d="M17.5 16.5l2 4 2-4m2-4l1-2-1 2z"/></g></svg>'
        },
        37235: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M17 11v6h3v-6h-3zm-.5-1h4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5z"/><path d="M18 7h1v3.5h-1zm0 10.5h1V21h-1z"/><path d="M9 8v12h3V8H9zm-.5-1h4a.5.5 0 0 1 .5.5v13a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-13a.5.5 0 0 1 .5-.5z"/><path d="M10 4h1v3.5h-1zm0 16.5h1V24h-1z"/></svg>'
        },
        82954: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none"><path stroke="currentColor" d="M11 20.5H7.5a5 5 0 1 1 .42-9.98 7.5 7.5 0 0 1 14.57 2.1 4 4 0 0 1-1 7.877H18"/><path stroke="currentColor" d="M14.5 24V12.5M11 16l3.5-3.5L18 16"/></g></svg>'
        },
        13472: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M12 7v14h5V7h-5Zm4 1h-3v12h3V8ZM19 15v6h5v-6h-5Zm4 1h-3v4h3v-4ZM5 12h5v9H5v-9Zm1 1h3v7H6v-7Z"/></svg>'
        },
        32887: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M13.5 6a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM4 14.5a9.5 9.5 0 1 1 19 0 9.5 9.5 0 0 1-19 0z"/><path fill="currentColor" d="M9 14h4v-4h1v4h4v1h-4v4h-1v-4H9v-1z"/></svg>'
        },
        77208: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path d="M21 7v4h1V6h-5v1z"/><path d="M16.854 11.854l5-5-.708-.708-5 5zM7 7v4H6V6h5v1z"/><path d="M11.146 11.854l-5-5 .708-.708 5 5zM21 21v-4h1v5h-5v-1z"/><path d="M16.854 16.146l5 5-.708.708-5-5z"/><g><path d="M7 21v-4H6v5h5v-1z"/><path d="M11.146 16.146l-5 5 .708.708 5-5z"/></g></g></svg>'
        },
        43892: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M9 8v12h3V8H9zm-1-.502C8 7.223 8.215 7 8.498 7h4.004c.275 0 .498.22.498.498v13.004a.493.493 0 0 1-.498.498H8.498A.496.496 0 0 1 8 20.502V7.498z"/><path d="M10 4h1v3.5h-1z"/><path d="M17 6v6h3V6h-3zm-1-.5c0-.276.215-.5.498-.5h4.004c.275 0 .498.23.498.5v7c0 .276-.215.5-.498.5h-4.004a.503.503 0 0 1-.498-.5v-7z"/><path d="M18 2h1v3.5h-1z"/></svg>'
        },
        58539: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M7.5 7H7v14h5V7H7.5zM8 20V8h3v12H8zm7.5-11H15v10h5V9h-4.5zm.5 9v-8h3v8h-3z"/></svg>'
        },
        4733: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M17 11v6h3v-6h-3zm-.5-1h4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5z"/><path d="M18 7h1v3.5h-1zm0 10.5h1V21h-1z"/><path d="M9 8v11h3V8H9zm-.5-1h4a.5.5 0 0 1 .5.5v12a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-12a.5.5 0 0 1 .5-.5z"/><path d="M10 4h1v5h-1zm0 14h1v5h-1zM8.5 9H10v1H8.5zM11 9h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11z"/></svg>'
        },
        59672: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M20 17l-5 5M15 17l5 5M9 11.5h7M17.5 8a2.5 2.5 0 0 0-5 0v11a2.5 2.5 0 0 1-5 0"/></svg>'
        },
        88320: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M11 5h3v12h5V8h3v13h1V7h-5v9h-3V4h-5v18H7v-5H6v6h5z"/></svg>'
        },
        76660: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22M11 10v10"/></g></svg>'
        },
        67856: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22M7 10v10M15 10v10"/></g></svg>'
        },
        82517: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="25" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="24" height="20" rx="2"/><path d="M0 10h24M6 10v10M12 10v10M18 10v10"/></g></svg>'
        },
        85341: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22M11 0v10"/></g></svg>'
        },
        1413: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22M0 15h22M11 0v10"/></g></svg>'
        },
        17018: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M11 0v20"/></g></svg>'
        },
        11141: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22"/></g></svg>'
        },
        84626: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M7 0v20M15 0v20"/></g></svg>'
        },
        20814: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h11M11 0v20"/></g></svg>'
        },
        24046: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M11 0v20M11 10h11"/></g></svg>'
        },
        79849: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 7h22M0 13h22"/></g></svg>'
        },
        76983: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22M11 0v20"/></g></svg>'
        },
        68155: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="25" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="24" height="20" rx="2"/><path d="M6 0v20M12 0v20M18 0v20"/></g></svg>'
        },
        44475: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M11 0v20M11 7h11M11 13h11"/></g></svg>'
        },
        82991: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 5h22M0 10h22M0 15h22"/></g></svg>'
        },
        56114: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M11 0v20M11 5h11M11 10h11M11 15h11"/></g></svg>'
        },
        81805: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 10h22M7 0v20M15 0v20"/></g></svg>'
        },
        24129: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 7h22M0 13h22M11 0v20"/></g></svg>'
        },
        20321: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="25" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="24" height="20" rx="2"/><path d="M0 10h24M6 0v20M12 0v20M18 0v20"/></g></svg>'
        },
        94400: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><g fill="none" stroke="currentColor" transform="translate(.5 .5)"><rect width="22" height="20" rx="2"/><path d="M0 5h22M0 10h22M0 15h22M11 0v20"/></g></svg>'
        },
        90503: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="23" height="21"><rect width="22" height="20" fill="none" stroke="currentColor" rx="2" transform="translate(.5 .5)"/></svg>'
        },
        59604: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18M9 8v8"/></g></svg>'
        },
        37828: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18M6 8v8M12 8v8"/></g></svg>'
        },
        72918: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(4.5 6.5)"><rect width="20" height="16" rx="2"/><path d="M0 8h20M5 8v8M10 8v8M15 8v8"/></g></svg>'
        },
        8793: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18M9 0v8"/></g></svg>'
        },
        79264: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18M0 12h18M9 0v8"/></g></svg>'
        },
        93263: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M9 0v16"/></g></svg>'
        },
        315: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18"/></g></svg>'
        },
        41806: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M6 0v16M12 0v16"/></g></svg>'
        },
        77370: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h9M9 0v16"/></g></svg>'
        },
        65942: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M9 0v16M9 8h9"/></g></svg>'
        },
        53750: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 5h18M0 11h18"/></g></svg>'
        },
        74011: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18M9 0v16"/></g></svg>'
        },
        25993: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(4.5 6.5)"><rect width="20" height="16" rx="2"/><path d="M5 0v16M10 0v16M15 0v16"/></g></svg>'
        },
        18429: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M9 0v16M9 5h9M9 11h9"/></g></svg>'
        },
        48066: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 4h18M0 8h18M0 12h18"/></g></svg>'
        },
        62394: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M9 0v16M9 4h9M9 8h9M9 12h9"/></g></svg>'
        },
        93464: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 8h18M6 0v16M12 0v16"/></g></svg>'
        },
        63670: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 5h18M0 11h18M9 0v16"/></g></svg>'
        },
        1290: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(4.5 6.5)"><rect width="20" height="16" rx="2"/><path d="M0 8h20M5 0v16M10 0v16M15 0v16"/></g></svg>'
        },
        99104: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none" stroke="currentColor" transform="translate(5.5 6.5)"><rect width="18" height="16" rx="2"/><path d="M0 4h18M0 8h18M0 12h18M9 0v16"/></g></svg>'
        },
        98569: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><rect width="18" height="16" fill="none" stroke="currentColor" rx="2" transform="translate(5.5 6.5)"/></svg>'
        },
        62061: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M11.982 16.689L17.192 12h3.033l4.149-4.668-.748-.664L19.776 11h-2.968l-4.79 4.311L9 12.293l-4.354 4.353.708.708L9 13.707z"/></svg>'
        },
        84001: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M18 24h3V12h-3v12zm-1-13h5v14h-5V11zm-4-8v7h3V3h-3zm-1-1h5v9h-5V2zM8 19h3v-7H8v7zm-1-8h5v9H7v-9z"/></svg>'
        },
        6361: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 21" width="21" height="21"><g fill="none" stroke="currentColor"><path d="M18.5 11v5.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2H9"/><path stroke-linecap="square" d="M18 2l-8.5 8.5m4-9h5v5"/></g></svg>'
        },
        5312: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M14.5 16a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zm0-1a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm0 7a2.5 2.5 0 1 1 0-5 2.5 2.5 0 0 1 0 5zm0-1a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm3.293-15.5l4.707 4.707.707-.707L18.5 4.793z"/><path d="M18.5 10.207L23.207 5.5l-.707-.707L17.793 9.5zm-.707 1.293l4.707 4.707.707-.707-4.707-4.707z"/><path d="M18.5 16.207l4.707-4.707-.707-.707-4.707 4.707zM5.793 17.5l4.707 4.707.707-.707L6.5 16.793z"/><path d="M6.5 22.207l4.707-4.707-.707-.707L5.793 21.5zM5.793 5.5l4.707 4.707.707-.707L6.5 4.793z"/><path d="M6.5 10.207L11.207 5.5l-.707-.707L5.793 9.5zM5.793 11.5l4.707 4.707.707-.707L6.5 10.793z"/><path d="M6.5 16.207l4.707-4.707-.707-.707L5.793 15.5z"/></svg>'
        },
        292: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor" fill-rule="evenodd"><path fill-rule="nonzero" d="M14 17a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-1a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/><path d="M5.005 16A1.003 1.003 0 0 1 4 14.992v-1.984A.998.998 0 0 1 5 12h1.252a7.87 7.87 0 0 1 .853-2.06l-.919-.925c-.356-.397-.348-1 .03-1.379l1.42-1.42a1 1 0 0 1 1.416.007l.889.882A7.96 7.96 0 0 1 12 6.253V5c0-.514.46-1 1-1h2c.557 0 1 .44 1 1v1.253a7.96 7.96 0 0 1 2.06.852l.888-.882a1 1 0 0 1 1.416-.006l1.42 1.42a.999.999 0 0 1 .029 1.377s-.4.406-.918.926a7.87 7.87 0 0 1 .853 2.06H23c.557 0 1 .447 1 1.008v1.984A.998.998 0 0 1 23 16h-1.252a7.87 7.87 0 0 1-.853 2.06l.882.888a1 1 0 0 1 .006 1.416l-1.42 1.42a1 1 0 0 1-1.415-.007l-.889-.882a7.96 7.96 0 0 1-2.059.852v1.248c0 .56-.45 1.005-1.008 1.005h-1.984A1.004 1.004 0 0 1 12 22.995v-1.248a7.96 7.96 0 0 1-2.06-.852l-.888.882a1 1 0 0 1-1.416.006l-1.42-1.42a1 1 0 0 1 .007-1.415l.882-.888A7.87 7.87 0 0 1 6.252 16H5.005zm3.378-6.193l-.227.34A6.884 6.884 0 0 0 7.14 12.6l-.082.4H5.005C5.002 13 5 13.664 5 14.992c0 .005.686.008 2.058.008l.082.4c.18.883.52 1.71 1.016 2.453l.227.34-1.45 1.46c-.004.003.466.477 1.41 1.422l1.464-1.458.34.227a6.959 6.959 0 0 0 2.454 1.016l.399.083v2.052c0 .003.664.005 1.992.005.005 0 .008-.686.008-2.057l.399-.083a6.959 6.959 0 0 0 2.454-1.016l.34-.227 1.46 1.45c.003.004.477-.466 1.422-1.41l-1.458-1.464.227-.34A6.884 6.884 0 0 0 20.86 15.4l.082-.4h2.053c.003 0 .005-.664.005-1.992 0-.005-.686-.008-2.058-.008l-.082-.4a6.884 6.884 0 0 0-1.016-2.453l-.227-.34 1.376-1.384.081-.082-1.416-1.416-1.465 1.458-.34-.227a6.959 6.959 0 0 0-2.454-1.016L15 7.057V5c0-.003-.664-.003-1.992 0-.005 0-.008.686-.008 2.057l-.399.083a6.959 6.959 0 0 0-2.454 1.016l-.34.227-1.46-1.45c-.003-.004-.477.466-1.421 1.408l1.457 1.466z"/></g></svg>'
        },
        70639: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M18.293 13l-2.647 2.646.707.708 3.854-3.854-3.854-3.854-.707.708L18.293 12H12.5A5.5 5.5 0 0 0 7 17.5V19h1v-1.5a4.5 4.5 0 0 1 4.5-4.5h5.793z"/></svg>'
        },
        2200: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M18 5v5h3V5h-3zm-1-1h5v7h-5V4zm-4 13h3v-5h-3v5zm-1-6h5v7h-5v-7zM8 24h3v-5H8v5zm-1-6h5v7H7v-7z"/></svg>'
        },
        25109: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.118 6a.5.5 0 0 0-.447.276L9.809 8H5.5A1.5 1.5 0 0 0 4 9.5v10A1.5 1.5 0 0 0 5.5 21h16a1.5 1.5 0 0 0 1.5-1.5v-10A1.5 1.5 0 0 0 21.5 8h-4.309l-.862-1.724A.5.5 0 0 0 15.882 6h-4.764zm-1.342-.17A1.5 1.5 0 0 1 11.118 5h4.764a1.5 1.5 0 0 1 1.342.83L17.809 7H21.5A2.5 2.5 0 0 1 24 9.5v10a2.5 2.5 0 0 1-2.5 2.5h-16A2.5 2.5 0 0 1 3 19.5v-10A2.5 2.5 0 0 1 5.5 7h3.691l.585-1.17z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 18a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm0 1a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9z"/></svg>'
        },
        33626: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" width="23" height="23"><circle fill="none" stroke="currentColor" cx="11.5" cy="11.5" r="11"/><path fill="currentColor" d="M11.366 6.636c0-.327.116-.6.348-.816a1.19 1.19 0 0 1 .846-.326c.327 0 .607.108.842.326.234.217.351.49.351.816 0 .322-.117.593-.351.813-.235.22-.515.33-.842.33-.328 0-.608-.109-.843-.326a1.067 1.067 0 0 1-.351-.817zM11.908 17h-1.86l1.186-6.372H10.23l.308-1.472h2.835L11.908 17z"/></svg>'
        },
        33279: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M8 7h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zM6 8c0-1.1.9-2 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V8zm11-1h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm-2 1c0-1.1.9-2 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V8zm-4 8H8a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1zm-3-1a2 2 0 0 0-2 2v3c0 1.1.9 2 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H8zm9 1h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zm-2 1c0-1.1.9-2 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2v-3z"/></svg>'
        },
        13940: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M8.707 13l2.647 2.646-.707.708L6.792 12.5l3.853-3.854.708.708L8.707 12H14.5a5.5 5.5 0 0 1 5.5 5.5V19h-1v-1.5a4.5 4.5 0 0 0-4.5-4.5H8.707z"/></svg>'
        },
        56085: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8 9.5H6.5a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V20m-8-1.5h11a1 1 0 0 0 1-1v-11a1 1 0 0 0-1-1h-11a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1z"/></svg>'
        },
        99923: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M6.5 16v4.5a1 1 0 001 1h14a1 1 0 001-1V16M14.5 5V17m-4-3.5l4 4l4-4"/></svg>'
        },
        17110: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="currentColor" d="M9 1l2.35 4.76 5.26.77-3.8 3.7.9 5.24L9 13l-4.7 2.47.9-5.23-3.8-3.71 5.25-.77L9 1z"/></svg>'
        },
        6639: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M9 2.13l1.903 3.855.116.236.26.038 4.255.618-3.079 3.001-.188.184.044.259.727 4.237-3.805-2L9 12.434l-.233.122-3.805 2.001.727-4.237.044-.26-.188-.183-3.079-3.001 4.255-.618.26-.038.116-.236L9 2.13z"/></svg>'
        },
        57957: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M19 15l2.5-2.5c1-1 1.5-3.5-.5-5.5s-4.5-1.5-5.5-.5L13 9M10 12l-2.5 2.5c-1 1-1.5 3.5.5 5.5s4.5 1.5 5.5.5L16 18M17 11l-5 5"/></svg>'
        },
        38071: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="#1DA1F2" d="M10.28 22.26c7.55 0 11.68-6.26 11.68-11.67v-.53c.8-.58 1.49-1.3 2.04-2.13-.74.33-1.53.54-2.36.65.85-.5 1.5-1.32 1.8-2.28-.78.48-1.66.81-2.6 1a4.1 4.1 0 00-7 3.74c-3.4-.17-6.43-1.8-8.46-4.29a4.1 4.1 0 001.28 5.48c-.68-.02-1.3-.2-1.86-.5v.05a4.11 4.11 0 003.29 4.02 4 4 0 01-1.85.08 4.1 4.1 0 003.83 2.85A8.23 8.23 0 014 20.43a11.67 11.67 0 006.28 1.83z"/></svg>'
        }
    }
]);
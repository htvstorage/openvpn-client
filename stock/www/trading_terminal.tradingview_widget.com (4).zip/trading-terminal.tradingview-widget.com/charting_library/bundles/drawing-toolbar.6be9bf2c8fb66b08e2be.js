(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [2878], {
        10745: e => {
            e.exports = {
                dropdown: "dropdown-m5d9X7vB",
                buttonWrap: "buttonWrap-m5d9X7vB",
                control: "control-m5d9X7vB",
                arrow: "arrow-m5d9X7vB",
                arrowIcon: "arrowIcon-m5d9X7vB",
                isOpened: "isOpened-m5d9X7vB",
                hover: "hover-m5d9X7vB",
                isGrayed: "isGrayed-m5d9X7vB"
            }
        },
        61226: e => {
            e.exports = {
                container: "container-68Nk42BD",
                mirror: "mirror-68Nk42BD",
                background: "background-68Nk42BD",
                arrow: "arrow-68Nk42BD"
            }
        },
        83860: e => {
            e.exports = {
                item: "item-x0Gb0fpu",
                label: "label-x0Gb0fpu"
            }
        },
        85494: e => {
            e.exports = {
                drawingToolbar: "drawingToolbar-3e32hIe9",
                isHidden: "isHidden-3e32hIe9",
                inner: "inner-3e32hIe9",
                popupMenuItem: "popupMenuItem-3e32hIe9",
                group: "group-3e32hIe9",
                noGroupPadding: "noGroupPadding-3e32hIe9",
                lastGroup: "lastGroup-3e32hIe9",
                fill: "fill-3e32hIe9",
                separator: "separator-3e32hIe9"
            }
        },
        84006: e => {
            e.exports = {
                toggleButton: "toggleButton-5IlBhjdP",
                collapsed: "collapsed-5IlBhjdP",
                background: "background-5IlBhjdP",
                arrow: "arrow-5IlBhjdP"
            }
        },
        88234: e => {
            e.exports = {
                wrap: "wrap-9Mqd4dY6",
                smallTablet: "smallTablet-9Mqd4dY6",
                mobileWrap: "mobileWrap-9Mqd4dY6",
                item: "item-9Mqd4dY6",
                hovered: "hovered-9Mqd4dY6",
                active: "active-9Mqd4dY6",
                title: "title-9Mqd4dY6",
                separator: "separator-9Mqd4dY6"
            }
        },
        48214: e => {
            e.exports = {
                buttonIcon: "buttonIcon-OGj1N2Ml",
                button: "button-OGj1N2Ml"
            }
        },
        60306: e => {
            e.exports = {
                wrap: "wrap-GVak88eE",
                scrollWrap: "scrollWrap-GVak88eE",
                noScrollBar: "noScrollBar-GVak88eE",
                content: "content-GVak88eE",
                icon: "icon-GVak88eE",
                scrollBot: "scrollBot-GVak88eE",
                scrollTop: "scrollTop-GVak88eE",
                isVisible: "isVisible-GVak88eE",
                iconWrap: "iconWrap-GVak88eE",
                fadeBot: "fadeBot-GVak88eE",
                fadeTop: "fadeTop-GVak88eE"
            }
        },
        16059: e => {
            e.exports = {
                menuWrap: "menuWrap-8MKeZifP",
                isMeasuring: "isMeasuring-8MKeZifP",
                scrollWrap: "scrollWrap-8MKeZifP",
                momentumBased: "momentumBased-8MKeZifP",
                menuBox: "menuBox-8MKeZifP",
                isHidden: "isHidden-8MKeZifP"
            }
        },
        63095: e => {
            e.exports = {
                item: "item-UZNJ2Dq5",
                label: "label-UZNJ2Dq5",
                labelRow: "labelRow-UZNJ2Dq5",
                toolbox: "toolbox-UZNJ2Dq5"
            }
        },
        524: e => {
            e.exports = {
                separator: "separator-GzmeVcFo",
                small: "small-GzmeVcFo",
                normal: "normal-GzmeVcFo",
                large: "large-GzmeVcFo"
            }
        },
        72571: (e, t, o) => {
            "use strict";
            o.d(t, {
                Icon: () => n
            });
            var i = o(59496);
            const n = i.forwardRef((e, t) => {
                const {
                    icon: o = "",
                    ...n
                } = e;
                return i.createElement("span", { ...n,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: o
                    }
                })
            })
        },
        93599: (e, t, o) => {
            "use strict";
            o.d(t, {
                DEFAULT_VERTICAL_TOOLBAR_HIDER_THEME: () => a,
                VerticalToolbarHider: () => c
            });
            var i = o(59496),
                n = o(97754),
                s = o(12777),
                l = o(61226);
            const a = l,
                r = "http://www.w3.org/2000/svg";

            function c(e) {
                const {
                    direction: t,
                    theme: o = l
                } = e;
                return i.createElement("svg", {
                    xmlns: r,
                    width: "9",
                    height: "27",
                    viewBox: "0 0 9 27",
                    className: n(o.container, "right" === t ? o.mirror : null),
                    onContextMenu: s.preventDefault
                }, i.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd"
                }, i.createElement("path", {
                    className: o.background,
                    d: "M4.5.5a4 4 0 0 1 4 4v18a4 4 0 1 1-8 0v-18a4 4 0 0 1 4-4z"
                }), i.createElement("path", {
                    className: o.arrow,
                    d: "M5.5 10l-2 3.5 2 3.5"
                })))
            }
        },
        27790: (e, t, o) => {
            "use strict";
            o.r(t), o.d(t, {
                DrawingToolbarRenderer: () => Je
            });
            var i = o(59496),
                n = o(87995),
                s = o(88537),
                l = o(25177),
                a = o(97754),
                r = o(72535),
                c = o(70122),
                h = o(82527),
                d = o(93546),
                u = o(26760),
                m = o(59410),
                p = o(97496),
                g = o.n(p),
                b = o(1227),
                v = o(69111),
                _ = o(84291);
            class T {
                constructor(e) {
                    this._drawingsAccess = e || {
                        tools: [],
                        type: "black"
                    }
                }
                isToolEnabled(e) {
                    const t = this._findTool(e);
                    return !(!t || !t.grayed) || ("black" === this._drawingsAccess.type ? !t : !!t)
                }
                isToolGrayed(e) {
                    const t = this._findTool(e);
                    return Boolean(t && t.grayed)
                }
                _findTool(e) {
                    return this._drawingsAccess.tools.find(t => t.name === e)
                }
            }
            var C = o(80185);
            const f = [{
                id: "linetool-group-cursors",
                title: (0, l.t)("Cursors"),
                items: [{
                    name: "cursor"
                }, {
                    name: "dot"
                }, {
                    name: "arrow"
                }, {
                    name: "eraser"
                }],
                trackLabel: null
            }, {
                id: "linetool-group-trend-line",
                title: (0, l.t)("Trend Line Tools"),
                items: [{
                    name: "LineToolTrendLine",
                    hotkeyHash: C.Modifiers.Alt + 84
                }, {
                    name: "LineToolArrow"
                }, {
                    name: "LineToolRay"
                }, {
                    name: "LineToolInfoLine"
                }, {
                    name: "LineToolExtended"
                }, {
                    name: "LineToolTrendAngle"
                }, {
                    name: "LineToolHorzLine",
                    hotkeyHash: C.Modifiers.Alt + 72
                }, {
                    name: "LineToolHorzRay",
                    hotkeyHash: C.Modifiers.Alt + 74
                }, {
                    name: "LineToolVertLine",
                    hotkeyHash: C.Modifiers.Alt + 86
                }, {
                    name: "LineToolCrossLine",
                    hotkeyHash: C.Modifiers.Alt + 67
                }, {
                    name: "LineToolParallelChannel"
                }, {
                    name: "LineToolRegressionTrend"
                }, {
                    name: "LineToolFlatBottom"
                }, {
                    name: "LineToolDisjointAngle"
                }, null].filter(Boolean),
                trackLabel: null
            }, {
                id: "linetool-group-gann-and-fibonacci",
                title: (0, l.t)("Gann and Fibonacci Tools"),
                items: [{
                    name: "LineToolFibRetracement",
                    hotkeyHash: C.Modifiers.Alt + 70
                }, {
                    name: "LineToolTrendBasedFibExtension"
                }, {
                    name: "LineToolPitchfork"
                }, {
                    name: "LineToolSchiffPitchfork2"
                }, {
                    name: "LineToolSchiffPitchfork"
                }, {
                    name: "LineToolInsidePitchfork"
                }, {
                    name: "LineToolFibChannel"
                }, {
                    name: "LineToolFibTimeZone"
                }, {
                    name: "LineToolGannSquare"
                }, {
                    name: "LineToolGannFixed"
                }, {
                    name: "LineToolGannComplex"
                }, {
                    name: "LineToolGannFan"
                }, {
                    name: "LineToolFibSpeedResistanceFan"
                }, {
                    name: "LineToolTrendBasedFibTime"
                }, {
                    name: "LineToolFibCircles"
                }, {
                    name: "LineToolPitchfan"
                }, {
                    name: "LineToolFibSpiral"
                }, {
                    name: "LineToolFibSpeedResistanceArcs"
                }, {
                    name: "LineToolFibWedge"
                }],
                trackLabel: null
            }, {
                id: "linetool-group-geometric-shapes",
                title: (0, l.t)("Geometric Shapes"),
                items: [{
                    name: "LineToolBrush"
                }, {
                    name: "LineToolHighlighter"
                }, {
                    name: "LineToolRectangle"
                }, {
                    name: "LineToolCircle"
                }, {
                    name: "LineToolEllipse"
                }, {
                    name: "LineToolPath"
                }, {
                    name: "LineToolBezierQuadro"
                }, {
                    name: "LineToolPolyline"
                }, {
                    name: "LineToolTriangle"
                }, {
                    name: "LineToolRotatedRectangle"
                }, {
                    name: "LineToolArc"
                }, {
                    name: "LineToolBezierCubic"
                }],
                trackLabel: null
            }, {
                id: "linetool-group-annotation",
                title: (0, l.t)("Annotation Tools"),
                items: [{
                    name: "LineToolText"
                }, {
                    name: "LineToolTextAbsolute"
                }, {
                    name: "LineToolNote"
                }, {
                    name: "LineToolNoteAbsolute"
                }, {
                    name: "LineToolSignpost"
                }, null, null, null, {
                    name: "LineToolCallout"
                }, {
                    name: "LineToolBalloon"
                }, {
                    name: "LineToolPriceLabel"
                }, {
                    name: "LineToolPriceNote"
                }, {
                    name: "LineToolArrowMarker"
                }, {
                    name: "LineToolArrowMarkLeft"
                }, {
                    name: "LineToolArrowMarkRight"
                }, {
                    name: "LineToolArrowMarkUp"
                }, {
                    name: "LineToolArrowMarkDown"
                }, {
                    name: "LineToolFlagMark"
                }].filter(Boolean),
                trackLabel: null
            }, {
                id: "linetool-group-patterns",
                title: (0, l.t)("Patterns"),
                items: [{
                    name: "LineTool5PointsPattern"
                }, {
                    name: "LineToolCypherPattern"
                }, {
                    name: "LineToolABCD"
                }, {
                    name: "LineToolTrianglePattern"
                }, {
                    name: "LineToolThreeDrivers"
                }, {
                    name: "LineToolHeadAndShoulders"
                }, {
                    name: "LineToolElliottImpulse"
                }, {
                    name: "LineToolElliottTriangle"
                }, {
                    name: "LineToolElliottTripleCombo"
                }, {
                    name: "LineToolElliottCorrection"
                }, {
                    name: "LineToolElliottDoubleCombo"
                }, {
                    name: "LineToolCircleLines"
                }, {
                    name: "LineToolTimeCycles"
                }, {
                    name: "LineToolSineLine"
                }],
                trackLabel: null
            }, {
                id: "linetool-group-prediction-and-measurement",
                title: (0, l.t)("Prediction and Measurement Tools"),
                items: [{
                    name: "LineToolRiskRewardLong"
                }, {
                    name: "LineToolRiskRewardShort"
                }, {
                    name: "LineToolPrediction"
                }, {
                    name: "LineToolDateRange"
                }, {
                    name: "LineToolPriceRange"
                }, {
                    name: "LineToolDateAndPriceRange"
                }, {
                    name: "LineToolBarsPattern"
                }, {
                    name: "LineToolGhostFeed"
                }, {
                    name: "LineToolProjection"
                }, {
                    name: "LineToolFixedRangeVolumeProfile"
                }].filter(Boolean),
                trackLabel: null
            }];
            var w = o(28097),
                k = o(81814),
                y = o(82027),
                S = o(70981),
                M = o(30140);

            function E(e) {
                const {
                    id: t,
                    action: o,
                    isActive: n,
                    isHidden: s,
                    isTransparent: l,
                    toolName: a
                } = e;
                return i.createElement(M.ToolButton, {
                    id: t,
                    icon: _.lineToolsInfo[a].icon,
                    isActive: n,
                    isHidden: s,
                    isTransparent: l,
                    onClick: o,
                    title: _.lineToolsInfo[a].localizedName,
                    "data-name": a
                })
            }
            var L = o(39667);
            const D = [61536, 61537, 61538, 61539, 61725, 61726, 61575, 61576, 61796, 61797, 61779, 61780, 61781, 61782, 61783, 61784, 61785, 61786, 61845, 61440, 61442, 61444, 61445, 61446, 61447, 61452, 61453, 61454, 61457, 61458, 61459, 61461, 61463, 61466, 61467, 61470, 61473, 61476, 61488, 61504, 61505, 61507, 61510, 61523, 61524, 61525, 61526, 61527, 61528, 61529, 61530, 61531, 61532, 61533, 61534, 61540, 61541, 61542, 61543, 61544, 61545, 61546, 61547, 61548, 61550, 61552, 61553, 61554, 61557, 61558, 61559, 61560, 61565, 61566, 61568, 61572, 61578, 61601, 61602, 61603, 61604, 61605, 61606, 61607, 61609, 61610, 61611, 61654, 61655, 61656, 61657, 61658, 61667, 61669, 61671, 61675, 61683, 61698, 61699, 61700, 61701, 61702, 61703, 61708, 61712, 61713, 61714, 61715, 61720, 61721, 61722, 61731, 61732, 61736, 61737, 61738, 61749, 61751, 61753, 61754, 61757, 61760, 61768, 61769, 61770, 61813, 61814, 61815, 61816, 61817, 61820, 61827, 61829, 61830, 61832, 61842];
            var A = o(72571),
                x = o(44377),
                B = o(417),
                I = o(59339),
                N = o(96366),
                W = o(10745);
            class P extends i.PureComponent {
                constructor(e) {
                    super(e), this._toggleDropdown = e => {
                        this.setState({
                            isOpened: void 0 !== e ? e : !this.state.isOpened
                        })
                    }, this._handleClose = () => {
                        this._toggleDropdown(!1)
                    }, this._getDropdownPosition = () => {
                        if (!this._control) return {
                            x: 0,
                            y: 0
                        };
                        const e = this._control.getBoundingClientRect();
                        return {
                            x: e.left + e.width + 1,
                            y: e.top - 6
                        }
                    }, this._handleClickArrow = () => {
                        var e, t;
                        null === (t = (e = this.props).onArrowClick) || void 0 === t || t.call(e), this._toggleDropdown()
                    }, this._handleTouchStart = () => {
                        this.props.onClickButton && this.props.onClickButton(), this._toggleDropdown()
                    }, this._handlePressStart = () => {
                        if (r.mobiletouch && !this.props.checkable) !this._longPressDelay && this.props.onClickButton && this.props.onClickButton();
                        else {
                            if (this._doubleClickDelay) return clearTimeout(this._doubleClickDelay), delete this._doubleClickDelay, void this._toggleDropdown(!0);
                            this._doubleClickDelay = setTimeout(() => {
                                delete this._doubleClickDelay, !this._longPressDelay && this.props.onClickButton && this.props.onClickButton()
                            }, 175)
                        }
                        this._longPressDelay = setTimeout(() => {
                            delete this._longPressDelay, this._toggleDropdown(!0)
                        }, 300)
                    }, this._cancelAllTimeouts = () => {
                        clearTimeout(this._longPressDelay), delete this._longPressDelay, clearTimeout(this._doubleClickDelay), delete this._doubleClickDelay
                    }, this._handleTouchPressEnd = e => {
                        e.cancelable && e.preventDefault(), this._handlePressEnd()
                    }, this._handlePressEnd = () => {
                        this._longPressDelay && (clearTimeout(this._longPressDelay), delete this._longPressDelay, this.state.isOpened ? this._toggleDropdown(!1) : this.props.checkable || this.state.isOpened || r.mobiletouch || !this.props.isActive && !this.props.openDropdownByClick ? !this._doubleClickDelay && this.props.onClickButton && this.props.onClickButton() : this._toggleDropdown(!0))
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        buttonActiveClass: e,
                        buttonClass: t,
                        buttonIcon: o,
                        buttonTitle: n,
                        buttonHotKey: s,
                        dropdownTooltip: l,
                        children: c,
                        isActive: h,
                        isGrayed: d,
                        onClickWhenGrayed: u,
                        checkable: m,
                        isSmallTablet: p
                    } = this.props, {
                        isOpened: g
                    } = this.state, b = (0, B.filterDataProps)(this.props);
                    return i.createElement("div", {
                        className: a(W.dropdown, {
                            [W.isGrayed]: d,
                            [W.isActive]: h,
                            [W.isOpened]: g
                        }),
                        onClick: d ? u : void 0
                    }, i.createElement("div", { ...b,
                        ref: e => this._control = e,
                        className: W.control
                    }, i.createElement("div", { ...this._getButtonHandlers(),
                        className: a(W.buttonWrap, {
                            "apply-common-tooltip common-tooltip-vertical": Boolean(n || s)
                        }),
                        "data-tooltip-hotkey": s,
                        "data-tooltip-delay": 1500,
                        "data-role": "button",
                        title: n
                    }, i.createElement(M.ToolButton, {
                        activeClass: e,
                        className: t,
                        icon: o,
                        isActive: h,
                        isGrayed: d,
                        isTransparent: !m
                    })), !d && !r.mobiletouch && i.createElement("div", {
                        className: a(W.arrow, l && "apply-common-tooltip common-tooltip-vertical"),
                        title: l,
                        onClick: this._handleClickArrow,
                        "data-role": "menu-handle"
                    }, i.createElement(A.Icon, {
                        className: W.arrowIcon,
                        icon: N
                    }))), !d && (p ? g && i.createElement(I.Drawer, {
                        onClose: this._handleClose,
                        position: "Bottom"
                    }, c) : i.createElement(x.PopupMenu, {
                        doNotCloseOn: this,
                        isOpened: g,
                        onClose: this._handleClose,
                        position: this._getDropdownPosition
                    }, c)))
                }
                _getButtonHandlers() {
                    const {
                        isGrayed: e,
                        checkable: t
                    } = this.props;
                    return e ? {} : r.mobiletouch ? t ? {
                        onTouchStart: this._handlePressStart,
                        onTouchEnd: this._handleTouchPressEnd,
                        onTouchMove: this._cancelAllTimeouts
                    } : {
                        onClick: this._handleTouchStart
                    } : {
                        onMouseDown: this._handlePressStart,
                        onMouseUp: this._handlePressEnd
                    }
                }
            }
            var R = o(17850),
                V = o(88234);
            class F extends i.Component {
                constructor(e) {
                    super(e), this._renderItem = (e, t) => {
                        const {
                            isSmallTablet: o
                        } = this.props, n = a(V.item, o && V.smallTablet, t && o && this.state.isActive && e === this.state.current && V.active);
                        return i.createElement("div", {
                            className: n,
                            key: e,
                            onClick: () => {
                                this._handleSelect(e), (0, S.globalCloseMenu)()
                            }
                        }, String.fromCharCode(e))
                    }, this._onChangeDrawingStateTool = () => {
                        this.setState({
                            isActive: this._isActive()
                        })
                    }, this._onChangeDrawingStateIcon = () => {
                        const e = d.iconTool.value();
                        let {
                            recents: t
                        } = this.state;
                        const o = t.indexOf(e); - 1 !== o && t.splice(o, 1), t = [e, ...t.slice(0, 9)], (0, c.setJSON)("linetoolicon.recenticons", t), this.setState({
                            current: e,
                            recents: t
                        })
                    }, this._handleSelect = e => {
                        d.iconTool.setValue(e), d.tool.setValue("LineToolIcon")
                    }, this.state = {
                        current: (0, L.defaults)("linetoolicon").icon,
                        recents: (0, c.getJSON)("linetoolicon.recenticons") || [],
                        isActive: this._isActive()
                    }
                }
                componentDidMount() {
                    d.tool.subscribe(this._onChangeDrawingStateTool), d.iconTool.subscribe(this._onChangeDrawingStateIcon), c.onSync.subscribe(this, this._onSyncSettings)
                }
                componentWillUnmount() {
                    d.tool.unsubscribe(this._onChangeDrawingStateTool), d.iconTool.unsubscribe(this._onChangeDrawingStateIcon), c.onSync.unsubscribe(this, this._onSyncSettings)
                }
                render() {
                    const {
                        isSmallTablet: e,
                        isMobileWrap: t
                    } = this.props, {
                        recents: o
                    } = this.state, n = a(V.wrap, e && V.smallTablet, t && V.mobileWrap);
                    return i.createElement(i.Fragment, null, o && i.createElement(i.Fragment, null, e && i.createElement("div", {
                        className: V.title
                    }, (0, l.t)("Recently used")), i.createElement("div", {
                        className: n
                    }, o.map(e => this._renderItem(e, !0))), i.createElement(R.PopupMenuSeparator, {
                        className: a(e && V.separator)
                    })), i.createElement("div", {
                        key: "all",
                        className: n
                    }, D.map(e => this._renderItem(e))))
                }
                _isActive() {
                    var e;
                    return d.tool.value() === (null !== (e = this.props.toolName) && void 0 !== e ? e : "LineToolIcon")
                }
                _onSyncSettings() {
                    this.setState({
                        recents: (0, c.getJSON)("linetoolicon.recenticons")
                    })
                }
            }
            var O = o(48214);
            const H = {
                icon: (0, l.t)("Icon"),
                dropdownTooltip: (0, l.t)("Icons")
            };
            class G extends i.Component {
                constructor(e) {
                    super(e), this._onChangeDrawingStateTool = () => {
                        this.setState({
                            isActive: this._isActive()
                        })
                    }, this._onChangeDrawingStateIcon = () => {
                        const e = d.iconTool.value();
                        this.setState({
                            current: e
                        })
                    }, this._handleSelect = e => {
                        d.iconTool.setValue(e), d.tool.setValue("LineToolIcon")
                    }, this._handleClick = () => {
                        const {
                            current: e
                        } = this.state;
                        this._handleSelect(e || D[0]), this._trackClick()
                    }, this._handleArrowClick = () => {
                        this._trackClick("menu")
                    }, this.state = {
                        current: (0, L.defaults)("linetoolicon").icon,
                        isActive: this._isActive()
                    }
                }
                componentDidMount() {
                    d.tool.subscribe(this._onChangeDrawingStateTool), d.iconTool.subscribe(this._onChangeDrawingStateIcon)
                }
                componentWillUnmount() {
                    d.tool.unsubscribe(this._onChangeDrawingStateTool), d.iconTool.unsubscribe(this._onChangeDrawingStateIcon)
                }
                render() {
                    const {
                        isGrayed: e,
                        toolName: t,
                        isSmallTablet: o
                    } = this.props, {
                        current: n,
                        isActive: s
                    } = this.state, l = (0, B.filterDataProps)(this.props);
                    return i.createElement(P, {
                        buttonClass: O.button,
                        buttonIcon: i.createElement("div", {
                            className: O.buttonIcon
                        }, String.fromCharCode(n || D[0])),
                        buttonTitle: H.icon,
                        dropdownTooltip: H.dropdownTooltip,
                        isActive: s,
                        isGrayed: e,
                        isSmallTablet: o,
                        onClickButton: this._handleClick,
                        onClickWhenGrayed: () => (0, m.emit)("onGrayedObjectClicked", {
                            type: "drawing",
                            name: _.lineToolsInfo[t].localizedName
                        }),
                        onArrowClick: this._handleArrowClick,
                        ...l
                    }, i.createElement(F, {
                        isSmallTablet: o,
                        toolName: t
                    }))
                }
                _isActive() {
                    return d.tool.value() === this.props.toolName
                }
                _trackClick(e) {
                    0
                }
            }
            var z = o(16062);
            class U extends i.PureComponent {
                constructor(e) {
                    super(e), this._handleClick = () => {
                        this.props.saveDefaultOnChange && (0, z.saveDefaultProperties)(!0);
                        const e = !this.props.property.value();
                        this.props.property.setValue(e), this.props.saveDefaultOnChange && (0, z.saveDefaultProperties)(!1),
                            this.props.onClick && this.props.onClick(e)
                    }, this.state = {
                        isActive: this.props.property.value()
                    }
                }
                componentDidMount() {
                    this.props.property.subscribe(this, this._onChange)
                }
                componentWillUnmount() {
                    this.props.property.unsubscribe(this, this._onChange)
                }
                render() {
                    const {
                        toolName: e
                    } = this.props, {
                        isActive: t
                    } = this.state, o = _.lineToolsInfo[e];
                    return i.createElement(M.ToolButton, {
                        icon: t && o.iconActive ? o.iconActive : o.icon,
                        isActive: t,
                        onClick: this._handleClick,
                        title: o.localizedName,
                        buttonHotKey: o.hotKey,
                        "data-name": e
                    })
                }
                _onChange(e) {
                    this.setState({
                        isActive: e.value()
                    })
                }
            }
            class q extends i.PureComponent {
                constructor(e) {
                    super(e), this._handleClick = () => {
                        var e, t;
                        d.tool.setValue(this.props.toolName), null === (t = (e = this.props).onClick) || void 0 === t || t.call(e)
                    }, this._onChange = () => {
                        this.setState({
                            isActive: d.tool.value() === this.props.toolName
                        })
                    }, this.state = {
                        isActive: d.tool.value() === this.props.toolName
                    }
                }
                componentDidMount() {
                    d.tool.subscribe(this._onChange)
                }
                componentWillUnmount() {
                    d.tool.unsubscribe(this._onChange)
                }
                render() {
                    const {
                        toolName: e
                    } = this.props, {
                        isActive: t
                    } = this.state, o = _.lineToolsInfo[e];
                    return i.createElement(M.ToolButton, {
                        icon: _.lineToolsInfo[e].icon,
                        isActive: t,
                        isTransparent: !0,
                        onClick: this._handleClick,
                        title: o.localizedName,
                        buttonHotKey: o.hotKey,
                        "data-name": e
                    })
                }
            }
            class j extends i.PureComponent {
                constructor(e) {
                    super(e), this._boundUndoModel = null, this._handleClick = () => {
                        const e = this._activeChartWidget();
                        e.hasModel() && e.model().zoomFromViewport()
                    }, this._syncUnzoomButton = () => {
                        const e = this._activeChartWidget();
                        let t = !1;
                        if (e.hasModel()) {
                            const o = e.model();
                            this._boundUndoModel !== o && (this._boundUndoModel && this._boundUndoModel.zoomStack().onChange().unsubscribe(null, this._syncUnzoomButton), o.zoomStack().onChange().subscribe(null, this._syncUnzoomButton), this._boundUndoModel = o), t = !o.zoomStack().isEmpty()
                        } else e.withModel(null, this._syncUnzoomButton);
                        this.setState({
                            isVisible: t
                        })
                    }, this.state = {
                        isVisible: !1
                    }
                }
                componentDidMount() {
                    this.props.chartWidgetCollection.activeChartWidget.subscribe(this._syncUnzoomButton, {
                        callWithLast: !0
                    })
                }
                componentWillUnmount() {
                    this.props.chartWidgetCollection.activeChartWidget.unsubscribe(this._syncUnzoomButton)
                }
                render() {
                    return this.state.isVisible ? i.createElement(E, {
                        action: this._handleClick,
                        isTransparent: !0,
                        toolName: "zoom-out"
                    }) : i.createElement("div", null)
                }
                _activeChartWidget() {
                    return this.props.chartWidgetCollection.activeChartWidget.value()
                }
            }
            var K = o(3597),
                Z = o(77687),
                Y = o(92063),
                X = o(14417);
            class J extends i.PureComponent {
                constructor(e) {
                    super(e), this._onChangeDrawingState = () => {
                            const e = this._getActiveToolIndex();
                            this.setState({
                                current: -1 !== e ? e : this.state.current,
                                isActive: -1 !== e
                            })
                        }, this._handleClickButton = () => {
                            if (this._trackClick(), b.CheckMobile.any()) return;
                            const e = this._getCurrentToolName();
                            this._selectTool(e)
                        }, this._handleClickItem = e => {
                            this._selectTool(e)
                        }, this._handleGrayedClick = e => {
                            (0, m.emit)("onGrayedObjectClicked", {
                                type: "drawing",
                                name: _.lineToolsInfo[e].localizedName
                            })
                        }, this._handleClickFavorite = e => {
                            this.state.favState && this.state.favState[e] ? K.LinetoolsFavoritesStore.removeFavorite(e) : K.LinetoolsFavoritesStore.addFavorite(e)
                        },
                        this._onAddFavorite = e => {
                            this.setState({
                                favState: { ...this.state.favState,
                                    [e]: !0
                                }
                            })
                        }, this._onRemoveFavorite = e => {
                            this.setState({
                                favState: { ...this.state.favState,
                                    [e]: !1
                                }
                            })
                        }, this._onSyncFavorites = () => {
                            this.setState({
                                favState: this._composeFavState()
                            })
                        }, this._handleArrowClick = () => {
                            this._trackClick("menu")
                        }, this._trackClick = e => {
                            const {
                                trackLabel: t
                            } = this.props
                        };
                    const t = this._getActiveToolIndex();
                    this.state = {
                        current: -1 === t ? this._firstNonGrayedTool() : t,
                        favState: this._composeFavState(),
                        isActive: -1 !== t
                    }
                }
                componentDidMount() {
                    d.tool.subscribe(this._onChangeDrawingState), K.LinetoolsFavoritesStore.favoriteAdded.subscribe(null, this._onAddFavorite), K.LinetoolsFavoritesStore.favoriteRemoved.subscribe(null, this._onRemoveFavorite), K.LinetoolsFavoritesStore.favoritesSynced.subscribe(null, this._onSyncFavorites)
                }
                componentWillUnmount() {
                    d.tool.unsubscribe(this._onChangeDrawingState), K.LinetoolsFavoritesStore.favoriteAdded.unsubscribe(null, this._onAddFavorite), K.LinetoolsFavoritesStore.favoriteRemoved.unsubscribe(null, this._onRemoveFavorite), K.LinetoolsFavoritesStore.favoritesSynced.unsubscribe(null, this._onSyncFavorites)
                }
                componentDidUpdate(e, t) {
                    e.lineTools !== this.props.lineTools && this.setState({
                        favState: this._composeFavState()
                    })
                }
                render() {
                    const {
                        favoriting: e,
                        grayedTools: t,
                        lineTools: o,
                        dropdownTooltip: n,
                        isSmallTablet: s
                    } = this.props, {
                        current: l,
                        favState: a,
                        isActive: r
                    } = this.state, c = this._getCurrentToolName(), h = _.lineToolsInfo[c], d = this._showShortcuts(), u = (0, B.filterDataProps)(this.props);
                    return i.createElement("span", null, i.createElement(P, {
                        buttonIcon: h.icon,
                        buttonTitle: h.localizedName,
                        buttonHotKey: h.hotKey,
                        dropdownTooltip: n,
                        isActive: r,
                        onClickButton: this._handleClickButton,
                        onArrowClick: this._handleArrowClick,
                        isSmallTablet: s,
                        ...u
                    }, o.map((o, n) => {
                        const c = o.name,
                            h = _.lineToolsInfo[c],
                            u = t[c];
                        return i.createElement(Y.PopupMenuItem, {
                            key: c,
                            "data-name": o.name,
                            theme: s ? X.multilineLabelWithIconAndToolboxTheme : void 0,
                            dontClosePopup: u,
                            forceShowShortcuts: d,
                            shortcut: !s && o.hotkeyHash ? (0, C.humanReadableHash)(o.hotkeyHash) : void 0,
                            icon: h.icon,
                            isActive: r && l === n,
                            appearAsDisabled: u,
                            label: h.localizedName,
                            onClick: u ? this._handleGrayedClick : this._handleClickItem,
                            onClickArg: c,
                            showToolboxOnHover: !a[c],
                            toolbox: e && !u ? i.createElement(Z.FavoriteButton, {
                                isActive: r && l === n,
                                isFilled: a[c],
                                onClick: () => this._handleClickFavorite(c)
                            }) : void 0
                        })
                    })))
                }
                _getCurrentToolName() {
                    const {
                        current: e
                    } = this.state, {
                        lineTools: t
                    } = this.props;
                    return t[e || 0].name
                }
                _firstNonGrayedTool() {
                    const {
                        grayedTools: e,
                        lineTools: t
                    } = this.props;
                    return t.findIndex(t => !e[t.name])
                }
                _getActiveToolIndex() {
                    return this.props.lineTools.findIndex(e => e.name === d.tool.value())
                }
                _showShortcuts() {
                    return this.props.lineTools.some(e => "shortcut" in e)
                }
                _selectTool(e) {
                    d.tool.setValue(e)
                }
                _composeFavState() {
                    const e = {};
                    return this.props.lineTools.forEach(t => {
                        e[t.name] = K.LinetoolsFavoritesStore.isFavorite(t.name)
                    }), e
                }
            }
            var $ = o(32133),
                Q = o(93173),
                ee = o(83860);
            const te = (0, Q.mergeThemes)(Y.DEFAULT_POPUP_MENU_ITEM_THEME, ee),
                oe = {
                    all: (0, l.t)("Remove Drawings & Indicators"),
                    drawings: (0, l.t)("Remove Drawings"),
                    studies: (0, l.t)("Remove Indicators")
                };
            class ie extends i.PureComponent {
                constructor() {
                    super(...arguments), this._handleRemoveToolClick = () => {
                        r.mobiletouch || this._handleRemoveDrawings(), se()
                    }, this._handleRemoveDrawings = () => {
                        ne("remove drawing"), this.props.chartWidgetCollection.activeChartWidget.value().removeAllDrawingTools()
                    }, this._handleRemoveStudies = () => {
                        ne("remove indicator"), this.props.chartWidgetCollection.activeChartWidget.value().removeAllStudies()
                    }, this._handleRemoveAll = () => {
                        ne("remove all"), this.props.chartWidgetCollection.activeChartWidget.value().removeAllStudiesDrawingTools()
                    }
                }
                render() {
                    const e = this.props.isSmallTablet ? te : void 0;
                    return i.createElement(P, {
                        buttonIcon: _.lineToolsInfo[this.props.toolName].icon,
                        buttonTitle: oe.drawings,
                        onClickButton: this._handleRemoveToolClick,
                        isSmallTablet: this.props.isSmallTablet,
                        "data-name": this.props.toolName,
                        onArrowClick: this._handleArrowClick,
                        openDropdownByClick: !1
                    }, i.createElement(Y.PopupMenuItem, {
                        "data-name": "remove-drawing-tools",
                        label: oe.drawings,
                        onClick: this._handleRemoveDrawings,
                        theme: e
                    }), i.createElement(Y.PopupMenuItem, {
                        "data-name": "remove-studies",
                        label: oe.studies,
                        onClick: this._handleRemoveStudies,
                        theme: e
                    }), i.createElement(Y.PopupMenuItem, {
                        "data-name": "remove-all",
                        label: oe.all,
                        onClick: this._handleRemoveAll,
                        theme: e
                    }))
                }
                _handleArrowClick() {
                    se("menu")
                }
            }

            function ne(e) {
                (0, $.trackEvent)("GUI", "Chart Left Toolbar", e)
            }

            function se(e) {
                0
            }
            var le = o(69893),
                ae = o(12297),
                re = o(26309);
            const ce = i.createContext({
                hideMode: "drawings",
                isActive: !1
            });

            function he(e) {
                const {
                    hideMode: t,
                    option: {
                        label: o,
                        dataName: n,
                        getBoxedValue: s
                    },
                    isSmallTablet: l,
                    onClick: a
                } = e, {
                    hideMode: r,
                    isActive: c
                } = (0, i.useContext)(ce), h = null == s ? void 0 : s();
                return "all" === t || h ? i.createElement(Y.PopupMenuItem, {
                    label: o,
                    isActive: r === t && c,
                    onClick: function() {
                        a(t, (0, ae.toggleHideMode)(t))
                    },
                    "data-name": n,
                    theme: l ? te : void 0
                }) : i.createElement(i.Fragment, null)
            }
            const de = {
                drawings: {
                    active: le.drawingToolsIcons.hideAllDrawingToolsActive,
                    inactive: le.drawingToolsIcons.hideAllDrawingTools
                },
                indicators: {
                    active: le.drawingToolsIcons.hideAllIndicatorsActive,
                    inactive: le.drawingToolsIcons.hideAllIndicators
                },
                positions: {
                    active: le.drawingToolsIcons.hideAllPositionsToolsActive,
                    inactive: le.drawingToolsIcons.hideAllPositionsTools
                },
                all: {
                    active: le.drawingToolsIcons.hideAllDrawingsActive,
                    inactive: le.drawingToolsIcons.hideAllDrawings
                }
            };

            function ue(e) {
                const {
                    isSmallTablet: t
                } = e, [{
                    isActive: o,
                    hideMode: n
                }, l] = (0, i.useState)(() => ({
                    isActive: !1,
                    hideMode: (0, ae.getSavedHideMode)()
                }));
                (0, i.useEffect)(() => (re.hideStateChange.subscribe(null, l), () => {
                    re.hideStateChange.unsubscribe(null, l)
                }), []);
                const a = _.lineToolsInfo.hideAllDrawings,
                    {
                        trackLabel: r,
                        tooltip: c,
                        dataName: h
                    } = (0, s.ensureDefined)((0, ae.getHideOptions)().get(n)),
                    d = de[n][o ? "active" : "inactive"],
                    u = o ? c.active : c.inactive;
                return i.createElement(P, {
                    buttonIcon: d,
                    buttonTitle: u,
                    buttonHotKey: a.hotKey,
                    onClickButton: function() {
                        (0, ae.toggleHideMode)(n), me(r, !o), pe(o ? "on" : "off")
                    },
                    isSmallTablet: t,
                    isActive: o,
                    checkable: !0,
                    "data-name": "hide-all",
                    "data-type": h,
                    onArrowClick: function() {
                        pe("menu")
                    }
                }, i.createElement(ce.Provider, {
                    value: {
                        isActive: o,
                        hideMode: n
                    }
                }, Array.from((0,
                    ae.getHideOptions)()).map(([e, o]) => i.createElement(he, {
                    key: e,
                    hideMode: e,
                    option: o,
                    isSmallTablet: t,
                    onClick: m
                }))));

                function m(e, t) {
                    me((0, s.ensureDefined)((0, ae.getHideOptions)().get(e)).trackLabel, t)
                }
            }

            function me(e, t) {
                (0, $.trackEvent)("GUI", "Chart Left Toolbar", `${e} ${t?"on":"off"}`)
            }

            function pe(e) {
                0
            }
            var ge = o(16409),
                be = o(82219);
            const ve = (0, l.t)("Show Favorite Drawing Tools Toolbar");
            class _e extends i.PureComponent {
                constructor() {
                    super(...arguments), this._instance = null, this._promise = null, this._bindedForceUpdate = () => this.forceUpdate(), this._handleClick = () => {
                        null !== this._instance && (this._instance.isVisible() ? (this._instance.hide(), this._trackClick(!1)) : (this._instance.show(), this._trackClick(!0)))
                    }
                }
                componentDidMount() {
                    const e = this._promise = (0, s.ensureNotNull)((0, ge.getFavoriteDrawingToolbarPromise)());
                    e.then(t => {
                        this._promise === e && (this._instance = t, this._instance.canBeShown().subscribe(this._bindedForceUpdate), this._instance.visibility().subscribe(this._bindedForceUpdate), this.forceUpdate())
                    })
                }
                componentWillUnmount() {
                    this._promise = null, null !== this._instance && (this._instance.canBeShown().unsubscribe(this._bindedForceUpdate), this._instance.visibility().unsubscribe(this._bindedForceUpdate), this._instance = null)
                }
                render() {
                    return null !== this._instance && this._instance.canBeShown().value() ? i.createElement(M.ToolButton, {
                        id: this.props.id,
                        icon: be,
                        isActive: this._instance.isVisible(),
                        onClick: this._handleClick,
                        title: ve
                    }) : null
                }
                _trackClick(e) {
                    0
                }
            }
            var Te, Ce = o(25892);
            ! function(e) {
                e.Screenshot = "drawing-toolbar-screenshot", e.FavoriteDrawings = "drawing-toolbar-favorite-drawings", e.ObjectTree = "drawing-toolbar-object-tree"
            }(Te || (Te = {}));
            var fe = o(21258),
                we = o(12777),
                ke = o(16678),
                ye = o(28466),
                Se = o(17324);
            class Me extends i.PureComponent {
                constructor(e) {
                    super(e), this._syncVisibleState = () => {
                        this.setState({
                            isVisible: this._isMultipleLayout()
                        })
                    }, this.state = {
                        isVisible: this._isMultipleLayout()
                    }
                }
                componentDidMount() {
                    this.props.layout.subscribe(this._syncVisibleState)
                }
                componentWillUnmount() {
                    this.props.layout.unsubscribe(this._syncVisibleState)
                }
                render() {
                    return this.state.isVisible ? this.props.children : i.createElement("div", null)
                }
                _isMultipleLayout() {
                    return (0, Se.isMultipleLayout)(this.props.layout.value())
                }
            }
            var Ee = o(93599),
                Le = o(84006);
            const De = (0, Q.mergeThemes)(Ee.DEFAULT_VERTICAL_TOOLBAR_HIDER_THEME, Le),
                Ae = {
                    hide: (0, l.t)("Hide Drawings Toolbar"),
                    show: (0, l.t)("Show Drawings Toolbar")
                };
            class xe extends i.PureComponent {
                constructor() {
                    super(...arguments), this._toggleVisibility = () => {
                        w.isDrawingToolbarVisible.setValue(!w.isDrawingToolbarVisible.value())
                    }
                }
                render() {
                    const {
                        toolbarVisible: e,
                        "data-name": t
                    } = this.props;
                    return i.createElement("div", {
                        className: a(De.toggleButton, "apply-common-tooltip common-tooltip-vertical", !e && De.collapsed),
                        onClick: this._toggleVisibility,
                        title: e ? Ae.hide : Ae.show,
                        "data-name": t,
                        "data-value": e ? "visible" : "collapsed"
                    }, i.createElement(Ee.VerticalToolbarHider, {
                        direction: e ? "left" : "right",
                        theme: e ? void 0 : De
                    }))
                }
            }
            var Be = o(63694),
                Ie = o(96038),
                Ne = o(30052);
            const We = {
                chartWidgetCollection: o(19036).any.isRequired
            };
            var Pe = o(23404),
                Re = o(85494);
            const Ve = h.enabled("right_toolbar"),
                Fe = h.enabled("keep_object_tree_widget_in_right_toolbar"),
                Oe = {
                    weakMagnet: (0, l.t)("Weak Magnet"),
                    strongMagnet: (0, l.t)("Strong Magnet")
                },
                He = (0, b.onWidget)(),
                Ge = new(g()),
                ze = $.trackEvent.bind(null, "GUI", "Chart Left Toolbar"),
                Ue = (e, t) => ze(`${e} ${t?"on":"off"}`);

            function qe() {
                const e = !d.properties().childs().magnet.value();
                Ue("magnet mode", e), Xe("magnet mode", e ? "on" : "off"), (0, u.setIsMagnetEnabled)(e)
            }

            function je() {
                (0, $.trackEvent)("GUI", "Magnet mode", "Weak"), (0, u.setMagnetMode)(Ce.MagnetMode.WeakMagnet)
            }

            function Ke() {
                (0, $.trackEvent)("GUI", "Magnet mode", "Strong"), (0, u.setMagnetMode)(Ce.MagnetMode.StrongMagnet)
            }

            function Ze() {
                Xe("magnet mode", "menu")
            }
            class Ye extends i.PureComponent {
                constructor(e) {
                    var t;
                    super(e), this._grayedTools = {}, this._handleMeasureClick = () => {
                        Xe("measure")
                    }, this._handleZoomInClick = () => {
                        Xe("zoom in")
                    }, this._handleDrawingClick = e => {
                        Ue("drawing mode", e), Xe("drawing mode", e ? "on" : "off")
                    }, this._handleLockClick = e => {
                        Ue("lock all drawing", e), Xe("lock", e ? "on" : "off")
                    }, this._handleSyncClick = e => {
                        Ue("sync", e), Xe("sync", e ? "on" : "off")
                    }, this._handleObjectsTreeClick = () => {
                        this._activeChartWidget().showObjectsTreeDialog(), Xe("object tree")
                    }, this._handleMouseOver = e => {
                        (0, fe.hoverMouseEventFilter)(e) && this.setState({
                            isHovered: !0
                        })
                    }, this._handleMouseOut = e => {
                        (0, fe.hoverMouseEventFilter)(e) && this.setState({
                            isHovered: !1
                        })
                    }, this._handleChangeVisibility = e => {
                        this.setState({
                            isVisible: e
                        })
                    }, this._handleEsc = () => {
                        d.resetToCursor(!0)
                    }, this._updateMagnetEnabled = () => {
                        const e = {
                            magnet: (0, u.magnetEnabled)().value()
                        };
                        this.setState(e)
                    }, this._updateMagnetMode = () => {
                        const e = {
                            magnetMode: (0, u.magnetMode)().value()
                        };
                        this.setState(e)
                    }, this._handleWidgetbarSettled = e => {
                        var t;
                        this.setState({
                            isWidgetbarVisible: Boolean(null === (t = window.widgetbar) || void 0 === t ? void 0 : t.visible().value()),
                            widgetbarSettled: e
                        })
                    }, this._handleWidgetbarVisible = e => {
                        this.setState({
                            isWidgetbarVisible: e
                        })
                    }, d.init(), this._toolsFilter = new T(this.props.drawingsAccess), this._filteredLineTools = f.map(e => ({
                        id: e.id,
                        title: e.title,
                        items: e.items.filter(e => this._toolsFilter.isToolEnabled(_.lineToolsInfo[e.name].localizedName)),
                        trackLabel: e.trackLabel
                    })).filter(e => 0 !== e.items.length), this._filteredLineTools.forEach(e => e.items.forEach(e => {
                        this._grayedTools[e.name] = this._toolsFilter.isToolGrayed(_.lineToolsInfo[e.name].localizedName)
                    })), this.state = {
                        isHovered: !1,
                        isVisible: w.isDrawingToolbarVisible.value(),
                        isWidgetbarVisible: Boolean(null === (t = window.widgetbar) || void 0 === t ? void 0 : t.visible().value()),
                        widgetbarSettled: void 0 !== window.widgetbar,
                        magnet: d.properties().childs().magnet.value(),
                        magnetMode: d.properties().childs().magnetMode.value()
                    }, this._features = {
                        favoriting: !He && h.enabled("items_favoriting"),
                        multicharts: h.enabled("support_multicharts"),
                        tools: !He || h.enabled("charting_library_base")
                    }, this._registry = {
                        chartWidgetCollection: this.props.chartWidgetCollection
                    }, this._negotiateResizer()
                }
                componentDidMount() {
                    var e;
                    w.isDrawingToolbarVisible.subscribe(this._handleChangeVisibility), S.globalCloseDelegate.subscribe(this, this._handleGlobalClose), (0,
                        u.magnetEnabled)().subscribe(this._updateMagnetEnabled), (0, u.magnetMode)().subscribe(this._updateMagnetMode), this._tool = d.tool.spawn(), this._tool.subscribe(this._updateHotkeys.bind(this)), this._initHotkeys(), this.props.widgetbarSettled && (this.props.widgetbarSettled.subscribe(this, this._handleWidgetbarSettled), b.CheckMobile.any() && (null === (e = window.widgetbar) || void 0 === e || e.visible().subscribe(this._handleWidgetbarVisible)))
                }
                componentWillUnmount() {
                    var e;
                    null === (e = window.widgetbar) || void 0 === e || e.visible().unsubscribe(this._handleWidgetbarVisible), w.isDrawingToolbarVisible.unsubscribe(this._handleChangeVisibility), S.globalCloseDelegate.unsubscribe(this, this._handleGlobalClose), (0, u.magnetEnabled)().unsubscribe(this._updateMagnetEnabled), (0, u.magnetMode)().unsubscribe(this._updateMagnetMode), this._tool.destroy(), this._hotkeys.destroy()
                }
                componentDidUpdate(e, t) {
                    var o;
                    const {
                        isVisible: i,
                        widgetbarSettled: n
                    } = this.state;
                    i !== t.isVisible && (m.emit("toggle_sidebar", !i), c.setValue("ChartDrawingToolbarWidget.visible", i), this._negotiateResizer()), t.widgetbarSettled !== n && n && b.CheckMobile.any() && (null === (o = window.widgetbar) || void 0 === o || o.visible().subscribe(this._handleWidgetbarVisible))
                }
                render() {
                    const {
                        bgColor: e,
                        chartWidgetCollection: t,
                        readOnly: o
                    } = this.props, {
                        isHovered: n,
                        isVisible: s,
                        magnet: l,
                        magnetMode: c
                    } = this.state, u = {
                        backgroundColor: e && "#" + e
                    };
                    let m;
                    m = i.createElement(xe, {
                        toolbarVisible: s,
                        "data-name": "toolbar-drawing-toggle-button"
                    });
                    const p = () => !!this._features.tools && (!(!h.enabled("show_object_tree") || Fe && !Ve) && (!h.enabled("right_toolbar") || (!this.state.isWidgetbarVisible && b.CheckMobile.any() || (0, v.isOnMobileAppPage)("new"))));
                    return i.createElement(Pe.RegistryProvider, {
                        validation: We,
                        value: this._registry
                    }, i.createElement(ye.CloseDelegateContext.Provider, {
                        value: Ge
                    }, i.createElement(Be.DrawerManager, null, i.createElement(Ne.MatchMedia, {
                        rule: Ie.DialogBreakpoints.TabletSmall
                    }, e => i.createElement("div", {
                        id: "drawing-toolbar",
                        className: a(Re.drawingToolbar, {
                            [Re.isHidden]: !s
                        }),
                        style: u,
                        onClick: this.props.onClick,
                        onContextMenu: we.preventDefaultForContextMenu
                    }, i.createElement(k.VerticalScroll, {
                        onScroll: this._handleGlobalClose,
                        isVisibleFade: r.mobiletouch,
                        isVisibleButtons: !r.mobiletouch && n,
                        isVisibleScrollbar: !1,
                        onMouseOver: this._handleMouseOver,
                        onMouseOut: this._handleMouseOut
                    }, i.createElement("div", {
                        className: Re.inner
                    }, !o && i.createElement("div", {
                        className: Re.group,
                        style: u
                    }, this._filteredLineTools.map((o, n) => i.createElement(J, {
                        "data-name": o.id,
                        chartWidgetCollection: t,
                        favoriting: this._features.favoriting,
                        grayedTools: this._grayedTools,
                        key: n,
                        dropdownTooltip: o.title,
                        lineTools: o.items,
                        isSmallTablet: e,
                        trackLabel: o.trackLabel
                    })), this._toolsFilter.isToolEnabled("Font Icons") && i.createElement(G, {
                        "data-name": "linetool-group-font-icons",
                        isGrayed: this._grayedTools["Font Icons"],
                        toolName: "LineToolIcon",
                        isSmallTablet: e
                    })), !o && i.createElement("div", {
                        className: Re.group,
                        style: u
                    }, i.createElement(q, {
                        toolName: "measure",
                        onClick: this._handleMeasureClick
                    }), i.createElement(q, {
                        toolName: "zoom",
                        onClick: this._handleZoomInClick
                    }), i.createElement(j, {
                        chartWidgetCollection: t
                    })), !o && i.createElement("div", {
                        className: Re.group,
                        style: u
                    }, i.createElement(P, {
                        "data-name": "magnet-button",
                        buttonIcon: c === Ce.MagnetMode.StrongMagnet ? le.drawingToolsIcons.strongMagnet : le.drawingToolsIcons.magnet,
                        buttonTitle: _.lineToolsInfo.magnet.localizedName,
                        isActive: l,
                        onClickButton: qe,
                        buttonHotKey: _.lineToolsInfo.magnet.hotKey,
                        checkable: !0,
                        isSmallTablet: e,
                        onArrowClick: Ze
                    }, i.createElement(Y.PopupMenuItem, {
                        key: "weakMagnet",
                        className: e ? Re.popupMenuItem : void 0,
                        "data-name": "weakMagnet",
                        icon: le.drawingToolsIcons.magnet,
                        isActive: l && c !== Ce.MagnetMode.StrongMagnet,
                        label: Oe.weakMagnet,
                        onClick: je
                    }), i.createElement(Y.PopupMenuItem, {
                        key: "strongMagnet",
                        className: e ? Re.popupMenuItem : void 0,
                        "data-name": "strongMagnet",
                        icon: le.drawingToolsIcons.strongMagnet,
                        isActive: l && c === Ce.MagnetMode.StrongMagnet,
                        label: Oe.strongMagnet,
                        onClick: Ke
                    })), this._features.tools && i.createElement(U, {
                        property: d.properties().childs().stayInDrawingMode,
                        saveDefaultOnChange: !0,
                        toolName: "drawginmode",
                        onClick: this._handleDrawingClick
                    }), this._features.tools && i.createElement(U, {
                        property: d.lockDrawings(),
                        toolName: "lockAllDrawings",
                        onClick: this._handleLockClick
                    }), this._features.tools && i.createElement(ue, {
                        isSmallTablet: e
                    }), this._features.tools && this._features.multicharts && i.createElement(Me, {
                        layout: t.layout
                    }, i.createElement(U, {
                        property: d.drawOnAllCharts(),
                        saveDefaultOnChange: !0,
                        toolName: "SyncDrawing",
                        onClick: this._handleSyncClick
                    }))), !o && this._features.tools && i.createElement("div", {
                        className: Re.group,
                        style: u
                    }, i.createElement(ie, {
                        chartWidgetCollection: t,
                        isSmallTablet: e,
                        toolName: "removeAllDrawingTools"
                    })), i.createElement("div", {
                        className: Re.fill,
                        style: u
                    }), !o && (this._features.tools || !1) && i.createElement("div", {
                        className: a(Re.group, Re.lastGroup),
                        style: u
                    }, !1, this._features.tools && this._features.favoriting && i.createElement(_e, {
                        id: Te.FavoriteDrawings
                    }), p() && i.createElement(E, {
                        id: Te.ObjectTree,
                        action: this._handleObjectsTreeClick,
                        toolName: "showObjectsTree"
                    })))), m)))))
                }
                _activeChartWidget() {
                    return this.props.chartWidgetCollection.activeChartWidget.value()
                }
                _negotiateResizer() {
                    const e = ke.TOOLBAR_WIDTH_COLLAPSED;
                    this.props.resizerBridge.negotiateWidth(this.state.isVisible ? ke.TOOLBAR_WIDTH_EXPANDED : e)
                }
                _handleGlobalClose() {
                    Ge.fire()
                }
                _updateHotkeys() {
                    this._hotkeys.promote()
                }
                _initHotkeys() {
                    this._hotkeys = y.createGroup({
                        desc: "Drawing Toolbar"
                    }), this._hotkeys.add({
                        desc: "Reset",
                        hotkey: 27,
                        handler: () => this._handleEsc(),
                        isDisabled: () => d.toolIsCursor(d.tool.value())
                    })
                }
            }

            function Xe(e, t) {
                0
            }
            class Je {
                constructor(e, t) {
                    this._component = null, this._handleRef = e => {
                        this._component = e
                    }, this._container = e, n.render(i.createElement(Ye, { ...t,
                        ref: this._handleRef
                    }), this._container)
                }
                destroy() {
                    n.unmountComponentAtNode(this._container)
                }
                getComponent() {
                    return (0, s.ensureNotNull)(this._component)
                }
            }
        },
        81814: (e, t, o) => {
            "use strict";
            o.d(t, {
                VerticalScroll: () => u
            });
            var i = o(59496),
                n = o(97754),
                s = o.n(n),
                l = o(7270),
                a = o(72571),
                r = o(42609),
                c = o(85787),
                h = o(60306),
                d = o(86219);
            class u extends i.PureComponent {
                constructor(e) {
                    super(e), this._scroll = null, this._handleScrollTop = () => {
                        this.animateTo(Math.max(0, this.currentPosition() - (this.state.heightWrap - 50)))
                    }, this._handleScrollBot = () => {
                        this.animateTo(Math.min((this.state.heightContent || 0) - (this.state.heightWrap || 0), this.currentPosition() + (this.state.heightWrap - 50)))
                    }, this._handleResizeWrap = ({
                        height: e
                    }) => {
                        this.setState({
                            heightWrap: e
                        })
                    }, this._handleResizeContent = ({
                        height: e
                    }) => {
                        this.setState({
                            heightContent: e
                        })
                    }, this._handleScroll = () => {
                        const {
                            onScroll: e
                        } = this.props;
                        e && e(this.currentPosition(), this.isAtTop(), this.isAtBot()), this._checkButtonsVisibility()
                    }, this._checkButtonsVisibility = () => {
                        const {
                            isVisibleTopButton: e,
                            isVisibleBotButton: t
                        } = this.state, o = this.isAtTop(), i = this.isAtBot();
                        o || e ? o && e && this.setState({
                            isVisibleTopButton: !1
                        }) : this.setState({
                            isVisibleTopButton: !0
                        }), i || t ? i && t && this.setState({
                            isVisibleBotButton: !1
                        }) : this.setState({
                            isVisibleBotButton: !0
                        })
                    }, this.state = {
                        heightContent: 0,
                        heightWrap: 0,
                        isVisibleBotButton: !1,
                        isVisibleTopButton: !1
                    }
                }
                componentDidMount() {
                    this._checkButtonsVisibility()
                }
                componentDidUpdate(e, t) {
                    t.heightWrap === this.state.heightWrap && t.heightContent === this.state.heightContent || this._handleScroll()
                }
                currentPosition() {
                    return this._scroll ? this._scroll.scrollTop : 0
                }
                isAtTop() {
                    return this.currentPosition() <= 1
                }
                isAtBot() {
                    return this.currentPosition() + this.state.heightWrap >= this.state.heightContent - 1
                }
                animateTo(e, t = c.dur) {
                    const o = this._scroll;
                    o && (0, r.doAnimate)({
                        onStep(e, t) {
                            o.scrollTop = t
                        },
                        from: o.scrollTop,
                        to: Math.round(e),
                        easing: c.easingFunc.easeInOutCubic,
                        duration: t
                    })
                }
                render() {
                    const {
                        children: e,
                        isVisibleScrollbar: t,
                        isVisibleFade: o,
                        isVisibleButtons: n,
                        onMouseOver: r,
                        onMouseOut: c
                    } = this.props, {
                        heightContent: u,
                        heightWrap: m,
                        isVisibleBotButton: p,
                        isVisibleTopButton: g
                    } = this.state;
                    return i.createElement(l, {
                        whitelist: ["height"],
                        onMeasure: this._handleResizeWrap
                    }, i.createElement("div", {
                        className: h.wrap,
                        onMouseOver: r,
                        onMouseOut: c
                    }, i.createElement("div", {
                        className: s()(h.scrollWrap, {
                            [h.noScrollBar]: !t
                        }),
                        onScroll: this._handleScroll,
                        ref: e => this._scroll = e
                    }, i.createElement(l, {
                        onMeasure: this._handleResizeContent,
                        whitelist: ["height"]
                    }, i.createElement("div", {
                        className: h.content
                    }, e))), o && i.createElement("div", {
                        className: s()(h.fadeTop, {
                            [h.isVisible]: g && u > m
                        })
                    }), o && i.createElement("div", {
                        className: s()(h.fadeBot, {
                            [h.isVisible]: p && u > m
                        })
                    }), n && i.createElement("div", {
                        className: s()(h.scrollTop, {
                            [h.isVisible]: g && u > m
                        }),
                        onClick: this._handleScrollTop
                    }, i.createElement("div", {
                        className: h.iconWrap
                    }, i.createElement(a.Icon, {
                        icon: d,
                        className: h.icon
                    }))), n && i.createElement("div", {
                        className: s()(h.scrollBot, {
                            [h.isVisible]: p && u > m
                        }),
                        onClick: this._handleScrollBot
                    }, i.createElement("div", {
                        className: h.iconWrap
                    }, i.createElement(a.Icon, {
                        icon: d,
                        className: h.icon
                    })))))
                }
            }
            u.defaultProps = {
                isVisibleScrollbar: !0
            }
        },
        23404: (e, t, o) => {
            "use strict";
            o.d(t, {
                validateRegistry: () => a,
                RegistryProvider: () => r,
                registryContextType: () => c
            });
            var i = o(59496),
                n = o(19036),
                s = o.n(n);
            const l = i.createContext({});

            function a(e, t) {
                s().checkPropTypes(t, e, "context", "RegistryContext")
            }

            function r(e) {
                const {
                    validation: t,
                    value: o
                } = e;
                return a(o, t), i.createElement(l.Provider, {
                    value: o
                }, e.children)
            }

            function c() {
                return l
            }
        },
        21709: (e, t, o) => {
            "use strict";

            function i(e, t, o, i, n) {
                function s(n) {
                    if (e > n.timeStamp) return;
                    const s = n.target;
                    void 0 !== o && null !== t && null !== s && s.ownerDocument === i && (t.contains(s) || o(n))
                }
                return n.click && i.addEventListener("click", s, !1), n.mouseDown && i.addEventListener("mousedown", s, !1), n.touchEnd && i.addEventListener("touchend", s, !1), n.touchStart && i.addEventListener("touchstart", s, !1), () => {
                    i.removeEventListener("click", s, !1), i.removeEventListener("mousedown", s, !1), i.removeEventListener("touchend", s, !1), i.removeEventListener("touchstart", s, !1)
                }
            }
            o.d(t, {
                addOutsideEventListener: () => i
            })
        },
        85089: (e, t, o) => {
            "use strict";
            o.d(t, {
                setFixedBodyState: () => r
            });
            var i = o(35922);
            const n = () => !window.matchMedia("screen and (min-width: 768px)").matches,
                s = () => !window.matchMedia("screen and (min-width: 1280px)").matches;
            let l = 0,
                a = !1;

            function r(e) {
                const {
                    body: t
                } = document, o = t.querySelector(".widgetbar-wrap");
                if (e && 1 == ++l) {
                    const e = (0, i.getCSSProperty)(t, "overflow"),
                        n = (0, i.getCSSPropertyNumericValue)(t, "padding-right");
                    "hidden" !== e.toLowerCase() && t.scrollHeight > t.offsetHeight && ((0, i.setStyle)(o, "right", (0, i.getScrollbarWidth)() + "px"), t.style.paddingRight = n + (0, i.getScrollbarWidth)() + "px", a = !0), t.classList.add("i-no-scroll")
                } else if (!e && l > 0 && 0 == --l && (t.classList.remove("i-no-scroll"), a)) {
                    (0, i.setStyle)(o, "right", "0px");
                    let e = 0;
                    e = o ? (r = (0, i.getContentWidth)(o), n() ? 0 : s() ? 46 : Math.min(Math.max(r, 46), 450)) : 0, t.scrollHeight <= t.clientHeight && (e -= (0, i.getScrollbarWidth)()), t.style.paddingRight = (e < 0 ? 0 : e) + "px", a = !1
                }
                var r
            }
        },
        21258: (e, t, o) => {
            "use strict";
            o.d(t, {
                hoverMouseEventFilter: () => s,
                useAccurateHover: () => l,
                useHover: () => n
            });
            var i = o(59496);

            function n() {
                const [e, t] = (0, i.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        s(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        s(e) && t(!1)
                    }
                }]
            }

            function s(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function l(e) {
                const [t, o] = (0, i.useState)(!1);
                return (0, i.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const i = e.current.contains(t.target);
                        o(i)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        61174: (e, t, o) => {
            "use strict";
            o.d(t, {
                useOutsideEvent: () => s
            });
            var i = o(59496),
                n = o(21709);

            function s(e) {
                const {
                    click: t,
                    mouseDown: o,
                    touchEnd: s,
                    touchStart: l,
                    handler: a,
                    reference: r,
                    ownerDocument: c = document
                } = e, h = (0, i.useRef)(null), d = (0, i.useRef)(new CustomEvent("timestamp").timeStamp);
                return (0, i.useLayoutEffect)(() => {
                    const e = {
                            click: t,
                            mouseDown: o,
                            touchEnd: s,
                            touchStart: l
                        },
                        i = r ? r.current : h.current;
                    return (0, n.addOutsideEventListener)(d.current, i, a, c, e)
                }, [t, o, s, l, a]), r || h
            }
        },
        30052: (e, t, o) => {
            "use strict";
            o.d(t, {
                MatchMedia: () => n
            });
            var i = o(59496);
            class n extends i.PureComponent {
                constructor(e) {
                    super(e), this._handleChange = () => {
                        this.forceUpdate()
                    }, this.state = {
                        query: window.matchMedia(this.props.rule)
                    }
                }
                componentDidMount() {
                    this._subscribe(this.state.query)
                }
                componentDidUpdate(e, t) {
                    this.state.query !== t.query && (this._unsubscribe(t.query), this._subscribe(this.state.query))
                }
                componentWillUnmount() {
                    this._unsubscribe(this.state.query)
                }
                render() {
                    return this.props.children(this.state.query.matches)
                }
                static getDerivedStateFromProps(e, t) {
                    return e.rule !== t.query.media ? {
                        query: window.matchMedia(e.rule)
                    } : null
                }
                _subscribe(e) {
                    e.addListener(this._handleChange)
                }
                _unsubscribe(e) {
                    e.removeListener(this._handleChange)
                }
            }
        },
        30553: (e, t, o) => {
            "use strict";
            o.d(t, {
                MenuContext: () => i
            });
            const i = o(59496).createContext(null)
        },
        10618: (e, t, o) => {
            "use strict";
            o.d(t, {
                DEFAULT_MENU_THEME: () => b,
                Menu: () => v
            });
            var i = o(59496),
                n = o(97754),
                s = o.n(n),
                l = o(88537),
                a = o(97280),
                r = o(12777),
                c = o(53327),
                h = o(70981),
                d = o(63212),
                u = o(82027),
                m = o(94488),
                p = o(30553),
                g = o(16059);
            const b = g;
            class v extends i.PureComponent {
                constructor(e) {
                    super(e), this._containerRef = null, this._scrollWrapRef = null, this._raf = null, this._scrollRaf = null, this._scrollTimeout = void 0, this._manager = new d.OverlapManager, this._hotkeys = null, this._scroll = 0, this._handleContainerRef = e => {
                        this._containerRef = e, this.props.reference && ("function" == typeof this.props.reference && this.props.reference(e), "object" == typeof this.props.reference && (this.props.reference.current = e))
                    }, this._handleScrollWrapRef = e => {
                        this._scrollWrapRef = e, "function" == typeof this.props.scrollWrapReference && this.props.scrollWrapReference(e), "object" == typeof this.props.scrollWrapReference && (this.props.scrollWrapReference.current = e)
                    }, this._handleMeasure = ({
                        callback: e,
                        forceRecalcPosition: t
                    } = {}) => {
                        var o, i, n, s;
                        if (this.state.isMeasureValid && !t) return;
                        const {
                            position: r
                        } = this.props, c = (0, l.ensureNotNull)(this._containerRef);
                        let h = c.getBoundingClientRect();
                        const d = document.documentElement.clientHeight,
                            u = document.documentElement.clientWidth,
                            m = null !== (o = this.props.closeOnScrollOutsideOffset) && void 0 !== o ? o : 0;
                        let p = d - 0 - m;
                        const g = h.height > p;
                        if (g) {
                            (0, l.ensureNotNull)(this._scrollWrapRef).style.overflowY = "scroll", h = c.getBoundingClientRect()
                        }
                        const {
                            width: b,
                            height: v
                        } = h, _ = "function" == typeof r ? r(b, v, d) : r, T = u - (null !== (i = _.overrideWidth) && void 0 !== i ? i : b) - 0, C = (0, a.clamp)(_.x, 0, Math.max(0, T)), f = 0 + m, w = d - (null !== (n = _.overrideHeight) && void 0 !== n ? n : v) - 0;
                        let k = (0, a.clamp)(_.y, f, Math.max(f, w));
                        if (_.forbidCorrectYCoord && k < _.y && (p -= _.y - k, k = _.y), t && void 0 !== this.props.closeOnScrollOutsideOffset && _.y <= this.props.closeOnScrollOutsideOffset) return void this._handleGlobalClose(!0);
                        const y = null !== (s = _.overrideHeight) && void 0 !== s ? s : g ? p : void 0;
                        this.setState({
                            appearingMenuHeight: t ? this.state.appearingMenuHeight : y,
                            appearingMenuWidth: t ? this.state.appearingMenuWidth : _.overrideWidth,
                            appearingPosition: {
                                x: C,
                                y: k
                            },
                            isMeasureValid: !0
                        }, () => {
                            this._restoreScrollPosition(), e && e()
                        })
                    }, this._restoreScrollPosition = () => {
                        const e = document.activeElement,
                            t = (0, l.ensureNotNull)(this._containerRef);
                        if (null !== e && t.contains(e)) try {
                            e.scrollIntoView()
                        } catch (e) {} else(0, l.ensureNotNull)(this._scrollWrapRef).scrollTop = this._scroll
                    }, this._resizeForced = () => {
                        this.setState({
                            appearingMenuHeight: void 0,
                            appearingMenuWidth: void 0,
                            appearingPosition: void 0,
                            isMeasureValid: void 0
                        })
                    }, this._resize = () => {
                        null === this._raf && (this._raf = requestAnimationFrame(() => {
                            this.setState({
                                appearingMenuHeight: void 0,
                                appearingMenuWidth: void 0,
                                appearingPosition: void 0,
                                isMeasureValid: void 0
                            }), this._raf = null
                        }))
                    }, this._handleGlobalClose = e => {
                        this.props.onClose(e)
                    }, this._handleSlot = e => {
                        this._manager.setContainer(e)
                    }, this._handleScroll = () => {
                        this._scroll = (0, l.ensureNotNull)(this._scrollWrapRef).scrollTop
                    }, this._handleScrollOutsideEnd = () => {
                        clearTimeout(this._scrollTimeout), this._scrollTimeout = setTimeout(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            })
                        }, 80)
                    }, this._handleScrollOutside = e => {
                        e.target !== this._scrollWrapRef && (this._handleScrollOutsideEnd(), null === this._scrollRaf && (this._scrollRaf = requestAnimationFrame(() => {
                            this._handleMeasure({
                                forceRecalcPosition: !0
                            }), this._scrollRaf = null
                        })))
                    }, this.state = {}
                }
                componentDidMount() {
                    this._handleMeasure({
                        callback: this.props.onOpen
                    });
                    const {
                        customCloseDelegate: e = h.globalCloseDelegate
                    } = this.props;
                    e.subscribe(this, this._handleGlobalClose), window.addEventListener("resize", this._resize);
                    const t = null !== this.context;
                    this._hotkeys || t || (this._hotkeys = u.createGroup({
                        desc: "Popup menu"
                    }), this._hotkeys.add({
                        desc: "Close",
                        hotkey: 27,
                        handler: () => this._handleGlobalClose()
                    })), this.props.repositionOnScroll && window.addEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    })
                }
                componentDidUpdate() {
                    this._handleMeasure()
                }
                componentWillUnmount() {
                    const {
                        customCloseDelegate: e = h.globalCloseDelegate
                    } = this.props;
                    e.unsubscribe(this, this._handleGlobalClose), window.removeEventListener("resize", this._resize), window.removeEventListener("scroll", this._handleScrollOutside, {
                        capture: !0
                    }), this._hotkeys && (this._hotkeys.destroy(), this._hotkeys = null), null !== this._raf && (cancelAnimationFrame(this._raf), this._raf = null), null !== this._scrollRaf && (cancelAnimationFrame(this._scrollRaf), this._scrollRaf = null), this._scrollTimeout && clearTimeout(this._scrollTimeout)
                }
                render() {
                    const {
                        id: e,
                        role: t,
                        "aria-labelledby": o,
                        "aria-activedescendant": n,
                        children: l,
                        minWidth: a,
                        theme: h = g,
                        className: d,
                        maxHeight: u,
                        onMouseOver: b,
                        onMouseOut: v,
                        onKeyDown: T,
                        onFocus: C,
                        onBlur: f
                    } = this.props, {
                        appearingMenuHeight: w,
                        appearingMenuWidth: k,
                        appearingPosition: y,
                        isMeasureValid: S
                    } = this.state;
                    return i.createElement(p.MenuContext.Provider, {
                        value: this
                    }, i.createElement(m.SubmenuHandler, null, i.createElement(c.SlotContext.Provider, {
                        value: this._manager
                    }, i.createElement("div", {
                        id: e,
                        role: t,
                        "aria-labelledby": o,
                        "aria-activedescendant": n,
                        className: s()(d, h.menuWrap, !S && h.isMeasuring),
                        style: {
                            height: w,
                            left: y && y.x,
                            minWidth: a,
                            position: "fixed",
                            top: y && y.y,
                            width: k
                        },
                        "data-name": this.props["data-name"],
                        ref: this._handleContainerRef,
                        onScrollCapture: this.props.onScroll,
                        onContextMenu: r.preventDefaultForContextMenu,
                        tabIndex: this.props.tabIndex,
                        onMouseOver: b,
                        onMouseOut: v,
                        onKeyDown: T,
                        onFocus: C,
                        onBlur: f
                    }, i.createElement("div", {
                        className: s()(h.scrollWrap, !this.props.noMomentumBasedScroll && h.momentumBased),
                        style: {
                            overflowY: void 0 !== w ? "scroll" : "auto",
                            maxHeight: u
                        },
                        onScrollCapture: this._handleScroll,
                        ref: this._handleScrollWrapRef
                    }, i.createElement(_, {
                        className: h.menuBox
                    }, l)))), i.createElement(c.Slot, {
                        reference: this._handleSlot
                    })))
                }
                update(e) {
                    e ? this._resizeForced() : this._resize()
                }
            }

            function _(e) {
                const t = (0, l.ensureNotNull)((0, i.useContext)(m.SubmenuContext)),
                    o = i.useRef(null);
                return i.createElement("div", {
                    ref: o,
                    className: e.className,
                    onMouseOver: function(e) {
                        if (!(null !== t.current && e.target instanceof Node && (i = e.target, null === (n = o.current) || void 0 === n ? void 0 : n.contains(i)))) return;
                        var i, n;
                        t.isSubmenuNode(e.target) || t.setCurrent(null)
                    },
                    "data-name": "menu-inner"
                }, e.children)
            }
            v.contextType = m.SubmenuContext
        },
        63212: (e, t, o) => {
            "use strict";
            o.d(t, {
                OverlapManager: () => s,
                getRootOverlapManager: () => a
            });
            var i = o(88537);
            class n {
                constructor() {
                    this._storage = []
                }
                add(e) {
                    this._storage.push(e)
                }
                remove(e) {
                    this._storage = this._storage.filter(t => e !== t)
                }
                has(e) {
                    return this._storage.includes(e)
                }
                getItems() {
                    return this._storage
                }
            }
            class s {
                constructor(e = document) {
                    this._storage = new n, this._windows = new Map, this._index = 0, this._document = e, this._container = e.createDocumentFragment()
                }
                setContainer(e) {
                    const t = this._container,
                        o = null === e ? this._document.createDocumentFragment() : e;
                    ! function(e, t) {
                        Array.from(e.childNodes).forEach(e => {
                            e.nodeType === Node.ELEMENT_NODE && t.appendChild(e)
                        })
                    }(t, o), this._container = o
                }
                registerWindow(e) {
                    this._storage.has(e) || this._storage.add(e)
                }
                ensureWindow(e, t = {
                    position: "fixed",
                    direction: "normal"
                }) {
                    const o = this._windows.get(e);
                    if (void 0 !== o) return o;
                    this.registerWindow(e);
                    const i = this._document.createElement("div");
                    if (i.style.position = t.position, i.style.zIndex = this._index.toString(), i.dataset.id = e, void 0 !== t.index) {
                        const e = this._container.childNodes.length;
                        if (t.index >= e) this._container.appendChild(i);
                        else if (t.index <= 0) this._container.insertBefore(i, this._container.firstChild);
                        else {
                            const e = this._container.childNodes[t.index];
                            this._container.insertBefore(i, e)
                        }
                    } else "reverse" === t.direction ? this._container.insertBefore(i, this._container.firstChild) : this._container.appendChild(i);
                    return this._windows.set(e, i), ++this._index, i
                }
                unregisterWindow(e) {
                    this._storage.remove(e);
                    const t = this._windows.get(e);
                    void 0 !== t && (null !== t.parentElement && t.parentElement.removeChild(t), this._windows.delete(e))
                }
                getZindex(e) {
                    const t = this.ensureWindow(e);
                    return parseInt(t.style.zIndex || "0")
                }
                moveToTop(e) {
                    if (this.getZindex(e) !== this._index) {
                        this.ensureWindow(e).style.zIndex = (++this._index).toString()
                    }
                }
                removeWindow(e) {
                    this.unregisterWindow(e)
                }
            }
            const l = new WeakMap;

            function a(e = document) {
                const t = e.getElementById("overlap-manager-root");
                if (null !== t) return (0, i.ensureDefined)(l.get(t)); {
                    const t = new s(e),
                        o = function(e) {
                            const t = e.createElement("div");
                            return t.style.position = "absolute", t.style.zIndex = 150..toString(), t.style.top = "0px", t.style.left = "0px", t.id = "overlap-manager-root", t
                        }(e);
                    return l.set(o, t), t.setContainer(o), e.body.appendChild(o), t
                }
            }
        },
        14417: (e, t, o) => {
            "use strict";
            o.d(t, {
                multilineLabelWithIconAndToolboxTheme: () => l
            });
            var i = o(93173),
                n = o(23576),
                s = o(63095);
            const l = (0, i.mergeThemes)(n, s)
        },
        17850: (e, t, o) => {
            "use strict";
            o.d(t, {
                PopupMenuSeparator: () => a
            });
            var i = o(59496),
                n = o(97754),
                s = o.n(n),
                l = o(524);

            function a(e) {
                const {
                    size: t = "normal",
                    className: o
                } = e;
                return i.createElement("div", {
                    className: s()(l.separator, "small" === t && l.small, "normal" === t && l.normal, "large" === t && l.large, o)
                })
            }
        },
        28466: (e, t, o) => {
            "use strict";
            o.d(t, {
                CloseDelegateContext: () => s
            });
            var i = o(59496),
                n = o(70981);
            const s = i.createContext(n.globalCloseDelegate)
        },
        8361: (e, t, o) => {
            "use strict";
            o.d(t, {
                Portal: () => r,
                PortalContext: () => c
            });
            var i = o(59496),
                n = o(87995),
                s = o(16345),
                l = o(63212),
                a = o(53327);
            class r extends i.PureComponent {
                constructor() {
                    super(...arguments), this._uuid = (0, s.guid)()
                }
                componentWillUnmount() {
                    this._manager().removeWindow(this._uuid)
                }
                render() {
                    const e = this._manager().ensureWindow(this._uuid, this.props.layerOptions);
                    return e.style.top = this.props.top || "", e.style.bottom = this.props.bottom || "", e.style.left = this.props.left || "", e.style.right = this.props.right || "", e.style.pointerEvents = this.props.pointerEvents || "", n.createPortal(i.createElement(c.Provider, {
                        value: this
                    }, this.props.children), e)
                }
                moveToTop() {
                    this._manager().moveToTop(this._uuid)
                }
                _manager() {
                    return null === this.context ? (0, l.getRootOverlapManager)() : this.context
                }
            }
            r.contextType = a.SlotContext;
            const c = i.createContext(null)
        },
        53327: (e, t, o) => {
            "use strict";
            o.d(t, {
                Slot: () => n,
                SlotContext: () => s
            });
            var i = o(59496);
            class n extends i.Component {
                shouldComponentUpdate() {
                    return !1
                }
                render() {
                    return i.createElement("div", {
                        style: {
                            position: "fixed",
                            zIndex: 150,
                            left: 0,
                            top: 0
                        },
                        ref: this.props.reference
                    })
                }
            }
            const s = i.createContext(null)
        },
        94488: (e, t, o) => {
            "use strict";
            o.d(t, {
                SubmenuContext: () => n,
                SubmenuHandler: () => s
            });
            var i = o(59496);
            const n = i.createContext(null);

            function s(e) {
                const [t, o] = (0, i.useState)(null), s = (0, i.useRef)(null), l = (0, i.useRef)(new Map);
                return (0, i.useEffect)(() => () => {
                    null !== s.current && clearTimeout(s.current)
                }, []), i.createElement(n.Provider, {
                    value: {
                        current: t,
                        setCurrent: function(e) {
                            null !== s.current && (clearTimeout(s.current), s.current = null);
                            null === t ? o(e) : s.current = setTimeout(() => {
                                s.current = null, o(e)
                            }, 100)
                        },
                        registerSubmenu: function(e, t) {
                            return l.current.set(e, t), () => {
                                l.current.delete(e)
                            }
                        },
                        isSubmenuNode: function(e) {
                            return Array.from(l.current.values()).some(t => t(e))
                        }
                    }
                }, e.children)
            }
        },
        86219: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 10" width="20" height="10"><path fill="none" stroke="currentColor" stroke-width="1.5" d="M2 1l8 8 8-8"/></svg>'
        },
        82219: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="19" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.103.687a1 1 0 0 1 1.794 0l2.374 4.81 5.309.772a1 1 0 0 1 .554 1.706l-3.841 3.745.906 5.287a1 1 0 0 1-1.45 1.054L10 15.565 5.252 18.06A1 1 0 0 1 3.8 17.007l.907-5.287L.866 7.975a1 1 0 0 1 .554-1.706l5.31-.771L9.102.688zM10 1.13L7.393 6.412l-5.829.847 4.218 4.111-.996 5.806L10 14.436l5.214 2.74-.996-5.805 4.218-4.112-5.83-.847L10 1.13z"/></svg>'
        }
    }
]);
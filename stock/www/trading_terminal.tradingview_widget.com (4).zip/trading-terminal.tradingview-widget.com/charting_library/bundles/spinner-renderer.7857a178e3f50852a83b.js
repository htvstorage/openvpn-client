"use strict";
(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [7102], {
        74063: (e, n, r) => {
            r.r(n), r.d(n, {
                render: () => a,
                destroy: () => o
            });
            var s = r(59496),
                t = r(87995),
                i = r(32455);

            function a(e) {
                t.render(s.createElement(i.Spinner), e)
            }

            function o(e) {
                t.unmountComponentAtNode(e)
            }
        },
        32455: (e, n, r) => {
            r.d(n, {
                Spinner: () => a
            });
            var s = r(59496),
                t = r(97754),
                i = r(63654);
            r(24780);

            function a(e) {
                const n = t(e.className, "tv-spinner", "tv-spinner--shown", "tv-spinner--size_" + i.spinnerSizeMap[e.size || i.DEFAULT_SIZE]);
                return s.createElement("div", {
                    className: n,
                    style: e.style,
                    role: "progressbar"
                })
            }
        }
    }
]);
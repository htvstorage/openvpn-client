(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [8354], {
        92395: () => {},
        37593: e => {
            e.exports = {
                wrapper: "wrapper-5Xd5conM",
                input: "input-5Xd5conM",
                box: "box-5Xd5conM",
                icon: "icon-5Xd5conM",
                noOutline: "noOutline-5Xd5conM",
                "intent-danger": "intent-danger-5Xd5conM",
                check: "check-5Xd5conM",
                dot: "dot-5Xd5conM"
            }
        },
        96670: e => {
            e.exports = {
                checkbox: "checkbox-GxG6nBa7",
                reverse: "reverse-GxG6nBa7",
                label: "label-GxG6nBa7",
                baseline: "baseline-GxG6nBa7"
            }
        },
        55576: e => {
            e.exports = {
                button: "button-9pA37sIi",
                hover: "hover-9pA37sIi",
                isInteractive: "isInteractive-9pA37sIi",
                isGrouped: "isGrouped-9pA37sIi",
                newStyles: "newStyles-9pA37sIi",
                isActive: "isActive-9pA37sIi",
                isOpened: "isOpened-9pA37sIi",
                isDisabled: "isDisabled-9pA37sIi",
                text: "text-9pA37sIi",
                icon: "icon-9pA37sIi"
            }
        },
        78966: e => {
            e.exports = {
                title: "title-mAu74Mtg"
            }
        },
        71123: e => {
            e.exports = {
                button: "button-khcLBZEz",
                hover: "hover-khcLBZEz",
                arrow: "arrow-khcLBZEz",
                arrowWrap: "arrowWrap-khcLBZEz",
                newStyles: "newStyles-khcLBZEz",
                isOpened: "isOpened-khcLBZEz"
            }
        },
        4339: e => {
            e.exports = {
                title: "title-uBToaXxI",
                currency: "currency-uBToaXxI",
                activeCurrency: "activeCurrency-uBToaXxI",
                label: "label-uBToaXxI",
                labelWrapper: "labelWrapper-uBToaXxI",
                summary: "summary-uBToaXxI",
                dropdown: "dropdown-uBToaXxI",
                singleItemDropdown: "singleItemDropdown-uBToaXxI",
                content: "content-uBToaXxI"
            }
        },
        10794: e => {
            e.exports = {
                wrapper: "wrapper-g6lUYjBY"
            }
        },
        16719: e => {
            e.exports = {
                headerWrapper: "headerWrapper-dbzrfmFA"
            }
        },
        51871: e => {
            e.exports = {
                itemWrapper: "itemWrapper-tp4JSoHa",
                value: "value-tp4JSoHa",
                title: "title-tp4JSoHa"
            }
        },
        55983: e => {
            e.exports = {
                wrapper: "wrapper-EiWh73lq"
            }
        },
        47276: e => {
            e.exports = {
                accountManager: "accountManager-N8TKUQxc",
                topPanel: "topPanel-N8TKUQxc",
                secondaryPanel: "secondaryPanel-N8TKUQxc",
                content: "content-N8TKUQxc",
                page: "page-N8TKUQxc"
            }
        },
        81334: e => {
            e.exports = {
                pageContainer: "pageContainer-fitxEu8O"
            }
        },
        85410: e => {
            e.exports = {
                counter: "counter-9Y0FRxjC",
                text: "text-9Y0FRxjC",
                count: "count-9Y0FRxjC",
                blue: "blue-9Y0FRxjC",
                grey: "grey-9Y0FRxjC",
                green: "green-9Y0FRxjC",
                orange: "orange-9Y0FRxjC",
                red: "red-9Y0FRxjC"
            }
        },
        4834: e => {
            e.exports = {
                counter: "counter-IcPlk7WW",
                text: "text-IcPlk7WW",
                count: "count-IcPlk7WW"
            }
        },
        12356: e => {
            e.exports = {
                tableContainer: "tableContainer-EVvOTmMW",
                fitContent: "fitContent-EVvOTmMW",
                withScroll: "withScroll-EVvOTmMW",
                noScroll: "noScroll-EVvOTmMW"
            }
        },
        67761: e => {
            e.exports = {
                title: "title-zC6v6B9f"
            }
        },
        91802: e => {
            e.exports = {
                container: "container-TTrPke40",
                sticky: "sticky-TTrPke40"
            }
        },
        22795: e => {
            e.exports = {
                menuButton: "menuButton-eLgvCb0y",
                icon: "icon-eLgvCb0y",
                label: "label-eLgvCb0y",
                checkBox: "checkBox-eLgvCb0y"
            }
        },
        2627: e => {
            e.exports = {
                wrapper: "wrapper-R6hgQk56",
                icon: "icon-R6hgQk56",
                message: "message-R6hgQk56",
                warning: "warning-R6hgQk56",
                information: "information-R6hgQk56",
                error: "error-R6hgQk56"
            }
        },
        85769: e => {
            e.exports = {
                wrapper: "wrapper-cki5BFA5",
                info: "info-cki5BFA5",
                title: "title-cki5BFA5",
                description: "description-cki5BFA5"
            }
        },
        59260: e => {
            e.exports = {
                text: "text-P2FUw9Vj",
                noWrap: "noWrap-P2FUw9Vj"
            }
        },
        42206: e => {
            e.exports = {
                gray: "gray-nKJZM9Ax",
                blue: "blue-nKJZM9Ax",
                red: "red-nKJZM9Ax",
                green: "green-nKJZM9Ax",
                orange: "orange-nKJZM9Ax"
            }
        },
        85758: e => {
            e.exports = {
                "desktop-cell-padding": "6px 16px 2px",
                wrapper: "wrapper-bZH95Ecg"
            }
        },
        50357: e => {
            e.exports = {
                "mobile-row-padding": "4px",
                "mobile-row-border-size": "1px",
                "mobile-row-margin": "38px",
                "content-font-size": "14px",
                "desktop-cell-padding": "6px 16px 2px",
                table: "table-GTBQ4JqO",
                tableBody: "tableBody-GTBQ4JqO",
                tableHead: "tableHead-GTBQ4JqO",
                headCell: "headCell-GTBQ4JqO",
                headCellContent: "headCellContent-GTBQ4JqO",
                cell: "cell-GTBQ4JqO",
                capitalize: "capitalize-GTBQ4JqO",
                rightAlignedHeadCell: "rightAlignedHeadCell-GTBQ4JqO",
                rightAlignedCell: "rightAlignedCell-GTBQ4JqO",
                cellContent: "cellContent-GTBQ4JqO",
                hideLabelOnMobile: "hideLabelOnMobile-GTBQ4JqO",
                hideCellOnMobile: "hideCellOnMobile-GTBQ4JqO",
                row: "row-GTBQ4JqO",
                withMargin: "withMargin-GTBQ4JqO",
                withVirtualization: "withVirtualization-GTBQ4JqO",
                highlightedRow: "highlightedRow-GTBQ4JqO",
                inactiveRow: "inactiveRow-GTBQ4JqO",
                linkedRow: "linkedRow-GTBQ4JqO",
                successRow: "successRow-GTBQ4JqO",
                dangerRow: "dangerRow-GTBQ4JqO",
                tableWrapper: "tableWrapper-GTBQ4JqO",
                tableWrapperEmpty: "tableWrapperEmpty-GTBQ4JqO",
                fixedCell: "fixedCell-GTBQ4JqO"
            }
        },
        66164: e => {
            e.exports = {
                "mobile-row-padding": "4px",
                "mobile-row-border-size": "1px",
                "mobile-row-margin": "38px",
                "content-font-size": "14px",
                "cell-lateral-padding": "32px",
                "desktop-cell-padding": "6px 16px 2px"
            }
        },
        49818: e => {
            e.exports = {
                wrapper: "wrapper-iPWNBRdb"
            }
        },
        82515: e => {
            e.exports = {
                mobile: "screen and (max-width: 567px)"
            }
        },
        88913: () => {},
        66998: e => {
            e.exports = {
                wrap: "wrap-3HaHQVJm",
                positionBottom: "positionBottom-3HaHQVJm",
                backdrop: "backdrop-3HaHQVJm",
                drawer: "drawer-3HaHQVJm",
                positionLeft: "positionLeft-3HaHQVJm"
            }
        },
        91998: e => {
            e.exports = {
                checkbox: "checkbox-HU5RMv36"
            }
        },
        23576: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-4TFSfyGO",
                hovered: "hovered-4TFSfyGO",
                isDisabled: "isDisabled-4TFSfyGO",
                isActive: "isActive-4TFSfyGO",
                shortcut: "shortcut-4TFSfyGO",
                toolbox: "toolbox-4TFSfyGO",
                withIcon: "withIcon-4TFSfyGO",
                icon: "icon-4TFSfyGO",
                labelRow: "labelRow-4TFSfyGO",
                label: "label-4TFSfyGO",
                showOnHover: "showOnHover-4TFSfyGO"
            }
        },
        8323: (e, t, s) => {
            "use strict";
            s.d(t, {
                CheckboxInput: () => c
            });
            var i = s(59496),
                r = s(97754),
                o = s(72571),
                n = s(57369),
                a = s(37593),
                l = s.n(a);

            function c(e) {
                const t = r(l().box, l()["intent-" + e.intent], {
                        [l().check]: !Boolean(e.indeterminate),
                        [l().dot]: Boolean(e.indeterminate),
                        [l().noOutline]: -1 === e.tabIndex
                    }),
                    s = r(l().wrapper, e.className);
                return i.createElement("span", {
                    className: s,
                    title: e.title
                }, i.createElement("input", {
                    id: e.id,
                    tabIndex: e.tabIndex,
                    className: l().input,
                    type: "checkbox",
                    name: e.name,
                    checked: e.checked,
                    disabled: e.disabled,
                    value: e.value,
                    autoFocus: e.autoFocus,
                    role: e.role,
                    onChange: function() {
                        e.onChange && e.onChange(e.value)
                    },
                    ref: e.reference
                }), i.createElement("span", {
                    className: t
                }, i.createElement(o.Icon, {
                    icon: n,
                    className: l().icon
                })))
            }
        },
        2946: (e, t, s) => {
            "use strict";
            s.d(t, {
                Checkbox: () => c
            });
            var i = s(59496),
                r = s(97754),
                o = s(32834),
                n = s(8323),
                a = s(96670),
                l = s.n(a);
            class c extends i.PureComponent {
                render() {
                    const {
                        inputClassName: e,
                        labelClassName: t,
                        ...s
                    } = this.props, o = r(this.props.className, l().checkbox, {
                        [l().reverse]: Boolean(this.props.labelPositionReverse),
                        [l().baseline]: Boolean(this.props.labelAlignBaseline)
                    }), a = r(l().label, t, {
                        [l().disabled]: this.props.disabled
                    });
                    let c = null;
                    return this.props.label && (c = i.createElement("span", {
                        className: a,
                        title: this.props.title
                    }, this.props.label)), i.createElement("label", {
                        className: o
                    }, i.createElement(n.CheckboxInput, { ...s,
                        className: e
                    }), c)
                }
            }
            c.defaultProps = {
                value: "on"
            };
            (0, o.makeSwitchGroupItem)(c)
        },
        52130: (e, t, s) => {
            "use strict";
            s.d(t, {
                useIsMounted: () => r
            });
            var i = s(59496);
            const r = () => {
                const e = (0, i.useRef)(!1);
                return (0, i.useEffect)(() => (e.current = !0, () => {
                    e.current = !1
                }), []), e
            }
        },
        32834: (e, t, s) => {
            "use strict";
            s.d(t, {
                SwitchGroup: () => o,
                makeSwitchGroupItem: () => n
            });
            var i = s(59496),
                r = s(19036);
            class o extends i.PureComponent {
                constructor() {
                    super(...arguments), this._subscriptions = new Set, this._getName = () => this.props.name, this._getValues = () => this.props.values, this._getOnChange = () => this.props.onChange, this._subscribe = e => {
                        this._subscriptions.add(e)
                    }, this._unsubscribe = e => {
                        this._subscriptions.delete(e)
                    }
                }
                getChildContext() {
                    return {
                        switchGroupContext: {
                            getName: this._getName,
                            getValues: this._getValues,
                            getOnChange: this._getOnChange,
                            subscribe: this._subscribe,
                            unsubscribe: this._unsubscribe
                        }
                    }
                }
                render() {
                    return this.props.children
                }
                componentDidUpdate(e) {
                    this._notify(this._getUpdates(this.props.values, e.values))
                }
                _notify(e) {
                    this._subscriptions.forEach(t => t(e))
                }
                _getUpdates(e, t) {
                    return [...t, ...e].filter(s => t.includes(s) ? !e.includes(s) : e.includes(s))
                }
            }

            function n(e) {
                var t;
                return (t = class extends i.PureComponent {
                    constructor() {
                        super(...arguments), this._onChange = e => {
                            this.context.switchGroupContext.getOnChange()(e)
                        }, this._onUpdate = e => {
                            e.includes(this.props.value) && this.forceUpdate()
                        }
                    }
                    componentDidMount() {
                        this.context.switchGroupContext.subscribe(this._onUpdate)
                    }
                    render() {
                        return i.createElement(e, { ...this.props,
                            name: this._getName(),
                            onChange: this._onChange,
                            checked: this._isChecked()
                        })
                    }
                    componentWillUnmount() {
                        this.context.switchGroupContext.unsubscribe(this._onUpdate)
                    }
                    _getName() {
                        return this.context.switchGroupContext.getName()
                    }
                    _isChecked() {
                        return this.context.switchGroupContext.getValues().includes(this.props.value)
                    }
                }).contextTypes = {
                    switchGroupContext: r.any.isRequired
                }, t
            }
            o.childContextTypes = {
                switchGroupContext: r.any.isRequired
            }
        },
        47465: (e, t, s) => {
            "use strict";
            s.d(t, {
                makeCancelable: () => r,
                isCancelled: () => o
            });
            class i {}

            function r(e) {
                let t = !1;
                return {
                    promise: new Promise((s, r) => {
                        e.then(e => t ? r(new i) : s(e)), e.catch(e => r(t ? new i : e))
                    }),
                    cancel() {
                        t = !0
                    }
                }
            }

            function o(e) {
                return e instanceof i
            }
        },
        75803: (e, t, s) => {
            "use strict";
            s.d(t, {
                DEFAULT_TOOL_WIDGET_BUTTON_THEME: () => l,
                ToolWidgetButton: () => c
            });
            var i = s(59496),
                r = s(97754),
                o = s(72571),
                n = s(4257),
                a = s(55576);
            const l = a,
                c = i.forwardRef((e, t) => {
                    const {
                        icon: s,
                        isActive: l,
                        isOpened: c,
                        isDisabled: d,
                        isGrouped: h,
                        isHovered: u,
                        onClick: p,
                        text: _,
                        textBeforeIcon: m,
                        title: g,
                        theme: b = a,
                        className: v,
                        forceInteractive: f,
                        "data-name": w,
                        ...C
                    } = e, y = r(v, b.button, g && "apply-common-tooltip", {
                        [b.isActive]: l,
                        [b.isOpened]: c,
                        [b.isInteractive]: (f || Boolean(p)) && !d,
                        [b.isDisabled]: d,
                        [b.isGrouped]: h,
                        [b.hover]: u,
                        [b.newStyles]: n.hasNewHeaderToolbarStyles
                    }), S = s && ("string" == typeof s ? i.createElement(o.Icon, {
                        className: b.icon,
                        icon: s
                    }) : i.cloneElement(s, {
                        className: r(b.icon, s.props.className)
                    }));
                    return i.createElement("div", { ...C,
                        ref: t,
                        "data-role": "button",
                        className: y,
                        onClick: d ? void 0 : p,
                        title: g,
                        "data-name": w
                    }, m && _ && i.createElement("div", {
                        className: r("js-button-text", b.text)
                    }, _), S, !m && _ && i.createElement("div", {
                        className: r("js-button-text", b.text)
                    }, _))
                })
        },
        46369: (e, t, s) => {
            "use strict";
            s.d(t, {
                ToolWidgetMenuSummary: () => n
            });
            var i = s(59496),
                r = s(97754),
                o = s(78966);

            function n(e) {
                return i.createElement("div", {
                    className: r(e.className, o.title)
                }, e.children)
            }
        },
        34816: (e, t, s) => {
            "use strict";
            s.d(t, {
                DEFAULT_TOOL_WIDGET_MENU_THEME: () => _,
                ToolWidgetMenu: () => m
            });
            var i = s(59496),
                r = s(97754),
                o = s(44377),
                n = s(15783),
                a = s(417),
                l = s(63694),
                c = s(59339),
                d = s(85673),
                h = s(30052),
                u = s(4257),
                p = s(71123);
            const _ = p;
            class m extends i.PureComponent {
                constructor(e) {
                    super(e), this._wrapperRef = null, this._controller = i.createRef(), this._handleWrapperRef = e => {
                        this._wrapperRef = e, this.props.reference && this.props.reference(e)
                    }, this._handleClick = e => {
                        e.target instanceof Node && e.currentTarget.contains(e.target) && (this._handleToggleDropdown(), this.props.onClick && this.props.onClick(e, !this.state.isOpened))
                    }, this._handleToggleDropdown = e => {
                        const {
                            onClose: t,
                            onOpen: s
                        } = this.props, {
                            isOpened: i
                        } = this.state, r = "boolean" == typeof e ? e : !i;
                        this.setState({
                            isOpened: r
                        }), r && s && s(), !r && t && t()
                    }, this._handleClose = () => {
                        this.close()
                    }, this.state = {
                        isOpened: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        arrow: t,
                        content: s,
                        isDisabled: o,
                        isDrawer: l,
                        isShowTooltip: c,
                        title: d,
                        className: p,
                        hotKey: _,
                        theme: m,
                        drawerBreakpoint: g
                    } = this.props, {
                        isOpened: b
                    } = this.state, v = r(p, m.button, {
                        "apply-common-tooltip": c || !o,
                        [m.isDisabled]: o,
                        [m.isOpened]: b,
                        [m.newStyles]: u.hasNewHeaderToolbarStyles
                    });
                    return i.createElement("div", {
                        id: e,
                        className: v,
                        onClick: o ? void 0 : this._handleClick,
                        title: d,
                        "data-tooltip-hotkey": _,
                        ref: this._handleWrapperRef,
                        "data-role": "button",
                        ...(0, a.filterDataProps)(this.props)
                    }, s, t && i.createElement("div", {
                        className: m.arrow
                    }, i.createElement("div", {
                        className: m.arrowWrap
                    }, i.createElement(n.ToolWidgetCaret, {
                        dropped: b
                    }))), this.state.isOpened && (g ? i.createElement(h.MatchMedia, {
                        rule: g
                    }, e => this._renderContent(e)) : this._renderContent(l)))
                }
                close() {
                    this._handleToggleDropdown(!1)
                }
                update() {
                    null !== this._controller.current && this._controller.current.update()
                }
                _renderContent(e) {
                    const {
                        menuDataName: t,
                        minWidth: s,
                        menuClassName: r,
                        maxHeight: n,
                        drawerPosition: a = "Bottom",
                        children: h
                    } = this.props, {
                        isOpened: u
                    } = this.state, p = {
                        horizontalMargin: this.props.horizontalMargin || 0,
                        verticalMargin: this.props.verticalMargin || 2,
                        verticalAttachEdge: this.props.verticalAttachEdge,
                        horizontalAttachEdge: this.props.horizontalAttachEdge,
                        verticalDropDirection: this.props.verticalDropDirection,
                        horizontalDropDirection: this.props.horizontalDropDirection,
                        matchButtonAndListboxWidths: this.props.matchButtonAndListboxWidths
                    }, _ = Boolean(u && e && a), m = function(e) {
                        return "function" == typeof e
                    }(h) ? h({
                        isDrawer: _
                    }) : h;
                    return _ ? i.createElement(l.DrawerManager, null, i.createElement(c.Drawer, {
                        onClose: this._handleClose,
                        position: a,
                        "data-name": t
                    }, m)) : i.createElement(o.PopupMenu, {
                        controller: this._controller,
                        closeOnClickOutside: this.props.closeOnClickOutside,
                        doNotCloseOn: this,
                        isOpened: u,
                        minWidth: s,
                        onClose: this._handleClose,
                        position: (0, d.getPopupPositioner)(this._wrapperRef, p),
                        className: r,
                        maxHeight: n,
                        "data-name": t
                    }, m)
                }
            }
            m.defaultProps = {
                arrow: !0,
                closeOnClickOutside: !0,
                theme: p
            }
        },
        4257: (e, t, s) => {
            "use strict";
            s.d(t, {
                hasNewHeaderToolbarStyles: () => i
            });
            s(82527);
            const i = !1
        },
        73560: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                AccountManagerHeaderDropdowns: () => m
            });
            var i = s(59496),
                r = s(25177),
                o = s(97754),
                n = s.n(o),
                a = s(88537),
                l = s(1227),
                c = s(34816),
                d = s(92063),
                h = s(46369),
                u = s(4339);

            function p(e) {
                const {
                    currentAccount: t,
                    accountsList: s,
                    currentAccountUpdate: o
                } = e, [p, _] = (0, i.useState)(t);
                (0, i.useEffect)(() => (o.subscribe(null, g), () => {
                    o.unsubscribe(null, g)
                }), [o, s]);
                const m = void 0 !== p.currency ? `${p.name} (${p.currency})` : p.name;
                return 1 === s.length ? i.createElement("div", {
                    className: u.content
                }, i.createElement("span", {
                    className: u.singleItemDropdown
                }, m)) : i.createElement(c.ToolWidgetMenu, {
                    isDrawer: l.CheckMobile.any(),
                    content: i.createElement("span", {
                        className: u.content
                    }, m),
                    className: u.dropdown
                }, i.createElement(h.ToolWidgetMenuSummary, {
                    className: u.summary
                }, (0, r.t)("Accounts")), s.map(e => {
                    const t = p.id === e.id;
                    return i.createElement(d.PopupMenuItem, {
                        labelClassName: u.labelWrapper,
                        isActive: t,
                        label: i.createElement("div", {
                            className: u.label
                        }, i.createElement("div", {
                            className: u.title
                        }, e.name), void 0 !== e.currency && i.createElement("div", {
                            className: n()(u.currency, t && u.activeCurrency)
                        }, "(", e.currency, ")")),
                        onClick: () => e.callBack(),
                        key: e.id
                    })
                }));

                function g(e) {
                    _((0, a.ensureDefined)(s.find(t => t.id === e)))
                }
            }
            var _ = s(10794);

            function m(e) {
                const {
                    brokerDropdownProps: t,
                    accountDropdownProps: s
                } = e;
                return i.createElement("div", {
                    className: _.wrapper
                }, void 0 !== t && i.createElement(BrokerDropdown, { ...t
                }), i.createElement(p, { ...s
                }))
            }
        },
        38186: (e, t, s) => {
            "use strict";
            s.d(t, {
                makeAccountManagerHeaderDropdownsProps: () => u
            });
            var i = s(88537),
                r = s(50681),
                o = s(80802),
                n = s(52275),
                a = s(51951),
                l = s(50317);
            const c = (0, a.getLogger)("Trading.DataExport");
            class d {
                constructor(e, t) {
                    this._prefix = t, this._getDataExporters = e
                }
                tabs() {
                    return [...this._getDataExporters()].map(([e, t]) => ({
                        value: e,
                        content: t.title
                    }))
                }
                async exportData(e) {
                    const {
                        exporters: t,
                        title: s
                    } = (0, i.ensureDefined)(this._getDataExporters().get(e), "data exporter");
                    try {
                        const e = await Promise.all(t.map(({
                            exportData: e
                        }) => e()));
                        e.forEach((i, r) => {
                            const a = t[r].name,
                                l = void 0 === a || "" === a ? `${(0,o.default)(s)}${e.length>1?"-"+(r+1):""}` : (0, o.default)(a);
                            let c = "";
                            if (0 !== i.length) {
                                const e = [h(Object.keys(i[0]))];
                                for (const t of i) e.push(h(Object.values(t)));
                                c = e.join("\n")
                            }(0, n.saveTextFile)(`${(0,o.default)(this._prefix)}-${l}-${(new Date).toISOString()}.csv`, c, "text/csv")
                        })
                    } catch (e) {
                        c.logError((0, l.getLoggerMessage)(e))
                    }
                }
            }

            function h(e) {
                return e.map(n.escapeCSVValue).join(",")
            }
            async function u(e, t, s) {
                const o = e.brokersList().filter(e => !e.configFlags.isSuspended),
                    n = Promise.resolve(void 0),
                    a = (0, i.ensureNotNull)(e.activeBroker()),
                    l = await n,
                    c = await a.accountsMetainfo(),
                    h = a.accountManagerInfo();
                if (0 === c.length) return;
                const u = c.map(e => {
                        var t;
                        return {
                            id: e.id,
                            name: e.name,
                            callBack: async () => {
                                e.id !== a.currentAccount() && a.setCurrentAccount(e.id)
                            },
                            currency: "" === e.currency ? void 0 : null !== (t = e.currency) && void 0 !== t ? t : void 0
                        }
                    }),
                    p = u.find(e => e.id === a.currentAccount()),
                    _ = a.metainfo(),
                    m = void 0 !== l ? (0, r.brokersListFromPlans)(o, l) : void 0;
                return {
                    brokerDropdownProps: void 0 === m ? void 0 : {
                        title: h.accountTitle,
                        brokerName: _.title,
                        logo: _.logoMiniUrl,
                        logoBlack: _.logoMiniBlackUrl,
                        actions: a.buttonDropdownActions(),
                        dataExportController: void 0 !== s ? new d(s, _.title) : void 0,
                        trading: e,
                        brokers: m,
                        initialSummaryFieldsVisibilityInfo: t.fieldsVisibilityInfo(),
                        summaryFieldsVisibilityInfo$: t.fieldsVisibilityInfo$,
                        summaryFieldToggler: t.toggleField
                    },
                    accountDropdownProps: {
                        currentAccount: (0, i.ensureDefined)(p),
                        accountsList: u,
                        currentAccountUpdate: a.currentAccountUpdate
                    }
                }
            }
        },
        56718: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                AccountManager: () => Ms
            });
            var i, r = s(25177),
                o = s(59496),
                n = s(87995),
                a = s(59255),
                l = s(88537),
                c = s(88401),
                d = s(1227),
                h = s(82527),
                u = (s(92395), s(72535)),
                p = s(85787),
                _ = s(87213),
                m = s(97496),
                g = s.n(m),
                b = s(94511),
                v = s(25914),
                f = s(70122),
                w = s(34581),
                C = s(42609);
            ! function(e) {
                e[e.Left = 0] = "Left", e[e.Right = 1] = "Right"
            }(i || (i = {}));
            const y = {
                    saveTab: "",
                    noSlider: !1,
                    onTabClick: !1,
                    loadedClass: "i-loaded",
                    tabsContainerClass: "tv-tabs",
                    tabClass: "tv-tabs__tab",
                    tabDisabledClass: "disabled",
                    activeTabClass: "i-active",
                    activePageClass: "active",
                    sliderClass: "tv-tabs__slider",
                    scrollBoxClass: "tv-tabs__scroll-box",
                    scrollWrapClass: "tv-tabs__scroll-wrap",
                    lArrowClass: "tv-tabs__left-arrow",
                    rArrowClass: "tv-tabs__right-arrow"
                },
                S = b,
                T = v;
            class x {
                constructor(e, t, s = {}) {
                    this._animating = !1, this._prevWidth = -1, this._bindings = [], this._options = (0, _.deepExtend)({}, y, s), this.tabChanged = new(g()), this._elTabs = e, this._elPages = t, this._elScrollWrap = D(this._options.scrollWrapClass || "", this._elTabs, "wrapInner"), this._elScrollBox = D(this._options.scrollBoxClass || "", this._elScrollWrap, "wrapInner"), this._options.noSlider || (this._elSlider = D(this._options.sliderClass || "", this._elScrollBox, "append")), u.mobiletouch || (this._elArrowLeft = D(this._options.lArrowClass || "", this._elTabs, "append", `<div class="${this._options.lArrowClass||""} i-slided">${S}</div>`), this._elArrowRight = D(this._options.rArrowClass || "", this._elTabs, "append", `<div class="${this._options.rArrowClass||""} i-slided">${T}</div>`), this._addClass(this._elArrowLeft, this._options.addLeftArrowsClass), this._addClass(this._elArrowRight, this._options.addRightArrowsClass)), this._addClass(this._elScrollBox, this._options.addScrollBoxClass), this._addClass(this._elSlider, this._options.addSliderClass), this._addClass(this._elTabs, this._options.tabsContainerClass), this._addClass(this.getTabsArray(), this._options.tabClass), this._addClass(this._elTabs, this._options.loadedClass), this.checkScrollArrows(!0), this._initActivePage(), this._bindEvents()
                }
                getTabsArray() {
                    const e = this._elScrollBox.children;
                    if (!this._options.sliderClass) return Array.prototype.slice.call(e);
                    const t = [];
                    for (let s = 0; s < e.length; s++) {
                        const i = e[s];
                        P(i, this._options.sliderClass) || t.push(i)
                    }
                    return t
                }
                getPagesArray() {
                    return this._elPages ? Array.prototype.slice.call(this._elPages.children) : []
                }
                getElTabs() {
                    return this._elTabs
                }
                getElPages() {
                    return this._elPages
                }
                checkScrollArrows(e = !1) {
                    const t = Math.ceil(this._elScrollWrap.scrollLeft),
                        s = E(this._elScrollWrap),
                        r = this._elScrollWrap.scrollWidth - s - 2;

                    function o(e) {
                        M(e, "i-slided"), e.style.transition = ""
                    }

                    function n(t, s) {
                        F(t, "i-slided"), e && (t.style.transition = "none")
                    }
                    this._elArrowLeft && (t >= 1 ? o(this._elArrowLeft) : (t <= 1 || this._elScrollWrap.scrollWidth <= s) && n(this._elArrowLeft, i.Left)), this._elArrowRight && (r - t > 1 ? o(this._elArrowRight) : (t >= r || this._elScrollWrap.scrollWidth <= s) && n(this._elArrowRight, i.Right))
                }
                index() {
                    const e = this.getElActiveTab();
                    return e ? this.getTabsArray().indexOf(e) : -1
                }
                getElActiveTab() {
                    return this._getActiveElement(this.getTabsArray(), this._options.activeTabClass || "", this._options.inactiveTabClass)
                }
                getElActivePage() {
                    return this._getActiveElement(this.getPagesArray(), this._options.activePageClass || "", this._options.inactivePageClass)
                }
                setActivePage(e, t, s) {
                    if (-1 === e || e === this.index() && !s) return;
                    const i = this.index();

                    function r(t, s, i) {
                        t.forEach((t, r) => {
                            const o = e === r;
                            s && A(t, s, o), i && A(t, i, !o)
                        })
                    }
                    r(this.getTabsArray(), this._options.activeTabClass, this._options.inactiveTabClass), r(this.getPagesArray(), this._options.activePageClass, this._options.inactivePageClass), this._options.noSlider || this.updateSlider(i, e, t), this._options.saveTab && f.setValue(this._options.saveTab, e), this.tabChanged.fire(e)
                }
                updateSlider(e, t, s) {
                    if (this._options.noSlider) return;
                    const i = this.getTabsArray()[t];
                    if (0 === i.clientWidth || 0 === i.clientHeight || "none" === window.getComputedStyle(i).getPropertyValue("display")) return;
                    const r = window.getComputedStyle(i);
                    let o = i.offsetLeft + parseInt(r.getPropertyValue("padding-left")),
                        n = E(i);
                    const a = i.querySelector(".js-tabs__slider-pos");
                    if (a) {
                        const e = window.getComputedStyle(a);
                        o += parseInt(e.getPropertyValue("padding-left")) + a.offsetLeft, n -= n - E(a)
                    }
                    if (s = s || -1 === e || document.all && !window.atob) this._elSlider.style.left = o + "px", this._elSlider.style.width = n + "px";
                    else {
                        this._animating = !0;
                        const e = parseInt(getComputedStyle(this._elSlider).left),
                            t = parseInt(getComputedStyle(this._elSlider).width);
                        (0, C.doAnimate)({
                            from: e,
                            to: o,
                            duration: p.dur,
                            onStep: (e, t) => {
                                this._elSlider.style.left = t + "px"
                            }
                        }), (0, C.doAnimate)({
                            from: t,
                            to: n,
                            duration: p.dur,
                            onStep: (e, t) => {
                                this._elSlider.style.width = t + "px"
                            },
                            onComplete: () => {
                                this._animating = !1
                            }
                        })
                    }
                }
                onTabClick(e) {
                    const t = e.currentTarget || e.target,
                        s = this.getTabsArray().indexOf(t); - 1 === s || this._isTabDisabled(t) || this.setActivePage(s), document.activeElement.blur(), e.preventDefault()
                }
                resizeSlider() {
                    if (this._options.noSlider) return;
                    const e = this._elTabs.offsetWidth;
                    if (e === this._prevWidth) return;
                    this._prevWidth = e;
                    const t = this.index();
                    this.updateSlider(t, t, !0)
                }
                count() {
                    return this.getTabsArray().length
                }
                add(e, t) {
                    this._elScrollBox.appendChild(e), this._elPages && t && this._elPages.appendChild(t), this._bindTabEvents(e), this.checkScrollArrows(!0)
                }
                remove(e) {
                    function t(e) {
                        e.parentElement && e.parentElement.removeChild(e)
                    }
                    const s = this.tabAt(e);
                    s && (this._unbindTabEvents(s), t(s));
                    const i = this.pageAt(e);
                    i && t(i);
                    const r = e - 1 >= 0 ? e - 1 : 0;
                    this.setActivePage(r), this.checkScrollArrows(!0)
                }
                indexOfTab(e) {
                    return this.getTabsArray().indexOf(e)
                }
                indexOfPage(e) {
                    return this.getPagesArray().indexOf(e)
                }
                pageAt(e) {
                    return this.getPagesArray()[e] || null
                }
                tabAt(e) {
                    return this.getTabsArray()[e] || null
                }
                deselect() {
                    const e = this.getElActiveTab();
                    this._options.activeTabClass && e && M(e, this._options.activeTabClass);
                    const t = this.getElActivePage();
                    return this._options.activePageClass && t && M(t, this._options.activePageClass), this._elSlider && (this._elSlider.style.left = "", this._elSlider.style.width = ""), this
                }
                stop() {
                    this._unbindEvents({})
                }
                _addClass(e, t) {
                    "string" == typeof t && (Array.isArray(e) || (e = [e]), e.forEach(e => {
                        F(e, t)
                    }))
                }
                _initActivePage() {
                    let e = 0;
                    this._options.saveTab && (e = f.getInt(this._options.saveTab, 0));
                    const t = this.index(); - 1 !== t && (e = t), void 0 !== this._options.activeTab && (e = this._options.activeTab), this.setActivePage(e, !0, !0)
                }
                _bindEvents() {
                    this.getTabsArray().forEach(this._bindTabEvents.bind(this)), this._bindOneEvent({
                        eventName: "scroll",
                        listener: this.checkScrollArrows.bind(this, !1),
                        target: this._elScrollWrap
                    }), this._elArrowLeft && this._bindOneEvent({
                        eventName: "click",
                        listener: () => {
                            const e = this.getTabsArray();
                            let t = 0,
                                s = !1;
                            const i = this._elScrollWrap.scrollLeft;
                            (0, w.isRtl)() && e.reverse(), e.forEach(e => {
                                if (s) return;
                                const r = e.offsetLeft + e.offsetWidth;
                                r > i ? s = !0 : t = r
                            }), (0, C.doAnimate)({
                                from: this._elScrollWrap.scrollLeft,
                                to: this._elScrollWrap.scrollLeft + Math.floor(t - i - E(this._elArrowLeft)),
                                duration: p.dur / 2,
                                onStep: (e, t) => {
                                    this._elScrollWrap.scrollLeft = t
                                }
                            })
                        },
                        target: this._elArrowLeft
                    }), this._elArrowRight && this._bindOneEvent({
                        eventName: "click",
                        listener: () => {
                            const e = this.getTabsArray();
                            let t = 0;
                            const s = (0, w.isRtl)() ? 0 : this._elScrollWrap.scrollLeft + E(this._elScrollWrap);
                            (0, w.isRtl)() && e.reverse(), e.forEach(e => {
                                if (0 !== t) return;
                                const i = e.offsetLeft + e.offsetWidth;
                                i > s && (t = i)
                            }), (0, C.doAnimate)({
                                from: this._elScrollWrap.scrollLeft,
                                to: this._elScrollWrap.scrollLeft + Math.ceil(t - s + E((0, l.ensureDefined)(this._elArrowRight))),
                                duration: p.dur / 2,
                                onStep: (e, t) => {
                                    this._elScrollWrap.scrollLeft = t
                                }
                            })
                        },
                        target: this._elArrowRight
                    });
                    const e = Array.prototype.slice.call(this._elTabs.querySelectorAll(".js-tabs__slider-hover") || []);
                    e.length && e.forEach(e => this._bindOneEvent({
                        eventName: "mouseenter",
                        listener: e => {
                            if (this._animating) return;
                            const t = e.currentTarget;
                            t && this._options.activeTabClass && P(t, this._options.activeTabClass) && this._hoverSlider(t)
                        },
                        target: e
                    }));
                    let t = null;
                    const s = () => {
                        t = null, this.checkScrollArrows(!0), this._options.noSlider || this.resizeSlider()
                    };
                    this._bindOneEvent({
                        eventName: "resize",
                        listener: () => {
                            null === t && (t = window.requestAnimationFrame(s))
                        },
                        target: window
                    })
                }
                _bindTabEvents(e) {
                    this._bindOneEvent({
                        eventName: "click",
                        listener: e => {
                            "function" == typeof this._options.onTabClick ? this._options.onTabClick(e) : this.onTabClick(e)
                        },
                        target: e
                    })
                }
                _unbindTabEvents(e) {
                    this._unbindEvents({
                        target: e
                    })
                }
                _bindOneEvent(e) {
                    e.target.addEventListener(e.eventName, e.listener), this._bindings.push(e)
                }
                _unbindEvents(e) {
                    const t = t => !(void 0 !== t.eventName && t.eventName !== e.eventName || void 0 !== t.target && t.target !== e.target || void 0 !== t.listener && t.listener !== e.listener);
                    this._bindings.filter(t).forEach(e => e.target.removeEventListener(e.eventName, e.listener)), this._bindings = this._bindings.filter(e => !t(e))
                }
                _getActiveElement(e, t, s) {
                    return e.filter(e => t ? P(e, t) : !!s && !P(e, s))[0] || null
                }
                _isTabDisabled(e) {
                    return P(e, "i-disabled") || this._options.tabDisabledClass && P(e, this._options.tabDisabledClass) || e.hasAttribute("disabled")
                }
                _hoverSlider(e) {
                    const t = E(e),
                        s = window.getComputedStyle(e),
                        i = e.offsetLeft + parseInt(s.getPropertyValue("padding-left")) + parseInt(s.getPropertyValue("margin-left"));
                    (0, C.doAnimate)({
                        from: parseInt(getComputedStyle(this._elSlider).left),
                        to: i,
                        duration: p.dur / 4,
                        onStep: (e, t) => {
                            this._elSlider.style.left = t + "px"
                        }
                    }), (0, C.doAnimate)({
                        from: parseInt(getComputedStyle(this._elSlider).width),
                        to: t,
                        duration: p.dur / 4,
                        onStep: (e, t) => {
                            this._elSlider.style.width = t + "px"
                        }
                    });
                    const r = () => {
                        this.getElActiveTab() === e && this._unhoverSlider(e), e.removeEventListener("mousleave", r)
                    };
                    e.addEventListener("mouseleave", r)
                }
                _unhoverSlider(e) {
                    const t = window.getComputedStyle(e),
                        s = e.querySelector(".js-tabs__slider-pos"),
                        i = window.getComputedStyle(s),
                        r = e.offsetLeft + parseInt(t.getPropertyValue("padding-left")) + parseInt(t.getPropertyValue("margin-left")) + parseInt(i.getPropertyValue("padding-left")) + s.offsetLeft,
                        o = E(e),
                        n = o - (o - E(s));
                    (0, C.doAnimate)({
                        from: parseInt(getComputedStyle(this._elSlider).left),
                        to: r,
                        duration: p.dur / 2,
                        onStep: (e, t) => {
                            this._elSlider.style.left = t + "px"
                        }
                    }), (0, C.doAnimate)({
                        from: parseInt(getComputedStyle(this._elSlider).width),
                        to: n,
                        duration: p.dur / 2,
                        onStep: (e, t) => {
                            this._elSlider.style.width = t + "px"
                        }
                    })
                }
            }

            function E(e) {
                if (0 === e.offsetWidth) return 0; {
                    const t = window.getComputedStyle(e);
                    return e.offsetWidth - parseFloat(t.getPropertyValue("padding-left")) - parseFloat(t.getPropertyValue("padding-right")) - parseFloat(t.getPropertyValue("border-left-width")) - parseFloat(t.getPropertyValue("border-right-width"))
                }
            }

            function D(e, t, s, i) {
                let r = t.querySelector("." + e);
                if (!r) {
                    const o = document.createElement("div");
                    if (o.innerHTML = i || `<div class="${e}"></div>`, r = o.firstElementChild, "append" === s) t.appendChild(r);
                    else {
                        if ("wrapInner" !== s) throw new Error("Unknown insertMethod"); {
                            const e = Array.prototype.slice.call(t.childNodes);
                            for (let t = 0; t < e.length; t++) r.appendChild(e[t]);
                            t.appendChild(r)
                        }
                    }
                }
                return r
            }

            function F(e, t) {
                e.classList.add(...k(t))
            }

            function M(e, t) {
                e.classList.remove(...k(t))
            }

            function P(e, t) {
                return k(t).every(t => e.classList.contains(t))
            }

            function A(e, t, s) {
                k(t).forEach(t => e.classList.toggle(t, s))
            }

            function k(e) {
                return e.split(/\s+/)
            }
            var O = s(50681),
                R = s(9696);
            class I {
                constructor(e) {
                    this._delegates = e
                }
                subscribe(e, t, s) {
                    this._delegates.forEach(i => i.subscribe(e, t, s))
                }
                unsubscribe(e, t) {
                    this._delegates.forEach(s => s.unsubscribe(e, t))
                }
                unsubscribeAll(e) {
                    this._delegates.forEach(t => t.unsubscribeAll(e))
                }
            }
            var N = s(33080),
                B = s(93605),
                U = s(18833);

            function L(e) {
                return 0 !== e.qty || 0 !== e.longQty && void 0 !== e.longQty || 0 !== e.shortQty && void 0 !== e.shortQty
            }
            var V, H = s(12334);
            ! function(e) {
                e.Success = "success", e.Danger = "danger"
            }(V || (V = {}));
            var W = s(47465);
            class j {
                constructor(e) {
                    this._active = !1, this._created = !1, this._started = !1, this._fullUpdateDelegate = null,
                        this._partialUpdateDelegate = null, this._deleteUpdateDelegate = null, this._noMoreEntries = !1, this._isLoadingMore = !1, this._fullUpdateCancel = null, this._exportData = async () => {
                            const e = this._active;
                            e || (this.start(), await this.setActive(!0));
                            const t = this._view.exportData();
                            return e || await this.setActive(!1), t
                        }, this._viewVisibilityHandler = e => {
                            this._model.setActive(e)
                        }, this._sortingChangeHandler = e => {
                            this._updateModelSortingState(e)
                        }, this._sizeChangeHandler = () => {
                            this._updateModelSortingState({
                                column: this._view.sortingColumn(),
                                mode: this._view.sortingMode()
                            })
                        };
                    const {
                        idProperty: t,
                        name: s,
                        model: i,
                        view: r,
                        source: o,
                        subscriptions: n,
                        supportPagination: a
                    } = e;
                    this._idProperty = t, this._model = i, this._view = r, this._name = s, this._source = o, this._subscriptions = n, this._supportPagination = Boolean(a)
                }
                start() {
                    this._started || (this._updateModelSortingState({
                        column: this._view.sortingColumn(),
                        mode: this._view.sortingMode()
                    }), this._subscribeUpdates(), this._subscribeView(), this._started = !0)
                }
                stop() {
                    this._started && (this._unsubscribeUpdates(), this._unsubscribeView(), this.reset(), this._started = !1)
                }
                isStarted() {
                    return this._started
                }
                async setActive(e) {
                    (0, l.assert)(!e || this._started, "Should be started first"), this._active !== e && (this._active = e, this._active && !this._created && await this._fullUpdate(), this._model.setActive(e))
                }
                isActive() {
                    return this._active
                }
                reset() {
                    this._active ? this._fullUpdate() : (this._deleteRows(), this._created = !1)
                }
                destroy() {
                    this._unsubscribeUpdates(), this._unsubscribeView()
                }
                getDataExporter() {
                    return {
                        name: this._name,
                        exportData: this._exportData
                    }
                }
                setHeight(e) {
                    this._view.setHeight(e)
                }
                highlightRowById(e) {
                    this._view.highlightRowById(e)
                }
                setRowInactiveById(e, t) {
                    this._view.setRowInactiveById(e, t)
                }
                setRowInactiveByFilter(e) {
                    this._view.setRowInactiveByFilter(e)
                }
                addFormatter(e) {
                    this._view.addFormatter(e)
                }
                addFormatters(e) {
                    for (const t of e) this.addFormatter(t)
                }
                isRowInViewport(e) {
                    return this._view.isRowInViewport(e)
                }
                setColumnAvailable(e, t) {
                    this._view.setColumnAvailable(e, t)
                }
                setRowLinkedByFilter(e) {
                    this._view.setRowLinkedByFilter(e)
                }
                setRowLinkedById(e, t) {
                    this._view.setRowLinkedById(e, t)
                }
                rowIdAtEvent(e) {
                    return this._view.rowIdAtEvent(e)
                }
                rowAtEvent(e) {
                    const t = this._view.rowIdAtEvent(e);
                    if (void 0 !== t) return this.rowById(t)
                }
                rowById(e) {
                    return this._model.data().get(e)
                }
                _update(e) {
                    return !!this._created && (this._model.addRow(e), !0)
                }
                _deleteRow(e) {
                    this._created && this._model.deleteRow(e)
                }
                _deleteRows() {
                    this._model.deleteRows(), this._created = !1
                }
                _fullUpdate() {
                    if (this._deleteRows(), this._noMoreEntries = !1, !this._active) return Promise.resolve();
                    this._fullUpdateCancel && this._fullUpdateCancel();
                    const e = (0, W.makeCancelable)(this._source());
                    return this._fullUpdateCancel = e.cancel, e.promise.then(e => {
                        this._fullUpdateCancel = null, this._model.addRows(e), this._created = !0, this._onCreated()
                    }).catch(e => {
                        if (!(0, W.isCancelled)(e)) throw e
                    })
                }
                _onCreated() {}
                _loadMoreIfBottomVisible(e) {
                    if (this._isLoadingMore || !e || this._noMoreEntries) return;
                    const t = this._model.rows().length - 1;
                    if (-1 === t) return;
                    const s = this._model.rows()[t][this._idProperty];
                    this._isLoadingMore = !0, this._source(s).then(e => {
                        0 !== e.length ? (this._model.addRows(e), this._isLoadingMore = !1) : this._noMoreEntries = !0
                    }).catch(() => {
                        this._isLoadingMore = !1
                    })
                }
                _subscribeView() {
                    this._view.onSizeChange.subscribe(this, this._sizeChangeHandler), this._view.onTableVisibilityChange.subscribe(this, this._viewVisibilityHandler), this._view.onSortingChange.subscribe(this, this._sortingChangeHandler), this._supportPagination && this._view.onBottomVisibilityChange.subscribe(this, this._loadMoreIfBottomVisible)
                }
                _unsubscribeView() {
                    this._view.onSizeChange.unsubscribe(this, this._sizeChangeHandler), this._view.onTableVisibilityChange.unsubscribe(this, this._viewVisibilityHandler), this._view.onSortingChange.unsubscribe(this, this._sortingChangeHandler), this._view.onBottomVisibilityChange.unsubscribe(this, this._loadMoreIfBottomVisible)
                }
                _updateModelSortingState({
                    column: e,
                    mode: t
                }) {
                    this._model.setSortingState({
                        column: e,
                        mode: 0 !== this._view.size() || this._supportPagination ? t : null
                    })
                }
                _subscribeUpdates() {
                    if (this._fullUpdateDelegate) throw new Error("should unsubscribe first");
                    this._fullUpdateDelegate = this._subscriptions.fullUpdateDelegate, this._fullUpdateDelegate.subscribe(this, this._fullUpdate), this._partialUpdateDelegate = this._subscriptions.rowUpdateDelegate, this._partialUpdateDelegate.subscribe(this, this._update), this._subscriptions.rowDeleteDelegate && (this._deleteUpdateDelegate = this._subscriptions.rowDeleteDelegate, this._deleteUpdateDelegate.subscribe(this, this._deleteRow))
                }
                _unsubscribeUpdates() {
                    this._fullUpdateDelegate && (this._fullUpdateDelegate.unsubscribe(this, this._fullUpdate), delete this._fullUpdateDelegate), this._partialUpdateDelegate && (this._partialUpdateDelegate.unsubscribe(this, this._update), delete this._partialUpdateDelegate), this._deleteUpdateDelegate && (this._deleteUpdateDelegate.unsubscribe(this, this._deleteRow), delete this._deleteUpdateDelegate)
                }
            }
            var G = s(4834);
            class z extends class {
                constructor(e, t) {
                    this._active = !1, this._content = e, this._id = t.id, this._name = t.name, this._header = function(e) {
                        if (!e.headerCounter) {
                            const t = document.createElement("span");
                            return t.textContent = e.name, t
                        }
                        const t = document.createElement("div");
                        t.className = G.counter;
                        const s = document.createElement("div");
                        s.className = G.text, s.textContent = e.name;
                        const i = document.createElement("div");
                        return i.className = G.count + " js-header-count", i.textContent = "0", t.appendChild(s), t.appendChild(i), t
                    }(t), this._countElement = this._header.querySelector(".js-header-count")
                }
                setActive(e) {
                    this._active !== e && (this._active = e, this._onActiveChanged(e))
                }
                isActive() {
                    return this._active
                }
                reset() {}
                destroy() {}
                header() {
                    return this._header
                }
                content() {
                    return this._content
                }
                name() {
                    return this._name
                }
                id() {
                    return this._id || this._name
                }
                contextItems(e) {
                    return []
                }
                topline() {
                    return null
                }
                _setCount(e) {
                    null !== this._countElement && (this._countElement.innerHTML = String(e))
                }
                _onActiveChanged(e) {}
            } {
                constructor(e, t, s) {
                    super(e, t), this._tableControllers = s
                }
                reset() {
                    this._tableControllers.forEach(e => e.reset()), super.reset()
                }
                destroy() {
                    this._tableControllers.forEach(e => e.destroy()), super.destroy()
                }
                setHeight(e) {
                    this._tableControllers.forEach(t => t.setHeight(e))
                }
                getExporters() {
                    const e = this._tableControllers.map(e => e.getDataExporter());
                    return {
                        title: this.name(),
                        exporters: e
                    }
                }
                contextRow(e) {}
                _onActiveChanged(e) {
                    this._tableControllers.forEach(t => t.setActive(e))
                }
            }
            var q = s(93751),
                Q = s(72249),
                $ = s(83887),
                J = s(89963),
                K = s(52647);
            var X = s(2683),
                Z = s(42419);
            var Y = s(50317),
                ee = (s(99357), s(47152), s(97754)),
                te = s.n(ee);
            s(88913);
            s(72476);
            var se = s(30052);
            s(39391), s(21162);
            new Map;
            var ie = s(85769);
            new Map;

            function re(e) {
                const {
                    brokerSymbol: t
                } = e;
                return o.createElement("div", {
                    className: ie.title
                }, t)
            }

            function oe(e) {
                return o.createElement(se.MatchMedia, {
                    rule: H.TradingLayoutBreakpoint.Mobile
                }, t => t ? o.createElement("span", null, e.brokerSymbol) : o.createElement(re, { ...e
                }))
            }
            var ne = s(42206);

            function ae(e) {
                return 1 === e ? ne.blue : ne.red
            }

            function le(e) {
                const {
                    side: t
                } = e;
                return o.createElement("span", {
                    className: ae(t)
                }, (0, Y.sideToText)(t))
            }

            function ce(e) {
                const {
                    side: t
                } = e;
                return o.createElement("span", {
                    className: ae(t)
                }, (0, Y.positionSideToText)(t))
            }
            var de = s(59260);

            function he(e) {
                const {
                    value: t,
                    noWrap: s
                } = e;
                return o.createElement("span", {
                    className: te()(de.text, s && de.noWrap)
                }, t)
            }

            function ue(e) {
                const {
                    priceFormatter: t,
                    price: s,
                    prevPrice: i
                } = e, r = (0, Q.splitThousands)(t.format(s), " ");
                if (void 0 === i) return {
                    same: r
                };
                const o = (0, Q.splitThousands)(t.format(i), " "),
                    n = r.split("").findIndex((e, t) => e !== o[t]);
                if (-1 === n) return {
                    same: r
                };
                return {
                    same: r.substring(0, n),
                    differs: r.substring(n)
                }
            }

            function pe(e) {
                const {
                    price: t,
                    prevPrice: s,
                    lastCharSup: i
                } = e, {
                    same: r,
                    differs: n
                } = ue(e);
                return void 0 === n || void 0 === s ? function(e, t) {
                    return o.createElement("span", null, t ? _e(e) : (0, w.forceLTRStr)(e))
                }(r, i) : o.createElement("span", null, r, o.createElement("span", {
                    className: t > s ? ne.green : ne.red
                }, i ? _e(n) : n))
            }

            function _e(e) {
                const t = /^([^]*)(\S)(\s*)$/.exec(e);
                return "0" === e || null === t ? o.createElement(o.Fragment, null, (0, w.forceLTRStr)(e)) : o.createElement(o.Fragment, null, t[1], o.createElement("sup", null, t[2]), void 0 !== t[3] && "" !== t[3] && o.createElement("sup", null, t[3]))
            }
            const me = {
                3: ne.gray,
                6: ne.blue,
                5: ne.red,
                2: ne.green,
                1: ne.orange,
                4: void 0
            };

            function ge(e) {
                const {
                    status: t
                } = e;
                return o.createElement("span", {
                    className: me[t],
                    style: {
                        textTransform: "capitalize"
                    }
                }, (0, O.orderStatusToText)(t))
            }

            function be(e) {
                const {
                    profit: t,
                    currency: s
                } = e;
                if (!(0, X.isNumber)(t)) return "";
                const i = (0, q.fixComputationError)(t),
                    r = i > 0 ? "+" : "",
                    o = void 0 !== s ? " " + s : "";
                return (0, w.forceLTRStr)(r + (0, Q.splitThousands)((i || 0).toFixed(2), " ") + o)
            }

            function ve(e) {
                const t = be(e);
                return "" === t ? o.createElement("span", null) : o.createElement("span", {
                    className: te()(e.profit < 0 && ne.red, e.profit > 0 && ne.green)
                }, t)
            }
            const fe = new $.DateTimeFormatter,
                we = new class {
                    constructor() {
                        this._dateFormatter = new K.DateFormatter, this._timeFormatter = new J.TimeFormatter
                    }
                    format(e) {
                        const t = new Date(e.dateOrDateTime);
                        let s = this._dateFormatter.format(t);
                        return e.hasTime && (s += " " + this._timeFormatter.format(t)), s
                    }
                    formatLocal(e) {
                        const t = new Date(e.dateOrDateTime);
                        let s = this._dateFormatter.formatLocal(t);
                        return e.hasTime && (s += " " + this._timeFormatter.formatLocal(t)), s
                    }
                },
                Ce = new Z.PercentageFormatter;

            function ye({
                value: e
            }) {
                return String(null != e ? e : "")
            }
            const Se = {
                name: "default",
                formatText: ye
            };

            function Te(e) {
                return (0, O.isDefined)(e.value) ? function(e) {
                    const {
                        same: t,
                        differs: s
                    } = ue(e);
                    return (0, w.forceLTRStr)(`${t}${s||""}`)
                }({ ...e,
                    price: e.value
                }) : ""
            }
            const xe = [{
                name: "symbol",
                formatElement: ({
                    value: e,
                    row: t
                }) => o.createElement(oe, {
                    brokerSymbol: e,
                    symbol: t.symbol
                }),
                formatText: ye
            }, {
                name: "side",
                formatElement: ({
                    value: e
                }) => o.createElement(le, {
                    side: e
                }),
                formatText: ({
                    value: e
                }) => (0, Y.sideToText)(e)
            }, {
                name: "positionSide",
                formatElement: ({
                    value: e
                }) => o.createElement(ce, {
                    side: e
                }),
                formatText: ({
                    value: e
                }) => (0, Y.positionSideToText)(e)
            }, {
                name: "text",
                formatElement: ({
                    value: e
                }) => o.createElement(he, {
                    value: e
                }),
                formatText: ye
            }, {
                name: "textNoWrap",
                formatElement: ({
                    value: e
                }) => o.createElement(he, {
                    value: e,
                    noWrap: !0
                }),
                formatText: ye
            }, {
                name: "type",
                formatText: ({
                    value: e
                }) => (0, Y.orderTypeToText)(e)
            }, {
                name: "formatPrice",
                formatElement: ({
                    value: e,
                    priceFormatter: t,
                    prevValue: s
                }) => (0, O.isDefined)(e) ? o.createElement(pe, {
                    priceFormatter: t,
                    price: e,
                    prevPrice: s
                }) : void 0,
                formatText: Te
            }, {
                name: "formatPriceForexSup",
                formatElement: ({
                    value: e,
                    priceFormatter: t,
                    prevValue: s
                }) => (0, O.isDefined)(e) ? o.createElement(pe, {
                    priceFormatter: t,
                    price: e,
                    prevPrice: s,
                    lastCharSup: t.hasForexAdditionalPrecision()
                }) : void 0,
                formatText: Te
            }, {
                name: "status",
                formatElement: ({
                    value: e
                }) => (0, O.isDefined)(e) ? o.createElement(ge, {
                    status: e
                }) : void 0,
                formatText: ({
                    value: e
                }) => {
                    return (0, O.isDefined)(e) ? (t = (0, Y.orderStatusToText)(e)).charAt(0).toUpperCase() + t.substring(1) : "";
                    var t
                }
            }, {
                name: "date",
                formatText: ({
                    value: e
                }) => (0, O.isDefined)(e) && Ee(e) ? fe.format(new Date(e)) : ""
            }, {
                name: "localDate",
                formatText: ({
                    value: e
                }) => (0, O.isDefined)(e) && Ee(e) ? fe.formatLocal(new Date(e)) : ""
            }, {
                name: "dateOrDateTime",
                formatText: ({
                    value: e
                }) => (0, O.isDefined)(e) && Ee(e.dateOrDateTime) ? we.format(e) : ""
            }, {
                name: "localDateOrDateTime",
                formatText: ({
                    value: e
                }) => (0, O.isDefined)(e) && Ee(e.dateOrDateTime) ? we.formatLocal(e) : ""
            }, {
                name: "fixed",
                formatText: ({
                    value: e
                }) => !(0, O.isDefined)(e) || isNaN(e) ? "" : (0, w.forceLTRStr)(Math.abs(e || 0) < .001 ? "0.00" : (0, Q.splitThousands)((e || 0).toFixed(2), " "))
            }, {
                name: "variablePrecision",
                formatText: ({
                    value: e
                }) => !(0, O.isDefined)(e) || isNaN(e) ? "" : (0, w.forceLTRStr)(String((0, q.fixComputationError)(e)))
            }, {
                name: "pips",
                formatText: ({
                    value: e
                }) => (0, X.isNumber)(e) ? (0, w.forceLTRStr)(Math.abs(e) < .01 ? "0.0" : (0, Q.splitThousands)(e.toFixed(1), " ")) : ""
            }, {
                name: "integerSeparated",
                formatText: ({
                    value: e
                }) => (0, X.isNumber)(e) ? (0, w.forceLTRStr)((0, Q.splitThousands)(e.toFixed(0), " ")) : ""
            }, {
                name: "formatQuantity",
                formatText: ({
                    value: e
                }) => (0, X.isNumber)(e) ? (0, w.forceLTRStr)((0, Q.splitThousands)(e, " ")) : ""
            }, {
                name: "profit",
                formatElement: ({
                    value: e
                }) => (0, O.isDefined)(e) ? o.createElement(ve, {
                    profit: e
                }) : void 0,
                formatText: ({
                    value: e
                }) => (0, O.isDefined)(e) ? be({
                    profit: e
                }) : ""
            }, {
                name: "profitInInstrumentCurrency",
                formatElement: ({
                    value: e,
                    row: {
                        currency: t
                    }
                }) => (0, O.isDefined)(e) ? o.createElement(ve, {
                    profit: e,
                    currency: t
                }) : void 0,
                formatText: ({
                    value: e,
                    row: {
                        currency: t
                    }
                }) => (0, O.isDefined)(e) ? be({
                    profit: e,
                    currency: t
                }) : ""
            }, {
                name: "percentage",
                formatText: ({
                    value: e
                }) => (0, X.isNumber)(e) ? (0, w.forceLTRStr)(Ce.format(e)) : ""
            }, {
                name: "marginPercent",
                formatText: ({
                    value: e
                }) => (0,
                    O.isDefined)(e) ? isFinite(e) ? e < .01 ? e + "%" : Ce.format(e) : "> 200%" : ""
            }];

            function Ee(e) {
                return "number" == typeof e ? e > 0 : "" !== e
            }
            var De = s(12356);

            function Fe(e = {}) {
                const {
                    withScroll: t = !1,
                    fitContent: s = !1
                } = e, i = document.createElement("div");
                return i.classList.add(De.tableContainer), i.classList.toggle(De.withScroll, t), i.classList.toggle(De.noScroll, !t), i.classList.toggle(De.fitContent, s), i
            }
            var Me = s(43370);

            function Pe(e, t) {
                return void 0 === e && void 0 !== t ? 1 : void 0 !== e && void 0 === t ? -1 : void 0 === e || void 0 === t ? 0 : e < t ? 1 : e > t ? -1 : 0
            }
            class Ae {
                constructor(e) {
                    this.onRowsChanged = new(g()), this.onRowChanged = new(g()), this._rowsData = new Map, this._priceFormatters = new Map, this._rows = [], this._isActive = !1, this._sortingPostponed = !1, this._sortingMode = null;
                    const {
                        columns: t,
                        options: s,
                        priceFormatterGetter: i,
                        reverse: r = !0
                    } = e;
                    this._idProperty = s.idProperty, this._reverse = r, this._group = s.group, this._priceFormatterGetter = i, this._sortAndGroupRowsThrottled = (0, Me.default)(() => {
                        this._sortAndGroupRows(), this._update()
                    }, 1e3), this._columns = new Map(t.map(e => [e.property, e]))
                }
                setActive(e) {
                    this._isActive = e, this._onTableStateChanged(e)
                }
                addRow(e) {
                    const t = e[this._idProperty];
                    this._rowsData.has(t) ? this._updateRow(t, e) : (this._addRowData(e), this._sortAndGroupRowsThrottled.cancel(), this._sortAndGroupRows(), this._update())
                }
                addRows(e) {
                    for (const t of e) {
                        const e = t[this._idProperty];
                        this._rowsData.has(e) ? this._updateRowData(e, t) : this._addRowData(t)
                    }
                    this._sortAndGroupRows(), this._update()
                }
                rows() {
                    return this._rows
                }
                data() {
                    return this._rowsData
                }
                deleteRow(e) {
                    const t = this._rowsData.get(e);
                    void 0 !== t && (this._rowsData.delete(e), this._rows.splice(this._rows.indexOf(t), 1), this._update())
                }
                deleteRows() {
                    this._deleteRows(), this._update()
                }
                destroy() {
                    this._sortAndGroupRowsThrottled.cancel(), this._deleteRows()
                }
                setSortingState(e) {
                    this._sortingColumn = e.column, this._sortingMode = e.mode, this._onSortingChange()
                }
                _deleteRows() {
                    this._rowsData.clear(), this._rows = []
                }
                _sortAndGroupRows() {
                    var e, t;
                    if (!this._isActive) return void(this._sortingPostponed = !0);
                    const s = void 0 !== this._sortingColumn ? this._columns.get(this._sortingColumn) : void 0,
                        i = null !== (t = null !== (e = null == s ? void 0 : s.sortProp) && void 0 !== e ? e : null == s ? void 0 : s.property) && void 0 !== t ? t : this._sortingColumn;
                    this._rows.sort((e, t) => function(e) {
                        const {
                            aRow: t,
                            bRow: s,
                            sortingMode: i,
                            sortingColumn: r,
                            groupDefiner: o
                        } = e;
                        let n = 0;
                        return void 0 !== o && (n = Pe(o(t), o(s))), 0 === n && (n = t.isTotalRow ? 1 : s.isTotalRow ? -1 : 0), null === i || 0 !== n || void 0 === r ? n : (n = Pe(t[r], s[r]), 0 === i ? -n : n)
                    }({
                        aRow: e,
                        bRow: t,
                        sortingColumn: i,
                        sortingMode: this._sortingMode,
                        groupDefiner: this._group
                    }))
                }
                _onSortingChange() {
                    this._sortAndGroupRowsThrottled.cancel(), null === this._sortingMode && this._resetRowsOrder(), this._sortAndGroupRows(), this._update()
                }
                _resetRowsOrder() {
                    this._rows = [...this._rowsData.values()], this._reverse && this._rows.reverse()
                }
                _onTableStateChanged(e) {
                    if (!e) return this._sortAndGroupRowsThrottled.cancel(), void(this._sortingPostponed = !0);
                    this._update()
                }
                _update() {
                    this._isActive && (this._sortingPostponed && (this._sortingPostponed = !1, this._sortAndGroupRows()), this.onRowsChanged.fire())
                }
                _updateRowData(e, t) {
                    var s, i;
                    const r = (0,
                            l.ensureDefined)(this._rowsData.get(e)),
                        {
                            prevValue: o,
                            priceFormatter: n,
                            ...a
                        } = r;
                    for (const e of Object.keys(r)) delete r[e];
                    Object.assign(r, t, {
                        priceFormatter: n,
                        prevValue: a
                    }), this.onRowChanged.fire(e);
                    const c = (null === (s = this._group) || void 0 === s ? void 0 : s.call(this, r)) !== (null === (i = this._group) || void 0 === i ? void 0 : i.call(this, a));
                    (void 0 !== this._sortingColumn && t[this._sortingColumn] !== a[this._sortingColumn] || c) && this._sortAndGroupRowsThrottled()
                }
                _updateRow(e, t) {
                    this._updateRowData(e, t), this._update()
                }
                _addRowData({ ...e
                }) {
                    this._rowsData.set(e[this._idProperty], e), this._reverse ? this._rows.unshift(e) : this._rows.push(e), this._resolvePriceFormatter(e[this._idProperty])
                }
                async _resolvePriceFormatter(e) {
                    if (void 0 !== this._priceFormatterGetter) try {
                        const t = this._rowsData.get(e);
                        if (void 0 === t || void 0 !== t.priceFormatter) return;
                        t.priceFormatter = null;
                        const s = this._priceFormatters.get(e);
                        if (void 0 !== s) return t.priceFormatter = s, void this._update();
                        const i = await this._priceFormatterGetter(t);
                        this._priceFormatters.set(e, i), t.priceFormatter = i, this._update()
                    } catch (e) {}
                }
            }
            var ke = s(86416),
                Oe = s(11307),
                Re = s(4889),
                Ie = s(15427),
                Ne = s(33054),
                Be = s(89e3),
                Ue = s(11126),
                Le = s(16345),
                Ve = s(1397),
                He = s(94489),
                We = s.n(He),
                je = s(97265),
                Ge = s(75803),
                ze = s(34816),
                qe = s(85673),
                Qe = s(79266),
                $e = s(53327),
                Je = s(22795),
                Ke = s(56620);
            const Xe = new(We())(null).readonly();

            function Ze(e) {
                const {
                    items: t,
                    onCheck: s,
                    overlapManagerWV: i
                } = e, n = (0, je.useWatchedValueReadonly)({
                    watchedValue: null != i ? i : Xe
                }), a = (0, o.useMemo)(() => t.filter(e => e.visible), [t]);
                return o.createElement($e.SlotContext.Provider, {
                    value: n
                }, o.createElement(ze.ToolWidgetMenu, {
                    horizontalDropDirection: qe.HorizontalDropDirection.FromRightToLeft,
                    horizontalAttachEdge: qe.HorizontalAttachEdge.Right,
                    className: Je.menuButton,
                    arrow: !1,
                    isDrawer: d.CheckMobile.any(),
                    content: o.createElement(Ge.ToolWidgetButton, {
                        className: Je.icon,
                        title: (0, r.t)("Column setup"),
                        icon: Ke
                    })
                }, t.map(e => o.createElement(Qe.PopupMenuItemToggle, {
                    key: e.id,
                    label: e.title,
                    isChecked: e.visible,
                    labelClassName: Je.label,
                    className: Je.checkBox,
                    onClick: () => {
                        return t = e.id, void s(t);
                        var t
                    },
                    isDisabled: 1 === a.length && a[0].id === e.id
                }))))
            }
            var Ye = s(91802);

            function et(e) {
                const {
                    isSticky: t,
                    ...s
                } = e;
                return o.createElement("div", {
                    className: te()(Ye.container, t && Ye.sticky)
                }, o.createElement(Ze, { ...s
                }))
            }
            var tt = s(53408),
                st = s(34985),
                it = s(39226),
                rt = s(16550),
                ot = s.n(rt),
                nt = s(85758);

            function at(e) {
                const {
                    column: t,
                    dispatch: s,
                    onColumnsReordered: i,
                    columnsReorderingEnabled: r
                } = e, [{
                    isDragging: n
                }, a, l] = (0, st.useDrag)(() => ({
                    type: "HeadCell",
                    item: {
                        id: t.key
                    },
                    canDrag: () => r,
                    collect: e => ({
                        isDragging: e.isDragging()
                    })
                })), [, c] = (0, it.useDrop)(() => ({
                    accept: "HeadCell",
                    hover: (e, i) => {
                        var r;
                        if (e.id === t.key) return;
                        const o = null === (r = d.current) || void 0 === r ? void 0 : r.getBoundingClientRect(),
                            n = i.getClientOffset(),
                            a = i.getDifferenceFromInitialOffset();
                        void 0 !== o && null !== n && null !== a && function(e, t, s, i) {
                            const r = t - s,
                                o = .4 * (i - s);
                            return e > 0 ? r > o : r < o
                        }(a.x, n.x, o.left, o.right) && s({
                            type: Ue.ActionType.ReorderColumns,
                            columnKey: e.id,
                            targetColumnKey: t.key
                        })
                    },
                    drop: () => {
                        i()
                    }
                })), d = (0, o.useRef)(null);
                return (0, o.useEffect)(() => {
                    "" !== t.title && a(c(d)), l((0,
                        tt.getEmptyImage)(), {
                        captureDraggingState: !0
                    })
                }, [t]), o.createElement("div", {
                    ref: d,
                    className: nt.wrapper,
                    style: {
                        opacity: n ? .4 : 1
                    }
                }, o.createElement(ot(), { ...e
                }))
            }
            var lt = s(60511),
                ct = s.n(lt);

            function dt(e) {
                const {
                    visibilityHandler: t,
                    ...s
                } = e;
                return (0, o.useLayoutEffect)(() => (t(s.rowKeyValue, !0), () => t(s.rowKeyValue, !1)), []), o.createElement(ct(), { ...s
                })
            }
            var ht = s(66164);
            const ut = {
                mobileRowPadding: pt(ht["mobile-row-padding"]),
                mobileRowBorderSize: pt(ht["mobile-row-border-size"]),
                mobileRowMargin: pt(ht["mobile-row-margin"]),
                contentFontSize: ht["content-font-size"],
                maxCellWidth: 200,
                minCellWidth: 80,
                cellLateralPadding: pt(ht["cell-lateral-padding"])
            };

            function pt(e) {
                return Number(e.replace("px", ""))
            }
            var _t = s(49818);

            function mt(e) {
                const {
                    children: t,
                    onWidthChange: s,
                    widthMeasurer: i,
                    maxWidth: r
                } = e, [n, a] = (0, o.useState)(), [l, c] = (0, o.useState)(!1), d = (0, o.useRef)(null);
                return (0, o.useEffect)(() => {
                    if (null === d.current) return;
                    const e = d.current.innerText;
                    if (e === n) return;
                    a(e);
                    const t = i(e);
                    s(t), c(t > r)
                }, [t]), o.createElement("span", {
                    ref: d,
                    className: te()(_t.wrapper, l && "apply-common-tooltip"),
                    "data-tooltip": n
                }, t)
            }
            var gt = s(50357);
            const bt = {
                    0: Ue.SortDirection.Ascend,
                    1: Ue.SortDirection.Descend
                },
                vt = {
                    [V.Danger]: gt.dangerRow,
                    [V.Success]: gt.successRow
                };
            class ft {
                constructor(e = 0) {
                    this._mode = e
                }
                value() {
                    return this._mode
                }
                next() {
                    switch (this._mode) {
                        case 0:
                            this._mode = 1;
                            break;
                        case 1:
                            this._mode = null;
                            break;
                        case null:
                            this._mode = 0
                    }
                    return this._mode
                }
                reset() {
                    this._mode = 0
                }
            }

            function wt({
                value: e
            }) {
                let t = "";
                return void 0 !== e && (t = String(e).replace(/&nbsp;/g, " ")), t
            }
            const Ct = new Ve.PriceFormatter,
                yt = (0, l.ensureNotNull)(document.createElement("canvas").getContext("2d"));
            yt.font = `${ut.contentFontSize} ${getComputedStyle(document.body).fontFamily}`;

            function St(e) {
                return Math.ceil(yt.measureText(e).width) + 10
            }
            Ie.default.fieldDelimiter = "";
            class Tt {
                constructor(e) {
                    var t, s;
                    this.onTableVisibilityChange = new(g()), this.onBottomVisibilityChange = new(g()), this.onSizeChange = new(g()), this.onSortingChange = new(g()), this._isVisible = !1, this._tableWrapperKey = (0, Le.randomHashN)(5), this._rowHeightCache = new Map, this._rowsElements = new Map, this._rowsDisplayOptions = new Map, this._columnsWidth = new Map, this._columnWidthChangeHandlers = new Map, this._highlightTimeoutIds = new Map, this._formatters = new Map, this._visibleColumnsWithFormatters = new Map, this._hiddenFilterColumns = new Set, this._visibleRows = new Set, this._invalidateRowCache = e => {
                            this._rowHeightCache.delete(e)
                        }, this._makeHeadCellAttributes = ({
                            column: {
                                key: e,
                                title: t
                            }
                        }) => {
                            const s = "settings" === e,
                                i = {
                                    className: te()(gt.headCell, s && !this._isMobile && gt.fixedCell)
                                };
                            return this._isMobile || (i.width = this._fixedColumns ? "50%" : this._columnsWidth.get(e), s && (i.width = 68)), i
                        }, this._setColumnWidth = (e, t) => {
                            const s = t + ut.cellLateralPadding,
                                i = this._columnsWidth.get(e);
                            void 0 !== i && s <= i || (this._columnsWidth.set(e, s), this._render())
                        }, this._updateTableProps = e => {
                            if (e.type === Ue.ActionType.UpdateSortDirection) {
                                const t = this._columnsMetainfo.get(e.columnKey);
                                if (void 0 === t || t.notSortable) return;
                                this._handleSortingUpdate(e.columnKey)
                            }
                            this._tableProps = (0, Be.kaReducer)(this._tableProps, e), this._render()
                        },
                        this._handleEmptyRows = () => {
                            0 === this._model.rows().length && this._resetTableVirtualScrollPosition()
                        }, this._calculateRowHeight = e => {
                            var t, s;
                            const i = null === (s = null === (t = this._virtualization) || void 0 === t ? void 0 : t.rowHeightParams) || void 0 === s ? void 0 : s[this._isMobile ? "mobile" : "desktop"];
                            if (void 0 === i) return 48;
                            if ("number" == typeof i) return i;
                            const r = e[this._idProperty],
                                o = this._isMobile && this._isFirstRow(r) ? ut.mobileRowMargin : 0,
                                n = this._rowHeightCache.get(r);
                            if (void 0 !== n) return n + o;
                            const a = i(e, this._visibleColumnsWithFormatters);
                            return this._rowHeightCache.set(r, a), a + o
                        }, this._makeHeadCellContent = e => {
                            const {
                                column: t
                            } = e;
                            if ("settings" === t.key) {
                                const e = this._getAvailableColumnsFilterItems();
                                if (0 !== e.length) return o.createElement(et, { ...this._columnsFilterProps,
                                    items: e
                                })
                            }
                            const s = this._columnsMetainfo.get(t.key);
                            return void 0 !== (null == s ? void 0 : s.help) ? o.createElement("span", {
                                className: "apply-common-tooltip",
                                title: s.help
                            }, t.title) : t.title
                        }, this._makeTextContent = e => {
                            var t, s, i, r;
                            const {
                                value: o,
                                rowData: n,
                                field: a
                            } = e, l = this._columnsMetainfo.get(a);
                            if (void 0 === l || !1 === l.showZeroValues && 0 === o) return "";
                            const c = void 0 !== l.formatter && null !== (s = null === (t = this._formatters.get(l.formatter)) || void 0 === t ? void 0 : t.formatText) && void 0 !== s ? s : wt,
                                d = null === (i = n.prevValue) || void 0 === i ? void 0 : i[a];
                            return c({
                                value: o,
                                prevValue: l.highlightDiff ? d : void 0,
                                priceFormatter: null !== (r = n.priceFormatter) && void 0 !== r ? r : Ct,
                                row: n
                            })
                        }, this._makeCellContent = e => {
                            var t, s, i, r;
                            const {
                                value: n,
                                rowData: a,
                                field: l
                            } = e, c = this._columnsMetainfo.get(l);
                            if (void 0 === c) return;
                            if (!1 === c.showZeroValues && 0 === n) return o.createElement(o.Fragment, null);
                            let d = wt;
                            if (void 0 !== c.formatter) {
                                const e = this._formatters.get(c.formatter);
                                d = null !== (s = null !== (t = null == e ? void 0 : e.formatElement) && void 0 !== t ? t : null == e ? void 0 : e.formatText) && void 0 !== s ? s : d
                            }
                            const h = null === (i = a.prevValue) || void 0 === i ? void 0 : i[l],
                                u = d({
                                    value: n,
                                    prevValue: c.highlightDiff ? h : void 0,
                                    priceFormatter: null !== (r = a.priceFormatter) && void 0 !== r ? r : Ct,
                                    row: a
                                });
                            if (this._isMobile || this._fixedColumns) return o.createElement(o.Fragment, null, u);
                            let p = this._columnWidthChangeHandlers.get(l);
                            return void 0 === p && (p = e => this._setColumnWidth(l, e), this._columnWidthChangeHandlers.set(l, p)), o.createElement(mt, {
                                onWidthChange: p,
                                widthMeasurer: St,
                                maxWidth: ut.maxCellWidth
                            }, u)
                        }, this._makeRowContent = e => o.createElement(dt, { ...e,
                            visibilityHandler: this._handleRowVisibilityChange
                        }), this._handleRowVisibilityChange = (e, t) => {
                            t ? this._visibleRows.add(e) : this._visibleRows.delete(e)
                        }, this._makeRowAttributes = ({
                            rowKeyValue: e,
                            rowData: t
                        }) => {
                            var s;
                            const i = this._rowsDisplayOptions.get(e),
                                r = null === (s = this._rowBadgeTypeInferrer) || void 0 === s ? void 0 : s.call(this, t);
                            return {
                                className: te()(gt.row, (null == i ? void 0 : i.isInactive) && gt.inactiveRow, (null == i ? void 0 : i.isLinked) && gt.linkedRow, void 0 !== r && vt[r], this._isFirstRow(e) && gt.withMargin, this._isLastRow(e) && gt.lastRow),
                                "data-row-id": e,
                                ref: t => this._setRowElement(e, t),
                                onClick: (e, t) => {
                                    var s, i;
                                    null === (i = null === (s = this._rowEventsHandlers) || void 0 === s ? void 0 : s.onClick) || void 0 === i || i.call(s, t.childProps.rowData, this._isMobile)
                                },
                                onMouseEnter: (e, t) => {
                                    var s, i;
                                    null === (i = null === (s = this._rowEventsHandlers) || void 0 === s ? void 0 : s.onMouseEnter) || void 0 === i || i.call(s, t.childProps.rowData, this._isMobile)
                                },
                                onMouseLeave: (e, t) => {
                                    var s, i;
                                    null === (i = null === (s = this._rowEventsHandlers) || void 0 === s ? void 0 : s.onMouseLeave) || void 0 === i || i.call(s, t.childProps.rowData, this._isMobile)
                                }
                            }
                        }, this._setRowElement = (e, t) => {
                            this._rowsElements.set(e, t)
                        }, this._makeHeadCellContentAttributes = ({
                            column: e
                        }) => {
                            const {
                                key: t
                            } = e, s = this._columnsMetainfo.get(t);
                            return {
                                className: te()(gt.headCellContent, ("right" === (null == s ? void 0 : s.alignment) || "settings" === t) && gt.rightAlignedHeadCell)
                            }
                        }, this._makeCellAttributes = ({
                            column: e,
                            value: t
                        }) => {
                            const {
                                title: s,
                                key: i
                            } = e, r = this._columnsMetainfo.get(i), o = !1 === (null == r ? void 0 : r.showOnMobile) || !1 === (null == r ? void 0 : r.showZeroValues) && 0 === t || null == t;
                            return {
                                className: te()(gt.cell, ("right" === (null == r ? void 0 : r.alignment) || "settings" === i) && gt.rightAlignedCell, !1 === (null == r ? void 0 : r.showLabelOnMobile) && !1, o && gt.hideCellOnMobile, "settings" === i && !this._isMobile && gt.fixedCell),
                                "data-label": s
                            }
                        }, this._makeCellContentAttributes = ({
                            column: e,
                            rowData: t
                        }) => {
                            var s;
                            const {
                                key: i
                            } = e, r = this._columnsMetainfo.get(i), o = void 0 !== (null == r ? void 0 : r.tooltipProperty) ? null === (s = t[r.tooltipProperty]) || void 0 === s ? void 0 : s[r.property] : void 0;
                            return {
                                className: te()(gt.cellContent, void 0 !== o && "apply-common-tooltip common-tooltip-html", !1 !== (null == r ? void 0 : r.isCapitalize) && gt.capitalize),
                                title: o
                            }
                        }, this._makeTableWrapperAttributes = () => {
                            var e;
                            return {
                                className: te()(gt.tableWrapper, (null === (e = this._virtualization) || void 0 === e ? void 0 : e.enabled) && gt.tableWrapperEmpty),
                                onScroll: this._onTableScroll,
                                key: this._tableWrapperKey
                            }
                        }, this._onTableScroll = (e, {
                            baseFunc: t
                        }) => {
                            this._update.cancel(), t(e), this._checkBottomIsVisible(e.currentTarget)
                        }, this._resizeHandler = ({
                            matches: e
                        }) => {
                            this._isMobile = e, this._visibleColumnsWithFormatters.clear(), this._columnsVisibilityInfo = this._makeColumnsVisibilityInfo(), this._columnsFilterProps = this._makeColumnsFilterProps(), this._tableProps.columns = this._makeColumns(), this._rowHeightCache.clear(), this.onSizeChange.fire()
                        }, this._saveColumnsOrder = () => {
                            var e;
                            const t = this._tableProps.columns.map(e => e.key);
                            null === (e = this._getSettingsStorage()) || void 0 === e || e.setTableColumnsOrder(this._id, t)
                        };
                    const {
                        id: i,
                        model: r,
                        className: n,
                        container: a,
                        columns: l,
                        virtualization: c,
                        stickyMobileColumnsFilter: d,
                        idProperty: h,
                        overlapManager: u,
                        initialSorting: p,
                        rowBadgeTypeInferrer: _,
                        fixedColumns: m,
                        getSettingsStorage: b,
                        rowEventsHandlers: v
                    } = e;
                    this._id = i, this._model = r, this._fixedColumns = m, this._sortingColumnKey = this._id + ".sort.column", this._sortingModeKey = this._id + ".sort.mode", this._container = a, this._idProperty = h, this._virtualization = c, this._overlapManager = u, this._isStickyMobileColumnsFilter = d, this._columnsMetainfo = new Map(l.map(e => [e.property, e])), this._rowBadgeTypeInferrer = _, this._getSettingsStorage = b, this._rowEventsHandlers = v, this._checkBottomIsVisible = (0, Re.default)(this._checkBottomIsVisible, 100), this._update = (0, Me.default)(this._render, 1e3);
                    const f = null !== (t = this._getSavedSortingParameters()) && void 0 !== t ? t : p;
                    this._sortingColumn = null == f ? void 0 : f.columnId;
                    const w = !1 === (null == f ? void 0 : f.asc) ? 1 : 0;
                    let C;
                    this._sortingModeSwitcher = new ft(void 0 === f ? null : w), (null == c ? void 0 : c.enabled) && (C = {
                        itemHeight: this._calculateRowHeight
                    }), this._mobileMediaQuery = window.matchMedia(H.TradingLayoutBreakpoint.Mobile), this._isMobile = this._mobileMediaQuery.matches, (0, Ne.mediaQueryAddEventListener)(this._mobileMediaQuery, this._resizeHandler);
                    const y = "IntersectionObserver" in window;
                    y || (this._isVisible = !0), this._containerVisibilityObserver = y ? new IntersectionObserver(e => {
                        e.forEach(({
                            intersectionRatio: e
                        }) => {
                            this._isVisible = 0 !== e, this._isVisible ? this._render() : this._resetTableVirtualScrollPosition(), this.onTableVisibilityChange.fire(this._isVisible)
                        })
                    }) : null, null === (s = this._containerVisibilityObserver) || void 0 === s || s.observe(this._container), this._columnsVisibilityInfo = this._makeColumnsVisibilityInfo(), this._columnsFilterProps = this._makeColumnsFilterProps(), this._tableProps = {
                        columns: this._makeColumns(),
                        dispatch: this._updateTableProps,
                        rowKeyField: this._idProperty,
                        virtualScrolling: C,
                        sortingMode: Ue.SortingMode.SingleTripleStateRemote,
                        childComponents: {
                            table: {
                                elementAttributes: () => ({
                                    className: te()(gt.table, n, void 0 !== C && gt.withVirtualization),
                                    "data-selector": "table",
                                    style: {
                                        borderCollapse: "separate"
                                    }
                                })
                            },
                            tableBody: {
                                elementAttributes: () => ({
                                    className: gt.tableBody
                                })
                            },
                            tableHead: {
                                elementAttributes: () => ({
                                    className: gt.tableHead
                                })
                            },
                            headRow: {
                                elementAttributes: () => ({
                                    className: gt.headRow
                                })
                            },
                            headCell: {
                                elementAttributes: this._makeHeadCellAttributes,
                                content: e => o.createElement(at, { ...e,
                                    dispatch: (0, Re.default)(this._updateTableProps, 15),
                                    onColumnsReordered: this._saveColumnsOrder,
                                    columnsReorderingEnabled: !this._isMobile
                                })
                            },
                            cell: {
                                elementAttributes: this._makeCellAttributes
                            },
                            tableWrapper: {
                                elementAttributes: this._makeTableWrapperAttributes
                            },
                            dataRow: {
                                content: this._makeRowContent,
                                elementAttributes: this._makeRowAttributes
                            },
                            cellText: {
                                content: this._makeCellContent,
                                elementAttributes: this._makeCellContentAttributes
                            },
                            headCellContent: {
                                elementAttributes: this._makeHeadCellContentAttributes,
                                content: this._makeHeadCellContent
                            }
                        }
                    }, this._render(), this._subscribeModel()
                }
                rowIdAtEvent(e) {
                    return function(e) {
                        if (void 0 !== e.dataset.rowId) return e.dataset.rowId;
                        let t = e.parentElement;
                        for (; null !== t;) {
                            if (void 0 !== t.dataset.rowId) return t.dataset.rowId;
                            t = t.parentElement
                        }
                    }(e.target)
                }
                isRowInViewport(e) {
                    return this._visibleRows.has(e)
                }
                sortingColumn() {
                    return this._sortingColumn
                }
                sortingMode() {
                    return this._sortingModeSwitcher.value()
                }
                size() {
                    return this._isMobile ? 0 : 1
                }
                highlightRowById(e) {
                    const t = this._rowElementById(e);
                    void 0 !== t && (clearTimeout(this._highlightTimeoutIds.get(e)), t.classList.remove(gt.highlightedRow), t.classList.add(gt.highlightedRow), this._highlightTimeoutIds.set(e, setTimeout(() => {
                        t.classList.remove(gt.highlightedRow)
                    }, 700)))
                }
                addFormatter(e) {
                    this._formatters.set(e.name, e)
                }
                setColumnAvailable(e, t) {
                    if (this._setColumnAvailableInFilter(e, t), t) {
                        const t = this._isMobile ? ".invisibleMobileColumns" : ".invisibleColumns";
                        if (f.getJSON(`${this._id}${t}`, []).includes(e)) return
                    }
                    this._setColumnVisibility(e, t)
                }
                setHeight(e) {
                    void 0 !== this._tableProps.virtualScrolling && (this._tableProps.virtualScrolling = { ...this._tableProps.virtualScrolling,
                        tbodyHeight: e
                    }), this._tableProps.childComponents = { ...this._tableProps.childComponents,
                        tableWrapper: {
                            elementAttributes: () => ({ ...this._makeTableWrapperAttributes(),
                                style: {
                                    height: e
                                }
                            })
                        }
                    }, this._render()
                }
                setRowInactiveById(e, t) {
                    var s;
                    (null === (s = this._rowsDisplayOptions.get(e)) || void 0 === s ? void 0 : s.isInactive) !== t && (this._setRowInactiveById(e, t), this._render())
                }
                setRowInactiveByFilter(e) {
                    this._model.data().forEach((t, s) => this._setRowInactiveById(s, e(t))), this._render()
                }
                setRowLinkedById(e, t) {
                    var s;
                    (null === (s = this._rowsDisplayOptions.get(e)) || void 0 === s ? void 0 : s.isLinked) !== t && (this._setRowLinkedById(e, t), this._render())
                }
                setRowLinkedByFilter(e) {
                    this._model.data().forEach((t, s) => this._setRowLinkedById(s, e(t))), this._render()
                }
                destroy() {
                    var e;
                    (0, Ne.mediaQueryRemoveEventListener)(this._mobileMediaQuery, this._resizeHandler), this._unsubscribeModel(), null === (e = this._containerVisibilityObserver) || void 0 === e || e.disconnect(), n.unmountComponentAtNode(this._container)
                }
                exportData() {
                    const e = [...this._columnsVisibilityInfo.values()];
                    return this._model.rows().map(t => {
                        const s = {};
                        for (const {
                                isVisible: i,
                                label: r,
                                property: o
                            } of e) {
                            if (!i || "settings" === o) continue;
                            const e = this._makeTextContent({
                                field: o,
                                value: t[o],
                                rowData: t
                            });
                            s[r] = e || ""
                        }
                        return s
                    })
                }
                _setRowInactiveById(e, t) {
                    this._updateRowDisplayOptions(e, {
                        isInactive: t
                    })
                }
                _setRowLinkedById(e, t) {
                    this._updateRowDisplayOptions(e, {
                        isLinked: t
                    })
                }
                _rowElementById(e) {
                    var t;
                    return null !== (t = this._rowsElements.get(e)) && void 0 !== t ? t : void 0
                }
                _makeColumns() {
                    const e = new Map;
                    for (const [t, s] of this._columnsMetainfo) {
                        const {
                            isVisible: i,
                            isVisibleOnMobile: r,
                            forceInvisible: o
                        } = (0, l.ensureDefined)(this._columnsVisibilityInfo.get(t));
                        this._isMobile || this._fixedColumns || void 0 !== this._columnsWidth.get(t) || this._columnsWidth.set(t, St(s.label) + ut.cellLateralPadding);
                        const n = {
                                key: t,
                                title: s.label,
                                visible: (this._isMobile ? r : i) && !o,
                                style: {
                                    minWidth: this._isMobile ? void 0 : ut.minCellWidth,
                                    maxWidth: this._isMobile ? void 0 : ut.maxCellWidth
                                }
                            },
                            a = this._sortingModeSwitcher.value();
                        t === this._sortingColumn && null !== a && (n.sortDirection = bt[a]), e.set(n.key, n)
                    }
                    const t = this._getSavedColumnsOrder();
                    return this._columnsMetainfo.has("settings") || e.set("settings", {
                        key: "settings",
                        title: "",
                        visible: !0
                    }), this._isMobile || void 0 === t ? [...e.values()] : this._reorderColumns(t, e)
                }
                _resetTableVirtualScrollPosition() {
                    void 0 !== this._tableProps.virtualScrolling && (this._tableProps.virtualScrolling = { ...this._tableProps.virtualScrolling,
                        scrollTop: 0
                    }, this._tableWrapperKey = (0, Le.randomHashN)(5), this._render(!0))
                }
                _render(e = !1) {
                    if (!e && !this._isVisible) return;
                    const t = this._model.rows();
                    let s = [];
                    this._isMobile && 0 !== t.length && (s = this._getAvailableColumnsFilterItems()), n.render(o.createElement(o.Fragment, null, 0 !== s.length && o.createElement(et, { ...this._columnsFilterProps,
                        items: s
                    }), o.createElement(ke.DndProvider, {
                        backend: Oe.HTML5Backend
                    }, o.createElement(Be.Table, { ...this._tableProps,
                        dispatch: this._updateTableProps,
                        data: t
                    }))), this._container)
                }
                _updateRowDisplayOptions(e, t) {
                    const s = this._rowsDisplayOptions.get(e);
                    this._rowsDisplayOptions.set(e, { ...s,
                        ...t
                    })
                }
                _handleSortingUpdate(e) {
                    e === this._sortingColumn ? this._sortingModeSwitcher.next() : (this._sortingColumn = e, this._sortingModeSwitcher.reset()), this._updateSortingColumnSettings(), this.onSortingChange.fire({
                        column: e,
                        mode: this._sortingModeSwitcher.value()
                    })
                }
                _updateSortingColumnSettings() {
                    const e = this._sortingModeSwitcher.value();
                    if (null === e) return f.remove(this._sortingColumnKey), void f.remove(this._sortingModeKey);
                    f.setValue(this._sortingColumnKey, this._sortingColumn), f.setValue(this._sortingModeKey, e)
                }
                _getSavedSortingParameters() {
                    const e = f.getValue(this._sortingColumnKey);
                    if (void 0 === e) return;
                    return {
                        columnId: e,
                        asc: 0 === f.getInt(this._sortingModeKey)
                    }
                }
                _setColumnAvailableInFilter(e, t) {
                    t ? this._hiddenFilterColumns.delete(e) : this._hiddenFilterColumns.add(e)
                }
                _makeColumnsVisibilityInfo() {
                    const e = new Map,
                        t = [...this._columnsMetainfo.values()].filter(e => e.hideByDefault).map(e => e.property),
                        s = f.getJSON(this._id + ".invisibleColumns", t),
                        i = f.getJSON(this._id + ".invisibleMobileColumns", t);
                    return this._columnsMetainfo.forEach(t => {
                        var r;
                        const o = s.includes(t.property),
                            n = i.includes(t.property);
                        (this._isMobile ? n : o) ? this._visibleColumnsWithFormatters.delete(t.property): this._visibleColumnsWithFormatters.set(t.property, null !== (r = t.formatter) && void 0 !== r ? r : "text"), e.set(t.property, {
                            isVisible: !o,
                            isVisibleOnMobile: !n,
                            isAlwaysVisible: !0 === t.notHideable,
                            property: t.property,
                            label: t.label
                        })
                    }), e
                }
                _isFirstRow(e) {
                    var t;
                    return e === (null === (t = this._model.rows()[0]) || void 0 === t ? void 0 : t[this._idProperty])
                }
                _isLastRow(e) {
                    var t;
                    const s = this._model.rows();
                    return e === (null === (t = s[s.length - 1]) || void 0 === t ? void 0 : t[this._idProperty])
                }
                _checkBottomIsVisible(e) {
                    const t = e.querySelector('[data-selector="table"]');
                    if (null === t) return;
                    const {
                        bottom: s
                    } = t.getBoundingClientRect(), i = window.innerHeight - s >= -100;
                    this.onBottomVisibilityChange.fire(i)
                }
                _makeColumnsFilterProps() {
                    return {
                        items: [...this._columnsVisibilityInfo.values()].filter(e => "settings" !== e.property && !e.isAlwaysVisible).map(e => ({
                            id: e.property,
                            title: e.label,
                            visible: (this._isMobile ? e.isVisibleOnMobile : e.isVisible) && !e.forceInvisible
                        })),
                        onCheck: e => this._toggleColumnVisibility(e),
                        overlapManagerWV: this._overlapManager,
                        isSticky: this._isStickyMobileColumnsFilter
                    }
                }
                _toggleColumnVisibility(e) {
                    const t = !this._visibleColumnsWithFormatters.has(e);
                    this._setColumnVisibility(e, t);
                    const s = `${this._id}${this._isMobile?".invisibleMobileColumns":".invisibleColumns"}`,
                        i = new Set(f.getJSON(s, []));
                    t ? i.delete(e) : i.add(e), f.setJSON(s, [...i])
                }
                _setColumnVisibility(e, t) {
                    var s, i;
                    t ? this._visibleColumnsWithFormatters.set(e, null !== (i = null === (s = this._columnsMetainfo.get(e)) || void 0 === s ? void 0 : s.formatter) && void 0 !== i ? i : "text") : this._visibleColumnsWithFormatters.delete(e);
                    const r = this._columnsVisibilityInfo.get(e);
                    void 0 !== r && (this._isMobile ? this._columnsVisibilityInfo.set(e, { ...r,
                            isVisibleOnMobile: t && !r.forceInvisible
                        }) : this._columnsVisibilityInfo.set(e, { ...r,
                            isVisible: t && !r.forceInvisible
                        }),
                        this._columnsFilterProps = this._makeColumnsFilterProps()), void 0 !== this._tableProps.virtualScrolling && this._rowHeightCache.clear(), this._updateTableProps({
                        type: t ? Ue.ActionType.ShowColumn : Ue.ActionType.HideColumn,
                        columnKey: e
                    })
                }
                _getAvailableColumnsFilterItems() {
                    return this._columnsFilterProps.items.filter(e => !this._hiddenFilterColumns.has(e.id))
                }
                _subscribeModel() {
                    this._model.onRowChanged.subscribe(this, this._invalidateRowCache), this._model.onRowsChanged.subscribe(this, this._handleEmptyRows), this._model.onRowsChanged.subscribe(this, this._update)
                }
                _unsubscribeModel() {
                    this._model.onRowChanged.unsubscribe(this, this._invalidateRowCache), this._model.onRowsChanged.unsubscribe(this, this._handleEmptyRows), this._model.onRowsChanged.unsubscribe(this, this._update)
                }
                _reorderColumns(e, t) {
                    const s = new Map(t),
                        i = s.get("settings");
                    s.delete("settings");
                    const r = [];
                    for (const t of e) {
                        const e = s.get(t);
                        void 0 !== e && (r.push(e), s.delete(t))
                    }
                    return r.push(...s.values()), void 0 !== i && r.push(i), r
                }
                _getSavedColumnsOrder() {
                    var e;
                    return null === (e = this._getSettingsStorage()) || void 0 === e ? void 0 : e.tableColumnsOrder(this._id)
                }
            }
            var xt = s(67761);
            class Et extends z {
                constructor(e) {
                    const t = Fe({
                            withScroll: !0
                        }),
                        s = [],
                        i = [],
                        r = [];
                    e.tables.forEach(o => {
                        var n, a, l;
                        const c = Fe({
                                withScroll: !0,
                                fitContent: 1 !== e.tables.length
                            }),
                            d = document.createElement("div"),
                            h = new Ae({
                                options: o.options,
                                priceFormatterGetter: o.priceFormatterFn,
                                reverse: null === (n = o.flags) || void 0 === n ? void 0 : n.reverse,
                                columns: o.columns
                            }),
                            u = new Tt({
                                id: o.id,
                                model: h,
                                container: d,
                                columns: o.columns,
                                idProperty: o.options.idProperty,
                                className: o.options.className,
                                stickyMobileColumnsFilter: !0,
                                overlapManager: e.overlapManager,
                                initialSorting: o.initialSorting,
                                fixedColumns: null === (a = o.flags) || void 0 === a ? void 0 : a.fixedColumns,
                                getSettingsStorage: e.getTableSettingsStorage,
                                rowEventsHandlers: o.rowEventsHandlers
                            });
                        if (o.title) {
                            const e = function(e) {
                                const t = document.createElement("h3");
                                return t.className = xt.title, t.textContent = e, t
                            }(o.title);
                            c.appendChild(e)
                        }
                        c.appendChild(d), t.appendChild(c);
                        const p = new j({
                            idProperty: o.options.idProperty,
                            name: o.title || void 0,
                            model: h,
                            view: u,
                            source: o.source,
                            subscriptions: o.subscriptions,
                            supportPagination: null === (l = o.flags) || void 0 === l ? void 0 : l.supportPagination
                        });
                        i.push(h), r.push(u), s.push(p), p.addFormatters(o.formatters.concat(xe)), p.start()
                    });
                    const o = {
                        id: e.id,
                        name: e.title,
                        headerCounter: !1
                    };
                    super(t, o, s), this._tableViewModels = i, this._tableViews = r, this._contentPage = t
                }
                setHeight(e) {
                    var t, s;
                    if (1 === this._tableControllers.length) {
                        const i = null !== (s = null === (t = this._contentPage.getElementsByTagName("h3")[0]) || void 0 === t ? void 0 : t.offsetHeight) && void 0 !== s ? s : 0;
                        this._tableControllers[0].setHeight(e - i)
                    }
                }
                destroy() {
                    this._tableViewModels.forEach(e => e.destroy()), this._tableViews.forEach(e => e.destroy()), super.destroy()
                }
            }
            const Dt = [{
                label: (0, r.t)("Time"),
                property: "time",
                formatter: "localDate"
            }, {
                label: (0, r.t)("Title"),
                property: "title"
            }, {
                label: (0, r.t)("Text"),
                property: "text"
            }];
            class Ft extends z {
                constructor(e, t, s) {
                    super(e, t, s), s.forEach(e => e.addFormatters(t.formatters.concat(xe)))
                }
            }

            function Mt(e) {
                return "" === e || null == e
            }
            const Pt = 2 * ut.mobileRowPadding + ut.mobileRowBorderSize;

            function At(e, t) {
                let s = Pt;
                for (const [i, r] of t.entries()) {
                    Mt(e[i]) || (s += 22)
                }
                return s
            }

            function kt(e, t) {
                let s = Pt;
                for (const i of t.keys()) {
                    Mt(e[i]) || (s += 22)
                }
                return s
            }
            class Ot extends Ft {
                constructor(e) {
                    const t = Fe(),
                        s = new Ae({
                            options: {
                                idProperty: "id"
                            },
                            priceFormatterGetter: e.priceFormatterFn,
                            columns: e.columns
                        }),
                        i = new Tt({
                            id: e.id,
                            model: s,
                            container: t,
                            columns: e.columns,
                            idProperty: "id",
                            virtualization: {
                                enabled: !0,
                                rowHeightParams: {
                                    mobile: kt
                                }
                            },
                            overlapManager: e.overlapManager,
                            initialSorting: e.initialSorting,
                            rowBadgeTypeInferrer: e.rowBadgeTypeInferrer,
                            getSettingsStorage: e.getTableSettingsStorage
                        }),
                        r = new j({
                            idProperty: "id",
                            model: s,
                            view: i,
                            source: e.source,
                            subscriptions: e.subscriptions
                        });
                    super(t, {
                        id: e.id,
                        name: e.title,
                        headerCounter: !1,
                        formatters: e.formatters
                    }, [r]), this._tableViewModel = s, this._tableView = i, r.start()
                }
                destroy() {
                    this._tableViewModel.destroy(), this._tableView.destroy(), super.destroy()
                }
            }
            class Rt {
                constructor(e, t, s, i) {
                    this.filterFullUpdateDelegate = new(g()), this.filterObjectUpdateDelegate = new(g()), this.filterObjectDeleteDelegate = new(g()), this._filteredObjects = [], this._requestsCount = 0, this._started = !1, this._objectsRequest = null, this._source = e, this._objectUpdateDelegate = t, this._objectDeleteDelegate = s, this._fullUpdateDelegate = i
                }
                start() {
                    this._requestsCount++;
                    const e = this._source,
                        t = this._objectsRequest || Promise.resolve([]);
                    this._objectsRequest = t.then(() => e()).then(e => {
                        const t = e.filter(e => this._satisfy(e));
                        return this._requestsCount--, this._requestsCount || (this.stop(), this._filteredObjects = t, this._objectsRequest = null, this._objectUpdateDelegate.subscribe(this, this._onObjectUpdated), this._objectDeleteDelegate && this._objectDeleteDelegate.subscribe(this, this._onObjectDeleted), this._fullUpdateDelegate.subscribe(this, this._onFullUpdate), this._started = !0), t.slice(0)
                    })
                }
                stop() {
                    this._objectUpdateDelegate.unsubscribe(this, this._onObjectUpdated), this._fullUpdateDelegate.unsubscribe(this, this._onFullUpdate), this._objectDeleteDelegate && this._objectDeleteDelegate.unsubscribe(this, this._onObjectDeleted), this._filteredObjects = [], this._started = !1
                }
                isStarted() {
                    return this._started
                }
                filterSource() {
                    return this._objectsRequest ? this._objectsRequest : Promise.resolve(this._filteredObjects.slice(0))
                }
                _satisfy(e) {
                    throw new Error("should be implemented")
                }
                _onFullUpdate() {
                    this.stop(), this.start(), this.filterFullUpdateDelegate.fire()
                }
                _onObjectDeleted(e) {
                    const t = this._filteredObjects.find(t => t.id === e);
                    t && this.filterObjectDeleteDelegate.fire(t.id)
                }
                _onObjectUpdated(e) {
                    const t = this._filteredObjects.find(t => t.id === e.id),
                        s = t ? this._filteredObjects.indexOf(t) : -1;
                    this._satisfy(e) ? (t ? this._filteredObjects[s] = e : this._filteredObjects.push(e), this.filterObjectUpdateDelegate.fire(e)) : t && (this.filterObjectDeleteDelegate.fire(t.id), this._filteredObjects.splice(s, 1))
                }
            }
            class It extends j {
                constructor(e) {
                    super(e), this._onLinkingBound = this._onLinking.bind(this), c.linking.proSymbol.subscribe(this._onLinkingBound)
                }
                destroy() {
                    c.linking.proSymbol.unsubscribe(this._onLinkingBound), super.destroy()
                }
                _update(e) {
                    if (!super._update(e)) return !1;
                    const t = c.linking.proSymbol.value();
                    return this.setRowLinkedById(e.id, t === e.symbol), !0
                }
                _onCreated() {
                    this.setRowLinkedByFilter(e => e.symbol === c.linking.proSymbol.value())
                }
                _onLinking(e) {
                    this.setRowLinkedByFilter(t => t.symbol === e)
                }
            }
            var Nt = s(85410);

            function Bt(e, t) {
                const s = document.createElement("div");
                s.className = "tv-tabs tv-tabs--no-border tv-tabs--secondary-active tv-tabs--no-margin tv-tabs--semi-compact";
                for (const i of e) {
                    const e = document.createElement("div");
                    e.className = "tv-tabs__tab " + i.id;
                    const r = document.createElement("div");
                    r.className = "tv-tabs__wrap";
                    const o = document.createElement("div");
                    o.className = Nt.counter;
                    const n = document.createElement("div");
                    n.className = Nt.text, n.textContent = i.name;
                    const a = document.createElement("div");
                    a.className = `${Nt.count} js-counter-category-${i.id} js-counter-count`;
                    const l = null == t ? void 0 : t[i.id];
                    void 0 !== l && a.classList.add(l), a.textContent = "0", o.appendChild(n), o.appendChild(a), r.appendChild(o), e.appendChild(r), s.appendChild(e)
                }
                return s
            }
            var Ut = s(52130),
                Lt = s(72571),
                Vt = s(24818),
                Ht = s(2627),
                Wt = s(44114),
                jt = s(72351),
                Gt = s(6467);

            function zt(e) {
                const {
                    closeFn: t,
                    closeTitle: s,
                    isDisabled: i
                } = e;
                return o.createElement(Ge.ToolWidgetButton, {
                    className: Ht.icon,
                    title: null != s ? s : (0, r.t)("Close", {
                        context: "position"
                    }),
                    icon: jt,
                    onClick: e => {
                        e.stopPropagation(), t()
                    },
                    isDisabled: i
                })
            }

            function qt(e) {
                const {
                    editFn: t,
                    editTitle: s,
                    isDisabled: i
                } = e;
                return o.createElement(Ge.ToolWidgetButton, {
                    className: Ht.icon,
                    title: null != s ? s : (0, r.t)("Edit"),
                    icon: Wt,
                    onClick: () => t(),
                    isDisabled: i
                })
            }
            const Qt = {
                [Vt.OrderOrPositionMessageType.Information]: Ht.information,
                [Vt.OrderOrPositionMessageType.Warning]: Ht.warning,
                [Vt.OrderOrPositionMessageType.Error]: Ht.error
            };

            function $t(e) {
                const {
                    type: t,
                    text: s
                } = e;
                return o.createElement(Lt.Icon, {
                    className: te()("apply-common-tooltip", Ht.message, Qt[t]),
                    title: s,
                    icon: Gt
                })
            }

            function Jt(e) {
                const [t, s] = (0, o.useState)(!1), i = (0, Ut.useIsMounted)(), {
                    closeFn: r,
                    closeTitle: n,
                    editFn: a,
                    editTitle: l,
                    message: c
                } = e;
                return o.createElement("span", {
                    className: Ht.wrapper
                }, void 0 !== c && o.createElement($t, { ...c
                }), void 0 !== a && o.createElement(qt, {
                    editFn: a,
                    editTitle: l,
                    isDisabled: t
                }), void 0 !== r && o.createElement(zt, {
                    closeFn: async function() {
                        try {
                            s(!0), await (null == r ? void 0 : r())
                        } finally {
                            i.current && s(!1)
                        }
                    },
                    closeTitle: n,
                    isDisabled: t
                }))
            }
            class Kt {
                constructor(e, t, s, i) {
                    this._source = e, this._totalCount = 0, this._activeCount = 0, this._orderUpdateDelegate = t, this._fullUpdateDelegate = s, this._possibleStatuses = i, this._statusCount = this._emptyStatuses(), this.countChanged = new(g()), this._recalcCountsDelayed = (0, Re.default)(this._recalcCounts.bind(this), 100)
                }
                start() {
                    this._orderUpdateDelegate.subscribe(this, this._recalcCountsDelayed), this._fullUpdateDelegate.subscribe(this, this._recalcCountsDelayed), this._recalcCounts()
                }
                stop() {
                    this._statusCount = this._emptyStatuses(), this._orderUpdateDelegate.unsubscribe(this, this._recalcCountsDelayed), this._fullUpdateDelegate.unsubscribe(this, this._recalcCountsDelayed)
                }
                _emptyStatuses() {
                    const e = {};
                    return this._possibleStatuses.forEach(t => {
                        e[t] = 0
                    }), e
                }
                _recalcCounts() {
                    const e = this._emptyStatuses();
                    this._source().then(t => {
                        let s = 0;
                        t.forEach(t => {
                            const i = e[t.status];
                            void 0 !== i && (e[t.status] = i + 1, 6 !== t.status && 3 !== t.status || s++)
                        }), this._possibleStatuses.forEach(t => {
                            e[t] !== this._statusCount[t] && (this._statusCount[t] = e[t], this.countChanged.fire(t, (0, l.ensureDefined)(this._statusCount[t])))
                        }), this._totalCount !== t.length && (this._totalCount = t.length, this.countChanged.fire(0, this._totalCount)), this._activeCount !== s && (this._activeCount = s, this.countChanged.fire(-1, this._activeCount))
                    })
                }
            }
            class Xt extends Rt {
                constructor(e, t, s, i) {
                    super(e, t, s, i), this._filterStatus = null
                }
                setFilterStatus(e) {
                    this._filterStatus = e, this.isStarted() && (this.stop(), this.start())
                }
                filterStatus() {
                    return this._filterStatus
                }
                _satisfy(e) {
                    return !this._filterStatus || e.status === this._filterStatus
                }
            }
            class Zt extends Rt {
                constructor(e, t, s, i, r) {
                    super(e, t, s, i), this._functor = r
                }
                _satisfy(e) {
                    return this._functor(e)
                }
            }
            class Yt {
                constructor(e, t, s) {
                    this._orders = [], this._source = e, this._rowUpdateDelegate = t, this._fullUpdateDelegate = s, this._orders = [], this.newStatusDelegate = new(g())
                }
                start() {
                    this._source().then(e => {
                        this._orders = e.slice(0), this._rowUpdateDelegate.subscribe(this, this._onRowUpdated), this._fullUpdateDelegate.subscribe(this, this._onFullUpdate)
                    })
                }
                stop() {
                    this._fullUpdateDelegate.unsubscribe(this, this._onFullUpdate), this._rowUpdateDelegate.unsubscribe(this, this._onRowUpdated), this._orders = []
                }
                _onFullUpdate() {
                    this.stop(), this.start()
                }
                _onRowUpdated(e) {
                    const t = this._orders.find(t => t.id === e.id);
                    t && t.status === e.status || (this.newStatusDelegate.fire(e), t ? t.status = e.status : this._orders.push(Object.assign({}, e)))
                }
            }
            class es extends It {
                constructor(e) {
                    super(e), this._title = e.title, this._getFilterStatus = e.filterStatusGetter, this._isAlwaysActive = e.isAlwaysActive
                }
                fullUpdate() {
                    return this._fullUpdate()
                }
                getDataExporter() {
                    const e = super.getDataExporter(),
                        t = this._getFilterStatus(),
                        s = null !== t ? (0, O.orderStatusToText)(t) : (0, r.t)("All");
                    return e.name = `${this._title} ${s}`, e
                }
                _update(e) {
                    return !!super._update(e) && (this.setRowInactiveById(e.id, !this._filterByStatus(e.status)), !0)
                }
                _onCreated() {
                    super._onCreated(), this.setRowInactiveByFilter(e => !this._filterByStatus(e.status))
                }
                _filterByStatus(e) {
                    return this._isAlwaysActive || null !== this._getFilterStatus() || (0, O.isOrderActive)(e)
                }
            }
            const ts = {
                    "orderstatus-working": Nt.blue,
                    "orderstatus-inactive": Nt.grey,
                    "orderstatus-filled": Nt.green,
                    "orderstatus-cancelled": Nt.orange,
                    "orderstatus-rejected": Nt.red
                },
                ss = ["formatPrice", "formatPriceForexSup"];
            class is extends z {
                constructor(e) {
                    const t = e.formatters || [],
                        s = new Zt(e.source, e.subscriptions.rowUpdateDelegate, null, e.subscriptions.fullUpdateDelegate, e.filter),
                        i = new Kt(s.filterSource.bind(s), s.filterObjectUpdateDelegate, s.filterFullUpdateDelegate, e.possibleOrderStatuses),
                        n = new Xt(s.filterSource.bind(s), s.filterObjectUpdateDelegate, s.filterObjectDeleteDelegate, s.filterFullUpdateDelegate),
                        a = e.subscriptions.fullUpdateDelegate;
                    e.source = n.filterSource.bind(n), e.subscriptions.rowUpdateDelegate = n.filterObjectUpdateDelegate, e.subscriptions.rowDeleteDelegate = n.filterObjectDeleteDelegate, e.subscriptions.fullUpdateDelegate = n.filterFullUpdateDelegate;
                    const c = Fe(),
                        d = {
                            group: e => +(0, O.isOrderActive)(e.status),
                            idProperty: "id"
                        },
                        h = e.columns.map(e => ss.includes(e.formatter) ? { ...e,
                            showZeroValues: !1
                        } : e),
                        u = [...h, {
                            label: "",
                            property: "settings",
                            formatter: "orderSettings",
                            notSortable: !0,
                            showOnMobile: !1
                        }],
                        p = new Ae({
                            columns: u,
                            priceFormatterGetter: e.priceFormatterFn,
                            options: d
                        }),
                        _ = new Tt({
                            id: e.tableId,
                            model: p,
                            className: "orders",
                            container: c,
                            columns: u,
                            idProperty: "id",
                            virtualization: {
                                enabled: !0,
                                rowHeightParams: {
                                    mobile: At
                                }
                            },
                            overlapManager: e.overlapManager,
                            initialSorting: e.initialSorting,
                            getSettingsStorage: e.getTableSettingsStorage,
                            rowEventsHandlers: e.tableRowEventsHandlers
                        }),
                        m = {
                            id: e.id,
                            name: e.title,
                            headerCounter: e.headerCounter
                        },
                        g = new es({
                            idProperty: "id",
                            title: e.title,
                            model: p,
                            view: _,
                            source: e.source,
                            subscriptions: e.subscriptions,
                            filterStatusGetter: () => this._ordersFilter.filterStatus(),
                            isAlwaysActive: e.isAlwaysActive
                        });
                    super(c, m, [g]), this._tableViewModel = p, this._tableView = _, this._tableController = g, this._globalFullUpdateDelegate = a, this._statusWatcher = new Yt(s.filterSource.bind(s), s.filterObjectUpdateDelegate, s.filterFullUpdateDelegate), this._orderPreFilter = s, this._ordersFilter = n, this._statusesCount = i, this._activeCount = 0, this._highlightChanges = e.highlightChanges, this._possibleOrderStatuses = e.possibleOrderStatuses, this._columns = h, this._pendingNewOrdersByStatuses = {}, this._configFlags = e.configFlags, this._closeFn = t => ((0, l.ensureNotNull)((0, N.tradingService)()).trackEvent("Orders Page", "Cancel Order"), e.cancelFn(t)), this._editFn = (t, s, i, r) => ((0, l.ensureNotNull)((0, N.tradingService)()).trackEvent("Orders Page", "Edit Order"), e.modifyFn(t, s, i, r));
                    const b = {
                        name: "orderSettings",
                        formatElement: ({
                            row: e
                        }) => {
                            const t = e,
                                s = "" === t.symbol || !(0, O.isOrderActive)(t.status),
                                i = s && this._isPlacingOrderCancellingDisabled(t.status) ? void 0 : () => this._closeFn(t.id),
                                n = s || !(0, O.isModifyOrderSupported)(t, this._configFlags) ? void 0 : () => this._editFn(t);
                            return o.createElement(Jt, {
                                closeFn: i,
                                closeTitle: (0, r.t)("Cancel"),
                                editFn: n,
                                editTitle: (0, U.appendEllipsis)((0, r.t)("Modify Order")),
                                message: t.message
                            })
                        },
                        formatText: () => ""
                    };
                    g.addFormatters([...xe, b, ...t]);
                    const v = this._possibleOrderStatuses.map(this._translateStatus);
                    this._filter = Bt([{
                        id: "status-all",
                        name: (0, r.t)("All")
                    }].concat(v), ts), this._filterTabs = new x(this._filter, void 0, {
                        noSlider: !0
                    }), this._subscribeUpdates()
                }
                destroy() {
                    this._unsubscribeUpdates(), this._tableViewModel.destroy(), this._tableView.destroy(), super.destroy()
                }
                contextItems(e) {
                    const t = this._tableController.rowIdAtEvent(e);
                    if (void 0 === t) return [];
                    const s = this._tableController.rowById(t);
                    if (void 0 === s || "" === s.symbol) return [];
                    const i = [];
                    return (0, O.isModifyOrderSupported)(s, this._configFlags) && i.push({
                        text: (0, U.appendEllipsis)((0, r.t)("Modify Order")),
                        enabled: (0, O.isOrderActive)(s.status),
                        action: () => this._editFn(s)
                    }), i.push({
                        text: (0, r.t)("Cancel Order"),
                        enabled: (0, O.isOrderActive)(s.status) || !this._isPlacingOrderCancellingDisabled(s.status),
                        action: () => this._closeFn(t)
                    }), i
                }
                contextRow(e) {
                    return this._tableController.rowAtEvent(e)
                }
                topline() {
                    return this._filter
                }
                get filter() {
                    return this._filter
                }
                _subscribeUpdates() {
                    this._tableController.start(),
                        this._orderPreFilter.start(), this._ordersFilter.start(), this._statusesCount.start(), this._statusWatcher.start(), this._statusWatcher.newStatusDelegate.subscribe(this, this._onNewStatus), this._filterTabs.tabChanged.subscribe(this, this._onFilterChanged), this._statusesCount.countChanged.subscribe(this, this._onCountChanged), this._globalFullUpdateDelegate.subscribe(this, this._onGlobalFullUpdate)
                }
                _unsubscribeUpdates() {
                    this._statusWatcher.newStatusDelegate.unsubscribe(this, this._onNewStatus), this._statusWatcher.stop(), this._ordersFilter.stop(), this._statusesCount.stop(), this._tableController.stop(), this._filterTabs.tabChanged.unsubscribe(this, this._onFilterChanged), this._statusesCount.countChanged.unsubscribe(this, this._onCountChanged), this._globalFullUpdateDelegate.unsubscribe(this, this._onGlobalFullUpdate)
                }
                _onGlobalFullUpdate() {
                    this._pendingNewOrdersByStatuses = {}, this._updateFiltersActiveState()
                }
                _count() {
                    this._setCount(this._activeCount)
                }
                _translateStatus(e) {
                    const t = (0, O.orderStatusToText)(e),
                        s = t[0].toUpperCase() + t.slice(1);
                    return {
                        id: rs(e),
                        name: s
                    }
                }
                _onFilterChanged(e) {
                    const t = 0 === e ? null : this._possibleOrderStatuses[e - 1];
                    (0, l.ensureNotNull)((0, N.tradingService)()).trackEvent("Orders Page", "Order status filter", null !== t ? (0, O.orderStatusToText)(t) : void 0), this._ordersFilter.setFilterStatus(t), this._columns.filter(e => e.hasOwnProperty("supportedStatusFilters")).forEach(e => {
                        var s;
                        void 0 !== e.supportedStatusFilters && this._tableController.setColumnAvailable(e.property, e.supportedStatusFilters.includes(null !== (s = t) && void 0 !== s ? s : 0))
                    }), this._tableController.fullUpdate().then(() => {
                        if (t) {
                            const e = this._pendingNewOrdersByStatuses[t];
                            void 0 !== e && e.forEach(e => this._tableController.highlightRowById(e))
                        }
                        this._removeActiveState()
                    })
                }
                _onCountChanged(e, t) {
                    const s = this._filter.querySelectorAll(".js-counter-count");
                    if (0 === e) return void(s[0].textContent = String(t));
                    if (-1 === e && this._activeCount !== t) return this._activeCount = t, void this._count();
                    const i = this._possibleOrderStatuses.indexOf(e); - 1 !== i && (s[i + 1].textContent = String(t))
                }
                _onNewStatus(e) {
                    var t;
                    4 !== e.status && (this._possibleOrderStatuses.forEach(t => {
                        const s = this._pendingNewOrdersByStatuses[t];
                        if (void 0 !== s) {
                            const t = s.indexOf(e.id); - 1 !== t && s.splice(t, 1)
                        }
                    }), this._pendingNewOrdersByStatuses[e.status] || (this._pendingNewOrdersByStatuses[e.status] = []), null === (t = this._pendingNewOrdersByStatuses[e.status]) || void 0 === t || t.push(e.id), setTimeout(() => {
                        var t;
                        const s = this._ordersFilter.filterStatus();
                        let i = !1;
                        s && s !== e.status || this._tableController.isRowInViewport(e.id) && (this._tableController.highlightRowById(e.id), i = !0), i || this._pendingNewOrdersByStatuses[e.status] && -1 !== (null === (t = this._pendingNewOrdersByStatuses[e.status]) || void 0 === t ? void 0 : t.indexOf(e.id)) && this._updateFiltersActiveState(), this._scheduleRemoveActiveState()
                    }, 0))
                }
                _scheduleRemoveActiveState() {
                    this._activeStateRemovalScheduled || (this._activeStateRemovalScheduled = !0, setTimeout(() => this._removeActiveState(), 1e3))
                }
                _removeActiveState() {
                    this._activeStateRemovalScheduled = !1;
                    const e = this._ordersFilter.filterStatus();
                    e ? this._pendingNewOrdersByStatuses[e] = [] : this._pendingNewOrdersByStatuses = {}, this._updateFiltersActiveState()
                }
                _updateFiltersActiveState() {
                    this._highlightChanges && this._possibleOrderStatuses.forEach(e => {
                        var t, s;
                        const i = this._pendingNewOrdersByStatuses[e] && (null === (t = this._pendingNewOrdersByStatuses[e]) || void 0 === t ? void 0 : t.length);
                        null === (s = this._filter.querySelector(".js-counter-category-" + rs(e))) || void 0 === s || s.classList.toggle("i-active", !!i)
                    })
                }
                _isPlacingOrderCancellingDisabled(e) {
                    return !this._configFlags.supportPlacingOrderCancelling || 4 !== e
                }
            }

            function rs(e) {
                switch (e) {
                    case 2:
                        return "orderstatus-filled";
                    case 1:
                        return "orderstatus-cancelled";
                    case 6:
                        return "orderstatus-working";
                    case 3:
                        return "orderstatus-inactive";
                    case 4:
                        return "orderstatus-placing";
                    case 5:
                        return "orderstatus-rejected";
                    default:
                        return "orderstatus-unknown"
                }
            }
            var os = s(81334);
            class ns {
                constructor(e, t, s) {
                    this._totalCount = 0, this._recalcCountsDelayed = (0, Re.default)(this._recalcCounts.bind(this), 100), this._source = e, this._rowUpdateDelegate = t, this._fullUpdateDelegate = s, this.countChanged = new(g())
                }
                start() {
                    this._rowUpdateDelegate.subscribe(this, this._recalcCountsDelayed), this._fullUpdateDelegate.subscribe(this, this._recalcCountsDelayed), this._recalcCounts()
                }
                stop() {
                    this._rowUpdateDelegate.unsubscribe(this, this._recalcCountsDelayed), this._fullUpdateDelegate.unsubscribe(this, this._recalcCountsDelayed)
                }
                _recalcCounts() {
                    this._source().then(e => {
                        const t = e.filter(e => L(e));
                        this._totalCount !== t.length && (this._totalCount = t.length, this.countChanged.fire(this._totalCount))
                    })
                }
            }

            function as(e) {
                const {
                    id: t,
                    name: s,
                    content: i,
                    source: r,
                    subscriptions: o,
                    columns: n,
                    priceFormatterFn: a,
                    rowEventsHandlers: l,
                    overlapManager: c,
                    getTableSettingsStorage: d
                } = e, h = new Ae({
                    priceFormatterGetter: a,
                    columns: n,
                    options: {
                        idProperty: "id"
                    }
                }), u = new Tt({
                    id: t,
                    model: h,
                    className: "positions",
                    container: i,
                    columns: n,
                    idProperty: "id",
                    virtualization: {
                        enabled: !0,
                        rowHeightParams: {
                            mobile: At
                        }
                    },
                    getSettingsStorage: d,
                    overlapManager: c,
                    rowEventsHandlers: l
                });
                return {
                    model: h,
                    view: u,
                    controller: new ls({
                        idProperty: "id",
                        name: s,
                        model: h,
                        view: u,
                        source: r,
                        subscriptions: o
                    })
                }
            }
            class ls extends It {
                _update(e) {
                    return L(e) ? super._update(e) : (this._deleteRow(e.id), !0)
                }
            }
            const cs = ["formatPrice", "formatPriceForexSup"],
                ds = (0, r.t)("Positions"),
                hs = (0, r.t)("Net Positions"),
                us = (0, r.t)("Individual Positions");
            class ps extends z {
                constructor(e) {
                    const t = function() {
                            const e = document.createElement("div");
                            return e.classList.add(os.pageContainer), e
                        }(),
                        s = {
                            id: "positions",
                            name: ds,
                            headerCounter: !0
                        },
                        i = Fe(),
                        n = e.positions.columns.map(e => cs.includes(e.formatter) ? { ...e,
                            showZeroValues: !1
                        } : e);
                    n.push({
                        label: "",
                        property: "settings",
                        formatter: "posSettings",
                        notSortable: !0,
                        showOnMobile: !1
                    });
                    const a = as({
                        id: e.brokerId + ".positions",
                        name: e.trades ? hs : ds,
                        content: i,
                        source: e.positions.source,
                        subscriptions: Object.assign({}, e.positions.subscriptions, {
                            fullUpdateDelegate: e.fullUpdateDelegate
                        }),
                        columns: n,
                        priceFormatterFn: e.priceFormatterFn,
                        overlapManager: e.overlapManager,
                        getTableSettingsStorage: e.getTableSettingsStorage,
                        rowEventsHandlers: e.tableRowEventsHandlers
                    });
                    t.appendChild(i);
                    const c = [a.controller];
                    let d, h = null;
                    if (e.trades) {
                        const s = e.trades.columns.map(e => cs.includes(e.formatter) ? { ...e,
                            showZeroValues: !1
                        } : e);
                        s.push({
                            label: "",
                            property: "settings",
                            formatter: "tradeSettings",
                            notSortable: !0,
                            showOnMobile: !1
                        }), h = Fe(), d = as({
                            id: e.brokerId + ".trades",
                            name: us,
                            content: h,
                            source: e.trades.source,
                            subscriptions: Object.assign({}, e.trades.subscriptions, {
                                fullUpdateDelegate: e.fullUpdateDelegate
                            }),
                            columns: s,
                            priceFormatterFn: e.priceFormatterFn,
                            overlapManager: e.overlapManager,
                            getTableSettingsStorage: e.getTableSettingsStorage,
                            rowEventsHandlers: e.tableRowEventsHandlers
                        }), t.appendChild(h), c.push(d.controller)
                    }
                    super(t, s, c), this._positionsTableContainer = i, this._tradesTableContainer = h, this._positionsTableController = a.controller, this._positionsTableViewModel = a.model, this._positionsTableView = a.view, this._tradesTableController = null == d ? void 0 : d.controller, this._tradesTableViewModel = null == d ? void 0 : d.model, this._tradesTableView = null == d ? void 0 : d.view;
                    const u = e.formatters || [];
                    this._fullUpdateDelegate = e.fullUpdateDelegate, this._posSubscriptions = e.positions.subscriptions, this._checkSupportTrades = e.checkSupportTrades, this._storeFunctions(e);
                    const p = {
                        name: "posSettings",
                        formatElement: ({
                            row: {
                                id: e,
                                message: t,
                                symbol: s
                            }
                        }) => {
                            const i = "" === s,
                                n = i || null === this._closePositionFn ? void 0 : this._closePositionFn.bind(null, e),
                                a = i || null === this._editPositionFn ? void 0 : this._editPositionFn.bind(null, e);
                            return o.createElement(Jt, {
                                closeFn: n,
                                closeTitle: (0, r.t)("Close", {
                                    context: "position"
                                }),
                                editFn: a,
                                editTitle: (0, U.appendEllipsis)((0, r.t)("Protect Position")),
                                message: t
                            })
                        },
                        formatText: () => ""
                    };
                    if (this._positionsTableController.addFormatters([p, ...xe, ...u]), e.trades) {
                        const t = {
                            name: "tradeSettings",
                            formatElement: ({
                                row: {
                                    id: e,
                                    message: t,
                                    canBeClosed: s,
                                    symbol: i
                                }
                            }) => {
                                const n = "" === i,
                                    a = n || null === this._closeTradeFn || !s ? void 0 : this._closeTradeFn.bind(null, e),
                                    l = n || null === this._editTradeFn ? void 0 : this._editTradeFn.bind(null, e);
                                return o.createElement(Jt, {
                                    closeFn: a,
                                    closeTitle: (0, r.t)("Close", {
                                        context: "position"
                                    }),
                                    editFn: l,
                                    editTitle: (0, U.appendEllipsis)((0, r.t)("Protect Position")),
                                    message: t
                                })
                            },
                            formatText: () => ""
                        };
                        (0, l.ensure)(this._tradesTableController).addFormatters([t, ...xe, ...u]), this._tradesCounter = new ns(e.trades.source, e.trades.subscriptions.countUpdateDelegate, this._fullUpdateDelegate)
                    } else this._tradesCounter = null;
                    this._positionsCounter = new ns(e.positions.source, this._posSubscriptions.countUpdateDelegate, this._fullUpdateDelegate), this._constructFilter(), this._subscribeUpdates();
                    const _ = f.getInt("Trading.PositionsTable.Filter", 0),
                        m = this._checkSupportTrades() ? _ : 1;
                    this._filterTabs.setActivePage(m), this._selectPage(m)
                }
                contextItems(e) {
                    const t = this._activeTableController(),
                        s = t.rowIdAtEvent(e);
                    if (void 0 === s) return [];
                    const i = (0, l.ensureDefined)(t.rowById(s));
                    if ("" === i.symbol) return [];
                    const o = [];
                    return 0 === this._filterTabs.index() ? (this._editTradeFn && o.push({
                        text: (0, U.appendEllipsis)((0, r.t)("Protect Position")),
                        action: this._editTradeFn.bind(null, s)
                    }), this._closeTradeFn && i.canBeClosed && o.push({
                        text: (0, r.t)("Close Position"),
                        action: this._closeTradeFn.bind(null, s)
                    }), o) : (this._editPositionFn && o.push({
                        text: (0, U.appendEllipsis)((0, r.t)("Protect Position")),
                        action: this._editPositionFn.bind(null, s)
                    }), this._closePositionFn && o.push({
                        text: (0, r.t)("Close Position"),
                        action: this._closePositionFn.bind(null, s)
                    }), this._reversePositionFn && o.push({
                        text: (0, r.t)("Reverse Position"),
                        action: this._reversePositionFn.bind(null, s)
                    }), o)
                }
                contextRow(e) {
                    return this._activeTableController().rowAtEvent(e)
                }
                topline() {
                    return this._checkSupportTrades() ? this._filter : null
                }
                destroy() {
                    var e, t;
                    this._unsubscribeUpdates(), this._positionsTableViewModel.destroy(), this._positionsTableView.destroy(), null === (e = this._tradesTableViewModel) || void 0 === e || e.destroy(), null === (t = this._tradesTableView) || void 0 === t || t.destroy(), super.destroy()
                }
                _onActiveChanged(e) {
                    e ? this._activeTableController().setActive(!0) : (this._positionsTableController.setActive(!1), this._tradesTableController && this._tradesTableController.setActive(!1))
                }
                _onPositionsCountChanged(e) {
                    this._setCount(e), this._setTabCount(1, e)
                }
                _onTradesCountChanged(e) {
                    this._setTabCount(0, e)
                }
                _setTabCount(e, t) {
                    this._filter.querySelectorAll(".js-counter-count")[e].innerHTML = String(t)
                }
                _activeTableController() {
                    return this._checkSupportTrades() && 0 === this._filterTabs.index() ? (0, l.ensure)(this._tradesTableController) : this._positionsTableController
                }
                _subscribeUpdates() {
                    this._positionsCounter.start(), this._positionsCounter.countChanged.subscribe(this, this._onPositionsCountChanged), this._tradesCounter && (this._tradesCounter.start(), this._tradesCounter.countChanged.subscribe(this, this._onTradesCountChanged)), this._filterTabs.tabChanged.subscribe(this, this._selectPage), this._fullUpdateDelegate.subscribe(this, this._showFilterIfNeeded)
                }
                _unsubscribeUpdates() {
                    this._positionsCounter.stop(), this._positionsCounter.countChanged.unsubscribe(this, this._onPositionsCountChanged), this._tradesCounter && (this._tradesCounter.stop(), this._tradesCounter.countChanged.unsubscribe(this, this._onTradesCountChanged)), this._filterTabs.tabChanged.unsubscribe(this, this._selectPage), this._fullUpdateDelegate.unsubscribe(this, this._showFilterIfNeeded)
                }
                _constructFilter() {
                    this._filter = Bt([{
                        id: "type-individual",
                        name: us
                    }, {
                        id: "type-net",
                        name: hs
                    }]), this._filterTabs = new x(this._filter, void 0, {
                        noSlider: !0
                    })
                }
                _showFilterIfNeeded() {
                    this.isActive() && this._checkSupportTrades() ? this._filter.classList.remove("js-hidden") : (this._filter.classList.add("js-hidden"), this._tradesTableController && this._tradesTableController.stop())
                }
                _selectPage(e) {
                    const t = 1 === e;
                    t ? this._positionsTableController.start() : this._tradesTableController && this._tradesTableController.start(), this._positionsTableContainer.classList.toggle("js-hidden", !t), this._tradesTableContainer && this._tradesTableContainer.classList.toggle("js-hidden", t), this._positionsTableController.setActive(t), this._tradesTableController && this._tradesTableController.setActive(!t), f.setValue("Trading.PositionsTable.Filter", e)
                }
                _storeFunctions(e) {
                    const t = (0, l.ensure)((0, N.tradingService)()),
                        s = "Positions Page",
                        i = e.positions.closeFn;
                    this._closePositionFn = i ? e => (t.trackEvent(s, "Close Position"), i(e)) : null;
                    const r = e.positions.editFn;
                    this._editPositionFn = r ? e => (t.trackEvent(s, "Edit Position"), r(e)) : null;
                    const o = e.positions.reverseFn;
                    this._reversePositionFn = o ? e => (t.trackEvent(s, "Reverse Position"), o(e)) : null;
                    const n = e.trades;
                    if (n) {
                        const e = n.closeFn;
                        this._closeTradeFn = e ? i => (t.trackEvent(s, "Close Trade"), e(i)) : null;
                        const i = n.editFn;
                        this._editTradeFn = i ? e => (t.trackEvent(s, "Edit Trade"), i(e)) : null
                    }
                }
            }
            var _s = s(61851),
                ms = s(51871);

            function gs(e) {
                const {
                    wValue: t,
                    formatter: s,
                    text: i
                } = e, r = (0, je.useWatchedValueReadonly)({
                    watchedValue: t
                }), n = (0, o.useMemo)(() => function(e, t = Se) {
                    for (const t of xe)
                        if (t.name === e) return t;
                    return t
                }(null != s ? s : "fixed"), [s]), a = (0, o.useMemo)(() => function(e, t) {
                    var s;
                    const i = (null !== (s = e.formatElement) && void 0 !== s ? s : e.formatText)({
                        value: t,
                        row: {}
                    });
                    return "string" != typeof i ? i : i.replace(/&nbsp;/g, " ")
                }(n, r), [n, r]);
                return void 0 === a ? o.createElement(o.Fragment, null) : o.createElement("div", {
                    className: ms.itemWrapper
                }, o.createElement("div", {
                    className: ms.value
                }, a), o.createElement("div", {
                    className: ms.title
                }, i))
            }
            var bs = s(55983);

            function vs(e) {
                const {
                    summaryFields: t,
                    summaryFieldsVisibilityInfo: s
                } = e;
                return o.createElement("div", {
                    className: bs.wrapper
                }, t.map(e => {
                    var t;
                    return (null === (t = s.get(e.text)) || void 0 === t ? void 0 : t.visible) ? o.createElement(gs, { ...e,
                        key: e.text
                    }) : null
                }))
            }
            var fs = s(73560),
                ws = s(16719);

            function Cs(e) {
                const {
                    brokerDropdownProps: t,
                    accountDropdownProps: s,
                    summaryFieldsVisibilityManager: i,
                    summaryFields: r
                } = e, n = (0, _s.useObservable)(i.fieldsVisibilityInfo$, i.fieldsVisibilityInfo()), a = void 0 !== s, l = 0 !== r.length;
                return a || l ? o.createElement("div", {
                    className: ws.headerWrapper
                }, a && o.createElement(fs.AccountManagerHeaderDropdowns, {
                    brokerDropdownProps: t,
                    accountDropdownProps: s
                }), l && o.createElement(vs, {
                    summaryFields: r,
                    summaryFieldsVisibilityInfo: n
                })) : o.createElement(o.Fragment, null)
            }
            var ys = s(38186),
                Ss = s(51763),
                Ts = s(62106),
                xs = s(70976),
                Es = s(47276);
            const Ds = [6, 3, 2, 1, 5],
                Fs = [2, 1, 5];
            class Ms {
                constructor(e) {
                    this._showContextMenu = async e => {
                        e.preventDefault();
                        let t = await this._contextItems(e);
                        h.enabled("property_pages") || (t = t.slice(0, -1)), R.ContextMenuManager.showMenu((0, O.convertActionDescriptionsToActions)(t), function(e) {
                            const t = e instanceof MouseEvent ? e : e.touches[0];
                            return {
                                clientX: t.clientX,
                                clientY: t.clientY
                            }
                        }(e), void 0, {
                            menuName: "AccountManagerContextMenu"
                        })
                    };
                    const {
                        broker: t,
                        bridge: s,
                        mode: i,
                        summaryFieldsVisibilityManager: r,
                        overlapManager: o
                    } = e;
                    this._adapter = (0, l.ensureNotNull)(t), this._bridge = s, this._container = s.container, this._mode = i, this._overlapManager = o, this._summaryFieldsVisibilityManager = r, this._pages = [], this._topLines = {}, this._trading = (0, l.ensureNotNull)((0, N.tradingService)()), this._info = this._adapter.accountManagerInfo(), this._dispatch = this.bindContextMenu(), this._contentResizeObserver = new a.default(e => {
                        this._contentHeight = e[0].contentRect.height, this._pages[this._tabs.index()].setHeight(this._contentHeight)
                    }), this._renderTemplate(), this._tabs = this._initializeTabs()
                }
                async priceFormatter(e) {
                    return e.symbol ? this._trading.formatter(e.symbol) : null
                }
                remove() {
                    for (this._unmountComponentBySelector(".js-account-manager-header"), this._unsubscribe(),
                        this._pages.forEach(e => e.destroy()), this.unbindContextMenu(); this._container.firstChild;) this._container.removeChild(this._container.firstChild)
                }
                bindContextMenu() {
                    return window.matchMedia(H.TradingLayoutBreakpoint.Mobile).matches && d.CheckMobile.any() ? this._bindTapMenu() : d.CheckMobile.iOS() ? this._bindLongPressMenu() : this._bindContextMenu()
                }
                unbindContextMenu() {
                    null !== this._dispatch && (this._dispatch(), this._dispatch = null)
                }
                static async create(e) {
                    const t = new Ms(e);
                    return await t._create(), t._hideSecondaryPanelIfEmpty(), t._subscribe(), t._fullUpdate(), t
                }
                _bindContextMenu() {
                    return this._container.addEventListener("contextmenu", this._showContextMenu), () => this._container.removeEventListener("contextmenu", this._showContextMenu)
                }
                _bindLongPressMenu() {
                    let e;
                    const t = t => {
                            clearTimeout(e), e = setTimeout(() => this._showContextMenu(t), 400)
                        },
                        s = () => clearTimeout(e);
                    return this._container.addEventListener("touchstart", t), this._container.addEventListener("touchend", s), this._container.addEventListener("touchmove", s), () => {
                        clearTimeout(e), this._container.removeEventListener("touchstart", t), this._container.removeEventListener("touchend", s), this._container.removeEventListener("touchmove", s)
                    }
                }
                _bindTapMenu() {
                    const e = e => {
                            void 0 !== this._currentPage().contextRow(e) && this._showContextMenu(e)
                        },
                        t = e => {
                            e.preventDefault()
                        };
                    return this._container.addEventListener("click", e), this._container.addEventListener("contextmenu", t), () => {
                        this._container.removeEventListener("click", e), this._container.removeEventListener("contextmenu", t)
                    }
                }
                _unmountComponentBySelector(e) {
                    const t = this._container.querySelector(e);
                    null !== t && n.unmountComponentAtNode(t)
                }
                _initializeTabs() {
                    const e = (0, l.ensureNotNull)(this._container.querySelector(".js-content")),
                        t = new x((0, l.ensureNotNull)(this._container.querySelector(".js-top-panel-tabs")), e);
                    return t.tabChanged.subscribe(this, this._onPageChanged), t
                }
                _linkTableRowSymbol(e, t) {
                    t || void 0 === e.symbol || "" === e.symbol || c.linking.symbol.setValue(e.symbol)
                }
                _onTableRowClick(e, t, s, i) {
                    const r = e;
                    t || "" === r.symbol || (c.linking.symbol.value() !== r.symbol ? c.linking.symbol.setValue(r.symbol) : s.setSelectedItem({
                        id: r.id,
                        type: i
                    }))
                }
                _onTableRowMouseEnter(e, t, s, i) {
                    const r = e;
                    t || c.linking.symbol.value() !== r.symbol || s.setHoveredItem({
                        id: r.id,
                        type: i
                    })
                }
                _onTableRowMouseLeave(e, t, s) {
                    const i = e;
                    t || c.linking.symbol.value() !== i.symbol || s.dropHoveredItem()
                }
                _makeTableRowEventsHandlers(e, t) {
                    return {
                        onClick: (s, i) => this._onTableRowClick(s, i, e, t),
                        onMouseEnter: (s, i) => this._onTableRowMouseEnter(s, i, e, t),
                        onMouseLeave: (t, s) => this._onTableRowMouseLeave(t, s, e)
                    }
                }
                async _getPages() {
                    const e = this._adapter.metainfo().id,
                        t = this._adapter.accountManagerInfo(),
                        s = this._adapter.metainfo().configFlags,
                        i = this._getPagesAvailabilityInfo(),
                        o = (0, l.ensureNotNull)(this._trading.brokerCommandsUI()),
                        n = {},
                        a = await this._trading.tradedItemsChartCollectionFacade();
                    if (i.positions) {
                        const i = this._makeTableRowEventsHandlers(a, Ss.TradedItemType.Position);
                        n.positionPage = {
                            ctor: ps,
                            ctorArguments: {
                                brokerId: e,
                                formatters: t.customFormatters || [],
                                tableRowEventsHandlers: i,
                                priceFormatterFn: this.priceFormatter.bind(this),
                                checkSupportTrades: () => !0 === s.supportTrades,
                                positions: {
                                    source: () => this._adapter.positions().then(e => e.filter(e => L(e))),
                                    closeFn: o.closePosition.bind(o),
                                    editFn: s.supportPositionBrackets ? o.editPositionBrackets.bind(o) : null,
                                    reverseFn: s.supportReversePosition ? o.reversePosition.bind(o) : null,
                                    columns: (0, l.ensureDefined)(t.positionColumns),
                                    subscriptions: {
                                        rowUpdateDelegate: new I([this._adapter.positionPartialUpdate, this._adapter.positionUpdate]),
                                        countUpdateDelegate: this._adapter.positionUpdate,
                                        plSubscription: this._adapter.subscribePL.bind(this._adapter)
                                    }
                                },
                                trades: s.supportTrades ? {
                                    source: () => this._adapter.trades().then(e => e.filter(e => 0 !== e.qty)),
                                    closeFn: s.supportCloseTrade ? o.closeTrade.bind(o) : null,
                                    editFn: s.supportTradeBrackets ? (0, l.ensureDefined)(o.editTradeBrackets).bind(o) : null,
                                    reverseFn: null,
                                    columns: (0, l.ensureDefined)(t.tradeColumns || t.positionColumns),
                                    subscriptions: {
                                        rowUpdateDelegate: new I([this._adapter.tradePartialUpdate, this._adapter.tradeUpdate]),
                                        countUpdateDelegate: this._adapter.tradeUpdate,
                                        plSubscription: this._adapter.subscribePL.bind(this._adapter)
                                    }
                                } : null,
                                fullUpdateDelegate: this._adapter.currentAccountUpdate,
                                overlapManager: this._overlapManager,
                                getTableSettingsStorage: this._trading.getBrokerTradingSettingsStorage
                            }
                        }
                    }
                    const c = this._adapter.orders.bind(this._adapter),
                        d = this._makeTableRowEventsHandlers(a, Ss.TradedItemType.Order);
                    n.orderPage = {
                        ctor: is,
                        ctorArguments: {
                            id: "Orders",
                            title: (0, r.t)("Orders"),
                            source: c,
                            cancelFn: o.cancelOrder.bind(o),
                            modifyFn: o.modifyOrder.bind(o),
                            columns: t.orderColumns,
                            headerCounter: !0,
                            tableId: e + ".orders",
                            tableRowEventsHandlers: d,
                            formatters: t.customFormatters || [],
                            priceFormatterFn: this.priceFormatter.bind(this),
                            subscriptions: {
                                fullUpdateDelegate: this._adapter.currentAccountUpdate,
                                rowUpdateDelegate: new I([this._adapter.orderPartialUpdate, this._adapter.orderUpdate]),
                                orderUpdateDelegate: this._adapter.orderUpdate
                            },
                            possibleOrderStatuses: Ds.filter(e => !t.possibleOrderStatuses || -1 !== t.possibleOrderStatuses.indexOf(e)),
                            filter: () => !0,
                            highlightChanges: !0,
                            initialSorting: t.orderColumnsSorting,
                            configFlags: s,
                            overlapManager: this._overlapManager,
                            getTableSettingsStorage: this._trading.getBrokerTradingSettingsStorage
                        }
                    };
                    const h = this._adapter.ordersHistory.bind(this._adapter);
                    return i.history && (n.historyPage = {
                        ctor: is,
                        ctorArguments: {
                            id: "History",
                            title: (0, r.t)("History"),
                            source: () => Promise.all([c(), h()]).then(e => [].concat(...e)),
                            cancelFn: o.cancelOrder.bind(o),
                            modifyFn: o.modifyOrder.bind(o),
                            columns: (0, l.ensureDefined)(t.historyColumns),
                            headerCounter: !1,
                            tableId: e + ".history",
                            tableRowEventsHandlers: d,
                            formatters: t.customFormatters || [],
                            priceFormatterFn: this.priceFormatter.bind(this),
                            subscriptions: {
                                fullUpdateDelegate: this._adapter.currentAccountUpdate,
                                rowUpdateDelegate: new I([this._adapter.orderPartialUpdate, this._adapter.orderUpdate]),
                                orderUpdateDelegate: this._adapter.orderUpdate
                            },
                            possibleOrderStatuses: Fs.filter(e => !t.possibleOrderStatuses || -1 !== t.possibleOrderStatuses.indexOf(e)),
                            filter: e => ![3, 4, 6].includes(e.status),
                            highlightChanges: !1,
                            initialSorting: t.historyColumnsSorting,
                            isAlwaysActive: !0,
                            configFlags: s,
                            overlapManager: this._overlapManager,
                            getTableSettingsStorage: this._trading.getBrokerTradingSettingsStorage
                        }
                    }), n.customPages = t.pages.map(s => {
                        const i = s.tables.map(i => {
                            var r;
                            return {
                                id: `${e}.${s.id}.${i.id}`,
                                title: i.title || "",
                                columns: i.columns,
                                source: i.getData,
                                options: {
                                    className: "balances",
                                    idProperty: "id"
                                },
                                initialSorting: i.initialSorting,
                                formatters: t.customFormatters || [],
                                priceFormatterFn: this.priceFormatter.bind(this),
                                subscriptions: {
                                    fullUpdateDelegate: this._adapter.currentAccountUpdate,
                                    rowUpdateDelegate: i.changeDelegate
                                },
                                flags: i.flags,
                                rowEventsHandlers: (null === (r = i.flags) || void 0 === r ? void 0 : r.supportLinking) ? {
                                    onClick: this._linkTableRowSymbol
                                } : void 0
                            }
                        });
                        return {
                            ctor: Et,
                            ctorArguments: {
                                id: s.id,
                                title: s.title,
                                tables: i,
                                overlapManager: this._overlapManager,
                                getTableSettingsStorage: this._trading.getBrokerTradingSettingsStorage
                            }
                        }
                    }), i.notifications && (n.notificationsPage = {
                        ctor: Ot,
                        ctorArguments: {
                            id: "notifications_log",
                            title: (0, r.t)("Notifications log"),
                            source: () => Promise.resolve(this._trading.getNotifications()),
                            columns: Dt,
                            formatters: [],
                            priceFormatterFn: this.priceFormatter.bind(this),
                            subscriptions: {
                                fullUpdateDelegate: this._trading.onNotificationsChanged,
                                rowUpdateDelegate: this._trading.onNewNotification
                            },
                            overlapManager: this._overlapManager,
                            initialSorting: {
                                columnId: "time",
                                asc: !1
                            },
                            rowBadgeTypeInferrer: Ps,
                            getTableSettingsStorage: this._trading.getBrokerTradingSettingsStorage
                        }
                    }), n
                }
                _getPagesAvailabilityInfo() {
                    const e = this._adapter.metainfo().configFlags;
                    return {
                        positions: Boolean(e.supportPositions),
                        orders: !0,
                        history: Boolean(e.supportOrdersHistory),
                        notifications: Boolean(h.enabled("show_trading_notifications_history") && e.showNotificationsLog)
                    }
                }
                _renderTemplate() {
                    const e = this._getPagesAvailabilityInfo(),
                        t = Object.values(e).filter(e => e).length + this._adapter.accountManagerInfo().pages.length,
                        s = (0, l.ensureNotNull)((0, B.parseHtmlElement)(((e = 0) => `\n<div class="${Es.accountManager}">\n\t<div class="js-account-manager-header"></div>\n\t<div class="${Es.topPanel} js-top-panel">\n\t\t<div class="tv-tabs tv-tabs--semi-compact tv-tabs--no-margin tv-tabs--no-border js-top-panel-tabs">\n\t\t\t${'<div class="tv-tabs__tab js-tab"></div>'.repeat(e)}\n\t\t</div>\n\t</div>\n\t<div class="${Es.secondaryPanel} js-secondary-panel">\n\t\t<div class="js-secondary-tabs"></div>\n\t</div>\n\t<div class="${Es.content} js-content">\n\t\t${`<div class="${Es.page} js-page"></div>`.repeat(e)}\n\t</div>\n</div>`)(t)));
                    this._container.appendChild(s)
                }
                async _create() {
                    const e = await this._getPages();
                    for (const t of Object.values(e))
                        if (Array.isArray(t)) {
                            const e = t.map(e => new e.ctor(e.ctorArguments));
                            this._pages.push(...e)
                        } else this._pages.push(new t.ctor(t.ctorArguments));
                    const t = (0, l.ensureNotNull)(this._container.querySelector(".js-content"));
                    this._contentResizeObserver.observe(t), this._render();
                    const s = this._container.querySelectorAll(".js-page"),
                        i = this._container.querySelectorAll(".js-tab");
                    this._pages.forEach((e, t) => {
                        s[t].innerHTML = "", s[t].appendChild(e.content()), i[t].innerHTML = "", i[t].appendChild(e.header())
                    })
                }
                async _render() {
                    let e;
                    1 === this._mode && (e = await (0,
                        ys.makeAccountManagerHeaderDropdownsProps)(this._trading, this._summaryFieldsVisibilityManager, () => this._getDataExporters())), n.render(o.createElement(Cs, { ...e,
                        summaryFields: this._info.summary,
                        summaryFieldsVisibilityManager: this._summaryFieldsVisibilityManager
                    }), this._container.querySelector(".js-account-manager-header"))
                }
                _getDataExporters() {
                    const e = new Map;
                    for (const t of this._pages) {
                        const s = t.getExporters();
                        e.set(s.title, s)
                    }
                    return e
                }
                _subscribe() {
                    const e = e => {
                        e ? this._updatePagesActiveStatuses() : this._pages.forEach(e => e.setActive(!1))
                    };
                    this._bridge.visible.subscribe(e, {
                        callWithLast: !0
                    }), this._dispatchVisibilityHandler = () => this._bridge.visible.unsubscribe(e), this._attachFilter()
                }
                _onPageChanged(e) {
                    this._attachFilter(), this._hideSecondaryPanelIfEmpty(), this._trading.trackEvent("Bottom Panel", `Select ${this._pages[e].id()} page`), this._updatePagesActiveStatuses()
                }
                _hideSecondaryPanelIfEmpty() {
                    (0, l.ensureNotNull)(this._container.querySelector(".js-secondary-panel")).classList.toggle("js-hidden", null === this._currentPage().topline())
                }
                _updatePagesActiveStatuses() {
                    const e = 1 === this._adapter.connectionStatus(),
                        t = this._tabs.index();
                    void 0 !== this._contentHeight && this._pages[t].setHeight(this._contentHeight);
                    for (let s = 0; s < this._pages.length; s++) this._pages[s].setActive(t === s && e)
                }
                _detachFilter() {
                    const e = (0, l.ensureNotNull)(this._container.querySelector(".js-secondary-tabs")).children;
                    for (const t of Array.from(e)) t.classList.add("js-hidden")
                }
                _attachFilter() {
                    if (this._detachFilter(), this._topLines[this._currentPageIndex()]) this._topLines[this._currentPageIndex()].classList.remove("js-hidden");
                    else if (this._currentPage().topline()) {
                        const e = (0, l.ensureNotNull)(this._currentPage().topline());
                        (0, l.ensureNotNull)(this._container.querySelector(".js-secondary-tabs")).appendChild(e), this._topLines[this._currentPageIndex()] = e
                    }
                }
                _fullUpdate() {
                    this._pages.forEach(e => e.reset())
                }
                _unsubscribe() {
                    this._tabs && (this._tabs.tabChanged.unsubscribe(this, this._onPageChanged), this._tabs.stop()), this._contentResizeObserver.disconnect(), this._dispatchVisibilityHandler && (this._dispatchVisibilityHandler(), delete this._dispatchVisibilityHandler);
                    const e = this._container.querySelector(".js-secondary-tabs");
                    if (null !== e)
                        for (; e.firstChild;) e.removeChild(e.firstChild);
                    this._topLines = {}
                }
                _currentPageIndex() {
                    return this._tabs.index()
                }
                _currentPage() {
                    return this._pages[this._currentPageIndex()]
                }
                async _contextItems(e) {
                    const t = "Bottom Panel Context Menu",
                        s = this._currentPage().contextItems(e);
                    if (this._info && this._info.contextMenuActions) return this._info.contextMenuActions(e, s);
                    const i = {
                            separator: !0
                        },
                        o = 1 === this._mode,
                        n = [];
                    if (o) {
                        0 !== s.length && s.push(i);
                        const e = c.linking.proSymbol.value(),
                            r = await this._trading.makeNewOrderContextMenuAction(e, t);
                        n.push(r)
                    } else {
                        const o = this._currentPage().contextRow(e);
                        void 0 !== o && "symbol" in o && (0 !== s.length && s.push(i), n.push({
                            text: (0, r.t)("Open chart with {symbol}").replace("{symbol}", o.symbol),
                            icon: Ts,
                            action: () => {
                                this._trading.trackEvent(t, "Open chart"), c.linking.symbol.setValue(o.symbol), this._trading.tradingPanelPopup.hide()
                            }
                        }))
                    }
                    return h.enabled("buy_sell_buttons") && o && n.push(i, {
                        text: (0, r.t)("Show Buy/Sell Buttons"),
                        checkable: !0,
                        checked: this._trading.showSellBuyButtons.value(),
                        action: () => {
                            const e = !this._trading.showSellBuyButtons.value();
                            this._trading.trackEvent(t, "Show Sell/Buy Buttons", e ? "Check" : "Uncheck"), this._trading.showSellBuyButtons.setValue(e)
                        }
                    }), h.enabled("property_pages") && (s.length > 0 && n.push(i), n.push({
                        text: (0, U.appendEllipsis)((0, r.t)("Trading Settings")),
                        icon: xs,
                        action: () => {
                            this._trading.trackEvent(t, "Trading Properties"), this._trading.showTradingProperties()
                        }
                    })), s.concat(n)
                }
            }

            function Ps(e) {
                return "danger" === e.type ? V.Danger : "success" === e.type ? V.Success : void 0
            }
        },
        56656: (e, t, s) => {
            "use strict";
            s.r(t), s.d(t, {
                SummaryFieldsVisibilityManager: () => r
            });
            var i = s(47488);
            class r {
                constructor(e, t) {
                    var s;
                    this.toggleField = e => {
                        var t;
                        const s = this._fieldsVisibilityInfo$.getValue(),
                            i = new Map(s),
                            r = i.get(e);
                        void 0 !== r && (r.visible = !r.visible, this._fieldsVisibilityInfo$.next(i), null === (t = this._settingsGetter()) || void 0 === t || t.setSummaryFieldsVisibilityInfo(i))
                    }, this._settingsGetter = t;
                    const r = null === (s = this._settingsGetter()) || void 0 === s ? void 0 : s.summaryFieldsVisibilityInfo();
                    this._fieldsVisibilityInfo$ = new i.BehaviorSubject(new Map(e.map(({
                        text: e,
                        isDefault: t
                    }) => {
                        var s, i, o;
                        return [e, {
                            id: e,
                            visible: null === (o = null !== (i = null === (s = null == r ? void 0 : r.get(e)) || void 0 === s ? void 0 : s.visible) && void 0 !== i ? i : t) || void 0 === o || o
                        }]
                    }))), this.fieldsVisibilityInfo$ = this._fieldsVisibilityInfo$.asObservable()
                }
                fieldsVisibilityInfo() {
                    return this._fieldsVisibilityInfo$.getValue()
                }
            }
        },
        51763: (e, t, s) => {
            "use strict";
            var i;
            s.d(t, {
                    TradedItemType: () => i
                }),
                function(e) {
                    e[e.Position = 0] = "Position", e[e.Order = 1] = "Order"
                }(i || (i = {}))
        },
        12334: (e, t, s) => {
            "use strict";
            s.d(t, {
                TradingLayoutBreakpoint: () => r
            });
            var i = s(82515);
            const r = {
                Mobile: i.mobile
            }
        },
        47152: (e, t, s) => {
            "use strict";

            function i(e) {
                let t = null;
                return (s, ...i) => (null == t || t.abort(), t = new AbortController, null == s || s.addEventListener("error", () => null == t ? void 0 : t.abort(), {
                    once: !0
                }), e(t.signal, ...i))
            }

            function r(e) {
                if (!l(e)) throw e
            }

            function o(e) {
                if (l(e)) throw e
            }

            function n(e) {
                return (null == e ? void 0 : e.aborted) ? Promise.reject(a()) : new Promise((t, s) => {
                    null == e || e.addEventListener("abort", () => s(a()), {
                        once: !0
                    })
                })
            }

            function a() {
                return new DOMException("Aborted", "AbortError")
            }

            function l(e) {
                return e instanceof Error && "AbortError" === e.name
            }

            function c(e, t) {
                return Promise.race([n(e), t])
            }
            async function d(e, t) {
                let s;
                try {
                    await c(e, new Promise(e => {
                        s = setTimeout(e, t)
                    }))
                } finally {
                    clearTimeout(s)
                }
            }
            s.d(t, {
                respectLatest: () => i,
                skipAbortError: () => r,
                rethrowAbortError: () => o,
                isAbortError: () => l,
                respectAbort: () => c,
                delay: () => d
            })
        },
        99357: (e, t, s) => {
            "use strict";
            s.d(t, {
                LogoSize: () => n,
                getLogoUrlResolver: () => c
            });
            var i = s(88537);
            (0, s(51951).getLogger)("Common.InitData");
            const r = window.initData || {};

            function o() {
                return r
            }
            var n;
            ! function(e) {
                e[e.Medium = 0] = "Medium", e[e.Large = 1] = "Large"
            }(n || (n = {}));
            class a {
                constructor(e) {
                    (0, i.assert)("" !== e, "S3 base url must be a non-empty string"), this._baseUrl = e
                }
                getSymbolLogoUrl(e, t) {
                    switch ((0, i.assert)("" !== e, "logo id must be a non-empty string"), t) {
                        case n.Medium:
                            return this._baseUrl + (e + ".svg");
                        case n.Large:
                            return this._baseUrl + (e + "--big.svg")
                    }
                }
                getCountryFlagUrl(e, t) {
                    return this.getSymbolLogoUrl("country/" + e, t)
                }
                getCryptoLogoUrl(e, t) {
                    return this.getSymbolLogoUrl("crypto/" + e, t)
                }
                getProviderLogoUrl(e, t) {
                    return this.getSymbolLogoUrl("provider/" + e, t)
                }
            }
            let l;

            function c() {
                if (!l) {
                    const e = o(),
                        t = e.settings ? e.settings.S3_LOGO_SERVICE_BASE_URL : "";
                    l = new a(t)
                }
                return l
            }
        },
        52275: (e, t, s) => {
            "use strict";
            s.d(t, {
                saveTextFile: () => r,
                escapeCSVValue: () => l
            });
            var i = s(1227);

            function r(e, t, s = "text/plain") {
                const r = new Blob([t], {
                    type: s
                });
                if (i.CheckMobile.iOS()) {
                    const t = new FileReader;
                    return t.onload = () => {
                        t.result && o(e, t.result.toString())
                    }, void t.readAsDataURL(r)
                }
                const n = window.URL.createObjectURL(r);
                navigator.msSaveOrOpenBlob ? navigator.msSaveOrOpenBlob(r, e) : window.navigator.msSaveBlob ? window.navigator.msSaveBlob(r, e) : (o(e, n), window.URL.revokeObjectURL(n))
            }

            function o(e, t) {
                const s = document.createElement("a");
                s.style.display = "none", document.body.appendChild(s), s.href = t, s.download = e, s.click(), document.body.removeChild(s)
            }
            const n = /[",\r\n]/,
                a = /"/g;

            function l(e) {
                return n.test(e) ? `"${e.replace(a,'""')}"` : e
            }
        },
        63694: (e, t, s) => {
            "use strict";
            s.d(t, {
                DrawerManager: () => r,
                DrawerContext: () => o
            });
            var i = s(59496);
            class r extends i.PureComponent {
                constructor(e) {
                    super(e), this._addDrawer = () => {
                        const e = this.state.currentDrawer + 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this._removeDrawer = () => {
                        const e = this.state.currentDrawer - 1;
                        return this.setState({
                            currentDrawer: e
                        }), e
                    }, this.state = {
                        currentDrawer: 0
                    }
                }
                render() {
                    return i.createElement(o.Provider, {
                        value: {
                            addDrawer: this._addDrawer,
                            removeDrawer: this._removeDrawer,
                            currentDrawer: this.state.currentDrawer
                        }
                    }, this.props.children)
                }
            }
            const o = i.createContext(null)
        },
        59339: (e, t, s) => {
            "use strict";
            s.d(t, {
                Drawer: () => p
            });
            var i = s(59496),
                r = s(88537),
                o = s(97754),
                n = s(59142),
                a = s(85089),
                l = s(8361),
                c = s(63694),
                d = s(1227),
                h = s(28466),
                u = s(66998);

            function p(e) {
                const {
                    position: t = "Bottom",
                    onClose: s,
                    children: p,
                    className: _,
                    theme: m = u
                } = e, g = (0, r.ensureNotNull)((0, i.useContext)(c.DrawerContext)), [b, v] = (0, i.useState)(0), f = (0, i.useRef)(null), w = (0, i.useContext)(h.CloseDelegateContext);
                return (0, i.useEffect)(() => {
                    const e = (0, r.ensureNotNull)(f.current);
                    return e.focus({
                        preventScroll: !0
                    }), w.subscribe(g, s), 0 === g.currentDrawer && (0, a.setFixedBodyState)(!0), d.CheckMobile.iOS() && (0, n.disableBodyScroll)(e), v(g.addDrawer()), () => {
                        w.unsubscribe(g, s);
                        const t = g.removeDrawer();
                        d.CheckMobile.iOS() && (0, n.enableBodyScroll)(e), 0 === t && (0, a.setFixedBodyState)(!1)
                    }
                }, []), i.createElement(l.Portal, null, i.createElement("div", {
                    className: o(u.wrap, u["position" + t])
                }, b === g.currentDrawer && i.createElement("div", {
                    className: u.backdrop,
                    onClick: s
                }), i.createElement("div", {
                    className: o(u.drawer, m.drawer, u["position" + t], _),
                    ref: f,
                    tabIndex: -1,
                    "data-name": e["data-name"]
                }, p)))
            }
        },
        61851: (e, t, s) => {
            "use strict";
            s.d(t, {
                useObservable: () => r
            });
            var i = s(59496);

            function r(e, t) {
                const [s, r] = (0, i.useState)(t);
                return (0, i.useEffect)(() => {
                    const t = e.subscribe(r);
                    return () => t.unsubscribe()
                }, [e]), s
            }
        },
        97265: (e, t, s) => {
            "use strict";
            s.d(t, {
                useWatchedValueReadonly: () => r
            });
            var i = s(59496);
            const r = (e, t = !1) => {
                const s = "watchedValue" in e ? e.watchedValue : void 0,
                    r = "defaultValue" in e ? e.defaultValue : e.watchedValue.value(),
                    [o, n] = (0, i.useState)(s ? s.value() : r);
                return (t ? i.useLayoutEffect : i.useEffect)(() => {
                    if (s) {
                        n(s.value());
                        const e = e => n(e);
                        return s.subscribe(e), () => s.unsubscribe(e)
                    }
                    return () => {}
                }, [s]), o
            }
        },
        79266: (e, t, s) => {
            "use strict";
            s.d(t, {
                PopupMenuItemToggle: () => l
            });
            var i = s(59496),
                r = s(97754),
                o = s(92063),
                n = s(2946),
                a = s(91998);

            function l(e) {
                const {
                    isDisabled: t,
                    hint: s,
                    label: l,
                    isChecked: c,
                    checkboxClassName: d,
                    labelClassName: h,
                    indeterminate: u,
                    ...p
                } = e;
                return i.createElement(o.PopupMenuItem, { ...p,
                    isDisabled: t,
                    shortcut: s,
                    dontClosePopup: !0,
                    labelRowClassName: h,
                    label: i.createElement(n.Checkbox, {
                        disabled: t,
                        label: l,
                        checked: c,
                        indeterminate: u,
                        className: r(a.checkbox, d)
                    })
                })
            }
        },
        92063: (e, t, s) => {
            "use strict";
            s.d(t, {
                DEFAULT_POPUP_MENU_ITEM_THEME: () => c,
                PopupMenuItem: () => u
            });
            var i = s(59496),
                r = s(97754),
                o = s(70981),
                n = s(32133),
                a = s(417),
                l = s(23576);
            const c = l;

            function d(e) {
                const {
                    reference: t,
                    ...s
                } = e, r = { ...s,
                    ref: t
                };
                return i.createElement(e.href ? "a" : "div", r)
            }

            function h(e) {
                e.stopPropagation()
            }

            function u(e) {
                const {
                    id: t,
                    role: s,
                    "aria-selected": c,
                    className: u,
                    title: p,
                    labelRowClassName: _,
                    labelClassName: m,
                    shortcut: g,
                    forceShowShortcuts: b,
                    icon: v,
                    isActive: f,
                    isDisabled: w,
                    isHovered: C,
                    appearAsDisabled: y,
                    label: S,
                    link: T,
                    showToolboxOnHover: x,
                    target: E,
                    rel: D,
                    toolbox: F,
                    reference: M,
                    onMouseOut: P,
                    onMouseOver: A,
                    suppressToolboxClick: k = !0,
                    theme: O = l
                } = e, R = (0, a.filterDataProps)(e), I = (0, i.useRef)(null);
                return i.createElement(d, { ...R,
                    id: t,
                    role: s,
                    "aria-selected": c,
                    className: r(u, O.item, v && O.withIcon, {
                        [O.isActive]: f,
                        [O.isDisabled]: w || y,
                        [O.hovered]: C
                    }),
                    title: p,
                    href: T,
                    target: E,
                    rel: D,
                    reference: function(e) {
                        I.current = e, "function" == typeof M && M(e);
                        "object" == typeof M && (M.current = e)
                    },
                    onClick: function(t) {
                        const {
                            dontClosePopup: s,
                            onClick: i,
                            onClickArg: r,
                            trackEventObject: a
                        } = e;
                        if (w) return;
                        a && (0, n.trackEvent)(a.category, a.event, a.label);
                        i && i(r, t);
                        s || (0, o.globalCloseMenu)()
                    },
                    onContextMenu: function(t) {
                        const {
                            trackEventObject: s,
                            trackRightClick: i
                        } = e;
                        s && i && (0, n.trackEvent)(s.category, s.event, s.label + "_rightClick")
                    },
                    onMouseUp: function(t) {
                        const {
                            trackEventObject: s,
                            trackMouseWheelClick: i
                        } = e;
                        if (1 === t.button && T && s) {
                            let e = s.label;
                            i && (e += "_mouseWheelClick"), (0, n.trackEvent)(s.category, s.event, e)
                        }
                    },
                    onMouseOver: A,
                    onMouseOut: P
                }, void 0 !== v && i.createElement("div", {
                    className: O.icon,
                    dangerouslySetInnerHTML: {
                        __html: v
                    }
                }), i.createElement("div", {
                    className: r(O.labelRow, _)
                }, i.createElement("div", {
                    className: r(O.label, m)
                }, S)), (void 0 !== g || b) && i.createElement("div", {
                    className: O.shortcut
                }, (N = g) && N.split("+").join(" + ")), void 0 !== F && i.createElement("div", {
                    onClick: k ? h : void 0,
                    className: r(O.toolbox, {
                        [O.showOnHover]: x
                    })
                }, F));
                var N
            }
        },
        44114: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M13.5 7l1.65-1.65a.5.5 0 0 0 0-.7l-1.8-1.8a.5.5 0 0 0-.7 0L11 4.5M13.5 7L11 4.5M13.5 7l-8.35 8.35a.5.5 0 0 1-.36.15H2.5v-2.3a.5.5 0 0 1 .15-.35L11 4.5"/></svg>'
        },
        62106: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M8 5.5h12A2.5 2.5 0 0 1 22.5 8v12a2.5 2.5 0 0 1-2.5 2.5H8A2.5 2.5 0 0 1 5.5 20V8A2.5 2.5 0 0 1 8 5.5zM4 8a4 4 0 0 1 4-4h12a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V8zm15.49 5.07a.75.75 0 1 0-.98-1.14l-2.97 2.55-2.51-2.51a.75.75 0 0 0-1.02-.04l-3.5 3a.75.75 0 1 0 .98 1.14l2.97-2.55 2.51 2.51c.28.28.72.3 1.02.04l3.5-3z"/></svg>'
        },
        57369: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 11 9" width="11" height="9" fill="none"><path stroke-width="2" d="M0.999878 4L3.99988 7L9.99988 1"/></svg>'
        },
        72351: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"><path fill="currentColor" d="M9.707 9l4.647-4.646-.707-.708L9 8.293 4.354 3.646l-.708.708L8.293 9l-4.647 4.646.708.708L9 9.707l4.646 4.647.708-.707L9.707 9z"/></svg>'
        },
        6467: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 9 9" width="9" height="9"><path fill="currentColor" d="M9 4.5A4.5 4.5 0 0 1 4.5 9 4.5 4.5 0 0 1 0 4.5 4.5 4.5 0 0 1 4.5 0 4.5 4.5 0 0 1 9 4.5z"/><path fill="#fff" d="M4.768 1.527c.131 0 .243.047.334.141a.444.444 0 0 1 .141.33.461.461 0 0 1-.14.339.455.455 0 0 1-.335.137.468.468 0 0 1-.471-.475c0-.132.045-.244.137-.335a.455.455 0 0 1 .334-.137zm-.42 5.946v-3.67h-.591V3.16h1.357v4.314z"/></svg>'
        },
        94511: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14" width="14" height="14"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="2" d="M8.5 1.5L3.5 7l5 5.5"/></svg>'
        },
        25914: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14 14" width="14" height="14"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="2" d="M5.5 1.5l5 5.5-5 5.5"/></svg>'
        },
        56620: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 6 26" width="3" height="13" fill="currentColor"><circle cx="3" cy="3" r="3"/><circle cx="3" cy="13" r="3"/><circle cx="3" cy="23" r="3"/></svg>'
        }
    }
]);
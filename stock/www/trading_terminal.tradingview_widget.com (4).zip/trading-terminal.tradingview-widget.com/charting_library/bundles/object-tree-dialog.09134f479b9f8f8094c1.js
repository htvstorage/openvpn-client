(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [4862], {
        96746: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        67179: e => {
            e.exports = {
                dialog: "dialog-HExheUfY",
                wrapper: "wrapper-HExheUfY",
                separator: "separator-HExheUfY"
            }
        },
        89185: e => {
            e.exports = {
                itemRow: "itemRow-9Sl1Rwzy",
                favoriteButton: "favoriteButton-9Sl1Rwzy",
                active: "active-9Sl1Rwzy",
                selected: "selected-9Sl1Rwzy",
                mobile: "mobile-9Sl1Rwzy",
                itemInfo: "itemInfo-9Sl1Rwzy",
                title: "title-9Sl1Rwzy",
                details: "details-9Sl1Rwzy",
                itemInfoWithPadding: "itemInfoWithPadding-9Sl1Rwzy",
                favorite: "favorite-9Sl1Rwzy",
                removeButton: "removeButton-9Sl1Rwzy"
            }
        },
        91441: e => {
            e.exports = {
                "small-height-breakpoint": "screen and (max-height: 360px)",
                container: "container-tuOy5zvD",
                unsetAlign: "unsetAlign-tuOy5zvD",
                title: "title-tuOy5zvD",
                subtitle: "subtitle-tuOy5zvD",
                ellipsis: "ellipsis-tuOy5zvD",
                close: "close-tuOy5zvD"
            }
        },
        9267: e => {
            e.exports = {
                title: "title-f0amBBvb",
                empty: "empty-f0amBBvb",
                image: "image-f0amBBvb",
                spinner: "spinner-f0amBBvb",
                contentList: "contentList-f0amBBvb"
            }
        },
        32713: e => {
            e.exports = {
                dialog: "dialog-W0U3ul53",
                button: "button-W0U3ul53"
            }
        },
        16842: e => {
            e.exports = {
                favorite: "favorite-JVQQsDQk",
                disabled: "disabled-JVQQsDQk",
                active: "active-JVQQsDQk",
                checked: "checked-JVQQsDQk"
            }
        },
        91626: e => {
            e.exports = {
                separator: "separator-jtAq6E4V"
            }
        },
        73432: e => {
            e.exports = {
                button: "button-SD4Dbbwd",
                disabled: "disabled-SD4Dbbwd",
                active: "active-SD4Dbbwd",
                hidden: "hidden-SD4Dbbwd"
            }
        },
        72571: (e, t, n) => {
            "use strict";
            n.d(t, {
                Icon: () => o
            });
            var r = n(59496);
            const o = r.forwardRef((e, t) => {
                const {
                    icon: n = "",
                    ...o
                } = e;
                return r.createElement("span", { ...o,
                    ref: t,
                    dangerouslySetInnerHTML: {
                        __html: n
                    }
                })
            })
        },
        58884: (e, t, n) => {
            "use strict";
            async function r(e, t, n) {
                let r;
                for (let o = 0; o < t; ++o) try {
                    return await e(r)
                } catch (e) {
                    r = e, await n(o)
                }
                throw r
            }
            async function o(e, t) {
                return r(e, t, () => Promise.resolve())
            }
            n.d(t, {
                getAllSourcesIcons: () => d,
                loadAllSourcesIcons: () => c
            });
            const i = (0, n(51951).getLogger)("DataSourcesIcons");
            let s = null;

            function a() {
                const e = n.c[26872];
                return e ? Promise.resolve(e.exports.lineToolsIcons) : n.e(1890).then(n.bind(n, 26872)).then(e => e.lineToolsIcons)
            }

            function l() {
                const e = n.c[93790];
                return e ? Promise.resolve(e.exports.SERIES_ICONS) : n.e(3718).then(n.bind(n, 93790)).then(e => e.SERIES_ICONS)
            }
            let u = null;

            function c() {
                return null === u && (u = function() {
                    const e = o(a, 2).then(e => e).catch(e => (i.logWarn(e), {})),
                        t = o(l, 2).then(e => e).catch(e => (i.logWarn(e), {}));
                    return Promise.all([e, t])
                }()), u.then(e => (s = {
                    linetool: e[0],
                    series: e[1]
                }, s))
            }

            function d() {
                return s
            }
        },
        7270: function(e, t, n) {
            var r, o, i;
            e.exports = (r = n(59496), o = n(87995), i = n(59255), function(e) {
                function t(r) {
                    if (n[r]) return n[r].exports;
                    var o = n[r] = {
                        exports: {},
                        id: r,
                        loaded: !1
                    };
                    return e[r].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports
                }
                var n = {};
                return t.m = e, t.c = n, t.p = "dist/", t(0)
            }([function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(1));
                t.default = r.default, e.exports = t.default
            }, function(e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var o = function() {
                        function e(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                            }
                        }
                        return function(t, n, r) {
                            return n && e(t.prototype, n), r && e(t, r), t
                        }
                    }(),
                    i = n(2),
                    s = (r(i), n(3)),
                    a = r(s),
                    l = r(n(13)),
                    u = r(n(14)),
                    c = r(n(15)),
                    d = function(e) {
                        function t(e) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, t);
                            var n = function(e, t) {
                                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !t || "object" != typeof t && "function" != typeof t ? e : t
                            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                            return n.measure = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.props.includeMargin;
                                if (n.props.shouldMeasure) {
                                    n._node.parentNode || n._setDOMNode();
                                    var t = n.getDimensions(n._node, e),
                                        r = "function" == typeof n.props.children;
                                    n._propsToMeasure.some((function(e) {
                                        if (t[e] !== n._lastDimensions[e]) return n.props.onMeasure(t), r && void 0 !== n && n.setState({
                                            dimensions: t
                                        }), n._lastDimensions = t, !0
                                    }))
                                }
                            }, n.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, n._node = null, n._propsToMeasure = n._getPropsToMeasure(e), n._lastDimensions = {}, n
                        }
                        return function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                        }(t, e), o(t, [{
                            key: "componentDidMount",
                            value: function() {
                                var e = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new u.default((function() {
                                    return e.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(e) {
                                var t = (e.config, e.whitelist),
                                    n = e.blacklist;
                                this.props.whitelist === t && this.props.blacklist === n || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: t,
                                    blacklist: n
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = l.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, c.default)(e, {
                                    margin: t
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(e) {
                                var t = e.whitelist,
                                    n = e.blacklist;
                                return t.filter((function(e) {
                                    return n.indexOf(e) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.props.children;
                                return i.Children.only("function" == typeof e ? e(this.state.dimensions) : e)
                            }
                        }]), t
                    }(i.Component);
                d.propTypes = {
                    whitelist: a.default.array,
                    blacklist: a.default.array,
                    includeMargin: a.default.bool,
                    useClone: a.default.bool,
                    cloneOptions: a.default.object,
                    shouldMeasure: a.default.bool,
                    onMeasure: a.default.func
                }, d.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, t.default = d, e.exports = t.default
            }, function(e, t) {
                e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) {
                        var o = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        e.exports = n(5)((function(e) {
                            return "object" === (void 0 === e ? "undefined" : r(e)) && null !== e && e.$$typeof === o
                        }), !0)
                    } else e.exports = n(12)()
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n() {
                    throw new Error("setTimeout has not been defined")
                }

                function r() {
                    throw new Error("clearTimeout has not been defined")
                }

                function o(e) {
                    if (u === setTimeout) return setTimeout(e, 0);
                    if ((u === n || !u) && setTimeout) return u = setTimeout, setTimeout(e, 0);
                    try {
                        return u(e, 0)
                    } catch (t) {
                        try {
                            return u.call(null, e, 0)
                        } catch (t) {
                            return u.call(this, e, 0)
                        }
                    }
                }

                function i() {
                    f && p && (f = !1, p.length ? h = p.concat(h) : m = -1, h.length && s())
                }

                function s() {
                    if (!f) {
                        var e = o(i);
                        f = !0;
                        for (var t = h.length; t;) {
                            for (p = h, h = []; ++m < t;) p && p[m].run();
                            m = -1, t = h.length
                        }
                        p = null, f = !1,
                            function(e) {
                                if (c === clearTimeout) return clearTimeout(e);
                                if ((c === r || !c) && clearTimeout) return c = clearTimeout, clearTimeout(e);
                                try {
                                    c(e)
                                } catch (t) {
                                    try {
                                        return c.call(null, e)
                                    } catch (t) {
                                        return c.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function a(e, t) {
                    this.fun = e, this.array = t
                }

                function l() {}
                var u, c, d = e.exports = {};
                ! function() {
                    try {
                        u = "function" == typeof setTimeout ? setTimeout : n
                    } catch (e) {
                        u = n
                    }
                    try {
                        c = "function" == typeof clearTimeout ? clearTimeout : r
                    } catch (e) {
                        c = r
                    }
                }();
                var p, h = [],
                    f = !1,
                    m = -1;
                d.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    h.push(new a(e, t)), 1 !== h.length || f || o(s)
                }, a.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, d.title = "browser", d.browser = !0, d.env = {}, d.argv = [], d.version = "", d.versions = {}, d.on = l, d.addListener = l, d.once = l, d.off = l, d.removeListener = l, d.removeAllListeners = l, d.emit = l, d.prependListener = l, d.prependOnceListener = l, d.listeners = function(e) {
                    return []
                }, d.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, d.cwd = function() {
                    return "/"
                }, d.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, d.umask = function() {
                    return 0
                }
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        },
                        o = n(6),
                        i = n(7),
                        s = n(8),
                        a = n(9),
                        l = n(10),
                        u = n(11);
                    e.exports = function(e, n) {
                        function c(e, t) {
                            return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
                        }

                        function d(e) {
                            this.message = e, this.stack = ""
                        }

                        function p(e) {
                            function r(r, u, c, p, h, f, m) {
                                if (p = p || w, f = f || c,
                                    m !== l)
                                    if (n) i(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== t.env.NODE_ENV && "undefined" != typeof console) {
                                    var v = p + ":" + c;
                                    !o[v] && a < 3 && (s(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", f, p), o[v] = !0, a++)
                                }
                                return null == u[c] ? r ? new d(null === u[c] ? "The " + h + " `" + f + "` is marked as required in `" + p + "`, but its value is `null`." : "The " + h + " `" + f + "` is marked as required in `" + p + "`, but its value is `undefined`.") : null : e(u, c, p, h, f)
                            }
                            if ("production" !== t.env.NODE_ENV) var o = {},
                                a = 0;
                            var u = r.bind(null, !1);
                            return u.isRequired = r.bind(null, !0), u
                        }

                        function h(e) {
                            return p((function(t, n, r, o, i, s) {
                                var a = t[n];
                                return m(a) !== e ? new d("Invalid " + o + " `" + i + "` of type `" + v(a) + "` supplied to `" + r + "`, expected `" + e + "`.") : null
                            }))
                        }

                        function f(t) {
                            switch (void 0 === t ? "undefined" : r(t)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !t;
                                case "object":
                                    if (Array.isArray(t)) return t.every(f);
                                    if (null === t || e(t)) return !0;
                                    var n = function(e) {
                                        var t = e && (y && e[y] || e[b]);
                                        if ("function" == typeof t) return t
                                    }(t);
                                    if (!n) return !1;
                                    var o, i = n.call(t);
                                    if (n !== t.entries) {
                                        for (; !(o = i.next()).done;)
                                            if (!f(o.value)) return !1
                                    } else
                                        for (; !(o = i.next()).done;) {
                                            var s = o.value;
                                            if (s && !f(s[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function m(e) {
                            var t = void 0 === e ? "undefined" : r(e);
                            return Array.isArray(e) ? "array" : e instanceof RegExp ? "object" : function(e, t) {
                                return "symbol" === e || "Symbol" === t["@@toStringTag"] || "function" == typeof Symbol && t instanceof Symbol
                            }(t, e) ? "symbol" : t
                        }

                        function v(e) {
                            if (null == e) return "" + e;
                            var t = m(e);
                            if ("object" === t) {
                                if (e instanceof Date) return "date";
                                if (e instanceof RegExp) return "regexp"
                            }
                            return t
                        }

                        function g(e) {
                            var t = v(e);
                            switch (t) {
                                case "array":
                                case "object":
                                    return "an " + t;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + t;
                                default:
                                    return t
                            }
                        }
                        var y = "function" == typeof Symbol && Symbol.iterator,
                            b = "@@iterator",
                            w = "<<anonymous>>",
                            _ = {
                                array: h("array"),
                                bool: h("boolean"),
                                func: h("function"),
                                number: h("number"),
                                object: h("object"),
                                string: h("string"),
                                symbol: h("symbol"),
                                any: p(o.thatReturnsNull),
                                arrayOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new d("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside arrayOf.");
                                        var s = t[n];
                                        if (!Array.isArray(s)) return new d("Invalid " + o + " `" + i + "` of type `" + m(s) + "` supplied to `" + r + "`, expected an array.");
                                        for (var a = 0; a < s.length; a++) {
                                            var u = e(s, a, r, o, i + "[" + a + "]", l);
                                            if (u instanceof Error) return u
                                        }
                                        return null
                                    }))
                                },
                                element: p((function(t, n, r, o, i) {
                                    var s = t[n];
                                    return e(s) ? null : new d("Invalid " + o + " `" + i + "` of type `" + m(s) + "` supplied to `" + r + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if (!(t[n] instanceof e)) {
                                            var s = e.name || w;
                                            return new d("Invalid " + o + " `" + i + "` of type `" + function(e) {
                                                return e.constructor && e.constructor.name ? e.constructor.name : w
                                            }(t[n]) + "` supplied to `" + r + "`, expected instance of `" + s + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: p((function(e, t, n, r, o) {
                                    return f(e[t]) ? null : new d("Invalid " + r + " `" + o + "` supplied to `" + n + "`, expected a ReactNode.")
                                })),
                                objectOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new d("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside objectOf.");
                                        var s = t[n],
                                            a = m(s);
                                        if ("object" !== a) return new d("Invalid " + o + " `" + i + "` of type `" + a + "` supplied to `" + r + "`, expected an object.");
                                        for (var u in s)
                                            if (s.hasOwnProperty(u)) {
                                                var c = e(s, u, r, o, i + "." + u, l);
                                                if (c instanceof Error) return c
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(e) {
                                    return Array.isArray(e) ? p((function(t, n, r, o, i) {
                                        for (var s = t[n], a = 0; a < e.length; a++)
                                            if (c(s, e[a])) return null;
                                        return new d("Invalid " + o + " `" + i + "` of value `" + s + "` supplied to `" + r + "`, expected one of " + JSON.stringify(e) + ".")
                                    })) : ("production" !== t.env.NODE_ENV && s(!1, "Invalid argument supplied to oneOf, expected an instance of array."), o.thatReturnsNull)
                                },
                                oneOfType: function(e) {
                                    if (!Array.isArray(e)) return "production" !== t.env.NODE_ENV && s(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), o.thatReturnsNull;
                                    for (var n = 0; n < e.length; n++) {
                                        var r = e[n];
                                        if ("function" != typeof r) return s(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", g(r), n), o.thatReturnsNull
                                    }
                                    return p((function(t, n, r, o, i) {
                                        for (var s = 0; s < e.length; s++)
                                            if (null == (0, e[s])(t, n, r, o, i, l)) return null;
                                        return new d("Invalid " + o + " `" + i + "` supplied to `" + r + "`.")
                                    }))
                                },
                                shape: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var s = t[n],
                                            a = m(s);
                                        if ("object" !== a) return new d("Invalid " + o + " `" + i + "` of type `" + a + "` supplied to `" + r + "`, expected `object`.");
                                        for (var u in e) {
                                            var c = e[u];
                                            if (c) {
                                                var p = c(s, u, r, o, i + "." + u, l);
                                                if (p) return p
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var s = t[n],
                                            u = m(s);
                                        if ("object" !== u) return new d("Invalid " + o + " `" + i + "` of type `" + u + "` supplied to `" + r + "`, expected `object`.");
                                        var c = a({}, t[n], e);
                                        for (var p in c) {
                                            var h = e[p];
                                            if (!h) return new d("Invalid " + o + " `" + i + "` key `" + p + "` supplied to `" + r + "`.\nBad object: " + JSON.stringify(t[n], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(e), null, "  "));
                                            var f = h(s, p, r, o, i + "." + p, l);
                                            if (f) return f
                                        }
                                        return null
                                    }))
                                }
                            };
                        return d.prototype = Error.prototype, _.checkPropTypes = u, _.PropTypes = _, _
                    }
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    return function() {
                        return e
                    }
                }
                var r = function() {};
                r.thatReturns = n, r.thatReturnsFalse = n(!1), r.thatReturnsTrue = n(!0), r.thatReturnsNull = n(null), r.thatReturnsThis = function() {
                    return this
                }, r.thatReturnsArgument = function(e) {
                    return e
                }, e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var n = function(e) {};
                    "production" !== t.env.NODE_ENV && (n = function(e) {
                        if (void 0 === e) throw new Error("invariant requires an error message argument")
                    }), e.exports = function(e, t, r, o, i, s, a, l) {
                        if (n(t), !e) {
                            var u;
                            if (void 0 === t) u = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var c = [r, o, i, s, a, l],
                                    d = 0;
                                (u = new Error(t.replace(/%s/g, (function() {
                                    return c[d++]
                                })))).name = "Invariant Violation"
                            }
                            throw u.framesToPop = 1, u
                        }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = n(6);
                    if ("production" !== t.env.NODE_ENV) {
                        var o = function(e) {
                            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            var o = 0,
                                i = "Warning: " + e.replace(/%s/g, (function() {
                                    return n[o++]
                                }));
                            "undefined" != typeof console && console.error(i);
                            try {
                                throw new Error(i)
                            } catch (e) {}
                        };
                        r = function(e, t) {
                            if (void 0 === t) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== t.indexOf("Failed Composite propType: ") && !e) {
                                for (var n = arguments.length, r = Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                                o.apply(void 0, [t].concat(r))
                            }
                        }
                    }
                    e.exports = r
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }
                var r = Object.getOwnPropertySymbols,
                    o = Object.prototype.hasOwnProperty,
                    i = Object.prototype.propertyIsEnumerable;
                e.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var e = new String("abc");
                        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
                        if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                                return t[e]
                            })).join("")) return !1;
                        var r = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                            r[e] = e
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
                    } catch (e) {
                        return !1
                    }
                }() ? Object.assign : function(e, t) {
                    for (var s, a, l = n(e), u = 1; u < arguments.length; u++) {
                        for (var c in s = Object(arguments[u])) o.call(s, c) && (l[c] = s[c]);
                        if (r) {
                            a = r(s);
                            for (var d = 0; d < a.length; d++) i.call(s, a[d]) && (l[a[d]] = s[a[d]])
                        }
                    }
                    return l
                }
            }, function(e, t) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) var o = n(7),
                        i = n(8),
                        s = n(10),
                        a = {};
                    e.exports = function(e, n, l, u, c) {
                        if ("production" !== t.env.NODE_ENV)
                            for (var d in e)
                                if (e.hasOwnProperty(d)) {
                                    var p;
                                    try {
                                        o("function" == typeof e[d], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", u || "React class", l, d, r(e[d])), p = e[d](n, d, u, l, null, s)
                                    } catch (e) {
                                        p = e
                                    }
                                    if (i(!p || p instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", u || "React class", l, d, void 0 === p ? "undefined" : r(p)), p instanceof Error && !(p.message in a)) {
                                        a[p.message] = !0;
                                        var h = c ? c() : "";
                                        i(!1, "Failed %s type: %s%s", l, p.message, null != h ? h : "")
                                    }
                                }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                "use strict";
                var r = n(6),
                    o = n(7),
                    i = n(10);
                e.exports = function() {
                    function e(e, t, n, r, s, a) {
                        a !== i && o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function t() {
                        return e
                    }
                    e.isRequired = e;
                    var n = {
                        array: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: t,
                        element: e,
                        instanceOf: t,
                        node: e,
                        objectOf: t,
                        oneOf: t,
                        oneOfType: t,
                        shape: t,
                        exact: t
                    };
                    return n.checkPropTypes = r, n.PropTypes = n, n
                }
            }, function(e, t) {
                e.exports = o
            }, function(e, t) {
                e.exports = i
            }, function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = e.getBoundingClientRect(),
                        o = void 0,
                        i = void 0,
                        s = void 0;
                    return t.margin && (s = (0, r.default)(getComputedStyle(e))), t.margin ? (o = s.left + n.width + s.right, i = s.top + n.height + s.bottom) : (o = n.width, i = n.height), {
                        width: o,
                        height: i,
                        top: n.top,
                        right: n.right,
                        bottom: n.bottom,
                        left: n.left
                    }
                };
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(16));
                e.exports = t.default
            }, function(e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    return {
                        top: n((e = e || {}).marginTop),
                        right: n(e.marginRight),
                        bottom: n(e.marginBottom),
                        left: n(e.marginLeft)
                    }
                };
                var n = function(e) {
                    return parseInt(e) || 0
                };
                e.exports = t.default
            }]))
        },
        33054: (e, t, n) => {
            "use strict";
            n.d(t, {
                mediaQueryAddEventListener: () => r,
                mediaQueryRemoveEventListener: () => o
            });
            const r = (e, t) => {
                    (null == e ? void 0 : e.addEventListener) ? e.addEventListener("change", t): e.addListener(t)
                },
                o = (e, t) => {
                    (null == e ? void 0 : e.removeEventListener) ? e.removeEventListener("change", t): e.removeListener(t)
                }
        },
        96038: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogBreakpoints: () => o
            });
            var r = n(96746);
            const o = {
                SmallHeight: r["small-height-breakpoint"],
                TabletSmall: r["tablet-small-breakpoint"],
                TabletNormal: r["tablet-normal-breakpoint"]
            }
        },
        53337: (e, t, n) => {
            "use strict";
            n.d(t, {
                AdaptivePopupDialog: () => O
            });
            var r = n(59496),
                o = n(88537),
                i = n(33054),
                s = n(97754),
                a = n.n(s),
                l = n(80185),
                u = n(98043),
                c = n(40766),
                d = n(94707),
                p = n(96038),
                h = n(30052),
                f = n(10549),
                m = n(6594),
                v = n(59410),
                g = n(72571),
                y = n(90410),
                b = n(35487),
                w = n(91441);

            function _(e) {
                const {
                    title: t,
                    subtitle: n,
                    showCloseIcon: o = !0,
                    onClose: i,
                    renderBefore: s,
                    renderAfter: l,
                    draggable: u,
                    className: c,
                    unsetAlign: d
                } = e, [p, h] = (0, r.useState)(!1);
                return r.createElement(y.DialogHeaderContext.Provider, {
                    value: {
                        setHideClose: h
                    }
                }, r.createElement("div", {
                    className: a()(w.container, c, (n || d) && w.unsetAlign)
                }, s, r.createElement("div", {
                    "data-dragg-area": u,
                    className: w.title
                }, r.createElement("div", {
                    className: w.ellipsis
                }, t), n && r.createElement("div", {
                    className: a()(w.ellipsis, w.subtitle)
                }, n)), l, o && !p && r.createElement(g.Icon, {
                    className: w.close,
                    icon: b,
                    onClick: i,
                    "data-name": "close",
                    "data-role": "button"
                })))
            }
            var C = n(67179);
            const E = {
                    vertical: 20
                },
                S = {
                    vertical: 0
                };
            class O extends r.PureComponent {
                constructor() {
                    super(...arguments), this._controller = null, this._reference = null, this._orientationMediaQuery = null,
                        this._renderChildren = (e, t) => (this._controller = e, this.props.render({
                            requestResize: this._requestResize,
                            centerAndFit: this._centerAndFit,
                            isSmallWidth: t
                        })), this._handleReference = e => this._reference = e, this._handleClose = () => {
                            this.props.onClose()
                        }, this._handleOpen = () => {
                            void 0 !== this.props.onOpen && this.props.isOpened && this.props.onOpen(this.props.fullScreen || window.matchMedia(p.DialogBreakpoints.TabletSmall).matches)
                        }, this._handleKeyDown = e => {
                            var t;
                            if (!e.defaultPrevented) switch (this.props.onKeyDown && this.props.onKeyDown(e), (0, l.hashFromEvent)(e)) {
                                case 27:
                                    if (e.defaultPrevented) return;
                                    if (this.props.forceCloseOnEsc && this.props.forceCloseOnEsc()) return void this._handleClose();
                                    const {
                                        activeElement: n
                                    } = document, r = (0, o.ensureNotNull)(this._reference);
                                    if (null !== n) {
                                        if (e.preventDefault(), "true" === (t = n).getAttribute("data-haspopup") && "true" !== t.getAttribute("data-expanded")) return void this._handleClose();
                                        if ((0, u.isTextEditingField)(n)) return void r.focus();
                                        if (r.contains(n)) return void this._handleClose()
                                    }
                            }
                        }, this._requestResize = () => {
                            null !== this._controller && this._controller.recalculateBounds()
                        }, this._centerAndFit = () => {
                            null !== this._controller && this._controller.centerAndFit()
                        }
                }
                componentDidMount() {
                    v.subscribe(m.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), this._handleOpen(), void 0 !== this.props.onOpen && (this._orientationMediaQuery = window.matchMedia("(orientation: portrait)"), (0, i.mediaQueryAddEventListener)(this._orientationMediaQuery, this._handleOpen))
                }
                componentWillUnmount() {
                    v.unsubscribe(m.CLOSE_POPUPS_AND_DIALOGS_COMMAND, this._handleClose, null), null !== this._orientationMediaQuery && (0, i.mediaQueryRemoveEventListener)(this._orientationMediaQuery, this._handleOpen)
                }
                focus() {
                    (0, o.ensureNotNull)(this._reference).focus()
                }
                getElement() {
                    return this._reference
                }
                contains(e) {
                    var t, n;
                    return null !== (n = null === (t = this._reference) || void 0 === t ? void 0 : t.contains(e)) && void 0 !== n && n
                }
                render() {
                    const {
                        className: e,
                        wrapperClassName: t,
                        headerClassName: n,
                        isOpened: o,
                        title: i,
                        dataName: s,
                        onClickOutside: l,
                        additionalElementPos: u,
                        additionalHeaderElement: m,
                        backdrop: v,
                        shouldForceFocus: g = !0,
                        showSeparator: y,
                        subtitle: b,
                        draggable: w = !0,
                        fullScreen: O = !1,
                        showCloseIcon: M = !0,
                        rounded: x = !0,
                        isAnimationEnabled: D,
                        growPoint: T,
                        dialogTooltip: N,
                        unsetHeaderAlign: k,
                        onDragStart: R,
                        dataDialogName: P
                    } = this.props, I = "after" !== u ? m : void 0, A = "after" === u ? m : void 0, j = "string" == typeof i ? i : P || "";
                    return r.createElement(h.MatchMedia, {
                        rule: p.DialogBreakpoints.SmallHeight
                    }, u => r.createElement(h.MatchMedia, {
                        rule: p.DialogBreakpoints.TabletSmall
                    }, p => r.createElement(c.PopupDialog, {
                        rounded: !(p || O) && x,
                        className: a()(C.dialog, e),
                        isOpened: o,
                        reference: this._handleReference,
                        onKeyDown: this._handleKeyDown,
                        onClickOutside: l,
                        onClickBackdrop: l,
                        fullscreen: p || O,
                        guard: u ? S : E,
                        boundByScreen: p || O,
                        shouldForceFocus: g,
                        backdrop: v,
                        draggable: w,
                        isAnimationEnabled: D,
                        growPoint: T,
                        name: this.props.dataName,
                        dialogTooltip: N,
                        onDragStart: R
                    }, r.createElement("div", {
                        className: a()(C.wrapper, t),
                        "data-name": s,
                        "data-dialog-name": j
                    }, void 0 !== i && r.createElement(_, {
                        draggable: w && !(p || O),
                        onClose: this._handleClose,
                        renderAfter: A,
                        renderBefore: I,
                        subtitle: b,
                        title: i,
                        showCloseIcon: M,
                        className: n,
                        unsetAlign: k
                    }), y && r.createElement(d.Separator, {
                        className: C.separator
                    }), r.createElement(f.PopupContext.Consumer, null, e => this._renderChildren(e, p || O))))))
                }
            }
        },
        73572: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogContentItem: () => d
            });
            var r = n(59496),
                o = n(97754),
                i = n.n(o),
                s = n(1227),
                a = n(77687),
                l = n(72621);

            function u(e) {
                const {
                    url: t,
                    ...n
                } = e;
                return t ? r.createElement("a", { ...n,
                    href: t
                }) : r.createElement("div", { ...n
                })
            }
            var c = n(89185);

            function d(e) {
                const {
                    title: t,
                    subtitle: n,
                    removeBtnLabel: o,
                    onClick: d,
                    onClickFavorite: h,
                    onClickRemove: f,
                    isActive: m,
                    isSelected: v,
                    isFavorite: g,
                    isMobile: y = !1,
                    showFavorite: b = !0,
                    ...w
                } = e;
                return r.createElement(u, { ...w,
                    className: i()(c.itemRow, m && !v && c.active, y && c.mobile, v && c.selected),
                    onClick: p.bind(null, d),
                    "data-role": "list-item",
                    "data-active": m
                }, b && h && r.createElement(a.FavoriteButton, {
                    className: i()(c.favoriteButton, g && c.favorite, s.CheckMobile.any() && c.mobile),
                    isActive: m && !v,
                    isFilled: g,
                    onClick: p.bind(null, h),
                    "data-name": "list-item-favorite-button",
                    "data-favorite": g
                }), r.createElement("div", {
                    className: i()(c.itemInfo, !b && c.itemInfoWithPadding)
                }, r.createElement("div", {
                    className: i()(c.title, m && !v && c.active, y && c.mobile),
                    "data-name": "list-item-title"
                }, t), r.createElement("div", {
                    className: i()(c.details, m && !v && c.active, y && c.mobile)
                }, n)), r.createElement(l.RemoveButton, {
                    className: c.removeButton,
                    isActive: m && !v,
                    onClick: p.bind(null, f),
                    "data-name": "list-item-remove-button",
                    title: o
                }))
            }

            function p(e, t) {
                t.defaultPrevented || (t.preventDefault(), e(t))
            }
        },
        90410: (e, t, n) => {
            "use strict";
            n.d(t, {
                DialogHeaderContext: () => r
            });
            const r = n(59496).createContext({
                setHideClose: () => {}
            })
        },
        45879: (e, t, n) => {
            "use strict";
            n.d(t, {
                ManageDrawings: () => C
            });
            var r = n(59496),
                o = n(88537),
                i = n(72571),
                s = n(51049),
                a = n(2054),
                l = n(25177),
                u = n(18517),
                c = n(51951),
                d = n(5796),
                p = n(73572),
                h = n(2683),
                f = n(32455),
                m = n(505),
                v = n(75606),
                g = n(9267);
            (0, c.getLogger)("Chart.ManageDrawings");
            const y = new u.TranslatedString("remove all line tools for {symbol}", (0, l.t)("remove all line tools for {symbol}")),
                b = e => (0, l.t)("{drawingsCount} drawing", {
                    plural: "{drawingsCount} drawings",
                    count: e
                }).format({
                    drawingsCount: e.toString()
                }),
                w = (0, l.t)("Remove all drawings for this symbol"),
                _ = (0, l.t)("No drawings yet");
            class C extends r.PureComponent {
                constructor(e) {
                    super(e), this._totalCount = 0, this._model = null, this._symbolDrawingsMap = null, this._storageContentLoadingPromise = null, this._onItemClick = e => {
                        "" !== e && (this.props.chartWidget.setSymbol(e), null !== this._model && this.setState({
                            currentSymbol: e
                        }), this.props.onClose && this.props.onClose())
                    }, this._onRemove = async e => {
                        if (this._model && this._symbolDrawingsMap) {
                            const t = this._symbolDrawingsMap.get(e);
                            if (t) {
                                const n = Array.from(t).map(e => (0, o.ensureNotNull)(this._model).model().dataSourceForId(e)).filter(h.notNull);
                                n.length > 0 && this._model.removeSources(n, !1, y.format({
                                    symbol: e
                                })), this._updateItems()
                            }
                        }
                    }, this._updateItems = async () => {
                        if (null !== this._model) {
                            const e = await this._getItems(this._model.model().dataSources());
                            this.setState({
                                items: e
                            })
                        }
                    }, this._updateTheme = () => {
                        const e = a.watchedTheme.value();
                        this.setState({
                            theme: e
                        })
                    }, this.state = {
                        currentSymbol: null,
                        items: null,
                        theme: a.watchedTheme.value()
                    }
                }
                componentDidMount() {
                    this.props.chartWidget.withModel(this, async () => {
                        this._model = this.props.chartWidget.model(), this._model.model().dataSourceCollectionChanged().subscribe(this, this._updateItems);
                        const e = await this._getItems(this._model.model().dataSources());
                        this.setState({
                            currentSymbol: this._model.mainSeries().symbol(),
                            items: e
                        }, () => {
                            var e, t;
                            return null === (t = (e = this.props).onInitialized) || void 0 === t ? void 0 : t.call(e)
                        })
                    }), a.watchedTheme.subscribe(this._updateTheme)
                }
                componentWillUnmount() {
                    a.watchedTheme.unsubscribe(this._updateTheme), null !== this._model && this._model.model().dataSourceCollectionChanged().unsubscribe(this, this._updateItems)
                }
                render() {
                    const {
                        isMobile: e
                    } = this.props, {
                        currentSymbol: t,
                        items: n
                    } = this.state, o = this._symbolDrawingsMap ? this._symbolDrawingsMap.size : 0, i = `${s=o,(0,l.t)("{symbolsCount} symbol",{plural:"{symbolsCount} symbols",context:"symbols_and_drawings_count",count:s}).format({symbolsCount:s.toString()})} ${(e=>(0,l.t)("with {drawingsCount} drawing",{plural:"with {drawingsCount} drawings",context:"symbols_and_drawings_count",count:e}).format({drawingsCount:e.toString()}))(this._totalCount)}`;
                    var s;
                    return r.createElement(r.Fragment, null, n && n.length > 0 && r.createElement("div", {
                        className: g.title
                    }, i), null === n || 0 === n.length ? this._renderEmptyContent() : n.map(n => r.createElement(p.DialogContentItem, {
                        key: n.symbol,
                        title: n.symbol,
                        subtitle: b(n.drawingsCount),
                        removeBtnLabel: w,
                        isActive: n.symbol === t,
                        isMobile: e,
                        onClick: this._onItemClick.bind(this, n.symbol),
                        onClickRemove: this._onRemove.bind(this, n.symbol),
                        showFavorite: !1
                    })))
                }
                _renderEmptyContent() {
                    const {
                        theme: e
                    } = this.state, t = e === s.StdTheme.Dark ? v : m;
                    return null === this._symbolDrawingsMap ? r.createElement(f.Spinner, {
                        className: g.spinner
                    }) : r.createElement("div", {
                        className: g.empty
                    }, r.createElement(i.Icon, {
                        className: g.image,
                        icon: t
                    }), r.createElement("span", null, _))
                }
                async _getStorageContent() {
                    return new Map
                }
                async _getItems(e) {
                    const t = [],
                        n = this._getSymbolDrawingsMap(e);
                    return (await this._getStorageContent()).forEach((e, t) => {
                        const r = n.get(t) || new Set;
                        e.forEach(e => r.add(e)), n.set(t, r)
                    }), this._symbolDrawingsMap = n, this._totalCount = 0, this._symbolDrawingsMap.forEach((e, n) => {
                        t.push({
                            symbol: n,
                            drawingsCount: e.size
                        }), this._totalCount = this._totalCount + e.size
                    }), t.sort((e, t) => e.drawingsCount === t.drawingsCount ? e.symbol.localeCompare(t.symbol) : e.drawingsCount > t.drawingsCount ? -1 : 1)
                }
                _getSymbolDrawingsMap(e) {
                    const t = new Map;
                    return e.forEach(e => {
                        var n;
                        if ((0, d.isLineTool)(e) && e.showInObjectTree()) {
                            const r = null !== (n = e.symbol()) && void 0 !== n ? n : "",
                                o = t.get(r) || new Set;
                            o.add(e.id()), t.set(r, o)
                        }
                    }), t
                }
            }
        },
        99329: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                ObjectTreeDialogRenderer: () => E
            });
            var r = n(59496),
                o = n(87995),
                i = n(58884),
                s = n(59339),
                a = n(63694),
                l = n(30052),
                u = n(25177),
                c = n(53337),
                d = n(96038),
                p = n(45879);
            var h = n(93321),
                f = n(20779),
                m = n(35842),
                v = n(32713);
            class g extends r.PureComponent {
                constructor(e) {
                    super(e), this._isMounted = !1, this._dialogRef = r.createRef(), this._renderChildren = e => r.createElement(y, {
                        isSmallTablet: e,
                        viewModel: this.props.viewModel
                    }), this._handleMediaChange = () => {
                        this.state.showDrawer && !window.matchMedia(d.DialogBreakpoints.TabletSmall).matches && this.setState({
                            showDrawer: !1
                        })
                    }, this._onManageDrawings = e => {
                        throw new Error("not supported")
                    }, this._closeDrawer = () => {
                        this.setState({
                            showDrawer: !1
                        })
                    }, this._handleContextMenuOpened = e => {
                        this.setState({
                            isContextMenuOpened: e
                        })
                    }, this._matchMedia = window.matchMedia(d.DialogBreakpoints.TabletSmall), this.state = {
                        showDrawer: !1,
                        showDialog: !1,
                        isContextMenuOpened: !1
                    }
                }
                componentDidMount() {
                    this._isMounted = !0, this._matchMedia.addListener(this._handleMediaChange), this.props.viewModel.isContextMenuOpened().subscribe(this._handleContextMenuOpened)
                }
                componentWillUnmount() {
                    this._isMounted = !1, this._matchMedia.removeListener(this._handleMediaChange), this.props.viewModel.isContextMenuOpened().unsubscribe(this._handleContextMenuOpened)
                }
                render() {
                    return r.createElement(r.Fragment, null, r.createElement(l.MatchMedia, {
                        rule: d.DialogBreakpoints.TabletSmall
                    }, e => r.createElement(c.AdaptivePopupDialog, {
                        additionalElementPos: "after",
                        additionalHeaderElement: !1,
                        className: v.dialog,
                        dataName: "object-tree-dialog",
                        isOpened: !0,
                        onClickOutside: this.state.showDialog || e || this.state.isContextMenuOpened ? () => {} : this.props.onClose,
                        onClose: this.props.onClose,
                        ref: this._dialogRef,
                        render: () => this._renderChildren(e),
                        title: (0, u.t)("Object tree"),
                        showSeparator: !0
                    })), r.createElement(a.DrawerManager, null, this.state.showDrawer && r.createElement(s.Drawer, {
                        onClose: this._closeDrawer,
                        position: "Bottom"
                    }, r.createElement(p.ManageDrawings, {
                        onClose: this._closeDrawer,
                        chartWidget: this.props.activeChartWidget,
                        isMobile: !0
                    }))))
                }
            }

            function y(e) {
                const {
                    isSmallTablet: t,
                    viewModel: n
                } = e, o = (0, r.useMemo)(() => ({
                    size: t ? 1 : 0,
                    smallSizeTreeNodeAction: 0
                }), [t]);
                return r.createElement(m.SizeContext.Provider, {
                    value: o
                }, r.createElement(h.ObjectTree, {
                    nodeRenderer: f.NodeRenderer,
                    showHeader: !1,
                    viewModel: n,
                    isDialog: !0
                }))
            }
            var b = n(33290),
                w = n(85473),
                _ = n(42997),
                C = n(89014);
            class E extends C.DialogRenderer {
                constructor() {
                    super(), this._handleClose = () => {
                        o.unmountComponentAtNode(this._container), this._setVisibility(!1), null !== this._viewModel && (this._viewModel.destroy(), this._viewModel = null)
                    };
                    const e = (0, b.service)(w.CHART_WIDGET_COLLECTION_SERVICE);
                    this._activeChartWidget = e.activeChartWidget.value(), this._viewModel = new _.ObjectTree(e.activeChartWidget)
                }
                hide() {
                    this._handleClose()
                }
                isVisible() {
                    return this.visible().value()
                }
                show() {
                    (0, i.loadAllSourcesIcons)().then(() => {
                        null !== this._viewModel && (o.render(r.createElement(g, {
                            onClose: this._handleClose,
                            viewModel: this._viewModel,
                            activeChartWidget: this._activeChartWidget
                        }), this._container), this._setVisibility(!0))
                    })
                }
            }
        },
        77687: (e, t, n) => {
            "use strict";
            n.d(t, {
                FavoriteButton: () => d
            });
            var r = n(25177),
                o = n(59496),
                i = n(97754),
                s = n(72571),
                a = n(17110),
                l = n(6639),
                u = n(16842);
            const c = {
                add: (0, r.t)("Add to favorites"),
                remove: (0, r.t)("Remove from favorites")
            };

            function d(e) {
                const {
                    className: t,
                    isFilled: n,
                    isActive: r,
                    onClick: d,
                    ...p
                } = e;
                return o.createElement(s.Icon, { ...p,
                    className: i(u.favorite, "apply-common-tooltip", n && u.checked, r && u.active, t),
                    icon: n ? a : l,
                    onClick: d,
                    title: n ? c.remove : c.add
                })
            }
        },
        21258: (e, t, n) => {
            "use strict";
            n.d(t, {
                hoverMouseEventFilter: () => i,
                useAccurateHover: () => s,
                useHover: () => o
            });
            var r = n(59496);

            function o() {
                const [e, t] = (0, r.useState)(!1);
                return [e, {
                    onMouseOver: function(e) {
                        i(e) && t(!0)
                    },
                    onMouseOut: function(e) {
                        i(e) && t(!1)
                    }
                }]
            }

            function i(e) {
                return !e.currentTarget.contains(e.relatedTarget)
            }

            function s(e) {
                const [t, n] = (0, r.useState)(!1);
                return (0, r.useEffect)(() => {
                    const t = t => {
                        if (null === e.current) return;
                        const r = e.current.contains(t.target);
                        n(r)
                    };
                    return document.addEventListener("mouseover", t), () => document.removeEventListener("mouseover", t)
                }, []), t
            }
        },
        94707: (e, t, n) => {
            "use strict";
            n.d(t, {
                Separator: () => s
            });
            var r = n(59496),
                o = n(97754),
                i = n(91626);

            function s(e) {
                return r.createElement("div", {
                    className: o(i.separator, e.className)
                })
            }
        },
        72621: (e, t, n) => {
            "use strict";
            n.d(t, {
                RemoveButton: () => c
            });
            var r = n(25177),
                o = n(59496),
                i = n(97754),
                s = n(72571),
                a = n(72351),
                l = n(73432);
            const u = {
                remove: (0, r.t)("Remove")
            };

            function c(e) {
                const {
                    className: t,
                    isActive: n,
                    onClick: r,
                    onMouseDown: c,
                    title: d,
                    hidden: p,
                    "data-name": h = "remove-button",
                    ...f
                } = e;
                return o.createElement(s.Icon, { ...f,
                    "data-name": h,
                    className: i(l.button, "apply-common-tooltip", n && l.active, p && l.hidden, t),
                    icon: a,
                    onClick: r,
                    onMouseDown: c,
                    title: d || u.remove
                })
            }
        },
        32455: (e, t, n) => {
            "use strict";
            n.d(t, {
                Spinner: () => s
            });
            var r = n(59496),
                o = n(97754),
                i = n(63654);
            n(24780);

            function s(e) {
                const t = o(e.className, "tv-spinner", "tv-spinner--shown", "tv-spinner--size_" + i.spinnerSizeMap[e.size || i.DEFAULT_SIZE]);
                return r.createElement("div", {
                    className: t,
                    style: e.style,
                    role: "progressbar"
                })
            }
        },
        35487: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 17" width="17" height="17" fill="currentColor"><path d="m.58 1.42.82-.82 15 15-.82.82z"/><path d="m.58 15.58 15-15 .82.82-15 15z"/></svg>'
        },
        75606: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120"><path fill="#B2B5BE" fill-rule="evenodd" d="M23 39a36 36 0 0 1 72 0v13.15l15.1 8.44 2.16 1.2-1.64 1.86-12.85 14.59 3.73 4.03L98.57 85 95 81.13V117H77v-12H67v9H50V95H40v22H23V81.28l-3.8 3.61-2.76-2.9 4.05-3.84-12.77-14.5-1.64-1.86 2.16-1.2L23 52.34V39Zm72 36.33 10.98-12.46L95 56.73v18.6ZM23 56.92v18.03L12.35 62.87 23 56.92ZM59 7a32 32 0 0 0-32 32v74h9V91h18v19h9v-9h18v12h10V39A32 32 0 0 0 59 7Zm-7 36a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm19 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></svg>'
        },
        505: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120"><path fill="#131722" fill-rule="evenodd" d="M23 39a36 36 0 0 1 72 0v13.15l15.1 8.44 2.16 1.2-1.64 1.86-12.85 14.59 3.73 4.03L98.57 85 95 81.13V117H77v-12H67v9H50V95H40v22H23V81.28l-3.8 3.61-2.76-2.9 4.05-3.84-12.77-14.5-1.64-1.86 2.16-1.2L23 52.34V39Zm72 36.33 10.98-12.46L95 56.73v18.6ZM23 56.92v18.03L12.35 62.87 23 56.92ZM59 7a32 32 0 0 0-32 32v74h9V91h18v19h9v-9h18v12h10V39A32 32 0 0 0 59 7Zm-7 36a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm19 3a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></svg>'
        },
        17110: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="currentColor" d="M9 1l2.35 4.76 5.26.77-3.8 3.7.9 5.24L9 13l-4.7 2.47.9-5.23-3.8-3.71 5.25-.77L9 1z"/></svg>'
        },
        6639: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M9 2.13l1.903 3.855.116.236.26.038 4.255.618-3.079 3.001-.188.184.044.259.727 4.237-3.805-2L9 12.434l-.233.122-3.805 2.001.727-4.237.044-.26-.188-.183-3.079-3.001 4.255-.618.26-.038.116-.236L9 2.13z"/></svg>'
        }
    }
]);

import Renko from "./Renko";
import updatingDataWrapper from "./updatingDataWrapper";

const RenkoWithUpdatingData = updatingDataWrapper(Renko);

export default RenkoWithUpdatingData;

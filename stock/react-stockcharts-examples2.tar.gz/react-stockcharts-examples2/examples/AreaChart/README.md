### Pre req
node 6+

npm 3+


```
$ git clone https://github.com/rrag/react-stockcharts-examples2
$ cd examples/<example you wish>

$ npm install

$ npm start # this should launch a browser with http://localhost:3000
```


import Kagi from "./Kagi";
import updatingDataWrapper from "./updatingDataWrapper";

const KagiWithUpdatingData = updatingDataWrapper(Kagi);

export default KagiWithUpdatingData;


import PointAndFigure from "./PointAndFigure";
import updatingDataWrapper from "./updatingDataWrapper";

const PointAndFigureWithUpdatingData = updatingDataWrapper(PointAndFigure);

export default PointAndFigureWithUpdatingData;
